
# thead demo

print("do thread demo")

