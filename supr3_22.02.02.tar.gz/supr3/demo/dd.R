
# dfs demo

print("do DD demo")

  tmp <- tempdir()
  #dir.create(tmp)
  data.name <- substr(tmp, nchar("/tmp/")+1, stop=nchar(tmp))
  #data.name <- substr(tmp, 2, stop=nchar(tmp))
  if(DD.exists(data.name))
     DD.rm(data.name, TRUE)

  DD.open(data.name)

  N <- 100L  # number of subsets
  K <- 1000L # subset size
  mis.prob <- 0.5

  #files <- paste("EM_data/part_", 1:N, ".rdata", sep="")
  #tmp <- tempdir()
  files <- paste(tmp,"/part_", 1:N, ".rdata", sep="")

  for(i in 1:length(files)){
    x <- rnorm(K)
    mis <- runif(K) < mis.prob
    x[mis] <- NA
    x <- data.frame(x=x)
    save(N, x, file=files[i])
  }

  DD.put(data.name, files, NULL)
  DD.list(data.name)
  # a <- DD.list(data.name); attributes(a)
  cat("unlink(", tmp, ")\n")
  unlink(tmp, recursive = TRUE)

  DD.replicate(data.name)
  DD.list(data.name)

  DD.replicate(data.name)
  DD.list(data.name)

  DD.persist(data.name, "tmp")
  DD.list(data.name)

  a <- DD.get(data.name, NULL)

  DD.persist(data.name, "file")


