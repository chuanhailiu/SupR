
if(FALSE && !is.loaded("R_thread_init")) {
  dyn.load("libsupr.so")
  .Call("R_thread_init")
}

nextSubset <- function(env = parent.frame()){
  .Call("TR_getNextSubset", env)
}

cluster.combine <- function(x, combine, bykey = FALSE, env = parent.frame()){
  if(bykey) {
    res <- .Call("TR_combine_bykey", x, combine, env)
    res
  }  else {
    .Call("TR_combine", x, combine, env)
  }
}

#clusterCombine <- cluster.combine
#combine <- cluster.combine

#sync.eval <- function(expr, mutex="mutex.testing", env=parent.frame())
#{
#  .Call("TR_sync_eval", expr, mutex, env)
#}

# monitor -> mutex???
# cluster.wait ?
if(FALSE){
# the current functions are all sync.* for eval, wait, and notify 
  wait <- function(monitor, time=0, env=parent.frame())
  {
    .Call("TR_wait", monitor, time, env)
  }


# cluster.notify ?
  notify <- function(monitor, all=FALSE, env=parent.frame())
  {
    .Call("TR_notify", monitor, as.logical(all), env)
  }

# cluster.notifyAll ? did with sync.
  notifyAll <- function(monitor, env=parent.frame())
  {
    .Call("TR_notify", monitor, TRUE, env)
  }

  # use JobEnv$name <- value
  put.par <- function(name, value, job = NULL, env=parent.frame()){
    .Call("TR_put_par", name, value, job, env)
  }
  # use JobEnv$name
  get.par <- function(name, job = NULL, env=parent.frame()){
    .Call("TR_get_par", name, job, env)
  }

}

cond.count <- function(..., cond.name = "default", env=parent.frame()) {
    .Call("TR_countAndGet", cond.name, pairlist(...))
}

#loadRData <- function(file){
#    env = new.env()
#    load(file, envir = env)
#    as.list(env)
#}

send.driver <- function(msg, env=parent.frame()){
    .Call("TR_sendDriver", as.character(msg), env)
}


