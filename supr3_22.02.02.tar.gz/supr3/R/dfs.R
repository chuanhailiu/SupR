

dim.DD.frame <- function(x) {
  v <- x$value
  x <- x$x
  if(is.null(x)){
    return(v)
  } else if(class(x) == "DD.frame"){
    n <- length(x)
    m <- if(is.null(v)) 0L else v[1]
    c(m + if(n==0) n else length(x[[1]]), n)
  } else { ## "DD.value" ?
    if(is.null(v)) x else c(v[1]+x[1], x[2])
  }
}

DFS.startNamenode <- function(verbose=FALSE, debug=FALSE, infoConn=NULL)
{
  .Call("DFS_startNamenode", as.logical(verbose), as.logical(debug),
	infoConn)
}

open.DD <- function(connection, name = NULL, create = TRUE){
  .Call("DD_open4", connection, name, create, NULL)
} 

close.DD <- function(connection, name, save = TRUE){
  if(save){
    DD.persist(name, level = "file")
  }
  .Call("DD_close3", connection, as.character(name), NULL)
}

open.DDEnv <- function(ddenv, name=NULL, create = TRUE){
  .Call("DD_open4", ddenv, name, create, NULL)
}
close.DDEnv <- function(ddenv, name, save = TRUE){
  if(missing(name)) name = attr(ddenv, "name")
  if(save) DD.persist(name, level = "file")
  
  .Call("DD_close3", ddenv, as.character(name), NULL)
}

print.DDEnv <- function(x, debug=FALSE, ..., env=parent.frame()){
  name <- attr(x, "name")
  if(is.null(name)){
    if(debug){
      print.default(x)
      call <- x$.LocalEnv$call
      while(typeof(call) == "language"){
        print(call)
        cat("(", typeof(call$x), ") x: \n")
        print(call$x)
        cat("(", typeof(call$i), ") i: \n")
        print(call$i)
        cat("(", typeof(call$j), ") j: \n")
        print(call$j)
        cat("(", typeof(call$group), ") group: \n")
        print(call$group)
        cat("(", typeof(call$env), ") env: \n")
        print(ls.str(call$env))
        cat("//env\n\n")
        call <- call$x
      }
      cat("dd_name: ", call, "\n")
    } else {
      x <- .Call("DDT_call", x)
      # print(x)
      if(class(x) == ".__DDEnvPrint__."){
        attr(x, "class") <- NULL
        cat(x,"\n");
      } else {
        print(x)
      }
      return(x)
    }
  } else {
      x <- .Call("DDT_call", x)
      # print.default(x)
      if(class(x) == ".__DDEnvPrint__."){
        attr(x, "class") <- NULL
        cat(x,"\n");
      } else {
        print(x)
      }
      return(x)
  }
}


mv <- function(src, dest){
   if(is.DDEnv(src)) {
     src = attr(src, "name")
   } else if(!is.character(src)) {
     src <- as.character(src)
     #attr(src, "name") <- dest
   }
   .Call("DD_operation", "move", NULL, pairlist(src = src, dest = 
						as.character(dest)))
}

#dir <- function(x, ...) UseMethod("dir")
#dir.default <- function(x, ...) base::dir(x, ...)

ls <- function(x, ...) UseMethod("ls")
ls.default <- function(x, ...) base::ls(x, ...)
ls.DFSNameNode <- function(connection){
  .Call("DD_list", structure(".", class="DD",
  	dfs.name=attr(connection,"conn")))
}
ls.DD <- function(x) .Call("DD_list", x)



#.Call("DD_put", dd.name, subsets, subset.names)
`[<-.DD` <- function(x, names, values){
   y <- x
   .Call("DD_put", x, values, names)
   y
}

`[.DD` <- function(x, names, ..., env = parent.frame())
{
   names <- if(missing(names)) NULL else as.character(names)
   .Call("DD_get", x, names, env, pairlist(...))
}

persist <- function (name, level = c("file", "tmp", "shm", "mem", "null")) 
{
    level = which(level[1] == rev(c("file", "tmp", "shm", "mem", 
        "null"))) - 1L
    if (length(level) == 0) 
        stop("invalid 'level' argument")
    if(is.DDEnv(name))
	    name = attr(name, "name")
    .Call("DD_operation", "persist", name, pairlist(level = level))
}

is.DDEnv <- function(x) any(class(x)=="DDEnv")


# make one more replicate
replicate.DDEnv <- function (name)
{
    .Call("DD_replicate", attr(name, "name"))
}

replicate <- function(x, ...) UseMethod("replicate")
replicate.default <- function(n, ...) base::replicate(n, ...)


if(FALSE){
`[.DDEnv` <- function(x, subset.names, ..., env = parent.frame()) {
  name <- attr(x, "name")
  .Call("DD_get", name, subset.names, env, pairlist(...)) 
}
}

`[.DDEnv` <- function(x, i, j, combine, ..., env = list()) {
  if(missing(i)) i <- NULL
  if(missing(j)) j <- NULL
  if(missing(combine)) combine <- NULL
##  if(FALSE){
##    i <- if (is.symbol(qexpr <- substitute(i))) i else qexpr
##    j <- if (is.symbol(qexpr <- substitute(j))) j else qexpr
##    group <- if (is.symbol(qexpr <- substitute(group))) group else qexpr
##    env <- as.environment(append(as.list(env), pairlist(...)))
##  } else {
    i <- substitute(i)
    j <- substitute(j)
    combine <- substitute(combine)
#    env <- as.environment(list(...))
    env <- as.environment(append(as.list(env), pairlist(...)))
##  }
 # stop("not implemented yet")
  .Call("DDT_tmp", list(match.call()), x, i, j, combine,  env) 
}


`[<-.DDEnv` <- function(x, subset.names, values) {
  name <- attr(x, "name")
  .Call("DD_put", name, values, subset.names)
  x
}

# FIXME
dfs.open <- function(name=NULL, create = TRUE, dfs=NULL){
  .Call("DD_open4", dfs, name, create, NULL)
}
dfs.close <- function(name, save = TRUE, dfs=NULL){
  if(missing(name)) name = attr(dfs, "name")
  cat("name:", name, "\n")
  if(save) DD.persist(name, level = "file")
  
  .Call("DD_close3", dfs, as.character(name), NULL)
}


dfs.localfuns <- pairlist(
  open  = dfs.open,
  close = dfs.close
)




if(FALSE){
  #examples:

  #supr.options(verbose=TRUE)

  library(supr3)
  connection <- DFS.startNamenode()

  supr.options(verbose=TRUE, debug=FALSE)
  supr.options(verbose=FALSE)

  library(supr3)
  connection <- DFS.startNamenode()

  open(connection, "EM_data")

  close(connection, "EM_data", FALSE)

  #conn <- socketConnection(port=7205)
  #serialize(1:10, conn)

  methods(open)

  grep("DD", ls("package:supr3"), value=TRUE)

  x <- open(connection, "EM_data")
  x[as.character(1:10)] <- as.list(1:10)
  `[.DD` <- Whoops
  x[]

  persist(x)

  DD.exists("EM_data")
  exists("EM_data", envir=connection)

 


#  x$as.character(1:10) <- as.list(1:10)

  
  

}


