
#  dyn.unload("libsupr.so")

#  dyn.load("libsupr.so")

py.init <- function(){
  .Call("Rython_init")
}


# list of charactors 
py.ls <- function(dict = NULL, show.module=TRUE){
    .Call("Rython_ls", dict, show.module)
}

py.class <- function(py.object) {
  .Call("Rython_getClass", py.object)
}

# mode option:  any, func, field, method
py.attributes <- function(py.object, mode="any"){
  .Call("Rython_getAttrNames", py.object, mode)
}

py.attr <- function(x, which){
  .Call("Rython_getAttr", x, which)
}

py.setAttr <- function(x, which, value){
  .Call("Rython_setAttr", x, which, value)
}

py.toR <- function(py.object){
  .Call("Rython_toR", py.object)
}

##python.dict <- function(module){ .Call("Rython_getModuleDict", module); }


py.doCall <- function(what, args, quote = FALSE, envir = parent.frame()){
  if (!is.list(args))
        stop("'args' must be a list")
  if (quote)
        args <- lapply(args, enquote)

  .Call("Rython_doCall", what, args, quote, envir)
}

py.local <- function(text) {# text or compiled code
 .Call("Rython_parseString", text)
}

py.repl <- function() {
  .Call("Rython_repl")
}

if(TRUE){

#X.import <- function(name, fromlist = NULL)
#{
#  .Call("Rython_import", name, fromlist)
#}


`$.PyObject` <- function(py.object, a){
  py.toR(py.attr(py.object, substitute(a)))
}



} else {

  np <- import("numpy")
  si <- attr(np, "sin")
  py.toR(si)

  py.help(si)

#>>> import numpy as np
#>>> import matplotlib.pylab as plt
#>>> x = np.linspace(-np.pi, np.pi, 201)
#>>> plt.plot(x, np.sin(x))
#>>> plt.xlabel('Angle [rad]')
#>>> plt.ylabel('sin(x)')
#>>> plt.axis('tight')
#>>> plt.show()

  plt <- import("matplotlib.pylab")
  x <- py.toR(py.attr(np, "linspace"))(-pi, pi, 201)

    plt.plot <- py.toR(py.attr(plt, "plot"))
    np.sin <-   py.toR(py.attr(np, "sin"))
  plt.plot(x, np.sin(x))

    plt.xlabel <- py.toR(py.attr(plt, "xlabel"))
    plt.ylabel <- py.toR(py.attr(plt, "ylabel"))
    plt.axis   <- py.toR(py.attr(plt, "axis"))
    plt.show   <- py.toR(py.attr(plt, "show"))

  plt.xlabel('Angle [rad]')
  plt.ylabel('sin(x)')
  plt.axis('tight')
  plt.show()

####################################
####################################

#import <- function(name, fromlist = NULL)
#{
#  .Call("Rython_import", name, fromlist)
#}

#`$.PyObject` <- function(py.object, a){
#  py.toR(py.attr(py.object, substitute(a)))
#}


####################################

# python code:

# import numpy as np
# import matplotlib.pylab as plt
# x = np.linspace(-np.pi, np.pi, 201)
# plt.plot(x, np.sin(x))
# plt.xlabel('Angle [rad]')
# plt.ylabel('sin(x)')
# plt.axis('tight')
# plt.show()

####################################

  np  <- import("numpy")
  plt <- import("matplotlib.pylab")
  x   <- np$linspace(-pi, pi, 201L)
  plt$plot(x, np$sin(x))
  plt$xlabel('Angle [rad]')
  plt$ylabel('sin(x)')
  plt$axis('tight')
  plt$show()

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    plt.plot   <- plt$plot
    np.sin     <- np$sin
    np.linspace<- np$linspace
    plt.xlabel <- plt$xlabel 
    plt.ylabel <- plt$ylabel 
    plt.axis   <- plt$axis
    plt.show   <- plt$show
#------------------------------------

  x   <- np.linspace(-pi, pi, 201)
  plt.plot(x, np.sin(x))
  plt.xlabel('Angle [rad]')
  plt.ylabel('sin(x)')
  plt.axis('tight')
  plt.show()

####################################

####################################


  py.local("x = 1 + 2") 

  python.ls()

  class(.PythonEnv$sys)
  python.class(.PythonEnv$sys)
  python.attributes(.PythonEnv$sys)

  # Cached modules
  modules <- python.attr(.PythonEnv$sys, "modules")
  class(modules)
  python.class(modules)

  sm <- python.get("supr", modules)
  class(sm)
  python.class(sm)
  python.attributes(sm)

  g <- python.attr(sm, "get")
  python.attr(g, "__doc__")


  ## run dir(something)
  #python.dict(.PythonEnv$builtins)
  python.attributes(.PythonEnv$builtins)

  a <- python.attr(.PythonEnv$builtins, "abs")
  python.doCall(a, list(-10))



  python.attributes(.PythonEnv$builtins)




  python.run("x = 1 +2")
  python.class(.PythonEnv$main)

  python.attributes(.PythonEnv$main)

  python.attr(.PythonEnv$main, "x")
  python.setAttr(.PythonEnv$main, "x", 10L)




}

py.put <- function(name, value, dict = NULL)
{
  .Call("Rython_assign", name, value, dict)
}


py.get <- function(name, dict = NULL)
{
  .Call("Rython_get", name, dict)
}



py.print <- function(object)
{
  invisible(.Call("Rython_print", object))
}

## print.PyObject <- function(object, ...) { invisible(python.print(object)) }
print.PyObject <- function(object, ...) { invisible(py.print(object)) }

py.run <- function(src, file)
{
  if(!missing(src)) {
    .Call("Rython_runCommand", as.character(src))
  } else {
    .Call("Rython_source", as.character(file))
  }
  
}

py.help <- function(object) {
  .Call("Rython_help", object);
}

py.import <- function(what = NULL, as = NULL, from = NULL)
{
  .Call("Rython_import", what, as, from)
}


py.invoke <- function(method, object, ...){
##  .Call("Rython_callMethod", method, object, pairlist(...))
  .Call("Rython_invokeMethod", method, object, list(...))
}

#  python.init()


if(FALSE){

  py.run("x = ['','a','b']")
  x <- py.get("x")
  xc <- py.class(x)
  len <- py.attr(xc, "__len__")
  py.invoke(len, x)

  a <- py.attr(xc, "append")
  py.invoke(a, x, 1)
  py.get("x")

#  import os



  a <- py.attr(x, "append")
  py.help(a)


  py.ls() ## ls.py and use Method?
  py.run("import sys")
  py.ls(show = FALSE) ## ls.py and use Method?

  sys <- py.get("sys")

  py.attributes(sys, mode="func")
  py.attributes(sys, mode="cfunc")
  py.attributes(sys, mode="method")

  out <- py.get("sys.__stdout__")
  py.attributes(out)
  py.attributes(out, "cfunc")

  dir <- py.get("sys.__stdout__.__dir__")
  so <- py.get("sys.__stdout__.__sizeof__")

  modules <- py.get()
  b <- py.get("builtins", modules)
  py.attributes(b)
  py.attributes(b, "cfunc")
  py.attr(b, "abs")
  py.help(py.attr(b, "abs"))

  py.run("import builtins")
  b <- py.get("builtins")
  py.attributes(b)
  d <- py.attr(b, "dir")
  py.help(d)



  






  n <- py.import("sys")



  n <- py.run("import sys")

##  FIXME:
##  n <- py.run("import numpy")
##  n <- py.import("numpy")


  #python.ls()
  python.dir(.PythonEnv$sys)
  python.dir(.PythonEnv$main)
  python.dir(.PythonEnv$builtins)

  py.run("x = 1 +2")
##  .Call("Rython_globalDict")
  py.run("print(x)")

  x <- python.attr(.PythonEnv$main, "x")

  y <- .Call("Rython_serialize", x)

  xx <- 1:10
  python.run("print(xx)")

  .Call("Rython_source", "ry.py")


  sys <- python.get()
  modules <- .Call("Rython_getAttr", sys, "modules")



  python.run("x = 1 +2")
  python.run("print(dir())")

#  a <-  .Call("Rython_parseString", "x = 1 +2")

x <- python.put("myvar", 1:10)
x

a <- python.get("my.var")
modules <- python.get("modules") # in the sys module, a dict object
a <- python.ls(modules)
a
stat <- python.get("stat", modules)
a <- python.ls(stat)

python.ls()
python.ls("any")
keys <- .Call("Rython_getAttr", modules, "keys")
.Call("Rython_getAttr", keys, "__doc__")

.Call("Rython_callFunction", keys, NULL)

.Call("Rython_getClass", keys)

.Call("Rython_getAttrNames", keys)

  .Call("Rython_import", "sys", NULL)

  .Call("Rython_import", "sys")


} else {
}

