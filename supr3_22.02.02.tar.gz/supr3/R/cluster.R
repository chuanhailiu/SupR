
# master and dfs: addr or connection objects
# use default/existing master and dfs

## environments:
# .SuprEnv: local in .GlobalEnv
# ClusterEnv: a connection to driver's .SuprEnv

#ClusterEnv <- .Call("Cluster_createObjectTableEnv")
#MasterEnv <- new.env(parent=emptyenv());
ContextEnv <- new.env(parent=emptyenv());

#`$<-.ClusterContext` <- function(env, name, value){ NULL }
#masterenv <- function() MasterEnv
#contextenv <- function() ContextEnv
#driverenv <- function()  DriverEnv
suprenv <- function(address) .Call("Supr_connectionAsEnv", address)
masterenv <- function() {
  addr <- .Call("Supr_master_address")
  .Call("Supr_connectionAsEnv", addr)
}
driverenv <- function() .Call("Supr_connectionAsEnv", context()$driver)
clusterenv <- function() {
#      	.Call("Supr_connectionAsEnv", context()$driver)
#	SEXP Supr_cntxt(SEXP args, SEXP env)
  cntxt <- context()
  if(is.character(cntxt$driver))
    context(driver=cntxt$driver)
  cntxt$driver
}
dfsenv <- function() {
  cntxt <- context()
  if(is.character(cntxt$dfs))
    context(dfs=cntxt$dfs)
  cntxt$dfs
}

nnenv <- function() {
  addr <- .Call("Supr_namenode_address")
  .Call("Supr_connectionAsEnv", addr)
}
workerenv <- function(which = 0){
  addr <- .Call("Supr_worker_address", as.integer(which))
  if(which==0) return(addr)
  .Call("Supr_connectionAsEnv", addr)
}
dnenv <- function(which){
  addr <- .Call("Supr_datanode_address", as.integer(which))
  if(which==0) return(addr)
  .Call("Supr_connectionAsEnv", addr)
}

info <- function(msg){
  .Call("Cluster_info", msg)
}
send <- function(msg, to){
  .Call("Cluster_send", msg, to)
}
recv <- function(timeout=0){
  .Call("Cluster_recv", as.numeric(timeout))
}
messages <- function(){
  .Call("Cluster_messages")
}

broadcast <- function(..., addr=NULL){
       	.Call("Cluster_broadcast", list(...), addr)
}
broadcasted <- function(new=FALSE, timeout=0){
	.Call("Cluster_broadcasted", as.logical(new), as.numeric(timeout));
}
#broadcastedEnv <- new.env(parent = emptyenv())


startCluster <- function(port = NULL, master = NULL, dfs.namenode = NULL,
	verbose=FALSE, debug=FALSE, info=TRUE){
  if(!is.null(port)) port <- as.integer(port)
  if(!is.null(master)) master <- as.character(master)
  if(!is.null(dfs.namenode)) dfs.namenode <- as.character(dfs.namenode)
  .Call("Cluster_startDriver", port, master, dfs.namenode, 
	 as.logical(verbose), as.logical(debug), as.logical(info)
	)
}

stopCluster <- function(all=TRUE){
  .Call("Cluster_stopDriver", as.logical(all))
}

# Check
# drievr, worker, ...
stateCluster <- function(...){
  .Call("Cluster_state", substitute(list(...)))
}

debugCluster <- function(conn){
  .Call("Cluster_debug", as.character(conn))
}	

gbdDebug <- function(pid=Sys.getpid()){
#  .Call("Supr_debug_R", as.integer(pid))
  invisible(.Call("Supr_debug_R", as.integer(pid)))
}	

# Consider the style of the R options function
# Get objects:
# context()$name
# For convenience, set objects:
# context(name1=, name2=, ...)
context <- function(..., env=parent.frame()){
  args <- substitute(list(...))
  if(length(args)==1) ContextEnv else
  invisible(.Call("Supr_cntxt", args, env))
}

#ContextEnv <- context()

print.SuprContext <- function(x, ...) {
	names <- ls(x, all=TRUE)
	ret.val <- character()
	for(i in 1:length(names)){
	  name <- names[i]
	  val <- get(name, envir=x)
	  val <- if(is.character(val)) paste("\"",val,"\"",sep="") else 
	           paste(" -> (class)", paste(class(val), collapse=", "))
	  val <- paste(name, ":", val)
	  cat("[", i, "] ", val,"\n", sep="")
	  ret.val[i] <- val
	}
	ret.val
}

netstat <- function(port, args=NULL){
  .Call("Cluster_netstat", as.integer(port),
       	if(is.null(args)) NULL else as.character(asgs))
}


plot.SuprContext <- function(cntxt =  context()){
  conns <- strsplit(ls(cntxt$driver), "//")
  i <- which(unlist(lapply(conns, function(x) x[1] == "dfsname")))
  dfsname <- conns[[i]]

  i <- which(unlist(lapply(conns, function(x) x[1] == "worker")))
  workers <- conns[i]

  i <- which(unlist(lapply(conns, function(x) x[1] == "master")))

}


##print.DD <- function(x, ...){ .Call("DD_print", x, substitute(list(...))) print(ls.str(x)) }

if(FALSE){

  options(verbose = TRUE)
  options(debug = TRUE)
  options(info = TRUE)
  library(supr3)

  context(info = "7205", master=context()$master)
  context()$master

#  context(info = "7205", dfs=context()$dfs)
#  context()$dfs

  if(TRUE){ # DFS

    #dfs <- context()$dfs
    #a <- DDEnv()
    # dfs == DDEnv(".")

    library(supr3)
    context(info = "7205", dfs=context()$dfs)

    em.data <- open(DDEnv("EMData"))

    assign("x", 1:10, envir = em.data)
    assign("y", 1:100, envir = em.data)
    ls(em.data)
    get("x", envir=em.data)
    get("y", envir=em.data)
    get("z", envir=em.data)
    em.data$x
    em.data$y
    em.data$z
    em.data$z <- 1:20
    em.data$z

    exists("EMData", envir=em.data) # check subsets... or no?

    rm(EMData, envir = em.data) # check subsets... or no?

    # mv(em.data, as.character(where))
    persist(em.data, level)
    replicate(em.data)


    # make it subsettable:
    em.data["x"]
    em.data[c("x", "y")] <- list(x=1:2, y=5:6)

    close(em.data)
  }


  context(info = "7205", thread = context()$thread)

  ###
   options(info = TRUE)
   library(supr3)

  dfsenv <- function(){
    .Call("Supr_connectionAsEnv", context()$dfs)
  }

  connectionEnv <- function(addr){
    .Call("Supr_connectionAsEnv", addr)
  }

  context(dfs=context()$dfs)

  a <- dfsenv()
  a$connections

  d <- connectionEnv("dfsdata//liu1.stat.purdue.edu:7201")
  d$connections
  d <- connectionEnv("dfsdata//liu2.stat.purdue.edu:7201")
  d$connections

  context(dfs=NULL)

  ###
  options(info = TRUE)
  library(supr3)
  context(ths=context()$ths)

  context(ths=NULL)

  context(ths=list())
  
  context(ths=NULL)

  ###
  options(info = TRUE)
  library(supr3)

  context(master=context()$master)
  # m <- connectionEnv(context()$master)

  m <- masterenv()
  m$connections

  context(master=NULL)

  supr.options(info = FALSE)
  supr.options()
  context()

  options(info = TRUE)
  library(supr3)

  context(driver = context()$driver)

  cluster <- context()$driver
  ls(cluster)

  SharedEnv <- driverenv()
  ls(SharedEnv)
  SharedEnv$connections


  context(shutdown)

  # use a thread to monitor socket_connections ...?

  context(driver = NULL)
  context(driver = paste(context()$driver, "+",sep=""))

  a <- DDEnv()

  connectionEnv <- function(addr){
    .Call("Supr_connectionAsEnv", addr)
  }

  dfsenv <- function(){
      SharedEnv <- driverenv()
      conns <- SharedEnv$connections
      k <- grep("dfsname", conns)
      if(length(k)==1) {
        conn <- strsplit(conns[k], "//")[[1]][2]
        .Call("Supr_connectionAsEnv", conn)
      } else NULL
  } 
  dfsEnv <- dfsenv()

  a <- connectionEnv("//liu2.stat.purdue.edu:7200")

  expr <- expression({
	  f <- local({
		  SS <- 0
		  function(v){
			  if(missing(v)){
			  } else if (is.null(v)){
		            SS <<- 0
			  } else {
		            SS <<- SS +v
			  }
			  SS
		  }
	  })
	  list(sym="SS", fun=f, env=.SuprEnv) 
  })

  SharedEnv$makeActiveBinding <- list(expr=expr)

  ls(SharedEnv)
  SharedEnv $ SS <- c(1,2)



  ## getwd and setwd
  expr <- quote({
	  f <- local({
		  path <- getwd()
		  function(v){
			  if(!missing(v)){
		            setwd(v)
			    path <- getwd()
			  }
			  path
		  }
	  })
	  list(sym="cwd", fun=f, env=.SuprEnv) 
  })

  SharedEnv$makeActiveBinding <- list(expr=expr)

  # dir
  expr <- quote({
	  f <- local({
		  files <- dir()
		  function(v){
			  if(!missing(v)){
		            setwd(v)
		            files <- dir()
			  }
			  files
		  }
	  })
	  list(sym="dir", fun=f, env=.SuprEnv) 
  })
  a$makeActiveBinding <- list(expr=expr)


#  do.call(base::makeActiveBinding, eval(expr))

##activeBindingFunction("makeActiveBinding", .SuprEnv)



  cluster <- context()$driver
  ls(cluster)

  # gbdDebug()
  cluster <- startCluster(info=TRUE, verbose=TRUE, debug=TRUE)
  print(cluster)

  debugCluster("liu1.stat.purdue.edu:7208")
  debugCluster("liu2.stat.purdue.edu:7208")

  #stateCluster(driver)

  ls(cluster)
  cluster$pthreads

  # in another session, do:
  if(FALSE){
    library(supr3)
    context(info = "7224", driver = context()$driver)

    cluster <- context()$driver
    ls(cluster)

  }


  cluster <- context()$driver
  ls(cluster)
  a <- cluster$"master//liu1.stat.purdue.edu:7202:0"
  ls(a)
  b <- cluster$"dfsname//liu1.stat.purdue.edu:7200:0"
  ls(b)
  w <- cluster$"worker//liu1.stat.purdue.edu:7204:0"
  ls(w)
  w <- cluster$"worker//liu2.stat.purdue.edu:7204:0"
  ls(w)

  w <- cluster$"liu2.stat.purdue.edu:7201:0"
  ls(w)

  debugCluster("liu1.stat.purdue.edu:7218")

  debugCluster("liu2.stat.purdue.edu:7218")

  foo <- function(...) substitute(list(...))
  x <- foo(x,y)


  



  stopCluster()

}

#if(FALSE && !is.loaded("R_thread_init")) {
#  dyn.load("libsupr.so")
#print("To call .Call(\"R_thread_init\")");
#print(ls())
#  .Call("R_thread_init")
#print("Called .Call(\"R_thread_init\")");
#}

loadRData <- function(file){
    env = new.env()
    load(file, envir = env)
    as.list(env)
}

#SuprContext.conf <- function(..., add = TRUE, save=FALSE, envir=parent.frame()){
#  .Call("SuprContext_conf", pairlist(...), add, save, envir)
#}

#SuprContext.start <- function(...){
#  .Call("SuprContext_start", pairlist(...), parent.frame())
#}


SuprContext <- function(what, ..., character.only = FALSE,
		       	envir = parent.frame()){
  if(missing(what)){ 
	  what <- NULL
  } else if(!character.only){
    name <- substitute(what)
    if(is.symbol(name)){
      what <- as.character(name)
      if(exists(what, envir)) {
        what <- get(what, envir)
        if(!is.character(what))
	  what <- as.character(name)
      }
    } 
  }

  if(!is.null(what) && !is.character(what))
	  stop("invalid 'what' argument")

  .Call("SuprContext", what, pairlist(...), envir)
}

#`ntrs<-` <- function(worker, value){
#  .Call("SC_nTaskrunners", worker, as.integer(value))
#  worker
#}

worker.options <- function(worker, ...){
  .Call("Worker_options", worker, pairlist(...));
}

SuprJob <- function(job, action = c("print","get", "is.done", "cancel", "info", "rm"),
		    ...){
  .Call("SuprJob",  job, as.character(action[1]), pairlist(...))
}


print.SuprJob <- function(x) { invisible(SuprJob(x, "print"))}

jobGet <- function(job, combine = NULL, timeout = 60) {
  r <- .Call("SuprJob", job, "get", pairlist(timeout=timeout))
  if(!is.null(combine)) combine(r) else r
}

#SuprContext.quit <- function(){ .Call("SuprContext_quit") }


startDriver <- function(port = 0)
{
  .Call("startDriver", port)
}

stopDriver <- function(stop.master = TRUE)
{
  .Call("stopDriver", stop.master)
}

driver.info <- function()
{
  .Call("Driver_info")
}

startWorker <- function(port=0, subdir="testing", master=NA)
{
  .Call("startWorker", as.integer(port), as.character(subdir),
       	as.character(master))
}


#shutdown <- function() { driverEval("shutdown", pairlist()) }

job.combine.default <- function(x){
  e <- lapply(x, "[[", "error")
  k <- which(!unlist(lapply(e, is.null)))
  if(length(k) > 0) return(x)
  
  w <- lapply(x, "[[", "warnings")
  k <- which(!unlist(lapply(w, is.null)))
  if(length(k) > 0) return(x)

  v <- lapply(x, "[[", "value")

#  trs <- lapply(x, "[[", "taskrunner")
#  trs <- paste(unlist(lapply(trs, "[", "host")),
#	       unlist(lapply(trs, "[", "pid")), sep=":")
#  names(v) <- trs
  v
}


cluster.eval <- function(expr, data, envir=list(),
	 error.handler = NULL,
	 env=parent.frame(), wait=TRUE, combine=job.combine.default, ...)
{
#   expr <- if (is.symbol(qexpr <- substitute(expr))) expr else qexpr

  .Call("R_cluster_eval", expr, data, as.environment(envir),
	error.handler, list(...), env, wait, combine)
}

#job.get <- function(job, timeout = 0){ SuprJob(job, "get", timeout = timeout) }

#job.isDone <- function(job){ SuprJob(job, "is.done") }

#job.cancel <- function(job){ .Call("R_future", job, "cancel", 0) }
#job.cancel <- function(job){ SuprJob(job, "cancel") }

#job.info <- function(job){ if(missing(job)) job <- -1L SuprJob(job, "info") }
#job.rm <- function(job, all = FALSE){ #  if(missing(job)) job <- -1L
##  .Call("Cluster_jobOperation", "rm", job)
# if(all == TRUE)
#    job = -1L
#  SuprJob(job, "rm")
#}

## FIXME
#job.malloc <- function(){ #  if(missing(job)) job <- -1L SuprJob(0L, "malloc") }

#job.remove <- function(job){
#  if(missing(job)) job <- -1L
#  .Call("Cluster_jobRemove", job)
#}

#nrun <- function(monitor=NULL, env = parent.frame()){ .Call("Cluster_getNumTaskrunners", substitute(monitor), env) }

cluster.get <- function(uri, name, remove=FALSE){
       	.Call("Cluster_getRObject", uri, name,  remove)
}

#cluster.put <- function(uri, name, value){ stop("not implemented") .Call("Cluster_putRObject", uri, name,  value) }

#nextEvent <- function(...){
#    .Call("DCL_nextEvent", pairlist(...))
#}

#cluster.collect
collect <- function(x, remove=FALSE)
{
    value <- list()
    for(i in 1 : length(x)){
      y <- x[[i]] ##$value
      if(length(y)){
        addr <- attr(y, "location")
        val  <- sapply(y, function(name){
                    cluster.get(addr, name, remove)
                  })
        value <- append(value, val)
      }
    }
    value
}

# block:  TRUE for blocking and FALSE for nonblocking
socket.block <- function(block, driver=NULL) {
  if(missing(block)) block = NULL
  .Call("Socket_setBlockingStatus", block, driver)	
}
clusterInfoAddr <- function(addr, driver=NULL) {
  if(missing(addr)) addr = NULL
  .Call("Info_getInfoSever", addr, driver)	
}

#start <- function(x, ...) UseMethod("start")
#start.default <- function(x, ...)
# defined in stats

driver.localfuns <- pairlist(
  eval = cluster.eval,
  block = socket.block, #use an active binding ?
  info.addr = clusterInfoAddr,
  get =  cluster.get
)




