#start dfs_name: dfs_name -dir 01/00/...  

# dyn.unload("libsupr.so")



ddenv <- function(name=".", addr = context()$dfs)
	.Call("DFS_DDEnv", as.character(name), addr)

print.DD <- function(x, ...){
        .Call("DD_print", x, substitute(list(...)))
}

#print.DDEnv <- function(x, ...){ .Call("DDEnv_print", x, substitute(list(...))) }


if(FALSE){
Thread.init <- function(){
  if(!is.loaded("R_thread_init"))
    dyn.load("libsupr.so")
 .Call("R_thread_init")
}
}

#Thread.init()

#python <- function() { .Call("Sys_Python") }

#DFS <- FALSE

##SEXP DD_enableInfo(SEXP r_level)

Thread <- function(...){
	stop("TODO")
}

if(FALSE){
Info.send <- function(message, type=0L, level=0L, hostname = NULL, port=NULL)
{
  .Call("DD_sendUserInfo", message, type, level, hostname, port)
}

Info.getMessages <- function()
{
  .Call("DD_getMessages")
}
}

#if(DFS) .Call("connectDFSNamenode", NULL, NULL) }

# add error.handler
Thread.new <- function(expr, ..., env = parent.frame(), error.handler = NULL,
		       name = NULL, proc = FALSE, start=FALSE)
{
  thread <-  .Call("Thread_new", expr, pairlist(...), error.handler, env,
		   name, proc)
  if(start) Thread.start(thread) else thread 
}

Thread.start <- function(thread)
{
  .Call("Thread_start", thread);
}

Thread.current <- function()
{
  .Call("Thread_current");
}

Thread.name <- function(thread)
{
  .Call("Thread_name", thread);
}

Thread.state <- function(thread)
{
  .Call("Thread_state", thread);
}

Thread.startInputHandler <- function()
{
  .Call("Thread_startInputHandler")
}


Thread.join <- function(thread)
{
  .Call("Thread_join", thread);
}

Thread.interrupt <- function(thread)
{
  .Call("Thread_interrupt", thread)
}

Thread.stackTrace <- function(thread)
{
  .Call("Thread_stackTrace", thread)
}

Monitor.info <- function()
{
  .Call("Monitor_info")
}

Sync.eval <- function(expr, monitor = .GlobalEnv, env = parent.frame())
{
  .Call("Sync_eval", monitor, expr, env)
}

Sync.wait <- function(monitor = .GlobalEnv, timeout = 2)
{
  .Call("Sync_wait", monitor, timeout)
}

Sync.notify <- function(monitor = .GlobalEnv, all = FALSE)
{
  .Call("Sync_notify", monitor, all)
}

Thread.interrupt <- function(thread)
{
  .Call("Thread_interrupt", thread);
}


if(FALSE){
loadRData <- function(file){
    env = new.env()
    load(file, envir = env)
    as.list(env)
}
}


DD.options <- function(...){
  .Call("DD_operation", "options", "some_name?", pairlist(...))
}

DD.exists <- function(name, ...){
  .Call("DD_operation", "exists", name, pairlist(...))
}

DD.enableInfo <- function(level = 0L) {
  .Call("DD_enableInfo", as.integer(level)) 
}
DD.disableInfo <- function() {
  .Call("DD_disableInfo")
}

DD.create <- function(name) {
  .Call("DD_create", as.character(name))
}

# create: create.if.not.exists
DD.open <- function(name, create = TRUE) {
  .Call("DD_open", as.character(name), create)
}

DD.put <- function(dd.name, subsets=as.list(1:10), subset.names)
{
  .Call("DD_put", dd.name, subsets, subset.names)
}

DD.list <- function(name = "."){
   .Call("DD_list", name)
}

#if(DFS){ DD.enableInfo() DD.options(timeout = 60) }

#DD.open("mydata")

DD.replicate <- function(name){
  .Call("DD_replicate", name)
}

DD.mv <- function(src, dest){
  .Call("DD_operation", "move", NULL, pairlist(src=src, dest=dest))
}

DD.rm <- function(name, recursive = FALSE){
  .Call("DD_operation", "rm", name, pairlist(recursive=recursive))
}

#DD.update <- function(name){ .Call("DD_operation", "update", name) }

DD.close <- function(name, save=TRUE){
  if(save){
    DD.persist(name, level = "file")
  }
  .Call("DD_close", name)
}


if(FALSE){
  DD.mv("myd01", "myd02")
}

# dyn.unload("libsupr.so")

#dyn.load("libsupr.so")
#a <- .Call("connectDFSNamenode", NULL, NULL)
#DD_options(timeout = 30)





# ... is used a  suffix-function pairlist
DD.get <- function(name, subset.names, ..., env=parent.frame()){
  .Call("DD_get", name, subset.names, env, pairlist(...))
}

DD <- function(name) structure(as.character(name), class = "DD")

get.DD <- function(dd, subset.names, ..., env=parent.frame()){
  .Call("DD_get", as.character(dd), subset.names, env, pairlist(...))
}


#.Call("DD_persist", "mydata")

# level: 0 - SHM, 1 - HARD DISK
DD.persist <- function(name, level = c("file", "tmp", "shm", "mem", "null")){
#define DFS_DD_PERSIST_NULL_LEVEL  0
#define DFS_DD_PERSIST_MEM_LEVEL   1
#define DFS_DD_PERSIST_SHM_LEVEL   2
#define DFS_DD_PERSIST_TMP_LEVEL   3
#define DFS_DD_PERSIST_FILE_LEVEL  4
 level = which(level[1] == rev(c("file", "tmp", "shm", "mem", "null")))-1L 
 if(length(level)==0) stop("invalid 'level' argument")
  .Call("DD_operation", "persist", name, pairlist(level=level))
}


# not about dd but dfs system itself
DD.info <- function(topic = NULL, ...){
  .Call("DD_operation", "info", topic, pairlist(...))
}

#DD <- function(...){ stop("TODO") }

## Thread name: Thread.tid
## .ThreadEnv servers a place for all alive threads

