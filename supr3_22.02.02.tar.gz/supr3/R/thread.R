

# For further development ?
# new.Thread (...), new(Thread, ...), and thread.new(...) are 
# similar

local.thread.server <- NULL

Sys.gettid <- function(){
    .Call("Sys_gettid")
}

Sys.getppid <- function(){
    .Call("Sys_getppid")
}
ThreadServer.cancel <- function(host, port, address=paste(host, port, sep=":"))
{
  .Call("ThreadServer_stop", as.character(address));
}

ThreadServer.start <- function(port){

    if(missing(port)){
      return(supr3:::local.thread.server)
    }

    server <- .Call("ThreadServer_start", as.integer(port))
    # bindingIsLocked(sym, env): TRUE
    unlockBinding("local.thread.server", environment(ThreadServer.start))
    #supr3:::local.thread.server <- server
    assign("local.thread.server", server, asNamespace("supr3"))
    assign("local.thread.server", server,  environment(ThreadServer.start))
    lockBinding("local.thread.server", environment(ThreadServer.start))
    server
}

print.ThreadServer <- function(x){
#  cat("(ThreadServer) address: ", attr(x, "address"), ", type: ", attr(x, "type"), "\n", sep="")
  cat("<ThreadServer: addr=", attr(x, "address"), ", type=", attr(x, "type"), ">\n", sep="")
}

#toString.ThreadServer <- function(x){ paste(attr(x, "address"), attr(x, "port"), attr(x, "host")) }

info <- function(text, conn = NULL){
    .Call("Supr_info", conn, as.character(text))
}


DELETEME <- TRUE

master <- 0
workers <- 0
driver <- 0

#who <- function(){ .Call("Sync_who") }

# use sync instead
#R.lock <- function(){ .Call("R_lock"); }
#R.unlock <- function(){ .Call("R_unlock"); }



##
## change sync.eval to sync, sync.wait to wait, and sync.notify to notify?
##
# monitor: default -- LocalEnv at driver or worker?
# monitor: server$monitor?

Sync.eval <- function(monitor, expr, language.only = FALSE, env = parent.frame())
{
#  if(FALSE){
#    C_func <- if(any(class(monitor)=="Cluster")) "TR_sync_eval" else "Sync_eval"
#    .Call(C_func, expr, monitor, env)
#  }

  #if(TRUE) print(substitute(eval(quote(expr))))
  #.Call("Sync_eval", substitute(monitor), substitute(eval(quote(expr))), env)
  .Call("Sync_eval", substitute(monitor),
  	#substitute(eval(quote(expr))),
	if(is.symbol(qexpr <- substitute(expr))) expr else qexpr,
        env)
}
sync <- Sync.eval



#unsync <- function(monitor, env = parent.frame()){ .Call("Sync_unlock", substitute(monitor), env) }

Sync.wait <- function(monitor, timeout = 0, env=parent.frame())
{
  #.Call("Sync_wait", monitor, timeout)
  #if(missing(monitor)) .Call("Sync_wait", NULL, timeout, env) else
  timeout <- serialize(substitute(timeout), NULL)
  .Call("Sync_wait", substitute(monitor), timeout, env)
}
wait <- Sync.wait

Sync.notify <- function(monitor, all = FALSE, env = parent.frame())
{
#  .Call("Sync_notify", monitor, all)
  #monitor <- if(missing(monitor)) NULL else substitute(monitor)
  #.Call("Sync_notify", monitor, all, env)
  .Call("Sync_notify", substitute(monitor), all, env)
}
notify <- Sync.notify




Thread.start <- function(thread, ...)
{
#  if(is.character(thread))
#    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_start", thread, list(...))
}

#
# server: a character of the form host:port, specifying the host name and
#         port number
#
Thread.new <- function(expr, ...,  env = parent.frame(), error.handler = NULL,
       server = local.thread.server, start=FALSE)
{
#  if(TRUE) print(substitute(eval(quote(expr)), env=list2env(list(...))))

  thread <-  .Call("Thread_new", 
  		   if(is.symbol(qexpr <- substitute(expr))) expr else qexpr,
		   pairlist(...), error.handler, env, NULL,
		   if(is.null(server)) NULL else server)
  class(thread) <- "Thread"
  if(start) startThread(thread)
  thread 
}

Thread.join <- function(thread, useProxy=TRUE)
{
#  if(is.character(thread)) thread = get(thread, envir = .ThreadEnv)

  x <- .Call("Thread_join", thread, as.logical(useProxy))
  if(!is.null(x$value)) {
    if(!is.null(x$stdout) && length(x$stdout) &&nchar(x$stdout[1]))
	  cat("stdout:\n", x$stdout, "\n")
    if(!is.null(x$stderr) && length(x$stderr) &&nchar(x$stdout[1]))
	  cat("stderr:\n", x$stderr, "\n")
    x$value
  } else {
    if(!is.null(x$stdout) && length(x$stdout) &&nchar(x$stdout[1]))
	  cat("stdout:\n", x$stdout, "\n")

    stop(x$stderr)
  }

}
join <- Thread.join

# delete ...
##print.ThreadResult <- function(x){ if(!is.null(x$value)) print(x$value) if(!is.null(x$stdout) && length(x$stdout) &&nchar(x$stdout[1])) cat("stdout:\n", x$stdout, "\n") if(!is.null(x$stderr) && length(x$stderr) &&nchar(x$stdout[1])) cat("stderr:\n", x$stderr, "\n") }

Thread.interrupt <- function(thread)
{
#  if(is.character(thread)) thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_interrupt", thread)
}
interrupt <- Thread.interrupt
#interrupt <- if(SYS.cmd == "worker" || SYS.cmd == "driver" || Sys.cmd == "master") { function(...) .Call("Supr_interrupt", pairlist(...)) } else Thread.interrupt



Thread.state <- function(thread)
{
  .Call("ThreadProc_state", thread)
}
state <- Thread.state

ThreadServer.ping <- function(server, timeout = 10){
	# checking ?
  .Call("ThreadServer_ping", server, as.numeric(timeout))
}
ping <- ThreadServer.ping


ThreadServer.connect <- function(host, port, address=paste(host, port,sep=":")){
  .Call("ThreadServer_connect", as.character(address))
}
connect <- ThreadServer.connect


## TODO
ths.localfuns <- pairlist(
  new = Thread.new
)

toString.ThreadServer = function(x, ...){
  attr(x, "address")
}

start.Thread <- function(x, ...){
  .Call("Thread_start", x, list(...))
}

#Sync.get <- function(x, server){ .Call("Sync_get", as.character(x), server) }
#Sync.put <- function(x, value, server){ .Call("Sync_put", as.character(x), value, server) }
#Sync.exists <- function(x, server){ .Call("Sync_exists", as.character(x), server) }
#Sync.rm <- function(x, server){ .Call("Sync_remove", as.character(x), server) }
#Sync.ls <- function(server){ .Call("Sync_list", server) }


### Thread and Sync: Examples ###
if(FALSE){


  # examples: 
  options(info=TRUE)
  library(supr3)
  context(ths=context()$ths)

  # th <-  Thread.new(Sys.getppid(), server= context()$ths[[1]])
  th <-  context()$ths[[1]]$new(Sys.getppid())
  Thread.start(th)
  r <- join(th)
  r

  th <-  Thread.new(stop("testing error"), server= context()$ths[[1]])
  Thread.start(th)
  r <- join(th)
  r




foo <- function (expr, envir = new.env()) {
#	x <- substitute(eval(quote(expr)))
#	print(length(x[[2]][[2]]))
#	x
#	x[[2]][[2]]
#	expr <- quote({1+bbb})
#	substitute(expr)
	x <- substitute(expr)
#	print(as.list(x))
#	print(is.symbol(x))
#	if(length(x)==1) expr else  x
       # substitute(eval(quote(expr)))
	if(is.symbol(x)) expr else  x
}
expr0 <- quote({
1+aaa
})
foo(expr0+1)

  library(supr3)
  port <- 2021L
  server <- ThreadServer.start(port)
  conn <- connect(host=Sys.info()["nodename"], port=port)

  thread <- new.Thread(cat("\033[0;31mNew thread: ", Sys.getpid(),"\033[0m\n"),
		       server=conn)
  start.Thread(thread)
  state(thread)
  join(thread)


  expr0 <- quote(cat("\033[0;31mNew thread: ", Sys.getpid(),"\033[0m\n"))
  thread <- new.Thread(eval(expr0), expr0=expr0, server=conn)
  start.Thread(thread)
  state(thread)
  join(thread)



  library(supr3)

  # make it simple: always use Thread.server?
  supr3:::local.thread.server
  server <- Thread.server(2021)
  supr3:::local.thread.server

  thread <- Thread.new(cat("\033[0;31mNew thread: ", Sys.getpid(),"\033[0m\n"))

  Thread.state(thread)

  Thread.state(as.integer(thread))

  # C: kill(pid, SIGKILL); Thread.interrupt(thread)

  Thread.start(thread)
  Thread.join(thread)


  thread <- Thread.new(1:10)
  Thread.start(thread)
  res<-Thread.join(thread)

  Thread.serverIsAlive(server)

  conn <- Thread.connectServer(server = server)


  # sync.eval, wait, notify
  library(supr3)
  server <- start.ThreadServer(2021)
  connection <- connect.ThreadServer(address=attr(server, "address"))

  expr <- quote({
      print(Sys.getpid())
      Sys.sleep(2)
      #stop("testing")
      Sys.getpid()
    })

  sync.eval(connection$monitor, expr)


  thread <- new.Thread(sync.eval(connection$monitor, expr), server=connection)
  start.Thread(thread)

  supr.options(verbose=TRUE)
  res <- join(thread)


  library(supr3)
  server <- ThreadServer.start(2022)
  conn <- connect(address=attr(server, "address"))

  expr <- quote({
      print(Sys.getpid())
#      sync.eval(conn$monitor, {
#          rc <- wait(conn$monitor, timeout=60)
#	})
          #rc <- wait(conn$monitor, timeout=60)
          #rc <- wait(conn$monitor, timeout=x[1])
          rc <- wait(conn$monitor, timeout={y <- 13; x[1]})
      cat("wait: ", rc, "\n")
      #stop("testing")
      Sys.getpid()
    })

  #thread <- Thread.new(Sync.eval(connection$monitor, expr), server=connection)
  #Thread.start(thread)
  thread <- conn$new(Sync.eval(conn$monitor, expr))
  start(thread)

  state(thread)

  res <- join(thread)

  conn$x <- 1:10

  supr.options(verbose=TRUE)

  sync.eval(conn$monitor, {
          notify(conn$ttmonitor)
	})



  library(supr3)
  server <- start.ThreadServer(2021)
  connection <- connect.ThreadServer(address=attr(server, "address"))

    expr <- quote({
      print(Sys.getpid())
      sync.eval(connection$monitor, {
          rc <- wait(connection$monitor, timeout=10)
       })
      cat("wait: ", rc, "\n")
      #stop("testing")
      Sys.getpid()
    })

  # supr.options(verbose=TRUE)
  thread <- new.Thread(expr, server=connection)
  start.Thread(thread)

  state(thread)

  # supr.options(verbose=FALSE)
  # supr.options(verbose=TRUE)
  res <- join(thread)

  sync.eval(connection$monitor, {
          notify(connection$monitor)
        })

  

  # ThreadServer

  library(supr3)
  #
  # Start a thread server on the current machine
  #
  theServer <- start.ThreadServer(2021)
  print(theServer)

  typeof(theServer)
  class(theServer)
  attributes(theServer)

  #
  # Establish A connection to the server
  #
  server <- connect.ThreadServer(address = attr(theServer, "address"))
  typeof(server)
  attributes(server)

  library(supr3)
  # supr.options(verbose=TRUE)
  # supr.options(info=TRUE)
  theServer <- start.ThreadServer(2021)
  server <- connect.ThreadServer(address = attr(theServer, "address"))

  # Start a new thread on the server machine
  thread <- new.Thread(
    expr=cat("\033[0;31mNew thread: ", Sys.getpid(),"\033[0m\n"),
    	server=server)

  start.Thread(thread)
  state(thread)
  res <- join(thread)
  print.ThreadResult(res)

  #assign("x", 1:10, server)
  server$x <- 1:100
  server$x 

  ls(server)

  exists("x", envir=server)
  exists("y", envir=server)

  rm("x", envir=server)
  rm("y", envir=server)

  # Sync.wait

  library(supr3)

  server <- Thread.server(2021)
  Thread.ping(server)

  

  s <- Sync.get("x", server)
  s

  expr <- quote({
      print(Sys.getpid())
      cat("Sync.wait...\n")
      warning("Testing")
      x <- 1:10000
#      while(TRUE) { rm(x); x <- 1:10000 }
      #rc <- Sync.wait(server$monitor, 60)
      Sys.sleep(100)
      cat("Sync.wait...Done, rc:", rc, "\n")
      stop("testing")
      Sys.getpid()
    })

  errHandler <- function(msg, envir){
	  cat("\033[0;31merrHandler ...\033[0m\n")
	  stop("whoops!")
  }

  thread <- Thread.new(expr, error.handler = errHandler)



  Thread.start(thread)

  Thread.join(thread)





  Thread.start(thread)
  #Sync.eval(server$monitor, expr)

  thread <- Thread.new(Sync.eval(server$monitor, expr))

  Thread.start(thread)





  res<-Thread.join(thread) # avoid deadlock -- TODO
  
  # Sync.notify

  library(supr3)
  server <- Thread.server(2021)

  expr <- quote({
      print(Sys.getpid())
      cat("Sync.wait...\n")
      #rc <- Sync.wait(server$monitor, 60)
      rc <- Sync.wait(server$monitor)
      cat("Sync.wait...Done, rc:", rc, "\n")
      #stop("testing")
      Sys.getpid()
    })


  thread <- Thread.new(Sync.eval(server$monitor, expr))
  Thread.start(thread)
  
  Sync.eval(server$monitor, {
       Sync.notify(server$monitor, all=FALSE)
    })

  threads <- as.list(1:10)
  for(i in 1:length(threads)){
    threads[[i]] <- Thread.new(Sync.eval(server$monitor, expr))
    Thread.start(threads[[i]])
  }

  Sync.eval(server$monitor, {
       Sync.notify(server$monitor, all=TRUE)
    })

  # res<-Thread.join(thread) # avoid deadlock -- TODO

  # Sync.put and Sync.get

  library(supr3)
  server <- Thread.server(2021)

  a <- Thread.connectServer(server = server)
  a

  Thread.ping(server)
  Thread.ping(a)

  Sync.eval(server$monitor, {
       Sync.put("z", 1:10, server)
       Sync.put(c("x", "y"), list(1:5, 6:10), server)
    })

  x <- Sync.eval(server$monitor, {
       Sync.get("x", server)
       traceback(1)
    })
  xy <- Sync.eval(server$monitor, {
       Sync.get(c("x", "y"), server)
    })

  Sync.ls(server)

  Sync.exists(c("x", "y", "z", "a", "b"), server)

  Sync.rm(c("x", "y"), server)
  Sync.rm(c("x", "y", "z", "a", "b"), server)

#  conn <- socketConnection(port=2021)

#  Driver.stop(backend)

  # examples: EM
  n <- 1000; mis.frac <- 0.25
  X <- rnorm(n)
  X[runif(n) < mis.frac] <- NA
  m <- 10 # the number of threads to be used
  dim(X) <- c(m, n/m)

  #
  # Start thread servers on a group of computers. Here four servers
  # are to be started at four R sessions on one computer as follows:
  #
  # Session 1:
  # library(supr3)
  # server <- start.ThreadServer(port=2021L)
  #
  # Session 2:
  # library(supr3)
  # server <- start.ThreadServer(port=2031L)
  #
  # Session 3:
  # library(supr3)
  # server <- start.ThreadServer(port=2041L)
  #
  # Session 4:
  # library(supr3)
  # server <- start.ThreadServer(port=2051L)
  #

  # Connected the thread servers
  # The server addresses:
  # EM example
  if(TRUE){

    library(supr3)
    server <- ThreadServer.start(port=2052L)
    servers <- paste(Sys.info()["nodename"], 2052L,#c(2021L, 2031L, 2041L, 2051L),
		   sep=":")
    connections <- as.list(1:length(servers))
    for(i in 1:length(servers))
      connections[[i]] <- connect(address = servers[i])

  } else {
	  


	  options(info=TRUE)
	#  options(verbose=TRUE)
          library(supr3)
	#  options(verbose=FALSE)
	  context(ths=context()$ths)

          connections <- context()$ths
  }
  # Start m threads (at random) by these thread servers
  # using a single server for shared objects
  shared <- connections[[sample(1:length(connections), size=1)]]
  shared.addr <- attr(shared, "address")
  shared$SS <- c(0,0) # Sufficient Statistics at the server for
                      # shared objects
  n <- 1000; mis.frac <- 0.25
  X <- rnorm(n)
  X[runif(n) < mis.frac] <- NA
  m <- 10 # the number of threads to be used
  dim(X) <- c(m, n/m)
  threads <- as.list(1:m)
  for(i in 1:length(threads)){
     conn <- connections[[sample(1:length(connections), size=1)]]
     expr <- quote({
         shared <- connect(address = shared.addr)
	 which.mis <- which(is.na(x))
	 for(it in 1:50){
	     #E-step
	     x[which.mis] <- mu
	     my.SS <- c(sum(x), length(x))
	     Sync.eval(shared$EM, {
		   SS <- shared$SS + my.SS
		   cat("[",it, "] SS:",SS, "n:", n, "\n")
		   if(SS[2] < n) {
		     shared$SS <- SS
		     wait(shared$EM)
		     mu <- shared$mu
		     cat("[",it, "] mu:",mu,"\n")
		   } else {
	             #M-step
		     mu <- SS[1]/n
		     info(paste("[",it, "] pid:",Sys.getpid(), "mu:",mu))
		     shared$mu <- mu
                     shared$SS <- c(0,0)
		     notify(shared$EM, all=TRUE)
		   }
		})
	 }
         info(paste("\033[0;31m[",it, "] pid:",Sys.getpid(),"\033[0m"))
         shared$mu
     })
     threads[[i]] <- Thread.new(expr, x= X[i,], n=n, mu=0, shared.addr=shared.addr, server = conn)
  }

  for(i in 1:length(threads)){ Thread.start(threads[[i]]) }

  for(i in 1:length(threads)){print(i); join(threads[[i]]) }

  #ThreadServer.cancel(address = attr(server, "address"))

  shared$mu
  mean(as.numeric(X), na.rm=T)

#  context(ths=NULL)

  res1<- join(threads[[1]])
  cat(res1$stdout); cat(res1$stderr)
  res2<- join(threads[[2]])
  cat(res2$stdout)
  cat(res2$stderr)



#  local <- function (expr, envir = new.env())
# eval.parent(substitute(eval(quote(expr), envir)))

  foo <- function(expr, envir){
	  substitute(eval(quote(expr)))
  }
  foo(1+2)
  eval(foo(1+2))

  expr <- quote(1+2)
 eval(foo(eval(expr)))

 local(eval(expr))

foo <- function (expr, ..., env = parent.frame(), error.handler = NULL,
    server = local.thread.server, start = FALSE)
{
    cat("substitute(eval(quote(expr))):\n\t")
    print(substitute(eval(quote(expr))))
    envir <- new.env(parent=env)
    x <- list(...)
    for(i in 1:length(x)) assign(names(x)[i], x[[i]], envir=envir)
    eval(substitute(eval(quote(expr))), envir)
}

foo(1+a, a=19)

expr <- quote(1+2)

foo(expr, a=19)


}

######## TO BE DELETED ###########






if(FALSE){
  new.Thread <- setClass("Thread", slots = c(expr="language", proc="logical",
		       start="logical"),
		   contains=c("character"))

  Thread <- getClass("Thread")
#
# initializers do not appear to be attractive ...
# 

}



if(FALSE){
Thread <- function(what, ...){
}


# The current way of naming thread functions follows the R file functions

# for checking in creating packages
thread.check <- function(..., env=parent.frame()){
  .Call("Thread_check", pairlist(...), env)
}

print.Thread <- function(thread, ...){
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  print.default(data.frame(name = thread.name(thread)), ...)
}

print.ThreadEnv <- function(x, ...){
	print(ls.str(x, all=TRUE))
}

thread.start <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_start", thread)
}

thread.join <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_join", thread)
}

thread.new <- function(expr, ..., env = parent.frame(), error.handler = NULL,
       name = NULL, proc = FALSE, host = NULL, start=FALSE)
{
  .expr <- substitute(expr)
  if(!is.symbol(.expr)) expr <- .expr

  if(!is.null(host)) proc = as.character(host)

  thread <-  .Call("Thread_new", expr, pairlist(...), error.handler, env,
		   name, proc)
  if(start)
    thread.start(thread)
  thread 
}

thread.openXTerm <- function(...){ .Call("Thread_openXTerm", pairlist(...)) }



showThreads <- function(all = FALSE)
{
#  message(ls(.GlobalEnv, all=TRUE),"\n")
#print(ls(.GlobalEnv, all=TRUE))
  names <- ls(envir=.ThreadEnv, all = all)
  states <- unlist(sapply(names, thread.state))
  types <- unlist(sapply(names, thread.type))
  data.frame(name = names, type=types, state=states, row.names = NULL)
}

thread.current <- function()
{
  .Call("Thread_current");
}

thread.name <- function(thread)
{
  .Call("Thread_name", thread);
}

thread.state <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  state <- .Call("Thread_state", thread);
  c("NEW", "RUNNABLE", "BLOCKED", "WAITING", "TIMED_WAITING", "TERMINATED")[state+1]
}

thread.startInputHandler <- function()
{
  .Call("Thread_startInputHandler")
}


thread.sleep <- function(time)
{
  .Call("Thread_sleep", time)
}


thread.interrupt <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_interrupt", thread)
}

thread.stackTrace <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_stackTrace", thread)
}

thread.env <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_envir", thread)
}

thread.expr <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_expr", thread)
}

thread.type <- function(thread)
{
  if(is.character(thread))
    thread = get(thread, envir = .ThreadEnv)

  .Call("Thread_type", thread)
}


toString.monitor <- function(x, ...) {
  .Call("Monitor_toString", x)
}

monitor.info <- function(...)
{
  .Call("Monitor_info", pairlist(...))
}
}

if(FALSE){
##
## change sync.eval to sync, sync.wait to wait, and sync.notify to notify?
##
sync.eval <- function(monitor, expr, language.only = FALSE, env = parent.frame())
{
#if(missing(expr)){val <- .Call("Sync_lock", substitute(monitor), env);return(val)}

  if(!language.only){
    .expr <- substitute(expr)
    if (!is.symbol(.expr)) 
        expr <- .expr
  }

  if(FALSE){
    C_func <- if(any(class(monitor)=="Cluster")) "TR_sync_eval" else "Sync_eval"
    .Call(C_func, expr, monitor, env)
  }

  .Call("Sync_eval", expr, substitute(monitor), env)
}

#unsync <- function(monitor, env = parent.frame()){ .Call("Sync_unlock", substitute(monitor), env) }

sync.wait <- function(monitor, timeout = 0, env = parent.frame())
{
  #.Call("Sync_wait", monitor, timeout)
  #if(missing(monitor)) .Call("Sync_wait", NULL, timeout, env) else
  .Call("Sync_wait", substitute(monitor), timeout, env)
}

sync.notify <- function(monitor, all = FALSE, env = parent.frame())
{
#  .Call("Sync_notify", monitor, all)
  #monitor <- if(missing(monitor)) NULL else substitute(monitor)
  #.Call("Sync_notify", monitor, all, env)
  .Call("Sync_notify", substitute(monitor), all, env)
}
}



