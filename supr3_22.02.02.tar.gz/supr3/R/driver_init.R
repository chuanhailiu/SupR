
#if(FALSE && !is.loaded("R_thread_init")) {
#  dyn.load("libsupr.so")
#print("To call .Call(\"R_thread_init\")");
#print(ls())
#  .Call("R_thread_init")
#print("Called .Call(\"R_thread_init\")");
#}

loadRData <- function(file){
    env = new.env()
    load(file, envir = env)
    as.list(env)
}

#SuprContext.conf <- function(...){
#  .Call("SuprContext_conf", pairlist(...), parent.frame())
#}

#SuprContext.start <- function(...){
#  .Call("SuprContext_start", pairlist(...), parent.frame())
#}


if(FALSE){
SuprContext <- function(what, ..., character.only = FALSE,
		       	envir = parent.frame()){
  if(missing(what)){ 
	  what <- NULL
  } else if(!character.only){
    name <- substitute(what)
    if(is.symbol(name)){
      what <- as.character(name)
      if(exists(what, envir)) {
        what <- get(what, envir)
        if(!is.character(what))
	  what <- as.character(name)
      }
    } 
  }

  if(!is.null(what) && !is.character(what))
	  stop("invalid 'what' argument")

  .Call("SuprContext", what, pairlist(...), envir)
}
}

#SuprJob <- function(job, action = c("print","get", "is.done", "cancel"), ...){ .Call("SuprJob",  job, as.character(action[1]), pairlist(...)) }

#print.SuprContext <- function(x) { invisible(SuprContext("print"))}
print.SuprJob <- function(x) { invisible(SuprJob(x, "print"))}

#jobGet <- function(job, combine = NULL, timeout = 60) { r <- .Call("SuprJob", job, "get", pairlist(timeout=timeout)) if(!is.null(combine)) combine(r) else r }

#SuprContext.quit <- function(){ .Call("SuprContext_quit") }


startDriver <- function(port = 0) .Call("startDriver", port)

stopDriver <- function(stop.master = TRUE) .Call("stopDriver", stop.master)

#driver.info <- function() { .Call("Driver_info") }

startWorker <- function(port=0, subdir="testing", master=NA)
{
  .Call("startWorker", as.integer(port), as.character(subdir),
       	as.character(master))
}


#shutdown <- function() { driverEval("shutdown", pairlist()) }

if(FALSE){
Cluster.eval <- function(expr, data, envir=NULL, collect = FALSE,
                  dcl=NULL, dcl.expr = NULL, dcl.envir = NULL, 
                  env=parent.frame(), wait=TRUE, ...){
  if(!is.null(dcl))
	 dcl = as.character(dcl)

  .Call("R_cluster_eval", expr, data, envir,
         list(...), env, wait,
         dcl, dcl.expr, dcl.envir, collect)
}

cluster.eval <- Cluster.eval
}


#job.get <- function(job, timeout = 0){ .Call("R_future", job, "get", as.numeric(timeout)) }
#job.isDone <- function(job){ .Call("R_future", job, "is.done") }


#job.cancel <- function(job){ .Call("R_future", job, "cancel", 0) }
#Job.cancel <- function(job){ SuprJob(job, "cancel") }

Cluster.get <- function(uri, name, remove=FALSE){
  .Call("Cluster_getRObject", uri, name,  remove)
}

cluster.get <- Cluster.get

nextEvent <- function(...){
    .Call("DCL_nextEvent", pairlist(...))
}

#print(quote({
#    a <- cluster.eval(expr.1, data=as.list(1:10))
#  }))


# Simple combine example

if(FALSE){
  expr.combine <- quote({
    Sys.sleep(1)
    warning("testing")
    combine <- function(x, y){x+y}
    x <- nextSubset()
    # send.driver(paste("nextSubset() : x =  ",x))
    while(!is.null( y <- nextSubset() )){
	    x <- combine(x, y)
#	    Sys.sleep(10)
    }
    clusterCombine(x, combine)
  })

print(quote({
    a <- cluster.eval(expr.combine, data=as.list(1:10))
  }))


# Combine byKey example


  expr.cbk <- quote({
    Sys.sleep(1)
    x <- nextSubset()
    while(!is.null(y <- nextSubset())){
	    x <- x + y
    }

  #  send.driver(paste("\033[0;31mx=",x, "\033[0m"))

    data <- new.env(parent=emptyenv())
  
    if(x > 26) x = 26
    keys <- sample(letters, x)
    for(i in 1:x){
      assign(keys[i], x, data)
    }
    combine <- function(x, y){x+y}
    clusterCombine(data, combine, bykey=TRUE)
  })

  cat("expr:\n")
  print(expr.cbk)
  print(quote({
    a <- cluster.eval(expr.cbk, data=as.list(1:10))
  }))

  if(FALSE){
    value <- list()
    for(i in 1 : length(a)){
      x <- a[[i]]$value
      if(length(x)){
        addr <- attr(x, "location")
        val  <- sapply(x, function(name){
                    cluster.get(addr, name)
                  })
	print(val)
	value <- append(value, val)
      }
    }
    print(value)
  }


# synchronization example
# sync.eval (short for synchronized evalation

  expr.sync <- quote({
      cat("sync.eval ...\n")
      val <- list(date())
    sync.eval(quote({
      cat("synchronized at ")
      val <- append(val, date())
      print(date())
      Sys.sleep(1)
    }), mutex="sync.example")
    val <- append(val, date())
    val
  })


  cat("expr:\n")
  print(expr.sync)
  print(quote({
    a <- cluster.eval(expr.sync, data=as.list(1:10))
  }))

# wait and notify example

  expr.wait <- quote({
      cat("sync.eval ...\n")
      val <- list(date())
    sync.eval(quote({
      cat("synchronized at ")
      val <- append(val, date())
      print(date())
      rc <- wait("sync.example", 10)
      val <- append(val, date())
      val <- append(val, rc)
      
    }), mutex="sync.example")
    val <- append(val, date())
    val
  })


  cat("expr:\n")
  print(expr.wait)
  print(quote({
    a <- cluster.eval(expr.wait, data=as.list(1:10))
  }))


  expr.notify <- quote({
      cat("\nsync.eval ... x:\n")
      x <- nextSubset()
      print(x)
      y <- put.par("myData", x)
      cat("\nsync.eval ... y:\n")
      print(y)
      z <- get.par("myData")
      cat("\nsync.eval ... z:\n")
      print(z)
      val <- list(date())
    sync.eval(quote({
      cat("synchronized at ")
      val <- append(val, date())
      print(date())
      rc <- if(x != floor(x/2)*2 ) {
	      Sys.sleep(2)
	      notify("sync.example", all=FALSE)
      } else wait("sync.example", 5)
      val <- append(val, date())
      val <- append(val, rc)
      
    }), mutex="sync.example")
    val <- append(val, date())
    if(is.null(x)){
        notifyAll("sync.example") # automatically synchronize..
    }
    val
  })


  cat("\n\033[0;32mexpr:\033[0m\n")
  print(expr.notify)

  Thread.openXTerm <- function(...){
    .Call("Thread_openXTerm", pairlist(...))
  }

  my.dcl.expr <- quote({
    # Sys.sleep(30)
    Thread.openXTerm(tty="/dev/pts/14")
    Thread.startInputHandler()
    while(!is.null(e <- nextEvent())){
      print(e)
      plot(1:10)
    }
    print("DONE!")
    x <- scan()
    print(x)
  })

  print(quote({
    a <- cluster.eval(expr.notify, data=as.list(1:10),
      dcl="my.dcl", dcl.expr=my.dcl.expr, dcl.env = new.env())
  }))

#  Cond.count <- function(..., cond.name = "default", env=parent.frame()) {
#    .Call("TR_countAndGet", cond.name, pairlist(...))
#  }


  expr.cond <- quote({
    subsets <- list()
    while( !is.null(x <- nextSubset()))
       subsets <- append(subsets, x)

    for(i in 1:10) {
    count <- Cond.count(n = length(subsets))
    Sys.sleep(2)
    #count <- Cond.count()
    }
    subsets
  })

  print(quote({
    a <- cluster.eval(expr.cond, data=as.list(1:10),
      dcl="my.dcl", dcl.expr=my.dcl.expr, dcl.env = new.env())
  }))


  # DD data

#  DD <- function(name){ name = as.character(name) class(name) <- "DD" name }

  expr.dd <- quote({
    subsets <- list()
    while( !is.null(x <- nextSubset()))
       subsets <- append(subsets, x)

    for(i in 1:10) {
    count <- Cond.count(n = length(subsets))
    Sys.sleep(2)
    #count <- Cond.count()
    }
    subsets
  })

  print(quote({
    a <- cluster.eval(expr.dd, data=DD("mydata"),
      dcl="my.dcl", dcl.expr=my.dcl.expr, dcl.env = new.env())
  }))

}







