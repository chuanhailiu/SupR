
local({
  print("run supr/R/supr ...")
})

#DD <- function(...){ print("This is the basic tool for DD") }

# context(config=list(env="SLURM_JOB_NODELIST"))

supr.version <- function(){
   .Call("Supr_version")
}

xterm <- function(interactive = FALSE, ...){
  .Call("Supr_X_terminal", interactive, list(...))
}

#xterm.exit <- function(){ .Call("Supr_X_terminal_exit") }

supr.gdb <- function(proc.id = NULL, interactive = TRUE){
   .Call("Supr_gdb", proc.id, interactive)
}

Sys.info2 <- function(){
   .Call("Supr_info_extended")
}



# TODO
# verbose, debug, 
supr.options <- function(...)
{
  .Call("Supr_setOptions", list(...))
}

supr.call <- function(..., env=list()) {
   call <- match.call()
   .Call("Supr_doRemoteCall", .name, .server, call);
}

signal <- function(pid, sig=c("INT", "USR1", "USR2", "KILL", "ABRT", "PIPE",
    "WINCH", "STOP", "CONT", "CHLD")[1], cmd = NULL, message = NULL){
   .Call("Supr_signal", as.integer(pid), as.character(sig),
	as.integer(cmd), message) 
}

#worker.interrupt <- function(...){ .Call("Supr_interrupt", pairlist(...)); }

if(FALSE){
Supr <- function(verbose = FALSE, check = FALSE, ...)
{
  if(!missing(verbose))
    .Call("Supr_setVerboseEnabled", verbose)

  if(!missing(check))
    .Call("Supr_check")
}
}

print.SuprError <- function(x, ...)
{
  m <- attr(x, "message")
  if(is.null(m)) invisible(m) else print(m)
}

SuprError <- function(what, message)
{
  if(missing(what)) return(.SuprError)

  name <- as.character(substitute(what))

  if(name == "clear") {
	  .Call("SuprError_clearMessage")
  } else if(name == "set")
	  .Call("SuprError_setRMessage", as.character(message))
  .SuprError
}

Supr.xterm <- function (...)
{
    .Call("Supr_xterm", pairlist(...))
}


#SuprError <- .SuprError

print.DefinedVar <- function(x, ...)
{
	stop("delete me")
}

runAsWorker <- function(...){
  .Call("Supr_runAsWorker", pairlist(...))
}

runAsDFSDatanode <- function(...){
  .Call("Supr_runAsDFSDatanode", pairlist(...))
}

runAsDFSNamenode <- function(...){
  .Call("Supr_runAsDFSNamenode", pairlist(...))
}


.onLoad <- function(libname,  pkgname){
  ns <- .Call("Supr_onLoad", libname,  pkgname)
  cmd <- ns$Sys.cmd
#  cat("cmd:", cmd, "\n")
  if(!is.null(cmd) && (cmd == "worker" || cmd == "driver" || cmd == "master") )
    ns$interrupt <- function(...) .Call("Supr_interrupt", pairlist(...)) 

  if(!is.null(cmd) && (cmd == "taskrunner"))
    ns$task.info <- pairlist(tr.name=NULL)
}

.onAttach <- function(libname,  pkgname){

  .Call("Supr_onAttach", libname,  pkgname)

  fun <- function(v) {
            if (missing(v))
                .Call("Supr_getConnections")
            else { #cat("set\n") #x <<- v
		    NULL
            }
         }
  environment(fun) <- .getNamespace("supr3") #parent.frame()
  makeActiveBinding("connections", fun, .SuprEnv)

  fun <- function(v) {
            if (missing(v))
                .Call("Supr_getPthreads")
            else { #cat("set\n") #x <<- v
		    NULL
            }
         }
  environment(fun) <- .getNamespace("supr3") #parent.frame()
  makeActiveBinding("pthreads", fun, .SuprEnv)

  ns <- .getNamespace("supr3") #parent.frame()
  cmd <- ns$Sys.cmd

  if(cmd == "driver"){
    assign("master", function(addr=NULL) .Call("Supr_master", addr), .SuprEnv)
    assign("dfs", function(addr=NULL) .Call("Supr_dfsname", addr), .SuprEnv)
    assign("jobs", function() .Call("R_cluster_jobs"), .SuprEnv)
    assign("job", function(job.id) .Call("R_cluster_job", as.integer(job.id)), .SuprEnv)
  }

  ## For now... ?
  if(FALSE){
    fun <- function(v) {
            if (missing(v))
                .Call("Supr_interrupt", NULL)
            else { #cat("set\n") #x <<- v
                .Call("Supr_interrupt", v)
            }
         }
    environment(fun) <- .getNamespace("supr3") #parent.frame()
    makeActiveBinding("interrupt", fun, .SuprEnv)
  }


  
#  fun <- function(v) {
#            if (missing(v))
#                .Call("Supr_setOptions", NULL)
#            else { #cat("set\n") #x <<- v
#                .Call("Supr_setOptions", v)
#            }
#         }
#  environment(fun) <- .getNamespace("supr3") #parent.frame()
#  makeActiveBinding("supr.options", fun, .SuprEnv)



  fun <- local( {
         x <- NULL
         function(expr) {
            if (!missing(expr)){
	        args <- eval(expr$expr, .SuprEnv)
                x <<- do.call(base::makeActiveBinding, args)
            }
            x
         }
     })
  makeActiveBinding("makeActiveBinding", fun, .SuprEnv)

  fun <- function(v) {
            if (missing(v))
                .Call("shm_operations", NULL)
            else {
                .Call("shm_operations", v)
            }
         }
  environment(fun) <- .getNamespace("supr3") #parent.frame()
  makeActiveBinding("shm", fun, .SuprEnv)

}

.onDetach <- function(libpath){
  .Call("Supr_onDetach", libpath)
}

.onUnload <- function(libpath){
  .Call("Supr_onUnload", libpath)
}

#DD <- function(name){ name = as.character(name) class(name) <- "DD" name }

#thread.openXTerm <- function(...){
#    .Call("Thread_openXTerm", pairlist(...))
#  }

# Cluster Objects
ClusterObj <- function(name)
       	structure(as.character(name), class="ClusterObj") 

put <- function(x, ...) UseMethod("put")
put.default <- function(x, ...) stop("undefined")

put.DD <- function(name, ...) {
	DD.put(name, ...)
}



if(FALSE){
#put.ClusterObject <- function(name, ...) { return(paste("TODO: put cluster object ", name)) }

#`$<-.SuprShared` <- function(x, name, value) { .Call("SuprShared_put", x, name, value) x }

#`$.SuprShared` <- function(x, name) { .Call("SuprShared_get", x, name) }

#ls.SuprShared <- function(x, ...) { "TODO" }

#.ClusterEnv <- structure(new.env(parent =emptyenv()), class = "SuprShared")

#show_addr <- function(x){ .Call("Supr_addr", x) }
}

## .Call("SuprShared_put", x, name, value)
## .Call("SuprShared_get", x, name)


if(FALSE){
makeActiveBinding("JobEnv", local({
     .JobEnv <- structure(".JobEnv", class = "SuprShared")
     function(v){
       if(missing(v)){
         .JobEnv
       } else {
         warning("ignore assignment")
       }
     }
  }), environment())

makeActiveBinding("ClusterEnv", local({
     .ClusterEnv <- structure(".ClusterEnv", class = "SuprShared")
     function(v){
       if(missing(v)){
         .ClusterEnv
       } else {
         warning("ignore assignment")
       }
     }
  }), environment())

makeActiveBinding("SharedEnv", local({
     .SharedEnv <- structure(".SharedEnv", class = "SuprShared")
     function(v){
       if(missing(v)){
         .SharedEnv
       } else {
         warning("ignore assignment")
       }
     }
  }), environment())

makeActiveBinding("LocalEnv", local({
     .LocalEnv <- structure(".LocalEnv", class = "SuprShared")
     function(v){
       if(missing(v)){
         .LocalEnv
       } else {
         warning("ignore assignment")
       }
     }
  }), environment())

# just use three character objects, no active binding is necessary...
lockBinding("SharedEnv",  environment())
lockBinding("ClusterEnv", environment())
lockBinding("JobEnv", environment())
lockBinding("LocalEnv", environment())

print.SuprShared <- function(x, ...){
  val <- .Call("SuprShared_print", x, pairlist(...), parent.frame())
  print(if(is.environment(val)) ls.str(val, all=TRUE) else val)
  invisible(val)
}


# S4 make the base::get function generic
setGeneric("get", base::get)
ClusterObject <- setClass("ClusterObject", contains=c("character"))
setMethod("get", "ClusterObject", function(x){
		  paste(x,"of myClass", "TODO ...")}
	  )

# setMethod("get", signature("thread.server"), Sync.get)





#SuprShared <- setClass("SuprShared", contains=c("character"))
#setMethod("$", "SuprShared", function(x, name) .Call("SuprShared_get", x, name))
#setMethod("$<-", "SuprShared", function(x, name, value) .Call("SuprShared_put", x, name, value))

}

