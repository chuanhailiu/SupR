
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <time.h>
#include <assert.h>
#include <signal.h>
#include <pthread.h>

#include <sys/syscall.h>


// network
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>


#include <dirent.h>
#include <sys/vfs.h>



static char *Supr_message = NULL;


char *runAsDaemon(char *dir)
{
   pid_t pid = fork();
   if(pid < 0) {
           perror("fork");
           exit(EXIT_FAILURE);
   }

   if (pid > 0) {
     Supr_message = "Daemon exit 1";
     exit(EXIT_SUCCESS); // wait?
   }

   if(setsid() < 0) {
           perror("fork");
           exit(EXIT_FAILURE);
   }

   {
     fprintf(stderr, "ppid: %d, pid %d\n", getppid(), getpid());
   }

   //signal(SIGCHLD, SIG_IGN); // otherwise, cause waitpid problems ...
   //signal(SIGHUP, SIG_IGN);

   // fork off for the second time
   pid = fork();
   if(pid < 0) {
           perror("fork");
           exit(EXIT_FAILURE);
   }

   if (pid > 0) {
     Supr_message = "Daemon exit 2";
     exit(EXIT_SUCCESS); // wait?
   }

   // Set new file permissions
   umask(0);

   char path[PATH_MAX];

   if(!dir){
     dir = getcwd(path, sizeof(path));
     if(!dir){
           perror("getcwd");
           exit(EXIT_FAILURE);
     }
     dir = malloc(strlen(path)+1);
     memcpy(dir, path, strlen(path)+1);
   }

   if(chdir(dir) == -1){
           perror(dir);
           exit(EXIT_FAILURE);
   }

   // close all open file descriptors
   for(int fd = sysconf(_SC_OPEN_MAX); fd >= 0; fd --)
           close(fd);

   // open the log file
   // openlog("supr.master", LOG_PID, LOG_DAEMON);

   //sprintf(path, "%s/%s/stdout.txt", Supr_usrHome, cmd_name);
   sprintf(path, "%s/suprd-stdout.txt", dir);
   unlink(path);

   FILE *out = fopen(path, "w");
   if(out)
     dup2(fileno(out), STDOUT_FILENO);

   sprintf(path, "%s/suprd-stderr.txt", dir);
   unlink(path);
   FILE *err = fopen(path, "w");
   if(err)
     dup2(fileno(err), STDERR_FILENO);

   return dir;
}

const char *__version__ = "suprd 1.0.0";
const char *__doc__ =
"    suprd [--help] [--version] [-d directory] [-h host[:host]*]"
"          [-p port]";

//trusted_hosts:
typedef struct host_node_struct {
  struct host_node_struct *next;
  char *host;
} host_node_t;

host_node_t *host_root = NULL;
int port = 0;

host_node_t *host_add(const char *hosts){

  if(!hosts){
    char name[256];
    int len = gethostname(name, 256);
    if(len==-1){
	    perror("gethostname");
	    exit(EXIT_FAILURE);
    }
    //printf("hostname: %s, sizeof(name): %ld\n", name, sizeof(name));
    return host_add(name);
  }

  char buf[strlen(hosts)+1];
  memcpy(buf, hosts, strlen(hosts)+1);
  char *h = strtok(buf, ":");
  while(h){

    host_node_t *node = host_root;
    while(node) {
	    if(strcmp(node->host, h)==0)
		    break;
	    node = node->next;
    }

    if(node == NULL){
      printf("Add host: %s\n", h);
      node = malloc(sizeof(host_node_t));
      node->host = strdup(h);
      node->next = host_root;
      host_root = node;
    }

    h = strtok(NULL, ":");
  }

  return host_root;
}

void host_print(host_node_t *node)
{
  if(!node) node = host_root;
  while(node){
    printf("host: %s\n", node->host);
    node = node->next;
  }
}

#define MAX_PENDING_CONNECTIONS 20

int T_maxPendingConnections = MAX_PENDING_CONNECTIONS;

#define USE_NONBLOCKING_SOCKET

#define INT_SIZE sizeof(int)

int __socket_server(int _port, int *port, int reuse_addr)
{
  //printf("%s(port=%d, reuse_addr=%d) \n", __func__, _port, reuse_addr);

  struct sockaddr_in serv_addr;
  int listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if(listenfd == -1) // fixme - don't call errorcall ...
  {
     perror("socket");
     return -1;
  }

  if(reuse_addr){
    int val = 1;
    int rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &val, INT_SIZE);
    if(rc == -1)
      printf("warning in setsockopt(%d, ...): %s\n", listenfd, strerror(errno));
  }

#ifdef USE_NONBLOCKING_SOCKET
  { // 10/21/2019 try non-blocking mode
//    print_caller_info(0);
//    print_caller_info(1);
    int flags = fcntl(listenfd, F_GETFL);
    //printf("\033[0;31m%s: %d\033[0m\n", __func__, flags & O_NONBLOCK);
    //printf("\033[0;31m%s: listen_fd = %d\033[0m\n", __func__, listenfd);
    fcntl(listenfd, F_SETFL, O_NONBLOCK);
  }
#endif

  void *ptr = memset(&serv_addr, '0', sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(_port);

  int b = 0;
  int rc;
    while((rc = bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)))
                  ==-1){
          printf("Warning in bind(%d, port=%d, ...): %s\n", listenfd, _port,
                          strerror(errno));

          if(errno == EADDRINUSE && reuse_addr){
            int val = 1;
            rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &val, INT_SIZE);
            if(rc == 0) break;
            printf("error in setsockopt(%d, port=%d, ...): %s\n", listenfd,
                            _port, strerror(errno));

          }
          //sleep(1);
          /*
          {
true = 1;
setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &true, sizeof(int));
          }
          */

      b++;
      if(b>100) break;
      serv_addr.sin_port = htons(++_port);
  }

  //printf("[%s] bind: rc = %d\n", __func__, rc);

  if(b>100) {
    perror("bind");
    return -1;
  }

  if(listen(listenfd, T_maxPendingConnections)==-1){
    perror("listen");
    return -1;
  }

//  printf("[%s] listenfd: %d\n", __func__, listenfd);
//  printf("[%s] port: %d\n", __func__, _port);
//  printf("[%s] port: %d\n", __func__, serv_addr.sin_port);

  *port = _port;
  return listenfd;
}

int socket_server(int _port, int *port, int reuse_addr)
{
  static int min_port = 0, max_port = 9100; // FIXME

  if(!min_port){
          min_port = 6100;
          srandom((unsigned int) 7100);
  }

  if(_port)
    return __socket_server(_port, port, reuse_addr);

  int fd = -1;

  while(fd < 0){
    long rn = random();
    int this_port = (int) (min_port + rn % (max_port - min_port));
    printf("[%s] try port: %d\n", __func__, this_port);
    fd =  __socket_server(this_port, port, reuse_addr);
    if(fd < 0) sleep(5);
  }

  return fd;
}

int server_accept(int listenfd, struct sockaddr_in *pclientAddr)
{
//  struct sockaddr_in clientAddr;
  socklen_t addrlen = sizeof(struct sockaddr_in);

  //int connfd = accept(listenfd, (struct sockaddr*) &clientAddr, &addrlen);
  int connfd = accept(listenfd, (struct sockaddr*) pclientAddr, &addrlen);

  if(connfd==-1) {
          printf("connfd==-1!\n\tlistenfd=%d\n\t%s\n",
                         listenfd, strerror(errno));
//          print_caller_info(0);
//          print_caller_info(1);
    return connfd;
  } else {
    //printf("\tsin_family = %d (short AF_INET=%d)\n", clientAddr.sin_family,
    //printf("\tsin_family = %d (short AF_INET=%d)\n", pclientAddr->sin_family, AF_INET);
    //printf("\tsin_port = %u (unsigned short)\n", clientAddr.sin_port);
    //printf("\tsin_port = %u (unsigned short)\n", pclientAddr->sin_port);
    //char *ip = inet_ntoa(clientAddr.sin_addr);
    char *ip = inet_ntoa(pclientAddr->sin_addr);
    //printf("\tip in dots-and-numbers format = %s\n", ip);
    char hostname[1024];
    char service[1024];
    //getnameinfo((const struct sockaddr *)&clientAddr,
    getnameinfo((const struct sockaddr *)pclientAddr,
                   sizeof(struct sockaddr_in),
                   hostname, 128,  service, 128, 0);
    printf("\thostname:  %s\n", hostname);
    //printf("\tservice:   %s\n", service); // e.g., "http"
  }
  return connfd;
}


typedef struct conn_struct {
  int fd;
  int ok; // passcode OK?
  char *host;
  struct conn_struct *next;
} conn_t;

char *passcode = NULL;

void setPasscode()
{
  char *home = getenv("HOME");
  char path[PATH_MAX];
  sprintf(path, "%s/.supr/.passcode", home);
  int rc = access(path, F_OK);
  if(rc == -1){
    printf("Warning: the passcode file doesn't exist\n");
    return;
  }
  rc = access(path, R_OK);
  if(rc == -1){
    printf("Error: cannot read the passcode file, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  int fd = open(path, O_RDONLY);
  if(fd == -1){
    printf("Error: cannot open the passcode file, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  struct stat sb;
  rc = fstat(fd, &sb);
  if(rc == -1){
    printf("Error: stat, the passcode file, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  char buf[sb.st_size+1];
  ssize_t size = read(fd, buf, sb.st_size);
  if(size != sb.st_size){
    printf("Error: stat, the passcode file, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  buf[sb.st_size] = 0;
  close(fd);
  passcode = strdup(buf);

  printf("passcode: %s\n", passcode);

}

conn_t  conn_root = {-1, 1, NULL, NULL};

conn_t  *conn_add(int fd, const char *host)
{
  conn_t  *conn = malloc(sizeof(conn_t));
  conn->fd = fd;
  conn->ok = 0;
  conn->host = host ? strdup(host): NULL;
  conn->next = conn_root.next;
  conn_root.next = conn;

  return conn;
}

void conn_print()
{
  conn_t  *conn = &conn_root;
  while(conn){
	  printf("fd: %d, host: %s\n", conn->fd, conn->host);
	  conn = conn->next;
  }
}

#define conn_read(fd, buf, size)	do {	\
  size_t __size__ = (size);		\
  void *__buf__ = (void*) (buf);		\
  int __fd__ =  (fd);		\
  for(int i; ;i++){		\
    ssize_t k = read(__fd__, __buf__, __size__);		\
    if(k < 0 ) return -1;		\
    else if(k == __size__) break;		\
    else if(i > 100) return -1;		\
    else {__buf__ += k; __size__ -= k;}	\
  }		\
} while(0)

#define TRUE  1
#define FALSE 0

#define PASSCODE 1001
#define ADD_HOST 1011
#define RUN_CMD  1021

int run_cmd(int argc, char **argv)
{
  /*
  printf("argc: %d\n", argc);
  for(int i=0; i<argc; i++){
    printf("argv: %s\n", argv[i]);
  }
  */

  char **argv_exec = argv + 1;
  /*
  for(int i=0; argv_exec[i]; i++){
    printf("argv_exec: %s\n", argv_exec[i]);
  }
  */

  pid_t pid = fork();
  if(pid != 0) return pid;

  int rc;
  /*
  rc = setpgrp();
  if(rc == -1)
    printf("setpgrp: %d, %s\n", rc, strerror(errno));
    */

  pid=fork();
  if(pid) exit(EXIT_SUCCESS);

  rc = setsid();
  if(rc == -1)
    printf("setsid: %d, %s\n", rc, strerror(errno));

  //int rc = execv(argv[0], ++argv);
  rc = execv(argv[0], argv_exec);
  printf("\033[0;31mrc: %d, error: %s\033[0m\n", rc, strerror(errno));
  
}

int handleCommand(conn_t *conn)
{
  int cmd;
  int fd = conn->fd;
  for(int count =0; ; count++) {
      ssize_t len = recv(fd, &cmd, INT_SIZE, MSG_PEEK | MSG_DONTWAIT);
      if(len == INT_SIZE)
              break;
      else if(len == 0) {
         return -1;
      }
      else if(len == -1) {
         printf("Error: %s\n", strerror(errno));
         return -1;
      } else {
         printf("Warning: len = %ld\n", len);
	 count++;
	 if(count >= 10) return -1;
	 sleep(1);
      }
  }

  conn_read(fd, &cmd, INT_SIZE);

  switch(cmd){
    case PASSCODE:  
	 {
		 //printf("cmd: PASSCODE\n");
	     int len;
             conn_read(fd, &len, INT_SIZE);
	     char buf[len];
             conn_read(fd, buf, len);
		 //printf("buf: %s\n", buf);
	     if(passcode && strcmp(buf, passcode)==0){
	       conn->ok = TRUE;
	       int rc = 0;
               write(fd, &rc, INT_SIZE);
		 //printf("PASSCODE: OK\n");
	     } else {
	       return -1;
	     }
	 }
	 return 0;

    case ADD_HOST: 
	 {
		 printf("cmd: ADD_HOST\n");
	   if(conn->ok || passcode == NULL){
	     int len;
             conn_read(fd, &len, INT_SIZE);
	     char buf[len];
             conn_read(fd, buf, len);
	     host_add(buf);
	     int rc = 0;
	     write(fd, &rc, INT_SIZE);
	   } else {
	     return -1;
	   }
	 }
	 return 0;

    case RUN_CMD: 
	 {
		 //printf("cmd: RUN_CMD\n");
	   if(conn->ok || passcode == NULL){
	     int argc;
             conn_read(fd, &argc, INT_SIZE);
		 //printf("argc: %d\n", argc);
	     char **argv = (char**) malloc(sizeof(char*)*(argc+1));
	     for(int i=0; i<argc; i++){
	       int len;
               conn_read(fd, &len, INT_SIZE);
		 //printf("len: %d\n", len);
	       argv[i] = (char*) malloc(len);
               conn_read(fd, argv[i], len);
		 //printf("argv[%d]: %s\n",i, argv[i]);
	     }
	     argv[argc] = NULL;
	     int rc = run_cmd(argc, argv);
	     write(fd, &rc, INT_SIZE);
	     for(int i=0; i<argc; i++)
	       free(argv[i]);
	     free(argv);
	   } else {
	     return -1;
	   }
	 }
	 return 0;

    default:
	 printf("unknown command: %d\n", cmd);
	 return -1;
  }
  
}


void run_Repl(const char *dir, int port, int reuse_addr)
{
  printf("port: %d, reuse_addr: %d\n", port, reuse_addr);
  int listen_fd = socket_server(port, &port, reuse_addr);
  printf("listen_port: %d\n", port);
  printf("listen_fd:   %d\n", listen_fd);

  conn_root.fd = listen_fd;
  conn_root.host = strdup("localhost");

  while(TRUE){
    struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      int max_fd = 0;
      FD_ZERO(&readfds);

      for(conn_t *conn = &conn_root; conn; conn = conn->next){
        FD_SET(conn->fd, &readfds);
	if(conn->fd > max_fd)
	  max_fd = conn->fd;
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(listenfd, &readfds) = %d\n", __func__,
               FD_ISSET(listen_fd, &readfds));
	    //exit(EXIT_SUCCESS);
      }

      conn_t *conn = &conn_root; 
      while(conn->next){
        conn_t *n = conn->next;
	if(FD_ISSET(n->fd, &readfds)) {
	  int rc = handleCommand(n);
	  if(rc == -1){
             conn->next = n->next;
	     close(n->fd);
	     free(n->host);
	     free(n);
	     continue;
	  }
	}
	conn = conn->next;
      }

      if(FD_ISSET(conn_root.fd, &readfds)) {
        struct sockaddr_in clientAddr;
        int fd = server_accept(conn_root.fd, &clientAddr);
        char hostname[256];
        char service[256];
        getnameinfo((const struct sockaddr *)&clientAddr,
                   sizeof(struct sockaddr_in),
                   hostname, 128,  service, 128, 0);
        printf("\thostname:  %s\n", hostname);
	if(strcmp(hostname, "localhost")==0)
		gethostname(hostname, sizeof(hostname));
	
        host_node_t *node = host_root;
	while(node){
	  if(strcmp(node->host, hostname)==0)
		  break;
	  node = node->next;
	}
	if(node) {
          conn_add(fd, hostname);
          conn_print();
	} else {
	  close(fd);
	}
      }
  }
  printf("EXIT\n");
}



int main(int argc, char **argv)
{
  char *dir = NULL;

  host_add(NULL);

  for(int i=1; i<argc; i++) {
    if(strcmp(argv[i], "--help")==0) {
      printf("%s\n", __doc__);
      exit(EXIT_SUCCESS);
    } else if(strcmp(argv[i], "--verison")==0) {
      printf("%s\n", __version__);
      exit(EXIT_SUCCESS);
    } else if(strcmp(argv[i], "-d")==0) {
      if(i == argc-1){
	fprintf(stdout, "the directory name is not provided"
		       " for the '-d' option");
        exit(EXIT_FAILURE);
      }
      dir = argv[++i];
    } else if(strcmp(argv[i], "-h")==0) {
      if(i == argc-1){
	fprintf(stdout, "the host names are not provided"
		       " for the '-h' option");
        exit(EXIT_FAILURE);
      }
      host_add(argv[++i]);
    } else if(strcmp(argv[i], "-p")==0) {
      if(i == argc-1){
	fprintf(stdout, "the port number is not provided"
		       " for the '-p' option");
        exit(EXIT_FAILURE);
      }
      port = atoi(argv[++i]);
    } else {
      fprintf(stdout, "unknown argument: %s\n", argv[i]);
      exit(EXIT_FAILURE);
    }
  }

  host_print(NULL);
  printf("port: %d\n", port);
  printf("dir:  %s\n", dir);
  fflush(stdout);

  setPasscode();

  dir = runAsDaemon(dir);

  run_Repl(dir, port, 0);
}

