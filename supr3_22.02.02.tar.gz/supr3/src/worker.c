
/*
 * FIXME: not to use job->sc to communicate with driver
 *
 */

//#include "supr.h"
//#include "util.h"
#include "dd.h"


#include <sys/types.h>
#include <sys/wait.h>

#include <netinet/tcp.h>
//#include <signal.h>

#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)


#define gettid() ((int)syscall(SYS_gettid))

#define DEPRECATED_TR_SEND_DRIVER

extern vector_t *sys_threads;
extern void do_backtrace(void *);
extern char *cmd;
extern char *X11_str; // X11Forwarding

extern SEXP (*Supr_getPthreads_ptr)();
SEXP Worker_getPthreads();
extern SEXP SuprEnv;

// supr.h #define TR_WAIT_USE_TIME_EXPR

#define   DECREASE_REF(x) do {	\
	printf("[DECREASE_REF] %s:%d\n", __FILE__, __LINE__);	\
	__decrease_ref__(x)	;	\
} while(0)

#define __host__ Supr_hostname
#define msg_color "\033[0;37m"
#define SIG_BACKTRACE SIGINT

void Worker_dumper();

//#define DRIVER_MALLOC_DEBUG 1
#ifdef DRIVER_MALLOC_DEBUG
extern SEXP Malloc_print();
#define MALLOC_PRINT   Malloc_print()
void *__MALLOC_DEBUG_MARK__(size_t s)
{
        return malloc(s);
}
#define MALLOC_MARK(s) __MALLOC_DEBUG_MARK__(s)

//vector_t *taskrunners_to_join = NULL;

/*
char *__strdup(const char *s, const char *func, const char *file, int line)
{
  size_t len = strlen(s)+1;
  char *t = __supr_malloc__(len, func, file, line);
  memcpy(t, s, len);
  return t;
}
#define my_strdup(s) __strdup((s), __func__, __FILE__, __LINE__)
*/


#else
#define MALLOC_PRINT
#define MALLOC_MARK(s)
#endif

supr_socket_conn_t *socketServerConn = NULL;

extern const char *info_addr;
extern pthread_mutex_t Supr_syncMutex;
extern pthread_cond_t  Supr_syncCond;
extern void *Supr_syncObject;
static char msg[1024];
static supr_thread_t *debug_thread = NULL;

extern supr_socket_conn_t *info_sc;
extern supr_socket_conn_t *debug_sc;

static const char *master_addr = NULL;
//static const char *driver_addr = NULL;
static const char *notify_addr = NULL;
static const char *dfs_addr = NULL;
static pthread_t main_thread_id = 0;

struct sigaction R_oldSigBacktraceAct;

typedef struct SO_serialized_struct {
  void *ptr; // RAW(SEXP)
  ssize_t size; // LENGTH(SEXP)
} SO_serialized_t;

SO_serialized_t *SO_null = NULL;


void Thread_SigactionBacktrace(int sig, siginfo_t *ip, void *context){

  char msg[256];
  sprintf(msg, "%s___ tid: %d", __func__, gettid());
  Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

  supr_thread_t *cth = pthread_getspecific(currentThreadKey); 
  if(cth->fun) cth->fun(cth->data);
  pthread_mutex_lock(&cth->mutex);
    pthread_cond_signal(&cth->cond);
  pthread_mutex_unlock(&cth->mutex);
  sprintf(msg, "___%s tid: %d", __func__, gettid());
  Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
}


pthread_mutex_t driverServerInitMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  driverServerInitCond  = PTHREAD_COND_INITIALIZER;

vector_t *taskrunners_to_join = NULL;

int Taskrunner_sdl_count = 0; // for symbolic directory links
extern char *shm_prefix;

double CPU_usage(){
    // cpu info (USER_HZ: 1/100ths   of   a  second)
    // user   (1) Time spent in user mode.
    // nice   (2) Time spent in  user  mode  with  low  priority (nice).
    // system (3) Time spent in system mode
    // idle   (4)  Time  spent  in  the  idle  task.
    // iowait (5)  Time waiting for I/O to complete.
    // irq (6) Time servicing interrupts.

    unsigned long long total_cpu_usage1, total_cpu_usage0;
    unsigned long long cpu_usage1, cpu_usage0;
    int time = 1; // second
    for(int i=0; i<2; i++) {
      FILE *f = fopen("/proc/stat", "r");
      int c;
      size_t len=0;
      while((c=fgetc(f)) !='\n') len++;
      len ++;
      rewind(f);
      char buf[len];
      len=0;
      while((c=fgetc(f)) !='\n') buf[len++] = c;
      buf[len++]=0;
      fclose(f);

      unsigned long long user, nice, system, idle;
      sscanf(buf,"%*s %llu %llu %llu %llu",&user,&nice,&system,&idle);
      //printf("%llu %llu %llu %llu\n", user, nice, system, idle);
      if(i==0) {
        total_cpu_usage0 = user + nice + system + idle;
	cpu_usage0 = user + nice + system;
      } else  {
        total_cpu_usage1 = user + nice + system + idle;
	cpu_usage1 = user + nice + system;
      }

      sleep(time);
    }

    int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
    double cpu_usage = ((double)(cpu_usage1-cpu_usage0)) /
             (total_cpu_usage1-total_cpu_usage0) * 100.0*ncpu;

    return cpu_usage;
}

static void Taskrunner_interrupt(void *data);

int tr_count = 0, __tr_count = 0; // for count down ...
pthread_mutex_t *tr_count_mutex = NULL;
//pthread_cond_t *tr_count_mutex = NULL;


// under development
#define DEBUG_GC


//#define USE_SIGCHLD
#ifdef USE_SIGCHLD
void Worker_SigactionCHLD(int sig, siginfo_t *ip, void *context);
#endif

#define RUN_AS_DAEMON_PROC

extern char *Supr_sysHome;
extern char *Supr_usrHome;
extern char *Supr_message;

extern supr_thread_t *main_thread;

extern int Supr_verbose;
extern void supr_info(const char *format, ...);

//extern SEXP Supr_namespace;
extern SEXP SuprJobEnv;

typedef struct main_thread_task_struct {
  void (*fun)(void *);
  void *data;
} main_thread_task_t;

vector_t *main_thread_tasks = NULL;

void main_thread_tasks_add(void (*fun)(void *), void *data)
{
  main_thread_task_t *task = malloc(sizeof(main_thread_task_t));
  task->fun = fun;
  task->data = data;
  pthread_mutex_lock(main_thread_tasks->mutex);
    vectorAdd(main_thread_tasks, task);
  pthread_mutex_unlock(main_thread_tasks->mutex);

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);
}

main_thread_task_t *main_thread_tasks_get()
{
  main_thread_task_t *task = NULL;
  pthread_mutex_lock(main_thread_tasks->mutex);
    if(vectorSize(main_thread_tasks))
      task = (main_thread_task_t *) vectorRemove(main_thread_tasks, 0);
  pthread_mutex_unlock(main_thread_tasks->mutex);
  return task;
}



supr_socket_conn_t *master_conn = NULL;
supr_socket_conn_t *scToBackend = NULL;
supr_thread_t *backendThread = NULL;

extern void addCleanups(void (*run)(void *), void *data);

static int rjni_strcmp(const void *a, const void *b)
{
  return strcmp(*((char **) a), *((char **) b));
}



void broadcast_lock_destroy_W(broadcast_lock_t *bc)
{
	/*
  char *shm_name = (char *)data;
  ssize_t size;
  void *bc_shm_ptr = Supr_shm_open(shm_name, &size);
  if(!bc_shm_ptr) return;

  broadcast_lock_t *bc = (broadcast_lock_t *) bc_shm_ptr;
  */
  //basic_info("pthread_rwlock_destroy");
  pthread_rwlock_destroy(&bc->rwlock);
  //basic_info("pthread_mutex_destroy");
  pthread_mutex_destroy(&bc->mutex);
  //basic_info("pthread_cond_destroy");
  pthread_cond_destroy(&bc->cond); // deadlock? FIXME
  //basic_info(__func__);

  char msg[256];
  int rc = shm_unlink(bc->shm_name);
  /* if(rc == -1) {
	  sprintf(msg, "shm_unlink(%s), %s", bc->shm_name, strerror(errno)); 
	  basic_info(msg);
  } */

  char shm_name[256];
  sprintf(shm_name, "%s-sync", bc->shm_name);

  ssize_t size = sizeof(broadcast_lock_t) +strlen(bc->shm_name)+1;
  rc = munmap(bc, size);
  if(rc == -1) {
	  sprintf(msg, "munmap(->%s, %ld), %s", shm_name,size,strerror(errno)); 
	  basic_info(msg);
  }
  rc = shm_unlink(shm_name);
  if(rc == -1) {
	  sprintf(msg, "shm_unlink(%s), %s", shm_name, strerror(errno)); 
	  basic_info(msg);
  }

  verbose_info("broadcast_lock_destroy_W");
}

void broadcast_lock_destroy(void *data)
{
  char *shm_name = (char *)data;
  ssize_t size;
  void *bc_shm_ptr = Supr_shm_open(shm_name, &size);
  if(!bc_shm_ptr) return;

  broadcast_lock_t *bc = (broadcast_lock_t *) bc_shm_ptr;
  basic_info("pthread_rwlock_destroy");
  pthread_rwlock_destroy(&bc->rwlock);
  basic_info("pthread_mutex_destroy");
  pthread_mutex_destroy(&bc->mutex);
  basic_info("pthread_cond_destroy");
  pthread_cond_destroy(&bc->cond); // deadlock? FIXME
  basic_info(__func__);

  char msg[256];
  int rc = shm_unlink(bc->shm_name);
  if(rc == -1) {
	  sprintf(msg, "shm_unlink(%s), %s", bc->shm_name, strerror(errno)); 
	  basic_info(msg);
  }

  rc = munmap(bc_shm_ptr, size);
  if(rc == -1) {
	  sprintf(msg, "munmap(->%s, %ld), %s", shm_name,size,strerror(errno)); 
	  basic_info(msg);
  }
  rc = shm_unlink(shm_name);
  if(rc == -1) {
	  sprintf(msg, "shm_unlink(%s), %s", shm_name, strerror(errno)); 
	  basic_info(msg);
  }
}



broadcast_lock_t *broadcast_lock_create(int job_id)
{

    char bc_shm_name[256];
    sprintf(bc_shm_name, "%s-%d-bc-%d", shm_prefix, getpid(), job_id);
    char shm_name[256];
    sprintf(shm_name, "%s-sync", bc_shm_name);


    ssize_t size = sizeof(broadcast_lock_t) + strlen(bc_shm_name)+1;
    void *bc_shm_ptr = Supr_shm_create(shm_name, size); // do unlink atexit...
    broadcast_lock_t *bc = (broadcast_lock_t *) bc_shm_ptr;

    pthread_rwlockattr_t attr;
    pthread_rwlockattr_init(&attr);
    pthread_rwlockattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
    pthread_rwlock_init(&bc->rwlock, &attr);
    pthread_rwlockattr_destroy(&attr);

    //pthread_mutex_init(&bc->mutex, NULL);
    pthread_mutexattr_t mattr;
    pthread_mutexattr_init(&mattr);
    pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED);
    pthread_mutexattr_setrobust(&mattr, PTHREAD_MUTEX_ROBUST);
    pthread_mutex_init(&bc->mutex, &mattr);
    pthread_mutexattr_destroy(&mattr);

    //pthread_cond_init(&bc->cond, NULL);
    pthread_condattr_t cattr;
    pthread_condattr_init(&cattr);
    pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_SHARED);
    pthread_cond_init(&bc->cond, &cattr);
    pthread_condattr_destroy(&cattr);

    bc->bc_id = 0;
    bc->destroy = FALSE;

    strcpy(bc->shm_name, bc_shm_name);

    //basic_info(bc->shm_name);

    addCleanups(broadcast_lock_destroy, strdup(shm_name));

    return bc;
}

//static void *bc_shm_ptr = NULL;

/*
void Broadcast_destroy(void *data)
{
  broadcast_lock_t *bc = (broadcast_lock_t *) data;

  int rc = shm_unlink(bc->shm_name);
  if(rc == -1) basic_info(strerror(errno));

  char shm_name[256];
  sprintf(shm_name, "%s-sync", bc->shm_name);
  basic_info(shm_name);
  pthread_mutex_destroy(&bc->mutex);
  pthread_cond_destroy(&bc->cond);
  rc = munmap(data, sizeof(broadcast_lock_t) + strlen(bc->shm_name)+1);
  if(rc == -1) basic_info(strerror(errno));
  rc = shm_unlink(shm_name);
  if(rc == -1) basic_info(strerror(errno));
}

// use pthread mutex
void Broadcast_init()
{
    char shm_name[256];
    sprintf(shm_name, "%s-%d-bc-sync", shm_prefix, getpid());

    char bc_shm_name[256];
    sprintf(bc_shm_name, "%s-%d-bc", shm_prefix, getpid());
    ssize_t size = sizeof(broadcast_lock_t) + strlen(bc_shm_name)+1;
    bc_shm_ptr = Supr_shm_create(shm_name, size); // do unlink atexit...
    broadcast_lock_t *bc = (broadcast_lock_t *) bc_shm_ptr;

    //pthread_mutex_init(&bc->mutex, NULL);
    pthread_mutexattr_t mattr;
    pthread_mutexattr_init(&mattr);
    pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED);
    pthread_mutexattr_setrobust(&mattr, PTHREAD_MUTEX_ROBUST);
    pthread_mutex_init(&bc->mutex, &mattr);
    pthread_mutexattr_destroy(&mattr);

    //pthread_cond_init(&bc->cond, NULL);
    pthread_condattr_t cattr;
    pthread_condattr_init(&cattr);
    pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_SHARED);
    pthread_cond_init(&bc->cond, &cattr);
    pthread_condattr_destroy(&cattr);

    bc->bc_id = 0;
    strcpy(bc->shm_name, bc_shm_name);
    basic_info(bc->shm_name);

    addCleanups(Broadcast_destroy, bc_shm_ptr);
}


// use pthread mutex
void Broadcast_reinit()
{

    broadcast_lock_t *bc = (broadcast_lock_t *) bc_shm_ptr;

    //pthread_cond_init(&bc->cond, NULL);
    pthread_mutex_lock(&bc->mutex); // FIXME
    pthread_cond_broadcast(&bc->cond); // FIXME

    pthread_cond_destroy(&bc->cond);

    pthread_condattr_t cattr;
    pthread_condattr_init(&cattr);
    pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_SHARED);
    pthread_cond_init(&bc->cond, &cattr);
    pthread_condattr_destroy(&cattr);

    //pthread_mutex_init(&bc->mutex, NULL);
    pthread_mutex_destroy(&bc->mutex);
    pthread_mutexattr_t mattr;
    pthread_mutexattr_init(&mattr);
    pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED);
    pthread_mutexattr_setrobust(&mattr, PTHREAD_MUTEX_ROBUST);
    pthread_mutex_init(&bc->mutex, &mattr);
    pthread_mutexattr_destroy(&mattr);

}
*/



extern ssize_t Socket_send(int socket, const void *buffer, size_t length, int flags);

#define send(s, b, len, flags) Socket_send((s), (b), (len), (flags))




#define USE_CHECKSUM
#ifdef  USE_CHECKSUM
#define MSG_HEADER_SIZE 2*INT_SIZE
int (*cfncn)(char *, int, uint32_t *, off_t *) = Supr_crc32;
#else
#define MSG_HEADER_SIZE 0
#endif

/*
typedef struct tmp_output_struct {
  supr_socket_conn_t *conn;
  pid_t pid; // R process pid
  pid_t tid; // taskrunner thread id //
  char *file_name;
  void *mem_ptr;
  size_t file_size;
  size_t size; 
  size_t pos; // position
  struct tmp_output_struct *next;
//  int flush; int padding;
} tmp_output_t; // free...
*/

#define OUTPUT_BUF_SIZE 65536

size_t Output_bufferSize = OUTPUT_BUF_SIZE;

typedef struct tmp_output_struct {

  struct tmp_output_struct *next;
  supr_socket_conn_t *conn;
  pid_t pid; // R process pid
  //pid_t tid; // taskrunner thread id //
  int    start_loc; // 0: 0, 1: pos 

  size_t pos; // position
  size_t buf_size;
  unsigned char buf[0];

} tmp_output_t; // free...

tmp_output_t *tmp_output_root = NULL; 

const char *src_func;
const char *src_file;
int src_line;
void __src_info(const char *func, const char *file, int line)
{
  src_func = func;
  src_file = file;
  src_line = line;
}

void worker_info(const char *format, ...)
{
  supr_thread_t *cth = currentThread();
  if(FALSE && cth && master_conn && scToBackend ) { // lock ...
    if(cth != backendThread) {
      pthread_mutex_lock(scToBackend->mutex);
        int cmd = CLUSTER_WORKER_NULL;
        write(scToBackend->fd, &cmd, INT_SIZE);
        read(scToBackend->fd, &cmd, INT_SIZE);
    }

    pthread_mutex_lock(master_conn->mutex);

#ifdef USE_CHECKSUM

      size_t buf_size = 1024;
      char buf[buf_size];
      char *s = buf + MSG_HEADER_SIZE;
      va_list ap;
      va_start(ap, format);
      sprintf(s, "%s (%s:%d) ", src_func, src_file, src_line);
      int len = vsnprintf(s + strlen(s),
                      buf_size - MSG_HEADER_SIZE - strlen(s) - 1,
                      format, ap);
      len = strlen(s);
      s[len++] = 0;

      int master_fd = master_conn->fd;

    //{ fprintf(stderr, "%s", buf); continue; }
    //{
      uint32_t cksum_val;
      off_t    cksum_len;
      buf_size = MSG_HEADER_SIZE + len;
      int type = 2;
      int pid =  0;
      int hdr[] = {pid, type}; // fixme?
      memcpy(buf, hdr, sizeof(hdr));
      cfncn(buf, buf_size, &cksum_val, &cksum_len);

      int cmd = CLUSTER_BYTE_MSG;
      write(master_fd, &cmd, INT_SIZE);
      //fprintf(stderr, "\033[0;31m***** buf_size: %ld, s: %s\n", buf_size, s);
      write(master_fd, &buf_size, SIZE_SIZE);
      write(master_fd, buf, buf_size);
      //fprintf(stderr, "***** cksum_val: %d\033[0m\n", cksum_val);
      write(master_fd, &cksum_val, sizeof(uint32_t));
      /*
      write(master_fd, arg_2, strlen(arg_2));
      write(master_fd, (char*) block, blksize);
      write(master_fd, (char*) &cksum_val, sizeof(uint32_t));
      */
    //}
      /*
      uint32_t m_cksum_val;
      read(master_fd, &m_cksum_val, sizeof(uint32_t));
      if(m_cksum_val != cksum_val){
	      fprintf(stderr, "Error: cksum_val: %d, m_cksum_val: %d\n",
			      cksum_val, m_cksum_val);
      }
      */


#else
      size_t buf_size = 1024;
      char buf[buf_size];
      va_list ap;
      va_start(ap, format);
      sprintf(buf, "[%s_%s:%d] ", src_func, src_file, src_line);
      int n = vsnprintf(buf + strlen(buf), buf_size-strlen(buf)-1, format, ap);
      for(int i=0; i<strlen(buf); i++){
      }

      int fd = master_conn->fd;
      int byte_msg = CLUSTER_BYTE_MSG;
      write(fd, &byte_msg, INT_SIZE);
      pid_t pid = 0;
      write(fd, &pid, INT_SIZE);
      int type = 1;
      write(fd, &type, INT_SIZE);
      n = strlen(buf);
      buf[n++] = 0;
      //fprintf(stderr,"%s", buf);
      write(fd, &n, INT_SIZE);
      write(fd, &buf, n);

#endif

    pthread_mutex_unlock(master_conn->mutex);

    if(cth != backendThread) {
        int cmd = CLUSTER_WORKER_NULL;
        write(scToBackend->fd, &cmd, INT_SIZE);
      pthread_mutex_unlock(scToBackend->mutex);
    }


  } // else {

    if(Supr_verbose == FALSE) return;

    fprintf(stdout, "%s %s:%d", src_func, src_file, src_line);
    va_list ap;
    cth = currentThread();
    if(cth) fprintf(stdout, " %d.%d ", cth->pid, cth->tid);
    va_start(ap, format);
    vprintf(format, ap);

    fflush(stdout);
  //}
}

extern vector_t *socket_connections;
extern vector_t *threads;
vector_t *tr_threads;

void shutdown_killTaskrunners();

void handleShutdown(supr_socket_conn_t *conn)
{
  fprintf(stderr, "%d. %s\n", __LINE__, Supr_curErrorBuf);
  verbose_info(Supr_curErrorBuf);

  shutdown_killTaskrunners();
	/*
	int msg[] = {CLUSTER_SHUTDOWN, TRUE};
	int rc;

//	   if(msg[1]) { // all = TRUE => kill master and dfs_name?
             for(int i=vectorSize(socket_connections)-1; i>=0; i--){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
		       vectorElementAt(socket_connections, i);
	       if(   sc->type == DFS_NAMENODE_CONN 
	          || sc->type == MASTER_CONN ){

		  if(sc->type == MASTER_CONN) master_conn = NULL;

                  ssize_t size = write(sc->fd, msg, sizeof(msg));
		  shutdown(sc->fd, SHUT_WR); 
                  size = read(sc->fd, &rc, INT_SIZE); //?
	          printf("shutdown read response size: %ld, rc:%d\n", size, rc);
		  close(sc->fd);
		  vectorRemove(socket_connections, i);
	       } else if(   sc->type == USER_INFO){
		  shutdown(sc->fd, SHUT_WR);
		  close(sc->fd);
		  vectorRemove(socket_connections, i);
	       }
	     }
	   //}

//	   rc = 0;
//	   write(fd, &rc, INT_SIZE);
*/

// FIXME...           system_exit(CLUSTER_SHUTDOWN);

  
	  char msg[1024];


  if(Supr_curStrError){
    char *err = malloc(strlen(Supr_curStrError) + strlen(__func__)
		    + strlen("<-")+1);
    sprintf(err, "%s<-%s", __func__, Supr_curStrError);
    Supr_curStrError = err;
  } else {
    Supr_curStrError = (char*)  __func__;
  }
  // wait for threads that are using info_sc ?
  pthread_mutex_lock(&Supr_syncMutex);
    if(info_sc){
      close(info_sc->fd);
      info_sc = NULL;
    }
    if(parent_sc){
      close(parent_sc->fd);
      parent_sc = NULL;
    }
  pthread_mutex_unlock(&Supr_syncMutex);


  // 1. Close connections


  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(socket_connections, i);
    close(sc->fd); // Supr_decref???
    free(sc);
  }

  // 2. Cancel pthreads
  supr_thread_t *cth = pthread_getspecific(currentThreadKey);

  for(int i=vectorSize(threads)-1; i>=0; i--){
    supr_thread_t *th = vectorElementAt(threads, i);
    if(th != cth){
      int locked = !pthread_mutex_trylock(&th->mutex);
      if(locked){
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d, state: %s)", th->tid, th->pid, state2char(th->state));
      }else {
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d)", th->tid, th->pid);
      }
      fprintf(stderr, "%s\n", msg);

      int rc = pthread_cancel(th->ptid);
      if(locked){
        pthread_mutex_unlock(&th->mutex);
      }
      /*
      if(rc == 0){
	void *retval;
        int rc = pthread_join(th->ptid, &retval);
	if(retval == PTHREAD_CANCELED){
          fprintf(stderr, " pthread_join(%d, ...): PTHREAD_CANCELED\n",
			  th->tid);
	} else {
          fprintf(stderr, " pthread_join(%d, ...): %p\n",
			  th->tid, retval);
	}
      }
      */
    }
  }


//  pthread_mutex_unlock(&Supr_syncMutex);
  int rc = pthread_cancel(cth->ptid);
  //pthread_exit(NULL); //??

  
}

int X11_pid = 0;

/*
void supr_src(const char* func, const char* file, int line)
{
  if(Supr_verbose == FALSE) return;
  printf("(%s:%s:%d) ", func, file, line);
}
*/

#define printf __src_info(__func__, __FILE__, __LINE__); worker_info

struct sigaction R_oldSegvAct;
struct sigaction R_segvAct;

void  Worker_SigactionSegv(int sig, siginfo_t *ip, void *context);
void Worker_sigaction()
{
    R_segvAct.sa_sigaction = Worker_SigactionSegv;
    sigemptyset(&R_segvAct.sa_mask);
    R_segvAct.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &R_segvAct, &R_oldSegvAct);
}



extern void SocketConn_closeAll(vector_t *conns, int do_shutdown);


int Taskrunner_useWindow = FALSE;
char *Worker_dir = NULL;

extern supr_xterm_t *supr_xterm3(const char *name, char **args, int new_window);


supr_socket_conn_t *workerServerConn = NULL;
supr_socket_conn_t *driverServerConn = NULL;

typedef struct {
  class_t *class;
  int ref_count;
  int padding;
  pthread_mutex_t lock;
  void (*dealloc)(void *); // for free elements of val
  void *val[1]; // NULL terminated array
} share_t;

void Share_finalize(class_t *class, void *object)
{
	printf("\033[0;32mFREE\033[0m\n");

  share_t *s = (share_t *) object;
  pthread_mutex_destroy(&s->lock);
  if(s->dealloc)
	  for(int i=0; s->val[i]; i++)
	  {
//fprintf(stderr, "\033[0;32mFREE, i: %d, ptr: %p\n\tdealloc: %p, free: %p, __supr_free__: %p\033[0m\n", i, s->val[i], s->dealloc, free, __supr_free__);
	     s->dealloc(s->val[i]);
	  }
  free(s);
}

const char *Share_toString(class_t *class, void *object)
{
  return "Shared object"; // TODO
}

class_t __share_class = {"Share", Share_toString, Share_finalize};
class_t *Share_class = &__share_class;

share_t *Share_new(int nval, void **values, void (*dealloc)(void *))
{
  share_t *s = (share_t *) malloc(sizeof(share_t) + (nval+1)*sizeof(void*));
  s->class = Share_class;
  s->ref_count = REF_COUNT_INITIALIZER;
  s->dealloc = dealloc;
  pthread_mutex_init(&s->lock, NULL);
  s->val[nval] = NULL;
  if(values){
    for(int i=0; i< nval; i++) s->val[i] = values[i];
  } else {
    for(int i=0; i< nval; i++) s->val[i] = NULL;
  }
  return s;
}

void Cond_notify(const char *mutex, int tid, share_t *s);

typedef struct __malloc_obj_struct {
  size_t size;
  int ref_count;
#ifdef DEBUG_GC
  int src_line; // delete me
  char *src_file;
#else
  int padding;
#endif
} __malloc_obj_t;


#ifdef DEBUG_GC
#endif
typedef struct malloc_debug_struct {
  void *ptr; //
  void *malloc_ptr;
  struct malloc_debug_struct *next;
} malloc_debug_t;

malloc_debug_t malloc_bebug_root_struct = {NULL, NULL, NULL};
malloc_debug_t *malloc_bebug_root = &malloc_bebug_root_struct;

malloc_debug_t *malloc_bebug_add(malloc_debug_t *m)
{
  m->next = malloc_bebug_root->next;
  return malloc_bebug_root->next = m;
}


/*
void *__malloc__(size_t size, char *src_file, int src_line)
{
  printf("\033[0;36m[%s]\033[0m] %s:%d\n", __func__, src_file, src_line);
  __malloc_obj_t *p = (__malloc_obj_t *) malloc(sizeof(__malloc_obj_t)+size);

  p->size = size;
  p->ref_count = 1;
#ifdef DEBUG_GC
  p->src_line = src_line;
  p->src_file = src_file;
#endif
  return p+1;
}


// man 3 free

void __free__(__malloc_obj_t *p)
{
  fprintf(stderr, "\033[0;36m[%s] %s:%d\033[0m]\n", __func__,
		  p->src_file, p->src_line);
//  __malloc_obj_t *p = (__malloc_obj_t *) ( (long) ptr - sizeof(__malloc_obj_t)); 
  free(p);
}
*/


//void __malloc_obj__(class_t *class){}

int __decrease_ref__(void *ptr)
{
	/*
  __malloc_obj_t *p = (__malloc_obj_t *) ptr;
  p->ref_count--;
  if(p->ref_count == 0) 
   __free__(p);
   */
  return 0;
}

#define USE_SUPR_MALLOC
#ifdef  USE_SUPR_MALLOC

//#define malloc(size) __malloc__((size), __FILE__, __LINE__)
//#define free(ptr) __free__(ptr)
#endif

//pthread_key_t currentThreadKey;

hashtable_t *syncEnvironment = NULL;
hashtable_t *waitEnvironment = NULL;
hashtable_t *countdownEnvironment = NULL;

typedef struct executor_property_struct {
  supr_socket_conn_t *sc2worker;
  supr_socket_conn_t *sc2driver;
  vector_t *taskrunners;
} executor_property_t;

vector_t *executors = NULL;

vector_t *jobs = NULL; // new_jobs???
vector_t *cancelled_jobs = NULL;
vector_t *all_jobs = NULL;

int UID = 0;
void *PTHREAD_INTERRUPTED = NULL;
void *PTHREAD_TIMEOUT = NULL;
void *PTHREAD_SYNCHRONIZED = NULL;
void *PTHREAD_NOTIFIED = NULL;
void *JOB_CANCELLED = NULL;

typedef struct {
  int type;
  int padding; // not used ...
  void *data;
} thread_info_t;

#define INTERRUPT 1     // {type, (char*) cause?}
#define NEW_JOB   2	// {type, job}
#define SHUTDOWN  3	// {type, job}
#define SET_NTRS  4	// {type, job}
#define CONNECT_DRIVER  5
#define SIGNAL_RCVD 6

// info used for combine_bykey
typedef struct cbk_struct {
  pthread_cond_t cond;
  hashtable_t *shm_names;
  char **keys;
  int nkeys;
  int count;
} cbk_t;

void cbk_finalize(cbk_t *cbk)
{
  pthread_cond_destroy(&cbk->cond);

  if(cbk->shm_names) {
    fprintf(stderr, "[%s] cbk->shm_names->ref_count: %d\n", __func__,
		    cbk->shm_names->ref_count);
    Supr_decref(cbk->shm_names);
  }
  if(cbk->keys)
    free(cbk->keys); 
  free(cbk);
}

typedef struct w_job_struct {
  class_t *class;
  int ref_count;
  int padding; // reserved ?

  int id;
  int count;  // or for padding
  void *expr; // (serialized R expression for taskrunners
  SEXP env;   // for driver and workers?

//  iterator_t *tasks; // implemented as subsets
  char *result; // for combine
//  void *future;

  pthread_mutex_t mutex;

  vector_t *taskrunners;
  vector_t *executors; // or workers, identified by socket address
  // data change listeners ...
  // vector_t assigned tasks
  supr_socket_conn_t *sc; // socket connection to driver;
  supr_socket_conn_t *sc2worker; // socket connection to worker;
  broadcast_lock_t *bc;

  int stage;
  int cancelled;
  cbk_t *cbk;

  void *info; // GC only?
//  int status;

} w_job_t;

//(cost)
const char *workerJobToString(class_t *class, void *object);

/*
typedef struct object_struct {
  class_t *class;
} object_t;
*/

class_t *WorkerJob_class = NULL;

void workerJobFinalize(class_t *class, void *object)
{
  w_job_t *job = (w_job_t *) object;

  if(Supr_options.verbose) {
    char msg[256];
    sprintf(msg, "job_id: %d", job->id); 
    verbose_info(msg);
  }

  if(job->cbk) {
	  cbk_finalize(job->cbk);
	  //job->cbk = NULL;
  }

  free(job->expr);
  pthread_mutex_destroy(&job->mutex);
  //fprintf(stderr, "[%s] TODO ... %s:%d\n", __func__, __FILE__, __LINE__);
  Supr_decref(job->taskrunners);
  Supr_decref(job->executors);
  Supr_decref(job->sc);
  Supr_decref(job->sc2worker);

  broadcast_lock_destroy_W(job->bc);

  free(job->info);

  free(job);

  //fprintf(stderr, "[%s] Done!\033[0m\n", __func__);
  //pthread_mutex_lock(jobs->mutex);
  if(Supr_options.verbose) {
    char msg[256];
    sprintf(msg, "njobs: %d", vectorSize(jobs));
    verbose_info(msg);
    for(int i=0; i<vectorSize(jobs); i++){
      w_job_t *job = (w_job_t *)vectorElementAt(jobs, i);
      sprintf(msg, "%d. job: %d", i+1, job->id);
      verbose_info(msg);
    }
  }
  //pthread_mutex_unlock(jobs->mutex);
}

w_job_t *newWorkerJob(int job_id, void *expr)
{

  static class_t *class = NULL;
  if(!class){
    class = newClass("WorkerJob", workerJobToString, workerJobFinalize);
//    printf("[%s] class = %p\n", __func__, class);
//    printf("[%s] class->name = %s\n", __func__, class->name);
    WorkerJob_class = class;
  }

  w_job_t *job = (w_job_t *)malloc(sizeof(w_job_t));
  job->class = class;
  job->ref_count = REF_COUNT_INITIALIZER;
  job->padding = 0;

  job->id    = job_id;
  job->count = 0;
  job->expr  = expr;
  job->env   = R_NilValue;
//  job->tasks = tasks;
  job->result= NULL;
//  job->future= NULL;
  job->taskrunners = newVector(FALSE); // registered trs
  job->executors   = newVector(FALSE);
  job->stage = 0;

  job->cbk = NULL;

  job->info = NULL;

  //vectorAdd(jobs, job);

  //job->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(&job->mutex, NULL);

  job->sc = NULL;
  if(driverServerConn) { // error
    job->sc = socketOpen(driverServerConn);
    if(job->sc){ // register as a job conn?
      //char msg[256];
      //sprintf(msg, "job2driver_sc: %s:%d, fd: %d", job->sc->host, job->sc->port, job->sc->fd);
      //basic_info(msg);

      job->sc->mutex = malloc(sizeof(pthread_mutex_t));
      pthread_mutex_init(job->sc->mutex, NULL);
    } // else : error
  }

  job->sc2worker = NULL;
  if(workerServerConn) { // error
    job->sc2worker = socketOpen(workerServerConn);
    if(job->sc2worker){ // register as a job conn?
      //char msg[256];
      //sprintf(msg, "job2driver_sc: %s:%d, fd: %d", job->sc2worker->host, job->sc2worker->port, job->sc2worker->fd);
      //basic_info(msg);

      job->sc2worker->mutex = malloc(sizeof(pthread_mutex_t));
      pthread_mutex_init(job->sc2worker->mutex, NULL);
    } // else : error
  }

  job->bc = broadcast_lock_create(job->id);
//  __job__ = job;
//  __job_id__ = job->id;

  job->cancelled = FALSE;

  return job;
}

/*
void destroyWorkerJob(w_job_t *job)
{
  fprintf(stderr, "[%s] job->ref_count: %d\n", __func__,
		  ((object_t *)job)->ref_count);
  Supr_decref(job);
}
*/

const char *workerJobToString(class_t *class, void *object)
{
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(256);

  sb->size = 0;
  strbufPutStr(sb, "(");
  strbufPutStr(sb, class->name);
  strbufPutStr(sb, ") ");
  char buf[256];
  sprintf(buf, "%p [job_id = %d]", object, ((w_job_t *)object)->id); 
  strbufPutStr(sb, buf);
  return sb->buf;
}

typedef struct {
  w_job_t *job;
  shm_io_info_t *io;
  pid_t   R_pid;  
  int     isInterrupted;
  int killed; // SIG_NUMBER
  int tr_id;
  int last_cmd;
  int mutex_info[4];
  // ...
} taskrunner_env_t;

#define JOBS_MUTEX 0
#define JOB_MUTEX 1
#define DRIVER_MUTEX 2
#define WORKER_MUTEX 3

#define JOB_MUTEX_LOCK 1
#define JOB_MUTEX_SET 2
#define JOB_MUTEX_UNSET 0

#define LOCK_MUTEX(idx)	thread_env->mutex_info[idx] = JOB_MUTEX_LOCK
#define SET_MUTEX(idx)	thread_env->mutex_info[idx] = JOB_MUTEX_SET
#define UNSET_MUTEX(idx)	thread_env->mutex_info[idx] = JOB_MUTEX_UNSET

//pthread_key_t taskrunnerThreadKey;


extern char *SUPR_HOMEUSR;
extern char *SUPR_HOMESYS;
extern void suprHomeInit();

extern SEXP R_simpleTryEval(SEXP expr, SEXP env, int *errorOccurred);
extern SEXP R_simpleTryEval4(SEXP(*func)(SEXP args), SEXP args, SEXP env,
	       	int *errorOccurred);

/*
#define BEGIN_R_EVAL()     do      {       \
  pthread_mutex_lock(&main_thread->mutex);	\
  void *dummy; 	\
  int __save_R_CStackStart__ = R_CStackStart;	\
  R_CStackStart = (unsigned long) &dummy

#define END_R_EVAL()   \
  R_CStackStart = __save_R_CStackStart__;	\
  pthread_mutex_unlock(&main_thread->mutex);	\
} while(0)
*/


char *dupstr(const char *str)
{
  return memcpy(malloc(strlen(str)+1), str, strlen(str)+1);
}

//extern SEXP R_CStackStart;
extern unsigned long R_CStackStart;
extern unsigned long R_CStackLimit;
extern int R_Interactive;
extern void run_Rmainloop(void);

extern void myR_SigactionSegv(int sig, siginfo_t *ip, void *context);
extern void c_backtrace();



static shm_io_info_t *__io__ = NULL;

extern vector_t *cleanups;
extern void doCleanups();

int system_exit(int n)
{
  // cleanups later...
	/*
  if(cleanups){
    for(int i=vectorSize(cleanups)-1; i>=0; i--){
      do_t *cleanup = (do_t *) vectorElementAt(cleanups, i);
      printf("[%s] do_cleanup %p\n", __func__, cleanup);
      cleanup->_do_(cleanup->data);
    }
  }
  */
	/*
  tmp_output_t *out = tmp_output_root; 
  while(out){
    unlink(out->file_name);
    out = out->next;
  }
  */

  for(int i=0; i<vectorSize(executors); i++){
     supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
     printf("[%s] thread_state: %d\n", __func__, th->state);
     pthread_mutex_lock(&th->mutex);
     thread_info_t *info = (thread_info_t *)
                       malloc(sizeof(thread_info_t)); // free?
      info->type = SHUTDOWN; // INTERRUPT;
      info->data = NULL; //job;
               //th->data = PTHREAD_INTERRUPTED;
       th->data = info;
       pthread_cond_signal(&th->cond);
     pthread_mutex_unlock(&th->mutex);
  }
  //
  sleep(2);


  printf("%s: terminating ...\n", Supr_hostname);

  doCleanups();

  int status;
  //pid_t pid = waitpid(-1, &status, 0);
  pid_t pid;
  /*
  for(;;){
    errno = 0;
    pid = waitpid(-1, &status, WNOHANG);
    printf("\033[0;35mwaitpid: %d, info: %s\033[0m\n", pid, strerror(errno));
    if(pid == -1) break;
  }
  */

  //sleep(5);
  {
    pid_t ppid = getppid();
    char path[PATH_MAX];
    sprintf(path, "/proc/%d/cmdline", ppid);
    FILE *cmdline = fopen(path, "r");
    int c, p = 1;
    size_t n = 0;
    path[PATH_MAX-1] = 0;
    while(n < PATH_MAX-1) { 
      c = fgetc(cmdline);
      if(c==-1) { 
          path[n++] = 0;
	  break;
      } else if(c==0) { 
	if(p==0){
          path[n++] = 0;
	  break;
	} else 
          path[n++] = ' ';
      } else 
        path[n++] = c;
      p = c;
    }
    //path[n] = 0;
    fclose(cmdline);
    printf("\033[0;35mppid: %d, cmd: %s\033[0m\n", ppid, path);

    if(strstr(path, "--window")) {
      int rc =  kill(ppid, SIGINT);
      printf("\033[0;35mkill: %d\033[0m\n", rc);
      rc =  kill(ppid, SIGKILL);
      printf("\033[0;35mkill: %d\033[0m\n", rc);
      rc =  kill(ppid, 0);
      printf("\033[0;35mkill: %d\033[0m\n", rc);
    }

    if(X11_pid){
      //int rc =  kill(X11_pid, SIGINT);
      //int rc =  kill(X11_pid, SIGKILL);
      //int cmd = 0;
      //int rc = write(X11_pid, &cmd, INT_SIZE); // FIXME
      //printf("\033[0;35mkill: %d\033[0m\n", rc);
    }
  }
  exit(n);
}

 

int isDCLInterrupted = FALSE;
int isDisconnected = FALSE;

size_t __dcl_read__(int fd, void *ptr, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /* else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(listenfd, &readfds) = %d\n", __func__,
               FD_ISSET(fd, &readfds));
      } */
    }

    int n = read(fd, ptr + len,  size - len);
    //printf("[%s] isDCLInterrupted = %d n = %d\n", __func__, isDCLInterrupted, n);
    if(isDCLInterrupted) {
//      isDCLInterrupted = FALSE;
    //  return -1;
	    // clean...???
      errorcall(R_NilValue, "interrupted");
    } else if(n == -1) {
      errorcall(R_NilValue, "SIGPIPE?");
    } else if(n == 0) {
      printf("[%s] disconnected\n", __func__);
      isDisconnected = TRUE;
      errorcall(R_NilValue, "disconnected");
    }
    //if(n == -1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  return len;
}

// testing
//extern size_t (*__read__)(int, void *, size_t);


#include <readline/readline.h>
#include <readline/history.h>

 
void  myR_SigactionDCLInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  //c_backtrace();

  //if(isDCLInterrupted) exit(1);
  fprintf(stderr, "\033[0;31m[%s] FIXME: EXIT (%s, %d)\033[0m\n", __func__,
           __FILE__, __LINE__);
//  exit(1);

//  char *line = readline (">>> ");
//  printf("%s\n", line);
//  int c;
//  read(3, &c, 1);


  isDCLInterrupted = TRUE;

  if(FALSE && __io__){
    int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
    shm_io_write(__io__, __io__->out, array, sizeof(array));
  }
//  errorcall(R_NilValue, "segmentation fault"); //??? FIXME
//  exit(1); // not good...

  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);

}

//int isTaskrunnerInterrupted = FALSE;

//extern int isInterrupted;

char interrupt_message_buf[256];

/*
void  myR_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
  //c_backtrace();

  isTaskrunnerInterrupted = TRUE;
  isInterrupted = TRUE;


  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);
  //sigaction(SIGINT, &R_oldactInt, NULL);

  //errorcall(R_NilValue, msg); //??? FIXME
  //exit(1);
}
*/

/*
typedef struct tr_cntxt_struct {
  shm_io_info_t *io;
  int job_id;
  int tr_id;
  pid_t pid;
} tr_cntxt_t;

tr_cntxt_t tr_cntxt = {NULL, -1, -1, 0};
*/
extern tr_cntxt_t tr_cntxt;

char *cntxt2str(){
  char *s = malloc(256);
  sprintf(s, "\033[0;32mpid=%d, job_id=%d, tr_id=%d, %s\033[0m",
		  tr_cntxt.pid,  tr_cntxt.job_id,
		  tr_cntxt.tr_id, tr_cntxt.io->shm_info.shm_name);
  return s;
}

void  (*myTryEval_SigactionInt)(int sig, siginfo_t *ip, void *context) =NULL;

extern void sendDriverMessage(shm_io_info_t *io, int job_id, int tr_id, const char *msg);
extern void rjni_io_err_write(shm_io_info_t *io, const char *msg);

#define  BACKTRACE_SIZE 256
#include <execinfo.h>

char *myC_backtrace()
{
  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  size = backtrace(array, BACKTRACE_SIZE);
  strings = backtrace_symbols(array, size);

  int length = 0;
  for (i = 0; i < size; i++) //fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    length += strlen(strings[i]) + 1;
  
  char *str = (char*)malloc(length);
  char *s = str;
  for (i = 0; i < size; i++){
    memcpy(s, strings[i], strlen(strings[i]));
    s += strlen(strings[i]);
    *s = i== (size-1) ? 0 : '\n';
    s++;
  }

  free(strings);
  
  return str;
}

extern void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write);

char *myR_simpleTraceback();
//extern int isInterrupted;


/*
void  myR_SigactionTaskRunnerUsr2(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n",
		  __func__, pthread_self());
  //c_backtrace();

  isInterrupted = TRUE;

  int rc = sem_trywait(&__io__->err->sem_wr);
  fprintf(stderr, "\033[0;31m[%s] sem_trywait : %d\033[0m\n", __func__, rc);
  char *msg = "interrupted";
  if(rc == 0){
    msg = (char*) (__io__->err+1);
    msg[__io__->err->data_size-1] = 0;
    fprintf(stderr, "\033[0;31m[%s] message = %s\033[0m\n", __func__, msg);
    __io__->err->data_size = 0;
    sem_post(&__io__->err->sem_wr);
  }
  if(strlen(msg)==0) msg = "interrupted";
  int size = strlen(msg);
  if(sizeof(interrupt_message_buf)-1 < size)
	  size = sizeof(interrupt_message_buf)-1;
  memcpy(interrupt_message_buf, msg, size);
  interrupt_message_buf[size] = 0;

  
  kill(getpid(), SIGINT);

}
*/


/*
void  myTryEval_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n",
		  __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  c_backtrace();

  int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
  shm_io_write(__io__, __io__->out, array, sizeof(array));

  exit(1);
}
*/





/*
typedef struct shm_struct {
  size_t size;
  sem_t sem_w; // by java thread
  sem_t sem_r; // by java thread
} shm_struct_t;

typedef struct _shm_info {
  char *shm_name;
  void *mem_ptr;
} shm_info_t;
*/

//JNIEXPORT jlong JNICALL Java_RJNI_shmOpen (JNIEnv *javaEnv, jobject thisObj, jstring jshm_name)

/*
shm_info_t *shmOpen(const char *cshm_name) {
//  const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv, jshm_name, NULL);
  printf("[%s] cshm_name: %s\n", __func__, cshm_name);
  shm_info_t *shm_ptr = malloc(sizeof(shm_struct_t));

  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  size_t segment_size = sysconf(_SC_PAGE_SIZE);

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  close(fd);
  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);
//  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);

  shm_ptr->mem_ptr = mem_ptr;

  shm_struct_t * ssp = (shm_struct_t *)mem_ptr;
  ssp->size = segment_size;
  //sem_init(&ssp->sem_w, 1, 0);
  //sem_init(&ssp->sem_r, 1, 0);
  //sem_wait(&ssp->sem_w); sem_wait(&ssp->sem_r);
  int val;
  sem_getvalue(&ssp->sem_w, &val);
  printf("[%s] sem_getvalue(&ssp->sem_w, &val): %d\n", __func__, val);
  sem_getvalue(&ssp->sem_r, &val);
  printf("[%s] sem_getvalue(&ssp->sem_r, &val): %d\n", __func__, val);

  return shm_ptr;
}
*/

typedef void (*sighandler_t)(int);

//this worked 
void myTryEval_SIGINT_handler(int sig){
  fprintf(stderr, "[%s] is called on %d\n", __func__, getpid()); 
  fprintf(stdout, "[%s] is called on %d\n", __func__, getpid()); 
}

//extern char *__r2str(SEXP x, char *buf, int buf_size, int debug);
char *__r2str(SEXP x, char *buf, int buf_size, int debug)
{ 
       	return NULL;
}

char *sexp2char(SEXP x)
{
   int buf_size = 128*200;
   char buf[buf_size];
   //char *s = __r2str(x, buf, buf_size, 0);
   char *s = __r2str(x, buf, buf_size, 0);
   char *c = malloc(strlen(s)+1);
   memcpy(c, s, strlen(s)+1);
   return c;
}

char *myR_simpleTraceback()
{
  RCNTXT *cntxt = R_GlobalContext;
  int len  = 0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    len += strlen(c)+1+1+32;
    fprintf(stderr, "cntxt = %p: %s\n", cntxt, c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  char *str = malloc(len);
  char *s = str;
  cntxt = R_GlobalContext;
  int i=0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    if(i){ *s ='\n'; s++;}

    char b[16];
    sprintf(b, "%d: ", i++);
    memcpy(s, b, strlen(b));
    s += strlen(b);

    memcpy(s, c, strlen(c));
    s += strlen(c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  *s = 0;
  return str;
}


//extern int R_PPStackTop
//extern const char *R_curErrorBuf();
SEXP R_myTryEval(SEXP expr, SEXP env, int *errorOccurred)
{
#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue
//#define SETJMP(x) setjmp(x)

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  } 


#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));


  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      val = eval(expr, env);
      UNPROTECT(1);

    } else {

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  //UNPROTECT(1);

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n", 
		    __FILE__, __LINE__, save, R_PPStackTop);
  }

  return val;



//#undef SETJMP(x) 
#undef null
#undef R_ToplevelContext
}

extern int R_SignalHandlers;
void testing(int argc, char **argv){

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    //printf("R_CStackStart = %ld\n", R_CStackStart);
    //printf("R_CStackLimit = %ld\n", R_CStackLimit);
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();
  }

 
  /*
  {
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));

    int errorOccurred;
    printf("OKAY??\n");
    SEXP value = R_myTryEval(expr, R_GlobalEnv, &errorOccurred);
    printf("OKAY\n");
  }


  RCNTXT *__R_ToplevelContext  = R_GlobalContext;
  while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;

  printf("R_ToplevelContext>handlerstack:\n");
  PrintValue(__R_ToplevelContext->handlerstack);

#define R_ToplevelContext __R_ToplevelContext

  printf("R_ToplevelContext = %p\n", R_ToplevelContext);
  printf("R_GlobalContext   = %p\n", R_GlobalContext);
  printf("R_SignalHandlers   = %d\n", R_SignalHandlers);
  */
  //SETJMP(R_Toplevel.cjmpbuf);
/*
Defn.h:# define SIGSETJMP(x,s) sigsetjmp(x,s)
Defn.h:# define SETJMP(x) sigsetjmp(x,0)
Defn.h:# define SIGSETJMP(x,s) setjmp(x)
Defn.h:# define SETJMP(x) setjmp(x)
*/
//# define SETJMP(x) setjmp(x)
//  SETJMP(R_ToplevelContext->cjmpbuf);

  /*
  SETJMP(R_Toplevel.cjmpbuf);
    R_GlobalContext = R_ToplevelContext = R_SessionContext = &R_Toplevel;
    */
#define null R_NilValue
  /*
  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
  SEXP env = R_GlobalEnv;



  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

//  int count = 0;

  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

//    int succeeded = FALSE;
    if(!setjmp(R_ToplevelContext->cjmpbuf))
    //if(!setjmp(cntxt.cjmpbuf))
    {
      PrintValue(syscall);
   //   count++; if(count ==5) exit(1);
      printf("\033[0;31m%s: PrintValue\033[0m\n", __func__);
      val = PROTECT(eval(expr, env));
//      succeeded = TRUE;
    } else {
      val = PROTECT(mkString("pthread_error")); // to do
      setAttrib(val, install("class"), mkString("pthread_error"));
      PrintValue(val);
      printf("\033[0;35m%s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

  endcontext(&cntxt);
  */

  //exit(1);


  while(TRUE){

	  /*
    RCNTXT cntxt;
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
    SEXP env = R_GlobalEnv;
    SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

    begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    if(!setjmp(R_ToplevelContext->cjmpbuf))
    {
    */
        int errorOccurred;
        SEXP envir = R_GlobalEnv;
        SEXP expr = PROTECT(LCONS(install("stop"),
			    CONS(mkString("ERROR: TESTING"), R_NilValue)));
        SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(R_tryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(eval(expr, envir));
	printf("errorOccurred = %d\n", errorOccurred);
	if(errorOccurred)
	  fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
	else
          PrintValue(res);

	/*
    } else {
      printf("\033[0;35m[Error] %s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

    endcontext(&cntxt);
#undef null
*/

    //sleep(10);
  }

  //if(R_Interactive) run_Rmainloop();

  exit(1);
}

/*
typedef struct shm_data_header {
  int type;
  int padding;
  size_t size;
} shm_data_header_t;
*/
// Cluster.java:
#define TASK_RESULTS 303
#define TASK_EXIT    304

int  tr_get_shm_identityCode()
{
  static int code = 0;
  fprintf(stderr, "code = %d\n", code); 
  return code++;
}

static size_t __page_size__ = 0;
#define SHM_BLOCK_SIZE (2*__page_size__)

static socket_conn_t *__socket_conn__ = NULL;

extern SEXP SUPR_socketConnect(SEXP hostname, SEXP port, SEXP endian_str); 
extern SEXP SUPR_socketWrite(SEXP conn, SEXP x, SEXP endian_str);
extern SEXP SUPR_socketRead(SEXP conn, SEXP what, SEXP _n, SEXP endian_str); 
extern SEXP SUPR_socketReadObject(SEXP conn, SEXP env); 
extern SEXP SUPR_socketClose(SEXP conn); 
extern SEXP socketReadDCLEvent(SEXP socket_conn, SEXP env);

/*
void  dcl_error(const char *driver_host, int driver_port, int job_id,
	       	const char *msg, SEXP env)
{
  printf("%s: driver_host=%s\n", __func__, driver_host);
  printf("%s: driver_port=%d\n", __func__, driver_port);
  printf("%s: msg=%s\n", __func__, msg);

  SEXP host   = PROTECT(mkString(driver_host));
  SEXP port   = PROTECT(ScalarInteger(driver_port));
  SEXP endian = PROTECT(mkString("big"));
  SEXP conn   = PROTECT(SUPR_socketConnect(host, port, endian)); 

  SEXP x  = PROTECT(ScalarInteger(DCL_JOB_ERROR));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(ScalarInteger(job_id));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(mkString(msg));
  SUPR_socketWrite(conn, x, R_NilValue);

  SEXP ret  = SUPR_socketReadObject(conn, env); 
  UNPROTECT(7);


  printf("[%s] return\n", __func__);
  PrintValue(ret);

}
*/


/*
typedef struct sync_info_struct {
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  void (*run)(void *data);
  void *data;
  sem_t           sem_wait;
  sem_t           sem_notify;
} sync_info_t;
*/


// ?? void *rjni_shm_open(const char *cshm_name, size_t *size);
extern void *rjni_shm_open(const char *cshm_name, size_t *size);
extern void *supr_shm_open(const char *cshm_name, size_t *size);
extern int supr_shm_exists(const char *cshm_name);

// argv[0] -DCL -port port -shm shm_name -name name
/*
int data_change_listener(int argc, char **argv)
{
  // parse args

  const char *driver_host = "localhost";
  int driver_port = 0;
  const char *shm_name = NULL;

  const char *dcl_name = "default";

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-port")==0 && i+1 < argc) {
      driver_port = atoi(argv[i+1]);
      i++;
    } else if(strcmp(argv[i], "-shm")==0 && i+1 < argc) {
      shm_name = argv[i+1];
      i++;
    } else if(strcmp(argv[i], "-name")==0 && i+1 < argc) {
      dcl_name = argv[i+1];
      i++;
    }
  }

  if(!driver_port){ // FIXME
    char *driver_log_file = "DriverDir/Driver.log";
    int fd = open(driver_log_file, O_RDONLY, 0600);
    if(fd != -1){
      struct stat statbuf;
      int rc = fstat(fd, &statbuf);
      if(rc == -1) {
        printf("[%s] Error (%s, %d): %s\n", __func__, __FILE__, __LINE__, strerror(errno));
      }
      size_t size = statbuf.st_size; // printf("%s: size=%ld\n", driver_log_file, size);
      char buf[size+1];
      read(fd, buf, size);
      close(fd); // printf("%s: %s\n", driver_log_file, buf);
      char *str = strstr(buf, ":");
      *str = 0;

      str++; // printf("%s: \"%s\"\n", driver_log_file, str);
      driver_port = atoi(str);

      driver_host = dupstr(buf+2);
      printf("%s: driver_host=%s\n", driver_log_file, driver_host);
      printf("%s: driver_port=%d\n", driver_log_file, driver_port);

    } else {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      exit(1);
    }
  }

  shm_io_info_t *io = NULL;

  tr_cntxt.io = io;
  tr_cntxt.pid = getpid();

  // initialize R
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);
  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE; 
    setup_Rmainloop();
  }

  myTryEval_SigactionInt = myR_SigactionDCLInt;

  // add/change signal handler
#ifdef __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sa.sa_sigaction = myR_SigactionDCLInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
  }
#endif

  __read__ = __dcl_read__;

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }

  SEXP res = R_NilValue;

  {
    SEXP call = PROTECT(LCONS(install("source"),
                            CONS(mkString("jR.R"), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);

    //printf("\033[0;32m\n\n[%s] OKAY 00\n\n\033[0m", __func__);
  }

  SEXP socket_conn = R_NilValue;
  SEXP env = R_GlobalEnv;

  if(driver_port) {
    SEXP host = PROTECT(mkString(driver_host));
    SEXP port = PROTECT(ScalarInteger(driver_port));
    SEXP endian = PROTECT(mkString("big"));
    socket_conn = PROTECT(SUPR_socketConnect(host, port, endian));
    __socket_conn__ = R_ExternalPtrAddr(socket_conn);
    //printf("[%s] socket fd = %d\n\n", __func__, __socket_conn__->fd);
 
    defineVar(install("socket.conn"), socket_conn, R_GlobalEnv); // fixme
    UNPROTECT(4);
  }

  // # register as the default listener
#define DCL_CONN 4
  SEXP x = PROTECT(ScalarInteger(DCL_CONN));
  //printf("\033[0;33m"); PrintValue(socket_conn);
  SEXP y = SUPR_socketWrite(socket_conn, x, R_NilValue);
  //printf("[%s] y = ", __func__); PrintValue(y); printf("[%s] OKAY 01\n", __func__);

  y = SUPR_socketWrite(socket_conn, install(dcl_name), R_NilValue);
  //printf("[%s] dcl_name = %s y = ", __func__, dcl_name);
  //PrintValue(y); printf("[%s] OKAY 02\n", __func__);
  UNPROTECT(1);


  int job_id = -1;
  int tr_id = -1;
  tr_cntxt.job_id = job_id;
  tr_cntxt.tr_id =  tr_id;

  SEXP envir = env;

  defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);
  defineVar(install(TR_TR_ID), ScalarInteger(tr_id), envir);
  SEXP ioPtr = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
  defineVar(install(TR_TR_IO), ioPtr, envir);
  UNPROTECT(1);


  SEXP expr = R_NilValue;

  int X11 = TRUE;

  SEXP event = R_NilValue;


  if(shm_name){

	 
    size_t size;
    void *mem_ptr = rjni_shm_open(shm_name, &size);
    printf("5/6: [%s] shm_name = %s\n", __func__, shm_name);
    printf("5/6: [%s] size = %ld, mem_ptr = %p\n", __func__, size, mem_ptr);

    sem_t *sem_wr = (sem_t *) mem_ptr;
    pid_t pid = ((pid_t*)(sem_wr+1))[0];
    printf("[%s] pid = %d, RDriver.pid = %d\n", __func__, getpid(), pid);
    pid = getpid();
    memcpy(sem_wr + 1, &pid, sizeof(pid_t));

    sem_post(sem_wr);
    munmap(mem_ptr, size);
   
  }

  while(TRUE){

    printf("\033[0;32m\n[%d] Next Job\n\033[0m", getpid()); 
    isDCLInterrupted = FALSE;
    isDisconnected   = FALSE;

    int errorOccurred;
    
    int save = R_PPStackTop;

    fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);

    int pi_envir;
    PROTECT_WITH_INDEX(envir, &pi_envir);
    int pi;
    PROTECT_WITH_INDEX(expr, &pi);


    SEXP nextEvent = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("socketReadDCLEvent"),
	    CONS(socket_conn, CONS(envir, R_NilValue)))));

    SEXP event = PROTECT(R_myTryEval(nextEvent, envir, &errorOccurred));

    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(event, 0)));

      if(isDCLInterrupted){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
        break;
      } else if(isDisconnected){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "disconnected");
        break;
      } else {
        UNPROTECT(4);
        continue;
      }
    } else if(TYPEOF(event) == NILSXP){
        UNPROTECT(4);
	continue;
    }
    defineVar(install("event"), event, envir);
    //PrintValue(event);

    const char *event_name = CHAR(PRINTNAME(VECTOR_ELT(event, 2))); // FIXME
    //printf("\033[031m[%s] event_name = \"%s\"\n", __func__, event_name);
    if(strcmp(event_name, "new()")==0){

       SEXP event_value = VECTOR_ELT(event, 3); // FIXME
       printf("event_value:\n"); PrintValue(event_value);

       printf("expr:\n");
       expr = VECTOR_ELT(event_value, 0); // FIXME
       REPROTECT(expr, pi);
       PrintValue(expr);

       job_id = INTEGER(VECTOR_ELT(event_value, 2))[0]; // FIXME
       printf("job_id: %d\n", job_id);
       defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);

       printf("envir:\n");
       envir = VECTOR_ELT(event_value, 1); // FIXME
       //REPROTECT(envir, pi_envir);
       if(TYPEOF(envir) == NILSXP){
         envir =  allocSExp(ENVSXP);
         REPROTECT(envir, pi_envir);
       //} else if(TYPEOF(envir) == VECSXP){
       } else if(TYPEOF(envir) != ENVSXP){
         //dcl_error(driver_host, driver_port, job_id, "invalid environment variable", R_GlobalEnv);
       }
       SET_ENCLOS(envir, R_GlobalEnv);
       PrintValue(envir);

    } else {
      printf("[%s] Whoops: event_name = \"%s\"\n", __func__, event_name);
      UNPROTECT(4);
      continue;
    }
    printf("\033[0m\n");
    if(save + 4 != R_PPStackTop) {
      fprintf(stderr, "Warning: save + 4 = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save + 4, R_PPStackTop, __FILE__, __LINE__);
    }

    SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
    //printf("[%s] errorOccurred = %d\n", __func__, errorOccurred);
    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
      //dcl_error(driver_host, driver_port, job_id, CHAR(STRING_ELT(res, 0)), envir); } else 
      PrintValue(res);

    
    if(isDCLInterrupted){
      fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
      break;
    }

    if(!errorOccurred)
      UNPROTECT(5);

    if(save != R_PPStackTop) {
      fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);
    }

  }

  //if(R_Interactive) run_Rmainloop();

  fprintf(stderr, "\033[0;31m%s\033[0m", "exit");
  exit(0);

}
*/

#include "util.h"

extern int SocketConn_reuseAddr;
extern supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);
extern supr_socket_conn_t *serverSocketAccept(supr_socket_conn_t *serverConn);

extern vector_t *messages;
extern pthread_cond_t *messages_cond;
//vector_t *threads = NULL;
//extern vector_t *socket_connections;
//extern vector_t *threads;

size_t __read__(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      } 
    }

    int n = read(fd, buf + len,  size - len);

    if(n <= 0){
	    printf("[%s] read, n = %d, %s\n", __func__, n, strerror(errno));
	    return -1;
//	    errorcall(null, "read, n = %d, %s", n, strerror(errno));
    }

    /*  n = -1: If no messages are available at the socket, the receive calls wait  for
       a  message  to arrive, unless the socket is nonblocking (see fcntl(2)),
       in which case the value -1 is returned and the external variable  errno
       is set to EAGAIN or EWOULDBLOCK.  The receive calls normally return any
       data available, up to the requested amount,  rather  than  waiting  for
       receipt of the full amount requested.
       */

    len += n;
  }
}

#define R_SERIALIZED_OBJECT 171117121
//#define R_SERIALIZED_OBJECT 825768241


void handleClusterGet(supr_socket_conn_t *conn)
{
  //fprintf(stderr, "[%s] conn: <%p>, Start\n", __func__, conn);
  int fd = conn->fd;
  int cmd, remove, len;
  read(fd, &cmd, sizeof(int));
  read(fd, &remove, sizeof(int));
  read(fd, &len, sizeof(int));

  //fprintf(stderr, "[%s] remove: %d len: %d\n", __func__, remove, len);

  char data_name[len];
  read(fd, data_name, len);
  //fprintf(stderr, "[%s] date_name: %s\n", __func__, data_name);
  // try globalEnvironment ...
  // try shm
  size_t size;
  //assuming it is a so_t object

  if(supr_shm_exists(data_name)) {
    void *mem_ptr = supr_shm_open(data_name, &size); // fixme? exists
    write(fd, mem_ptr, size);
    munmap(mem_ptr, size);
    if(remove)
      shm_unlink(data_name);
  } else {
//    fprintf(stderr, "\n[%s] mem_ptr = %p, data_name: %s\n", __func__, mem_ptr, data_name);
    so_t so = {0, 0, 0, SUPR_UNBOUND_VALUE, 0};
    write(fd, &so, sizeof(so_t));
  }

  /*
  void *mem_ptr = rjni_shm_open(data_name, &size); // fixme? exists
  if(!mem_ptr) {
    fprintf(stderr, "\n[%s] mem_ptr = %p, data_name: %s\n", __func__, mem_ptr,
		  data_name);
    so_t so = {0, 0, 0, SUPR_UNBOUND_VALUE, 0};
    write(fd, &so, sizeof(so_t));

  } else {
    write(fd, mem_ptr, size);
    munmap(mem_ptr, size);
    if(remove)
      shm_unlink(data_name);
  }
  //fprintf(stderr, "[%s] conn: <%p> Return\n", __func__, conn);
  */
  
}

extern const char *cmd2char(int cmd);
/*
char *cmd2char(int cmd){
  switch(cmd){
    case TR_CLUSTER_GET: return "TR_CLUSTER_GET";
    default: break;
  }
  return "unknown";
}
*/

#ifndef VALUE_TO_STRING

#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)

#endif

#define read(fd, buf, size) __read__((fd), (buf), (size))

#ifdef read
//#pragma message "value of read(x, y, z) = " VALUE(read(x, y, z))
#endif

/*
#include <glibtop.h>
#include <glibtop/cpu.h>
#include <glibtop/mem.h>
#include <glibtop/proclist.h>
*/

extern char *connTypeToStr(int type);

void Worker_handleGetContext(supr_socket_conn_t *conn)
{
  int cmd, fd = conn->fd;
  read(fd, &cmd, INT_SIZE);
  int n = vectorSize(socket_connections); // LOCK?

  so_t *s = NULL;
  size_t size;

  BEGIN_R_EVAL();
    SEXP ret = PROTECT(CONS(R_NilValue, R_NilValue));
    SEXP t = ret;
    for(int i=0; i < vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
             vectorElementAt(socket_connections, i);
      char buf[256];
      sprintf(buf, "//%s:%d", sc->host, sc->port);
      SETCDR(t, CONS(mkString(buf), R_NilValue));
      t = CDR(t);
      sprintf(buf, "%s", connTypeToStr(sc->type));
      SET_TAG(t, install(buf));
    }

    errno = 0;
    int rc = isatty(STDOUT_FILENO);
    if(errno ==0 && rc){
      char buf[PATH_MAX];
      int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
      char *name = rc ? strerror(errno) : buf;
      SETCDR(t, CONS(mkString(name), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("stdout"));
    } else {
      char buf[PATH_MAX];
      ssize_t n = readlink("/proc/self/fd/1", buf, sizeof(buf));
      buf[n] = 0;
      SETCDR(t, CONS(mkString(buf), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("stdout"));

      n = readlink("/proc/self/fd/2", buf, sizeof(buf));
      buf[n] = 0;
      SETCDR(t, CONS(mkString(buf), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("stderr"));
    }

    // cpu info (USER_HZ: 1/100ths   of   a  second)
    // user   (1) Time spent in user mode.
    // nice   (2) Time spent in  user  mode  with  low  priority (nice).
    // system (3) Time spent in system mode
    // idle   (4)  Time  spent  in  the  idle  task.
    // iowait (5)  Time waiting for I/O to complete.
    // irq (6) Time servicing interrupts.

    unsigned long long total_cpu_usage1, total_cpu_usage0;
    unsigned long long cpu_usage1, cpu_usage0;
    int time = 1; // second
    for(int i=0; i<2; i++) {
      FILE *f = fopen("/proc/stat", "r");
      int c;
      size_t len=0;
      while((c=fgetc(f)) !='\n') len++;
      len ++;
      rewind(f);
      char buf[len];
      len=0;
      while((c=fgetc(f)) !='\n') buf[len++] = c;
      buf[len++]=0;
      fclose(f);

      unsigned long long user, nice, system, idle;
      sscanf(buf,"%*s %llu %llu %llu %llu",&user,&nice,&system,&idle);
      //printf("%llu %llu %llu %llu\n", user, nice, system, idle);
      if(i==0) {
        total_cpu_usage0 = user + nice + system + idle;
	cpu_usage0 = user + nice + system;
      } else  {
        total_cpu_usage1 = user + nice + system + idle;
	cpu_usage1 = user + nice + system;
      }

      sleep(time);
    }




    {

      int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
      double cpu_usage = ((double)(cpu_usage1-cpu_usage0)) /
             (total_cpu_usage1-total_cpu_usage0) * 100.0*ncpu;
      
      SETCDR(t, CONS(ScalarInteger(ncpu), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("ncpu"));
     
      SETCDR(t, CONS(ScalarReal(cpu_usage), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("%cpu"));
     
    }

    s = SO_valueOf(CDR(ret), &size);
    UNPROTECT(1);
  END_R_EVAL();

  write(fd, s, size); // handle errors ...
  free(s);
}


extern char *Exec_timestamp(char *buf, size_t buf_size);

//#define TMP_OUTPUT_SIZE 204800
// use it as buffer_size
#define TMP_OUTPUT_SIZE 1024

//tmp_output_t *tmp_output_root = NULL;

void Output_addTaskrunner(supr_socket_conn_t *conn)
{
	   
	/*
  char template[PATH_MAX];
  char *suffix = "txt";
  sprintf(template, "/tmp/taskrunner-XXXXXX.%s", suffix);
  int fd = mkstemps(template, strlen(suffix)+1);
  if(fd == -1){
	  perror("mkstemps");
	  return;
  }

  int rc = ftruncate(fd, TMP_OUTPUT_SIZE);
  if(rc == -1){
	  perror("ftruncate");
	  return;
  }
  void *mem_ptr = mmap(NULL, TMP_OUTPUT_SIZE, PROT_READ | PROT_WRITE,
		  MAP_SHARED, fd, 0); // fixme: MAP_SHARED??
  if(mem_ptr == NULL){
	  perror("mmap");
	  return;
  }

  close(fd);
  
  tmp_output_t *out = (tmp_output_t *)malloc(sizeof(tmp_output_t));
  out->conn = conn;
  out->file_name = strdup(template);
  out->mem_ptr = mem_ptr; 
  ((char*)out->mem_ptr)[0] = 0;
  out->file_size = TMP_OUTPUT_SIZE-1;
  out->size = 0;
  out->pos  = 0;

  out->next  = tmp_output_root;
  tmp_output_root = out;
  */

	/*
size_t Output_bufferSize = OUTPUT_BUF_SIZE;

typedef struct tmp_output_struct {

  struct tmp_output_struct *next;
  supr_socket_conn_t *conn;
  pid_t pid; // R process pid
  pid_t tid; // taskrunner thread id //

  size_t pos; // position
  size_t buf_size;
  unsigned char buf[0];

} tmp_output_t; // free...
*/

  tmp_output_t *out = (tmp_output_t *)
	malloc(sizeof(tmp_output_t) + Output_bufferSize);

  out->next  = tmp_output_root;
  tmp_output_root = out;

  out->conn = conn;
  out->pid  = conn->pid;
  out->start_loc  = 0; // 1: pos

  out->pos  = 0;
  out->buf_size = Output_bufferSize;
  memset(out->buf, 0, Output_bufferSize);
}

/*
void Output_toMaster(tmp_output_t *out)
{
  //fprintf(stderr, "Output_toMaster: TODO\n");
  if(!master_conn) return;
//  if(out->flush == 0) return;
  int master_fd = master_conn->fd;

  int hdr[] = {out->conn->pid, 2};
  unsigned char *buf;
  size_t buf_size;
  if(out->size <= out->file_size){
    buf_size = sizeof(hdr) + out->pos + 1;
    buf = (unsigned char*) malloc(buf_size);
    memcpy(buf + sizeof(hdr), out->mem_ptr, out->pos);
    buf[buf_size-1] = '\n';
  } else {
    buf_size = sizeof(hdr) + out->file_size + 1;
    buf = (unsigned char *) malloc(buf_size);
    size_t size_1 = out->file_size - (out->pos+1);
    memcpy(buf + sizeof(hdr), out->mem_ptr +out->pos+1, size_1);
    memcpy(buf + sizeof(hdr)+ size_1, out->mem_ptr, out->pos);
    buf[buf_size-1] = '\n';
  }

  memcpy(buf, hdr, sizeof(hdr));

  //fprintf(stderr, "%s, len: %ld\n", buf+sizeof(hdr), strlen(buf+sizeof(hdr)));

  buf_size = sizeof(hdr) + strlen(buf+sizeof(hdr));

  
      uint32_t cksum_val;
      off_t    cksum_len;
      //size_t buf_size = MSG_HEADER_SIZE + len;
      //int hdr[] = {0, pid, type, (int)len}; // fixme?
      memcpy(buf, hdr, sizeof(hdr)); 
      cfncn(buf, buf_size, &cksum_val, &cksum_len);

      int cmd = CLUSTER_BYTE_MSG;
      write(master_fd, &cmd, INT_SIZE);
      write(master_fd, &buf_size, SIZE_SIZE);
      write(master_fd, buf, buf_size);
      write(master_fd, &cksum_val, sizeof(uint32_t));

      free(buf);

//      out->flush = 0;
}
*/


/*
void deprecated_handleTaskrunnerPrint(supr_socket_conn_t *conn)
{
  char time_buf[256];
//  fprintf(stderr, "%s,  IN %s\n", __func__, Exec_timestamp(time_buf, 256));
  
  static const char *do_flush = "\033flush";

  int master_fd = master_conn ? master_conn->fd : STDERR_FILENO;
  int fd = conn->fd; //, pid=conn->pid;

  if(master_conn)
    pthread_mutex_lock(master_conn->mutex);

    size_t buf_size = 4096;
    unsigned char buf[MSG_HEADER_SIZE+buf_size+1];
    unsigned char *_buf = buf + MSG_HEADER_SIZE;

    ssize_t n = recv(fd, _buf, buf_size, MSG_PEEK | MSG_DONTWAIT);

    if(n <= 0){
        printf("\033[0;31mrecv conn(fd: %d) is disconnected "
		"(n=%ld)\033[0m\n\n", conn->fd, n);
	vectorRemoveElement(socket_connections, conn);
	close(conn->fd);
	Supr_decref(conn);

        if(master_conn)
          pthread_mutex_unlock(master_conn->mutex);

	return;
    }

    ssize_t len = read(fd, _buf, n);
    //_buf[len++] = 0;
    _buf[len+1] = 0;

    int type = strstr(_buf, do_flush) ? 2 : 1;

    if(master_conn) {
      uint32_t cksum_val;
      off_t    cksum_len;
      size_t buf_size = MSG_HEADER_SIZE + len;
      int hdr[] = {conn->pid, type}; // fixme?
      memcpy(buf, hdr, sizeof(hdr)); 
      cfncn(buf, buf_size, &cksum_val, &cksum_len);

      int cmd = CLUSTER_BYTE_MSG;
      write(master_fd, &cmd, INT_SIZE);
      write(master_fd, &buf_size, SIZE_SIZE);
      write(master_fd, buf, buf_size);
      write(master_fd, &cksum_val, sizeof(uint32_t));

      {// check embedded zeros
        for(int i=0; i < len; i++){
	  if(_buf[i] == 0){
            fprintf(stderr, "Warning: embedded zeros\n");
            fprintf(stderr, "%s\n", _buf);
            fprintf(stderr, "%s\n", _buf+i+1);
            fprintf(stderr, "Warning: embedded zeros\n");
	  }
	}
      }

    } else {
      fprintf(stderr, "//-:-:%d %s", conn->pid, _buf);
    }

  if(master_conn)
    pthread_mutex_unlock(master_conn->mutex);

  return;

  ////////////////////////////////////


#define NOT_USE_THIS_CODE
#ifndef NOT_USE_THIS_CODE

  int c, fd = conn->fd, pid=conn->pid;

  ssize_t n = recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT);
  if(n <= 0){
        if(master_conn)
          pthread_mutex_unlock(master_conn->mutex);

        printf("\033[0;31mrecv conn(fd: %d) is disconnected "
		"(n=%ld)\033[0m\n\n", conn->fd, n);
	vectorRemoveElement(socket_connections, conn);
	close(conn->fd);
	Supr_decref(conn);
	// free output ...

	return;
  }


  tmp_output_t *out = tmp_output_root;
  while(out){
    if(out->conn == conn)
	    break;
    out = out->next;
  }

  size_t buf_size = 1024;
  char buf[MSG_HEADER_SIZE+buf_size+1];

  //size_t out_bsize = stdout->bsize; // using this one ...
  fprintf(stderr, "FOPEN_MAX: %d\n", FOPEN_MAX);
  //fprintf(stderr, "FILE.bsize: %ld\n", out_bsize);

  for( ; ; ) {

    if(out){
      size_t size = out->file_size - out->pos;
      if(size <=0){
        out->pos = 0;
        size = out->file_size - out->pos;
      }
      n = recv(fd, out->mem_ptr + out->pos, size, MSG_PEEK | MSG_DONTWAIT);   

      if(n <= 0) break;



      char *_buf = (char*) (out->mem_ptr + out->pos);




      //int type = 1;
      for(int i=0; i<n; i++){
        if(_buf[i] == '\033')
        if(_buf[i] == '\033' && n-i > strlen("flush") &&
			strncmp(_buf + i + 1, "flush", strlen("flush"))==0){
          
	      fprintf(stderr, "_buf: %s\n", _buf);
	      fprintf(stderr, "follow: %s\n", _buf+i+1);
          //type = 2;
	  //_buf[i] = '\n';
          size_t len = i+1 + strlen("flush");
          len = read(fd, out->mem_ptr + out->pos, len);
          out->pos += len - (1 + strlen("flush"));
          out->size += len - (1 + strlen("flush"));
          ((char*)out->mem_ptr)[out->pos] = 0;
	  Output_toMaster(out);
	  out->size=0;
	  out->pos =0;
	  ((char *)out->mem_ptr)[0] = 0;

	  n -= len;
	  break;
        }
      }


      //char *s = (char*) (out->mem_ptr + out->pos);
      //fprintf(stderr, "\033[0;35m%s\033[0m", (char*) out->mem_ptr);
      if(n>0){
        size_t len = read(fd, out->mem_ptr + out->pos, n);

        out->pos += len;
      //if(out->size < out->file_size)
        out->size += len;
        ((char*)out->mem_ptr)[out->pos] = 0;
      }

      continue;

    }


    n = recv(fd, buf+MSG_HEADER_SIZE, buf_size, MSG_PEEK | MSG_DONTWAIT);
    if(n <= 0){
      break;
    }




    size_t len = read(fd, buf+MSG_HEADER_SIZE, n);
    buf[MSG_HEADER_SIZE + len++] = 0;

    int type = 1;
    char *_buf = buf + MSG_HEADER_SIZE;
    for(int i=0; i<len; i++){
      if(_buf[i] == 12){
        type = 2;
	_buf[i] = '\n';
	break;
      }
    }

    

#ifdef USE_CHECKSUM

    pid = 0;

    if(master_conn) {
      uint32_t cksum_val;
      off_t    cksum_len;
      size_t buf_size = MSG_HEADER_SIZE + len;
      int hdr[] = {pid, type}; // fixme?
      memcpy(buf, hdr, sizeof(hdr)); 
      cfncn(buf, buf_size, &cksum_val, &cksum_len);

      int cmd = CLUSTER_BYTE_MSG;
      write(master_fd, &cmd, INT_SIZE);
      write(master_fd, &buf_size, SIZE_SIZE);
      write(master_fd, buf, buf_size);
      write(master_fd, &cksum_val, sizeof(uint32_t));

    } else {
      { fprintf(stderr, "%s", buf); continue; }
    }
#else
    //fprintf(stderr, "\033[0;35m[%d] %s\033[0m", pid, buf);
    int hdr[] = {CLUSTER_BYTE_MSG, pid, type, (int)len};
    n = 0;
    void *ptr = hdr;
    while(n < sizeof(hdr)) {
      ssize_t r = write(master_fd, ptr+n, sizeof(hdr)-n);
      if(r == -1) {
	      fprintf(stderr, "Error: %s\n", strerror(errno));
      }
      n += r;
    }
    fprintf(stderr, "[%d] Wrote: %ld, to write %ld bytes\n",
		    getpid(), n, len);

    n = 0;
    while(n < len) {
      ssize_t r = write(master_fd, buf+n, len-n);
      if(r == -1) {
	      fprintf(stderr, "Error: %s\n", strerror(errno));
      }
      n += r;
      fprintf(stderr, "Wrote: %ld -> %ld\n", n, len);
    }

#endif
  }

  if(master_conn)
    pthread_mutex_unlock(master_conn->mutex);

#endif
#undef NOT_USE_THIS_CODE
//  fprintf(stderr, "%s, OUT %s\n", __func__, Exec_timestamp(time_buf, 256));
}
*/

void handleTaskrunnerPrint(supr_socket_conn_t *conn)
{
  tmp_output_t *out = tmp_output_root;
  while(out){
    if(out->conn == conn)
	    break;
    out = out->next;
  }

  int fd = conn->fd;

  while(TRUE){

    if(out->pos >= out->buf_size) {
      out->pos = 0;
      out->start_loc += 1;
      if( out->start_loc < 0 )
	    out->start_loc = 1;
    }
	  
    size_t size = out->buf_size - out->pos;
    ssize_t n = recv(fd, out->buf + out->pos, size, MSG_PEEK | MSG_DONTWAIT);

    if(n <= 0){
        printf("\033[0;31mrecv conn(fd: %d, pid: %d) is disconnected "
		"(n=%ld)\033[0m\n\n", conn->fd, conn->pid, n);
        fprintf(stderr, "\033[0;31mrecv conn(fd: %d, pid: %d) is disconnected "
		"(n=%ld)\033[0m\n\n", conn->fd, conn->pid, n);
	{
          sleep(1);
	  int rc = kill(conn->pid, 0);
	  errno = 0;
	  fprintf(stderr, "kill(%d, 0): %d, %s\n", conn->pid, rc,
			strerror(errno));
// send driver info...
	  int status, options = WNOHANG;
	  pid_t pid = waitpid(conn->pid, &status, options);
	  fprintf(stderr, "waitpid(%d, &status, WNOHANG): %d, status: %d%s\n",
			  conn->pid, pid, status, pid==-1?strerror(errno):"");
	  if(pid == conn->pid ){
	    if(status){
	      fprintf(stderr, "%d exit status: %d\n", conn->pid,
			   WEXITSTATUS(status)); 
              if(WIFSIGNALED(status)) {
	        fprintf(stderr, "%d was terminated by a signal (sig:%d, dump:%d)\n",
			      conn->pid, WTERMSIG(status), WCOREDUMP(status));
	      } else if(WIFEXITED(status)) 
	        fprintf(stderr, "%d terminated normally\n", conn->pid);
	    }
	  }
	}
	vectorRemoveElement(socket_connections, conn);
	close(conn->fd);
	Supr_decref(conn);

	return;
    }

    n = read(fd, out->buf + out->pos, n);
    out->pos += n;

    if(n < size)
      break;
  }
}

extern void Html_sendError(supr_socket_conn_t *conn, const char *file_name);
extern void Html_sendFile(supr_socket_conn_t *conn,
	       	const char *file_name, const char *type);

extern char **Supr_argv;

int restart(supr_socket_conn_t *conn)
{
  pid_t pid = fork();  
  if(pid <0 ){
    if(conn)
      Html_sendError(conn, strerror(errno));
    return -1;
  }

  if(pid) {
    int status;
    int rc = waitpid(pid, &status, 0);
    if(rc == -1) {
      if(conn)
        Html_sendError(conn, strerror(errno));
      return -1;
    } else {
      if(conn)
        Html_sendError(conn, "EXIT_SUCCESS");
      exit(EXIT_SUCCESS);
    }
  }

  // Clean up?

  char path[PATH_MAX];
  sprintf(path, "%s/bin/%s", Supr_sysHome, SYS_COMMAND_WORKER);
  int rc = execv(path, Supr_argv);

  if(rc == -1){
    if(conn)
      Html_sendError(conn, strerror(errno));
  }

  exit(0);
}

void handleHTTP_POST(supr_socket_conn_t *conn)
{
  int fd = conn->fd;

  size_t buf_size = 4096;
  unsigned char buf[buf_size+1];
  ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
  len = __read__(fd, buf, len);

  // fixme ... read to get "\r\n\r\n" ...
  // while(!strstr(buf, "\r\n\r\n")){
  //   ... ... Html_readHeader(...)
  // }

  buf[len++] = 0;
  fprintf(stderr, "\033[0;36m[%s://%s:%d]\n\"%s\"\033[0m\n",
            connTypeToStr(conn->type), conn->host, conn->port, buf);

  char *file_name = strstr(buf, " /")+2;
  char *str = strstr(file_name, " HTTP/");
  *str = 0; str++;

  if(strcmp(file_name, "restart.R")==0){ //int rc = restart(conn);
    len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
    if(len > 0) 
      len = __read__(fd, buf, len);

    Html_sendError(conn, "Restarting ...");
    close(fd);
    
    int rc = restart(NULL);
    return;
  }

  Html_sendError(conn, file_name);

}


void Html_sendIndex(supr_socket_conn_t *conn)
{

  char template[64];
  sprintf(template, "/tmp/supr_XXXXXX");
  int fd = mkstemp(template);
  FILE *file = fdopen(fd, "w");

  if(fd == -1 || !file){
    Html_sendError(conn, "Error");
  }

  fprintf(file, "<!DOCTYPE html>\n<HEAD>\n<TITLE>Worker@%s</TITLE>\n"
        "  <META charset=\"utf-8\">\n</HEAD>\n<BODY>\n", Supr_hostname);

  fprintf(file, "<h4>Worker info</h4>\n<UL>\n");
  fprintf(file, "\t<LI><a href=\"stdout.txt\">stdout</a></LI>\n"
        "\t<LI><a href=\"stderr.txt\">stderr</a></LI>\n"
        "</UL>\n");

  fprintf(file, "<h4>Executors</h4>\n<OL>\n");
    for(int i=0; i < vectorSize(executors); i++){
      fprintf(file, "<LI>Executor %d\n", i+1);
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
      pthread_mutex_lock(&th->mutex);
        fprintf(file, "%s\n", th->class->toString(th->class, th));
        fprintf(file, "<P><OL>\n");
	executor_property_t *properties = (executor_property_t *)
		th->properties;
	if(th->properties){
          vector_t *taskrunners = properties->taskrunners;
	  if(taskrunners){
	    pthread_mutex_lock(taskrunners->mutex);
	      for(int j=0; j < vectorSize(taskrunners); j++){
                supr_thread_t *tr = (supr_thread_t *)
		       	vectorElementAt(taskrunners,j);
                fprintf(file, "<LI>%s\n<p>",tr->class->toString(tr->class,tr));
		pthread_mutex_lock(&tr->mutex);
		  taskrunner_env_t *th_env = (taskrunner_env_t *)
			tr->properties;
		  if(th_env){
		    pid_t pid = th_env->R_pid;
		    int rc = kill(pid, 0);
		    char path[PATH_MAX];
		    sprintf(path, "%s/%d", Worker_dir, pid);
		    if(access(path, F_OK)==0){
                      fprintf(file,
		        "R process %d [%s] ("
		          "<a href=\"%d/stdout.txt\">stdout</a>"
		        ", <a href=\"%d/stderr.txt\">stderr</a>"
				")\n<p>",
			    pid, rc == -1?strerror(errno) : "alive",
			    pid, pid);
		    } else {
                      fprintf(file,
		        "<a href=\"proc-%d.txt\">R process %d</a> [%s]\n<p>",
			    pid, pid, rc == -1?strerror(errno) : "alive");
		    }
		  }
		pthread_mutex_unlock(&tr->mutex);
                fprintf(file, "</p></LI>\n");
	      }
	    pthread_mutex_unlock(taskrunners->mutex);
	  }
	}
      pthread_mutex_unlock(&th->mutex);
      fprintf(file, "</OL></P></LI>\n");
    }
  fprintf(file, "</OL>\n");

  // restart
  char *restart = "<form action=\"/restart.R\" method=\"post\">"
                "<input type=\"submit\" value=\"Restart\">"
                "<label for=\"fname\">(</label>"
                "<input type=\"text\" id=\"fname\" name=\"fname\">"
                "<label for=\"fname\">)</label><br><br>"
                "</form>";
  fprintf(file, "%s\n", restart);



  fprintf(file, "</BODY>\n");

  fclose(file);
  Html_sendFile(conn, template, "text/html");

  close(fd);
  unlink(template);


  /*
  char *idx = "<!DOCTYPE html>\n<HEAD>\n<TITLE>Worker</TITLE>\n"
        "  <META charset=\"utf-8\">\n</HEAD>\n<BODY>\n<UL>\n"
        "\t<LI><a href=\"stdout.txt\">stdout</a></LI>\n"
        "\t<LI><a href=\"stderr.txt\">stderr</a></LI>\n"
        "</UL>\n</BODY>\n";
//        "\t<LI><a href=\"worker.log\">worker.log</a></LI>\n"

  const char *p_format = "HTTP/1.1 200 OK\r\nServer:SupR2\r\n"
          "Content-length: %ld\r\nContent-type:%s; charset=UTF-8\r\n\r\n";
  char *ct = "text/html";

  char protocol[strlen(p_format)+strlen(ct)+64];
  sprintf(protocol, p_format, strlen(idx), ct);

  send(conn->fd, protocol, strlen(protocol), 0);
  send(conn->fd, idx, strlen(idx), 0);
  */

}

void handleHTTP_GET(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  size_t buf_size = 4096;
  unsigned char buf[buf_size+1];
  ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
  len = __read__(fd, buf, len);
  buf[len++] = 0;
//  fprintf(stderr, "//%s:%d\n", conn->host, conn->port);
//  fprintf(stderr, "%s\n", buf);
  // /favicon.ico

  char path[PATH_MAX];
  getcwd(path, PATH_MAX);
//  fprintf(stderr, "cwd: %s\n", path);

  char *file_name = strstr(buf, "/") + 1;
  char *str = strstr(file_name, " ");
  *str = 0;
  if(strlen(file_name) == 0){
     Html_sendIndex(conn);
     return;
  }

  if(strncmp(file_name, "proc-", strlen("proc-"))==0){

    pid_t pid = atoi(file_name + strlen("proc-"));
    printf("file-name: %s, pid: %d\n", file_name, pid);

    tmp_output_t *out = tmp_output_root;
    while(out){
      printf("file-name: %s, found pid: %d\n", file_name, out->pid);
      if(out->pid == pid)
	    break;
      out = out->next;
    }

    if(!out){
      Html_sendError(conn, file_name);  
      return;
    }

    char template[64];
    sprintf(template, "/tmp/supr_XXXXXX");
    int fd = mkstemp(template);
    //FILE *file = fdopen(fd, "w");

    if(out->start_loc == 0){
      write(fd, out->buf, out->pos);
    } else {
      write(fd, out->buf+out->pos, out->buf_size-out->pos);
      write(fd, out->buf, out->pos);
    }

    //fclose(file);
    Html_sendFile(conn, template, "text/plain");

    close(fd);
    unlink(template);



    return;
  }

  { // delete me...
    char path[PATH_MAX];
    getcwd(path, PATH_MAX);
    //fprintf(stderr, "file: %s/%s\n", Worker_dir, file_name);
    fprintf(stderr, "[%s] file: %s/%s\n", __func__, path, file_name);
  }

  Html_sendFile(conn, file_name, "text/plain");

  //Html_sendError(conn, "TODO");  
}

/*
void handleHTTP_POST(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  size_t buf_size = 4096;
  unsigned char buf[buf_size+1];
  ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
  len = __read__(fd, buf, len);
  buf[len++] = 0;
  fprintf(stderr, "//%s:%d\n", conn->host, conn->port);
  fprintf(stderr, "%s\n", buf);
  Html_sendError(conn, "TODO");  
}
*/

// deprecated ?
/*
void  removeJob(int job_id)
{
  fprintf(stderr, "[%s] job_id: %d (deprecated)\n", __func__, job_id);
  return;
	//

  w_job_t *job = NULL;
  pthread_mutex_lock(jobs->mutex);
    for(int i = vectorSize(jobs) - 1; i>=0; i--){
       w_job_t *j = vectorElementAt(jobs, i);
       //fprintf(stderr, "\tjob->id: %d\n", j->id);
       if(j->id == job_id) {
	 job = vectorRemove(jobs, i);
	 break;
       }
    }
  pthread_mutex_unlock(jobs->mutex);

  //fprintf(stderr, "\tjob: %p\n", job);
  if(!job) return;

  //fprintf(stderr, "[%s] job->id: %d\n\n", __func__, job->id);
  //destroyWorkerJob(job);
  //fprintf(stderr, "\t*job->ref_count: %d\n", ((object_t *)job)->ref_count);
  //fprintf(stderr, "\t*job->ref_count: %d\n", job->ref_count);
  pthread_mutex_lock(&job->mutex);
    Supr_decref(job);
  pthread_mutex_unlock(&job->mutex);


  //fflush(stderr);
}
*/

static int handleTaskrunnerInterrupt(int *msg, int len)
{
  int rc = 0;
  return rc;
}

void job_cancel_01(int job_id){

	   //
	   pthread_mutex_lock(waitEnvironment->mutex);
	   {
	     if(Supr_options.debug) 
	       basic_info("waitEnvironment:");
	     int n;
	     char **keys = hashtableKeySet(waitEnvironment, &n);
	     qsort(keys, n, sizeof(char *), rjni_strcmp);
	     for(int k=0; k<n; k++) {
	       vector_t *wait_queue = (vector_t *) hashtableGet(waitEnvironment,
			      keys[k]);
	       int i = vectorSize(wait_queue)-1;
	       for(; i>=0; i--) {
	         supr_thread_t *th = (supr_thread_t *)
			 vectorElementAt(wait_queue,i);

		 if(Supr_options.debug)
		 {
		   char msg[256];
		   sprintf(msg, "%d(%s).%d %s", k+1, keys[k], i+1, th->name);
		   debug_info(msg);
		 }

		 //char buf[256];
		 //sprintf(buf, "mutex: %s, th: %s (%d)", keys[k], th->name, th->tid);
		 //basic_info(buf);
		 taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  th->properties;
		 w_job_t *job = thread_env->job;
		 if(!job) {
			// error_info("\033[0;31m!job, FIXME\033[0m");
		   char msg[256];
		   sprintf(msg,"\033[0;31m[name:%s, tid:%d] !job, last_cmd: %d,  state: %s, FIXME\033[0m",
			 th->name, th->tid, thread_env->last_cmd, state2char(th->state));
		   error_info(msg);
		   //vectorRemoveElement(wait_queue, th);
		   continue;
		 }
		 if(job->id != job_id) continue;

		 // send "wait_return" ...
		 vectorRemoveElement(wait_queue, th);
		 pthread_mutex_lock(&th->mutex);
		   th->data = JOB_CANCELLED;
		   pthread_cond_signal(&th->cond);
		 pthread_mutex_unlock(&th->mutex);
	       }
	     }
	   }
	   pthread_mutex_unlock(waitEnvironment->mutex);

	   pthread_mutex_lock(syncEnvironment->mutex);
	   {
	     if(Supr_options.debug) 
	       debug_info("syncEnvironment:");
	     int n;
	     char **keys = hashtableKeySet(syncEnvironment, &n);
	     qsort(keys, n, sizeof(char *), rjni_strcmp);
	     for(int k=0; k<n; k++) {
	       vector_t *sync_queue = (vector_t *) hashtableGet(syncEnvironment,
			       keys[k]);
	       int i = vectorSize(sync_queue)-1;
	       for(; i>=0; i--) {
	         supr_thread_t *th = (supr_thread_t *)
			 vectorElementAt(sync_queue,i);
		 if(Supr_options.debug) {
		   char msg[256];
		   sprintf(msg, "%d(%s).%d %s", k+1, keys[k], i+1, th->name);
		   debug_info(msg);
		 }

		 //char buf[256];
		 //sprintf(buf, "mutex: %s, th: %s (%d)", keys[k], th->name, th->tid);
		 //basic_info(buf);
		 taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  th->properties;
		 w_job_t *job = thread_env->job;
		 if(!job) {
		   char msg[256];
		   sprintf(msg,"\033[0;31m[name:%s, tid:%d] !job, last_cmd: %d,  state: %s, FIXME\033[0m",
			 th->name, th->tid, thread_env->last_cmd, state2char(th->state));
		   error_info(msg);
		   //vectorRemoveElement(sync_queue, th);
		   continue;
		 }
		 if(job->id != job_id) continue;

		 // send "sync_return" ...
		 vectorRemoveElement(sync_queue, th);
		 pthread_mutex_lock(&th->mutex); // P2. DEAD LOCK
                   th->data = JOB_CANCELLED;
                   pthread_cond_signal(&th->cond);
                 pthread_mutex_unlock(&th->mutex);
	       }
	     }
	   }
	   pthread_mutex_unlock(syncEnvironment->mutex);

	   //
}

void sync_remove(supr_thread_t *sth){

	   //
	   pthread_mutex_lock(waitEnvironment->mutex);
	   {
	     //basic_info("waitEnvironment:");
	     int n;
	     char **keys = hashtableKeySet(waitEnvironment, &n);
	     qsort(keys, n, sizeof(char *), rjni_strcmp);
	     for(int k=0; k<n; k++) {
	       vector_t *wait_queue = (vector_t *) hashtableGet(waitEnvironment,
			      keys[k]);
	       int i = vectorSize(wait_queue)-1;
	       for(; i>=0; i--) {
	         supr_thread_t *th = (supr_thread_t *)
			 vectorElementAt(wait_queue,i);

		 /*
		 {
		   char msg[256];
		   sprintf(msg, "%d(%s).%d %s", k+1, keys[k], i+1, th->name);
		   basic_info(msg);
		 }
		 */

		 if(th == sth){
		   vectorRemoveElement(wait_queue, th);
		   //basic_info("\033[0;31mRemove!\033[0m");
		 }

		 /*
		 //char buf[256];
		 //sprintf(buf, "mutex: %s, th: %s (%d)", keys[k], th->name, th->tid);
		 //basic_info(buf);
		 taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  th->properties;
		 w_job_t *job = thread_env->job;
		 if(!job) {
			// error_info("\033[0;31m!job, FIXME\033[0m");
		   char msg[256];
		   sprintf(msg,"\033[0;31m[name:%s, tid:%d] !job, last_cmd: %d,  state: %s, FIXME\033[0m",
			 th->name, th->tid, thread_env->last_cmd, state2char(th->state));
		   error_info(msg);
		   //vectorRemoveElement(wait_queue, th);
		   continue;
		 }
		 if(job->id != job_id) continue;

		 // send "wait_return" ...
		 vectorRemoveElement(wait_queue, th);
		 pthread_mutex_lock(&th->mutex);
		   th->data = JOB_CANCELLED;
		   pthread_cond_signal(&th->cond);
		 pthread_mutex_unlock(&th->mutex);
		 */
	       }
	     }
	   }
	   pthread_mutex_unlock(waitEnvironment->mutex);

	   pthread_mutex_lock(syncEnvironment->mutex);
	   {
	     //basic_info("syncEnvironment:");
	     int n;
	     char **keys = hashtableKeySet(syncEnvironment, &n);
	     qsort(keys, n, sizeof(char *), rjni_strcmp);
	     for(int k=0; k<n; k++) {
	       vector_t *sync_queue = (vector_t *) hashtableGet(syncEnvironment,
			       keys[k]);
	       int i = vectorSize(sync_queue)-1;
	       for(; i>=0; i--) {
	         supr_thread_t *th = (supr_thread_t *)
			 vectorElementAt(sync_queue,i);
		 /*
		 {
		   char msg[256];
		   sprintf(msg, "%d(%s).%d %s", k+1, keys[k], i+1, th->name);
		   basic_info(msg);
		 }
		 */

		 if(th == sth){
		   vectorRemoveElement(sync_queue, th);
		   //basic_info("\033[0;31mRemove!\033[0m");
		 }

		 /*
		 //char buf[256];
		 //sprintf(buf, "mutex: %s, th: %s (%d)", keys[k], th->name, th->tid);
		 //basic_info(buf);
		 taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  th->properties;
		 w_job_t *job = thread_env->job;
		 if(!job) {
		   char msg[256];
		   sprintf(msg,"\033[0;31m[name:%s, tid:%d] !job, last_cmd: %d,  state: %s, FIXME\033[0m",
			 th->name, th->tid, thread_env->last_cmd, state2char(th->state));
		   error_info(msg);
		   //vectorRemoveElement(sync_queue, th);
		   continue;
		 }
		 if(job->id != job_id) continue;

		 // send "sync_return" ...
		 vectorRemoveElement(sync_queue, th);
		 pthread_mutex_lock(&th->mutex);
                   th->data = JOB_CANCELLED;
                   pthread_cond_signal(&th->cond);
                 pthread_mutex_unlock(&th->mutex);
		 */
	       }
	     }
	   }
	   pthread_mutex_unlock(syncEnvironment->mutex);

	   //
}





#ifdef write
#pragma message("\033[0;31mwrite is defined\033[0m\n")
#pragma message "\033[0;31mvalue of write(x, y, z) = " VALUE(write(x, y, z)) "\033[0m"
#endif
#ifdef read
#pragma message("\033[0;31mread is defined\033[0m\n")
#pragma message "1205. value of read(x, y, z) = " VALUE(read(x, y, z))
#endif


#ifndef DEPRECATED_TR_SEND_DRIVER
void sendDriver(void *data){
 
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  taskrunner_env_t *th_env = (taskrunner_env_t *) cth->properties;
  if(th_env){
    sync_remove(cth);
    w_job_t *job = th_env->job;
    supr_socket_conn_t *sc = job->sc;
    pthread_mutex_lock(sc->mutex);
      size_t len = ((size_t*) data)[0];
      int cmd = CLUSTER_BYTE_MSG;
      write(sc->fd, &cmd, sizeof(int));

      ssize_t n = write(sc->fd, data+sizeof(size_t), len);
      {
	      char msg[256];
	      sprintf(msg, "Wrote: %ld/%ld", n, len);
	      basic_info(msg);
      }
      so_t s;
      read(sc->fd, &s, sizeof(so_t));
      int rc = s.obj_type;
    pthread_mutex_unlock(sc->mutex);
  } else {
    error_info(cth->name);
  }
  free(data);
}

supr_thread_t *findTaskrunner(pid_t cpid){
  supr_thread_t *tr = NULL;

  
  for(int i=0; i< vectorSize(executors); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
    pthread_mutex_lock(&th->mutex); 
    executor_property_t *properties = (executor_property_t *)
                th->properties;
    if(th->properties){
      vector_t *taskrunners = properties->taskrunners;
      if(taskrunners){
        pthread_mutex_lock(taskrunners->mutex);
	  for(int j=0; j < vectorSize(taskrunners); j++){
            tr = (supr_thread_t *) vectorElementAt(taskrunners,j);
	    taskrunner_env_t *th_env = (taskrunner_env_t *)
                        tr->properties;
	    if(th_env->R_pid == cpid) break;
	    else tr = NULL;
	  }
        pthread_mutex_unlock(taskrunners->mutex);
      }
    }
    pthread_mutex_unlock(&th->mutex);
    if(tr) break;
  }
 
  return tr;
}
#endif


supr_thread_t *findTaskrunner(int tid){
  supr_thread_t *tr = NULL;

  //{
	pthread_mutex_lock(tr_threads->mutex);
	  for(int j=0; j < vectorSize(tr_threads); j++){
            tr = (supr_thread_t *) vectorElementAt(tr_threads,j);
	    if(tr->tid == tid) break;
	    else tr = NULL;
	}
	pthread_mutex_unlock(tr_threads->mutex);
  //}

  /*
  for(int i=0; i< vectorSize(executors); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
    pthread_mutex_lock(&th->mutex); 
    executor_property_t *properties = (executor_property_t *)
                th->properties;
    if(th->properties){
      vector_t *taskrunners = properties->taskrunners;
      if(taskrunners){
        pthread_mutex_lock(taskrunners->mutex);
	  for(int j=0; j < vectorSize(taskrunners); j++){
            tr = (supr_thread_t *) vectorElementAt(taskrunners,j);
	    if(tr->tid == tid) break;
	    else tr = NULL;
	  }
        pthread_mutex_unlock(taskrunners->mutex);
      }
    }
    pthread_mutex_unlock(&th->mutex);
    if(tr) break;
  }
  */
  return tr;
}


/*
void Sync_queue_cancel(void *data){

  supr_thread_t *th = (supr_thread_t *) data;
  pthread_mutex_lock(&th->mutex); //P1. dead lock...use main_thread; See driver::REPL...
    th->data = JOB_CANCELLED;
    pthread_cond_signal(&th->cond);
  pthread_mutex_unlock(&th->mutex);

}
*/

// handle sync for cancelled job
void Sync_cancel(void *data){
  //int job_id = *((int*) ((void **) data)[0]);
  //int tid = *((int*) ((void **) data)[1]);
  //char *mutex = (char*) ((void **) data)[2];

  int *int_ptr = (int*) data;
  int job_id = int_ptr[0];
  int tid = int_ptr[1];
  char *mutex = (char*) (data + 2*sizeof(int));

  w_job_t *job = NULL;

	     pthread_mutex_lock(cancelled_jobs->mutex);
	       for(int i=0; i<vectorSize(cancelled_jobs); i++){
                 job = (w_job_t *)vectorElementAt(cancelled_jobs, i);
	         if(job->id == job_id) {
		   basic_info("\033[0;33mJOB CANCELLED\033[0m");
		   break;
		 }
	         else job = NULL;
	       }
	     pthread_mutex_unlock(cancelled_jobs->mutex);
	   
	     //char *mutex = buf;
	     pthread_mutex_lock(syncEnvironment->mutex); // P2. DEAD LOCK?
	     vector_t *sync_queue = (vector_t *)
               hashtableGet(syncEnvironment, mutex);
	     if(!sync_queue || vectorSize(sync_queue)==0){
	        //error_info("Error: FIXME, JOB CANCELLED?"); // FIXME
		{
		  supr_thread_t *th= findTaskrunner(tid);
		  if(th){
	            basic_info("\033[0;33mFound the TR\033[0m");
		    //main_thread_tasks_add(Sync_queue_cancel, th);
	            pthread_mutex_lock(&th->mutex); 
	              th->data = JOB_CANCELLED;
	              pthread_cond_signal(&th->cond);
	            pthread_mutex_unlock(&th->mutex);
	            basic_info(th->name);
		  } else {
	            basic_info("\033[0;31mcannot find the TR\033[0m");
		  }
		}
	        pthread_mutex_unlock(syncEnvironment->mutex);
                free(data);     
		return;
	     }
	     int i = vectorSize(sync_queue)-1;
	     for(; i>=0; i--) {
	       supr_thread_t *th=(supr_thread_t *)vectorElementAt(sync_queue,i);
	       if(th->tid == tid){
		 vectorRemoveElement(sync_queue, th);
		 
		 //if(TRUE){
	         pthread_mutex_lock(&th->mutex); 
	           th->data = JOB_CANCELLED;
	           pthread_cond_signal(&th->cond);
	         pthread_mutex_unlock(&th->mutex);
		 //} else {
		 //main_thread_tasks_add(Sync_queue_cancel, th);
		 //}
	         break;
	       }
	     }

	     pthread_mutex_unlock(syncEnvironment->mutex);
  free(data);     
}

void Sync_return(void *data){

  int *int_ptr = (int*) data;
  int job_id = int_ptr[0];
  int tid = int_ptr[1];
  char *mutex = (char*) (data + 2*sizeof(int));

	   pthread_mutex_lock(syncEnvironment->mutex);
	     vector_t *sync_queue = (vector_t *)
               hashtableGet(syncEnvironment, mutex);
	     if(!sync_queue || vectorSize(sync_queue)==0){
	        basic_info("\033[0;32mError: FIXME, JOB CANCELLED?");
	        pthread_mutex_unlock(syncEnvironment->mutex);
		return;
	     }
	     int i = vectorSize(sync_queue)-1;
	     for(; i>=0; i--) {
	       supr_thread_t *th=(supr_thread_t *)vectorElementAt(sync_queue,i);
	       if(th->tid == tid){
		 vectorRemoveElement(sync_queue, th);
		
	         pthread_mutex_lock(&th->mutex);
	           th->data = PTHREAD_SYNCHRONIZED;
	           pthread_cond_signal(&th->cond);
	         pthread_mutex_unlock(&th->mutex);
		 
	         break;
	       }
	     }
	     if(i<0) printf("\033[0;32mFIXME\033[0m\n");

	   pthread_mutex_unlock(syncEnvironment->mutex);

}




void handleCommand(supr_socket_conn_t *conn)
{
  static int Reconnected2driver = FALSE;
  if(conn->type == TR_PRINT_STDOUT){
    handleTaskrunnerPrint(conn);
    return;
  }
#define NOT_DEBUG_SEGV_ACTION
#ifdef  DEBUG_SEGV_ACTION
  {
    struct sigaction sa;
    int rc = sigaction(SIGSEGV, &R_segvAct, &sa);
    if(rc == -1){
      printf("Error: sigaction, %s\n", strerror(errno));
    } else if(sa.sa_sigaction != Worker_SigactionSegv){
      printf("Error: sa.sa_sigaction != Worker_SigactionSegv\n");
      sleep(100);
    } else {
      printf("\033[0;31mInfo: %s\033[0m\n", strerror(errno));
    }
  }
#endif

  int fd = conn->fd;
  //conn->print(conn);

  int driver_to_fd = 0; // delete me ...

  int cmd;
  {
    ssize_t n = 0;
    for( ; ; ) {
      n = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
      if(n <= 0){
        printf("\033[0;31mrecv conn(fd: %d) is disconnected "
		"(n=%ld)\033[0m\n\n", conn->fd, n);
	vectorRemoveElement(socket_connections, conn);
	if(conn->type == MASTER_CONN){
     //      system_exit(CLUSTER_SHUTDOWN); // TODO
	  sprintf(Supr_curErrorBuf, "lost the master connection");
	  fprintf(stderr, "%d. %s\n", __LINE__, Supr_curErrorBuf);
	  handleShutdown(conn); // FIXME ...
	} else if (conn->type == TR_PRINT_STDOUT){
          fprintf(stderr, "TR-%d, disconnected\n", conn->pid);
	}
	close(conn->fd);
	Supr_decref(conn);
	return;
      } else if( n == INT_SIZE) break;
    }

    //if(TRUE || Supr_options.debug || fd == driver_to_fd)
    if(Supr_options.debug)
    {
      char buf[256];
      sprintf(buf, "[%s] fd: %d, type: %d, cmd = %d (%s)",
		   __func__, conn->fd, conn->type, cmd, cmd2char(cmd));
      debug_info(buf);
      //basic_info(buf);
    }

  }

  switch(cmd){
    case CLUSTER_JOB_SUBMIT:
	 {
	   int msg[2]; // {cmd, job_id}
           ssize_t size = read(fd, msg, sizeof(msg));

	   int job_id = msg[1];
	   so_t so;
           size = read(fd, &so, sizeof(so_t));

	   so_t *s = malloc(sizeof(so_t)+so.size);
	   memcpy(s, &so, sizeof(so_t));

           size = read(fd, s->val, so.size);

	   if(conn->type == DRIVER_CONN) {
	   } else { // from the "write-to" connection
		   int rc = 0;
		   write(fd, &rc, INT_SIZE);
		   driver_to_fd = fd; // delete me
	   }

	   
	   verbose_info("'%s:%d' (fd: %d) CLUSTER_JOB_SUBMIT",
			   conn->host, conn->port, conn->fd);

	   /*
	   { // Checking
             ssize_t n = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
	     printf("CLUSTER_JOB_SUBMIT: %d more bytes, %s\n", n,
			     n == -1 ?  strerror(errno) : "Success");
	   }
	   */

	   w_job_t *job = newWorkerJob(job_id, s);
	   pthread_mutex_lock(jobs->mutex);
	   vectorAdd(jobs, job);

//	   pthread_mutex_unlock(jobs->mutex);

	   for(int i=0; i< vectorSize(executors); i++){
             supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
//	     printf("[%s] thread_state: %d\n", __func__, th->state);
	     pthread_mutex_lock(&th->mutex);
//MALLOC_MARK(1);
//MALLOC_MARK(__LINE__);
	       thread_info_t *info = (thread_info_t *)
		       malloc(sizeof(thread_info_t));//free? job->free_list...?
	       job->info = info; // FIXME??
	       info->type = NEW_JOB;
	       info->data = job;
	       //th->data = job;
	       th->data = info;
	       pthread_cond_signal(&th->cond);
	     pthread_mutex_unlock(&th->mutex);

	     if(Supr_debug){
	       char msg[1024];
	       sprintf(msg, "Sent job %d signal to (executor) %s", job_id, th->name);
	       Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
	     }

	   }

	   pthread_mutex_unlock(jobs->mutex);
	   // ...
//	   printf("cmd: %s IS DONE\n\n", cmd2char(cmd));
	 }
	 return;

    case DRIVER_INFO:
	 {
           size_t size = read(fd, &cmd, sizeof(int));
	   int len;
           size = read(fd, &len, sizeof(int));
	   char buf[len];
           size = read(fd, buf, len);
//	   printf("[%s:%d:%s] buf=%s\n", __FILE__, __LINE__, __func__, buf);
	   char *str = strstr(buf, ":");
	   int port = atoi(str+1);
	   *str = 0;
	   str = strstr(buf,"//")+2;
	   supr_socket_conn_t *driver_conn = socketOpen2(str, port);

	   int i=0;
	   while(driver_conn == NULL){
	     {
	     char buf[strlen(str)+128];
	     sprintf(buf, "connect(%s:%d) returned %p", str, port, driver_conn);
             Cluster_sendSimpleMessage(buf, msg_color, VERBOSE_INFO_TYPE, 0);
	     }
	   
	     i++;
	     if(i>1) printf("Conntecting driver: %s:%d...\n", str, port);
	     sleep(1);
	     driver_conn = socketOpen2(str, port);
	   }

	   driver_conn->type = DRIVER_CONN;
           driver_conn->port = port;
           int msg[] = {WORKER_REGISTER, workerServerConn->port, getpid(),
	   	gettid()};
           size = write(driver_conn->fd, msg, sizeof(msg));

           vectorAdd(socket_connections, driver_conn); 

	   if(Reconnected2driver){
	     pthread_mutex_lock(jobs->mutex);

	     for(int i=0; i< vectorSize(executors); i++){
               supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
	       pthread_mutex_lock(&th->mutex);
	         thread_info_t *info = (thread_info_t *)
		       malloc(sizeof(thread_info_t));//free? job->free_list...?
	         info->type = CONNECT_DRIVER;
	         info->data = driver_conn;
	         th->data = info;
	         pthread_cond_signal(&th->cond);
	       pthread_mutex_unlock(&th->mutex);
	     }

	     pthread_mutex_unlock(jobs->mutex);

	   } else {
	     pthread_mutex_lock(&driverServerInitMutex);
	       driverServerConn = driver_conn;

               fprintf(stderr,"%d .%s: executors.size: %d\n", __LINE__, __func__,
			   vectorSize(executors));

	       pthread_cond_broadcast(&driverServerInitCond);
	     pthread_mutex_unlock(&driverServerInitMutex);
	     Reconnected2driver = TRUE;
	   }
	   
	   /*
	   for(int i=0; i<vectorSize(executors); i++){
             supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
	     // message:
	     pthread_mutex_lock(&th->mutex);
	       fprintf(stderr,"%d .%s: locked\n", __LINE__, __func__);
	       fprintf(stderr,"%d .%s: th->data: %p\n", __LINE__, __func__, 
			       th->data);
	       thread_info_t *info = (thread_info_t *)
		       malloc(sizeof(thread_info_t)); // free?
	       th->data = driverServerConn;
	       pthread_cond_signal(&th->cond);
	     pthread_mutex_unlock(&th->mutex);
	   }
	   */

	   cmd = SET_CONN_PID;
	   write(driver_conn->fd, &cmd, sizeof(int));
	   int pid = getpid();
	   write(driver_conn->fd, &pid, sizeof(int));
	   int type = WORKER_CONN;
	   write(driver_conn->fd, &type, sizeof(int));
	   //int rc; read(driver_conn->fd, &rc, sizeof(int)); // to do?
	 }
	 return;
	 
    case WORKER_READY:
	 {
           int msg[] = {WORKER_READY, __tr_count}; // FIXME
           ssize_t size = read(fd, msg, INT_SIZE);
	   fprintf(stderr, "WORKER_READY, __tr_count: %d\n", __tr_count);
           //ssize_t size = 
	   write(driverServerConn->fd, msg, sizeof(msg));
         }
	 return;
	 
	 /*
    case SET_CONN_PID:
	 { 
           int msg[3];
           read(fd, msg, sizeof(msg));
	   conn->pid = msg[1];
	   conn->type = msg[2]; // FIXME
         }
	 return;
	 */
	 
    case CLUSTER_SHUTDOWN:
	 {
	   sprintf(Supr_curErrorBuf, "Received CLUSTER_SHUTDOWN (%d) command from"
	     " %s:%d (fd: %d)", cmd, conn->host, conn->port, conn->fd);
	   basic_info(Supr_curErrorBuf);

	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));

           int rc = 0;
	   write(fd, &rc, sizeof(int));
	   master_conn = NULL;
           
	   sprintf(Supr_curErrorBuf, "Received CLUSTER_SHUTDOWN (%d, size: %ld) command from"
	     " %s:%d (fd: %d)", msg[0], size, conn->host, conn->port, conn->fd);
	   basic_info(Supr_curErrorBuf);

	   fprintf(stderr, "%d. %s\n", __LINE__, Supr_curErrorBuf);
	   handleShutdown(conn);
	 }
	 return;
	 
    case TR_CLUSTER_GET:
//	 {
//	   printf("\n\033[0;31m[%s] TR_CLUSTER_GET\033[0m\n", __func__);
           handleClusterGet(conn);
//	 }
	 return;
	 
    case TR_CLUSTER_INTERRUPT:
	 {
		 //basic_info("TR_CLUSTER_INTERRUPT");

	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));

	   int rc = 0;
           write(fd, &rc, INT_SIZE);

	   int job_id = msg[1];
	   // message:
 	   //fprintf(stderr, "cmd: %s, job_id: %d\n", cmd2char(cmd), job_id);

           pthread_mutex_lock(jobs->mutex);
	     w_job_t *job = NULL;
	     for(int i=vectorSize(jobs)-1; i>=0; i--){
	       w_job_t *j = (w_job_t*)vectorElementAt(jobs, i);
	       if(j->id == job_id) {
		 job = j;
		 vectorRemoveElement(jobs, job);
                 pthread_mutex_lock(cancelled_jobs->mutex);
		   vectorAdd(cancelled_jobs, job);
                 pthread_mutex_unlock(cancelled_jobs->mutex);
		 {
		   pthread_mutex_lock(&job->bc->mutex);
		     job->bc->destroy = TRUE;

		     //char buf[256];
		     //sprintf(buf, "job->bc->cond.__data.__wrefs: %d", job->bc->cond.__data.__wrefs);
		     //basic_info(buf);

		     pthread_cond_broadcast(&job->bc->cond); 
		   pthread_mutex_unlock(&job->bc->mutex);
		 }
		 job->cancelled = TRUE;
		 /*
                 pthread_mutex_lock(&job->mutex);
		   job->cancelled = TRUE;
                 pthread_mutex_unlock(&job->mutex);
		 */
		 break;
	       }
	     }
           pthread_mutex_unlock(jobs->mutex);

	   /*
	    
	   pthread_mutex_lock(waitEnvironment->mutex);
	   {
	     basic_info("waitEnvironment:");
	     int n;
	     char **keys = hashtableKeySet(waitEnvironment, &n);
	     qsort(keys, n, sizeof(char *), rjni_strcmp);
	     for(int k=0; k<n; k++) {
	       vector_t *wait_queue = (vector_t *) hashtableGet(waitEnvironment,
			      keys[k]);
	       int i = vectorSize(wait_queue)-1;
	       for(; i>=0; i--) {
	         supr_thread_t *th = (supr_thread_t *)
			 vectorElementAt(wait_queue,i);

		 char buf[256];
		 sprintf(buf, "mutex: %s, th: %s (%d)", keys[k],
				 th->name, th->tid);
		 basic_info(buf);
		 taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  th->properties;
		 w_job_t *job = thread_env->job;
		 if(job->id != job_id) continue;

		 // send "wait_return" ...
		 vectorRemoveElement(wait_queue, th);
		 pthread_mutex_lock(&th->mutex);
		   th->data = JOB_CANCELLED;
		   pthread_cond_signal(&th->cond);
		 pthread_mutex_unlock(&th->mutex);
	       }
	     }
	   }
	   pthread_mutex_unlock(waitEnvironment->mutex);

	   pthread_mutex_lock(syncEnvironment->mutex);
	   {
	     basic_info("syncEnvironment:");
	     int n;
	     char **keys = hashtableKeySet(syncEnvironment, &n);
	     qsort(keys, n, sizeof(char *), rjni_strcmp);
	     for(int k=0; k<n; k++) {
	       vector_t *sync_queue = (vector_t *) hashtableGet(syncEnvironment,
			       keys[k]);
	       int i = vectorSize(sync_queue)-1;
	       for(; i>=0; i--) {
	         supr_thread_t *th = (supr_thread_t *)
			 vectorElementAt(sync_queue,i);

		 char buf[256];
		 sprintf(buf, "mutex: %s, th: %s (%d)", keys[k],
				 th->name, th->tid);
		 basic_info(buf);
		 taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  th->properties;
		 w_job_t *job = thread_env->job;
		 if(job->id != job_id) continue;

		 // send "sync_return" ...
		 vectorRemoveElement(sync_queue, th);
		 pthread_mutex_lock(&th->mutex);
                   th->data = JOB_CANCELLED;
                   pthread_cond_signal(&th->cond);
                 pthread_mutex_unlock(&th->mutex);
	       }
	     }
	   }
	   pthread_mutex_unlock(syncEnvironment->mutex);

	   */

	   /*
           pthread_mutex_lock(&job->mutex);
	     for(int i=vectorSize(job->taskrunners)-1; i>=0; i--){
               char *addr = (char*) vectorElementAt(job->taskrunners,i);
	       int pid = atoi(strstr(addr, "#")+1);
	       printf("[%s] %s, pid=%d\n", __func__, addr, pid);
	       kill(pid, SIGUSR2);
	       int wstatus;
	       pid_t p = waitpid(pid, &wstatus, 0);
	       if(p==-1){
	         printf("[%s] waitpid(%d, ): %s\n", __func__, pid,
				 strerror(errno));
	       } else {
	         printf("[%s] waitpid(%d, ): %d\n", __func__, pid, p);
	       }
	       //pid_t p = waitpid(pid, &wstatus, WNOHANG);
	     }
           pthread_mutex_unlock(&job->mutex);
	   */

	   if(job){
	     for(int i=0; i<vectorSize(executors); i++){
               supr_thread_t *th=(supr_thread_t *)vectorElementAt(executors,i);
//	       printf("[%s] thread_state: %d\n", __func__, th->state);
	       pthread_mutex_lock(&th->mutex);
	         thread_info_t *info = (thread_info_t *)
		       malloc(sizeof(thread_info_t)); // free?
	         info->type = INTERRUPT;
	         info->data = job;
	       //th->data = PTHREAD_INTERRUPTED;
	         th->data = info;
	         pthread_cond_signal(&th->cond);
	       pthread_mutex_unlock(&th->mutex);
	     }
	   }
	   /*
	   for(int i=vectorSize(threads)-1; i>=0; i--){
             supr_thread_t *th = (supr_thread_t *)vectorElementAt(threads,i);
	     //printf("[%s] %s\n", __func__, objectToString(th));
	     printf("[%s] %p\n", __func__, th);
	     if(th) pthread_kill(th->ptid, SIGUSR2);
	   }
	   */
	 }
	 return;

#ifndef DEPRECATED_TR_SEND_DRIVER
    case TR_SEND_DRIVER:
	 {
           read(fd, &cmd, sizeof(int));
	   size_t len;
           read(fd, &len, sizeof(size_t));
	   void *ptr = malloc(len +sizeof(size_t));
	   ((size_t*)ptr)[0] = len;
           read(fd, ptr + sizeof(size_t), len);

	   pid_t cpid;
           read(fd, &cpid, sizeof(pid_t));

	   int rc = 0;
	   write(fd, &rc, sizeof(int));

		 // let the thread to do this ?
	   for(int i=0; i<vectorSize(socket_connections); i++){
             supr_socket_conn_t *sc = (supr_socket_conn_t *)
		       vectorElementAt(socket_connections, i);
	     if(sc->type == DRIVER_CONN){
	       int  cmd = CLUSTER_BYTE_MSG;
	       write(sc->fd, &cmd, sizeof(int));
	       ssize_t n = write(sc->fd, ptr + sizeof(size_t), len);
	       so_t s;
	       read(sc->fd, &s, sizeof(so_t));
	       rc = s.obj_type;
	       break;
	     }
	   }
	   free(ptr);
	   //
	   int status;
           rc = waitpid(cpid, &status, 0);
	   {
	     char buf[256];
	     sprintf(buf, "\033[0;34mwaitpid(%d, &status, 0): %d\033[0m", cpid, rc);
	     basic_info(buf);
	   }

	   /*
           supr_thread_t *tr = findTaskrunner(cpid);
	   if(tr){
	     char buf[256];
	     sprintf(buf, "taskrunner '%d' has tid: %d", cpid, tr->tid);
	     basic_info(buf);
	     pthread_kill(tr->ptid, SIGINT);
	     tr->data = ptr;
	     tr->fun = sendDriver;
	   } else {
	     char buf[256];
	     sprintf(buf, "taskrunner '%d' not found", cpid);
	     error_info(buf);
	   }
	   */
	 }
	 return;
#endif

    case TASKRUNNER_INTERRUPTED:
	 {
	   int len = 3;
	   int msg[len]; // cmd, tr_pid, tr_cmd
           size_t size = read(fd, msg, sizeof(msg));
	   int rc = handleTaskrunnerInterrupt(msg, len);
           write(fd, &rc, INT_SIZE);
	 }
	 return;
	 
    case TR_COUNTDOWN_DECREASE:
	 { // for efficiency, let the thread do it ... when
		 // the backend is reading these, driverConn can be used...
	   int cmd, job_id, tid;
           size_t size = read(fd, &cmd, INT_SIZE);
           read(fd, &job_id,  INT_SIZE);
           read(fd, &tid,     INT_SIZE);

	   size_t len;
           size = read(fd, &len, SIZE_SIZE);

//	   printf("\033[0;32m[%s:%d:%s] mutex.length: %ld\n", __FILE__, __LINE__, __func__, len);
	   char buf[len];
           size = read(fd, buf, len);
//	   printf("\033[0;32m[%s:%d:%s] mutex: %s\n", __FILE__, __LINE__, __func__, buf);

           read(fd, &size, SIZE_SIZE);

	   /*
	   unsigned char args[size];
	   */
	   void *args = malloc(size);
           read(fd, args, size);

	   write(driverServerConn->fd, &cmd, INT_SIZE);
	   write(driverServerConn->fd, &job_id, INT_SIZE);
	   write(driverServerConn->fd, &tid, INT_SIZE);
	   write(driverServerConn->fd, &len, SIZE_SIZE);
	   write(driverServerConn->fd, buf, len);
	   write(driverServerConn->fd, &size, SIZE_SIZE);
	   write(driverServerConn->fd, args, size);

	   free(args);
	 }
	 return;

	 /*
    case TR_COUNTDOWN_RELEASE:
	 { 
#define NON_NULL_ONLY
#ifdef  NON_NULL_ONLY

	   int cmd, n_values, n_trs;
           ssize_t size = read(fd, &cmd, INT_SIZE);
	   int len;
	   size = read(fd, &len, INT_SIZE);
	   char mutex[len];
	   size = read(fd, mutex, len);
//	   printf("mutex: %s\n", mutex);

           read(fd, &n_values,     INT_SIZE);

//	   printf("\033[0;34mcmd: %d (%s), n_values: %d\033[0m\n", cmd, cmd2char(cmd), n_values);
	   void *value[n_values];

	   for(int i=0; i<n_values; i++){
             so_t so;
	     size = read(fd, &so, sizeof(so_t));
//	     printf("size: %ld, so.obj_type: %d, so.size: %ld\n", size, so.obj_type, so.size);
	     so_t *s = (so_t *) malloc(sizeof(so_t) + so.size);
//	     printf("s: %p\n", s);
	     memcpy(s, &so, sizeof(so_t));
//	     printf("size: %ld, s->obj_type: %d, s->size: %ld\n", size, s->obj_type, s->size);
	     size = read(fd, s->val, s->size);
	     value[i] = s;
	   }

           read(fd, &n_trs,     INT_SIZE);
	   int tid[n_trs];
	   for(int i=0; i<n_trs; i++){
             read(fd, tid+i, INT_SIZE);
	   }

           share_t *sh = Share_new(n_values, value, Supr_free);

	   for(int k=0; k < n_trs; k++){
	     Supr_incref(sh);
             Cond_notify(mutex, tid[k], sh);
	   }
	   Supr_decref(sh);

#else
	   int cmd, n;
           ssize_t size = read(fd, &cmd, INT_SIZE);
           read(fd, &n,     INT_SIZE);
//	   printf("cmd: %d (%s), n: %d\n", cmd, cmd2char(cmd), n);
	   void *value[n];
	   int tid[n];

	   int len;
	   size = read(fd, &len, INT_SIZE);
	   char mutex[len];
	   size = read(fd, mutex, len);
//	   printf("mutex: %s\n", mutex);

	   for(int i=0; i<n; i++){

	     size = read(fd, tid+i, INT_SIZE);
//	     printf("tid: %d\n", tid[i]);


             so_t so;
	     size = read(fd, &so, sizeof(so_t));
//	     printf("size: %ld, so.obj_type: %d, so.size: %ld\n", size, so.obj_type, so.size);
	     so_t *s = (so_t *) malloc(sizeof(so_t) + so.size);

	     //unsigned char buf[sizeof(so_t) + so.size];
	     //so_t *s = (so_t *) buf;
//	     printf("s: %p\n", s);
	     memcpy(s, &so, sizeof(so_t));
//	     printf("size: %ld, s->obj_type: %d, s->size: %ld\n", size, s->obj_type, s->size);

	     size = read(fd, s->val, s->size);
	     //size = read(fd, s+1, s->size);
//	     printf("size: %ld, s->obj_type: %d, s->size: %ld\n", size, s->obj_type, s->size);

	     value[i] = s;
	   }

           //share_t *sh = Share_new(n, value, free);
           share_t *sh = Share_new(n, value, Supr_free);

	   int nth = 0;
	   for(int k=0; k < n; k++) {
             if(tid[k] <= 0) continue;
	     Supr_incref(sh);
	   }
	   Supr_decref(sh);

	   for(int k=0; k < n; k++){
             if(tid[k] <= 0) continue;
             Cond_notify(mutex, tid[k], sh);
	   }
#endif
	 }
	 return;
	 */


    case CLUSTER_SET_OPTIONS:
         {
           read(fd, &cmd, sizeof(int));
           supr_options_t options;
           read(fd, &options, sizeof(supr_options_t));
           //{
             Supr_options.info = options.info;
             Supr_options.debug = options.debug;
             Supr_options.verbose = options.verbose;
             //Supr_options.port = options.port;
             Supr_options.level = options.level;
             Supr_options.timeout = options.timeout;
           //}
           int rc = 0;
           write(fd, &rc, INT_SIZE);
         }
         return;


    case TR_CLUSTER_WAIT: // from task runners
	 {
	   int cmd, job_id, tid;
           size_t size = read(fd, &cmd, INT_SIZE);
           read(fd, &job_id,  INT_SIZE);
           read(fd, &tid,     INT_SIZE);

	   double timeout;
           read(fd, &timeout, DOUBLE_SIZE);

	   size_t len;
           size = read(fd, &len, SIZE_SIZE);

	   char buf[len];
           size = read(fd, buf, len);

	   w_job_t *job = NULL;
	   pthread_mutex_lock(jobs->mutex);
	     for(int i=0; i<vectorSize(jobs); i++){
               job = (w_job_t *)vectorElementAt(jobs, i);
	       if(job->id == job_id) break;
	       else job = NULL;
	     }
	   pthread_mutex_unlock(jobs->mutex);
	   if(!job){ // or cancelled ...
	     ssize_t size;
             read(fd, &size, sizeof(ssize_t));
	     char buf[size];
             read(fd, buf, size);

	     int rc = 2;
	     write(fd, &rc, sizeof(int));
	     //basic_info("\033[0;31mTR_CLUSTER_WAIT JOB CANCELLED\033[0m");
	     return;
	   }


	   //write(driverConn->fd, msg, 2*INT_SIZE);//change to this or sc2drver
	   write(driverServerConn->fd, &cmd, INT_SIZE);
	   write(driverServerConn->fd, &job_id, INT_SIZE);
	   write(driverServerConn->fd, &tid, INT_SIZE);
	   write(driverServerConn->fd, &timeout, DOUBLE_SIZE);
	   write(driverServerConn->fd, &len, SIZE_SIZE);
	   write(driverServerConn->fd, buf, len);

#ifdef TR_WAIT_USE_TIME_EXPR
	   {
	     ssize_t size;
             read(fd, &size, sizeof(ssize_t));
	     char buf[size];
             read(fd, buf, size);
             write(driverServerConn->fd, &size, sizeof(ssize_t));
             write(driverServerConn->fd, buf, size);
	   }
#endif
	   {
		   int rc;
		   read(driverServerConn->fd, &rc, sizeof(int));
		   //basic_info("Received rc from driverServerConn");
	   }

	   {
	     int rc = 0;
	     write(fd, &rc, sizeof(int));
	   }
	 }
	 return;

    case TR_CLUSTER_WAIT_RETURN: // from driver
    case TR_CLUSTER_WAIT_TIMEOUT: // from driver
    case TR_CLUSTER_WAIT_TIMEOUT_EXPR: // from driver
	 {
	   int cmd, job_id, tid;
           size_t size = read(fd, &cmd, INT_SIZE);
           size = read(fd, &job_id,     INT_SIZE);
           size = read(fd, &tid,        INT_SIZE);
//	   printf("\033[0;32mcmd: %s, job_id: %d tid:%d\n", cmd2char(cmd), job_id, tid);

	   size_t len;
           size = read(fd, &len, SIZE_SIZE);
	   char mutex[len];
           size = read(fd, mutex, len);
//	   printf("\033[0;32mmutex: %s\033[0m\n", mutex);

	   w_job_t *job = NULL;
	   pthread_mutex_lock(jobs->mutex);
	     for(int i=0; i<vectorSize(jobs); i++){
               job = (w_job_t *)vectorElementAt(jobs, i);
	       if(job->id == job_id) break;
	       else job = NULL;
	     }
	   pthread_mutex_unlock(jobs->mutex);
	   if(!job){ // or cancelled ...

		   basic_info("TR_CLUSTER_WAIT_.., !job");

	       if( cmd == TR_CLUSTER_WAIT_TIMEOUT_EXPR){ // FIXME
		     int rc;
                     size = read(fd, &rc, INT_SIZE);
		     if(rc == 0){ 
		       double timeout;
                       size = read(fd, &timeout, sizeof(double));
		       {
		         char msg[256];
		         sprintf(msg, "\033[0;35mrc: %d, timeout: %f\033[0m",
					 rc, timeout);
		         basic_info(msg);
		       }
		     } else { // -1, error
		       int len;
                       size = read(fd, &len, INT_SIZE);
		       void *ptr = malloc(sizeof(int)+len);
		       *((int*)ptr) = rc;
                       size = read(fd, ptr + sizeof(int), len);
	               error_info((char*) (ptr + sizeof(int)));
		       free(ptr);
		     }

	       }
	       if(conn->type==DRIVER_CONN){
	       } else {
			     int rc=0;
			     write(fd, &rc, sizeof(int));
	       }
	       //raise(SIGSEGV); // FIXME for debugging...
	       return;
	   }


	   // FIXME
	   pthread_mutex_lock(waitEnvironment->mutex);
	     vector_t *wait_queue = (vector_t *) hashtableGet(waitEnvironment,
			   mutex);

	     int i = vectorSize(wait_queue)-1;
	     for(; i>=0; i--) {
	       supr_thread_t *th=(supr_thread_t *)vectorElementAt(wait_queue,i);
	       if(th->tid == tid){
		 vectorRemoveElement(wait_queue, th);
	         pthread_mutex_lock(&th->mutex);
		   if( cmd == TR_CLUSTER_WAIT_TIMEOUT_EXPR){ // a special case
		     int rc;
                     size = read(fd, &rc, INT_SIZE);
		     if(rc == 0){ 
		       void *ptr = malloc(sizeof(int)+sizeof(double));
		       *((int*)ptr) = rc;
                       size = read(fd, ptr + sizeof(int), sizeof(double));
	               th->data = ptr;
		       if(Supr_options.verbose) {
		         char msg[256];
		         sprintf(msg, "\033[0;35mrc: %d, timeout: %f\033[0m",
					 rc, ((double*)(ptr + sizeof(int)))[0]);
		         verbose_info(msg);
		       }
		     } else { // -1, error
		       int len;
                       size = read(fd, &len, INT_SIZE);
		       void *ptr = malloc(sizeof(int)+len);
		       *((int*)ptr) = rc;
                       size = read(fd, ptr + sizeof(int), len);
	               th->data = ptr;

		       error_info((char*)(ptr + sizeof(int)));
		     }

		   } else 
	             th->data = cmd == TR_CLUSTER_WAIT_TIMEOUT ? PTHREAD_TIMEOUT
			   : PTHREAD_NOTIFIED;

		   if(conn->type==DRIVER_CONN){
		   } else {
			     int rc=0;
			     write(fd, &rc, sizeof(int));
		   }

	           pthread_cond_signal(&th->cond);
	         pthread_mutex_unlock(&th->mutex);
	         break;
	       }
	     }
	     if(i<0) {
	       sprintf(Supr_curErrorBuf,
	         "\033[0;31mtimedwait thread '%d' not found, JOB CANCELLED?\033[0m", tid);
	       error_info(Supr_curErrorBuf);
	       if( cmd == TR_CLUSTER_WAIT_TIMEOUT_EXPR){ // FIXME
		     int rc;
                     size = read(fd, &rc, INT_SIZE);
		     if(rc == 0){ 
		       double timeout;
                       size = read(fd, &timeout, sizeof(double));
		       {
		         char msg[256];
		         sprintf(msg, "\033[0;35mrc: %d, timeout: %f\033[0m",
					 rc, timeout);
		         basic_info(msg);
		       }
		     } else { // -1, error
		       int len;
                       size = read(fd, &len, INT_SIZE);
		       void *ptr = malloc(sizeof(int)+len);
		       *((int*)ptr) = rc;
                       size = read(fd, ptr + sizeof(int), len);
	               error_info((char*) (ptr + sizeof(int)));
		       free(ptr);
		     }

	       }
	       if(conn->type==DRIVER_CONN){
	       } else {
			     int rc=0;
			     write(fd, &rc, sizeof(int));
	       }
	       //raise(SIGSEGV); // FIXME for debugging...
	     }
	   pthread_mutex_unlock(waitEnvironment->mutex);


	 }
	 return;

    case TR_CLUSTER_SYNC: // from task runners
	 {
	   int cmd;
           size_t size = read(fd, &cmd, INT_SIZE);
	   int job_id, tid;
           size = read(fd, &job_id, INT_SIZE);
           size = read(fd, &tid,    INT_SIZE);
	   //if(cmd == TR_CLUSTER_SYNC)
	   {
		   conn->type = JOB_CONN;
		   conn->tid = job_id; // FIXME?
	   }

	   size_t len;
           size = read(fd, &len, SIZE_SIZE);
	   char buf[len];
           size = read(fd, buf, len);

	   if(conn->type == DRIVER_CONN){
	     sprintf(Supr_curErrorBuf,
		     "\033[0;32m[%s:%d:%s] UNEXPECTED, FIXME!",
			 __FILE__, __LINE__, __func__);
	     error_info(Supr_curErrorBuf);
	     sleep(600);
	   }

	   w_job_t *job = NULL;
	   pthread_mutex_lock(jobs->mutex);
	     for(int i=0; i<vectorSize(jobs); i++){
               job = (w_job_t *)vectorElementAt(jobs, i);
	       if(job->id == job_id) break;
	       else job = NULL;
	     }
	   pthread_mutex_unlock(jobs->mutex);

	   if(!job){

		   /* let the main thread to do it
	     pthread_mutex_lock(cancelled_jobs->mutex);
	       for(int i=0; i<vectorSize(cancelled_jobs); i++){
                 job = (w_job_t *)vectorElementAt(cancelled_jobs, i);
	         if(job->id == job_id) {
		   basic_info("\033[0;33mJOB CANCELLED\033[0m");
		   break;
		 }
	         else job = NULL;
	       }
	     pthread_mutex_unlock(cancelled_jobs->mutex);
	   
	     char *mutex = buf;
	     pthread_mutex_lock(syncEnvironment->mutex); // P2. DEAD LOCK?
	     vector_t *sync_queue = (vector_t *)
               hashtableGet(syncEnvironment, mutex);
	     if(!sync_queue || vectorSize(sync_queue)==0){
	        error_info("Error: FIXME, JOB CANCELLED?"); // FIXME
		{
		  supr_thread_t *th= findTaskrunner(tid);
		  if(th){
	            basic_info("Found the TR");
		    main_thread_tasks_add(Sync_queue_cancel, th);
	            basic_info(th->name);
		  } else {
	            basic_info("cannot find the TR");
		  }
		}
	        pthread_mutex_unlock(syncEnvironment->mutex);
		return;
	     }
	     int i = vectorSize(sync_queue)-1;
	     for(; i>=0; i--) {
	       supr_thread_t *th=(supr_thread_t *)vectorElementAt(sync_queue,i);
	       if(th->tid == tid){
		 vectorRemoveElement(sync_queue, th);
		 
		 if(FALSE){
	         pthread_mutex_lock(&th->mutex); //P1. dead lock...use main_thread; See driver::REPL...
	           th->data = JOB_CANCELLED;
	           pthread_cond_signal(&th->cond);
	         pthread_mutex_unlock(&th->mutex);
		 }
		
		 main_thread_tasks_add(Sync_queue_cancel, th);
	         break;
	       }
	     }

	     pthread_mutex_unlock(syncEnvironment->mutex);
	     return;
	     */










             void *data = malloc(2*sizeof(int) + strlen(buf)+1);
	     int *ptr = (int*) data;
	     ptr[0] = job_id;
	     ptr[1] = tid;
	     memcpy(data + 2*sizeof(int), buf, strlen(buf)+1);
	     main_thread_tasks_add(Sync_cancel, data);
	     return;
	   }


	   write(driverServerConn->fd, &cmd,    INT_SIZE);
	   len += 2*sizeof(int);
	   write(driverServerConn->fd, &len, sizeof(size_t));
	   char bytes[len];
	   ((int*) bytes)[0] = job_id;
	   ((int*) bytes)[1] = tid;
	   memcpy(bytes + 2*sizeof(int),  buf, len - 2*sizeof(int));
	   write(driverServerConn->fd, bytes, len);
	   
	   // activate this later ...
	   {
		 int rc;
		 read(driverServerConn->fd, &rc, INT_SIZE);
		 if(Supr_options.debug){
		   char msg[256];
		   sprintf(msg, "Sent cmd: %d (TR_CLUSTER_SYNC=%d), Received rc: %d", cmd, TR_CLUSTER_SYNC, rc);
		   debug_info(msg);
		 }
	   }
	   //
	 }
	 return;

    case TR_CLUSTER_UNSYNC: // from task runners
	 {
		   //basic_info("\033[0;31mTR_CLUSTER_UNSYNC\033[0m");
	
	   int cmd;
           size_t size = read(fd, &cmd, INT_SIZE);

	   int job_id, tid;
           size = read(fd, &job_id, INT_SIZE);
           size = read(fd, &tid,    INT_SIZE);

	   if(cmd == TR_CLUSTER_SYNC){
		   conn->type = JOB_CONN;
		   conn->tid = job_id; // FIXME?
	   }
	 
	   size_t len;
           size = read(fd, &len, SIZE_SIZE);

	   char buf[len];
           size = read(fd, buf, len);

	   if(conn->type == DRIVER_CONN){
	     sprintf(Supr_curErrorBuf,
		     "\033[0;32m[%s:%d:%s] UNEXPECTED, FIXME!",
			 __FILE__, __LINE__, __func__);
	     error_info(Supr_curErrorBuf);
	     sleep(600);
	   }

	   w_job_t *job = NULL;
	   pthread_mutex_lock(jobs->mutex);
	     for(int i=0; i<vectorSize(jobs); i++){
               job = (w_job_t *)vectorElementAt(jobs, i);
	       if(job->id == job_id) break;
	       else job = NULL;
	     }
	   pthread_mutex_unlock(jobs->mutex);

	   
	   int rc;
	   if(job){
		   rc = 0;
		   write(fd, &rc, sizeof(int));
	   } else {
		   rc = -1;
		   write(fd, &rc, sizeof(int));
		   //basic_info("\033[0;31mJOB CANCELLED?\033[0m");
		   return;
		   /*
	     char *mutex = buf;
	     pthread_mutex_lock(syncEnvironment->mutex);
	     vector_t *sync_queue = (vector_t *)
               hashtableGet(syncEnvironment, mutex);
	     if(!sync_queue || vectorSize(sync_queue)==0){
	        error_info("Error: FIXME, JOB CANCELLED?");
		//return;
	     }
	     int i = vectorSize(sync_queue)-1;
	     for(; i>=0; i--) {
	       supr_thread_t *th=(supr_thread_t *)vectorElementAt(sync_queue,i);
	       if(th->tid == tid){
		 vectorRemoveElement(sync_queue, th);
	         pthread_mutex_lock(&th->mutex);
	           th->data = JOB_CANCELLED;
	           pthread_cond_signal(&th->cond);
	         pthread_mutex_unlock(&th->mutex);
	         break;
	       }
	     }

	     pthread_mutex_unlock(syncEnvironment->mutex);
	     return;
	     */
	   }



	   //write(driverConn->fd, msg, 2*INT_SIZE);//change to this or sc2drver
	   write(driverServerConn->fd, &cmd,    INT_SIZE);

	   write(driverServerConn->fd, &job_id, INT_SIZE);
	   write(driverServerConn->fd, &tid,    INT_SIZE);
	   // send string
	   write(driverServerConn->fd, &len, SIZE_SIZE);
	   write(driverServerConn->fd, buf, len);

	   // activate this later ...
	   {
		 int rc;
		 read(driverServerConn->fd, &rc, INT_SIZE);
		 if(Supr_options.debug){
		   char msg[256];
		   sprintf(msg, "Send cmd: %d (TR_CLUSTER_UNSYNC=%d), Received rc: %d", cmd, TR_CLUSTER_UNSYNC, rc);
		   debug_info(msg);
		 }
	   }
	   //
	 }
	 return;

    case TR_CLUSTER_SYNC_RETURN: // from driver
	 {
	   int cmd;
           ssize_t size = read(fd, &cmd, INT_SIZE);
	   int job_id, tid;
           size = read(fd, &job_id, INT_SIZE);
           size = read(fd, &tid,    INT_SIZE);

	   ssize_t len;
           size = read(fd, &len, SIZE_SIZE);

	   char mutex[len];
           size = read(fd, mutex, len);

	   if(conn->type == DRIVER_CONN){// basic_info("From the DRIVER_CONN");
	   } else {
	     int rc = 0;
	     size = write(fd, &rc, INT_SIZE);
	     if(Supr_options.debug){
	       char msg[256];
	       sprintf(msg, "From the DRIVER_CONN'2' (fd: %d), write(fd, &rc, INT_SIZE): %ld (=4?)", fd,size);
	       debug_info(msg);
	     }
	     driver_to_fd = fd;
	   }

	   // FIXME
	   /*
	   pthread_mutex_lock(syncEnvironment->mutex);
	     vector_t *sync_queue = (vector_t *)
               hashtableGet(syncEnvironment, mutex);
	     if(!sync_queue || vectorSize(sync_queue)==0){
	        basic_info("\033[0;32mError: FIXME, JOB CANCELLED?");
	        pthread_mutex_unlock(syncEnvironment->mutex);
		return;
	     }
	     int i = vectorSize(sync_queue)-1;
	     for(; i>=0; i--) {
	       supr_thread_t *th=(supr_thread_t *)vectorElementAt(sync_queue,i);
	       if(th->tid == tid){
		 vectorRemoveElement(sync_queue, th);
		
	         pthread_mutex_lock(&th->mutex);
	           th->data = PTHREAD_SYNCHRONIZED;
	           pthread_cond_signal(&th->cond);
	         pthread_mutex_unlock(&th->mutex);
		 
	         break;
	       }
	     }
	     if(i<0) printf("\033[0;32mFIXME\033[0m\n");

	   pthread_mutex_unlock(syncEnvironment->mutex);
	   */




	   void *data = malloc(2*sizeof(int)+len);
	   int *int_ptr = (int*) data;
	   int_ptr[0] = job_id;
	   int_ptr[1] = tid;
	   memcpy(data + 2*sizeof(int), mutex, len);
	   main_thread_tasks_add(Sync_return, data);
	 }
	 return;

    case TR_CLUSTER_NOTIFY: // from driver
//    case TR_CLUSTER_NOTIFYALL: // from driver
	 {
	   int cmd;
           size_t size = read(fd, &cmd, INT_SIZE);
	 
//	   printf("\033[0;32m[%s:%d:%s] %d: TR_CLUSTER_NOTIFY%s\n", __FILE__, __LINE__, __func__, cmd, cmd == TR_CLUSTER_NOTIFY ? "":"ALL");
	   size_t len;
           size = read(fd, &len, SIZE_SIZE);

//	   printf("\033[0;32m[%s:%d:%s] mutex.length: %ld\n", __FILE__, __LINE__, __func__, len);
	   char mutex[len];
           size = read(fd, mutex, len);
//	   printf("\033[0;32m[%s:%d:%s] mutex: %s\n", __FILE__, __LINE__, __func__, mutex);
	   
	   pthread_mutex_lock(waitEnvironment->mutex);
	     vector_t *wait_queue = (vector_t *) hashtableGet(waitEnvironment,
			   mutex);
//	     printf("\033[0;32m[%s:%d:%s] threads: %s\033[0m\n", __FILE__, __LINE__, __func__, objectToString(wait_queue));
//	     printf("\033[0;32m[%s:%d:%s] conn->fd: %d\033[0m\n", __FILE__, __LINE__, __func__, conn->fd);
	     //int i = vectorSize(wait_queue)-1;
	     if(vectorSize(wait_queue)){
	       int i = 0;
	     //for(; i>=0; i--) {
	       supr_thread_t *th=(supr_thread_t *)vectorElementAt(wait_queue,i);
	       //if(th->tid == tid){
		 vectorRemoveElement(wait_queue, th);
	         pthread_mutex_lock(&th->mutex);
	           th->data = PTHREAD_TIMEOUT;
	           pthread_cond_signal(&th->cond);
	         pthread_mutex_unlock(&th->mutex);
	         //break;
	       //}
	     //}
	     }
	     //if(i<0) printf("\033[0;31m[%s:%d:%s] FIXME\033[0m\n", __FILE__, __LINE__, __func__);
	   pthread_mutex_unlock(waitEnvironment->mutex);

	   if(conn->type==DRIVER_CONN){
	   } else {
		   //basic_info("write(fd, &rc, sizeof(int))");
		   int rc=0;
		   write(fd, &rc, sizeof(int));
	   }

	 }
	 return;

    case CLUSTER_GET_CONTEXT:
         Worker_handleGetContext(conn);
	 return;

    case CLUSTER_SET_NTRS:
         //Worker_setNTaskrunners(conn);
	 {
	   int cmd;
	   int *data = (int *)malloc(sizeof(int)+sizeof(double));
           size_t size = read(fd, &cmd, INT_SIZE);
//	   printf("cmd: %d\n", cmd);
           size = read(fd, data, INT_SIZE);
//	   printf("sub_cmd: %d\n", data[0]);
	   if(data[0] == 0){
	   } else if(data[0] == 1){
             size = read(fd, data+1, INT_SIZE);
//	     printf("n_trs: %d\n", data[1]);
	   } else {
             size = read(fd, data+1, sizeof(double));
//	     printf("r: %f\n", ((double *)(data + 1)));
	   }
	   //
	   thread_info_t *info = (thread_info_t *)
		       malloc(sizeof(thread_info_t)); // free?
	   info->type = SET_NTRS;
	   info->data = data;

	   int nTaskRunners = 0;
	   
	   for(int i=0; i< vectorSize(executors); i++){
             supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
//	     printf("[%s] thread_state: %d\n", __func__, th->state);
	     pthread_mutex_lock(&th->mutex);
	       //thread_info_t *info = (thread_info_t *)
		 //      malloc(sizeof(thread_info_t)); // free?
	       //info->type = SET_NTRS;
	       //info->data = malloc(sizeof(int)+sizeof(double));
	       //memcpy(info->data, data, sizeof(int)+sizeof(double));
	       th->data = info;
	       pthread_cond_signal(&th->cond);
	       pthread_cond_wait(&th->cond, &th->mutex);
	       nTaskRunners += ((int*) info->data)[0];
	     pthread_mutex_unlock(&th->mutex);
	   }
	   free(data);
	   free(info);
	   cmd = 0;
	   write(fd, &nTaskRunners, INT_SIZE); // FIXME

	   // ...
	 }
	 return;

    case CLUSTER_WORKER_NULL:
	 {
           int cmd;
           size_t size = read(fd, &cmd, INT_SIZE);
           //fprintf(stderr, "cmd: %d\n", cmd);
           write(fd, &cmd, INT_SIZE);
           read(fd, &cmd, INT_SIZE);
           //fprintf(stderr, "cmd: %d\n", cmd);
	 }
	 return;

    case TR_PRINT_STDOUT:
    case TR_PRINT_STDERR: // FIXME
	 {
           int cmd, pid;
           size_t size = read(fd, &cmd, INT_SIZE);
           fprintf(stdout, "cmd: %d\n", cmd);
           size = read(fd, &pid, INT_SIZE);
           fprintf(stdout, "pid: %d\n", pid);
	   conn->type = TR_PRINT_STDOUT; // FIXME
	   conn->pid = pid;

	  
          //   Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);
	   
	   Output_addTaskrunner(conn);
	   /*
	   {
	     int flags =1;
	     int rc = setsockopt(conn->fd, SOL_TCP, TCP_NODELAY,
                      (void *)&flags, sizeof(flags));
	     if(rc == -1) perror("setsockopt");
	   }
	   */

	   char path[PATH_MAX];
	   sprintf(path, "%s/%d", Worker_dir, pid);
	   if(access(path, F_OK) == 0){
	     char link[PATH_MAX];
	     sprintf(link, "%s/tr%d", Worker_dir, ++Taskrunner_sdl_count);
	     int rc = symlink(path, link);
	   }

	 }
	 return;

    case CLUSTER_CONTEXT_OBJECTS:
         {
           handleClusterList(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_EXISTS:
         {
           handleClusterExists(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_PUT:
         {
           handleClusterAssign(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_GET:
         {
           handleClusterContextGet(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_DOCALL:
         {
           handleClusterContextDoCall(conn, SuprEnv);
         }
         return;

   case INFO_SERVER_REGISTER:
         {
           read(fd, &cmd, INT_SIZE);
           int len;
           read(fd, &len, INT_SIZE);
           char buf[len];
           read(fd, buf, len);

           free((char*)info_addr);
           info_addr = strdup(buf);

           basic_info(buf);
           basic_info("\033[0;36mClosing info_sc ...\033[0m");
           pthread_mutex_lock(&Supr_syncMutex);
             if(info_sc){
               close(info_sc->fd);
               free(info_sc);
               info_sc = NULL;
             }
             if(strstr(buf, ":")) {
               info_sc = trySocketOpen1(buf);
               if(info_sc){
                 Supr_registerSocketServer(socketServerConn, info_sc);
                 cmd = CLUSTER_PROC_CMD;
                 write(info_sc->fd, &cmd, sizeof(int));
                 len = strlen(proc_cmd)+1;
                 write(info_sc->fd, &len, sizeof(int));
                 write(info_sc->fd, proc_cmd, len);
                 int rc;
                 read(info_sc->fd, &rc, sizeof(int));
               }
             }
           pthread_mutex_unlock(&Supr_syncMutex);
           int rc = 0;
           write(fd, &rc, INT_SIZE);
         }
         return;


    case CLUSTER_PING:
         {
           read(fd, &cmd, INT_SIZE);
           int cmd = CLUSTER_PONG;
           write(fd, &cmd, INT_SIZE);
         }
         return;

    case CLUSTER_EXECUTOR_REGISTER:
         {
           read(fd, &cmd, INT_SIZE);
	   conn->type = EXECUTOR_CONN;
	   pid_t tid;
           read(fd, &tid, INT_SIZE);
	   conn->pid = tid;
         }
         return;

    case CLUSTER_TASKRUNNER_REGISTER:
         {
           read(fd, &cmd, INT_SIZE);
	   conn->type = TASKRUNNER_CONN;
	   pid_t tid;
           read(fd, &tid, INT_SIZE);
	   conn->pid = tid;
         }
         return;


    case SET_CONN_PID:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
           int pid;
           read(fd, &pid, sizeof(int));
           conn->pid = pid;
           int type;
           read(fd, &type, sizeof(int)); // ?
           conn->type = type;
	   //int rc = 0; write(fd, &rc, sizeof(int)); // ?
         }
         return;

    case CLUSTER_INFO:
         {
           read(fd, &cmd, INT_SIZE);
           char buf[8]; read(fd, buf, sizeof(buf));
           int type;    read(fd, &type, sizeof(int));
           int level;   read(fd, &level, sizeof(int));
           ssize_t size;read(fd, &size, sizeof(ssize_t));
           char buffer[128];
           //sprintf(buffer,"%s<%s>", color, conn->host);
           sprintf(buffer,"%s<%d>", buf, conn->pid);
           char *color = buffer;

           unsigned char *msg = malloc(size+2*strlen(color));
           read(fd, msg+strlen(color), size);
           memcpy(msg, color, +strlen(color));
           memcpy(msg+strlen(msg), "\033[0m", strlen("\033[0m")+1);

           //Cluster_sendSimpleMessage(msg, buf, type, drievr_info_sc); ???
           Cluster_sendSimpleMessage(msg, buf, type, level);
        
           int rc = 0;
           write(fd, &rc, sizeof(int));
           free(msg);
         }
         return;

    case CLUSTER_MSG_SEND_TO_TR:
	 {
           read(fd, &cmd, sizeof(int));
	   int len_trAddr;
           read(fd, &len_trAddr, sizeof(int));
	   char trAddr[len_trAddr];
           read(fd, trAddr, len_trAddr);

	   //basic_info(trAddr);
	   int tr_pid = atoi(strstr(trAddr, "#")+1);

           int header[3];
           read(fd, header, sizeof(header));
           int len_addr = header[1];
           int len_raw = header[2];
	   // {CLUSTER_MSG_SEND_TO_TR, tr_pid}
	   len_trAddr = 2*sizeof(int);
           void *msg = malloc(len_trAddr + sizeof(header) + len_addr+len_raw);

	   ((int*) msg)[0] = CLUSTER_MSG_SEND_TO_TR;
	   ((int*) msg)[1] = tr_pid;

           memcpy(msg+len_trAddr, header, sizeof(header));
           read(fd, msg+len_trAddr+sizeof(header), len_addr);
           ssize_t size = read(fd, msg+len_trAddr+sizeof(header)+len_addr,
			   len_raw);
           int rc = 0;
           write(fd, &rc, sizeof(int));

	   { // TODO basic_info("TODO");
	     // host:port#tr_pid  (not thread tid)
             pthread_mutex_lock(messages->mutex); 
               vectorAdd(messages, msg);
	       if(messages_cond) pthread_cond_broadcast(messages_cond);
             pthread_mutex_unlock(messages->mutex);
	   }
	 }
         return;

    case CLUSTER_MSG_SEND:
         {
		 error_info("Unexpected command, FIXME");

           int header[3];
           read(fd, header, sizeof(header));
           int len_addr = header[1];
           int len_raw = header[2];
           void *msg = malloc(sizeof(header) + len_addr+len_raw);
           memcpy(msg, header, sizeof(header));
           read(fd, msg+sizeof(header), len_addr);
           ssize_t size = read(fd, msg+sizeof(header)+len_addr, len_raw);
           int rc = 0;
           write(fd, &rc, sizeof(int));

	   /*
	   {
	     char buf[256];
	     sprintf(buf, "conn_type: %s", connTypeToStr(conn->type));
	     basic_info(buf);
	   }
	   */

	   char *addr = (char*) msg+sizeof(header);

	   if(conn->type == TASKRUNNER_CONN){
	     for(int i=vectorSize(socket_connections)-1; i>=0; i--){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
		     vectorElementAt(socket_connections, i);
	       if(sc->type == DRIVER_CONN){
                 int flags = fcntl(fd, F_GETFL); // FIXME
	         if(flags & O_NONBLOCK){
		       fcntl(fd, F_SETFL, flags & ~O_NONBLOCK); 
	         }
	         write(sc->fd, msg, sizeof(header) + len_addr+len_raw);
	         read(sc->fd, &rc, sizeof(int));
	       }
	     }
	     free(msg);
	   } else if(addr && strstr(addr, ":")){ // TODO
	     free(msg);
	   } else { // to taskrunners?
             pthread_mutex_lock(messages->mutex); 
               vectorAdd(messages, msg);
             pthread_mutex_unlock(messages->mutex);
	   }

         }
         return;

    case CLUSTER_MSG_BROADCAST:
         {
           int header[3];
           ssize_t size = read(fd, header, sizeof(header));
	   int len = header[2];
	   void *ptr = malloc(3*sizeof(int)+len);
           size += read(fd, ptr + 3*sizeof(int), len);
	   memcpy(ptr, header, 3*sizeof(int));
	   if(conn->type == DRIVER_CONN){
	     if(size != 3*sizeof(int)+len)
		   basic_info("size != 3*sizeof(int)+len");
	   } else {
	     int rc = 0;
	     size += write(fd, &rc, sizeof(int));
	     if(size != 4*sizeof(int)+len)
		   basic_info("size != 4*sizeof(int)+len");
	     //basic_info("Use worker-to connection!");
	   }

	   int job_id = header[1];
	   w_job_t *job = NULL;
           pthread_mutex_lock(jobs->mutex);
	     for(int i=vectorSize(jobs)-1; i>=0; i--){
	       w_job_t *j = (w_job_t*)vectorElementAt(jobs, i);
	       if(j->id == job_id) {
		 job = j;
		 break;
	       }
	     }
           pthread_mutex_unlock(jobs->mutex);
	   
	   if(job) {

#define USE_SHM_FOR_CLUSTER_MSG_BROADCAST
#ifdef  USE_SHM_FOR_CLUSTER_MSG_BROADCAST

             //broadcast_lock_t *bc = (broadcast_lock_t *) bc_shm_ptr;
             broadcast_lock_t *bc = job->bc;
	     pthread_rwlock_wrlock(&bc->rwlock);

               //char shm_name[256]; // synchronize???
	       //sprintf(shm_name, "%s-%d-bc", shm_prefix, getpid());
	       if(bc->destroy){
	         basic_info("bc->destroy");
	       } else {
	         char *shm_name = bc->shm_name;
	         //basic_info(shm_name);
	         {
	           void *ptr = Supr_shm_open(shm_name, &size);
	           if(ptr){
                     munmap(ptr, size);
		     shm_unlink(shm_name);
	           }
	         }
	         size = 3*sizeof(int)+len;
	         void *memptr = Supr_shm_create(shm_name, size);
	         memcpy(memptr, ptr, size);
                 munmap(memptr, size);

	         bc->bc_id++;
	       }
	     pthread_rwlock_unlock(&bc->rwlock);

	     pthread_mutex_lock(&bc->mutex);
	       pthread_cond_broadcast(&bc->cond);
	     pthread_mutex_unlock(&bc->mutex);

	     if(Supr_options.verbose){
	       char msg[256];
	       sprintf(msg, "Received broadcasted variables, updated id: %ld",
			       bc->bc_id);
	       verbose_info(msg);
	     }

#endif

	   } else {
		   char buf[256];
		   sprintf(buf, "cannot find job %d", job_id);
		   error_info(buf);
	   } 

	   if(Supr_options.verbose)
	     verbose_info("Received broadcast message");
         }
         return;


    case HTTP_GET:
	 handleHTTP_GET(conn);
         break;

    case HTTP_POST:
	 handleHTTP_POST(conn);
         break;

	 /*
    case TASKRUNNER_CONN: 
	 {
           int cmd, pid;
           size_t size = read(fd, &cmd, INT_SIZE);
           size = read(fd, &pid, INT_SIZE);
	   fprintf(stderr, "[TASKRUNNER_CONN] pid: %d\n", pid);
	   conn->type = TASKRUNNER_CONN;
	 }
	 break;
	 */

	 /*
    case CLUSTER_JOB_REMOVE:
	 {
           int cmd, job_id;
           size_t size = read(fd, &cmd, INT_SIZE);
           size = read(fd, &job_id, INT_SIZE);
	   fprintf(stderr, "[CLUSTER_JOB_REMOVE] job_id: %d\n", job_id);
	   removeJob(job_id);
	 }
	 return;
	 //break;
	 */

    case CLUSTER_MALLOC_PRINT:
	 {
           int cmd;
           ssize_t size = read(fd, &cmd, INT_SIZE);
	   fprintf(stderr, "\033[0;32m"); 
	   Worker_dumper(); // FIXME?
	   MALLOC_PRINT;
	   fprintf(stderr, "\033[0m"); 
	 }
	 return;

    default:
	 {
	 printf("\033[0;31m[%s:%d:%s] unknown cmd %d\n", 
			 __FILE__, __LINE__, __func__, cmd);
	 // message:
	 //fprintf(stderr, "\033[0;31m[%s:%d:%s] unknown cmd %d\033[0m\n", __FILE__, __LINE__, __func__, cmd);
//	 break;
         char c;

         while(TRUE){
           size_t size = recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT);
           if(size == -1){
	     printf("[%s] size = -1, no data ? %s\n", __func__, strerror(errno));
	     if(errno == EBADF){
               printf("\033[0;31m[%s] fd = %d is disconnected\033[0m\n", __func__, fd);
               vectorRemoveElement(socket_connections, conn);
               socketDestroy(conn);
	     }
	     return;
           } else if(size == 0){
	     printf("[%s] size = 0,  %s\n", __func__, strerror(errno));
           } else {
	     read(fd, &c, 1);
	     printf(" %0x", c);
           }
         }
       }
       break;
  }

  //return;
}

extern size_t fileWrite(const char*, char *, size_t);
extern char *fileRead(const char* file); 
extern supr_socket_conn_t *socketOpen2(const char *host, int port);

void  pthread_key_destructor(void *data)
{
	printf("[%s] data= %p\n", __func__, data);
}

shm_io_info_t *master_io = NULL;

/*
SEXP Worker_startMaster(const char *port, int *master_port)
{
  if(!SUPR_HOMESYS) suprHomeInit();

  char shm_name[128];
  sprintf(shm_name, "supr.master-%d-%d",geteuid(), getpid());
  printf("[%d] %s\n", getpid(), shm_name);

  //SEXP shm_conn = R_shmCreate
  size_t block_size = sysconf(_SC_PAGE_SIZE);
  shm_io_info_t *io = shm_io_create(shm_name, block_size);

  master_io = io;

  SEXP r_io = PROTECT(R_MakeExternalPtr(io, null, null));
  setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
  setAttrib(r_io, R_NameSymbol, mkString(shm_name));
  UNPROTECT(1);


  pid_t pid = fork();
  if(pid) {
    fprintf(stderr, "%s: proc %d is to run \"%s\"\n", __func__, pid, "driver");
    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: \"%s\"\033[0m\n", (char*) ptr);
    ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: serverSocket: port = %d\033[0m\n",
                    ((int*) ptr)[0]);
    *master_port = ((int*) ptr)[0];
    return r_io;
  }

  char CMD_PATH[PATH_MAX];
  sprintf(CMD_PATH, "%s/master", SUPR_HOMESYS);
  printf("[%s] cmd path: %s\n", __func__,  CMD_PATH);

  //const char *port = CHAR(asChar(sport));

  int rc = execl(CMD_PATH, "master",
                  "-port", port,
                  "-shm", shm_name,
          (char*) NULL);

  printf("[%s] run master: rc =  %d, %s\n", __func__, rc, strerror(errno));

  exit(0);

//  SEXP conn = connectDriver(SEXP hostname, SEXP sport)
}
*/


void backend_run_cleanup(void *data)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}
// subdir
int backend_run(int port, char *master_addr)
{

  {
      sigset_t sig_set;
      sigemptyset(&sig_set);
      //sigaddset(&sig_set, SIGINT);
      sigaddset(&sig_set, SIGCHLD);
      pthread_sigmask(SIG_BLOCK, &sig_set, NULL);
  }

  pthread_cleanup_push(backend_run_cleanup, NULL);

  char buf[256];
  sprintf(buf, "[%s:%d:%s:%s]", __FILE__, __LINE__, __func__, __host__);
  Cluster_sendSimpleMessage(buf, "\033[0;31m", VERBOSE_INFO_TYPE, 0);

  //int reuse_addr = port ? SocketConn_reuseAddr : FALSE;
  //supr_socket_conn_t *serverConn = serverSocketOpen(port, reuse_addr);
  verbose_info("port: %s:%d%s", Supr_hostname, port, nports?"":"+");

  supr_socket_conn_t *serverConn = serverSocketOpen3(port, nports, cmd);

  if(!serverConn){
    basic_info("cannot start socket server");
    exit(EXIT_FAILURE);
  }

  socketServerConn = serverConn;

  Supr_options.port = serverConn->port;


  serverConn->type = WORKER_CONN;

  sprintf(buf, "[%s:%d:%s:%s]", __FILE__, __LINE__, __func__, __host__);
  Cluster_sendSimpleMessage(buf, "\033[0;31m", VERBOSE_INFO_TYPE, 0);

  if(notify_addr){
    char *host = strdup(notify_addr);
    char *s = strstr(host, ":");
    if(s){
            *s = 0; s++;
            int port = atoi(s);
            supr_socket_conn_t *sc = socketOpen2(host, port);
	    if(sc){
            int cmd = CLUSTER_WORKER_STARTED;
            write(sc->fd, &cmd, sizeof(int));
            char buf[strlen(serverConn->host)+32];
            sprintf(buf, "%s:%d", serverConn->host, serverConn->port);
            int len = strlen(buf)+1;
            write(sc->fd, &len, sizeof(int));
            write(sc->fd, buf, len);
            int rc;
            read(sc->fd, &rc, sizeof(int));
            sprintf(msg, "Sent worker_addr %s to %s", buf, notify_addr);
            Cluster_sendSimpleMessage(msg, "\033[0;37m", VERBOSE_INFO_TYPE, 0);
            close(sc->fd);
            free(sc);
	    }
    }
    free(host);
  }



  if(!serverConn){
    printf("Error: %s\n", strerror(errno));
    exit(1);
  }

  workerServerConn = serverConn; // FIXME?

  workerServerConn->mutex = (pthread_mutex_t*)
	  malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(workerServerConn->mutex, NULL);

  {
    scToBackend = socketOpen(workerServerConn);
    scToBackend->mutex = malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(scToBackend->mutex, NULL);

    int msg[] = {SET_CONN_PID, (int)syscall(SYS_gettid), WORKER_CONN};
    write(scToBackend->fd, msg, sizeof(msg));
    
  }


  {
	  /*
    char fileName[strlen(SUPR_HOMEUSR)+strlen("/worker.log")+1];
    sprintf(fileName, "%s/worker.log", SUPR_HOMEUSR);
    */
    char fileName[strlen("worker.log")+1];
    sprintf(fileName, "worker.log");
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\npid:%d\n", serverConn->port, getpid());
    size_t size = fileWrite(fileName, buf, strlen(buf)+1);

//printf("[%s:%s] OKAY 2: buf value=%s (pid=%d, tid=%ld)\n", __FILE__,	__func__, buf, getpid(), syscall(SYS_gettid));
  }



  socket_connections = newVector(TRUE);
  vectorAdd(socket_connections, serverConn); 

  /*
  {
    pthread_key_t key;
    printf("[%s] sizeof(key) = %ld\n", __func__, sizeof(key));
    pthread_key_create(&key, pthread_key_destructor);
    pthread_setspecific(key, serverConn);
//    pthread_key_delete(key);
    printf("[%s] serverConn = %p\n", __func__, serverConn);
  }
  */

  //printf("FOPEN_MAX = %d\n", FOPEN_MAX);
  //printf("_SC_OPEN_MAX = %ld\n", sysconf(_SC_OPEN_MAX));

  // connect master
  //supr_socket_conn_t * master_conn = NULL;
  {
    char *addr = NULL;
    if(master_addr){
      addr = master_addr;
    } else {
      char fileName[strlen(SUPR_HOMEUSR)+strlen("/master.log")+1];
      sprintf(fileName, "%s/master.log", SUPR_HOMEUSR);
      char buf[1024];
      sprintf(buf, "//");
      int len = gethostname(buf+2, 1022);
      sprintf(buf + strlen(buf), ":%d\n", serverConn->port);
      addr = fileRead(fileName);
    }
  
    if(addr){
      char *str = strstr(addr, ":");
      int master_port = atoi(str+1);
      *str = 0;
      char *host = strstr(addr, "//") ? strstr(addr, "//")+2 : addr;

//      printf("Connect master: %s:%d\n", host, master_port);

      master_conn = socketOpen2(host, master_port);
     
      if(master_conn && master_conn->fd != -1)
      {
	   {
	     int flags =1;
	     int rc = setsockopt(master_conn->fd, SOL_TCP, TCP_NODELAY,
                      (void *)&flags, sizeof(flags));
	     if(rc == -1) perror("setsockopt");
	   }
//#define MASTER_CONN 3
	  master_conn->type = MASTER_CONN;
	  master_conn->port = master_port;
//#undef MASTER_CONN
//#define WORKER_REGISTER 12
	  int msg[] = {WORKER_REGISTER, serverConn->port};
	  int size = write(master_conn->fd, msg, sizeof(msg));
//	  printf("[Driver:%s] size = %d (%ld)\n", __func__, size, sizeof(msg));
	  if(size == -1){
	    printf("[Driver:%s] Error,  %s\n", __func__, strerror(errno));
	    // destroy?
	    master_conn = NULL;
	  } else {
            vectorAdd(socket_connections, master_conn); 
	  }
//#undef WORKER_REGISTER
      }
      //if(addr != master_addr) free(addr);
      //connections[conn->fd] = (supr_conn_t*) conn;
    }


    if(!master_conn){
	    printf("Error: couldn't connect to master\n");
	    system_exit(1);
	    /*
      BEGIN_R_EVAL();

//      printf("\n\033[0;33mstartMaster:\n");
	int master_port;
        SEXP shm_conn = startMaster("0", &master_port);
//      printf("\n\033[0;33mstartMaster master_port = %d:\n", master_port);
        PrintValue(shm_conn);
        defineVar(install("shm_conn"), shm_conn, R_GlobalEnv);
//      printf("\033[0m\n");

        master_conn = socketOpen2("localhost", master_port);
        if(master_conn && master_conn->fd != -1)
	{
//          vectorAdd(socket_connections, master_conn); 
//#define MASTER_CONN 3
	  master_conn->type = MASTER_CONN;
	  master_conn->port = master_port;
//#undef MASTER_CONN
//#define WORKER_REGISTER 12
	  int msg[] = {WORKER_REGISTER, serverConn->port};
	  int size = write(master_conn->fd, msg, sizeof(msg));
//	  printf("[Driver:%s] size = %d (%ld)\n", __func__, size, sizeof(msg));
	  if(size == -1){
	    printf("[Driver:%s] Error,  %s\n", __func__, strerror(errno));
	    // destroy?
	    master_conn = NULL;
	  } else {
            vectorAdd(socket_connections, master_conn); 
	  }
//#undef WORKER_REGISTER
	}

      END_R_EVAL();
      */


    }

  }

  /* Don't do this because it can close info_sc unintentionally...
  if(info_sc){
    info_sc->type = INFO_CONN;
    vectorAdd(socket_connections, info_sc);
  }
  */

  parent_sc = master_conn;

  master_conn->mutex = (pthread_mutex_t*) malloc(sizeof(pthread_mutex_t)); 
  pthread_mutex_init(master_conn->mutex, NULL);

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);

  supr_thread_t *cth = SUPR_CURRENT_THREAD();

  while(TRUE) {
      struct timeval tv;
      tv.tv_sec=1000;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      //int fd = serverConn->fd;
      int max_fd = 0;

      // lock ...  printf("\n");
      for(int i=0; i<vectorSize(socket_connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 

	//conn->print(conn);
        int fd = conn->fd;
        FD_SET(fd, &readfds);

	if(fd > max_fd) max_fd = fd;
      }



      cth->where = "backend_run: select(...)"; // ifdef DEBUG?
      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      cth->where = NULL;

      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /*  else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(serverConn->fd, &readfds) = %d\n", __func__,
               FD_ISSET(serverConn->fd, &readfds));
      }*/ 

      for(int i = vectorSize(socket_connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
	       	continue;

	if(conn == serverConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(serverConn);
	  
	  char msg[256];
          sprintf(msg, "\033[0;34mNewConn, host: %s, fd: %d\033[0m",
			  clientConn->host, clientConn->fd);
	  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

	  if(clientConn && clientConn->fd != -1){
            vectorAdd(socket_connections, clientConn); 
	  }
	} else {
          handleCommand(conn);
	}
      }

      //sleep(1);
  }



  sleep(60);
//  int k = FOPEN_MAX;


  pthread_cleanup_pop(TRUE);
  return 0;

}

//extern supr_thread_t *newThread(pthread_t ptid, pid_t, pid_t tid, int state);

void *backend_init(void *arg)
{
  //if(debug_sc) {
	/*
    struct sigaction sa;
    struct sigaction R_oldSigBacktraceAct; // FIXME
    sa.sa_sigaction = Thread_SigactionBacktrace;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIG_BACKTRACE, &sa, &R_oldSigBacktraceAct);
    */
  //}

  void *data = (void*) ((void **)arg)[0];
  char *master_addr = (char *) ((void **)arg)[1];
  sem_t *sem = (sem_t *) ((void **)arg)[2];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[3];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;

  free(th->name);
  char name[256];
  sprintf(name, "backend.%d", gettid());
  th->name = strdup(name);
  th->state = THREAD_STATE_RUNNABLE;

  pthread_mutex_lock(sys_threads->mutex);
    vectorAdd(sys_threads, th);
  pthread_mutex_unlock(sys_threads->mutex);

  pthread_setspecific(currentThreadKey, th);

  int port = ((int*)data)[0];
  //printf("[%s] port = %d, master_addr: %s\n", __func__, port, master_addr);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  backend_run(port, master_addr);

  pthread_exit(th);
  return NULL;
}

SEXP jobSubmit(SEXP);
SEXP help(SEXP);

typedef struct callable_struct {
  char *name;
  char *par_names;
  SEXP (*func)(SEXP args); // args: pairlist
  char *doc;
} callable_t;

/*
callable_t R_callable_functions[] =
{
  { "help",   "(topic)",   help, "..." },
  { "submit", "(expr, data, ...)", jobSubmit, "..." },
};

SEXP jobSubmit(SEXP args){
  return R_NilValue;
}

SEXP help(SEXP topic){
  if(TYPEOF(topic) == NILSXP){
    return mkString("TO DO");
  } else {

    PrintValue(topic);

    const char *name = CHAR(asChar(topic));
    for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
      if(strcmp(R_callable_functions[i].name, name)==0){
        return mkString(R_callable_functions[i].doc);
      }
    }
    errorcall(R_NilValue, "no doc is available on '%s'", name);
    return R_UnboundValue;

  }
}
*/

supr_thread_t *startTaskrunner(supr_thread_t *executor);

void executor_run_cleanup(void *data)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}

// make nTaskrunners a global variable?
void executor_run(int nTaskrunners)
{
  {
      sigset_t sig_set;
      sigemptyset(&sig_set);
      //sigaddset(&sig_set, SIGINT);
      sigaddset(&sig_set, SIGCHLD);
      pthread_sigmask(SIG_BLOCK, &sig_set, NULL);
  }


  pthread_cleanup_push(executor_run_cleanup, NULL);
  //workerServerConn = serverConn;
  
  supr_thread_t *currentThread = (supr_thread_t *)
		  pthread_getspecific(currentThreadKey);
#define WAIT_FOR_DRIVER
#ifdef  WAIT_FOR_DRIVER
  //printf("executor: Waiting for driver connection...\n");
  //message:


  /* start the executor before the backend ... */
  fprintf(stderr, "%s:%d: Waiting for driver connection...\n", __func__, __LINE__);
  /*
  pthread_mutex_lock(&currentThread->mutex);
    //message:
    fprintf(stderr, "%s:%d: locked\n", __func__, __LINE__);
    currentThread->data = NULL;
    pthread_cond_wait(&currentThread->cond, &currentThread->mutex);
    //currentThread->state = THREAD_STATE_RUNNABLE;
    if(currentThread->data ==  driverServerConn)
    {
      printf("currentThread->data ==  driverServerConn\n");
    }
    else 
    {
      printf("Hmm: currentThread->data !=  driverServerConn\n");
    }
    
  pthread_mutex_unlock(&currentThread->mutex);
  */
  pthread_mutex_lock(&driverServerInitMutex);
    if(!driverServerConn)
      pthread_cond_wait(&driverServerInitCond, &driverServerInitMutex);
  pthread_mutex_unlock(&driverServerInitMutex);
  //printf("executor: continue\n");
  //message:
  fprintf(stderr, "%s:%d: continue\n", __func__, __LINE__);
#endif

  // wait if no workerServerConn
  int i = 0;
  for(;;){
    if(workerServerConn)
	    break;
    i++;
    if(i>1) {
	    printf("Waiting for worker connection...\n");
    }
    sleep(1);
  }

  supr_socket_conn_t *sc2worker = NULL; // not used anymore? deprecated ...
  if(workerServerConn) { // sync ...
    sc2worker = socketOpen(workerServerConn);
    int cmd=CLUSTER_EXECUTOR_REGISTER;
    write(sc2worker->fd, &cmd, sizeof(int));
    pid_t tid = gettid();
    write(sc2worker->fd, &tid, sizeof(int));
  }

  supr_socket_conn_t *sc2driver = NULL;

  // wait if no driverServerConn
  i = 0;
  for(;;){
    if(driverServerConn)
	    break;
    i++;
    if(i>1) {
	    printf("Waiting for driver connection...\n");
    }
    sleep(1);
  }
  printf("driver: //%s:%d\n", driverServerConn->host, driverServerConn->port);

  if(driverServerConn) {
//    printf("[%s] executor to driver conn: //%s:%d\n", __func__, driverServerConn->host, driverServerConn->port);
    sc2driver = socketOpen(driverServerConn);
    int cmd=CLUSTER_EXECUTOR_REGISTER;
    write(sc2driver->fd, &cmd, sizeof(int));
    pid_t tid = gettid();
    write(sc2driver->fd, &tid, sizeof(int));
  }

  if(sc2worker){
    sc2worker->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(sc2worker->mutex, NULL);
  }
  if(sc2driver){
    sc2driver->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(sc2driver->mutex, NULL);
  }

//  supr_thread_t *currentThread = (supr_thread_t *)
//		  pthread_getspecific(currentThreadKey);

  executor_property_t *properties = (executor_property_t *)
	  malloc(sizeof(executor_property_t));
  currentThread->properties = properties;
  properties->sc2driver = sc2driver;
  properties->sc2worker = sc2worker;
  properties->taskrunners = NULL;


  pthread_mutex_lock(&currentThread->mutex);
    //  pthread_cond_wait(&currentThread->cond, &currentThread->mutex);
    currentThread->state = THREAD_STATE_RUNNABLE;
  pthread_mutex_unlock(&currentThread->mutex);

  //vector_t *taskrunners = newVector(FALSE);
  vector_t *taskrunners = newVector(TRUE);
  properties->taskrunners = taskrunners;
  //printf("[%s] %s\n", taskrunners->class->toString(taskrunners->class, taskrunners));
  // checking..
  for(int i=0; i<nTaskrunners; i++){
    supr_thread_t *tr = startTaskrunner(currentThread);
    vectorAdd(taskrunners, tr);

    pthread_mutex_lock(tr_threads->mutex);
      vectorAdd(tr_threads, tr);
    pthread_mutex_unlock(tr_threads->mutex);
  }

  while(TRUE){

    while(vectorSize(taskrunners) < nTaskrunners){
      supr_thread_t *tr = startTaskrunner(currentThread);
      vectorAdd(taskrunners, tr);

      pthread_mutex_lock(tr_threads->mutex);
        vectorAdd(tr_threads, tr);
      pthread_mutex_unlock(tr_threads->mutex);
    }

    int isInterrupted = FALSE;

    pthread_mutex_lock(&currentThread->mutex);
      currentThread->state = THREAD_STATE_WAITING;
      currentThread->data = NULL;
      currentThread->where = "executor_run: pthread_cond_wait(...)";
      pthread_cond_wait(&currentThread->cond, &currentThread->mutex);
      currentThread->where = NULL;

      thread_info_t *info = (thread_info_t *) currentThread->data;
      currentThread->data = NULL;
      if(!info){
        pthread_mutex_unlock(&currentThread->mutex);
	continue;
      }

      if(info->type == INTERRUPT){
	isInterrupted = TRUE;
      }

      currentThread->state = THREAD_STATE_RUNNABLE;

      if(info->type == NEW_JOB){
        void *object = info->data; // currentThread->data;
        if(object){
          class_t *class = NULL; (class_t*) ((void **) object)[0]; //class_t *
	  class = ((object_t*)object)->class;
          const char *str = class->toString(class, object);

	  if(class == WorkerJob_class){
            if(driverServerConn && sc2driver == NULL) 
	    {
	      for(int i=0; ; i++) {
                sc2driver = socketOpen(driverServerConn);
	        if(sc2driver == NULL) {
		  if(i>1) printf("%d: Connecting to driver...\n", __LINE__);
	          sleep(1);
	        }
	        else break;
	      }
	    }
            properties->sc2driver = sc2driver;
	    debug_info("NEW_JOB");

	    for(int i=vectorSize(taskrunners)-1; i>=0; i--) {
              supr_thread_t *tr=(supr_thread_t *)vectorElementAt(taskrunners,i);
	      class_t *class = classOf(tr);

	      if(tr->state == THREAD_STATE_TERMINATED){
	        void *val;
                pthread_join(tr->ptid, &val);

		if(val == PTHREAD_CANCELED)
			basic_info("THREAD_TERMINATED: PTHREAD_CANCELED");
		else
			basic_info("THREAD_TERMINATED");

	        threadDestroy(tr);
		
		if(vectorSize(taskrunners) <= nTaskrunners){

      		  pthread_mutex_lock(tr_threads->mutex);
		        vectorRemoveElement(tr_threads, tr);
      		  pthread_mutex_unlock(tr_threads->mutex);

                  tr = startTaskrunner(currentThread);
	          pthread_mutex_lock(&tr->mutex); //tr->data = object;
	          tr->data = info;
	          pthread_mutex_unlock(&tr->mutex);
                  vectorSet(taskrunners, i, tr);

      		  pthread_mutex_lock(tr_threads->mutex);
        		vectorAdd(tr_threads, tr);
      		  pthread_mutex_unlock(tr_threads->mutex);
                  //fprintf(stderr, "\t\trestarted\n");
		} else {
                  vectorRemove(taskrunners, i);
                  //fprintf(stderr, "\t\tremoved\n");
		}
	      } else {
	        pthread_mutex_lock(&tr->mutex);
		  if(tr->properties){
		    taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  tr->properties;
		    /*
		    char buf[256];
                    sprintf(buf, "job: %d, R_pid: %d, isInterrupted: %d"
				    " [%d %d %d %d]",
			  thread_env->job ?  thread_env->job->id: (-1),
			  thread_env->R_pid,
			  thread_env->isInterrupted,
			  thread_env->mutex_info[0],
			  thread_env->mutex_info[1],
			  thread_env->mutex_info[2],
			  thread_env->mutex_info[3]
			  );
		    basic_info(buf);
		    */
		  } //tr->data = object;
	          tr->data = info;
	          pthread_cond_signal(&tr->cond);
	        pthread_mutex_unlock(&tr->mutex);
	      }

	      if(isInterrupted){ //pthread_kill(tr->ptid, SIGUSR1);
	        tr->data = PTHREAD_INTERRUPTED;
	      }
	      debug_info(tr->name);
	    }
	    fflush(stderr);
	  }
        }
      } else if( info->type == INTERRUPT ){
	      //basic_info("INTERRUPTed/JOB_CANCEL");
//      message:
        //fprintf(stderr, "[%s:%d] INTERRUPT\n",__func__,__LINE__);
        void *object = info->data; // currentThread->data;
        if(object){
          class_t *class = ((object_t*)object)->class;
	  if(class == WorkerJob_class){
            int job_id = ((w_job_t*)object)->id;

	    {
	      char msg[256];
              sprintf(msg, "Cancel job: %d", job_id);
	      basic_info(msg);
	    }

            job_cancel_01(job_id);

	    int rc;
	    for(int i=0; i < vectorSize(taskrunners); i++){
              supr_thread_t *tr=(supr_thread_t *)vectorElementAt(taskrunners,i);
	      pthread_mutex_lock(&tr->mutex);
		if(tr->state == THREAD_STATE_TERMINATED){ //check this...
		} else if(tr->properties){
		  taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  tr->properties;
		  if(thread_env->job && thread_env->job->id == job_id){
	            //pthread_cond_signal(&tr->cond);
			  /*
	            tr->data = info; //tr->data = object;
	            pthread_cond_signal(&tr->cond);
		    rc = pthread_kill(tr->ptid, SIGINT);
		    thread_env->killed = SIGINT;
		    */
		    //if(rc !=0 )
		    int rc = 0;
		    shm_io_info_t *io = thread_env->io;
		    //rc = sem_trywait(&io->err->sem_wr);
		    rc = sem_trywait(&io->err->sem_wr);
		    if(rc == 0)
		    {
		      //char *err_msg = "Error occurred";//use error code...???
		      /*
                      if(strlen(c_message) >= io->err->buffer_size){
                        memcpy(io->err+1, c_message, io->err->buffer_size);
                        ((char*) (io->err+1))[io->err->buffer_size-1] = 0;
                      } else
                        memcpy(io->err+1, c_message, strlen(c_message)+1);
			*/

		      char *err = "job cancelled";
                      memcpy(io->err+1, err, strlen(err)+1);
                      io->err->data_size = strlen(err)+1;
                      //io->err->pid = getpid();
                      sem_post(&io->err->sem_wr);
                    } else {
		      error_info("cannot lock shm_io->err, FIXME");
		    }


		    //thread_env->isInterrupted = TRUE;
		    /*
		    thread_env->killed = TR_CLUSTER_INTERRUPT;
		    kill(thread_env->R_pid, SIGINT);
		    pthread_cancel(tr->ptid);
		    //pthread_kill(tr->ptid, SIGINT);
		    {
		      char msg[256];
		      sprintf(msg, "pthread_cancel(%d/%s): %d"
			      "\n\t[JOBS: %d JOB: %d DRIVER: %d WORKER: %d]",
				      tr->tid, tr->name, rc,
				      thread_env->mutex_info[0],
				      thread_env->mutex_info[1],
				      thread_env->mutex_info[2],
				      thread_env->mutex_info[3]
				      );
		      basic_info(msg);
		    }
		    */
		  }
		}
	        //pthread_cond_signal(&tr->cond);
	        //tr->data = info; //tr->data = object;
		//rc = pthread_kill(tr->ptid, SIGINT);
	      pthread_mutex_unlock(&tr->mutex);
	    }
	  }
	}
        isInterrupted = TRUE;
      } else if( info->type == SIGNAL_RCVD ){
        if(info->padding == SIGCHLD){
	  pid_t pid = (pid_t) ((int*) info->data)[0];
	  for(int i=0; i < vectorSize(taskrunners); i++){
            supr_thread_t *tr=(supr_thread_t *)vectorElementAt(taskrunners,i);
	    pthread_mutex_lock(&tr->mutex);
	      if(tr->state == THREAD_STATE_TERMINATED){ //check this...
	      } else if(tr->properties){
		taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  tr->properties;
		if(thread_env->R_pid == pid){
		  //int rc = pthread_cancel(tr->ptid);
		  basic_info(tr->name);
		  thread_env->R_pid = -1;
		  break;
		}
	      }
	    pthread_mutex_unlock(&tr->mutex);
	  }
	}
	free(info);
      } else if( info->type == SHUTDOWN ){
        printf("SHUTDOWN ...\n");
        //void *object = info->data; == NULL
	for(int i=0; i < vectorSize(taskrunners); i++){
          supr_thread_t *tr=(supr_thread_t *)vectorElementAt(taskrunners,i);
	  pthread_mutex_lock(&tr->mutex);
	    pthread_cond_signal(&tr->cond);
	    tr->data = info;
	    int rc = pthread_kill(tr->ptid, SIGINT);
            printf("SHUTDOWN pthread_kill(%d, SIGINT): %d\n", tr->ptid, rc);
	  pthread_mutex_unlock(&tr->mutex);
	}
      } else if( info->type == SET_NTRS ){
//        printf("SET_NTRS, TODO ...\n");
	int sub_cmd = ((int*)info->data)[0];
	int n_trs;
	if(sub_cmd == 0){
	  n_trs = vectorSize(taskrunners);
	} else if(sub_cmd == 1){
	  n_trs = ((int*)info->data)[1];
//          printf("SET_NTRS, ntrs: %d\n", n_trs);
	} else if(sub_cmd == 2){
	  double r = ((double*)(info->data + sizeof(int)))[0];
//          printf("SET_NTRS, r: %f\n", r);
	  if(r < 0) r = 0.0;
	  else if(r > 1) r = 1.0;
	  n_trs = sysconf(_SC_NPROCESSORS_ONLN);
	  n_trs = (int)( n_trs * r );
//          printf("SET_NTRS, ntrs: %d\n", n_trs);
	}

	((int*)info->data)[0] = nTaskrunners;
	pthread_cond_signal(&currentThread->cond);

	nTaskrunners = n_trs;
      } else if( info->type == CONNECT_DRIVER ){
        //Cluster_sendSimpleMessage("CONNECT_DRIVER", msg_color, ERROR_INFO_TYPE, 0);
	if(sc2driver){
	  pthread_mutex_destroy(sc2driver->mutex);
	  free(sc2driver->mutex);
		// destroy?
	}
	supr_socket_conn_t *driver_sc = (supr_socket_conn_t *)
		info->data;
	sc2driver = socketOpen2(driver_sc->host, driver_sc->port);
	if(sc2driver){
          sc2driver->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
          pthread_mutex_init(sc2driver->mutex, NULL);
          int cmd=CLUSTER_EXECUTOR_REGISTER;
          write(sc2driver->fd, &cmd, sizeof(int));
          pid_t tid = gettid();
          write(sc2driver->fd, &tid, sizeof(int));
	}
        properties->sc2driver = sc2driver;
	free(info);
        currentThread->data = NULL;
      }
    pthread_mutex_unlock(&currentThread->mutex);

#define RESTART_TASKRUNNERS_AFTER_INT
#ifdef  RESTART_TASKRUNNERS_AFTER_INT
                fprintf(stderr, "\tisInterrupted: %d\n", isInterrupted);
    if(isInterrupted){
      pthread_mutex_lock(&currentThread->mutex);

        for(int i=0; i < vectorSize(taskrunners); i++){
            supr_thread_t *tr = (supr_thread_t *)vectorElementAt(taskrunners,i);
	    //
	    int join = FALSE;
	    pthread_mutex_lock(&tr->mutex);
	        //
		if(tr->properties){
		  taskrunner_env_t *thread_env = (taskrunner_env_t *)
			  tr->properties;
		  //if(thread_env->job && thread_env->job->id == job_id){
	           // pthread_cond_signal(&tr->cond);
	            //tr->data = info; //tr->data = object;
		    //rc = pthread_kill(tr->ptid, SIGINT);
		  //}
		  join = thread_env->killed == SIGINT;
		}
		//
	        pthread_cond_signal(&tr->cond);
	        //tr->data = info; //tr->data = object;
		//rc = pthread_kill(tr->ptid, SIGINT);
	    pthread_mutex_unlock(&tr->mutex);
	    //

	    if(join)
	    {
		pthread_mutex_lock(tr_threads->mutex);
                  vectorRemoveElement(tr_threads, tr); // ???
		pthread_mutex_unlock(tr_threads->mutex);

	      if(tr->state == THREAD_STATE_TERMINATED)
	      {
	        void *val;
		int rc = pthread_join(tr->ptid, &val);
		free(tr->properties);
	        threadDestroy(tr);
                tr = startTaskrunner(currentThread);
                vectorSet(taskrunners, i, tr);
	      } else { // FIXME ...
		pthread_mutex_lock(taskrunners_to_join->mutex);
                  vectorAdd(taskrunners_to_join, tr); // ???
		pthread_mutex_unlock(taskrunners_to_join->mutex);
                tr = startTaskrunner(currentThread);
                vectorSet(taskrunners, i, tr);

	      }

		pthread_mutex_lock(tr_threads->mutex);
                  vectorAdd(tr_threads, tr); // ???
		pthread_mutex_unlock(tr_threads->mutex);
	    }
        }
      
      pthread_mutex_unlock(&currentThread->mutex);
    }
#endif
  }

  pthread_cleanup_pop(TRUE);
}

#define  DEFAULT_TASKRUNNER_TIMEOUT 600

// FIXME
so_t *readObject(int fd){
//MALLOC_MARK(__LINE__);
  so_t so;
  ssize_t size = read(fd, &so, sizeof(so_t));
  if(size != sizeof(so_t)){
	  error_info("size != sizeof(so_t)");
	  sleep(60);

	  // sync: Supr_curErrorBuf ...
	  sprintf(Supr_curErrorBuf, "%s", size==-1 ? strerror(errno): 
			  "read: size != sizeof(so_t)");
	  so_t err_so = { 0, 0, 0, SUPR_ERROR, strlen(Supr_curErrorBuf)+1};
	  so_t *s = malloc(sizeof(so_t)+ err_so.size);
	  memcpy(s, &err_so, sizeof(so_t)); 
	  memcpy(s + 1, Supr_curErrorBuf, strlen(Supr_curErrorBuf)+1); 
	  return s;
  }
  so_t *s = (so_t *) malloc(sizeof(so_t) + so.size);
  size = read(fd, s+1, so.size);
  if(size != so.size){
	  error_info("size != so.size");
	  sleep(60);

	  // sync: Supr_curErrorBuf ...
	  sprintf(Supr_curErrorBuf, "%s", size==-1 ? strerror(errno): 
			  "read: size != so.size");
	  so_t err_so = { 0, 0, 0, SUPR_ERROR, strlen(Supr_curErrorBuf)+1};
	  so_t *s = malloc(sizeof(so_t)+ err_so.size);
	  memcpy(s, &err_so, sizeof(so_t)); 
	  memcpy(s + 1, Supr_curErrorBuf, strlen(Supr_curErrorBuf)+1); 
	  return s;
  }
  memcpy(s, &so, sizeof(so_t));
//MALLOC_MARK(__LINE__);
  return s;
}

void TR_registerTaskrunner(w_job_t *job, pid_t tr_pid, shm_io_info_t *io,
		supr_socket_conn_t *sc, taskrunner_env_t *thread_env)
{
  int tr_id = -1;
  so_t *s = NULL;
  pthread_mutex_lock(&job->mutex);
  pthread_mutex_lock(sc->mutex);

    int fd = sc->fd;

    //if(job->count==0 && vectorSize(job->taskrunners)>0)
    if(job->stage)
    { // too late>
      shm_io_write(io, io->out, &tr_id, sizeof(int)); 
      /*
      {
	char buf[256];
        sprintf(buf, "job: %d, tr_addr: %d, TOO LATE", job->id, tr_pid);
        basic_info(buf);
      }
      */
    } else {
      const char *host = workerServerConn->host;
      int port = workerServerConn->port;
      char tr_addr[strlen(host)+64];
      sprintf(tr_addr, "//%s:%d#%d",host, port, tr_pid);

      char msg[4*sizeof(int)+strlen(tr_addr)+1];
      int *intVal = (int*) msg;
      intVal[0] = CLUSTER_BYTE_MSG; 
      intVal[1] = CLUSTER_TASKRUNNER_REGISTER;
      intVal[2] = job->id;
      intVal[3] = strlen(tr_addr)+1;
      sprintf(msg+4*sizeof(int), "%s", tr_addr);
      //int fd = job->sc->fd;

      /*
      {
	char buf[256];
        sprintf(buf, "job: %d, tr_addr: %s", job->id, msg+4*sizeof(int));
        basic_info(buf);
      }
      */

      write(fd, msg, sizeof(msg));
      read(fd, &tr_id, sizeof(int));
//      printf("\033[0;36m[%s:%d] tr_id: %d\033[0m\n", __func__, __LINE__, tr_id);

      shm_io_write(io, io->out, &tr_id, sizeof(int)); 

      thread_env->tr_id = tr_id;

      if(tr_id != -1){

	vectorAdd(job->taskrunners, strdup(tr_addr));
        job->count++;


        so_t so; // make this into a function
	read(fd, &so, sizeof(so_t));
	s = (so_t *) malloc(sizeof(so_t)+so.size);
	memcpy(s, &so, sizeof(so_t));
	read(fd, s + 1, s->size);


      } else {
        job->stage++;
	//if(vectorSize(job->taskrunners)==0)
	//if(job->count==0) { }
      }
    }
  pthread_mutex_unlock(sc->mutex);
  pthread_mutex_unlock(&job->mutex);

  if(s) {
    shm_io_write(io, io->out, s, sizeof(so_t) + s->size);
    free(s);
  }
}


// use job->sc

void combine(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job)
{
  int job_id = ((int*)ptr)[1]; // job->id;
  int tr_id  = ((int*)ptr)[2]; 
  int id_no  = ((int*)ptr)[3];

//  printf("[%s:%ld] job_id: %d(%d) tr_id: %d\n", __func__, syscall(SYS_gettid), job_id, job->id, tr_id);

  so_t so = {0,0,0, 0, 0};
  char *shm_name = NULL;
  char *uri_name = NULL;

  /*
  {
    char msg[256];
    sprintf(msg, "[%ld] pthread_mutex_lock(&job->mutex)", syscall(SYS_gettid));
    basic_info(msg);
  }
  */

  taskrunner_env_t *thread_env = NULL;
  {
    thread_env = (taskrunner_env_t *) pthread_getspecific(taskrunnerThreadKey);
    LOCK_MUTEX(JOBS_MUTEX);
  }

  pthread_mutex_lock(&job->mutex); // FIXME for JOB_CANCELLATION
    SET_MUTEX(JOBS_MUTEX);
    if(job->result){
//      printf("\033[0;32mTake it (job->count=%d)\n\033[0m", job->count);
      so.obj_type = SUPR_SHM_NAME;
      shm_name = job->result;
      job->result = NULL;
    } else {
//      printf("\033[0;33mLeave it (job->count=%d)\n\033[0m", job->count);
      char buf[256];
      sprintf(buf, "RTR_%d_TASK_%d_%d_%d", UID, job_id, tr_id,id_no);
      job->result = strdup(buf);
      job->count --;
      if(job->count){
        so.obj_type = SUPR_NILSXP; // done, without the final result
      } else {
//        printf("\033[0;34mCluster-level Combine!\n\033[0m");
	supr_socket_conn_t *conn = job->sc; 

	/*
  {
    char msg[256];
    sprintf(msg, "[%ld] pthread_mutex_lock(job->sc[2driver])", syscall(SYS_gettid));
    basic_info(msg);
  }
  */
        LOCK_MUTEX(DRIVER_MUTEX);
	pthread_mutex_lock(conn->mutex); // FIXME for JOB_CANCELLATION
        SET_MUTEX(DRIVER_MUTEX);

	int oldcancelstate;
       	pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);

	  int cmd = CLUSTER_BYTE_MSG;
	  write(conn->fd, &cmd, sizeof(int)); // FIXME for efficiency
	  write(conn->fd, ptr, size);
	  int len = strlen(job->result)+1;
	  write(conn->fd, &len, sizeof(int));
	  write(conn->fd, job->result, len);
	  //so_t so;
	  read(conn->fd, &so, sizeof(so_t));

       	pthread_setcancelstate(oldcancelstate, &oldcancelstate);

//        printf("\033[0;34mso.obj_type: %d\n\033[0m", so.obj_type);
	if(so.obj_type == SUPR_URI){
	  //int len;
	  //read(conn->fd, &len, sizeof(int));
	  //uri_name = (char*) malloc(len);
	  //read(conn->fd, uri_name, len);
	  uri_name = (char*) malloc(so.size);
	  read(conn->fd, uri_name, so.size);
	  if(!strstr(uri_name, ":")){
		  char err[256];
		  sprintf(err, "invalid uri_name: \"%s\"", uri_name);
		  error_info(err);
	  }
//          printf("\033[0;34muri_name: \"%s\"\n\033[0m", uri_name);

	  job->count ++;
	  job->result = NULL;
	} else {
	  job->result = NULL;
          job->count  = vectorSize(job->taskrunners);
	}

	pthread_mutex_unlock(conn->mutex); // necesssary?
        UNSET_MUTEX(DRIVER_MUTEX);
      }
    }
  pthread_mutex_unlock(&job->mutex);
  UNSET_MUTEX(JOBS_MUTEX);

  if(shm_name){
    so.size = sizeof(int)+strlen(shm_name)+1;
    unsigned char buf[sizeof(so_t)+so.size];
    memcpy(buf, &so, sizeof(so_t));
    ((int*)(buf+sizeof(so_t)))[0] = strlen(shm_name)+1;
    sprintf(buf+sizeof(so_t)+sizeof(int), "%s", shm_name);
    free(shm_name);
    shm_io_write(io, io->out, buf, sizeof(buf));

  } else if(uri_name){ // let R process do this

    //basic_info(uri_name);

    so.size = strlen(uri_name)+1;
    unsigned char buf[sizeof(so_t)+so.size];
    memcpy(buf, &so, sizeof(so_t));
    sprintf(buf+sizeof(so_t), "%s", uri_name);

    shm_io_write(io, io->out, buf, sizeof(buf));


  } else {
    shm_io_write(io, io->out, &so, sizeof(so_t));
  }
  
  if(uri_name) // { // FIXME?
	    free(uri_name);
  //}

}


void combine_bykey_get(shm_io_info_t *io, w_job_t *job)
{
  static const char *KEY_SEP = ";";
  char *key = NULL;

//  printf("[%s] ...\n", __func__);
  
  vector_t *shm_names = NULL;
  pthread_mutex_lock(&job->mutex);
    
    cbk_t *cbk = job->cbk;
    if(cbk->count){
      key =  cbk->keys[--cbk->count];
      shm_names = hashtableGet(cbk->shm_names, key);
    }

  pthread_mutex_unlock(&job->mutex);

  if(key){
   
      int len = strlen(key)+1;
      for(int i=0; i< vectorSize(shm_names); i++)
        len += strlen((char*) vectorElementAt(shm_names, i))+1;

      char buf[len];
      memcpy(buf, key, strlen(key));
      len = strlen(key);
      for(int i=0; i< vectorSize(shm_names); i++)
      {
        char *s = (char*) vectorElementAt(shm_names, i);
	buf[len++] = KEY_SEP[0];
	memcpy(buf+len, s, strlen(s));
	len += strlen(s);
      }
      buf[len++] = 0;

//      printf("[%s] buf: %s\n", __func__, buf);

      shm_io_write(io, io->out, buf, len);

  } else {
  
      //so_t so = {0,0,0, SUPR_UNBOUND_VALUE, 0};
      shm_io_write(io, io->out, (void*)KEY_SEP, 1); // FIXME 

  }
}

/*
typedef struct cbk_struct {
  pthread_cond_t cond;
  hashtable_t *shm_names;
  char **keys;
  int nkeys;
  int count;
} cbk_t;
*/



void combine_bykey(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job)
{
//MALLOC_MARK(0);
//MALLOC_MARK(__LINE__);
  static const char *KEY_SEP = ";";

  if(size == 3*sizeof(int)) { // nkey == 0??
    combine_bykey_get(io, job);
    //{ // FIXME?
    	free(ptr);
    //}
    return;
  }

  int job_id = ((int*)ptr)[1]; // job->id;
  int tr_id  = ((int*)ptr)[2]; 
  int nkeys  = ((int*)ptr)[3];

//  printf("[%s:%ld] job_id: %d(%d) tr_id: %d, nkeys: %d\n", __func__, syscall(SYS_gettid), job_id, job->id, tr_id, nkeys);

  pthread_mutex_lock(&job->mutex);
    char *str = (char*)(ptr + 4*sizeof(int));
//    printf("[%s] keys: \"%s\"\n", __func__, str);
    int len=0;
    char *shm_name = strdup(strtok(str, KEY_SEP));
    char *keys[nkeys];
    while(str = strtok(NULL, KEY_SEP)){
//      printf("[%s] [%d/%d]: \"%s\"\n", __func__, len+1, nkeys, str);
      keys[len++] = strdup(str); // free???
    }
    free(ptr);

//    printf("[%s] job->count: %d\n", __func__, job->count);

    if(job->count == vectorSize(job->taskrunners)){
      job->cbk = (cbk_t*) malloc(sizeof(cbk_t));
      job->cbk->shm_names = newHashtable(FALSE);
      pthread_cond_init(&job->cbk->cond, NULL);
      job->cbk->keys = NULL;
      job->cbk->nkeys = 0;
      job->cbk->count = 0;

      //{ // FIXME?
	      job->cbk->shm_names->free_data = Supr_decref;
      //}

    }
//MALLOC_MARK(__LINE__); // ...

    hashtable_t *shm_names = job->cbk->shm_names;
    for(int i=0; i<nkeys; i++){
      vector_t *names = (vector_t *) hashtableGet(shm_names, keys[i]);
      if(names == NULL){
        names = newVector(FALSE);
        hashtablePut(shm_names, keys[i], names);
      }
      vectorAdd(names, shm_name);
    }
    job->count--;
    if(job->count){
      pthread_cond_wait(&job->cbk->cond, &job->mutex);
    } else {
      char **keys = hashtableKeySet(shm_names, &nkeys);
      supr_socket_conn_t *conn = job->sc;
      len = 0;
      for(int i=0; i<nkeys; i++) len += strlen(keys[i])+1;
      char *line = (char*)malloc(len); // free?
      len = 0;
      for(int i=0; i<nkeys; i++) {
        if(i>0) line[len++] = KEY_SEP[0];
	memcpy(line + len, keys[i], strlen(keys[i]));
	len += strlen(keys[i]);
      }
      line[len++] = 0;
//      printf("[%s] keys (to driver): \"%s\"\n", __func__, line);
      int args[]= {CLUSTER_BYTE_MSG, TR_COMBINE_BYKEY_INIT, job_id, tr_id, 
	     nkeys, len};
      write(conn->fd, args, sizeof(args));
      write(conn->fd, line, len);

      so_t so;
      read(conn->fd, &so, sizeof(so_t));
//      printf("[%s] so.obj_type = %d\n", __func__, so.obj_type);
      //{ // FIXME
	      free(line);
	      if(job->cbk->keys){
		      free(job->cbk->keys);
		      //job->cbk->keys = NULL;
	      }

      //}
      job->cbk->keys = keys;
      job->cbk->nkeys = nkeys;
      job->cbk->count = nkeys;
      pthread_cond_broadcast(&job->cbk->cond);
    }
//MALLOC_MARK(__LINE__); // ...

  pthread_mutex_unlock(&job->mutex);

  combine_bykey_get(io, job);

//MALLOC_MARK(__LINE__);
}

//#define strdup my_strdup

void thread_sync(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int));
  string_t *mutex_str = newString(mutex);

  taskrunner_env_t *thread_env = (taskrunner_env_t *)
	  pthread_getspecific(taskrunnerThreadKey);

  supr_thread_t *cth = currentThread();

  pthread_mutex_lock(syncEnvironment->mutex);
    vector_t *sync_queue = (vector_t *)
	    hashtableGet(syncEnvironment, mutex);
    if(! sync_queue){
      sync_queue = newVector(FALSE);
      hashtablePut(syncEnvironment, mutex, sync_queue);
    }
    vectorAdd(sync_queue, cth);
  pthread_mutex_unlock(syncEnvironment->mutex);

  cth->data = NULL;
  void *ret_val = NULL;
  pthread_mutex_lock(&cth->mutex);
    
    supr_socket_conn_t *sc = job->sc2worker;

    //int oldcancelstate;
    //pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);

    LOCK_MUTEX(WORKER_MUTEX);
    pthread_mutex_lock(sc->mutex); // P2. DEAD LOCK
    SET_MUTEX(WORKER_MUTEX);

      int cmd = TR_CLUSTER_SYNC;
      write(sc->fd, &cmd,      INT_SIZE); 
      write(sc->fd, &job->id,  INT_SIZE); 
      write(sc->fd, &cth->tid, INT_SIZE); 
      writeString(sc->fd, mutex_str);
    pthread_mutex_unlock(sc->mutex);
    UNSET_MUTEX(WORKER_MUTEX);
    //pthread_setcancelstate(oldcancelstate, &oldcancelstate);

    pthread_cond_wait(&cth->cond, &cth->mutex);
    ret_val = cth->data;
    cth->data = NULL;

  pthread_mutex_unlock(&cth->mutex);

  if(ret_val == JOB_CANCELLED){
    int rc = -1;
    shm_io_write(io, io->out, &rc, INT_SIZE);

    pthread_mutex_lock(syncEnvironment->mutex);
      vector_t *sync_queue = (vector_t *)
	    hashtableGet(syncEnvironment, mutex);
      vectorRemoveElement(sync_queue, cth);
    pthread_mutex_unlock(syncEnvironment->mutex);

  } else {
    int rc = 0;
    shm_io_write(io, io->out, &rc, INT_SIZE);
  }

  { // FIXME?
	  Supr_decref(mutex_str); // ?
	  free(ptr);
  }
}

void thread_unsync(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int));

  taskrunner_env_t *thread_env = (taskrunner_env_t *)
	  pthread_getspecific(taskrunnerThreadKey);

  string_t *mutex_str = newString(mutex);

  supr_thread_t *cth = currentThread();

  pthread_mutex_lock(syncEnvironment->mutex);
    vector_t *sync_queue = (vector_t *)
	    hashtableGet(syncEnvironment, mutex);
    vectorRemoveElement(sync_queue, cth);
  pthread_mutex_unlock(syncEnvironment->mutex);

  int rc = 0;
  supr_socket_conn_t *sc = job->sc2worker;
  LOCK_MUTEX(WORKER_MUTEX);
  pthread_mutex_lock(sc->mutex);
  SET_MUTEX(WORKER_MUTEX);

      int cmd = TR_CLUSTER_UNSYNC;
      int fd = sc->fd;
      write(fd, &cmd,      INT_SIZE);
      write(fd, &job->id,  INT_SIZE);
      write(fd, &cth->tid, INT_SIZE);
      writeString(fd, mutex_str);

      read(fd, &rc, sizeof(int)); // P1. Dead lock // P2. DEAD LOCK

  pthread_mutex_unlock(sc->mutex);
  UNSET_MUTEX(WORKER_MUTEX);

  //int rc = 0;
  shm_io_write(io, io->out, &rc, INT_SIZE);

  Supr_decref(mutex_str); // ??
  free(ptr); // ???
}

// ptr -> char args[sizeof(int)+ sizeof(double)+ strlen(m)+1];
void cluster_wait(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int) + sizeof(double));
  double timeout = *((double*) (ptr+sizeof(int)));
  fprintf(stderr, "\033[0;34m[%s] size: %ld, WAIT:  %s, %f\033[0m\n", __func__, size, mutex, timeout);
#ifdef TR_WAIT_USE_TIME_EXPR
  size_t time_expr_size;
  void *time_expr_ptr = shm_io_read(io, io->in, &time_expr_size, NULL);
#endif

  taskrunner_env_t *thread_env = (taskrunner_env_t *)
	  pthread_getspecific(taskrunnerThreadKey);

  string_t *mutex_str = newString(mutex);
  //string_t *mutex_str = newString(strdup(mutex));

  supr_thread_t *cth = currentThread();

  /*
  pthread_mutex_lock(waitEnvironment->mutex);
    vector_t *wait_queue = (vector_t *)
	    hashtableGet(waitEnvironment, mutex);
    if(! wait_queue){
      wait_queue = newVector(FALSE);
      hashtablePut(waitEnvironment, mutex, wait_queue);
    }
    vectorAdd(wait_queue, cth);
  pthread_mutex_unlock(waitEnvironment->mutex); // FIXME
  */
  /* backend: INTERRUPT
   *          lock &this_thread->mutex
   * this_thread: lock(sc2worker->mutex);
   * some_other_thread: read(sc2worker->fd, ...), from backend.. dead lock!
   */

  int rc = 0;
  
  pthread_mutex_lock(&cth->mutex);
 
    supr_socket_conn_t *sc = job->sc2worker;
    LOCK_MUTEX(WORKER_MUTEX);
    pthread_mutex_lock(sc->mutex); // P1. dead lock
    SET_MUTEX(WORKER_MUTEX);

      pthread_mutex_lock(waitEnvironment->mutex);
        vector_t *wait_queue = (vector_t *)
	    hashtableGet(waitEnvironment, mutex);
        if(! wait_queue){
          wait_queue = newVector(FALSE);
          hashtablePut(waitEnvironment, mutex, wait_queue);
        }
        vectorAdd(wait_queue, cth);
      pthread_mutex_unlock(waitEnvironment->mutex); // FIXME

      int cmd = TR_CLUSTER_WAIT;
      //int fd = exec_prop->sc2worker->fd;
      int fd = sc->fd;
      write(fd, &cmd,      INT_SIZE); 
      write(fd, &job->id,  INT_SIZE); 
      write(fd, &cth->tid, INT_SIZE); 
      write(fd, &timeout,  DOUBLE_SIZE); 
      writeString(fd, mutex_str);

#ifdef TR_WAIT_USE_TIME_EXPR
      write(fd, &time_expr_size, sizeof(ssize_t));
      write(fd, time_expr_ptr, time_expr_size);
      free(time_expr_ptr);
#endif

      read(fd, &rc, sizeof(int));

    pthread_mutex_unlock(sc->mutex);
    UNSET_MUTEX(WORKER_MUTEX);

    if(rc == 2){
      pthread_mutex_unlock(&cth->mutex);

      //rc = 2; // FIXME
      shm_io_write(io, io->out, &rc, INT_SIZE);

      Supr_decref(mutex_str); // ??
      free(ptr);

      pthread_mutex_lock(syncEnvironment->mutex);
        vector_t *sync_queue = (vector_t *)
	    hashtableGet(syncEnvironment, mutex);
        vectorRemoveElement(sync_queue, cth);
      pthread_mutex_unlock(syncEnvironment->mutex);

      return;
    }

    cth->data = NULL;
    pthread_cond_wait(&cth->cond, &cth->mutex);

    if(cth->data == PTHREAD_TIMEOUT) {
      rc = 1;
      shm_io_write(io, io->out, &rc, INT_SIZE);
    }
    else if(cth->data == PTHREAD_NOTIFIED) {
      rc = 0;
      shm_io_write(io, io->out, &rc, INT_SIZE);
    }
    else if(cth->data == JOB_CANCELLED) {
      rc = 2;
      shm_io_write(io, io->out, &rc, INT_SIZE);

      pthread_mutex_lock(syncEnvironment->mutex);
        vector_t *sync_queue = (vector_t *)
	    hashtableGet(syncEnvironment, mutex);
        vectorRemoveElement(sync_queue, cth);
      pthread_mutex_unlock(syncEnvironment->mutex);
    }
    else if(!cth->data) {
	    basic_info("cth->data == NULL, FIXME");
      rc = 2;
      shm_io_write(io, io->out, &rc, INT_SIZE);
    }
    else {
       rc = -1; //shm_io_write(io, io->out, &rc, INT_SIZE);
       if(*((int*)cth->data) == 0){
         unsigned char buf[2*INT_SIZE+sizeof(double)];
	 *((int*)buf) = rc;
	 memcpy(buf+INT_SIZE, cth->data, INT_SIZE + sizeof(double));
         shm_io_write(io, io->out, buf, sizeof(buf));
       } else {
         int len = strlen((char*)(cth->data+INT_SIZE))+1;
         unsigned char buf[2*INT_SIZE+len];
	 *((int*)buf) = rc;
	 memcpy(buf+INT_SIZE, cth->data, INT_SIZE + len);
         shm_io_write(io, io->out, buf, sizeof(buf));
       }

       free(cth->data);
    } // handle job cancellation ...
    //else rc = 2; // or 2 interrupted??
    cth->data = NULL;

  pthread_mutex_unlock(&cth->mutex);


  Supr_decref(mutex_str); // ??
  free(ptr);
}

void cluster_notify(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int));
  double timeout = *((double*) (ptr+sizeof(int)));

  taskrunner_env_t *thread_env = (taskrunner_env_t *)
	  pthread_getspecific(taskrunnerThreadKey);

  string_t *mutex_str = newString(mutex);

  supr_thread_t *cth = currentThread();

  int rc = 0;
  
  supr_socket_conn_t *sc = job->sc;
  LOCK_MUTEX(DRIVER_MUTEX); // sync on cth->mutex???
  pthread_mutex_lock(sc->mutex);
  SET_MUTEX(DRIVER_MUTEX);
      int cmd = CLUSTER_BYTE_MSG;
      int fd = sc->fd;
      write(fd, &cmd, INT_SIZE); 
      write(fd, ptr,  INT_SIZE);  // notify or notifyAll
      write(fd, &job->id, INT_SIZE); 
      write(fd, &cth->tid, INT_SIZE);
      writeString(fd, mutex_str);
      read(fd, &rc, INT_SIZE);
  pthread_mutex_unlock(sc->mutex);
  UNSET_MUTEX(DRIVER_MUTEX);

  shm_io_write(io, io->out, &rc, INT_SIZE);

  Supr_decref(mutex_str);
  free(ptr);
}

//#undef strdup

/*
void Cond_notify(const char *mutex, int tid, share_t *value)
{
  pthread_mutex_lock(countdownEnvironment->mutex);
    vector_t *wait_queue = (vector_t *)
	    hashtableGet(countdownEnvironment, mutex);
    for(int i=0; i<vectorSize(wait_queue); i++){
       supr_thread_t *th = (supr_thread_t *) vectorElementAt(wait_queue, i);
       if(th->tid == tid){
         pthread_mutex_lock(&th->mutex);
           pthread_cond_signal(&th->cond);
//	   Supr_incref(value);
	   th->data = value;
         pthread_mutex_unlock(&th->mutex);
	 vectorRemove(wait_queue, i);
	 break;
       }
    }
  pthread_mutex_unlock(countdownEnvironment->mutex);
}
*/

// ptr: int args[] = {TR_RECV_MSG, job_id, tr_id, getpid(), gettid()};
void  TR_messages(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  basic_info("TODO");
  free(ptr);
  shm_io_write(io, io->out, SO_null->ptr, SO_null->size); // FIXME
}

// ptr: int args[] = {TR_RECV_MSG, job_id, tr_id, getpid(), gettid(), 0, 0};
//                 = {TR_RECV_MSG, job_id, tr_id, getpid(), gettid(), (timeout)}
void  TR_recv(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  pid_t pid = ((int*) ptr)[3];
  double timeout = *((double*) (ptr + 5*sizeof(int)));
  free(ptr);

  //char buf[256]; sprintf(buf, "timeout: %f", timeout); basic_info(buf);

  void *msg = NULL;
  pthread_mutex_lock(messages->mutex);
    while(TRUE){

      for(int i=0; i<vectorSize(messages); i++){
        msg = vectorElementAt(messages, i);
        if(((int*)msg)[1] == pid){
          vectorRemove(messages, i);
	  break;
        } else {
	      msg = NULL;
        }
      }

      if(msg) break;

      int rc;
      if(timeout > 0){
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;
        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));
        rc = pthread_cond_timedwait(messages_cond, messages->mutex, &wait);
        clock_gettime(CLOCK_REALTIME, &wait);
	timeout -= wait.tv_sec + wait.tv_nsec/1000000000.0;
      } else {
        rc = pthread_cond_wait(messages_cond, messages->mutex);
      }

      if(rc != 0 || timeout < 0) break;

      //sprintf(buf, "pid: %d, tid: %d, rc: %d, timeout: %f", getpid(), (int)syscall(SYS_gettid), rc, timeout); basic_info(buf);
      //if(rc == ETIMEDOUT) break;

      //}
    }
  pthread_mutex_unlock(messages->mutex);

  if(msg){
    int len_addr = ((int*) msg)[3];
    int len_raw = ((int*) msg)[4];
    void *raw = msg + 5*sizeof(int) + len_addr;
    shm_io_write(io, io->out, raw, len_raw);
    
    free(msg);
  } else { // FIXME
    int rc = -1;
    shm_io_write(io, io->out, &rc, sizeof(int));
  }
}

/*
void  countdownDecrease(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+4*sizeof(int));
  double timeout = *((double*) (ptr+sizeof(int)));
  // message:
  //fprintf(stderr, "[%s] size: %ld, COUNTDOWN_DECREASE: %s\n", __func__, size, mutex);

  string_t *mutex_str = newString(mutex);
  supr_thread_t *cth = currentThread();

  
  pthread_mutex_lock(countdownEnvironment->mutex);
    vector_t *wait_queue = (vector_t *)
	    hashtableGet(countdownEnvironment, mutex);
    if(! wait_queue){
      wait_queue = newVector(FALSE);
      hashtablePut(countdownEnvironment, mutex, wait_queue);
    }
    vectorAdd(wait_queue, cth);
  pthread_mutex_unlock(countdownEnvironment->mutex);
 
  //so_t *so;
  share_t *sh;

#define NOT_COUNTDOWN_SEND_DIRECTLY
#ifdef COUNTDOWN_SEND_DIRECTLY
#else
  pthread_mutex_lock(&cth->mutex);
    pthread_mutex_lock(exec_prop->sc2worker->mutex);

      int cmd = TR_COUNTDOWN_DECREASE;
      int fd = exec_prop->sc2worker->fd;
      write(fd, &cmd,      INT_SIZE); 
      write(fd, &job->id,  INT_SIZE); 
      write(fd, &cth->tid, INT_SIZE); 
      writeString(fd, mutex_str);
      //exec_prop->sc2worker->att = ptr; // ??
      write(fd, &size, SIZE_SIZE); 
      write(fd, ptr,  size); // or attached to cth->data ???

    pthread_mutex_unlock(exec_prop->sc2worker->mutex);
//    printf("[%s:%d] COUNTDIWN_DECREASE: waiting\n", __func__, cth->tid);

    cth->data = NULL;
    pthread_cond_wait(&cth->cond, &cth->mutex);
    //so = (so_t*) cth->data;
    sh = (share_t*) cth->data;
  pthread_mutex_unlock(&cth->mutex);
#endif

  //shm_io_write(io, io->out, so, sizeof(so_t)+so->size);
  // checking class?
  if(sh->class != Share_class) {
	  printf("Error: sh->class != Share_class, FIXME\n"); 
	  exit(0);
	  return;
  }

  int n=0;
  for(int i=0; sh->val[i]; i++) n++;
//  printf("COUNTDIWN_DECREASE: n: %d, Supr_refcnt: %d\n", n, Supr_refcnt(sh));
  shm_io_write(io, io->out, &n, INT_SIZE);
  for(int i=0; sh->val[i]; i++) {
    so_t *so = (so_t*) sh->val[i];
//    printf("COUNTDIWN_DECREASE: i: %d, so->size: %ld\n", i, so->size);
    shm_io_write(io, io->out, so, sizeof(so_t)+so->size);
  }

  pthread_mutex_lock(&sh->lock);
    Supr_decref(sh);
  pthread_mutex_unlock(&sh->lock);

  //{
	  Supr_decref(mutex_str);
	  free(ptr);
  //}

}
*/

/*
void  handlePrint(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop, pid_t pid)
{
  fprintf(stderr, "[cmd:%d] %s\n", ((int*)ptr)[0], (char*)(ptr+INT_SIZE));
  // use socket connection
  free(ptr);
}
*/

/*
void C_Taskrunner_SigactionInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>> %s <<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  supr_thread_t *currentThread = (supr_thread_t *)
		  pthread_getspecific(currentThreadKey);

  {
     char buf[256];
     sprintf(buf, "\033[0;31mname: %s, tid: %d\033[0m", currentThread->name, currentThread->tid);
     basic_info(buf);
  }

  pthread_mutex_lock(&currentThread->mutex);
    taskrunner_env_t *thread_env = (taskrunner_env_t *)
	    currentThread->properties;
    thread_env->isInterrupted = TRUE;
    if(currentThread->fun){
      currentThread->fun(currentThread->data);
      currentThread->fun  = NULL;
      currentThread->data = NULL;
    }
  pthread_mutex_unlock(&currentThread->mutex);

  return;


  debug_info(__func__);
  if(currentThread->fun = Taskrunner_interrupt){
     currentThread->fun(currentThread->data);
     return;
  }

  if(currentThread->fun){ // FIXME
     Thread_SigactionBacktrace(sig, ip, context);
     return;
  }

  thread_info_t *info = (thread_info_t *) currentThread->data;

  if(!info) return;

  taskrunner_env_t *env = (taskrunner_env_t *)
     pthread_getspecific(taskrunnerThreadKey);

  if(info->type == SHUTDOWN ){
    fprintf(stderr, "\033[0;31m[%s] SHUTDOWN: TO DO ...\033[0m\n", __func__);
    env->isInterrupted = TRUE;
    kill(env->R_pid, SIGUSR1);
    char buf[256];
    *((int*)buf) = CLUSTER_SHUTDOWN;
    sprintf(buf+INT_SIZE, "SHUTDOWN");
    shm_io_write(env->io, env->io->err, buf, sizeof(buf));
  } else if(env->job == info->data){
    fprintf(stderr, "\033[0;31m[%s] INTERRUPT: TO DO ...\033[0m\n", __func__);
    env->isInterrupted = TRUE; //kill(env->R_pid, SIGINT);
    kill(env->R_pid, SIGUSR1);
    kill(env->R_pid, SIGINT);
    char buf[256];
    *((int*)buf) = CLUSTER_INTERRUPT;
    sprintf(buf+INT_SIZE, "INTERRUPT/JOB_CANCEL");
    shm_io_write(env->io, env->io->err, buf, sizeof(buf));
  }
  // ignore otherwise
  // to do ...
}
*/

// check the function ...
extern int shm_io_destroy (shm_io_info_t *io);
extern so_t *SO_read(int fd);

void taskrunner_run_cleanup(void *data)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();

  basic_info(cth->name);

  // kill R-thread ...
  char *str_pid = strstr(cth->name, ".")+1;

  pid_t pid = atoi(str_pid);


  int rc = kill(pid, SIGTERM);
  /*
  int status;
  pid_t q = waitpid(pid, &status, 0);

  {
    char msg[256];
    sprintf(msg, "[%d] kill(%d, SIGTERM): %d, waitpid(...): %d",
		   cth->tid, pid, rc, q);
    basic_info(msg);
  }
  */
  

  cth->state = THREAD_STATE_TERMINATED;

  //pthread_kill(main_thread->ptid, SIGCHLD);

  return; // FIXME

  /*
  {
   char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf) basic_info(buf);
    free(buf);
  }
  */


  taskrunner_env_t *thread_env = (taskrunner_env_t *)
               pthread_getspecific(taskrunnerThreadKey);
  w_job_t *job = thread_env->job;
  if(!job) {
    free(thread_env); // free(cth?)...
    cth->state = THREAD_STATE_TERMINATED;
    return;
  }

  /*
  if(thread_env->last_cmd != TR_NEXT_JOB &&
     thread_env->last_cmd != TASK_RESULTS)
  {
     so_t ret = {0,0,0,SUPR_JOB_CANCELLED,0};
     char array[5*sizeof(int)+sizeof(ret)]; // FIXME
     int *header = (int*) array;
     header[0] = TASK_RESULTS;
     header[1] = job->id;
     header[2] = thread_env->tr_id;
     header[3] = TR_TASK_STATUS_CANCELLED;
     // ???header[4] = strlen(cth->name)+1;
     memcpy(array + 5*sizeof(int), &ret, sizeof(ret));

     supr_socket_conn_t *sc = job->sc;
     pthread_mutex_lock(sc->mutex);
                   int cmd = CLUSTER_BYTE_MSG;
                   int fd = sc->fd;
                   write(fd, &cmd, sizeof(int));
                   write(fd, array, sizeof(array));
                   so_t *s = SO_read(fd);
		   free(s);
     pthread_mutex_unlock(sc->mutex);
  }
  */

  char msg[256];
  if(job->mutex.__data.__owner == cth->tid) {
    sprintf(msg, "job->mutex.__data.__owner: %d", 
                  job->mutex.__data.__owner);
    basic_info(msg);
    pthread_mutex_unlock(&job->mutex);
  }

  if(job->sc->mutex->__data.__owner == cth->tid) {
    sprintf(msg, "\033[0;33mjob->sc->mutex->__data.__owner: %d\033[0m", 
                  job->sc->mutex->__data.__owner);
    basic_info(msg);
    pthread_mutex_unlock(job->sc->mutex);
  }
  if(job->sc2worker->mutex->__data.__owner == cth->tid) {
    sprintf(msg, "\033[0;34mjob->sc2worker->mutex->__data.__owner: %d\033[0m", 
                  job->sc2worker->mutex->__data.__owner);
    basic_info(msg);
    pthread_mutex_unlock(job->sc2worker->mutex);
  }

  pthread_mutex_lock(jobs->mutex);
    
        Supr_decref(job);

	{
          char msg[256];
	  sprintf(msg, "job->ref_count: %d (==1?)", job->ref_count);
	  basic_info(msg);
	}

        if(job->ref_count == 1) {

	  for(int i=vectorSize(jobs) - 1; i >= 0; i--){
		  w_job_t *j = vectorElementAt(jobs, i);
		  if(j == job){
		    vectorRemove(jobs, i);
		    break;
		  }
	  }

	  Supr_decref(job);
        }
  pthread_mutex_unlock(jobs->mutex);
  free(thread_env); // free(cth?)...
  cth->state = THREAD_STATE_TERMINATED;
  // destroy shm_io?
}

void printSource(void *data){
  if(!data) {
    basic_info("?");
    return;
  }
   
  char *file = (char*) ((void**)data)[0];
  int line  = ((int*) ((void**)data)[1])[0];
  char msg[256];
  sprintf(msg, "%s:%d", file, line);
  basic_info(msg);
}

void taskrunner_run(supr_thread_t *executor)
{
  pthread_cleanup_push(taskrunner_run_cleanup, NULL);
  executor_property_t *exec_properties = (executor_property_t *)
	  executor->properties;


  supr_thread_t *currentThread = (supr_thread_t *)
		  pthread_getspecific(currentThreadKey);

  taskrunner_env_t *thread_env = (taskrunner_env_t *)
	  malloc(sizeof(taskrunner_env_t));

  thread_env->job = NULL;
  thread_env->R_pid = -1;
  thread_env->isInterrupted = FALSE;
  thread_env->killed = 0;
  thread_env->tr_id = -1;
  thread_env->last_cmd = -1;
  UNSET_MUTEX(JOBS_MUTEX);
  UNSET_MUTEX(JOB_MUTEX);
  UNSET_MUTEX(DRIVER_MUTEX);
  UNSET_MUTEX(WORKER_MUTEX);

  pthread_setspecific(taskrunnerThreadKey, thread_env);

  pthread_mutex_lock(&currentThread->mutex);
    currentThread->state = THREAD_STATE_RUNNABLE;
    {
      currentThread->properties = thread_env;
    }
  pthread_mutex_unlock(&currentThread->mutex);


  /*
#define __USE_SIGINT__
#ifdef  __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionInt;
    sa.sa_sigaction = C_Taskrunner_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, NULL);
  }
#endif
  */

  // create tr process
  shm_io_info_t *io = NULL;
  pid_t cpid;

  int oldcancelstate;
  pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);

  {
    char shm_name[128];
    sprintf(shm_name, "supr.tr-%d-%d", geteuid(), currentThread->tid);
    size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
    io = shm_io_create(shm_name, block_size);

    thread_env->io = io;

    pid_t pid = fork();

    if(pid == -1){
	    printf("Error: fork, %s\n", strerror(errno));
	    pthread_exit(NULL); // FIXME... 
    }

    if(pid) {

      cpid = pid;

      size_t size;
      void *ptr = shm_io_read(io, io->in, &size, NULL);
      //thread_env->R_pid = atoi((char*)ptr);
      pthread_mutex_lock(&currentThread->mutex);
        thread_env->R_pid = atoi((char*)ptr);
	free(currentThread->name);
	char new_name[128];
	sprintf(new_name, "taskrunner.%d", thread_env->R_pid);
	currentThread->name = strdup(new_name);
      pthread_mutex_unlock(&currentThread->mutex);
//      printf("[%s] R_pid = %d\n", __func__, thread_env->R_pid);
      free(ptr);

      int port = workerServerConn->port;

      shm_io_write(io, io->out, &port, sizeof(int));

    } else {

      //basic_info("do SocketConn_closeAll?");
      // remove child proc's copy...
      //SocketConn_closeAll(socket_connections, 0);

      char CMD_PATH[PATH_MAX];
      //sprintf(CMD_PATH, "%s/bin/taskrunner", SUPR_HOMESYS);
      printf("\033[0;31mSupr_sysHome: %s\033[0m", Supr_sysHome);
      sprintf(CMD_PATH, "%s/bin/taskrunner", Supr_sysHome);
      fprintf(stderr, "cmd path: %s\n", CMD_PATH);
      fflush(stdout);

#define USE_XTERM
#ifdef  USE_XTERM
#else
#endif
#undef USE_XTERM

      if(FALSE && Taskrunner_useWindow){
        char *argv[] = {
          CMD_PATH,
          shm_name,
	  "-worker.dir", Worker_dir,
          (char*) NULL
        };
        //int argc = sizeof(args)/sizeof(char*);
        //supr_xterm_t *xterm = supr_xterm2("master", argv);

	char buf[256];
	sprintf(buf, "Taskrunner@");
        gethostname(buf+strlen(buf), sizeof(buf)-strlen(buf));

        //supr_xterm_t *xterm = supr_xterm2("Taskrunner", argv);
        //supr_xterm_t *xterm = supr_xterm2(buf, argv);
        supr_xterm_t *xterm = supr_xterm3(buf, argv, FALSE);
//        printf("[%s] run taskrunner: xterm =  %p, %s\n", __func__, xterm, strerror(errno));
      } else  {

	for(int fd = sysconf(_SC_OPEN_MAX); fd >= 3; fd --) {
           close(fd);
        }

        //int rc = execl(CMD_PATH, "taskrunner", shm_name, (char*) NULL);
	char cmd[strlen(CMD_PATH)+strlen(shm_name)+strlen("%s %s  ")+1];
	sprintf(cmd, "%s %s  ", CMD_PATH, shm_name);
        //int rc = execl("/bin/sh", "sh", "-c", cmd, (char*) NULL);
	
	printf("cmd: %s, workerServerConn: %p\n",
			CMD_PATH, workerServerConn);
	char port_arg[32];
	sprintf(port_arg, "%d", workerServerConn->port);

	//char master[256];
	//sprintf(master, "//%s:%d", master_conn->host, master_conn->port);

	printf("CMD: %s %s %s -worker.dir %s -worker.port %s -info %s\n",
		       	CMD_PATH, SYS_COMMAND_TASKRUNNER,
			shm_name, Worker_dir, port_arg, info_addr);
	
        int rc = execl(CMD_PATH, SYS_COMMAND_TASKRUNNER,
			shm_name, "-worker.dir", Worker_dir,
			"-worker.port", port_arg,
			"-info", info_addr ? info_addr : "",
			//"-master", master,
		       	(char*) NULL);

	sprintf(CMD_PATH+strlen(CMD_PATH), " rc: %d, err: %s\n", rc,
			strerror(errno));
        Supr_message = (char*)malloc(strlen(CMD_PATH)+1);
	memcpy(Supr_message, CMD_PATH, strlen(CMD_PATH)+1);
      }

      exit(0);

    }
  }

  static pthread_mutex_t __global_mutex = PTHREAD_MUTEX_INITIALIZER;// FIXME
  pthread_mutex_lock(&__global_mutex);
  if(tr_count_mutex) {
    pthread_mutex_lock(tr_count_mutex);
    tr_count--;
    if(tr_count == 0) {
      pthread_mutex_unlock(tr_count_mutex);
      pthread_mutex_destroy(tr_count_mutex);
      fprintf(stderr, "[%s@%d] tid: %ld, free ...\n", __func__, __LINE__,
		     syscall(SYS_gettid)); 
      free(tr_count_mutex);
      fprintf(stderr, "[%s@%d] tid: %ld, free !!!\n", __func__, __LINE__,
		     syscall(SYS_gettid)); 
      tr_count_mutex = NULL;
      pthread_mutex_lock(&currentThread->mutex);
         //exec_properties
         pthread_mutex_lock(exec_properties->sc2worker->mutex);

           int cmd = WORKER_READY;
           int fd = exec_properties->sc2worker->fd;
           write(fd, &cmd,      INT_SIZE); 
         pthread_mutex_unlock(exec_properties->sc2worker->mutex);
      pthread_mutex_unlock(&currentThread->mutex);
    } else { 
      pthread_mutex_unlock(tr_count_mutex);
    }
  }
  pthread_mutex_unlock(&__global_mutex);

  pthread_setcancelstate(oldcancelstate, &oldcancelstate);

  w_job_t *job = NULL;
//  w_job_t *last_job = NULL;
  int last_job_id = 0;

  // testing
#define TESTING_MY_JOBS
#ifdef  TESTING_MY_JOBS
  vector_t *my_jobs = newVector(FALSE);
#endif

  while(TRUE){ // FIXME...

    /*{
      char msg[256];
      sprintf(msg, "child proc (cpid): %d, R_pid: %d", cpid, thread_env->R_pid);
      basic_info(msg);
    } */

    // is the tr alive?
    int rc = kill(cpid, 0);
    if(rc == -1) {
      cpid = 0;
      char err[256];
      sprintf(err, "\033[0;31mError: lost child proc %d\033[0m", cpid);
      error_info(err);
      //pthread_exit(NULL);
      break;
    }

    {
      char *err = NULL;
      int rc = sem_wait(&io->err->sem_wr);
      if(rc == 0){
        if(io->err->data_size){
	  if(strcmp((char*)(io->err+1), "TERMINATED")==0)
	  {
            err = (char*)(io->err+1);
	    error_info(err);
	  }
	}
        sem_post(&io->err->sem_wr);
      } else break;

      if(err) break;
    }

    //sync_remove(currentThread);

#define USE_SIGBLOCK      
#ifdef  USE_SIGBLOCK      
      sigset_t sig_set;
      sigemptyset(&sig_set);
      //sigaddset(&sig_set, SIGINT);
      sigaddset(&sig_set, SIGCHLD);
      pthread_sigmask(SIG_BLOCK, &sig_set, NULL);
      //pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
#endif

    thread_env->job = job = NULL; //job = last_job;
    thread_env->tr_id = -1;
    thread_env->last_cmd = -1;
    thread_env->isInterrupted = 0;
    thread_env->killed = 0;

    pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);
    pthread_mutex_lock(jobs->mutex);
	for(int i=0; i<vectorSize(jobs); i++){
             w_job_t *j = (w_job_t *) vectorElementAt(jobs, i);
	     if(!j){
	       error_info("j: (null), FIXME %d:%s", __LINE__, __FILE__);
	       break;
	     }

	     if(j->id > last_job_id){
		     job = j;
		     break;
	     }
	}
	if(job) Supr_incref(job);
    pthread_mutex_unlock(jobs->mutex);
    pthread_setcancelstate(oldcancelstate, &oldcancelstate);

    if(job == NULL ){
      void *data = NULL;
      pthread_mutex_lock(&currentThread->mutex);
        currentThread->data = NULL;

        //double timeout = DEFAULT_TASKRUNNER_TIMEOUT;
        double timeout = Supr_options.timeout;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        wait.tv_sec += (long) timeout;

        currentThread->state = THREAD_STATE_TIMED_WAITING;

	//int oldtype;
	//int rc = pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, &oldtype);

	int rc = pthread_cond_timedwait(&currentThread->cond,
		       	&currentThread->mutex, &wait);

       	//rc = pthread_setcanceltype(oldtype, NULL);


	thread_info_t *info = (thread_info_t *) currentThread->data;
        currentThread->data = NULL;
	
	if( info && ( info->type == INTERRUPT || info->type == SHUTDOWN ))
	{
			//kill the R taskrunner ...
          int rc = kill(thread_env->R_pid, SIGKILL);
          printf("info->type: %s\n", info->type == INTERRUPT ?
	  		"INTERRUPT" : "SHUTDOWN");
          printf("kill(%d, SIGKILL): %d\n", thread_env->R_pid, rc);

          pthread_exit(PTHREAD_INTERRUPTED);
	} /*else if(info && info->type == NEW_JOB) {
          data = info->data;
	}*/


        //currentThread->state = THREAD_STATE_RUNNABLE;

	/*
        if(data)
          printf("\033[0;33m[%s] data: %s\n", __func__, objectToString(data));
	  */

      //pthread_cond_wait(&currentThread->cond, &currentThread->mutex);
      pthread_mutex_unlock(&currentThread->mutex);

      continue;
    }

    currentThread->state = THREAD_STATE_RUNNABLE;

    last_job_id = job->id;
    thread_env->job = job;

  if(Supr_options.verbose)
  {
	  char msg[256];
	  sprintf(msg, "new job: %d", job->id);
	  verbose_info(msg);
	//  basic_info(msg);
  }

  /*
#ifdef  USE_SIGBLOCK      
  //      sigset_t sig_set;
      sigemptyset(&sig_set);
      sigaddset(&sig_set, SIGINT);
      pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
#endif
*/

    int msg[] = {TR_NEW_JOB, job->id};
    shm_io_write(io, io->out, msg, sizeof(msg));
    so_t *so = (so_t *) job->expr;
    shm_io_write(io, io->out, so, sizeof(so_t)+so->size);

    supr_socket_conn_t *sc2driver = exec_properties->sc2driver;

    // FIXME
    int registered = FALSE; 

    //while(TRUE)
    while(! thread_env->isInterrupted)
    { // REPL


      size_t size;
      currentThread->fun = printSource;// FIXME
      int line = __LINE__;
      void *data[] = {__FILE__, &line};
      currentThread->data = data;
      void *ptr = shm_io_read(io, io->in, &size, NULL);
      currentThread->data = NULL;

      if(!ptr) {
	      if(thread_env->isInterrupted)
		      pthread_exit(NULL);
//	      continue;
      }

      fprintf(stderr, "[%s:%d] size: %ld, isInterrupted: %d\n", __func__, __LINE__, size, thread_env->isInterrupted);
      if(thread_env->isInterrupted) {
	      basic_info("thread_env->isInterrupted");
	      break;
      }
      
      int cmd = ((int*)ptr)[0];

      if(cmd == TR_NEXT_JOB) {
		   
	      thread_env->last_cmd = cmd;

	      free(ptr);
	      if(!registered){
	      	error_info("not registered, FIXME!");
	      }
	      //basic_info("\033[0;34mTR_NEXT_JOB\033[0m");
	      break;
      }

      switch(cmd){
        case TR_JOB_REGISTER:
	     {
	       supr_socket_conn_t *sc = thread_env->job->sc;
               pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,&oldcancelstate);
	         TR_registerTaskrunner(job, cpid, io, sc, thread_env);
	         free(ptr);
	       pthread_setcancelstate(oldcancelstate, &oldcancelstate);
	       ptr = NULL;
	       registered = TRUE;

	       basic_info("job.id: %d, tr.id: %d", job->id, thread_env->tr_id);
	     }
	     break;

        case TR_SEND_DRIVER:
	     {
	       free(ptr);
               ptr = shm_io_read(io, io->in, &size, NULL);
               if(thread_env->isInterrupted) break;
	       so_t *s;
	     
	       supr_socket_conn_t *sc = thread_env->job->sc;
	       pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,&oldcancelstate);
	         pthread_mutex_lock(sc->mutex);
		   cmd = CLUSTER_BYTE_MSG;
		   int fd = sc->fd;
	           write(fd, &cmd, sizeof(int));
		   {
		     thread_env->last_cmd = ((int*)ptr)[0]; 
		     if(thread_env->last_cmd == TASK_RESULTS)
                       sync_remove(currentThread);
		   }
	           write(fd, ptr, size);
		   free(ptr);
		   ptr = NULL;
		   s = SO_read(fd);
	         pthread_mutex_unlock(sc->mutex);
	       pthread_setcancelstate(oldcancelstate, &oldcancelstate);

               shm_io_write(io, io->out, s, sizeof(so_t)+s->size);
	       free(s);
	     }
	     break;

	case TR_NEXT_SUBSET:
	     {
	       supr_socket_conn_t *sc = thread_env->job->sc;
	       pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);
	         pthread_mutex_lock(sc->mutex);
	           cmd = CLUSTER_BYTE_MSG;
		   int fd = sc->fd;
                   write(fd, &cmd, sizeof(int));
		   write(fd, ptr, size);
		   free(ptr); ptr = NULL;
	           so_t *so = readObject(fd);
	         pthread_mutex_unlock(sc->mutex);

                 shm_io_write(io, io->out, so, sizeof(so_t) + so->size);
	         free(so);
	       pthread_setcancelstate(oldcancelstate, &oldcancelstate);
	     }
	     break;

	case TR_COMBINE:
	     { 
	       combine(io, ptr, size, job);
	       free(ptr);
	     }
	     break;

	case TR_COMBINE_BYKEY:
	     combine_bykey(io, ptr, size, job);
	     break;

	case TR_CLUSTER_SYNC:
	     pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,&oldcancelstate);
	     thread_sync(io, ptr, size, job, exec_properties);
	     pthread_setcancelstate(oldcancelstate, &oldcancelstate);
	     break;

	case TR_CLUSTER_UNSYNC:
	     pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,&oldcancelstate);
	     thread_unsync(io, ptr, size, job, exec_properties);
	     pthread_setcancelstate(oldcancelstate, &oldcancelstate);
	     break;

	case TR_CLUSTER_WAIT:
	     pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,&oldcancelstate);
	     cluster_wait(io, ptr, size, job, exec_properties);
	     pthread_setcancelstate(oldcancelstate, &oldcancelstate);
	     break;

        case TR_CLUSTER_NOTIFY:
        case TR_CLUSTER_NOTIFYALL:
	     pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,&oldcancelstate);
	       cluster_notify(io, ptr, size, job, exec_properties);
             pthread_setcancelstate(oldcancelstate, &oldcancelstate);
	     break;

	     /*
	case TR_COUNTDOWN_DECREASE: // count_and_get, deprecated ...
	     countdownDecrease(io, ptr, size, job, exec_properties);
	     break;
	     */

	case TR_GET_MSG:
	     TR_messages(io, ptr, size, job, exec_properties);
	     break;

	case TR_RECV_MSG:
	     TR_recv(io, ptr, size, job, exec_properties);
	     break;

	case TR_CHECK_INTERRUPT:
	     pthread_mutex_lock(&currentThread->mutex);
              shm_io_write(io, io->out, &thread_env->killed, sizeof(int));
	     pthread_mutex_unlock(&currentThread->mutex);
	     break;

	case TR_EXIT:
	     {
	        basic_info("EXIT");
		so_t ret = {0,0,0,SUPR_JOB_CANCELLED,0};
		char array[4*sizeof(int)+sizeof(ret)]; // FIXME
		int *header = (int*) array;
		header[0] = TASK_RESULTS;
		header[1] = job->id;
		header[2] = thread_env->tr_id;
		header[3] = TR_TASK_STATUS_CANCELLED;
		//header[4] = strlen(currentThread->name)+1;
		memcpy(array + 4*sizeof(int), &ret, sizeof(ret));

	        pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);
		supr_socket_conn_t *sc = job->sc;
     		pthread_mutex_lock(sc->mutex);
                   int cmd = CLUSTER_BYTE_MSG;
                   int fd = sc->fd;
                   write(fd, &cmd, sizeof(int));
                   write(fd, array, sizeof(array));
                   //write(fd, array, 4*sizeof(int));
                   //write(fd, &ret, sizeof(so_t));
                   so_t *s = SO_read(fd);
		   free(s);
		pthread_mutex_unlock(sc->mutex);
                pthread_setcancelstate(oldcancelstate, &oldcancelstate);
 
                thread_env->isInterrupted = TRUE;
	        //basic_info("EXIT");
	     }
	     break;

        default: {
			 char buf[256];
            sprintf(buf, "[%s] size = %ld, (unknown) cmd = %d ... \n", __func__, size, cmd);
	    basic_info(buf);
		 }
		 break;
      }
    }


//MALLOC_MARK(__LINE__);

    //fprintf(stderr, "[%s]  ??? ... (%s:%d)\n", __func__, __FILE__, __LINE__);
    //fflush(stderr);
    //{
      pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);
      pthread_mutex_lock(jobs->mutex);
        Supr_decref(job);
        if(job->ref_count == 1) {

	  for(int i=vectorSize(jobs) - 1; i >= 0; i--){
		  w_job_t *j = vectorElementAt(jobs, i);
		  if(j == job){
		    vectorRemove(jobs, i);
		    break;
		  }
	  }

	  if(job->cancelled){
	    basic_info("JOB CANCELLED: remove job %d", job->id);
	    for(int i=vectorSize(cancelled_jobs) - 1; i >= 0; i--){
		  w_job_t *j = vectorElementAt(cancelled_jobs, i);
		  if(j == job){
		    vectorRemove(cancelled_jobs, i);
		    break;
		  }
	    }
	  }

	  Supr_decref(job);
        }
      pthread_mutex_unlock(jobs->mutex);
      pthread_setcancelstate(oldcancelstate, &oldcancelstate);
    //}

    if(thread_env->isInterrupted) break;
  }

  // cleanups...
  if(thread_env->isInterrupted) { // FXIME???
    basic_info("INTERRUPTed!");
    //kill(thread_env->R_pid, SIGUSR2);
    fprintf(stderr, "[%s]  TODO... (%s:%d)\n", __func__, __FILE__,
			  __LINE__);
    int status;
    pid_t pid = waitpid(cpid, &status, 0);
    pid = waitpid(thread_env->R_pid, &status, 0);
    if(pid == -1){
      if(errno == ECHILD) {
        printf("[%d] Warning: waitpid, %s\n", getpid(), strerror(errno));
      } else
        printf("[%d] Error: waitpid, %s\n", getpid(), strerror(errno));
    }

    pthread_mutex_lock(&currentThread->mutex);
      currentThread->state = THREAD_STATE_TERMINATED;
    pthread_mutex_unlock(&currentThread->mutex);

    return;


  } else if(cpid==0) {
  } else {
    int cmd = TR_EXIT;
    shm_io_write(io, io->out, &cmd, sizeof(int));
  }

  shm_io_destroy(io);


  int rc = pthread_mutex_trylock(&executor->mutex);
  if(rc != 0){
    pthread_mutex_lock(&currentThread->mutex);
      currentThread->state = THREAD_STATE_BLOCKED;
      currentThread->data = &executor->mutex;
    pthread_mutex_unlock(&currentThread->mutex);

    pthread_mutex_lock(&executor->mutex);
  }

    pthread_cond_signal(&executor->cond);
  pthread_mutex_unlock(&executor->mutex);

  if(cpid){
    int status;
    pid_t pid = waitpid(cpid, &status, 0);
    pid = waitpid(thread_env->R_pid, &status, 0);
    if(pid == -1){
      if(errno == ECHILD) {
        printf("[%d] Warning: waitpid, %s\n", getpid(), strerror(errno));
      } else
        printf("[%d] Error: waitpid, %s\n", getpid(), strerror(errno));
    }
  }


//  printf("\033[0;31m[%s:%d] TERMINATED\033[0m\n", __func__, currentThread->tid);
  pthread_mutex_lock(&currentThread->mutex);
    currentThread->state = THREAD_STATE_TERMINATED;
  pthread_mutex_unlock(&currentThread->mutex);

  pthread_cleanup_pop(TRUE);
}


/*
void UI_run(shm_io_info_t *io){

  while(TRUE){
    size_t size;
    void *bytes = shm_io_read(io, io->in, &size, NULL);
    int cmd = ((int*)bytes)[0]; 
//    printf("[%s] cmd = %d\n", __func__, cmd);

    // BEGIN_R_EVAL:
    SEXP res = R_NilValue;
    BEGIN_R_EVAL();
      // testing
      SEXP raw = PROTECT(allocVector(RAWSXP, size));
      memcpy(DATAPTR(raw), bytes, size); 
      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, null)));
      SEXP val = PROTECT(eval(call, R_GlobalEnv));
    

      const char *func_name = CHAR(asChar(VECTOR_ELT(val,0)));
      SEXP (*func)(SEXP args) = NULL;
      for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
        if(strcmp(R_callable_functions[i].name, func_name)==0){ // use qsearch
          func = R_callable_functions[i].func;
	  break;
        }
      }
//      printf("\033[0;36m[%s] func = %s\033[0m\n", __func__, func_name);
//      printf("\033[0;36m[%s] func = %p\033[0m\n", __func__, func);

      if(func) {
        int errorOccurred;
        res = R_simpleTryEval4(func, VECTOR_ELT(val,1), R_GlobalEnv,
		       	&errorOccurred);
      } else {
        res = R_NilValue; // change it to error 
      }

    END_R_EVAL();
    // END_R_EVAL:

    shm_io_write(io, io->out, bytes, size);
    free(bytes);
  }
}
*/

/*
void *UI_Run(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
//  printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
//  printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
//  printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;


  //supr_socket_conn_t *serverConn = (supr_socket_conn_t *) data;
  //data += sizeof(supr_conn_t *);
 // char *shm_name = (char*) data;
  //int port = ((int*)data)[0];
  shm_io_info_t *io = (shm_io_info_t *)data;
//  printf("[%s] io = %p\"\n", __func__, io);

//  supr_socket_conn_t *sock_conn = socketOpen(serverConn);


  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  if(io) UI_run(io);

  threadDestroy(th);
  pthread_exit(th);
  return NULL;
}
*/

void *executor_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;

  /*
  pthread_key_t th_key;
  pthread_key_create(&th_key, thread_destructor);
  pthread_setspecific(th_key, th);
  */
  pthread_setspecific(currentThreadKey, th);

  int nTaskrunners = ((int*) data)[0];

  free(th->name);
  char buf[64];
  sprintf(buf, "executor.%ld", syscall(SYS_gettid));
  th->name = strdup(buf);
  th->state = THREAD_STATE_RUNNABLE;

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  executor_run(nTaskrunners);

  pthread_exit(th); // FIXME
  return NULL;
}

char *taskrunner_name(){
  char buf[256];
  sprintf(buf, "taskrunner_%ld", syscall(SYS_gettid));
  return strdup(buf);
}

void *taskrunner_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;
  free(th->name);
  th->name = taskrunner_name();

  pthread_setspecific(currentThreadKey, th);

  supr_thread_t *executor = (supr_thread_t *) data;

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  taskrunner_run(executor);

  pthread_exit(th);
  return NULL;
}










supr_thread_t *startBackend(int port, char *master_addr)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, master_addr, &sem, &sth};
  int rc = pthread_create(&thread, NULL, backend_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  return sth;
}



#ifdef USE_SIGCHLD

void childProcMonitor_init(void *arg)
{
  sigset_t *sig_set = (sigset_t *) ((void **)arg)[0];
//  pthread_sigmask(SIG_UNBLOCK, sig_set, NULL);

  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
                  (unsigned long) &sig_set);
  *sth = th;
  free(th->name);
  char name[256];
  sprintf(name, "childProcMonitor.%d", gettid());
  th->name = strdup(name);
  th->state = THREAD_STATE_RUNNABLE;

  pthread_mutex_lock(sys_threads->mutex);
    vectorAdd(sys_threads, th);
  pthread_mutex_unlock(sys_threads->mutex);

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);
}

void childProcMonitor_cleanup(void *data)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}


void *childProcMonitor_run(void *arg)
{
  childProcMonitor_init(arg);

  pthread_cleanup_push(childProcMonitor_cleanup, NULL);

  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  basic_info(cth->name);

  sigset_t sig_set;
  sigemptyset(&sig_set);
  sigaddset(&sig_set, SIGCHLD);
  int s = pthread_sigmask(SIG_BLOCK, &sig_set, NULL);
  siginfo_t info;
  siginfo_t *ip = &info;

  while(TRUE){
  /*
    pthread_mutex_lock(&cth->mutex);
      pthread_cond_wait(&cth->cond, &cth->mutex);
    pthread_mutex_unlock(&cth->mutex);
    */
    /*
    {
      int sig;
      int rc = sigwait(&sig_set, &sig);
    }
    */
    cth->where = "childProcMonitor: sigwaitinfo";
    int sig =  sigwaitinfo(&sig_set, &info);
    cth->where = NULL;
    basic_info(cth->name);
    //
    Worker_SigactionCHLD(sig, ip, NULL);
    cth->where = NULL;
    {
      char buf[256];
      sprintf(buf, "%s, SIG: %d (SIGCHLD: %d), pid: %d", cth->name, 
		      ip->si_signo,
		      SIGCHLD, ip->si_pid);
      //basic_info(cth->name);
      basic_info(buf);
    }
    //

  }

  pthread_cleanup_pop(TRUE);
  return NULL;
}


supr_thread_t *startChildProcMonitor(sigset_t *sig_set)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {sig_set, &sem, &sth};
  int rc = pthread_create(&thread, NULL, childProcMonitor_run, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  //
  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  //
  
  return sth;
}

#endif

/*
supr_thread_t *startUI(shm_io_info_t *io)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {io, &sem, &sth};
  int rc = pthread_create(&thread, NULL, UI_Run, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
//  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}
*/

supr_thread_t *startExecutor(int nTaskrunners)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&nTaskrunners, &sem, &sth};
  int rc = pthread_create(&thread, NULL, executor_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  return sth;
}

supr_thread_t *startTaskrunner(supr_thread_t *executor)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {executor, &sem, &sth};
  int rc = pthread_create(&thread, NULL, taskrunner_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  return sth;
}


void __R_init(int argc, char **argv){


  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  Rf_initialize_R(new_argc, new_argv);
  void *dummy;
  R_CStackStart = (unsigned long) &dummy;
  R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
  setup_Rmainloop();

  R_thread_init();


}

int isLocalOrNFS(const char *dir_path)
{
  struct statfs buf;
  int rc;
  const char *path[] = {"/etc", "/home", dir_path};

  for(int i=0; i<sizeof(path)/sizeof(char*); i++){

    rc =  statfs(path[i], &buf);

    printf("\n ------------ %s -----------\n", path[i]);
    printf("\nf_type: %lx\n", buf.f_type);
    printf("\nf_bsize: %lx  // Optimal transfer block size\n", buf.f_bsize);
    printf("\n");
//    printf("========= EXT2_SUPER_MAGIC: %ld, EXT3_SUPER_MAGIC: %ld =====\n", EXT2_SUPER_MAGIC, EXT3_SUPER_MAGIC);
  }

  return -1; // TO DO

}

extern int setDir(const char *dir_path, const char *subdir);
/*
int setDir(const char *dir_path, const char *subdir){
  char buf[strlen(dir_path)+strlen(subdir)+2];

  DIR* dir = opendir(dir_path);
  if(!dir){
    printf("[%s] Error: %s\n", __func__, strerror(errno));
    return -1;
  } else {
    struct dirent *dp;
    while((dp = readdir (dir))){
      printf("[%s] %s\n", __func__, dp->d_name);
    }

	  // rewinddir(dir);
    closedir(dir);
  }

  sprintf(buf, "%s", dir_path);

  char b[strlen(subdir)+2];
  sprintf(b, "%s/", subdir);
  char *s = b;
  while(s && strstr(s, "/")){
    char *name = s;
    s =  strstr(s, "/");
    *s = 0; s++;
    sprintf(buf+strlen(buf), "/%s", name);
    printf("buf::: %s\n", buf);
    dir = opendir(buf);
    if(!dir){ // create
      if(mkdir(buf, 0700)==-1){
        printf("[%s] Error: mkdir, %s\n", __func__, strerror(errno));
	return -1;
      } else 
        printf("[%s] mkdir(%s, 0700)\n", __func__, buf);
    } else {
      closedir(dir);
    }
  }

  printf("s::: %s\n", s);

  sprintf(buf, "%s/%s", dir_path, subdir); 
  printf("[chdir]: %s\n", buf);
  int rc = chdir(buf);
  if(rc == -1)
     printf("[%s] Error: chdir(%s), %s\n", __func__, buf, strerror(errno));
  return rc;
}
*/

void Worker_check()
{
  // backend
  for(int i=0; i<vectorSize(threads); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
    int rc = pthread_mutex_trylock(&th->mutex);
    char buf[256];
    if(rc == 0){
      sprintf(buf, "name: %s, where: %s", th->name, th->where);
      pthread_mutex_unlock(&th->mutex);
    } else {
      sprintf(buf, "pthread_mutex_trylock(%s): %d (EDEADLK: %d, EBUSY: %d)", th->name, rc, EDEADLK, EBUSY);
    }
    basic_info(buf);
  }
}


void REPL_cleanup(void *data)
{
	basic_info("\033[0;31mEXIT_SUCCESS\033[0m");
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
//	sleep(200);
	sleep(2);
	exit(EXIT_SUCCESS);
}

void  R_REPL(supr_thread_t *this_thread, int argc, char **argv)
{
  pthread_cleanup_push(REPL_cleanup, NULL);

  /*
  vector_t *info_connections = newVector(TRUE); 
  if(info_sc){
    vectorAdd(info_connections, info_sc);
  }
  */

  double timeout = 5*Supr_options.timeout;
  while(TRUE){

    while(TRUE){
      main_thread_task_t *task = main_thread_tasks_get();
      if(task == NULL) break;

      BEGIN_R_EVAL();
        Rboolean success = R_ToplevelExec(task->fun, task->data);
        if(!success)
              error_info(R_curErrorBuf());
      END_R_EVAL();
      free(task);
    }

    pthread_mutex_lock(&this_thread->mutex);
      
      struct timespec wait;
      clock_gettime(CLOCK_REALTIME, &wait);
      wait.tv_sec += (long) timeout;
      int rc = pthread_cond_timedwait(&this_thread->cond, &main_thread->mutex,
		      &wait);

      /*
      if(rc !=0 ){
        if(rc == ETIMEDOUT) {
	  basic_info("ETIMEDOUT");
	  Worker_check();
	}
      }
      */

    pthread_mutex_unlock(&this_thread->mutex);
  }
  // exit(0);
  pthread_cleanup_pop(TRUE);
}

//struct sigaction R_oldSegvAct;


void Worker_gdb_xterm(int sig, int pid, int tid)
{
  int xterm_fd;
  char *slavename = NULL;
  FILE *f_slave = NULL;
  pid_t xterm_pid;

  char *pSptyName = NULL;
  if((xterm_fd = posix_openpt(O_RDWR | O_NONBLOCK | O_NOCTTY))==-1
             || grantpt(xterm_fd) == -1
             || unlockpt(xterm_fd) == -1
             || !(pSptyName = ptsname(xterm_fd))
         ) {
    error_info("posix_openpt | grantpt | unlockpt | ptsname, %s",
      strerror(errno));
      return;
  }

  int master = xterm_fd;
  slavename = pSptyName;

  /*
  int xterm_in_fd = open(slavename, O_RDONLY);
  int xterm_out_fd = open(slavename, O_WRONLY);
  int xterm_err_fd = open(slavename, O_WRONLY);

  int save_in  = dup(STDIN_FILENO);
  int save_out = dup(STDOUT_FILENO);
  int save_err = dup(STDERR_FILENO);

  dup2(xterm_in_fd, STDIN_FILENO);
  dup2(xterm_out_fd, STDOUT_FILENO);
  dup2(xterm_err_fd, STDERR_FILENO);
  */

  char buf[256], window[256];
  snprintf(buf, sizeof(buf), "-S%s/%d -e gdb -p %d", strrchr(slavename,'/')+1, master, pid);
  xterm_pid = fork();
  if(!xterm_pid) {
    int rc = execlp("xterm", "xterm", buf, (char *)0);
    error_info("execlp(\"xterm\", ...), %s", pid, strerror(errno));
        _exit(1);
  } else {
    
/*
    int status;
    basic_info("waitpid: Wait\n");
    errno = 0;
    int rc = waitpid(cpid, &status, 0);
    basic_info("(%s:%d) waitpid(%d, ...), rc: %d, status: %d, err: %s\n",
             __FILE__, __LINE__, cpid, rc, status, strerror(errno));
*/
//    basic_info("1. xterm_pid: %d", xterm_pid);

    f_slave = fopen(slavename, "r+");
    fgets(window, sizeof window, f_slave);
    basic_info("window: %s", window);


    int xterm_in_fd = open(slavename, O_RDONLY);
    int xterm_out_fd = open(slavename, O_WRONLY);
    int xterm_err_fd = open(slavename, O_WRONLY);

    int save_in  = dup(STDIN_FILENO);
    int save_out = dup(STDOUT_FILENO);
    int save_err = dup(STDERR_FILENO);

    dup2(xterm_in_fd, STDIN_FILENO);
    dup2(xterm_out_fd, STDOUT_FILENO);
    dup2(xterm_err_fd, STDERR_FILENO);
  
    //fclose(f_slave);
    fprintf(stderr, "%s:~ $ # pid=%d, tid=%d\n", Supr_hostname, pid, tid);
    fprintf(stderr, "%s:~ $ gdb -p %d\n", Supr_hostname, pid);

    pid_t gdb_pid = fork();
    if(gdb_pid){ // FIXME, see _gdb_C...

      int status;
      basic_info("waitpid: Wait\n");
      errno = 0;
      int rc = waitpid(gdb_pid, &status, 0);
      basic_info("(%s:%d) waitpid(%d, ...), rc: %d, status: %d, err: %s\n",
             __FILE__, __LINE__, gdb_pid, rc, status, strerror(errno));

      for(int i=0; i<10; i++) {
        sleep(2); // FIXME
	fprintf(stderr, "\033[0;31m.\033[0m");
      }
      exit(EXIT_FAILURE);
    } else {
      char pid_str[64];
      sprintf(pid_str, "%d", pid);
      int rc = execlp("gdb", "gdb", "-p", pid_str, (char *)0);
      if(rc==-1) 
        error_info("system(\"gdb - p %d\"), %s", pid, strerror(errno));
        _exit(1);
    }
    
    dup2(save_in, STDIN_FILENO);
    dup2(save_out, STDOUT_FILENO);
    dup2(save_err, STDERR_FILENO);

    kill(xterm_pid, SIGKILL);
  }

}

void  Worker_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  {
    error_info("\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
    Worker_gdb_xterm(sig, getpid(), (int)syscall(SYS_gettid));
  }

  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s@%s] pid=%d, tid=%ld\033[0m\n",
                    __func__, Supr_hostname, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(300);
  exit(1);
}

void  Worker_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s:%s] pid=%d, tid=%ld\033[0m\n",
		    Supr_hostname, __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);
  exit(1);

}

//extern supr_xterm_t *supr_xterm3(const char *window_name, char **argv, int window);
extern int X11_check();
extern int X11_stdout(); 

extern int SocketConn_cleanup(const char *service, int port);
extern int Config_getPort(const char *name);


extern void runAsDaemon(char *dir);

char *workerDir(int argc, char **argv)
{
  if(!Supr_usrHome)
    Supr_usrHome = getenv("SUPR_USR_HOME"); // FIXME

  char path[PATH_MAX];
  struct stat sb;
  if(!Supr_usrHome) {
     char *home = getenv("HOME"); // FIXME
     if(!home){
           fprintf(stderr, "No home directory is avialable");
           return NULL;
     }
     sprintf(path, "%s/.supr", home);
     if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
       Supr_usrHome = strdup(path);
     else if(mkdir(path, 0700) != -1)
       Supr_usrHome = strdup(path);
  }

  if(!Supr_usrHome) {
           fprintf(stderr, "No usr.home is avialable");
           return NULL;
  }

  sprintf(path, "%s/%s", Supr_usrHome, SYS_COMMAND_WORKER);

  if(stat(path, &sb) == -1) {
    if(mkdir(path, 0700) == -1){
      perror(path);
      return NULL;
    }
  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    return NULL;
  }

  char *dir_suffix = "0";
  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-dir")==0 && i < argc-1){
        dir_suffix = argv[++i];
	break;
    }
  }

  sprintf(path + strlen(path), "/%s_%s", Supr_hostname, dir_suffix);

  if(stat(path, &sb) == -1) {
    if(mkdir(path, 0700) == -1){
      perror(path);
      return NULL;
    }
  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    return NULL;
  }

  return strdup(path);
}

char *Supr_getSysHome()
{
  char path[PATH_MAX];
  BEGIN_R_EVAL();
      SEXP call = PROTECT(LCONS(install(".libPaths"), R_NilValue));
      SEXP paths = PROTECT(eval(call, R_GlobalEnv));
      for(int i=0; i<LENGTH(paths); i++){
        const char *s = CHAR(STRING_ELT(paths,i));
	sprintf(path, "%s/supr3", s);
	if(access(path, F_OK)==0)
	  break;
        else path[0] = 0;
      }
      UNPROTECT(2);
  END_R_EVAL();

  if(strlen(path))
    Supr_sysHome = strdup(path);
  else
    Supr_sysHome = NULL;

  return Supr_sysHome;

}

extern int __rm_recursive__(const char *pathname);

void Worker_removeTaskrunnerDirs(const char * Worker_dir)
{
      fprintf(stderr, "%s(%s): \n", __func__, Worker_dir);
  DIR *dir = opendir(Worker_dir);
  if(!dir) {
    fprintf(stderr, "Error: %s, %s\n", Worker_dir, strerror(errno));
    return;
  }

  struct dirent *dp;
  while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0
         || strncmp(dp->d_name, ".nfs", 4)==0)
              continue;

      char *s = dp->d_name;
      while(*s && isdigit(*s)) s++;

      fprintf(stderr, "? %s\n", dp->d_name);
      if(*s) continue;

      char path[PATH_MAX];
      sprintf(path, "%s/%s", Worker_dir, dp->d_name);
      fprintf(stderr, "rm %s\n", path);
      __rm_recursive__(path); 
  }
}

const char *__doc__ = 
"worker [-port n] [--verbose] [--debug] [--info] [--help]\n"
"\t[-info addr] [-notify addr][-master address] [-ntrs k]\n"
	"The options are as follows:\n"
	"\t--help  print this message.\n"
	"\t-port   number, the socket server port number.\n"
	"\t-master //host:port, the master socket server address.\n"
	"\t-ntrs   k or\n"
	"\t-nTaskrunners  k, the number of taskrunners.\n";

extern void Supr_killall(char *name);

/*
void debugHandleCommand(supr_socket_conn_t *conn, vector_t *connections)
{
  int fd = conn->fd;
  //conn->print(conn);

  char msg[1024];
  int cmd;
  {
    ssize_t n = 0;
    for( ; ; ) {
      n = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
      if(n <= 0){
        //fprintf(stderr, "\033[0;31mrecv conn(fd: %d) is disconnected " "(n=%ld)\033[0m\n\n", conn->fd, n);
        char buf[256];
        sprintf(buf, " [%s:%d:%s:RemoveConn] fd: %d, type: %d, recv size = %ld",
			__FILE__, __LINE__, __func__, conn->fd, conn->type, n);
        Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

        vectorRemoveElement(connections, conn);
        if(conn->type == MASTER_CONN){
           system_exit(CLUSTER_SHUTDOWN); // TODO
        } else if (conn->type == TR_PRINT_STDOUT){
          fprintf(stderr, "TR-%d, disconnected\n", conn->pid);
        }
        close(conn->fd);
        Supr_decref(conn);
        return;
      } else if( n == INT_SIZE) break;
    }

    if(Supr_debug){
      char buf[256];
      sprintf(buf, "[%s] fd: %d, type: %d, recv size = %ld, cmd = %d (%s)",
                   __func__, conn->fd, conn->type, n, cmd, cmd2char(cmd));
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);
    }

  }


  switch(cmd){

    case CLUSTER_PING:
         {
           read(fd, &cmd, INT_SIZE);
           int cmd = CLUSTER_PONG;
           write(fd, &cmd, INT_SIZE);
         }
         return;


    case 0:
    default: 
      {
        read(fd, &cmd, sizeof(int));

	sprintf(msg, "\033[0;32m%s pid: %d, tid: %d\033[0m",
		       	__func__, getpid(), gettid());
        Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

	for(int i=0; i < vectorSize(sys_threads); i++){
          supr_thread_t *th = (supr_thread_t *)vectorElementAt(sys_threads,i);
	  sprintf(msg, "thread[%d] name: %s, tid: %d", i, th->name, th->tid);
          Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
	  //
	  if(!pthread_equal(th->ptid, pthread_self())){
	    vector_t *strace = newVector(FALSE);
	    th->fun = do_backtrace;
	    th->data = strace;
	    pthread_mutex_lock(&th->mutex);
	      pthread_kill(th->ptid, SIG_BACKTRACE);
	      pthread_cond_wait(&th->cond, &th->mutex); // do timedwait !
	    pthread_mutex_unlock(&th->mutex);
            Cluster_sendSimpleMessage(__func__, msg_color, DEBUG_INFO_TYPE, 0);
	    while(vectorSize(strace)){
	      char *line = vectorRemove(strace, 0);
	      fprintf(stderr, "line: %s\n", line);
              Cluster_sendSimpleMessage(line, msg_color, DEBUG_INFO_TYPE, 0);
	      free(line);
	    }
	    vectorDestroy(strace);
	    th->fun = NULL;
	    th->data = NULL;
	  }
	  //
	}

	if(Supr_debug){
	  char *buf= NULL;
	  Supr_debug2(getpid(), &buf); // TODO
	  if(buf)
            Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

	  free(buf);
	}
	
	int rc = 0;
        write(fd, &rc, sizeof(int));
      }
      break;
  }
}

void worker_debug_thread_cleanup(void *data){
  Cluster_sendSimpleMessage(__func__, msg_color, DEBUG_INFO_TYPE, 0);
}


void debug_run(supr_socket_conn_t *debugConn, const char *info_addr)
{
  pthread_cleanup_push(worker_debug_thread_cleanup,
		  pthread_getspecific(currentThreadKey));

  vector_t *connections = newVector(FALSE);
  vectorAdd(connections, debugConn);

  char msg[1024];

    while(TRUE) {
      
      struct timeval tv;
      tv.tv_sec=100;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      int max_fd = 0;

      for(int i=0; i<vectorSize(connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(connections, i);

        int fd = conn->fd;
        FD_SET(fd, &readfds);

        if(fd > max_fd) max_fd = fd;
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }

      for(int i = vectorSize(connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(connections, i);
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
                continue;

        if(conn == debugConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(debugConn);
          sprintf(msg, "\033[0;34mNewConn, host: %s, fd: %d\033[0m\n",
                          clientConn->host, clientConn->fd);
          Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

          if(clientConn && clientConn->fd != -1){
            vectorAdd(connections, clientConn);
          }
        } else {
          debugHandleCommand(conn, connections);
        }
      }
  }

  pthread_cleanup_pop(TRUE);
}
*/

/*
void *debug_init(void *arg)
{
  void **args = (void**)arg;
  int port = ((int*)args[0])[0];
  char *info_addr = (char *) args[1];
  sem_t *sem = (sem_t *) args[2];
  supr_thread_t **sth = (supr_thread_t **) args[3];

  //{
  int reuse_addr = port ? SocketConn_reuseAddr : FALSE;
  supr_socket_conn_t *debugConn = serverSocketOpen(port, reuse_addr);
  // FIXME: TODO
#define DEBUG_CONN 7001
  debugConn->type = DEBUG_CONN;
  //}

  //if(debugConn){
    supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
                  (unsigned long) &args[0]);

    *sth = th;
    free(th->name);
    char name[256];
    sprintf(name, "debug.%d.%d", getpid(), gettid());
    th->name = strdup(name);
    th->conn = debugConn;

    vectorAdd(sys_threads, th);

    pthread_setspecific(currentThreadKey, th);
  //}

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  if(debugConn)
    debug_run(debugConn, info_addr);

  pthread_exit(th);
  return NULL;
}
*/



/*
supr_thread_t *startDebugThread(int port, const char * info_addr)
{

  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, (char*) info_addr, &sem, &sth};
  int rc = pthread_create(&thread, NULL, debug_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);


  return sth;
}
*/

void Supr_load(void *data){

  supr_options_t save_supr_options;
  memcpy(&save_supr_options, &Supr_options, sizeof(supr_options_t));

          SEXP check_lib = PROTECT(LCONS(install(".libPaths"), R_NilValue));
          SEXP lib =  eval(check_lib, R_GlobalEnv);
          fprintf(stderr, ".libPaths():\n");
          PrintValue(lib);
          UNPROTECT(1);

          SEXP call = PROTECT(LCONS(install("library"),
                           CONS(mkString(PACKAGE_NAME), R_NilValue)));
          eval(call, R_GlobalEnv);
          UNPROTECT(1);

  //basic_info("Supr_options.ncpu: %d", Supr_options.ncpu);
  save_supr_options.ncpu = Supr_options.ncpu;

  memcpy(&Supr_options, &save_supr_options, sizeof(supr_options_t));
  Supr_infov = Supr_options.info;
  Supr_debug = Supr_options.debug;
  Supr_verbose = Supr_options.verbose;


}

// data = {SEXP, SO_serialized_t **, ..., SEXP, SO_serialized_t **, NULL}?
void Worker_SO_init(void *data){
  if(!data) return;

  void **args = (void**) data;

  for(int i=0; args[i]; i++){
    
    SO_serialized_t *SO_val = malloc(sizeof(SO_serialized_t));
    SEXP val = R_NilValue;
    SEXP call = PROTECT(LCONS(install("serialize"),
                          CONS((SEXP) args[i], CONS(R_NilValue, R_NilValue))));
    SEXP raw = eval(call, R_BaseEnv);
    SO_val->ptr = malloc(LENGTH(raw));
    memcpy(SO_val->ptr, RAW(raw), LENGTH(raw));
    SO_val->size = LENGTH(raw);
    UNPROTECT(1);
    *((SO_serialized_t **)args[++i]) = SO_val;
  }
}

void rmConnLog()
{
  char path[PATH_MAX];
  getcwd(path, PATH_MAX);
  while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
  sprintf(path+strlen(path), "/%s.log", cmd);
  unlink(path);

}

extern pid_t main_pid;
extern char *Cluster_netstat_C(int port, char *args);
extern void doCleanups();

extern vector_t *cleanups;


void send_ExitInfo(){
  if(getpid() != main_pid) return;

  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  basic_info(__func__);
  if(cth) basic_info(cth->name);
  else return;

  supr_socket_conn_t *sc = NULL;
  if(info_addr && (sc = trySocketOpen1(info_addr))){
    int fd = sc->fd;

    int cmd = CLUSTER_PROC_CMD;
    write(fd, &cmd, sizeof(int));
    int len = strlen(proc_cmd)+1;
    write(fd, &len, sizeof(int));
    write(fd, proc_cmd, len);
    int rc;
    read(fd, &rc, sizeof(int));

    char msg[1024];

    if(Supr_options.verbose) {
    for(int i=0; threads && i<vectorSize(threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);

      // msg_header?
      cmd = CLUSTER_INFO;
      write(fd, &cmd, sizeof(int));
      unsigned char buf[8]; 
      snprintf(buf, 8, "%s", msg_color); 
      write(fd, buf, sizeof(buf));
      int type = DEFAULT_INFO_TYPE;
      write(fd, &type, sizeof(int));
      int level = 0; // not used
      write(fd, &level, sizeof(int));

      sprintf(msg, "\033[0;33m%d: %s, tid: %d, state: %s, \tname: %s\033[0m",
	    getpid(), __func__, th->tid, state2char(th->state), th->name);

      ssize_t len_msg = strlen(msg)+1;
      write(fd, &len_msg, sizeof(ssize_t));
      write(fd, msg, len_msg);
      read(fd, &rc, sizeof(int));
    }

    for(int i=0; i< vectorSize(executors); i++){

      supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
      //pthread_mutex_lock(&th->mutex);
      pthread_mutex_trylock(&th->mutex); // FIXME
        vector_t *threads = ((executor_property_t *)th->properties)->taskrunners;
      pthread_mutex_unlock(&th->mutex);

      pthread_mutex_lock(threads->mutex);

        for(int i=vectorSize(threads)-1; i>=0; i--){
          supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);

	  //basic_info(th->name);

	  //pthread_cancel(th->ptid);
          // msg_header?
          cmd = CLUSTER_INFO;
          write(fd, &cmd, sizeof(int));
          unsigned char buf[8]; 
          snprintf(buf, 8, "%s", msg_color); 
          write(fd, buf, sizeof(buf));
          int type = DEFAULT_INFO_TYPE;
          write(fd, &type, sizeof(int));
          int level = 0; // not used
          write(fd, &level, sizeof(int));

          sprintf(msg, "\033[0;33m%s:%d: %s, tid: %d, state: %s, \tname: %s\033[0m",
		    __FILE__, __LINE__, __func__, 
		    th->tid, state2char(th->state), th->name);

          ssize_t len_msg = strlen(msg)+1;
          write(fd, &len_msg, sizeof(ssize_t));
          write(fd, msg, len_msg);
          read(fd, &rc, sizeof(int));
        }

      pthread_mutex_unlock(threads->mutex);
    }
    }

    cmd = CLUSTER_INFO;
    write(fd, &cmd, sizeof(int));
    unsigned char buf[8]; 
    snprintf(buf, 8, "%s", msg_color); 
    write(fd, buf, sizeof(buf));
    int type = DEFAULT_INFO_TYPE;
    write(fd, &type, sizeof(int));
    int level = 0; // not used
    write(fd, &level, sizeof(int));

    sprintf(msg, "\033[0;35m%d %s[%s], .., terminated, cleanups: %p\033[0m",
		    getpid(), __func__, Supr_curStrError, cleanups);

    ssize_t len_msg = strlen(msg)+1;
    write(fd, &len_msg, sizeof(ssize_t));
    write(fd, msg, len_msg);
    read(fd, &rc, sizeof(int));

  } else {
    fprintf(stderr, "func: %s[%s], this tid: %ld, pid: %d ..., terminated",
		    __func__, Supr_curStrError,
		    syscall(SYS_gettid),  getpid());
  }

  doCleanups();
	/*
  if(getpid() != main_pid)
	  return;

  basic_info(__func__);
  char buf[1024];
  sprintf(buf,"pid: %d, ...", getpid());
  basic_info(buf);
  //sleep(120);
  */

	/*
  if(getpid() != main_pid)
          return;

  basic_info(__func__);
  char buf[1024];
  sprintf(buf,"pid: %d, ...", getpid());
  basic_info(buf);

  if(socketServerConn) {
    basic_info("\nKill taskrunners based on netstat info:\n");
    char *netstat = Cluster_netstat_C(socketServerConn->port, NULL);
    basic_info(netstat);
    close(socketServerConn->port);
    char *s = netstat;
    while(s = strstr(s, "taskrunner")){
      while(s != netstat && !isspace(*s)) s--; 
      s++;
      pid_t pid = atoi(s);
      sprintf(buf, "kill taskrunner %d", pid);
      basic_info(buf);
      kill(pid, SIGKILL);
      s = strstr(s, "taskrunner") + strlen("taskrunner");
    }
    free(netstat);
  }
  basic_info(__FILE__);

  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorRemove(socket_connections,i);
    close(sc->fd);
  }


  //sleep(120);
  */
}





char *cmd_is_running(const char *dir, const char *cmd, char **file_name_addr){
  char path[PATH_MAX];
  if(dir) strcpy(path, dir);
  else getcwd(path, PATH_MAX);
  char *log = NULL;
  while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
  sprintf(path+strlen(path), "/%s.log", cmd);
  *file_name_addr = strdup(path);
  if(access(path, F_OK)==0){
    struct stat statbuf;
    int fd = open(path, O_RDONLY);
    int rc = fstat(fd, &statbuf);
    if(rc==0 && fd !=-1){
      log = malloc(statbuf.st_size+1);
      read(fd, log, statbuf.st_size);
      log[statbuf.st_size] = 0;
    }
    close(fd);
  }

  return log;
}

static char *getDefaultAddr(const char *which){
  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  struct stat sb;
  int fd = open(path, O_RDONLY);
  if(fd != -1 && fstat(fd, &sb) != -1) {

    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    buf[sb.st_size] = 0;
    close(fd);

    char *s = buf;
    while((s = strstr(s, which)) && (s = strstr(s, "//"))){
      char *t = strstr(s, "\n") + 2;
      if(t) {*t=0; t++;}
      if(strstr(s, Supr_hostname)){
         s = strdup(s);
         break;
      }
      s = t;
    }

    if(s) return s;
  }

  char buf[strlen(Supr_hostname)+32];
  sprintf(buf, "%s:1024+", Supr_hostname);
  return strdup(buf);
}


SEXP Worker_interrupt(SEXP what);
extern SEXP (*Supr_interrupt_ptr)(SEXP what);

// TODO...
#ifdef USE_SIGCHLD
void Worker_SigactionCHLD(int sig, siginfo_t *ip, void *context)
{	
  char msg[256];
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  {
    sprintf(msg, "\033[0;33m%s, ip->si_pid: %d, this pid: %d\033[0m",
		    cth->name, ip->si_pid, getpid());
    basic_info(msg);
  }


  pid_t pid;
  pid = ip->si_pid;

  int wstatus;
  int rc = waitpid(pid, &wstatus, 0);
  {
    sprintf(msg, "\033[0;33m%s, waitpid(%d, ...): %d", cth->name, pid, rc);
    basic_info(msg);
  }

  /*
  for(int i=0; i< vectorSize(executors); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
    pthread_mutex_lock(&th->mutex); 
      thread_info_t *info = (thread_info_t *) malloc(sizeof(thread_info_t)
		    +sizeof(int));
      th->data = info; // use task_stack instead?
      info->type    = SIGNAL_RCVD;
      info->padding = SIGCHLD;
      ((int*) (info + 1))[0] = pid;
      info->data = info + 1;
      pthread_cond_signal(&th->cond);
    pthread_mutex_unlock(&th->mutex);
  }
  */

}
#endif

//void (*Worker_do_xterm)(int use_xterm) = Supr_do_xterm;
/*
void Worker_do_xterm(int use_xterm){

  static supr_thread_t *gdb_thread = NULL;
  static char *xterm_name = NULL;

  if(use_xterm){
    if(gdb_thread){
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        if(gdb_thread->name) {
	  //
	} else {
          void *ret_val;
          rc = pthread_join(gdb_thread->ptid, &ret_val);
	  // destroy...
	}
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
      gdb_thread = NULL; // FIXME... destroy 
    }

    if(!gdb_thread){ // if(!xterm_name || !gdb_thread)
      Supr_gdb_C(0, TRUE, &gdb_thread, &xterm_name);
      Supr_options.xterm = 1;
      fprintf(stderr, "%s:%d. tid: %d\n\n", __FILE__, __LINE__,
    	gdb_thread->tid);
      sleep(1);
    
// testing
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        rc = pthread_cond_signal(&gdb_thread->cond);
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
    }

    //fprintf(stderr, "tid: %d, rc: %d\n", gdb_thread->tid, rc);

  } else {
    basic_info("%s(%s): TODO...", __func__, use_xterm? "TRUE":"FALSE");
    xterm_name = NULL;
    if(gdb_thread){
      int rc = pthread_cancel(gdb_thread->ptid);
      fprintf(stderr, "pthread_cancel, rc: %d\n", rc);
      void *ret_val;
      rc = pthread_join(gdb_thread->ptid, &ret_val);
      fprintf(stderr, "pthread_join, rc: %d\n", rc);
      for(int i=0; i<10; i++) fprintf(stderr, "\n");
      gdb_thread = NULL;
    }
    Supr_options.xterm = 0;
  }
}
*/

void Worker_do_ncpu(int ncpu){
    basic_info("%s(%s): TODO...", __func__, ncpu? "TRUE":"FALSE");
}

// ./worker -dir 00
int main(int argc, char **argv)
{
/*
  fprintf(stderr, "%s: path=%s\n", proc_cmd, argv[0]);
  fprintf(stderr, "%s: $DISPLAY=\"%s\"\n", proc_cmd, getenv("DISPLAY"));
  for(int i=0; i<argc; i++) fprintf(stderr, "\t%s\n", argv[i]);
*/
  //proc_cmd = argv[0];
  //while(strstr(proc_cmd, "/")) proc_cmd = strstr(proc_cmd, "/")+1;
  //proc_cmd = strrchr(argv[0], '\n');

  Supr_do_xterm_ptr = Supr_do_xterm;
  Supr_do_ncpu_ptr = Worker_do_ncpu;

  R_Interactive = FALSE;

//  Worker_do_xterm(TRUE); - X11 OK
// sleep(10);

  //proc_cmd = argv[0];
  //while(strstr(proc_cmd, "/")) proc_cmd = strstr(proc_cmd, "/")+1;

  Supr_getPthreads_ptr = Worker_getPthreads;
  Supr_interrupt_ptr = Worker_interrupt;

  cmd = argv[0]; 

  int port = -1;
      
  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--verbose")==0){
      Supr_options.verbose = Supr_verbose = TRUE;
    } else if(strcmp(argv[i], "--debug")==0){
      Supr_options.debug = Supr_debug = TRUE;
    } else if(strcmp(argv[i], "--info")==0){
      Supr_options.info= Supr_infov = TRUE;
    } else if(strcmp(argv[i], "-master")==0 && i+1 < argc){
            master_addr = argv[++i];
    } else if(strcmp(argv[i], "-notify")==0 && i+1 < argc){
            notify_addr = argv[++i];
    } else if(strcmp(argv[i], "-dfs")==0 && i+1 < argc){
            dfs_addr = argv[++i];
    } else if(strcmp(argv[i], "-port")==0 && i < argc-1){
       port = atoi(argv[++i]);
       if(port < 1024) port = 1024;
       if(strstr(argv[i], "+")) nports = 0;
    } else if(strcmp(argv[i], "-X11")==0 && i < argc-1){
       X11_str = argv[++i];
    }
  }

//Supr_options.debug = 1;


/*
  fprintf(stderr, "[worker:://%s] 1. %d do Supr_gdb_C. \n", Supr_hostname,
  	getpid());
  if(Supr_options.debug)// && --xterm ... TODO
    Supr_gdb_C(0, TRUE, &gdb_thread, &xterm_name);
  fprintf(stderr, "1. %d do Supr_gdb_C. OKAY?\n", getpid());
  
  fprintf(stderr, "xterm_name: %s\n", xterm_name);
*/

  //sleep(50);


  for(int i=0; i<argc; i++){ // direct connection for debugging
    if(strcmp(argv[i], "-info")==0 && i+1 < argc){
      info_addr = strdup(argv[i+1]);
      char *hostname = strdup(info_addr);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      info_sc = socketOpen2(hostname, port);
      if(info_sc) {
        info_sc->port = port;
        int cmd = CLUSTER_PROC_CMD;
        write(info_sc->fd, &cmd, sizeof(int));
        char *proc_cmd = argv[0];
        while(strstr(proc_cmd, "/"))
          proc_cmd = strstr(proc_cmd, "/")+1;
        int len = strlen(proc_cmd)+1;
        write(info_sc->fd, &len, sizeof(int));
        write(info_sc->fd, proc_cmd, len);
        int rc;
        read(info_sc->fd, &rc, sizeof(int));
      }

      debug_sc = info_sc;
      Cluster_sendSimpleMessage(argv[0], msg_color, VERBOSE_INFO_TYPE, 0);
      Cluster_sendSimpleMessage("hostname and userhome:", msg_color,
		      VERBOSE_INFO_TYPE, 0);
      Cluster_sendSimpleMessage(Supr_hostname, msg_color, VERBOSE_INFO_TYPE, 0);
      Cluster_sendSimpleMessage(Supr_usrHome, msg_color, VERBOSE_INFO_TYPE, 0);
      Cluster_sendSimpleMessage("\n", msg_color, VERBOSE_INFO_TYPE, 0);
      free(hostname);
      break;
    }
  }

//  basic_info("xterm_name: %s\n", xterm_name); // FIXME

  for(int i=0; i<argc; i++) {
    if(strcmp(argv[i], "--help")==0){
      fprintf(stderr, "%s\n", __doc__);
      exit(EXIT_SUCCESS);
    }
  }

  if( port <= 0 ) {
//      port = Config_getPort("Worker");
    char *addr = getDefaultAddr("Worker");

    //if(!addr) backend_exit();

    port = atoi(strstr(addr, ":")+1);
    if(strstr(strstr(addr, ":")+1, "+"))
            nports = 0;
    else
            nports = 1;
    basic_info("[%s] default port: %d%s\n", __func__, port, nports?"":"+");
    basic_info("use default addr: %s", addr);
    free(addr);

  }


  if(debug_sc) {
    struct sigaction sa;
    sa.sa_sigaction = Worker_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGSEGV, &sa, &R_oldSegvAct);
  }

  /*
  for(int i=0; i<argc; i++){
    verbose_info("argv[%d] %s", i, argv[i]);
    basic_info("argv[%d] %s", i, argv[i]);
    //Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
    //fprintf(stderr, "%s\n", msg);
  }
  */
  argv_info(argc, argv);


  //Supr_killall(SYS_COMMAND_TASKRUNNER);

#ifdef RUN_AS_DAEMON_PROC
  char *dir = workerDir(argc, argv);
  if(!dir)
    exit(EXIT_FAILURE);

  char buf[256];
  sprintf(msg, "host: %s, ppid: %d, pid: %d, Time: %s, call: runAsDaemon()",
                  Supr_hostname, getppid(), getpid(),
                  Exec_timestamp(buf, sizeof(buf)));
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  {
    sprintf(msg, "Supr_sysHome: %s", Supr_sysHome);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }

  runAsDaemon(dir);

  basic_info("%s. \033[0;33mpid: %d, ppid: %d, $DISPLAY: \"%s\"\033[0m",
 	proc_cmd, getpid(), getppid(), getenv("DISPLAY"));

  //int use_xterm = FALSE;
  //Worker_do_xterm(use_xterm);

  main_pid = getpid();
  atexit(send_ExitInfo);

  sprintf(msg, "host: %s, ppid: %d, pid: %d, Time: %s",
                  Supr_hostname, getppid(), getpid(),
                  Exec_timestamp(buf, sizeof(buf)));
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  char *cmd_log = NULL;
  char *file_name = NULL;
  pid_t worker_pid;
  if(cmd_log = cmd_is_running(NULL, cmd, &file_name)) {
    sprintf(msg, "Warning: %s exists,\n%s", file_name, cmd_log);
    Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);

    if(strstr(cmd_log, "pid:")){
      pid_t pid = atoi(strstr(cmd_log, "pid:") + 4);
      worker_pid = pid;
      errno = 0;
      int rc = kill(pid, 0);
      if(rc == 0){
        basic_info("kill(%d, 0): %d, %s", pid, rc, strerror(errno));

	// leave it as is. as a feature ... ?
        if(notify_addr && nports){
          supr_socket_conn_t *sc=trySocketOpen1(cmd_log);
          if(!sc){
            sc = socketOpen1(cmd_log);
            if(sc) {
              basic_info("can connect to the server... (too many pending connections)");
            } else {
              basic_info("cannot connect to the server (kill the master proc?)");
            }
          } else {
              basic_info("can connect to the server");
          }
          char *shm_name = Supr_signal_shm_create(pid, SIGINT, CLUSTER_INFO,
                   (void*)info_addr, info_addr ? (strlen(info_addr)+1) : 0);
        }


      } else if(rc == -1 && errno == ESRCH){
        //sprintf(msg, "kill(%d, 0): %s", pid, strerror(errno));
        //Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
        char path[PATH_MAX];
        //sprintf(msg, "Removing %s", file_name);
        //Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
        unlink(file_name);
        free(cmd_log);
        free(file_name);
        cmd_log = NULL;
      }
    } else {
      Cluster_sendSimpleMessage("pid not found", msg_color, ERROR_INFO_TYPE, 0);
    }
  }

  if(cmd_log){
    if(nports){
      if(notify_addr){
        Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_MASTER);
      }
      Cluster_sendSimpleMessage("q(\"no\")", msg_color, ERROR_INFO_TYPE, 0);
      exit(EXIT_FAILURE);
    } else {
        basic_info("Warning: ignore existing worker.log: %s", cmd_log);
	kill(worker_pid, SIGKILL);
        free(cmd_log);
        free(file_name);
        cmd_log = NULL;
    }
  }



  /*
  //
  if(info_sc)
  { // free(info_sc); info_sc = 0; char *hostname = strdup(info_addr); char *s = strstr(hostname, ":"); if(s) *s = 0; s++; int port = atoi(s); info_sc = socketOpen2(hostname, port); 

    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "CWD: %s", CWD_PATH);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

    //if(info_sc) //{ info_sc->port = port;
	Supr_debug = TRUE;
	Supr_infov = TRUE;
	Supr_verbose = TRUE;

	int debug_port = -1;
	{
	  char cn_file[PATH_MAX];
          sprintf(cn_file, "%s/supr.conf", Supr_usrHome);
        //Cluster_sendSimpleMessage(cn_file, "\033[0;34m", VERBOSE_INFO_TYPE, 0);
          int rc = access(cn_file, R_OK);
          int fd = open(cn_file, O_RDWR, 0600);
          struct stat sb;
          if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {
            //char buf[sb.st_size+1];
            char *buf = malloc(sb.st_size+1);
            read(fd, buf, sb.st_size);
            close(fd);

            buf[sb.st_size] = 0;
            char *line = strtok(buf, "\n");
            char * namenode_line = NULL;
            while(line){
              if(*line != '#' && strstr(line, "Worker")
                              && strstr(line, Supr_hostname)) {
		while(line){
                  if(*line != '#' && strstr(line, "debug.port")){
			  // FIXME?
		    line = strtok(strstr(line, "debug.port")
			    +strlen("debug.port"), " \t\n");
		    if(line) debug_port  = atoi(line);
		    break;
		  }
                  line = strtok(NULL, "\n");
		}
                break;
              }
              line = strtok(NULL, "\n");
            }
	    free(buf);
          }
        }
        sprintf(msg, "[%s:%d:%s:%d] start debug thread: %s:%d",
		    __FILE__, __LINE__, __func__, getpid(),
		    Supr_hostname, debug_port);
        Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

	sleep(1);
	debug_thread = startDebugThread(debug_port, info_addr);

	if(debug_thread){
          sprintf(msg, "[%s:%d:%s:%d] Reconnected with debug connection: %s:%d",
		    __FILE__, __LINE__, __func__, getpid(),
		    debug_thread->conn->host, debug_thread->conn->port);
          Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
	}

    //}

    //free(hostname);
  }

  */

  if(Supr_debug){
    sprintf(msg, "worker pid: %d, hostname: %s", getpid(), Supr_hostname);
    Cluster_sendSimpleMessage(msg, "\033[0;31m", DEBUG_INFO_TYPE, 0);
  }

//

  // syslog(LOG_NOTICE, "supr2/bin/master started");
  // ...
//  char buf[256];
  fprintf(stderr, "host: %s, ppid: %d, pid: %d\nTime: %s\n",
                  Supr_hostname, getppid(), getpid(),
                  Exec_timestamp(buf, sizeof(buf)));
#endif

    for(int i=0; i<argc; i++) {
      printf("\033[0;31m%d@%s argv[%d] %s\033[0m\n", getpid(), Supr_hostname, i, argv[i]);
    }


  
#define SUPR_DEBUG
#ifndef SUPR_DEBUG
  int devNull = open("/dev/null", O_WRONLY);
  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);
  dup2(devNull, STDERR_FILENO);
  dup2(devNull, STDOUT_FILENO);
#endif
  int nTaskrunners = 0; // FIXME

  for(int i=0; i<argc-1; i++) {
    if( strcmp(argv[i], "-ntrs")==0
       || strcmp(argv[i], "-nTaskrunners")==0) {
      nTaskrunners = atoi(argv[++i]);
    }
  }

  if(nTaskrunners == 0) nTaskrunners = Supr_options.ncpu;
  

  //printf("nTaskrunners: %d\n", nTaskrunners);
  if(nTaskrunners <= 0) {
	  /*
    double cpu_usage = CPU_usage();
    int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
    nTaskrunners = (int) ((ncpu - cpu_usage/100)*0.80);
    */
    nTaskrunners = sysconf(_SC_NPROCESSORS_ONLN);
    if(nTaskrunners <= 2 )
      nTaskrunners = 2;
  }

  {
    sprintf(msg, "nTaskrunners: %d", nTaskrunners);
    Cluster_sendSimpleMessage(msg, "\033[0;31m", VERBOSE_INFO_TYPE, 0);
  }

  // FIXME
  void *dummy= NULL;
  PTHREAD_INTERRUPTED = &dummy;
  void *timeout_dummy= NULL;
  PTHREAD_TIMEOUT = &timeout_dummy;

  PTHREAD_SYNCHRONIZED = malloc(INT_SIZE);
  PTHREAD_NOTIFIED     = malloc(INT_SIZE);
  JOB_CANCELLED     = malloc(INT_SIZE);

  //pthread_key_create(&taskrunnerThreadKey, NULL);

  UID = geteuid();

  //cleanups = newVector(FALSE);
  jobs = newVector(TRUE);
  cancelled_jobs = newVector(TRUE);
  all_jobs = newVector(TRUE); // DELETE_ME?
  taskrunners_to_join = newVector(TRUE);

  char hostname[256];
  gethostname(hostname, 256);
  char *subdir = hostname;// "00";
  for(int i=0; i<argc; i++) {
    if(strcmp(argv[i], "-dir")==0 && i < argc-1)
	    subdir = argv[i+1];
  }


//  int port = 0;
  char *shm_name = NULL;

//  char *master_addr = NULL;

  char *_stdout = NULL;
  char *_window = NULL;

  for(int i=0; i<argc; i++){
     if(strcmp(argv[i], "-port")==0 && i < argc-1)
       port = atoi(argv[++i]);
     else if(strcmp(argv[i], "-shm")==0 && i < argc-1)
       shm_name = argv[++i];
     else if(strcmp(argv[i], "-master")==0 && i < argc-1)
       master_addr = argv[++i];
     else if(strcmp(argv[i], "-reuse.addr")==0 && i < argc-1)
     { 
       if(strcmp(argv[++i], "FALSE")==0) SocketConn_reuseAddr = FALSE;
     }
     else if(strcmp(argv[i], "--window")==0)
       _window =  "--window";

  }

  suprHomeInit();

  {
    sprintf(msg, "Supr_sysHome: %s", Supr_sysHome);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }

 // printf("\033[0;32m\n");
  printf("[%s] SUPR_HOMEUSR = %s\n", argv[0], SUPR_HOMEUSR);
  printf("[%s] SUPR_HOMESYS = %s\n", argv[0], SUPR_HOMESYS);
  printf("[%s] port = %d\n", argv[0], port);
  printf("[%s] shm_name = %s\n", argv[0], shm_name);
//  printf("\033[0m\n");

  // use port ...
  //if(port == -1 && getenv("SUPR_WORKER_PORT")){ port = atoi(getenv("SUPR_WORKER_PORT")); }
  if( port <= 0 ) {
//      port = Config_getPort("Worker");
    char *addr = getDefaultAddr("Worker");

    //if(!addr) backend_exit();

    port = atoi(strstr(addr, ":")+1);
    if(strstr(strstr(addr, ":")+1, "+"))
            nports = 0;
    else
            nports = 1;
    fprintf(stderr, "[%s] default port: %d\n", __func__, port);

    sprintf(msg, "use default addr: %s", addr);
    Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
    free(addr);

  }


  /*
  int pong = tryPingSocketServer2(Supr_hostname, port);
  sprintf(msg, "tryPingSocketServer2(%s, %d): %d",
                      Supr_hostname, port, pong);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  //if(pong != CLUSTER_PONG){
    switch(pong){
      case -1: // OK socketOpen2 return NULL
           //break;
      case -2: // cannot write
      case -3: // cannot read
      default:
           {
             sprintf(msg, "worker with the same port %d is running on %s"
                             "\n\tkill ...",
                      port, Supr_hostname);
             Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
             vector_t *killed_cmds = newVector(FALSE);
             Supr_killSocketServer("worker", port, killed_cmds);
             for(int i=vectorSize(killed_cmds)-1; i>=0; i--) {
               char *s = (char*) vectorRemove(killed_cmds, i);
               Cluster_sendSimpleMessage(s, "\033[0;31m", VERBOSE_INFO_TYPE, 0);
               free(s);
             }
             vectorDestroy(killed_cmds);
           }
           break;
    }
  //}
  */

    /*
  if(debug_sc) {
    struct sigaction sa;
    sa.sa_sigaction = Thread_SigactionBacktrace;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIG_BACKTRACE, &sa, &R_oldSigBacktraceAct);
  }
  */

  //vectorAdd(sys_threads, main_thread);
  main_thread_id = pthread_self(); // FIXME in __dl_init()

  if(info_sc)
  { // free(info_sc); info_sc = 0; char *hostname = strdup(info_addr); char *s = strstr(hostname, ":"); if(s) *s = 0; s++; int port = atoi(s); info_sc = socketOpen2(hostname, port); 

    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "CWD: %s", CWD_PATH);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

    //if(info_sc) //{ info_sc->port = port;
	//Supr_debug = TRUE; Supr_infov = TRUE; Supr_verbose = TRUE;

	int debug_port = -1;
	{
	  char cn_file[PATH_MAX];
          sprintf(cn_file, "%s/supr.conf", Supr_usrHome);
        //Cluster_sendSimpleMessage(cn_file, "\033[0;34m", VERBOSE_INFO_TYPE, 0);
          int rc = access(cn_file, R_OK);
          int fd = open(cn_file, O_RDWR, 0600);
          struct stat sb;
          if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {
            //char buf[sb.st_size+1];
            char *buf = malloc(sb.st_size+1);
            read(fd, buf, sb.st_size);
            close(fd);

            buf[sb.st_size] = 0;
            char *line = strtok(buf, "\n");
            char *namenode_line = NULL;
            while(line){
              if(*line != '#' && strstr(line, "Worker")
                              && strstr(line, Supr_hostname)) {
		while(line){
                  if(*line != '#' && strstr(line, "debug.port")){
			  // FIXME?
		    line = strtok(strstr(line, "debug.port")
			    +strlen("debug.port"), " \t\n");
		    if(line) debug_port  = atoi(line);
		    break;
		  }
                  line = strtok(NULL, "\n");
		}
                break;
              }
              line = strtok(NULL, "\n");
            }
	    free(buf);
          }
        }
        sprintf(msg, "[%s:%d:%s:%d] start debug thread: %s:%d",
		    __FILE__, __LINE__, __func__, getpid(),
		    Supr_hostname, debug_port);
        Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

	{
             vector_t *killed_cmds = newVector(FALSE);
             Supr_killSocketServer("worker", debug_port, killed_cmds);
             for(int i=vectorSize(killed_cmds)-1; i>=0; i--) {
               char *s = (char*) vectorRemove(killed_cmds, i);
               Cluster_sendSimpleMessage(s, "\033[0;31m", VERBOSE_INFO_TYPE, 0);
               free(s);
             }
             vectorDestroy(killed_cmds);
	}
//	sleep(1);
	/*
	debug_thread = startDebugThread(debug_port, info_addr);

	if(debug_thread){
          sprintf(msg, "[%s:%d:%s:%d] Reconnected with debug connection: %s:%d",
		    __FILE__, __LINE__, __func__, getpid(),
		    debug_thread->conn->host, debug_thread->conn->port);
          Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
	}
	*/

    //}

    //free(hostname);
  }



  /*
#define DONOT_PORT_CLEANUP
#ifdef  DO_PORT_CLEANUP
  SocketConn_cleanup(SYS_COMMAND_WORKER, port);
#else
  if(port>0)
    SocketConn_cleanup(SYS_COMMAND_WORKER, port);
#endif
*/

  // chdir
  /*
  {
    char buf[strlen(subdir)+strlen("worker/")+2];
    sprintf(buf, "worker/%s", subdir);
    setDir(SUPR_HOMEUSR, buf);

    char cwd[PATH_MAX];
    char *s = getcwd(cwd, PATH_MAX);
    printf("cwd: %s\n", s);
    Worker_dir = (char*) malloc(strlen(s)+1);
    sprintf(Worker_dir, "%s", s);

    chdir(SUPR_HOMESYS);
  }
  */

  //  Worker_dir = (char*) malloc(strlen(s)+1);
  Worker_dir = dir;
  printf("Worker_dir: %s\n", Worker_dir);
  fprintf(stderr, "Worker_dir: %s\n", Worker_dir);

  Worker_removeTaskrunnerDirs(Worker_dir);
  Taskrunner_sdl_count = 0;

  // open shm_io
  shm_io_info_t *io = NULL;
  if(shm_name){
    io = shm_io_open(shm_name);
    shm_io_write(io, io->out, shm_name, strlen(shm_name)+1);
  }

  SUPR_setSignalHandler(NULL, NULL, NULL);

  /*
#define __USE_SIGINT__
#ifdef  __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionInt;
    sa.sa_sigaction = C_Taskrunner_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, NULL);
  }
#endif
  */

  syncEnvironment = newHashtable(TRUE);
  waitEnvironment = newHashtable(TRUE);
  countdownEnvironment = newHashtable(TRUE);

  if(!threads)
    threads = newVector(TRUE);
  executors = newVector(TRUE);
  tr_threads = newVector(TRUE);

  // initialized R_eval
  __R_init(argc, argv);

  printf("Supr_sysHome: %s\n", Supr_sysHome);
  //Supr_sysHome = NULL;
  //Supr_sysHome = SUPR_HOMESYS = getenv("SUPR_SYS_HOME");
  //Supr_usrHome = SUPR_HOMEUSR;

  printf("Supr_sysHome: %s\n", Supr_sysHome);
  if(!Supr_sysHome){
    Supr_sysHome = Supr_getSysHome();
    SUPR_HOMESYS = Supr_sysHome;
    /*
    BEGIN_R_EVAL();
      SEXP call = PROTECT(LCONS(".libPaths", R_NilValue));
      SEXP paths = PROTECT(eval(call, R_GlobalEnv));
      for(int i=0; i<LENGTH(paths); i++){
        const char *path = CHAR(STRING_ELT(paths,i));
      }
      UNPROTECT(2);
    END_R_EVAL();
    */
  }
  printf("Supr_sysHome: %s\n", Supr_sysHome);


#ifndef SUPR_DEBUG
  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
#endif
  // start timeout monitor
  //supr_thread_t *timeout_monitor = startTimeoutMonitor();
  //vectorAdd(threads, timeout_monitor);
  
  // for debug ...
  /*
  {
    struct sigaction sa;
    sa.sa_sigaction = Worker_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGSEGV, &sa, &R_oldSegvAct);
  }
  */
  Worker_sigaction();
  /*
  {
    R_segvAct.sa_sigaction = Worker_SigactionSegv;
    sigemptyset(&R_segvAct.sa_mask);
    R_segvAct.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &R_segvAct, &R_oldSegvAct);
  }
  */

  {
    struct sigaction sa;
    sa.sa_sigaction = Worker_SigactionSIGPIPE;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGPIPE, &sa, NULL);
  }

  BEGIN_R_EVAL();
    R_ToplevelExec(Supr_load, NULL);
    void *data[] = {R_NilValue, &SO_null, NULL};
    R_ToplevelExec(Worker_SO_init, data);
  END_R_EVAL();


  //if(nTaskrunners == 0)
  if(Supr_options.ncpu > 0)
    nTaskrunners = Supr_options.ncpu;

  //basic_info("nTaskrunners: %d", nTaskrunners);

  {
    sprintf(msg, "Supr_sysHome: %s", Supr_sysHome);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }

  if(main_thread) {
    free(main_thread->name);
    sprintf(msg, "main_thread.%d", getpid());
    main_thread->name = strdup(msg);
    vectorAdd(sys_threads, main_thread);
  }

//int tr_count = 0; // for count down ...
//pthread_mutex_t *tr_count_mutex = NULL;
  
  tr_count_mutex = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(tr_count_mutex, NULL);
  __tr_count = tr_count = nTaskrunners;

  atexit(rmConnLog);

  messages_cond = malloc(sizeof(pthread_cond_t));
  pthread_cond_init(messages_cond, NULL);

  /*
  {
    char shm_name[256];
    sprintf(shm_name, "%s-%d-bc-sem", shm_prefix, getpid());
    int nsem = 100; // FIXME
    ssize_t size = nsem*(2*sizeof(int) + sizeof(sem_t));
    bc_sem_ptr = Supr_shm_create(shm_name, size); // do unlink atexit...
    ((int*) bc_sem_ptr)[0] = nsem;
    sem_t *sem = (sem_t*) (bc_sem_ptr+2*sizeof(int));
    sem_init(sem, 1, 1);
    ((int*) bc_sem_ptr)[1] = 1; // number of activated semaphores?
  }
  */
  //Broadcast_init();

#ifdef USE_SIGCHLD
  {
	  //
	  /*
    struct sigaction sa;
    //sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sa.sa_sigaction = Worker_SigactionCHLD;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGCHLD, &sa, NULL);
    */
    //

    sigset_t sig_set;
    sigemptyset(&sig_set);
    sigaddset(&sig_set, SIGCHLD);
    //pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
    pthread_sigmask(SIG_BLOCK, &sig_set, NULL);

    //sigset_t old_sig_set;
    //sigprocmask(SIG_BLOCK, &sig_set, &old_sig_set);
    //int rc =  int sigismember(&old_sig_set, SIGCHLD);

  }

#endif


  /*
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionInt;
    sa.sa_sigaction = C_Taskrunner_SigactionInt; // for terminating taskrunners? 
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, NULL);
  }
  */

  main_thread_tasks = newVector(TRUE);

  // start backend
  supr_thread_t *backend = startBackend(port, (char*) master_addr);
  vectorAdd(threads, backend);
  backendThread = backend;

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
      vectorElementAt(socket_connections, 0);
    //printf("main:");
    //conn->print(conn);
    if(io) shm_io_write(io, io->out, &conn->port, sizeof(int));
  pthread_mutex_unlock(&main_thread->mutex);

#ifdef USE_SIGCHLD
  {
    sigset_t sig_set;
    sigemptyset(&sig_set);
    sigaddset(&sig_set, SIGCHLD);
    supr_thread_t *childProcMonitor = startChildProcMonitor(&sig_set);
    vectorAdd(threads, childProcMonitor);
  }
#else
  signal(SIGCHLD, SIG_IGN);
#endif
  // start User interface ?
  /*
  supr_thread_t *ui = startUI(io);
  vectorAdd(threads, ui);
  */

  /*
  {
     BEGIN_R_EVAL();
       SEXP call = PROTECT(LCONS(install("library"),
                           CONS(mkString("supr2"), R_NilValue)));
       eval(call, R_GlobalEnv);
       UNPROTECT(1);
     END_R_EVAL();

     if(TRUE){
       printf("\033[0;32mSupr_sysHome: %s@%s\n", Supr_sysHome, Supr_hostname);
       printf("Supr_usrHome: %s@%s\033[0m\n", Supr_usrHome, Supr_hostname);
     }

  }
  */
  //Supr_sysHome = SUPR_HOMESYS = getenv("SUPR_SYS_HOME");
  //Supr_usrHome = SUPR_HOMEUSR;

  

  

  //printf("Supr_sysHome: %s\n", Supr_sysHome);

  // start executor
  supr_thread_t *executor = startExecutor(nTaskrunners);
  vectorAdd(threads, executor);
  vectorAdd(executors, executor);
  
  // start R_eval service -- not really
  R_REPL(main_thread, argc, argv);
  /*
  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
  pthread_mutex_unlock(&main_thread->mutex);
  */
  
  exit(0);
}

// let taskrunners to handle automatically...
void shutdown_killTaskrunners()
{

      /*
    for(int i=vectorSize(threads)-1; i>=0; i--){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
        const char *name = th->name;
        char tid_str[32];
        if(!name) {
          name = tid_str;
          sprintf(tid_str, "%d", th->tid);
        }
        SET_STRING_ELT(row_names, i, mkChar(name));
        pthread_mutex_lock(&th->mutex);
          SET_STRING_ELT(state, i, mkChar(state2char(th->state)));
        pthread_mutex_unlock(&th->mutex);
        INTEGER(tid)[i] = th->tid;
    }
	*/

  for(int i=0; i< vectorSize(executors); i++){

    supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
    pthread_mutex_lock(&th->mutex);
      vector_t *threads = ((executor_property_t *)th->properties)->taskrunners;
      pthread_mutex_lock(threads->mutex);


      for(int i=vectorSize(threads)-1; i>=0; i--){
        supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
	//basic_info(th->name);
	pthread_cancel(th->ptid);
      }

      pthread_mutex_unlock(threads->mutex);
    pthread_mutex_unlock(&th->mutex);
  }

}

SEXP Worker_getPthreads()
{
  SEXP worker_threads = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP s = worker_threads;
  for(int i=0; i< vectorSize(executors); i++){

    supr_thread_t *th = (supr_thread_t *) vectorElementAt(executors,i);
    pthread_mutex_lock(&th->mutex);
      vector_t *threads = ((executor_property_t *)th->properties)->taskrunners;

  ////
  SEXP r;
  BEGIN_R_EVAL();

  // return as a data.frame
    int nrow = vectorSize(threads);
    int ncol = 2; // for now
    r = PROTECT(allocVector(VECSXP, ncol));
    SEXP names = PROTECT(allocVector(STRSXP, ncol));
    SEXP row_names = PROTECT(allocVector(STRSXP, nrow));

    ncol = 0;

    SEXP tid = PROTECT(allocVector(INTSXP, nrow));
    SET_STRING_ELT(names, ncol, mkChar("tid"));
    SET_VECTOR_ELT(r, ncol++, tid);

    SEXP state = PROTECT(allocVector(STRSXP, nrow));
    SET_STRING_ELT(names, ncol, mkChar("state"));
    SET_VECTOR_ELT(r, ncol++, state);

    setAttrib(r, R_ClassSymbol, mkString("data.frame"));
    setAttrib(r, R_NamesSymbol, names);
    setAttrib(r, install("row.names"), row_names);

    pthread_mutex_lock(threads->mutex);

    for(int i=vectorSize(threads)-1; i>=0; i--){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
        const char *name = th->name;
        char tid_str[32];
        if(!name) {
          name = tid_str;
          sprintf(tid_str, "%d", th->tid);
        }
        SET_STRING_ELT(row_names, i, mkChar(name));
        pthread_mutex_lock(&th->mutex);
          SET_STRING_ELT(state, i, mkChar(state2char(th->state)));
        pthread_mutex_unlock(&th->mutex);
        INTEGER(tid)[i] = th->tid;
    }

    pthread_mutex_unlock(threads->mutex);

    UNPROTECT(3+ncol);
  END_R_EVAL();
  ////
      SETCDR(s, CONS(r, R_NilValue));
      s = CDR(s);
      SET_TAG(s, install(th->name));
    pthread_mutex_unlock(&th->mutex);
  }

  UNPROTECT(1);

  return CDR(worker_threads);

}

static void Taskrunner_interrupt(void *data)
{
	debug_info(__func__);
  SEXP what = (SEXP) data;
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  pthread_mutex_lock(&cth->mutex);
    cth->fun = NULL;
    char buf[256];
    sprintf(buf, "TODO: %s", cth->name);
    cth->data = mkString(buf);
    pthread_cond_signal(&cth->cond);
  pthread_mutex_unlock(&cth->mutex);
}

/*
SEXP Supr_mkError(const char *str)
{
  SEXP err = PROTECT(mkString(str));
  setAttrib(err, R_ClassSymbol, mkString("SuprError"));
  UNPROTECT(1);
  return err;
}
*/

SEXP Worker_interrupt(SEXP what){
	debug_info(__func__);
  int rc = 0;
  SEXP ret_val = NULL;
  if(TYPEOF(what) == LISTSXP || TYPEOF(what) == VECSXP){
    const char *th_name = NULL;
    SEXP S_name = R_NilValue;
    if(TYPEOF(what) == LISTSXP){
      SEXP s = what;
      while(TYPEOF(s) != NILSXP){
        if(TYPEOF(TAG(s)) != NILSXP && (
	         strcmp(CHAR(PRINTNAME(TAG(s))), "tr")==0
	         ||strcmp(CHAR(PRINTNAME(TAG(s))), "taskrunner")==0)){
		S_name = CAR(s);
		break;
        }
	s = CDR(s);
      }
    } else if (TYPEOF(what) == VECSXP){
      SEXP names = getAttrib(what, R_NamesSymbol);
      for(int i=0; i<LENGTH(what); i++){
        if(names != R_NilValue && (
	         strcmp(CHAR(STRING_ELT(names, i)), "tr")==0
	         ||strcmp(CHAR(STRING_ELT(names, i)), "taskrunner")==0)){
		S_name=VECTOR_ELT(what, i);
		break;
	}
      } 
    }

    if(TYPEOF(S_name) == STRSXP && LENGTH(S_name)>0){
      th_name = CHAR(STRING_ELT(S_name, 0));
    } else {
      return Supr_mkError("invalid 'tr' argument");
    }

    if(!th_name){
      return Supr_mkError("'tr' not found");
    } else if(strstr(th_name, ".")){
      pid_t pid = atoi(strstr(th_name, ".")+1);
      rc = kill(pid, 0);
      if(rc == -1) 
        return Supr_mkError(strerror(errno));
      //{
      /*
        if(!sem)
          error(_("[%s:%d] Supr_shm_create(%s), %s"), __FILE__,__LINE__, shm_name,
                    strerror(errno));
        shm_unlink(shm_name);
	*/
         char shm_name[128];
         sprintf(shm_name, "%s-%d-taskrunner", shm_prefix, pid);
	 BEGIN_R_EVAL();
	    SEXP call = PROTECT(LCONS(install("serialize"), CONS(what,
					    CONS(R_NilValue, R_NilValue))));
	    SEXP val = PROTECT(eval(call, R_GlobalEnv));
	    ssize_t size = LENGTH(val);
            unsigned char *ptr =(unsigned char*)Supr_shm_create(shm_name, size);
	    // FIXME: push shm_name for cleanup ...
	    if(ptr){
	      memcpy(ptr, RAW(val), size);
	      UNPROTECT(2);
	      munmap(ptr, size);
	    }
	 END_R_EVAL();
      //}
      rc = kill(pid, SIGINT); // debugging ...
      sprintf(msg, "kill(%d, SIGINT): %d, %s", pid, rc, strerror(errno));
      debug_info(msg);
    } else {
      return Supr_mkError("invalid 'tr' argment");
    }

    /*
    for(int i=0; ret_val==NULL && i< vectorSize(executors); i++){

      supr_thread_t *executor = (supr_thread_t *) vectorElementAt(executors,i);
      pthread_mutex_lock(&executor->mutex);
        vector_t *threads =
	       	((executor_property_t *)executor->properties)->taskrunners;
        for(int i=vectorSize(threads)-1; i>=0; i--){
          supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
	  if(strcmp(th->name, th_name)==0){
            pthread_mutex_lock(&th->mutex);
debug_info(th->name);
              th->fun = Taskrunner_interrupt;
              th->data = what;
	      int rc = pthread_kill(th->ptid, SIGINT);
	      if(rc == 0){

		double timeout = Supr_options.timeout;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

                pthread_cond_timedwait(&th->cond, &th->mutex, &wait);

	        if(th->fun == NULL && th->data){
	          ret_val = th->data;
		} else {
debug_info("timeout");
		  ret_val = Supr_mkError("timeout");
		}
	      }
            pthread_mutex_unlock(&th->mutex);
	    break;
	  }
	}
      pthread_mutex_unlock(&executor->mutex);
    }
    */
  }
  if(ret_val) 
	  return ret_val;
  else
	  return ScalarInteger(rc);
}


void Worker_dumper()
{
  fprintf(stderr, "[%s] TODO ...\n", __func__);
}
