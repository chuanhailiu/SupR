
//#include <Rversion.h>
#include "Configure.h"
#include <setjmp.h>

#ifndef __SUPR_H__ 
#define __SUPR_H__ 

#ifndef __SUPR_OBJECT_TYPE__
#define __SUPR_OBJECT_TYPE__

typedef enum {
//  ROBJ     = 0,
  STRING   = 1,
  INT      = 2,
  VECTOR   = 3, //
  ITERATOR = 4, // iterator
  TASK     = 5, //
  R_SEXP   = 6,
  STRING_ARRAY   = 7,
  EXT     = 8,
  INT_MATRIX   = 9,
  NULL_VALUE   = 10,
  RAW_DATA   = 11,
  DATA_STREAM   = 12,
  INT_ARRAY   = 13,
  SHM_TYPE    = 14,
  SIZE_ARRAY   = 15,
  CALL_TYPE    = 16,
  ERROR_TYPE    = 17,
  DD_TYPE    = 18,
  DATAFRAME_TYPE    = 19,
  MEM_TMP_TYPE      = 20,
  MEM_SHM_TYPE      = 21,
  SOCKET_TYPE       = 22,
  COMMAND_TYPE      = 23,
  SHM_ALLOC         = 24,
  SHM_FREE          = 25,
  URL_TYPE       = 26,
  ROBJ     = 27,
  RUNNABLE     = 28,
  JOB_SUBSET    = 29,
  SHM_OBJ_TYPE  = 30,
  UNBOUND_VALUE = -1
} so_type_t;

//#warning "including __SUPR_OBJECT_TYPE__ from mydefn.h"
//#error "including __SUPR_OBJECT_TYPE__ from mydefn.h"

//storage [type|size|...]
typedef struct supr_obj { // obj header
  so_type_t type;
//  unsigned int hint; // padding...
  size_t    size;
  void      *val;
} supr_obj_t;

typedef struct _supr_obj { // obj header
  so_type_t type;
  unsigned int hint; // padding...
  size_t    size;
  void      *val;
} _supr_obj_t; // included by sdfs.c

#define FILE_HINT_TXT 101
#define FILE_HINT_CSV 102
#define FILE_HINT_ROBJ 103
//#define FILE_HINT_RDATA 104


#ifndef __SUPR_DATAFRAME__
#define __SUPR_DATAFRAME__
typedef struct supr_dataframe {
  supr_obj_t header;
  size_t ncol;
  size_t *offsets; // counted from the beginning of the block
} supr_dataframe_t;
#endif



typedef struct shm_obj { // obj header
  so_type_t type; // SHM_TYPE
  char      shm_name[64];
  char      var_name[64];
  size_t    offset;
  size_t    size;
} shm_obj_t;


#ifdef __USE_SUPR_CONN__
#define __USE_SUPR_CONN_H__

extern void print_supr_obj(supr_obj_t *so, const char *name);
extern int supr_write_supr_obj(int fd, supr_obj_t *so); // default for now
extern supr_obj_t *supr_read_supr_obj(int fd);

#endif

typedef enum {
  MAIN = 0,
  MASTER = 1,
  WORKER = 2,
  DRIVER = 3,
  TASK_RUNNER = 4,
  GDM = 5, // graphical device manager
  SDFS_MASTER = 6,
  SDFS_NODE = 7, // service node
  OTHER_TYPE  = 8
} session_type_t;


typedef struct session_list {
        const char *host; // hostname
        int port; // socket server port
        char *ip;
        int fd;
        session_type_t type;
        const char *name; // command name such as R etc...
        double heartbeat_time; // last heartbeat time...
        struct session_list *next_session;
} session_list_t;

/*
typedef struct supr_context {
        const char *hostname; // socket service hostname
        const char *ip_addr;  // socket service ip address
        int service_port;
        int main_loop_fd;
        int master_fd;
        int listen_fd; // added 10/22/2019
        session_list_t *sessions;
} supr_context_t;

extern void print_supr_context(supr_context_t *c);
extern void suprAddSession(int type, int connfd);
*/

#endif



#endif

extern void SDFS_version();
//#define SDFS_MASTER 0
//#define SDFS_NODE 1
extern int SDFS_start(char *, int type, pthread_t *thread, int *port);

#include <R_ext/Callbacks.h>

// void R_Busy(int which)
extern void (*ptr_R_Busy)(int);


//extern R_ToplevelCallbackEl * Rf_addTaskCallback(R_ToplevelCallback cb,
//       	void *data, void (*finalizer)(void *), const char *name, int *pos);

//extern const char *sexptype2char(SEXPTYPE type);
extern SEXP R_NewHashedEnv(SEXP enclos, SEXP size);
extern SEXP R_Visible;

// Defn.h
/*
typedef SEXP (*CCODE)(SEXP, SEXP, SEXP, SEXP);

typedef enum {
    PP_INVALID  =  0,
    PP_ASSIGN   =  1,
    PP_ASSIGN2  =  2,
    PP_BINARY   =  3,
    PP_BINARY2  =  4,
    PP_BREAK    =  5,
    PP_CURLY    =  6,
    PP_FOR      =  7,
    PP_FUNCALL  =  8,
    PP_FUNCTION =  9,
    PP_IF       = 10,
    PP_NEXT     = 11,
    PP_PAREN    = 12,
    PP_RETURN   = 13,
    PP_SUBASS   = 14,
    PP_SUBSET   = 15,
    PP_WHILE    = 16,
    PP_UNARY    = 17,
    PP_DOLLAR   = 18,
    PP_FOREIGN  = 19,
    PP_REPEAT   = 20
} PPkind;


typedef enum {
    PREC_FN      = 0,
    PREC_EQ      = 1,
    PREC_LEFT    = 2,
    PREC_RIGHT   = 3,
    PREC_TILDE   = 4,
    PREC_OR      = 5,
    PREC_AND     = 6,
    PREC_NOT     = 7,
    PREC_COMPARE = 8,
    PREC_SUM     = 9,
    PREC_PROD    = 10,
    PREC_PERCENT = 11,
    PREC_COLON   = 12,
    PREC_SIGN    = 13,
    PREC_POWER   = 14,
    PREC_SUBSET  = 15,
    PREC_DOLLAR  = 16,
    PREC_NS      = 17
} PPprec;


typedef struct {
        PPkind kind;     // deparse kind 
        PPprec precedence; // operator precedence 
        unsigned int rightassoc;  // right associative? 
} PPinfo;


typedef struct {
    char   *name;    // print name 
    CCODE  cfun;     // c-code address
    int    code;     // offset within c-code
    int    eval;     // evaluate args? 
    int    arity;    // function arity
    PPinfo gram;     // pretty-print info
} FUNTAB;


extern FUNTAB R_FunTab[];
*/

extern void Rf_checkArityCall(SEXP op, SEXP args, SEXP call);

extern int R_PPStackTop;

enum {
    CTXT_TOPLEVEL = 0,
    CTXT_NEXT     = 1,
    CTXT_BREAK    = 2,
    CTXT_LOOP     = 3,  /* break OR next target */
    CTXT_FUNCTION = 4,
    CTXT_CCODE    = 8,
    CTXT_RETURN   = 12,
    CTXT_BROWSER  = 16,
    CTXT_GENERIC  = 20,
    CTXT_RESTART  = 32,
    CTXT_BUILTIN  = 64  /* used in profiling */
};

typedef struct {
    int tag;
    union {
        int ival;
        double dval;
        SEXP sxpval;
    } u;
} R_bcstack_t;


//#define JMP_BUF jmp_buf
// R-3.6.2

#ifndef VALUE_TO_STRING
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)
#endif

#ifndef R_USE_SIGNALS
#define R_USE_SIGNALS
#endif
#ifndef HAVE_POSIX_SETJMP
#define HAVE_POSIX_SETJMP
#endif


#ifndef HAVE_POSIX_SETJMP
#define HAVE_POSIX_SETJMP
#endif

#ifdef R_USE_SIGNALS
#ifdef HAVE_POSIX_SETJMP
# define SIGJMP_BUF sigjmp_buf
# define SIGSETJMP(x,s) sigsetjmp(x,s)
# define SIGLONGJMP(x,i) siglongjmp(x,i)
# define JMP_BUF sigjmp_buf
# define SETJMP(x) sigsetjmp(x,0)
# define LONGJMP(x,i) siglongjmp(x,i)
#else
# define SIGJMP_BUF jmp_buf
# define SIGSETJMP(x,s) setjmp(x)
# define SIGLONGJMP(x,i) longjmp(x,i)
# define JMP_BUF jmp_buf
# define SETJMP(x) setjmp(x)
# define LONGJMP(x,i) longjmp(x,i)
#endif
#endif



/* Stack entry for pending promises */
typedef struct RPRSTACK {
    SEXP promise;
    struct RPRSTACK *next;
} RPRSTACK;

/* Evaluation Context Structure */
#if R_VERSION_MAJOR_NUM >= 4 && R_VERSION_MINOR_NUM >= 0
//&& R_VERSION_PATCH_NUM >= 0

#define DONT_BIND_UNBOUNDVALUE

typedef struct RCNTXT {
    struct RCNTXT *nextcontext; /* The next context up the chain */
    int callflag;               /* The context "type" */
    JMP_BUF cjmpbuf;            /* C stack and register information */
    int cstacktop;              /* Top of the pointer protection stack */
    int evaldepth;              /* evaluation depth at inception */
    SEXP promargs;              /* Promises supplied to closure */
    SEXP callfun;               /* The closure called */
    SEXP sysparent;             /* environment the closure was called from */
    SEXP call;                  /* The call that effected this context*/
    SEXP cloenv;                /* The environment */
    SEXP conexit;               /* Interpreted "on.exit" code */
    void (*cend)(void *);       /* C "on.exit" thunk */
    void *cenddata;             /* data for C "on.exit" thunk */
    void *vmax;                 /* top of R_alloc stack */
    int intsusp;                /* interrupts are suspended */
    int gcenabled;              /* R_GCEnabled value */
    int bcintactive;            /* R_BCIntActive value */
    SEXP bcbody;                /* R_BCbody value */
    void* bcpc;                 /* R_BCpc value */
    SEXP handlerstack;          /* condition handler stack */
    SEXP restartstack;          /* stack of available restarts */
    struct RPRSTACK *prstack;   /* stack of pending promises */
    R_bcstack_t *nodestack;
    R_bcstack_t *bcprottop;
    SEXP srcref;                /* The source line in effect */
    int browserfinish;          /* should browser finish this context without
                                   stopping */
    SEXP returnValue;           /* only set during on.exit calls */
    struct RCNTXT *jumptarget;  /* target for a continuing jump */
    int jumpmask;               /* associated LONGJMP argument */
} RCNTXT, *context;


#else

typedef struct RCNTXT {
    struct RCNTXT *nextcontext; /* The next context up the chain */
    int callflag;               /* The context "type" */
    JMP_BUF cjmpbuf;            /* C stack and register information */
    int cstacktop;              /* Top of the pointer protection stack */
    int evaldepth;              /* evaluation depth at inception */
    SEXP promargs;              /* Promises supplied to closure */
    SEXP callfun;               /* The closure called */
    SEXP sysparent;             /* environment the closure was called from */
    SEXP call;                  /* The call that effected this context*/
    SEXP cloenv;                /* The environment */
    SEXP conexit;               /* Interpreted "on.exit" code */
    void (*cend)(void *);       /* C "on.exit" thunk */
    void *cenddata;             /* data for C "on.exit" thunk */
    void *vmax;                 /* top of R_alloc stack */
    int intsusp;                /* interrupts are suspended */
    int gcenabled;              /* R_GCEnabled value */
    int bcintactive;            /* R_BCIntActive value */
    SEXP bcbody;                /* R_BCbody value */
    void* bcpc;                 /* R_BCpc value */
    SEXP handlerstack;          /* condition handler stack */
    SEXP restartstack;          /* stack of available restarts */
    struct RPRSTACK *prstack;   /* stack of pending promises */
    R_bcstack_t *nodestack;
    SEXP srcref;                /* The source line in effect */
    int browserfinish;          /* should browser finish this context without
                                   stopping */
    SEXP returnValue;           /* only set during on.exit calls */
    struct RCNTXT *jumptarget;  /* target for a continuing jump */
    int jumpmask;               /* associated LONGJMP argument */
} RCNTXT, *context;

#endif


extern RCNTXT* R_ToplevelContext;  /* The toplevel context */
extern RCNTXT* R_GlobalContext;


#define begincontext		Rf_begincontext
void begincontext(RCNTXT*, int, SEXP, SEXP, SEXP, SEXP, SEXP);

# define endcontext		Rf_endcontext
void endcontext(RCNTXT*);

