
#include "supr.h"
#include "util.h"

#include <math.h>
#include <sys/types.h>
#include <sys/wait.h>


// FIXME
#ifndef _
#define _(x) (x)
#endif

#define msg_color "\033[0;32m"


/*
class_t *newClass(char *name, char *(*toString)(class_t *, void *))
{
  class_t *c = (class_t *) malloc(sizeof(class_t));
  c->name = name;
  c->toString = toString;
  return c;
}
*/

#define gettid() ((int)syscall(SYS_gettid))

#define SUPR_MALLOC 1
#ifdef SUPR_MALLOC 

#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)

void __supr_free__1(void *p)
{
  __supr_free__(p, __func__, __FILE__, __LINE__);
}

#define __free_func__ __supr_free__1

#else

#define __free_func__ free

#endif

#define RUN_AS_DAEMON_PROC

#define CANNOT_FIND_JOB 2
#define JOB_WAS_CANCELLED 3

#define driver_color "\033[0;32m"

#define KEEP_JOB FALSE 

//#define DRIVER_MALLOC_DEBUG 1
#ifdef DRIVER_MALLOC_DEBUG 
extern SEXP Malloc_print();
#define MALLOC_PRINT   Malloc_print()
void *__MALLOC_DEBUG_MARK__(size_t s)
{
	return malloc(s);
}
#define MALLOC_MARK(s) __MALLOC_DEBUG_MARK__(s)
#else
#define MALLOC_PRINT
#define MALLOC_MARK(s) 
#endif

extern SEXP R_FalseValue;

extern char *cmd;
extern int Config_getPort(const char *name);
extern ssize_t Socket_send(int socket, const void *buffer, size_t length, int flags);

#define SOCKET_SEND_DEBUG 1
#ifdef  SOCKET_SEND_DEBUG
ssize_t __Socket_send(int socket, const void *buffer, size_t length, int flags,
		const char *file, int line)
{
  fprintf(stderr, "[%s, %ld] %s:%d\n", __func__, syscall(SYS_gettid), file, line);
  return Socket_send(socket, buffer, length, flags);
}
#define Socket_send(s, b, n, f) __Socket_send((s), (b), (n), (f), __FILE__, __LINE__) 
#endif

extern const char *info_addr;
static const char *notify_addr = NULL; // to do
extern supr_socket_conn_t *info_sc; // = NULL;
extern pthread_mutex_t Supr_syncMutex;
extern pthread_cond_t  Supr_syncCond;
extern void *Supr_syncObject;
static char msg[1024];

extern char *X11_str;

extern void (*__start_master_fun__)(void *);
extern void (*__start_dfsname_fun__)(void *);
void main_thread_start_master(void *);
void main_thread_start_dfsname(void *);

static const char *master_addr = NULL;
static const char *dfs_addr = NULL;
extern SEXP SuprEnv;
extern SEXP SuprJobEnv;

typedef struct main_thread_task_struct {
  void (*fun)(void *);
  void *data;
} main_thread_task_t;

vector_t *main_thread_tasks = NULL;


extern char *Supr_sysHome;
extern char *Supr_usrHome;
extern char *Supr_dfsHome;
extern char *Supr_message;

/*
static pthread_mutex_t *debug_mutex = NULL;

int __pthread_mutex_lock__(const char *file, int line, pthread_mutex_t *mutex)
{
  if(mutex == debug_mutex) basic_info("%s:%d", file, line);
  return pthread_mutex_lock(mutex);
}
int __pthread_mutex_unlock__(const char *file, int line, pthread_mutex_t *mutex)
{
  if(mutex == debug_mutex) basic_info("%s:%d", file, line);
  return pthread_mutex_unlock(mutex);
}
#define pthread_mutex_lock(m) __pthread_mutex_lock__(__FILE__, __LINE__, (m))
#define pthread_mutex_unlock(m) __pthread_mutex_unlock__(__FILE__, __LINE__, (m))
*/

void *JOB_CANCELLED = NULL;

pthread_mutex_t *notify_mutex = NULL;
pthread_cond_t *notify_cond = NULL;

int worker_count = 0;
pthread_mutex_t *worker_count_mutex = NULL;
pthread_cond_t  *worker_count_cond = NULL;
shm_io_info_t *user_io = NULL; // shared in initialization

struct sigaction R_oldPipeAct; // FIXME

static supr_socket_conn_t *master_conn = NULL;
static supr_socket_conn_t *scToBackend = NULL;
static supr_socket_conn_t *usrInfoConn = NULL;
static supr_thread_t *backendThread = NULL;

extern vector_t *threads;
extern char *Cluster_netstat_C(int port, char *args);

extern char *Exec_timestamp(char *buf, size_t buf_size);

extern void supr_info(const char *format, ...);
extern int  Supr_verbose;
extern int  Supr_debug;

const char *src_func;
const char *src_file;
int src_line;
void __src_info(const char *func, const char *file, int line)
{
  src_func = func;
  src_file = file;
  src_line = line;
}

#define USE_CHECKSUM
#ifdef  USE_CHECKSUM
#define MSG_HEADER_SIZE 2*INT_SIZE
int (*cfncn)(char *, int, uint32_t *, off_t *) = Supr_crc32; // FIXME
//extern int (*cfncn)(char *, int, uint32_t *, off_t *); // = Supr_crc32; // FIXME
#else
#define MSG_HEADER_SIZE 0
#endif

static int rjni_strcmp(const void *a, const void *b)
{
  return strcmp(*((char **) a), *((char **) b));
}


void driver_info(const char *format, ...)
{
	/*
   if(!scToBackend) {
	fprintf(stderr, "master_conn: %p, scToBackend: %p\n", master_conn, scToBackend);
//    if(Supr_verbose == FALSE) return;

//    fflush(stdout);
//	return;
  }
   */


  supr_thread_t *cth = currentThread();
  if(FALSE && cth && master_conn && scToBackend ) { // lock ...
    if(cth != backendThread) {
      pthread_mutex_lock(scToBackend->mutex);
        int cmd = CLUSTER_DRIVER_NULL;
        write(scToBackend->fd, &cmd, INT_SIZE);
        read(scToBackend->fd, &cmd, INT_SIZE);
    }

    pthread_mutex_lock(master_conn->mutex);

#ifdef USE_CHECKSUM
      size_t buf_size = 1024;
      char buf[buf_size];
      char *s = buf + MSG_HEADER_SIZE;
      va_list ap;
      va_start(ap, format);
      sprintf(s, "%s (%s:%d) ", src_func, src_file, src_line);
      int len = vsnprintf(s + strlen(s),
		      buf_size - MSG_HEADER_SIZE - strlen(s) - 1,
		      format, ap);
      len = strlen(s);
      s[len++] = 0;

      int master_fd = master_conn->fd;

    //{ fprintf(stderr, "%s", buf); continue; }
    //{
      uint32_t cksum_val;
      off_t    cksum_len;
      buf_size = MSG_HEADER_SIZE + len;
      int type = 2;
      int pid =  0;
      int hdr[] = {pid, type}; // fixme?
      memcpy(buf, hdr, sizeof(hdr));
      cfncn(buf, buf_size, &cksum_val, &cksum_len);

      int cmd = CLUSTER_BYTE_MSG;
      write(master_fd, &cmd, INT_SIZE);
      //fprintf(stderr, "\033[0;31m***** buf_size: %ld, s: %s\n", buf_size, s);
      write(master_fd, &buf_size, SIZE_SIZE);
      write(master_fd, buf, buf_size);
      //fprintf(stderr, "***** cksum_val: %d\033[0m\n", cksum_val);
      write(master_fd, &cksum_val, sizeof(uint32_t));
      /*
      write(master_fd, arg_2, strlen(arg_2));
      write(master_fd, (char*) block, blksize);
      write(master_fd, (char*) &cksum_val, sizeof(uint32_t));
      */
    //}
      /*
      uint32_t m_cksum_val;
      read(master_fd, &m_cksum_val, sizeof(uint32_t));
      if(m_cksum_val != cksum_val){
              fprintf(stderr, "Error: cksum_val: %d, m_cksum_val: %d\n",
                              cksum_val, m_cksum_val);
      }
      */


#else

      size_t buf_size = 1024;
      char buf[buf_size];
      va_list ap;
      va_start(ap, format);
      sprintf(buf, "%s (%s:%d) ", src_func, src_file, src_line);
      int n = vsnprintf(buf + strlen(buf), buf_size-strlen(buf)-1, format, ap);

      int fd = master_conn->fd;
      int byte_msg = CLUSTER_BYTE_MSG;
      write(fd, &byte_msg, INT_SIZE);
      pid_t pid = 0;
      write(fd, &pid, INT_SIZE);
      int type = 1;
      write(fd, &type, INT_SIZE);
      n = strlen(buf);
      buf[n++] = 0;
      write(fd, &n, INT_SIZE);
      write(fd, &buf, n);
#endif

    pthread_mutex_unlock(master_conn->mutex);

    if(cth != backendThread) {
        int cmd = CLUSTER_DRIVER_NULL;
        write(scToBackend->fd, &cmd, INT_SIZE);
      pthread_mutex_unlock(scToBackend->mutex);
    }
    //pthread_mutex_unlock(master_conn->mutex);

  } else {

    if(Supr_verbose == FALSE)
	    return;

    /*
  src_func = func;
  src_file = file;
  src_line = line;
  */

    va_list ap;
    supr_thread_t *cth = currentThread();
    // if(cth) printf("[INFO %d %d]", cth->pid, cth->tid);

    fprintf(stdout, "[%s %s:%d] ", src_func, src_file, src_line);

    va_start(ap, format);
    vfprintf(stdout, format, ap);

    fflush(stdout);
  }
  
}

#define printf __src_info(__func__, __FILE__, __LINE__); driver_info

//void __PrintValue(SEXP s){ PrintValue(s); }

// Maximum number of clients reached
// lsof -U
// kill -9 a dbus-daem ...

#undef PrintValue
#define PrintValue fprintf(stderr, "(%s:%s:%d) ",__func__, __FILE__, __LINE__); Rf_PrintValue


char **cmd_argv = NULL;
int cmd_argc = 0;

//extern
void *PTHREAD_INTERRUPTED = NULL;
void *PTHREAD_NOTIFIED = NULL;

pthread_mutex_t *interrupt_mutex  = NULL;
pthread_cond_t  *interrupt_cond   = NULL;
supr_thread_t   *interrupt_thread = NULL;


extern supr_socket_conn_t *DFS_namenode;
extern void Thread_dumper();
extern supr_thread_t *main_thread;

extern int SuprErr_set(const char *format, ...);
extern void *SuprErr_get();

extern void SocketConn_closeAll(vector_t *conns, int do_shutdown);

extern char *connTypeToStr(int type);

supr_thread_t *startMMapUI(const char *file_name);

extern supr_xterm_t *supr_xterm3(const char *window_name, char **argv,
                int window);

const char *cmd2char(int cmd);


int  Driver_startedMaster = FALSE;
//create a thread as a dcl_event_handler;
supr_thread_t *DCL_eventHandler = NULL;
supr_thread_t *startDCLEventHandler();
vector_t *DCL_connections = NULL;
vector_t *DC_events = NULL;

extern char *localhost;

typedef struct {
  class_t *class;
  int ref_count;
  //int padding;
  int count;
  char *name;
  vector_t *conns;
  vector_t *value;
} cond_t;

void Cond_finalize(class_t *class, void *object)
{
  cond_t *c = (cond_t *) object;
  free(c->name);
  c->conns->class->finalize(c->conns->class, c->conns);
  c->value->class->finalize(c->value->class, c->value);
  free(c);
}

const char *Cond_toString(class_t *class, void *object)
{
  return "Condition object"; // TODO
}

class_t __condition_class = {"Condition", Cond_toString, Cond_finalize};
class_t *Cond_class = &__condition_class;

cond_t *Cond_new(const char *name, int count) // countdown
{
  cond_t *c = (cond_t *) malloc(sizeof(cond_t));
  c->class = Cond_class;
  c->ref_count = REF_COUNT_INITIALIZER;
  c->name = strdup(name);
  c->conns = newVector(FALSE);
  c->value = newVector(FALSE);
  c->count = count;
  return c;
}

so_t *Cond_toSO(cond_t *c)
{
  // Supr_incref(c);
  int n = vectorSize(c->value);
  size_t size = (n+1)*sizeof(size_t);
  so_t *array[n];
  for(int i=0; i < n; i++){
    void *ptr = vectorElementAt(c->value, i);
    int *args = (int*) ptr;
    so_t *so = (so_t*) (ptr + 4*INT_SIZE + args[3]);
    array[i] = so;
    size += sizeof(so_t) + so->size;
//    printf("sizeof(so_t) + size: %ld\n", sizeof(so_t) + size);
  }

  //{so_t, n, n_offsets_so, ...}
  void *ptr = malloc(sizeof(so_t) + size);
  so_t *s = (so_t*) ptr;
  s->ref_count  = REF_COUNT_INITIALIZER; //1;
  s->mem_type  =  0;
  s->sys_type  =  0;
  s->obj_type = SUPR_SO_ARRAY;
  s->size  = size;

  size_t *offset = (size_t*) s->val;
  offset[0] = n;
  offset ++;

  size = sizeof(so_t) + (n+1)*sizeof(size_t);
  for(int i=0; i < n; i++){
    so_t *so = array[i];
//    printf("size: %ld, size + sizeof(so_t) + so->size: %ld\n", size, size + sizeof(so_t) + so->size);

    memcpy(ptr+size, so, sizeof(so_t) + so->size);
    offset[i] = size;
    size += sizeof(so_t) + so->size;
  }

  /*
  BEGIN_R_EVAL();
    SEXP x = SO_toRObject(s, sizeof(s) + s->size); 
    PrintValue(x);
  END_R_EVAL();
  */

  return s;
}


void Driver_shutdown(void *data)
{
  Thread_dumper();
  supr_thread_t *cth = currentThread();
  if(cth == main_thread){
    for(int i=vectorSize(threads)-1; i>=0; i--){
      supr_thread_t *th = (supr_thread_t *)vectorElementAt(threads,i);
      if(th==cth) continue;
      int rc = pthread_cancel(th->ptid);
      if(rc == 0){
	void *retval;
        rc = pthread_join(th->ptid, &retval);
	char buf[256];
	sprintf(buf, "%p", retval);
        fprintf(stdout, "pthread_cancel: %s, %s\n", th->name,
	       	retval == PTHREAD_CANCELED ?  "PTHREAD_CANCELED" : buf);

      } else {
        printf("Error: pthread_cancel, %s", strerror(errno));
      }
    }
    exit(0);
    // CleanUps???
  } else {
    main_thread->data = data;
    pthread_kill(main_thread->ptid, SIGINT);
  }
}


/*
void UserInfo_send(int type, int level, const char *msg)
{
  //message:
  fprintf(stderr, "[%s] tid: %ld\n", __func__,syscall(SYS_gettid));

  int fd = usrInfoConn? usrInfoConn->fd : STDOUT_FILENO;

  write(fd, &type, INT_SIZE);
  write(fd, &level, INT_SIZE);
  size_t len = strlen(msg) + 1;
  write(fd, &len, SIZE_SIZE);
  write(fd, msg, len);

  int rc;
  read(fd, &rc, INT_SIZE);
  fprintf(stderr, "[%s] tid: %ld, rc: %d\n", __func__,syscall(SYS_gettid), rc);
}
*/

typedef struct userinfo_struct {
  int type;
  int level;
  char *msg;
} userinfo_t;

void infosender_run(vector_t *messages)
{
  supr_thread_t *cth = (supr_thread_t *) pthread_getspecific(currentThreadKey);
  while(TRUE){

    
    for(;;){
      userinfo_t *info = NULL;
      pthread_mutex_lock(messages->mutex);
        if(vectorSize(messages)>0)
		info = vectorRemove(messages,0);
	else {
          pthread_cond_wait(&cth->cond, messages->mutex); // ??
	}
      pthread_mutex_unlock(messages->mutex);
      if(info){
  	//message:
  	//fprintf(stderr, "[%s] tid: %ld\n", __func__,syscall(SYS_gettid));

  	int fd = usrInfoConn? usrInfoConn->fd : STDOUT_FILENO;

  	write(fd, &info->type, INT_SIZE);
  	write(fd, &info->level, INT_SIZE);
  	size_t len = strlen(info->msg) + 1;
  	write(fd, &len, SIZE_SIZE);
  	write(fd, info->msg, len);

	free(info);

  	int rc;
  	read(fd, &rc, INT_SIZE);
  	fprintf(stderr, "[%s] tid: %ld, rc: %d\n", __func__,syscall(SYS_gettid), rc);
      } else {
        break;
      }
    }

    /*
    pthread_mutex_lock(&cth->mutex);
      pthread_cond_wait(&cth->cond, &cth->mutex);
    pthread_mutex_unlock(&cth->mutex);
    */
  } 
}

void *infosender_init(void *arg)
{
  vector_t *messages = (vector_t *) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
                  (unsigned long) &messages);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
//    pthread_mutex_lock(messages->mutex); //
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  infosender_run(messages);

  pthread_exit(th);
  return NULL;
}

userinfo_t *newUserInfo(int type, int level, const char *msg)
{
  userinfo_t *info = malloc(sizeof(userinfo_t));
  info->type =  type;
  info->level= level;
  info->msg  = strdup(msg);
  return info;
}


void UserInfo_send(int type, int level, const char *msg)
{
  static supr_thread_t *sender = NULL;
  static vector_t *messages = NULL; // the message queue
  if(!sender) {
    pthread_t thread;
    messages = newVector(TRUE);
    sem_t sem;
    sem_init(&sem, 1, 0);
    void *arg[] = {messages, &sem, &sender};
    int rc = pthread_create(&thread, NULL, infosender_init, arg);

    sem_wait(&sem);
    sem_destroy(&sem);

    pthread_mutex_lock(&sender->mutex);
      free(sender->name);
      sender->name = strdup("infosender*");
      vectorAdd(threads, sender);
      pthread_cond_signal(&sender->cond);
    pthread_mutex_unlock(&sender->mutex);
  }

  pthread_mutex_lock(messages->mutex);
    vectorAdd(messages, newUserInfo(type, level, msg));
    pthread_cond_signal(&sender->cond); //
  pthread_mutex_unlock(messages->mutex);

  /*
  pthread_mutex_lock(&sender->mutex);
    pthread_cond_signal(&sender->cond);
  pthread_mutex_unlock(&sender->mutex);
  */
}


//FILE warning_file = stderr;
//int warning_fd = 2;

/*
int Driver_showMessage(const char *format, ...)
{

  if(usrInfoConn){
    int fd = usrInfoConn->fd;
    int type = 0, level = 0;
    write(fd, &type, INT_SIZE);
    write(fd, &level, INT_SIZE);
  } else {

    int fd = STDOUT_FILENO;
    va_list ap;
    va_start(ap, format);
    int size = vdprintf(fd, format, ap);
    return size;
  }
}
*/

int driver_warning(const char *format, ...)
{
	/*
  int warning_fd = usrInfoConn? usrInfoConn->fd : STDOUT_FILENO;
  if(usrInfoConn){
    int type = 0, level = 0;
    write(warning_fd, &type, INT_SIZE);
    write(warning_fd, &level, INT_SIZE);
  }
  */
  int warning_fd = STDOUT_FILENO;

  dprintf(warning_fd, "\033[0;33m[Warning]");
  va_list ap;
  va_start(ap, format);
  int size = vdprintf(warning_fd, format, ap);
  dprintf(warning_fd, "\033[0m");
  return size;
}

hashtable_t *globalEnvironment = NULL;

typedef struct cbk_struct {
  //pthread_cond_t cond;
  hashtable_t *shm_names;
  hashtable_t *key_values;
  //char **keys;
  //int nkeys;
  supr_socket_conn_t **sc;
  int count;
  int nsc;
} cbk_t;

void cbk_finalize(cbk_t *cbk)
{
  fprintf(stderr, "\n[%s] cbk->shm_names: %p\n", __func__, cbk->shm_names);
  if(cbk->shm_names) {
    fprintf(stderr, "[%s] cbk->shm_names->ref_count: %d\n", __func__,
		  cbk->shm_names->ref_count);
    fprintf(stderr, "[%s] cbk->shm_names->free_data: %p\n", __func__,
		  cbk->shm_names->free_data);
    Supr_decref(cbk->shm_names);
  }

  fprintf(stderr, "[%s] cbk->key_values: %p\n", __func__, cbk->key_values);

  if(cbk->key_values) {
    fprintf(stderr, "[%s] cbk->key_values->ref_count: %d\n", __func__,
		  cbk->key_values->ref_count);
    fprintf(stderr, "[%s] cbk->key_values->free_data: %p\n", __func__,
		  cbk->key_values->free_data);
    if(!cbk->key_values->free_data)
	   cbk->key_values->free_data =  __free_func__;
    Supr_decref(cbk->key_values);
  }
  free(cbk->sc); // FIXME?
  free(cbk);
}

/*
void cbkDestroy(cbk_t *cbk)
{
  if(cbk->shm_names) hashtableDestroy(cbk->shm_names);
  if(cbk->key_values) hashtableDestroy(cbk->key_values);
  if(cbk->sc) free(cbk->sc);
  free(cbk);
}
*/

typedef struct future_struct {
} future_t;

typedef struct dcl_struct {
  char *name;
  int  sync;
  int  padding;
  pthread_mutex_t *mutex;
  pthread_cond_t *cond;
  supr_socket_conn_t *sc;
  struct dcl_struct *next; // for extensions?
} dcl_t;

void dcl_finalize(dcl_t *dcl)
{
  free(dcl->name);
  if(dcl->sync){
	  pthread_mutex_destroy(dcl->mutex);
	  free(dcl->mutex);
	  pthread_cond_destroy(dcl->cond);
	  free(dcl->cond);
  }
  free(dcl);
}

typedef struct job_struct {
  class_t *class;
  int ref_count;
  int padding; // reserved ?


  int id;
  int count;  // or for padding
  void *expr; // (serialized R expression for taskrunners
  SEXP env;   // for driver and workers?

  iterator_t *tasks; // implemented as subsets
  //SEXP result;
  vector_t *result;
  //future_t *future;

  vector_t *taskrunners;
  vector_t *executors; // or workers, identified by socket address
  // data change listeners ...
  // vector_t assigned tasks
  pthread_mutex_t mutex;
  pthread_cond_t  cond;

  char *combine_result;
  int   combine_count;
  int   state; 

  cbk_t * cbk;
  hashtable_t *environment;

  void *attachment; // used by the UI thread ... fixme?
  dcl_t *dcl;
} job_t;

#define JOB_STATE_SUBMITTED 0
#define JOB_STATE_TASKS_ASSIGNED 1
#define JOB_STATE_CANCELLED 2
#define JOB_STATE_FINISHED 3

static class_t *DriverJob_class =  NULL;

void cancelJob_cleanup_monitors(job_t *job);

#ifdef SUPR_MALLOC 
void result_free_data(void *p){
	__supr_free__(p, __func__, __FILE__, __LINE__);
}
#else
#define  result_free_data free
#endif

//typedef struct so_reference_struct {
//} so_ref_t;

void jobEnvironment_free_data(void *data) // so_t objects ...
{
  so_t *so = (so_t*) data;
  fprintf(stderr, "[%s] so->obj_type: %d\n", __func__, so->obj_type);
  if(so->obj_type == SUPR_REFERENCE){
    object_t *obj = (object_t *)((void **) (so + 1))[0];
    //object_t *obj = (object_t *) so->val;
    fprintf(stderr, "[%s] obj: %p, referrenced object class: %s\n", __func__,
		    obj, obj->class->name);
    Supr_decref(obj);
    *((void **) (so + 1)) = NULL;
  }

  __free_func__(data);

}

void driverJobFinalize(class_t *class, void *object)
{
  job_t *job = (job_t *) object;

  fprintf(stderr, "\033[0;33m");
  fprintf(stderr, "[%s] TODO (sync etc ...)\n", __func__);

  while(job->dcl) {
    dcl_t *dcl = job->dcl;
    job->dcl = dcl->next;
    dcl_finalize(dcl);
  }

  if(job->cbk)
	  cbk_finalize(job->cbk);

  //Supr_decref(job->dcl);
  //Supr_decref(job->attachment); // ???
  fprintf(stderr, "[%s] Supr_decref(job->environment)\n", __func__);
  fprintf(stderr, "[%s] job->environment->ref_count: %d\n", __func__,
		  ((object_t*)job->environment)->ref_count);
  fprintf(stderr, "[%s] job->environment->free_data: %p\n", __func__,
		  job->environment->free_data);
  if(!job->environment->free_data){ // FIXME?? job->dcl ... See PUT_PAR
	  //job->environment->free_data = __free_func__;
	  job->environment->free_data = jobEnvironment_free_data;
  }
  
  Supr_decref(job->environment); // free_data??


  //free(job->combine_result);

  fprintf(stderr, "[%s] pthread_cond_destroy(&job->cond)\n", __func__);
  pthread_cond_destroy(&job->cond);
  fprintf(stderr, "[%s] pthread_mutex_destroy(&job->mutex)\n", __func__);
  pthread_mutex_destroy(&job->mutex);
  fprintf(stderr, "[%s] Supr_decref(job->executors)\n", __func__);
  Supr_decref(job->executors);
  fprintf(stderr, "[%s] Supr_decref(job->taskrunners)\n", __func__);
  Supr_decref(job->taskrunners);

  if(job->result && job->result != JOB_CANCELLED){
    ((vector_t *)job->result)->free_data = result_free_data;
    class_t *class = getClass(job->result);
    fprintf(stderr, "[%s] classNameOf(job->result): %s\n", __func__,
		    class ? class->name : NULL);
    fprintf(stderr, "[%s] Supr_decref(job->result)\n", __func__);
    fflush(stderr);
    Supr_decref(job->result);
  }

  fprintf(stderr, "[%s] Supr_decref(job->tasks), ref_count: %d\n", __func__,
		  job->tasks->ref_count);
  Supr_decref(job->tasks);
  fprintf(stderr, "[%s] free(job->expr)\n", __func__);
  free(job->expr);
  fprintf(stderr, "[%s] free(job)\n", __func__);
  free(job);
  fprintf(stderr, "\033[0m");
  fflush(stderr);
}

const char *driverJobToString(class_t *class, void *object)
{
  return "driverJobObject: TODO";
}

void class_init()
{
  DriverJob_class = newClass("DriverJob", driverJobToString, driverJobFinalize);
}

//extern vector_t *jobs;
static vector_t *jobs = NULL;
extern SEXP (*__cluster_jobs_ptr__)();
extern SEXP (*__cluster_job_ptr__)(SEXP);

//job_t *__job__ = NULL; // last accessed job
//int __job_id__ = -1;

#define JOB_INCREF(job) do {	\
  pthread_mutex_lock(jobs->mutex);	\
	Supr_incref(job);	\
	basic_info("job->ref_count: %d", job->ref_count);	\
  pthread_mutex_unlock(jobs->mutex);	\
} while(0)

//	basic_info("job->ref_count: %d", job->ref_count);

#define JOB_DECREF(job) do {	\
  pthread_mutex_lock(jobs->mutex);	\
	Supr_decref(job);	\
  pthread_mutex_unlock(jobs->mutex);	\
} while(0)

job_t *findJob(int job_id){

  job_t *job = NULL;

  pthread_mutex_lock(jobs->mutex);
    for(int i=vectorSize(jobs)-1; i>=0; i--){
      job_t *j = (job_t *) vectorElementAt(jobs, i);
      if(j->id == job_id) {
        job = j;
        Supr_incref(job);
        break;
      }
    }
  pthread_mutex_unlock(jobs->mutex);

  return job;
}

//  static int job_id = 1;
//int job_id = 1;

job_t *newJob(void *expr, iterator_t *tasks){
  
//  if(!DriverJob_class){ class_init(); }
  static int job_id = 1;

  job_t *job = (job_t *)malloc(sizeof(job_t));

  job->class = DriverJob_class;
  job->ref_count = REF_COUNT_INITIALIZER;
  job->padding = 0;

  job->state = JOB_STATE_SUBMITTED;

//  job->id    = job_id++;
  job->count = 0;
  job->expr  = expr;
  job->env   = R_NilValue;
  job->tasks = tasks;
  job->result= NULL; 
  job->taskrunners = newVector(FALSE);
  job->executors   = newVector(FALSE);

  pthread_mutex_init(&job->mutex, NULL);
  pthread_cond_init(&job->cond, NULL);

  job->combine_result = NULL;
  job->combine_count  = 0;
  job->cbk = NULL;

  job->environment = newHashtable(FALSE);
  job->attachment  = NULL;
  job->dcl         = NULL;

  pthread_mutex_lock(jobs->mutex);
    job->id = job_id++;
    vectorAdd(jobs, job);
  pthread_mutex_unlock(jobs->mutex);

  //__job__ = job;
  //__job_id__ = job->id;

  return job;
}

//#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)
void removeDriverJob(job_t *job){

    if(!job) return;

    pthread_mutex_lock(jobs->mutex);
      for(int i = vectorSize(jobs) - 1; i >= 0; i--){
        job_t *j = vectorElementAt(jobs, i);
	if(j == job){
          vectorRemove(jobs, i);
	  break;
	}
      }
    pthread_mutex_unlock(jobs->mutex);

    /*
    pthread_mutex_lock(&job->mutex);
      Supr_decref(job);
    pthread_mutex_unlock(&job->mutex);
    */
    JOB_DECREF(job);
}

typedef struct dc_event_struct {
  job_t *job;
  char *name;
  so_t *value;
} dc_event_t;

// free name...
dc_event_t *newDCEvent(job_t *job, const char *name, so_t *value)
{
  dc_event_t *e = (dc_event_t *) malloc(sizeof(dc_event_t));
  //{ FIX ME?
  //pthread_mutex_lock(&job->mutex); // use ref_mutex ...
  	Supr_incref(job);
  //pthread_mutex_unlock(&job->mutex);
  //}
  e->job   = job;
  e->name  = strdup(name);
  //{ FIX ME?
  	SO_incref(value);
  //}
  e->value = value;
  /*
  if(value){
  fprintf(stderr, "[%s] e-value->ref_count: %d\n",__func__, e->value->ref_count);
MALLOC_MARK(e->value->ref_count);
  }
  */
  return e;
}


void addDCLEvent(job_t *job, const char *name, so_t *value)
{
   if( !job->dcl|| !DC_events ) return;

	static int count = 0;
	if(job->dcl->sync) {
	  fprintf(stderr, "%d. [%s] job->dcl->sync: %d, LOCK\n",
			 count++, __func__, job->dcl->sync);
	  pthread_mutex_lock(job->dcl->mutex);
	}


//	   if(DC_events && job->dcl) {
             dc_event_t *e = newDCEvent(job, name, value);

	     fprintf(stderr, "[%s] e->name: %s, job->ref_count: %d\n",
			     __func__, e->name, job->ref_count);

	     pthread_mutex_lock(DC_events->mutex);
	       vectorAdd(DC_events, e);
	     pthread_mutex_unlock(DC_events->mutex);

	     pthread_mutex_lock(&DCL_eventHandler->mutex);
	       pthread_cond_signal(&DCL_eventHandler->cond);
	     pthread_mutex_unlock(&DCL_eventHandler->mutex);

	     //fprintf(stderr, "[%s] e->name: %s, job->ref_count: %d\n", __func__, e->name, job->ref_count);
//	   }


	if(job->dcl->sync) {
	  fprintf(stderr, "[%s] job->dcl->sync: %d, WAIT\n", __func__, job->dcl->sync);
	  pthread_cond_wait(job->dcl->cond, job->dcl->mutex);
	  fprintf(stderr, "[%s] job->dcl->sync: %d, UNLOCK\n", __func__, job->dcl->sync);
	  pthread_mutex_unlock(job->dcl->mutex);

	  // free e:
	  //{
	    Supr_decref(e->job);
	    SO_decref(e->value);
	    free(e->name);
	    free(e);
	  //}

	}
}

supr_socket_conn_t *driverServerConn = NULL;

extern supr_thread_t *main_thread;

extern char *SUPR_HOMEUSR;
extern char *SUPR_HOMESYS;
extern void suprHomeInit();

extern void c_backtrace();

struct sigaction R_oldSegvAct;
struct sigaction R_oldIntAct;

// cp: void  Driver_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
void  Driver_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  sleep(180);
  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
        info_sc->mutex = malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(info_sc->mutex, NULL);
    sprintf(msg, "\033[0;31m\n[%s] %s pid=%d, tid=%ld\033[0m\n", proc_cmd,
                    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);

	/*
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));
  c_backtrace();
  printf("\n\033[0;31m");
  switch(ip->si_code){
    case SEGV_MAPERR:
         fprintf(stderr, "Address not mapped.\n");
         break;
    case SEGV_ACCERR:
         fprintf(stderr, "Access to this address is not allowed.\n");
         break;
    default:
         fprintf(stderr, "Unknown reason.\n");
         break;
  }
  printf("\n\033[0m\nR_oldSegvAct.sa_sigaction:\n");

  sleep(120);

  R_oldSegvAct.sa_sigaction(sig, ip, context);
  */
  //exit(1);
}

void  Driver_SigactionAbort(int sig, siginfo_t *ip, void *context)
{
  char msg[256];
  sprintf(msg, "\033[0;31mpid: %d, tid: %ld, ... sleep(180) ...\033[0m\n",
                  getpid(), syscall(SYS_gettid));
  basic_info(msg);
  sleep(180);
}

extern SEXP R_simpleTryEval(SEXP expr, SEXP env, int *errorOccurred);
extern SEXP R_simpleTryEval4(SEXP(*func)(SEXP args), SEXP args, SEXP env,
	       	int *errorOccurred);

/*
#define BEGIN_R_EVAL()     do      {       \
  pthread_mutex_lock(&main_thread->mutex);	\
  void *dummy; 	\
  int __save_R_CStackStart__ = R_CStackStart;	\
  R_CStackStart = (unsigned long) &dummy

#define END_R_EVAL()   \
  R_CStackStart = __save_R_CStackStart__;	\
  pthread_mutex_unlock(&main_thread->mutex);	\
} while(0)
*/


/*
char *dupstr(const char *str)
{
  return memcpy(malloc(strlen(str)+1), str, strlen(str)+1);
}
*/

//extern SEXP R_CStackStart;
extern unsigned long R_CStackStart;
extern unsigned long R_CStackLimit;
extern int R_Interactive;
extern void run_Rmainloop(void);

extern void myR_SigactionSegv(int sig, siginfo_t *ip, void *context);



static shm_io_info_t *__io__ = NULL;

extern vector_t *cleanups;
int system_exit(int n);


int isDCLInterrupted = FALSE;
int isDisconnected = FALSE;

size_t __dcl_read__(int fd, void *ptr, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /* else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(listenfd, &readfds) = %d\n", __func__,
               FD_ISSET(fd, &readfds));
      } */
    }

    int n = read(fd, ptr + len,  size - len);
    //printf("[%s] isDCLInterrupted = %d n = %d\n", __func__, isDCLInterrupted, n);
    if(isDCLInterrupted) {
//      isDCLInterrupted = FALSE;
    //  return -1;
	    // clean...???
      errorcall(R_NilValue, "interrupted");
    } else if(n == -1) {
      errorcall(R_NilValue, "SIGPIPE?");
    } else if(n == 0) {
      printf("[%s] disconnected\n", __func__);
      isDisconnected = TRUE;
      errorcall(R_NilValue, "disconnected");
    }
    //if(n == -1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  return len;
}

// testing
//extern size_t (*__read__)(int, void *, size_t);


#include <readline/readline.h>
#include <readline/history.h>

 
void  myR_SigactionDCLInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  //c_backtrace();

  //if(isDCLInterrupted) exit(1);
  fprintf(stderr, "\033[0;31m[%s] FIXME: EXIT (%s, %d)\033[0m\n", __func__,
           __FILE__, __LINE__);
//  exit(1);

//  char *line = readline (">>> ");
//  printf("%s\n", line);
//  int c;
//  read(3, &c, 1);


  isDCLInterrupted = TRUE;

  if(FALSE && __io__){
    int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
    shm_io_write(__io__, __io__->out, array, sizeof(array));
  }
//  errorcall(R_NilValue, "segmentation fault"); //??? FIXME
//  exit(1); // not good...

  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);

}

char interrupt_message_buf[256];

/*
int isTaskrunnerInterrupted = FALSE;

extern int isInterrupted;


void  myR_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
  //c_backtrace();

  isTaskrunnerInterrupted = TRUE;
  isInterrupted = TRUE;


  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);
  //sigaction(SIGINT, &R_oldactInt, NULL);

  //errorcall(R_NilValue, msg); //??? FIXME
  //exit(1);
}
*/

/*
typedef struct tr_cntxt_struct {
  shm_io_info_t *io;
  int job_id;
  int tr_id;
  pid_t pid;
} tr_cntxt_t;

tr_cntxt_t tr_cntxt = {NULL, -1, -1, 0};
*/
extern tr_cntxt_t tr_cntxt;

char *cntxt2str(){
  char *s = malloc(256);
  sprintf(s, "\033[0;32mpid=%d, job_id=%d, tr_id=%d, %s\033[0m",
		  tr_cntxt.pid,  tr_cntxt.job_id,
		  tr_cntxt.tr_id, tr_cntxt.io->shm_info.shm_name);
  return s;
}

void  (*myTryEval_SigactionInt)(int sig, siginfo_t *ip, void *context) =NULL;

extern void sendDriverMessage(shm_io_info_t *io, int job_id, int tr_id, const char *msg);
extern void rjni_io_err_write(shm_io_info_t *io, const char *msg);

#define  BACKTRACE_SIZE 256
#include <execinfo.h>

char *myC_backtrace()
{
  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  size = backtrace(array, BACKTRACE_SIZE);
  strings = backtrace_symbols(array, size);

  int length = 0;
  for (i = 0; i < size; i++) //fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    length += strlen(strings[i]) + 1;
  
  char *str = (char*)malloc(length);
  char *s = str;
  for (i = 0; i < size; i++){
    memcpy(s, strings[i], strlen(strings[i]));
    s += strlen(strings[i]);
    *s = i== (size-1) ? 0 : '\n';
    s++;
  }

  free(strings);
  
  return str;
}

extern void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write);

char *myR_simpleTraceback();
//extern int isInterrupted;


/*
void  myR_SigactionTaskRunnerUsr2(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n",
		  __func__, pthread_self());
  //c_backtrace();

  isInterrupted = TRUE;

  int rc = sem_trywait(&__io__->err->sem_wr);
  fprintf(stderr, "\033[0;31m[%s] sem_trywait : %d\033[0m\n", __func__, rc);
  char *msg = "interrupted";
  if(rc == 0){
    msg = (char*) (__io__->err+1);
    msg[__io__->err->data_size-1] = 0;
    fprintf(stderr, "\033[0;31m[%s] message = %s\033[0m\n", __func__, msg);
    __io__->err->data_size = 0;
    sem_post(&__io__->err->sem_wr);
  }
  if(strlen(msg)==0) msg = "interrupted";
  int size = strlen(msg);
  if(sizeof(interrupt_message_buf)-1 < size)
	  size = sizeof(interrupt_message_buf)-1;
  memcpy(interrupt_message_buf, msg, size);
  interrupt_message_buf[size] = 0;

  
  kill(getpid(), SIGINT);

}
*/


/*
void  myTryEval_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n",
		  __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  c_backtrace();

  int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
  shm_io_write(__io__, __io__->out, array, sizeof(array));

  exit(1);
}
*/





/*
typedef struct shm_struct {
  size_t size;
  sem_t sem_w; // by java thread
  sem_t sem_r; // by java thread
} shm_struct_t;

typedef struct _shm_info {
  char *shm_name;
  void *mem_ptr;
} shm_info_t;
*/

//JNIEXPORT jlong JNICALL Java_RJNI_shmOpen (JNIEnv *javaEnv, jobject thisObj, jstring jshm_name)

/*
shm_info_t *shmOpen(const char *cshm_name) {
//  const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv, jshm_name, NULL);
  printf("[%s] cshm_name: %s\n", __func__, cshm_name);
  shm_info_t *shm_ptr = malloc(sizeof(shm_struct_t));

  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  size_t segment_size = sysconf(_SC_PAGE_SIZE);

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  close(fd);
  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);
//  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);

  shm_ptr->mem_ptr = mem_ptr;

  shm_struct_t * ssp = (shm_struct_t *)mem_ptr;
  ssp->size = segment_size;
  //sem_init(&ssp->sem_w, 1, 0);
  //sem_init(&ssp->sem_r, 1, 0);
  //sem_wait(&ssp->sem_w); sem_wait(&ssp->sem_r);
  int val;
  sem_getvalue(&ssp->sem_w, &val);
  printf("[%s] sem_getvalue(&ssp->sem_w, &val): %d\n", __func__, val);
  sem_getvalue(&ssp->sem_r, &val);
  printf("[%s] sem_getvalue(&ssp->sem_r, &val): %d\n", __func__, val);

  return shm_ptr;
}
*/


// to do ...
so_t *newCountdown(const char *name, int job_id, int tr_id, int max_count,
		so_t *args)
{
  BEGIN_R_EVAL();
    SEXP r_args = SO_toRObject(args, sizeof(args)+args->size);
    printf("[%s] ", __func__);
    PrintValue(r_args);
  END_R_EVAL();
  return args;
}

so_t *countdownReset(so_t *countdown, int job_id, int tr_id, so_t *args)
{
  BEGIN_R_EVAL();
    SEXP r_args = SO_toRObject(args, sizeof(args)+args->size);
    printf("[%s] ", __func__);
    PrintValue(r_args);
  END_R_EVAL();
  return countdown;
}


#ifndef VALUE_TO_STRING
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)
#endif



#ifdef malloc
//#pragma message("\033[0;31mmalloc is defined\033[0m\n")
//#pragma message "value of malloc(x) = " VALUE(malloc(x))
#endif

#ifdef free
//#pragma message("\033[0;31mfree is defined\033[0m\n")
//#pragma message "value of free(x) = " VALUE(free(x))
#endif


//typedef struct { sc, tid, len, ...
//} driver_countdown_hdr_t;

// R: Cond.count(..., cond.name="defaut")
void handleCountdownDecrease(const char *mutex, supr_socket_conn_t *sc,
		int job_id, int tid, void *ptr, size_t size)
{
//  handleCountdownDecrease(buf, conn, job_id, tid, ptr, size);
//  printf("mutex/cond.name: %s, job_id: %d, tid: %d, addr: %s:%d, ptr: %p, size: %ld\n", mutex, job_id, tid, sc->host, sc->port, ptr, size);
  int *args = (int*) ptr;
//  printf("cmd: %d, job_id: %d, tr_id: %d, cond.name.len: %d\n", args[0], args[1], args[2], args[3]);

  args[2] = tid;
  *((supr_socket_conn_t **)ptr) = sc; // ignore cmd and job_id

  so_t *so;
  if(size == 4 * sizeof(int) + args[3])
    so = NULL;
  else
    so = ptr + 4 * sizeof(int) + args[3];

  /*
  if(so){
  BEGIN_R_EVAL();
    SEXP args = SO_toRObject(so, size);
    PrintValue(args);
  END_R_EVAL();
  }
  */

  /*
  job_t *job;
  if(job_id == __job_id__){
     job = __job__;
  } else {
     job = findJob(job_id);
     if(job) {
       __job_id__ = job_id;
       __job__ = job;
     }
  }
  */
  job_t *job = findJob(job_id);

  if(!job) {
    driver_warning("\033[0;34m[%s] no such a job\033[0m\n", __func__);
//	     write(fd, &tr_id, sizeof(int));
    return;
  }

#define USE_SO_REFERENCE
#ifdef  USE_SO_REFERENCE

  so_t *so_ref = (so_t *) hashtableGet(job->environment, mutex);
  if(!so_ref){
//MALLOC_MARK(__LINE__);
    cond_t *c = Cond_new(mutex, vectorSize(job->taskrunners));
    so_ref = (so_t *) malloc(sizeof(so_t)+sizeof(void *));
    so_ref->ref_count = REF_COUNT_INITIALIZER;
    so_ref->mem_type = 0;
    so_ref->sys_type = 0;
    so_ref->obj_type = SUPR_REFERENCE;
    so_ref->size = sizeof(void*);
//    so_ref->val = (char*) c;
//    void *p = (void *)(so_ref + 1);
//    memcpy(so_ref + 1, p, sizeof(void *));
    ((void **)(so_ref + 1))[0] = c;
    hashtablePut(job->environment, mutex, so_ref);
    //fprintf(stderr, "[%s] c: %p, (void*) so-val: %p\n", __func__, c, ((void **)(so_ref+1))[0]);
//MALLOC_MARK(__LINE__);
  } 
  cond_t *c = *((cond_t **)  so_ref->val);
//  fprintf(stderr, "[%s] c: %p, (void*) so-val: %p\n", __func__, c, ((void **)(so_ref+1))[0]);

#else

  cond_t *c = (cond_t *) hashtableGet(job->environment, mutex);
  if(!c){
MALLOC_MARK(__LINE__);
    c = Cond_new(mutex, vectorSize(job->taskrunners));
    hashtablePut(job->environment, mutex, c);
MALLOC_MARK(__LINE__);
  } 

#endif
  
//  if(so) vectorAdd(c->value, so);
//MALLOC_MARK(__LINE__);
  vectorAdd(c->value, ptr);
//MALLOC_MARK(__LINE__);
  vectorAddIfNotExists(c->conns, sc, NULL);
//MALLOC_MARK(__LINE__);
  c->count--;

	//  printf("c->count: %d\n", c->count);
  if(c->count == 0){
//MALLOC_MARK(__LINE__);
	 // printf("c->count: %d\n", c->count);
    if(job->dcl) {
      so_t *s =  Cond_toSO(c);
//MALLOC_MARK(s->ref_count);
  fprintf(stderr, "[%s] s->ref_count: %d\n", __func__, s->ref_count);
      addDCLEvent(job, "condition", s);
  fprintf(stderr, "[%s] s->ref_count: %d\n", __func__, s->ref_count);
      SO_decref(s);
    }

#define NON_NULL_ONLY
#ifdef  NON_NULL_ONLY
    int n_values = 0;
    for(int i = vectorSize(c->value)-1; i>=0; i--){
      void *ptr = vectorElementAt(c->value, i);
      int *args = (int*) ptr;
      so_t *so = (so_t*)(ptr + 4 * sizeof(int) + args[3]);
      if( so->obj_type != SUPR_NILSXP )
	  n_values++;
    }
//    printf("n_values: %d\n", n_values);

    int cmd = TR_COUNTDOWN_RELEASE;
    for(int k = vectorSize(c->conns)-1; k>=0; k--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *) vectorRemove(c->conns, k);
      write(sc->fd, &cmd, INT_SIZE);
      int len = strlen(mutex)+1;
      write(sc->fd, &len, INT_SIZE);
      write(sc->fd, mutex, len);

      write(sc->fd, &n_values, INT_SIZE);
      for(int i = vectorSize(c->value)-1; i>=0; i--){
        void *ptr = vectorElementAt(c->value, i);
        int *args = (int*) ptr;
        so_t *so = (so_t*)(ptr + 4 * sizeof(int) + args[3]);
        if( so->obj_type != SUPR_NILSXP ) {
          ssize_t nwr = write(sc->fd, so, sizeof(so_t) + so->size);
	}
      }

      int n_trs = 0;
      for(int i=0; i<vectorSize(c->value); i++){
        void *ptr = vectorElementAt(c->value, i);
	if(*((supr_socket_conn_t **)ptr) == sc)
          n_trs++;
      }
      
      write(sc->fd, &n_trs, INT_SIZE);
      for(int i=0; i<vectorSize(c->value); i++){
        void *ptr = vectorElementAt(c->value, i);
        //int *args = (int*) ptr;
	if(*((supr_socket_conn_t **)ptr) == sc)
	  //hdr = args[2]; // tid
          write(sc->fd, ptr+sizeof(supr_socket_conn_t **), INT_SIZE);
      }
    }

#else
    int n = vectorSize(c->value);
    int cmd = TR_COUNTDOWN_RELEASE;
    for(int k = vectorSize(c->conns)-1; k>=0; k--){
      so_t *so;
      supr_socket_conn_t *sc = (supr_socket_conn_t *) vectorRemove(c->conns, k);
      write(sc->fd, &cmd, INT_SIZE);
      write(sc->fd, &n, INT_SIZE);

      int len = strlen(mutex)+1;
      write(sc->fd, &len, INT_SIZE);
      write(sc->fd, mutex, len);

      for(int i=0; i<vectorSize(c->value); i++){
        //so = (so_t*) vectorElementAt(c->value, i);
        void *ptr = vectorElementAt(c->value, i);
        int *args = (int*) ptr;
	int hdr = -1; // tid
	if(*((supr_socket_conn_t **)ptr) == sc)
	  hdr = args[2]; // tid
	
        write(sc->fd, &hdr, INT_SIZE);

        so = (so_t*)(ptr + 4 * sizeof(int) + args[3]);
	printf("so.obj_type: %d, so.size: %ld\n", so->obj_type, so->size);
	size_t size = 4 * sizeof(int) + args[3] + sizeof(so_t) + so->size;
        ssize_t nwr = write(sc->fd, so, sizeof(so_t) + so->size);
	printf("size: %ld, nwr: %ld\n", size, nwr);
      }
    }
#endif

    for(int i = vectorSize(c->value)-1; i >= 0; i--)
    {
      void *ptr = vectorRemove(c->value, i);
      free(ptr);
    }

    c->count = vectorSize(job->taskrunners);
    
//MALLOC_MARK(__LINE__);
  }

  JOB_DECREF(job);
}


typedef void (*sighandler_t)(int);

//this worked 
void myTryEval_SIGINT_handler(int sig){
  fprintf(stderr, "[%s] is called on %d\n", __func__, getpid()); 
  fprintf(stdout, "[%s] is called on %d\n", __func__, getpid()); 
}

char *__r2str(SEXP x, char *buf, int buf_size, int debug)
{ 
       	return NULL;
}

//extern char *(*__r2str)(SEXP x, char *buf, int buf_size, int debug);

//extern char *(*sexp2char)(SEXP x);
//
char *sexp2char(SEXP x)
{
   int buf_size = 128*200;
   char buf[buf_size];
   //char *s = __r2str(x, buf, buf_size, 0);
   char *s = __r2str(x, buf, buf_size, 0);
   char *c = malloc(strlen(s)+1);
   memcpy(c, s, strlen(s)+1);
   return c;
}
//

char *myR_simpleTraceback()
{
  RCNTXT *cntxt = R_GlobalContext;
  int len  = 0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    len += strlen(c)+1+1+32;
    fprintf(stderr, "cntxt = %p: %s\n", cntxt, c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  char *str = malloc(len);
  char *s = str;
  cntxt = R_GlobalContext;
  int i=0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    if(i){ *s ='\n'; s++;}

    char b[16];
    sprintf(b, "%d: ", i++);
    memcpy(s, b, strlen(b));
    s += strlen(b);

    memcpy(s, c, strlen(c));
    s += strlen(c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  *s = 0;
  return str;
}


//extern int R_PPStackTop
//extern const char *R_curErrorBuf();
SEXP R_myTryEval(SEXP expr, SEXP env, int *errorOccurred)
{
#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue
//#define SETJMP(x) setjmp(x)

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  } 


#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));


  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      val = eval(expr, env);
      UNPROTECT(1);

    } else {

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  //UNPROTECT(1);

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n", 
		    __FILE__, __LINE__, save, R_PPStackTop);
  }

  return val;



//#undef SETJMP(x) 
#undef null
#undef R_ToplevelContext
}

extern int R_SignalHandlers;
void testing(int argc, char **argv){

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    //printf("R_CStackStart = %ld\n", R_CStackStart);
    //printf("R_CStackLimit = %ld\n", R_CStackLimit);
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();
  }

 
  /*
  {
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));

    int errorOccurred;
    printf("OKAY??\n");
    SEXP value = R_myTryEval(expr, R_GlobalEnv, &errorOccurred);
    printf("OKAY\n");
  }


  RCNTXT *__R_ToplevelContext  = R_GlobalContext;
  while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;

  printf("R_ToplevelContext>handlerstack:\n");
  PrintValue(__R_ToplevelContext->handlerstack);

#define R_ToplevelContext __R_ToplevelContext

  printf("R_ToplevelContext = %p\n", R_ToplevelContext);
  printf("R_GlobalContext   = %p\n", R_GlobalContext);
  printf("R_SignalHandlers   = %d\n", R_SignalHandlers);
  */
  //SETJMP(R_Toplevel.cjmpbuf);
/*
Defn.h:# define SIGSETJMP(x,s) sigsetjmp(x,s)
Defn.h:# define SETJMP(x) sigsetjmp(x,0)
Defn.h:# define SIGSETJMP(x,s) setjmp(x)
Defn.h:# define SETJMP(x) setjmp(x)
*/
//# define SETJMP(x) setjmp(x)
//  SETJMP(R_ToplevelContext->cjmpbuf);

  /*
  SETJMP(R_Toplevel.cjmpbuf);
    R_GlobalContext = R_ToplevelContext = R_SessionContext = &R_Toplevel;
    */
#define null R_NilValue
  /*
  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
  SEXP env = R_GlobalEnv;



  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

//  int count = 0;

  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

//    int succeeded = FALSE;
    if(!setjmp(R_ToplevelContext->cjmpbuf))
    //if(!setjmp(cntxt.cjmpbuf))
    {
      PrintValue(syscall);
   //   count++; if(count ==5) exit(1);
      printf("\033[0;31m%s: PrintValue\033[0m\n", __func__);
      val = PROTECT(eval(expr, env));
//      succeeded = TRUE;
    } else {
      val = PROTECT(mkString("pthread_error")); // to do
      setAttrib(val, install("class"), mkString("pthread_error"));
      PrintValue(val);
      printf("\033[0;35m%s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

  endcontext(&cntxt);
  */

  //exit(1);


  while(TRUE){

	  /*
    RCNTXT cntxt;
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
    SEXP env = R_GlobalEnv;
    SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

    begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    if(!setjmp(R_ToplevelContext->cjmpbuf))
    {
    */
        int errorOccurred;
        SEXP envir = R_GlobalEnv;
        SEXP expr = PROTECT(LCONS(install("stop"),
			    CONS(mkString("ERROR: TESTING"), R_NilValue)));
        SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(R_tryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(eval(expr, envir));
	printf("errorOccurred = %d\n", errorOccurred);
	if(errorOccurred)
	  fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
	else
          PrintValue(res);

	/*
    } else {
      printf("\033[0;35m[Error] %s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

    endcontext(&cntxt);
#undef null
*/

    //sleep(10);
  }

  //if(R_Interactive) run_Rmainloop();

  exit(1);
}

/*
typedef struct shm_data_header {
  int type;
  int padding;
  size_t size;
} shm_data_header_t;
*/
// Cluster.java:

int  tr_get_shm_identityCode()
{
  static int code = 0;
  fprintf(stderr, "code = %d\n", code); 
  return code++;
}

static size_t __page_size__ = 0;
#define SHM_BLOCK_SIZE (2*__page_size__)

static socket_conn_t *__socket_conn__ = NULL;

extern SEXP SUPR_socketConnect(SEXP hostname, SEXP port, SEXP endian_str); 
extern SEXP SUPR_socketWrite(SEXP conn, SEXP x, SEXP endian_str);
extern SEXP SUPR_socketRead(SEXP conn, SEXP what, SEXP _n, SEXP endian_str); 
extern SEXP SUPR_socketReadObject(SEXP conn, SEXP env); 
extern SEXP SUPR_socketClose(SEXP conn); 
extern SEXP socketReadDCLEvent(SEXP socket_conn, SEXP env);

/*
void  dcl_error(const char *driver_host, int driver_port, int job_id,
	       	const char *msg, SEXP env)
{
  printf("%s: driver_host=%s\n", __func__, driver_host);
  printf("%s: driver_port=%d\n", __func__, driver_port);
  printf("%s: msg=%s\n", __func__, msg);

  SEXP host   = PROTECT(mkString(driver_host));
  SEXP port   = PROTECT(ScalarInteger(driver_port));
  SEXP endian = PROTECT(mkString("big"));
  SEXP conn   = PROTECT(SUPR_socketConnect(host, port, endian)); 

  SEXP x  = PROTECT(ScalarInteger(DCL_JOB_ERROR));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(ScalarInteger(job_id));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(mkString(msg));
  SUPR_socketWrite(conn, x, R_NilValue);

  SEXP ret  = SUPR_socketReadObject(conn, env); 
  UNPROTECT(7);


  printf("[%s] return\n", __func__);
  PrintValue(ret);

}
*/


/*
typedef struct sync_info_struct {
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  void (*run)(void *data);
  void *data;
  sem_t           sem_wait;
  sem_t           sem_notify;
} sync_info_t;
*/


void *rjni_shm_open(const char *cshm_name, size_t *size);

// argv[0] -DCL -port port -shm shm_name -name name
/*
int data_change_listener(int argc, char **argv)
{
  // parse args

  const char *driver_host = "localhost";
  int driver_port = 0;
  const char *shm_name = NULL;

  const char *dcl_name = "default";

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-port")==0 && i+1 < argc) {
      driver_port = atoi(argv[i+1]);
      i++;
    } else if(strcmp(argv[i], "-shm")==0 && i+1 < argc) {
      shm_name = argv[i+1];
      i++;
    } else if(strcmp(argv[i], "-name")==0 && i+1 < argc) {
      dcl_name = argv[i+1];
      i++;
    }
  }

  if(!driver_port){ // FIXME
    char *driver_log_file = "DriverDir/Driver.log";
    int fd = open(driver_log_file, O_RDONLY, 0600);
    if(fd != -1){
      struct stat statbuf;
      int rc = fstat(fd, &statbuf);
      if(rc == -1) {
        printf("[%s] Error (%s, %d): %s\n", __func__, __FILE__, __LINE__, strerror(errno));
      }
      size_t size = statbuf.st_size; // printf("%s: size=%ld\n", driver_log_file, size);
      char buf[size+1];
      read(fd, buf, size);
      close(fd); // printf("%s: %s\n", driver_log_file, buf);
      char *str = strstr(buf, ":");
      *str = 0;

      str++; // printf("%s: \"%s\"\n", driver_log_file, str);
      driver_port = atoi(str);

      driver_host = dupstr(buf+2);
      printf("%s: driver_host=%s\n", driver_log_file, driver_host);
      printf("%s: driver_port=%d\n", driver_log_file, driver_port);

    } else {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      exit(1);
    }
  }

  shm_io_info_t *io = NULL;

  tr_cntxt.io = io;
  tr_cntxt.pid = getpid();

  // initialize R
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);
  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE; 
    setup_Rmainloop();
  }

  myTryEval_SigactionInt = myR_SigactionDCLInt;

  // add/change signal handler
#ifdef __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sa.sa_sigaction = myR_SigactionDCLInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
  }
#endif

  __read__ = __dcl_read__;

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }

  SEXP res = R_NilValue;

  {
    SEXP call = PROTECT(LCONS(install("source"),
                            CONS(mkString("jR.R"), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);

    //printf("\033[0;32m\n\n[%s] OKAY 00\n\n\033[0m", __func__);
  }

  SEXP socket_conn = R_NilValue;
  SEXP env = R_GlobalEnv;

  if(driver_port) {
    SEXP host = PROTECT(mkString(driver_host));
    SEXP port = PROTECT(ScalarInteger(driver_port));
    SEXP endian = PROTECT(mkString("big"));
    socket_conn = PROTECT(SUPR_socketConnect(host, port, endian));
    __socket_conn__ = R_ExternalPtrAddr(socket_conn);
    //printf("[%s] socket fd = %d\n\n", __func__, __socket_conn__->fd);
 
    defineVar(install("socket.conn"), socket_conn, R_GlobalEnv); // fixme
    UNPROTECT(4);
  }

  // # register as the default listener
#define dCL_CONN 4
  SEXP x = PROTECT(ScalarInteger(dCL_CONN));
  //printf("\033[0;33m"); PrintValue(socket_conn);
  SEXP y = SUPR_socketWrite(socket_conn, x, R_NilValue);
  //printf("[%s] y = ", __func__); PrintValue(y); printf("[%s] OKAY 01\n", __func__);

  y = SUPR_socketWrite(socket_conn, install(dcl_name), R_NilValue);
  //printf("[%s] dcl_name = %s y = ", __func__, dcl_name);
  //PrintValue(y); printf("[%s] OKAY 02\n", __func__);
  UNPROTECT(1);


  int job_id = -1;
  int tr_id = -1;
  tr_cntxt.job_id = job_id;
  tr_cntxt.tr_id =  tr_id;

  SEXP envir = env;

  defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);
  defineVar(install(TR_TR_ID), ScalarInteger(tr_id), envir);
  SEXP ioPtr = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
  defineVar(install(TR_TR_IO), ioPtr, envir);
  UNPROTECT(1);


  SEXP expr = R_NilValue;

  int X11 = TRUE;

  SEXP event = R_NilValue;


  if(shm_name){

	 
    size_t size;
    void *mem_ptr = rjni_shm_open(shm_name, &size);
    printf("5/6: [%s] shm_name = %s\n", __func__, shm_name);
    printf("5/6: [%s] size = %ld, mem_ptr = %p\n", __func__, size, mem_ptr);

    sem_t *sem_wr = (sem_t *) mem_ptr;
    pid_t pid = ((pid_t*)(sem_wr+1))[0];
    printf("[%s] pid = %d, RDriver.pid = %d\n", __func__, getpid(), pid);
    pid = getpid();
    memcpy(sem_wr + 1, &pid, sizeof(pid_t));

    sem_post(sem_wr);
    munmap(mem_ptr, size);
   
  }

  while(TRUE){

    printf("\033[0;32m\n[%d] Next Job\n\033[0m", getpid()); 
    isDCLInterrupted = FALSE;
    isDisconnected   = FALSE;

    int errorOccurred;
    
    int save = R_PPStackTop;

    fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);

    int pi_envir;
    PROTECT_WITH_INDEX(envir, &pi_envir);
    int pi;
    PROTECT_WITH_INDEX(expr, &pi);


    SEXP nextEvent = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("socketReadDCLEvent"),
	    CONS(socket_conn, CONS(envir, R_NilValue)))));

    SEXP event = PROTECT(R_myTryEval(nextEvent, envir, &errorOccurred));

    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(event, 0)));

      if(isDCLInterrupted){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
        break;
      } else if(isDisconnected){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "disconnected");
        break;
      } else {
        UNPROTECT(4);
        continue;
      }
    } else if(TYPEOF(event) == NILSXP){
        UNPROTECT(4);
	continue;
    }
    defineVar(install("event"), event, envir);
    //PrintValue(event);

    const char *event_name = CHAR(PRINTNAME(VECTOR_ELT(event, 2))); // FIXME
    //printf("\033[031m[%s] event_name = \"%s\"\n", __func__, event_name);
    if(strcmp(event_name, "new()")==0){

       SEXP event_value = VECTOR_ELT(event, 3); // FIXME
       printf("event_value:\n"); PrintValue(event_value);

       printf("expr:\n");
       expr = VECTOR_ELT(event_value, 0); // FIXME
       REPROTECT(expr, pi);
       PrintValue(expr);

       job_id = INTEGER(VECTOR_ELT(event_value, 2))[0]; // FIXME
       printf("job_id: %d\n", job_id);
       defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);

       printf("envir:\n");
       envir = VECTOR_ELT(event_value, 1); // FIXME
       //REPROTECT(envir, pi_envir);
       if(TYPEOF(envir) == NILSXP){
         envir =  allocSExp(ENVSXP);
         REPROTECT(envir, pi_envir);
       //} else if(TYPEOF(envir) == VECSXP){
       } else if(TYPEOF(envir) != ENVSXP){
         //dcl_error(driver_host, driver_port, job_id, "invalid environment variable", R_GlobalEnv);
       }
       SET_ENCLOS(envir, R_GlobalEnv);
       PrintValue(envir);

    } else {
      printf("[%s] Whoops: event_name = \"%s\"\n", __func__, event_name);
      UNPROTECT(4);
      continue;
    }
    printf("\033[0m\n");
    if(save + 4 != R_PPStackTop) {
      fprintf(stderr, "Warning: save + 4 = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save + 4, R_PPStackTop, __FILE__, __LINE__);
    }

    SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
    //printf("[%s] errorOccurred = %d\n", __func__, errorOccurred);
    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
      //dcl_error(driver_host, driver_port, job_id, CHAR(STRING_ELT(res, 0)), envir); } else 
      PrintValue(res);

    
    if(isDCLInterrupted){
      fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
      break;
    }

    if(!errorOccurred)
      UNPROTECT(5);

    if(save != R_PPStackTop) {
      fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);
    }

  }

  //if(R_Interactive) run_Rmainloop();

  fprintf(stderr, "\033[0;31m%s\033[0m", "exit");
  exit(0);

}
*/

#include "util.h"

extern int SocketConn_reuseAddr;
extern supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);
extern supr_socket_conn_t *serverSocketAccept(supr_socket_conn_t *serverConn);

extern vector_t *socket_connections; // defined in supr.c
extern vector_t *special_socket_connections; // defined in supr.c
extern vector_t *messages;
//vector_t *threads = NULL;

/*
supr_socket_conn_t *Supr_findConnection(int fd)
{
  if(socket_connections == NULL)
	  return NULL;

  for(int i = vectorSize(socket_connections) - 1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    if(sc->fd == fd)
	    return sc;
  }

  return NULL;
}
*/


//extern size_t (*__read__)(int fd, void *buf, size_t size);
//
ssize_t __read__(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec = (int) Supr_options.timeout;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
//            if(ns==0) continue; else return -1;
	      if(ns == 0) {
		//      errno = EWOULDBLOCK;
	      	error_info(strerror(errno));
		error_info("gdb -p %d; gdb -p %d", getpid(), gettid());
		/*
	        {
		      char buf[256];
		      sprintf(buf, "gdb -p %d", getpid());
		      error_info(buf);
	        }
	        // sleep(60); return -1;
		*/
	      } else {
	      	error_info(strerror(errno));
	        return -1;
	      }
      } 
    }

    ssize_t n = read(fd, buf + len,  size - len);

    if(n <= 0){
      char err[256];
      sprintf(err, "read, n = %ld, %s\n", n, strerror(errno));
      error_info(err);
      return -1;
    }


    len += n;
  }
  return size;
}
//

/*
int wrapped_strcmp(void *a, void *b)
{
	return strcmp((char*)a, (char*)b);
}
*/

/*
job_t *getJob(int job_id){
  
  job_t  *job = NULL;
  if(job_id == __job_id__){
     job = __job__;
  } else {
     job = findJob(job_id);
     if(job) {
       __job_id__ = job_id;
       __job__ = job;
     }
  }
  return job;
}
*/

#define read __read__	   

void combine(supr_socket_conn_t *conn, int job_id, int tr_id, int id_no,
                  char *shm_name)
{
//	printf("\033[0;35m");
  job_t *job = findJob(job_id); // handle error ...

  if(!job){
    char msg[256];
    sprintf(msg, "cannot find job: %d", job_id);
    basic_info(msg);
    char *err = msg;
    so_t so = {0, 0, 0, SUPR_ERROR, strlen(err)+1};
    write(conn->fd, &so, sizeof(so_t));
    write(conn->fd, err, strlen(err)+1);
    return;
  }

  pthread_mutex_lock(&job->mutex);

    if(job->combine_count==0){
      job->combine_count = vectorSize(job->executors);
    }

    if(!job->taskrunners){
	    error_info("!job->taskrunners, job cancelled");
	    pthread_mutex_unlock(&job->mutex);
	    return;
    }
    char *trAddr = vectorElementAt(job->taskrunners, tr_id);
//    printf("[%s:%d] trAddr: \"%s\"\n", __func__, __LINE__, trAddr);
//    printf("[%s:%d] job->combine_count: %d\n", __func__, __LINE__, job->combine_count);

    if(job->combine_result){
//      printf("[%s:%d] Take it: job->result=\"%s\"\n", __func__, __LINE__, job->combine_result);
      char *name = job->combine_result;
      job->combine_result = NULL;

      // URI [so_t, uri]
      so_t so = {0, 0, 0, SUPR_URI, strlen(name)+1};
      unsigned char buf[sizeof(so_t)+so.size];
      memcpy(buf, &so, sizeof(so_t));
      sprintf(buf+sizeof(so_t), "%s", name);

//      printf("[%s:%d] Send uri: \"%s\"\n", __func__, __LINE__, buf + sizeof(so_t));

      free(name);
      write(conn->fd, buf, sizeof(buf));

    } else {
      char buf[strlen(trAddr)+strlen(shm_name)+1];
      memcpy(buf, trAddr, strlen(trAddr)+1);
      memcpy(strstr(buf,"#")+1, shm_name, strlen(shm_name)+1);
      job->combine_result = strdup(buf);
//      printf("[%s:%d] Leave it at driver: job->result=\"%s\"\n", __func__, __LINE__, job->combine_result);
      job->combine_count--;
      so_t so = {0, 0, 0,
	      job->combine_count ? SUPR_NILSXP : SUPR_UNBOUND_VALUE,
	      0};
      write(conn->fd, &so, sizeof(so_t));
    }
    //Supr_decref(job);
    JOB_DECREF(job);
  pthread_mutex_unlock(&job->mutex);
//	printf("\033[0m");
  
}

char **strsplit(char *buf, const char *delim, int *length)
{
//  basic_info("buf: \"%s\"", buf);
  if(strlen(buf)==0){
     *length = 0;
     return NULL;
  }

  int n = *length > 0 ? *length : 0;
  if(n==0){
    if(!buf) { *length = 0; return NULL; }
    n ++;
    char *str;
    int len = strlen(delim);
    while(str = strstr(str, delim)){ n++; str += len; }
  } 

  char **ss = (char**) malloc(sizeof(char*)*n);

  ss[0] = strtok(buf, delim);
  for(int i=1; i<n; i++)
    ss[i] = strtok(NULL, delim);
  
  *length = n;
  return ss;
}

void combine_bykey_init(supr_socket_conn_t *conn)
{
//MALLOC_MARK(0);
//MALLOC_MARK(__LINE__);
  static const char *KEY_SEP = ";";
	printf("\033[0;35m");
  int fd = conn->fd;
  int job_id, tr_id, nkeys, len;
  read(fd, &job_id, sizeof(int));
  read(fd, &tr_id, sizeof(int));
  read(fd, &nkeys, sizeof(int));
  read(fd, &len, sizeof(int));

  job_t *job = findJob(job_id); // handle error ...

//MALLOC_MARK(__LINE__);
  char *buf = (char*) malloc(len);
//MALLOC_MARK(__LINE__);
  read(fd, buf, len);

  if(len==0){ // empty strings are not allowed
  }
  //printf("[%s] %d keys: %s\n", __func__, nkeys, buf);

  /*
  {// testing
	  char *s = strdup(buf);
	  int n = 0;
          char **ss = strsplit(s, KEY_SEP, &n);
	  printf("\033[0;37m(tid=%ld, n=%d)\n", syscall(SYS_gettid), n);
	  for(int i=0; i<n; i++){
            printf("%d: %s\n", i, ss[i]);
	  }
	  printf("\033[0m");
	  free(s);
	  free(ss);
  }
  */
  int n = nkeys;
  char **keys = strsplit(buf, KEY_SEP, &n);
//MALLOC_MARK(__LINE__);
  /*
  {
	  printf("\033[0;35m(tid=%ld)\n", syscall(SYS_gettid));
	  for(int i=0; i<n; i++){
            printf("%d: %s\n", i, keys[i]);
	  }
	  printf("\033[0m");
  }
  */

  pthread_mutex_lock(&job->mutex);
    char *trAddr = vectorElementAt(job->taskrunners, tr_id);
    //printf("[%s:%d], trAddr: %s\n", __func__, __LINE__, trAddr);
    char *executorAddr = strdup(trAddr); *strstr(executorAddr, "#") = 0;
    //printf("[%s:%d], execAddr: %s\n", __func__, __LINE__, executorAddr);
    if(!job->cbk){
      job->cbk = (cbk_t*) malloc(sizeof(cbk_t));
      job->cbk->shm_names = newHashtable(FALSE);
      job->cbk->key_values = newHashtable(FALSE);
      //pthread_cond_init(&job->cbk->cond, NULL);
      //job->cbk->keys = NULL;
      //job->cbk->nkeys = 0;
      //job->cbk->count = 0;
      job->cbk->count = vectorSize(job->executors);
      job->cbk->nsc = job->cbk->count;
      job->cbk->sc = (supr_socket_conn_t **)malloc(job->cbk->nsc*
		      sizeof(supr_socket_conn_t));
      //{
	      job->cbk->key_values->free_data = __free_func__;
	      //job->cbk->shm_names->free_data = __decref_func__;
	      job->cbk->shm_names->free_data = Supr_decref;
      //}
    }
//MALLOC_MARK(__LINE__);

    hashtable_t *shm_names = job->cbk->shm_names;
//MALLOC_MARK(__LINE__);
    for(int i = nkeys-1; i>=0; i--){
        vector_t *executor_names = (vector_t *)hashtableGet(shm_names, keys[i]);
        if(!executor_names){
          executor_names = newVector(FALSE);
	  hashtablePut(shm_names, keys[i], executor_names);
        }
	vectorAdd(executor_names, executorAddr);
    }
//MALLOC_MARK(__LINE__);
    job->cbk->count--;
    job->cbk->sc[job->cbk->count] = conn;

//MALLOC_MARK(__LINE__);

    if(job->cbk->count == 0){
      so_t so = {0, 0, 0, SUPR_NILSXP, 0};
      for(int i=0; i<job->cbk->nsc; i++){
        write(job->cbk->sc[i]->fd, &so, sizeof(so_t));
  //      printf("[%s:%d], Send: %s:%d\n", __func__, __LINE__, job->cbk->sc[i]->host, job->cbk->sc[i]->port);
      }
    }
    //Supr_decref(job);
    JOB_DECREF(job);
  pthread_mutex_unlock(&job->mutex);
  //printf("\033[0m");

  //{ // FIXME?
	  free(keys);
	  free(buf);
  //}
//MALLOC_MARK(__LINE__);
}

void combine_bykey(supr_socket_conn_t *conn)
{
//MALLOC_MARK(0);
  static const char *KEY_SEP = "\n"; // FIXME
  int fd = conn->fd;
  int job_id, tr_id, len;
  read(fd, &job_id, sizeof(int));
  read(fd, &tr_id, sizeof(int));
  read(fd, &len, sizeof(int));

//  printf("\033[0;32m[%s:%d] job_id: %d tr_id: %d\n", __func__, __LINE__, job_id, tr_id);

  job_t *job = findJob(job_id); // handle error ...

  char *buf = (char*) malloc(len); // free?
  read(fd, buf, len);
  //printf("[%s] key-value pair: %s\n", __func__, buf);
  char *key = buf;
  char *shm_name = strstr(buf, KEY_SEP);
  *shm_name = 0; shm_name += strlen(KEY_SEP);
//  printf("[%s] key-value pair: (%s, %s)\n", __func__, key, shm_name);

  pthread_mutex_lock(&job->mutex);

    char *trAddr = vectorElementAt(job->taskrunners, tr_id);
    //printf("[%s:%d], trAddr: %s\n", __func__, __LINE__, trAddr);
    char *executorAddr = strdup(trAddr); *strstr(executorAddr, "#") = 0;
 //   printf("[%s:%d], execAddr: %s\n", __func__, __LINE__, executorAddr);

    hashtable_t *key_values = job->cbk->key_values;
    char *value = (char *) hashtableGet(key_values, key); 
 //   printf("[%s:%d], cluster value: %s\n", __func__, __LINE__, value);

    if(value){ // take the value
  //    printf("\033[0;31m[%s:%d], Take URI: %s\033[0m\n", __func__, __LINE__, value);

      // URI
      char ret[sizeof(so_t) + strlen(value)+1]; //remove the int?
      sprintf(ret+sizeof(so_t), "%s", value);
      so_t so = {0, 0, 0, SUPR_URI, strlen(value)+1};
      memcpy(ret, &so, sizeof(so_t));

      write(conn->fd, &ret, sizeof(ret));

      hashtableDelete(key_values, key); 
//MALLOC_MARK(__LINE__);

    } else { // leave the shm_name as the value

//MALLOC_MARK(__LINE__); // ...
      value = (char*) malloc(strlen(executorAddr)+strlen(shm_name)+2);
//MALLOC_MARK(__LINE__); // ...
      sprintf(value, "%s#%s", executorAddr, shm_name);

//      printf("\033[0;34m[%s:%d], Leave URI: %s\033[0m\n", __func__, __LINE__, value);

      hashtablePut(key_values, key, value); 
      hashtable_t *shm_names = job->cbk->shm_names;
      vector_t *executor_names = (vector_t *) hashtableGet(shm_names, key);

      // FIXME
      int i=vectorSize(executor_names)-1; 
      for(; i>=0; i--){
        char *addr =  (char*)vectorElementAt(executor_names,i);
        if(strcmp(addr, executorAddr)==0){
          vectorRemoveElement(executor_names, addr);
	  break;
	}
      }
      if(i<0) {
	      printf("\033[0;31m[%s:%d] Error: FIXME\033[0m\n", __func__,
			      __LINE__);
      }
      
      if(vectorSize(executor_names)){ // not finished yet for this key
        so_t so = {0, 0, 0, 2, 0}; // FIXME?
        printf("[%s:%d], Send return code: 2\n", __func__, __LINE__);
        write(conn->fd, &so, sizeof(so_t));
      } else { // finished for this key
        hashtableDelete(shm_names, key);
	// check if finished for all keys

        printf("[%s:%d], %d more keys\n", __func__, __LINE__, 
			hashtableSize(shm_names));

	if(hashtableSize(shm_names)){ // not finished yet
          so_t so = {0, 0, 0, 1, 0};
          printf("[%s:%d], Send return code: 1\n", __func__, __LINE__);
          write(conn->fd, &so, sizeof(so_t));
	} else {
#ifdef CBK_KEEP_LAST_KEY_VALUES
	  hashtablePut(job->environment, ".LastValue", key_values);
	  job->cbk->key_values = NULL;
#endif
	  //cbkDestroy(job->cbk);
	  cbk_finalize(job->cbk);
	  job->cbk = NULL;
          so_t so = {0, 0, 0, 0, 0};
          printf("[%s:%d], Send return code: 0\n", __func__, __LINE__);
          write(conn->fd, &so, sizeof(so_t));
	}
      }

    }
    //Supr_decref(job);
    JOB_DECREF(job);
  pthread_mutex_unlock(&job->mutex);
	printf("\033[0m");
  //{ // FIXME?
	  free(buf);
  //}
//MALLOC_MARK(__LINE__);
}




static pthread_mutex_t sync_mutex = PTHREAD_MUTEX_INITIALIZER;
static supr_thread_t *timedwait_thread = NULL;

static hashtable_t *syncHashtable = NULL;
static hashtable_t *waitHashtable = NULL;

typedef struct sync_wait_struct {
  char *monitor; // mutex;
  supr_socket_conn_t *sc;
  int cmd; // _SYNC_RETURN or _NOTIFY
  int job_id;
  int padding; // or used as the ref_count???

  int tid; // for timedwait
  struct timespec wait;
} sync_wait_t;

sync_wait_t *newSyncWait(int job_id, int tid, char *monitor,
	       	supr_socket_conn_t *sc, int cmd){
  sync_wait_t *sw = (sync_wait_t *) malloc(sizeof(sync_wait_t));
  sw->monitor = monitor;
  sw->sc = sc;
  sw->cmd = cmd;
  sw->job_id = job_id;
  sw->tid = tid;
  sw->wait.tv_sec = 0;
  sw->wait.tv_nsec= 0;
  return sw;
}

static vector_t *timedwait_queue = NULL;

void sync_wait_destroy(sync_wait_t *sw)
{
  free(sw);
}

// FIXME: made it job specific
vector_t *Driver_getSyncQueue(int job_id, char *mutex)
{
  //if(!syncHashtable) syncHashtable = newHashtable(FALSE);
  vector_t *sync_queue = (vector_t *) hashtableGet(syncHashtable, mutex);

  if(!sync_queue){
    sync_queue = newVector(FALSE);
    hashtablePut(syncHashtable, mutex, sync_queue);
  }
  return sync_queue;
}

vector_t *Driver_getWaitQueue(int job_id, char *mutex)
{
  //if(!waitHashtable) waitHashtable = newHashtable(FALSE);
  vector_t *wait_queue = (vector_t *) hashtableGet(waitHashtable, mutex);

  if(!wait_queue){
    wait_queue = newVector(FALSE);
    hashtablePut(waitHashtable, mutex, wait_queue);
  }
  return wait_queue;
}

#define USE_NEW_TIMEDWAIT_THREAD_RUN
#ifndef USE_NEW_TIMEDWAIT_THREAD_RUN
// see supr.c: ThreadServer_timedwait_thread_run(supr3_thread_t *cth)

//void ThreadServer_timedwait_thread_run(supr3_thread_t *cth)
void  timedwait_thread_run() // FIXME for job cancellations ...
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();

  while(TRUE){
    pthread_mutex_lock(syncHashtable->mutex);

      if(vectorSize(timedwait_queue) == 0){
        pthread_cond_wait(&cth->cond, syncHashtable->mutex);
      } else {
        sync_wait_t *sw = (sync_wait_t *) vectorElementAt(timedwait_queue,0);
        long sw_time = sw->wait.tv_sec*1000000000 + sw->wait.tv_nsec;

        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        long current_time = wait.tv_sec*1000000000 + wait.tv_nsec;

        if(sw_time <= current_time){
		BASIC_INFO("TIMEOUT");
		/*
    if(Supr_verbose) {
      fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
                    sw->monitor, sw->sc->fd);
      //sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }
    */
          vectorRemoveElement(timedwait_queue, sw);
          char *mutex = sw->monitor;
          //vector_t *wait_queue = getWaitQueue(sw->sc, sw->monitor);
          //vector_t *sync_queue = getSyncQueue(sw->sc, sw->monitor);
          vector_t *wait_queue = Driver_getWaitQueue(sw->job_id, sw->monitor);
          vector_t *sync_queue = Driver_getSyncQueue(sw->job_id, sw->monitor);

	  /*
    if(Supr_verbose) {
      fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
                    sw->monitor, sw->sc->fd);
      sync_wait_queue_print(sync_queue, "sync_queue");
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }
    */

          if(!wait_queue || !sync_queue){
            fprintf(stderr, "[%s:%d:%s] ERROR, FIXME!\n",
                            __FILE__, __LINE__, __func__);
          }
          vectorRemoveElement(wait_queue, sw);

          //vectorAdd(sync_queue, sw);

	  /*
    if(Supr_verbose) {
      fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
                    sw->monitor, sw->sc->fd);
      sync_wait_queue_print(sync_queue, "sync_queue");
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }
    */
	  //
          if(vectorSize(sync_queue)==1){
            int rc = 0;
            ssize_t size = write(sw->sc->fd, &rc, sizeof(int));
          }
	  //
          pthread_mutex_unlock(syncHashtable->mutex);
          continue;
        }

        pthread_cond_timedwait(&cth->cond, syncHashtable->mutex, &sw->wait);
      }
    pthread_mutex_unlock(syncHashtable->mutex);
  }

}

#else
void  timedwait_thread_run() // FIXME for job cancellations ...
{
  supr_thread_t *cth = currentThread();
  //printf("[%s] tid: %d\n", __func__, cth->tid);

  while(TRUE){
    pthread_mutex_lock(&cth->mutex);
     
      struct timespec *timedwait = NULL;

      pthread_mutex_lock(&sync_mutex);

      //printf("\n\033[0m");
	{
          struct timespec wait;
          clock_gettime(CLOCK_REALTIME, &wait);
	  long current_time = wait.tv_sec*1000000000 + wait.tv_nsec;
	  //printf("current time: struct timespec{%ld, %ld}\n", wait.tv_sec, wait.tv_nsec);

          sync_wait_t *sw;
	  for(int i=0; i<vectorSize(timedwait_queue); i++){
            sw = (sync_wait_t *) vectorElementAt(timedwait_queue,i);

//	    printf("TIMEOUT time: struct timespec{%ld, %ld}, monitor: %s\n", sw->wait.tv_sec, sw->wait.tv_nsec, sw->monitor);

	    if(!sw->monitor){
              error_info("%d: [Error] sw->monitor == null\n", __LINE__);
	      sleep(2);
	      continue;
	    }

	    long sw_time = sw->wait.tv_sec*1000000000 + sw->wait.tv_nsec;
	    if(sw_time <= current_time){

//		BASIC_INFO("[TIMEOUT] diff: %ld\n", sw_time - current_time);

	      sw->cmd = TR_CLUSTER_WAIT_TIMEOUT;

	      vectorRemoveElement(timedwait_queue, sw);
	      i--;
//	      printf("\033[0;34m\ttimeout_notify(<%p>)\033[0;33m\n\n", sw);
	      
              //timeout_notify:
	      char *mutex = sw->monitor;
	      vector_t *wait_queue = Driver_getWaitQueue(sw->job_id, sw->monitor);
	      vector_t *sync_queue = Driver_getSyncQueue(sw->job_id, sw->monitor);

	      if(!wait_queue || !sync_queue){
	        error_info("\033[0;31m[%s] Error: FIXME (%s:%d),"
			" wait_queue: <%p>  sync_queue: <%p>\033[0;33m\n",
			       	__func__, __FILE__, __LINE__,
				wait_queue, sync_queue);
		continue;
	      }
	      vectorRemoveElement(wait_queue, sw);

	      if(vectorSize(sync_queue)){
                vectorAddElementAt(sync_queue, 1, sw); //check sync_mutex lock
		{
                  supr_socket_conn_t *conn = sw->sc;
                  //printf("(timeout) Added to sync_queue: //%s:%d\n\n", conn->host, conn->port);
		}
	      } else {
                supr_socket_conn_t *conn = sw->sc;
		
		int fd = conn->fd;
		if(conn->to) fd = conn->to->fd;
                int cmd = sw->cmd;
                //printf("\033[0;31m(timeout) Send cmd: %d (%s)\n", cmd, cmd2char(cmd));
                //printf("(timeout) Send addr: //%s:%d\n\n\033[0m", conn->host, conn->port);
                write(fd, &cmd,     INT_SIZE);

                write(fd, &sw->job_id,     INT_SIZE);

		//if(sw->cmd == TR_CLUSTER_TIMEOUT)
                write(fd, &sw->tid, INT_SIZE);
                size_t len = strlen(mutex)+1;
                write(fd, &len, SIZE_SIZE);
                write(fd, mutex, len);

		if(conn->to){
		  //basic_info("Check: read(fd, &rc, sizeof(int))");
		  int rc;
		  ssize_t n = read(fd, &rc, sizeof(int));
		  //BASIC_INFO("Check: read(fd, &rc, sizeof(int)): %ld, rc: %d", n, rc);
		}
                sw->cmd = TR_CLUSTER_SYNC_RETURN;
		vectorAdd(sync_queue, sw);
	      }

	    }
	  }
	}

        if(vectorSize(timedwait_queue)){

          sync_wait_t *sw = (sync_wait_t *) vectorElementAt(timedwait_queue,0);
	  timedwait = &sw->wait;
	  printf("TIMEOUT time: struct timespec{%ld, %ld}\n",
			  sw->wait.tv_sec, sw->wait.tv_nsec);
	  {
            struct timespec wait;
            clock_gettime(CLOCK_REALTIME, &wait);
	    printf("current time: struct timespec{%ld, %ld}\n",
			      wait.tv_sec, wait.tv_nsec);

	    for(int i=vectorSize(timedwait_queue)-1; i>=0; i--){
              sw = (sync_wait_t *) vectorElementAt(timedwait_queue, i);
	      struct timespec *timedwait = &sw->wait;
	      printf("%d. timeout time: struct timespec{%ld, %ld}\n",
			      i, sw->wait.tv_sec, sw->wait.tv_nsec);
	    }
	  }
	}

      //printf("\n\033[0m");
      pthread_mutex_unlock(&sync_mutex);

      
      cth->data = NULL;

      if(timedwait){
          pthread_cond_timedwait(&cth->cond, &cth->mutex, timedwait);
      } else {
          pthread_cond_wait(&cth->cond, &cth->mutex);
      }

      if(cth->data == PTHREAD_NOTIFIED)
      {
        printf("\033[0;32mPTHREAD_NOTIFIED\033[0m\n");
      }
      else
      {
        printf("\033[0;35mTIMEOUT EVENT\033[0m\n");
      }
     
    pthread_mutex_unlock(&cth->mutex);
  }
}
#endif

int sync_wait_compare(const void *x, const void *y){

  sync_wait_t *a = (sync_wait_t *) *((void **)x);
  sync_wait_t *b = (sync_wait_t *) *((void **)y);

  /*
  printf("[%s] \ta: {%ld\t%ld}\n", __func__, a->wait.tv_sec, a->wait.tv_nsec);
  printf("[%s] \tb: {%ld\t%ld}\n", __func__, b->wait.tv_sec, b->wait.tv_nsec);
  */

  long a_nsec = a->wait.tv_sec*1000000000 + a->wait.tv_nsec;
  long b_nsec = b->wait.tv_sec*1000000000 + b->wait.tv_nsec;
  /*
  int k = (int) (a_nsec - b_nsec);
  printf("[%s] \tdiff: %d\n", __func__, k);
  */
  return (int) (a_nsec - b_nsec);
}

int handleSync(supr_socket_conn_t *conn, int job_id, int tid,
	       	char *mutex, int sync)
{
  pthread_mutex_lock(&sync_mutex);

    //printf("\033[0;37m\n/////[\n");
    //printf("[%s] mutex: %s\n", __func__, mutex);

  // if(!syncHashtable) syncHashtable = newHashtable(FALSE);
  // vector_t *sync_queue = (vector_t *) hashtableGet(syncHashtable, mutex);
  //if(!sync_queue){
   // sync_queue = newVector(FALSE);
   // hashtablePut(syncHashtable, mutex, sync_queue);
  //}
    vector_t *sync_queue = Driver_getSyncQueue(job_id, mutex);
    if(!sync_queue){
	    basic_info("sync_queue == NULL");
            pthread_mutex_unlock(&sync_mutex);
	    return -1;
    }

    //printf("[%s] sync_queue: %s\n", __func__, objectToString(sync_queue));

    if(sync == TR_CLUSTER_SYNC){

      //printf("[%s] sync(mutex: %s)\n", __func__, mutex);
      int retcmd = TR_CLUSTER_SYNC_RETURN;
      vectorAdd(sync_queue, newSyncWait(job_id, tid, strdup(mutex), conn,
			    retcmd));

      //Supr_incref(conn); // FIXME add cleanup calls???

      if(vectorSize(sync_queue) == 1){

	int fd = conn->fd;
	if(conn->to) fd = conn->to->fd;
        write(fd, &retcmd, INT_SIZE);
        write(fd, &job_id, INT_SIZE);
        write(fd, &tid,    INT_SIZE);

        size_t len = strlen(mutex)+1;
        write(fd, &len, SIZE_SIZE);
        write(fd, mutex, len);

	if(conn->to){
		int rc;
		read(fd, &rc, sizeof(int));
		if(rc != 0){ // Checking... deleteme later ...
			error_info("rc != 0, FIXME!");
		}
	}
      }

    } else if(sync == TR_CLUSTER_UNSYNC){

      printf("[%s] unsync(mutex: %s)\n", __func__, mutex);
      sync_wait_t *sw = (sync_wait_t *) vectorRemove(sync_queue, 0);

      if(!sw || sw->sc != conn) 
      { // cancelled jobs...
	    basic_info(sw == NULL ? "sw == NULL" : "sw->sc != conn");
            pthread_mutex_unlock(&sync_mutex);
	    return -1;
      }

      if(sw->cmd == TR_CLUSTER_SYNC_RETURN) {
	      /*
	      char msg[1024];
	      sprintf(msg, "sw->cmd == TR_CLUSTER_SYNC_RETURN, sw: %p", sw);
	      basic_info(msg);
	      */
        sync_wait_destroy(sw); // FIXME: double free?
      }

      if(vectorSize(sync_queue)){
    
        sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
        int fd = sw->sc->fd;
	if(sw->sc->to) fd = sw->sc->to->fd;
        int retcmd = sw->cmd;  // SYNC_RETURN, WAIT_TIMEOUT, WAIT_RETURN
        write(fd, &retcmd,        INT_SIZE); //if(cmd == TR_CLUSTER_TIMEOUT)
        write(fd, &sw->job_id, INT_SIZE);
        write(fd, &sw->tid,    INT_SIZE);

        size_t len = strlen(mutex)+1;
        write(fd, &len, SIZE_SIZE);
        write(fd, mutex, len);

	if(sw->sc->to){
		//char msg[256]; sprintf(msg, "Sent cmd: %d (%s)", retcmd, cmd2char(retcmd)); basic_info(msg);
		int rc;
		read(fd, &rc, sizeof(int));
		if(rc != 0){ // Checking... deleteme later ...
			error_info("rc != 0, FIXME!");
		}
	}

        sw->cmd = TR_CLUSTER_SYNC_RETURN;
      }

    } else {
      printf("[%s:%d] sync = %d, TODO\n", __func__, __LINE__, sync);
    }
    printf("]/////\n\033[0m");

  pthread_mutex_unlock(&sync_mutex);
  return 0;
}
//int handleSync(supr_socket_conn_t *conn, int job_id, int tid, char *mutex, int sync)
void __handleSync__(void *data)
{
  supr_socket_conn_t *conn = ((supr_socket_conn_t **) data)[0];
  int *par = (int*)(data + sizeof(supr_socket_conn_t *));
  int cmd = par[0];
  int job_id = par[1];
  int tid = par[2];
  char *mutex = (char*)(par + 3);

  /*{
    char msg[256];
    sprintf(msg, "'%s:%d' cmd: %d (TR_CLUSTER_SYNC=%d, TR_CLUSTER_UNSYNC=%d) job_id: %d, tid: %d, mutex: %s", conn->host,
		    conn->port, cmd, TR_CLUSTER_SYNC,
		   TR_CLUSTER_UNSYNC, job_id, tid, mutex);
    basic_info(msg);
  }*/

  int rc = handleSync(conn, job_id, tid, mutex, cmd);
  free(data);
}

void  __handleErrorResult__(void *data){

  int job_id = ((job_t *)data)->id;

	         int count = 0;
		 int buf[] = {TR_CLUSTER_INTERRUPT, job_id};
		 for(int i=vectorSize(socket_connections)-1; i >= 0; i--){
                   supr_socket_conn_t *sc = (supr_socket_conn_t *)
                        vectorElementAt(socket_connections, i);
                   if(sc->type == WORKER_CONN && sc->to){
                     write(sc->to->fd, buf, sizeof(buf));
		     int rc;
		     read(sc->to->fd, &rc, INT_SIZE); //
		     count += 1 - rc;
		     if(Supr_options.verbose)
		     {
		       char msg[256];
		       sprintf(msg, "[TR_CLUSTER_INTERRUPT/CANCELL] job_id: %d, rc: %d",
                                 job_id, rc);
		       verbose_info(msg);
		     }
		   } 
		 } 

}

#ifdef TR_WAIT_USE_TIME_EXPR

typedef struct cluster_wait_arg_struct {
        supr_socket_conn_t *conn;
        const char *mutex;
	int job_id;
	int tid;
	ssize_t nraw;
        unsigned char *raw;
        double timeout;
} cluster_wait_arg_t;

extern SEXP (*cluster_timeout_ptr)(SEXP);
// more to do ...
SEXP Driver_timeout(SEXP argPtr)
{
  cluster_wait_arg_t *arg = (cluster_wait_arg_t *) R_ExternalPtrAddr(argPtr);
 // basic_info(arg->mutex);
  //char msg[256];
  //sprintf(msg, "\033[0;31mmutex: %s, job_id: %d\033[0m", arg->mutex, arg->job_id);
  //basic_info(msg);

  int job_id = arg->job_id;
  int ntrs = -1;
  pthread_mutex_lock(jobs->mutex);
    job_t *job = NULL;
    for(int i=0; i < vectorSize(jobs); i++){
      job = (job_t *) vectorElementAt(jobs, i);
      if(job->id == job_id) break; else job = NULL;
    }
    if(job){
      ntrs = vectorSize(job->taskrunners);
    }
  pthread_mutex_unlock(jobs->mutex);

  //sprintf(msg, "\033[0;31mmutex: %s, job_id: %d, ntrs: %d\033[0m", arg->mutex, arg->job_id, ntrs);
  //basic_info(msg);

  int nwaitors = 0;
  int rc = pthread_mutex_trylock(&sync_mutex);
  /*
  if(rc == 0) basic_info("SUCCESS");
  else if(rc == EDEADLK) basic_info("EDEADLK");
  else if(rc == EBUSY) basic_info("EBUSY"); 
  else if(rc == EAGAIN) basic_info("EAGAIN");
  else  basic_info("OTHERS");
  */

	int n;
        char **keys = hashtableKeySet(waitHashtable, &n);
        qsort(keys, n, sizeof(char *), rjni_strcmp);
        for(int i=0; i<n; i++) {
          vector_t *queue = (vector_t *) hashtableGet(waitHashtable, keys[i]);
          //sprintf(msg, "name: %s, length: %d", keys[i], vectorSize(queue));
          //basic_info(msg);
          for(int j=0; j<vectorSize(queue); j++){
            sync_wait_t *sw = (sync_wait_t *) vectorElementAt(queue, j);
//            sprintf(msg, "%d. {host: %s, job_id: %d, tid: %d}", j+1, sw->sc->host, sw->job_id, sw->tid);
//            basic_info(msg);
	    if(sw->job_id == job_id) nwaitors++;
          }
        }
	free(keys);// check this for all other functions...
  if(rc == 0)
    pthread_mutex_unlock(&sync_mutex);

  //sprintf(msg, "\n\033[0;31mmutex: %s, job_id: %d, ntrs: %d, nwaitors: %d\033[0m", arg->mutex, arg->job_id, ntrs, nwaitors);
  //basic_info(msg);

  double timeout = nwaitors >= ntrs-1 ? (-1.0) : 0.0;

  return ScalarReal(timeout);
}

extern SEXP Rf_deparse1m(SEXP call, Rboolean abbrev, int);
#define DEFAULTDEPARSE          1089

// TODO
void cluster_wait_arg_preprocess(void *data){
  cluster_wait_arg_t *arg = (cluster_wait_arg_t *) data;
  SEXP raw = PROTECT(allocVector(RAWSXP, arg->nraw));
  fprintf(stderr, "%s:%d:%s arg->nraw: %ld\n", __FILE__, __LINE__, __func__,
                  arg->nraw);
  memcpy(RAW(raw), arg->raw, arg->nraw);
  SEXP call= PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
  SEXP expr = PROTECT(eval(call,  R_BaseEnv)); // FIXME for driver...

//  SEXP val = PROTECT(eval(call, Thread_R_SharedEnv));
//  supr_thread_t *cth = (supr_thread_t *)pthread_getspecific(currentThreadKey);
  {
    SEXP ex = PROTECT(Rf_deparse1m(expr, 0, DEFAULTDEPARSE));
    PrintValue(ex);
    UNPROTECT(1);

    SEXP argPtr = PROTECT(R_MakeExternalPtr(arg, R_NilValue, R_NilValue));
    defineVar(install("timeout.arg"), argPtr, SuprEnv);
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SEXP body = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("Cluster_timeout"), CONS(argPtr, R_NilValue))));
    SET_CLOENV(func, SuprEnv);
    SET_FORMALS(func, R_NilValue);
    SET_BODY(func, body);
    defineVar(install("timeout"), func, SuprEnv);
    PrintValue(func);
    UNPROTECT(3);

    cluster_timeout_ptr = Driver_timeout;
  }
  SEXP val = PROTECT(eval(expr, SuprEnv)); // FIXME for driver... JobEnv?

  arg->timeout = asReal(val);
  UNPROTECT(4);
  fprintf(stderr, "%s:%d:%s timeout: %g\n", __FILE__, __LINE__, __func__,
                  arg->timeout);
}

#define TESTING_WORKER_SC_TO

int handleWaitAndNotify(supr_socket_conn_t *conn, char *mutex, int cmd,
	       	int job_id, int tid, void *timeout_expr, ssize_t length)
#else
int handleWaitAndNotify(supr_socket_conn_t *conn, char *mutex, int cmd,
	       	int job_id, int tid, double timeout)
#endif
{
  
#ifdef TR_WAIT_USE_TIME_EXPR
  double timeout;
#endif

#ifdef TESTING_WORKER_SC_TO
  int use_to = FALSE;
if(conn->to) {
       	conn = conn->to; // TESTING
	use_to = TRUE;
}
#endif
  

  pthread_mutex_lock(&sync_mutex);

    printf("\033[0;32m/////[\n\n");
    printf("mutex: %s\n", mutex);
    if(!waitHashtable) waitHashtable = newHashtable(FALSE);

  /*
  vector_t *wait_queue = (vector_t *) hashtableGet(waitHashtable, mutex);

  if(!wait_queue){
    wait_queue = newVector(FALSE);
    hashtablePut(waitHashtable, mutex, wait_queue);
  }
  */
    vector_t *wait_queue = Driver_getWaitQueue(job_id, mutex);

    printf("sync_queue: %s\n", __func__, objectToString(wait_queue));
    sync_wait_t *sw;

    if(cmd == TR_CLUSTER_WAIT){
      printf("wait(mutex: %s)\n", mutex);


#ifdef TR_WAIT_USE_TIME_EXPR
      cluster_wait_arg_t wait_arg = {conn, mutex, job_id, tid, length,
	    				  timeout_expr, 0.0};
      int success;
      BEGIN_R_EVAL();
        success = R_ToplevelExec(cluster_wait_arg_preprocess, &wait_arg);
      END_R_EVAL();
      if(success) {
        timeout = wait_arg.timeout;
	/*
	{
		char msg[256];
		sprintf(msg, "timeout = %f", timeout);
		basic_info(msg);
	}
	*/
	if(timeout < 0) { // return immediately
            int cmd = TR_CLUSTER_WAIT_TIMEOUT_EXPR;
	    write(conn->fd, &cmd,     INT_SIZE);
            write(conn->fd, &job_id,  INT_SIZE);
	    write(conn->fd, &tid, INT_SIZE);
	    size_t len = strlen(mutex)+1;
	    write(conn->fd, &len, SIZE_SIZE);
	    write(conn->fd, mutex, len);

            int rc = 0;
            write(conn->fd, &rc, sizeof(int));
            write(conn->fd, &timeout, sizeof(double));

#ifdef TESTING_WORKER_SC_TO
	    if(use_to){
		    read(conn->fd, &rc, sizeof(int));
		if(rc != 0){
			error_info("rc != 0");
		}
	    }
#endif
          pthread_mutex_unlock(&sync_mutex);
          return rc;
	}
      }
      else {
          int cmd = TR_CLUSTER_WAIT_TIMEOUT_EXPR;
  basic_info(cmd2char(cmd));
	  write(conn->fd, &cmd,     INT_SIZE);
          write(conn->fd, &job_id,  INT_SIZE);
	  write(conn->fd, &tid, INT_SIZE);
	  size_t len = strlen(mutex)+1;
	  write(conn->fd, &len, SIZE_SIZE);
	  write(conn->fd, mutex, len);

          int rc = -1; // error message? use Sync_errno ?
          write(conn->fd, &rc, sizeof(int));

          const char *errbuf = R_curErrorBuf();
          if(strstr(errbuf, "Error: "))
            errbuf = strstr(errbuf, "Error: ") + strlen("Error: ");
          char err[strlen(errbuf)+256];
          sprintf(err, "failed to evaluate 'timeout', %s", errbuf);
          int n = strlen(err)+1;
          write(conn->fd, &n, sizeof(int));
          write(conn->fd, err, n);
#ifdef TESTING_WORKER_SC_TO
	    if(use_to){
		    read(conn->fd, &rc, sizeof(int));
		if(rc != 0){
			error_info("rc != 0");
		}
	    }
#endif
        pthread_mutex_unlock(&sync_mutex);
        return rc;
      }

  
#endif


    //vector_t *sync_queue = (vector_t *) hashtableGet(syncHashtable, mutex);
      vector_t *sync_queue = Driver_getSyncQueue(job_id, mutex);

      sw = (sync_wait_t *) vectorRemove(sync_queue, 0);
    //sw->cmd = TR_CLUSTER_NOTIFY;
      if(sw->job_id != job_id || sw->tid != tid || sw->sc != conn) {
        printf("\033[0;31m********* Warning: unsynchronized wait???\033[0m\n");
      }

      sw->job_id = job_id; // or used for checking ???
      sw->tid = tid;
      sw->cmd = TR_CLUSTER_WAIT_RETURN;

      if(timeout>0) {
        clock_gettime(CLOCK_REALTIME, &sw->wait);
        timeout += sw->wait.tv_sec + sw->wait.tv_nsec/((double)1000000000.0);
        long sec = (long) floor(timeout);
        long nsec = (long)((timeout-sec)*1000000000);
        sw->wait.tv_sec = sec;
        sw->wait.tv_nsec = nsec;

        vectorAdd(timedwait_queue, sw);

        printf("[%s] timedwait_queue: %s\n", __func__,
		      objectToString(timedwait_queue));
      
      // checking starts ...
      /*
        if(vectorSize(timedwait_queue)){

          sync_wait_t *sw = (sync_wait_t *) vectorElementAt(timedwait_queue,0);
	  //timedwait = &sw->wait;
	  printf("[%s] \tstruct timespec{%ld, %ld}\n", __func__,
			  sw->wait.tv_sec, sw->wait.tv_nsec);
	  {
            struct timespec wait;
            clock_gettime(CLOCK_REALTIME, &wait);
	    printf("\n[%s] \t[current time] struct timespec{%ld, %ld}\n\n",
			      __func__, wait.tv_sec, wait.tv_nsec);

	    for(int i=vectorSize(timedwait_queue)-1; i>=0; i--){
              sw = (sync_wait_t *) vectorElementAt(timedwait_queue, i);
	      struct timespec *timedwait = &sw->wait;
	      printf("[%s] \t[%d] struct timespec{%ld, %ld}\n", __func__, i,
			  sw->wait.tv_sec, sw->wait.tv_nsec);
	    }
	  }
	}
	*/
	//checking ends ...

     
        qsort(timedwait_queue->elements, vectorSize(timedwait_queue),
		      sizeof(void *), sync_wait_compare);

        printf("[%s] sorted timedwait_queue: %s\n", __func__,
		      objectToString(timedwait_queue));

        //{ checking starts ...
        if(vectorSize(timedwait_queue)){

          sync_wait_t *sw = (sync_wait_t *) vectorElementAt(timedwait_queue,0);
	  //timedwait = &sw->wait;
	  printf("[%s] \tstruct timespec{%ld, %ld}\n", __func__,
			  sw->wait.tv_sec, sw->wait.tv_nsec);
	  {
            struct timespec wait;
            clock_gettime(CLOCK_REALTIME, &wait);
	    printf("\n[%s] \t[current time] struct timespec{%ld, %ld}\n\n",
			      __func__, wait.tv_sec, wait.tv_nsec);

	    for(int i=vectorSize(timedwait_queue)-1; i>=0; i--){
              sw = (sync_wait_t *) vectorElementAt(timedwait_queue, i);
	      struct timespec *timedwait = &sw->wait;
	      printf("[%s] \t[%d] struct timespec{%ld, %ld}\n", __func__, i,
			  sw->wait.tv_sec, sw->wait.tv_nsec);
	    }
	  }
	}
        //} checking ends ...

        pthread_mutex_lock(&timedwait_thread->mutex);
          timedwait_thread->data = PTHREAD_NOTIFIED;
          pthread_cond_signal(&timedwait_thread->cond);
        pthread_mutex_unlock(&timedwait_thread->mutex);
      }

      vectorAdd(wait_queue, sw);

      if(vectorSize(sync_queue)){
    
        sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
        int fd = sw->sc->fd;
#ifdef TESTING_WORKER_SC_TO
if(sw->sc->to) fd = sw->sc->to->fd; // TESTING
#endif
        int retcmd = sw->cmd;
        write(fd, &retcmd, INT_SIZE); //if(cmd == TR_CLUSTER_TIMEOUT)
        write(fd, &sw->job_id, INT_SIZE);
        write(fd, &sw->tid,    INT_SIZE);
        size_t len = strlen(mutex)+1;
        write(fd, &len, SIZE_SIZE);
        write(fd, mutex, len);

	  //basic_info(cmd2char(retcmd));
#ifdef TESTING_WORKER_SC_TO
        if(sw->sc->to && (   retcmd == TR_CLUSTER_WAIT_RETURN
                           ||retcmd == TR_CLUSTER_SYNC_RETURN
                           ||retcmd == TR_CLUSTER_WAIT_TIMEOUT
			 ))
			{
	  //basic_info(sw->sc->to->host);
		int rc;
		read(fd, &rc, sizeof(int));
		if(rc != 0){
			error_info("rc != 0");
		} /*else {
			basic_info("rc = 0 !");
		}*/
	} else {
	  error_info("FIXME");
	  basic_info("sw->sc->to: %p, retcmd: %d\n"
	    "\t(TR_CLUSTER_WAIT_RETURN=%d, TR_CLUSTER_SYNC_RETURN=%d"
	    ", TR_CLUSTER_WAIT_TIMEOUT=%d)",
	    sw->sc->to, retcmd, TR_CLUSTER_WAIT_RETURN,
		    TR_CLUSTER_SYNC_RETURN, TR_CLUSTER_WAIT_TIMEOUT);
	}
#endif

        sw->cmd = TR_CLUSTER_SYNC_RETURN;
      }

    } else if(cmd == TR_CLUSTER_NOTIFY){
      printf("[%s] notify(mutex: %s)\n", __func__, mutex);
      char msg[1024];
      sprintf(msg,"\033[0;31m[%s] notify(mutex: %s), TR_CLUSTER_NOTIFY\033[0m", __func__, mutex);
      basic_info(msg);


      if(vectorSize(wait_queue)){

        sw = (sync_wait_t *) vectorRemove(wait_queue, 0);
      //vector_t *sync_queue = (vector_t *) hashtableGet(syncHashtable, mutex);
        vector_t *sync_queue = Driver_getSyncQueue(job_id, mutex);

        vectorAdd(sync_queue, sw);
	vectorRemoveElement(timedwait_queue, sw);

        if(vectorSize(sync_queue)==1){

          sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);


	  int fd = sw->sc->fd;
#ifdef TESTING_WORKER_SC_TO
if(sw->sc->to) fd = sw->sc->to->fd; // TESTING
#endif
          int retcmd = sw->cmd;
          printf("[%s] Send cmd: %d\n", __func__, cmd);
          write(fd, &retcmd, INT_SIZE); // if(cmd == TR_CLUSTER_TIMEOUT)
          write(fd, &sw->job_id, INT_SIZE);
          write(fd, &sw->tid,    INT_SIZE);
          size_t len = strlen(mutex)+1;
          write(fd, &len, SIZE_SIZE);
          write(fd, mutex, len);

	  basic_info(cmd2char(retcmd));
#ifdef TESTING_WORKER_SC_TO
        if(sw->sc->to && retcmd == TR_CLUSTER_WAIT_RETURN){
		int rc;
		read(fd, &rc, sizeof(int));
		if(rc != 0){
			error_info("rc != 0");
		}
	}
#endif

          sw->cmd = TR_CLUSTER_SYNC_RETURN;
        }
      }

      int rc = 0;
      write(conn->fd, &rc, INT_SIZE);


    } else if(cmd == TR_CLUSTER_NOTIFYALL){

      if(Supr_options.verbose){
        char msg[1024];
        sprintf(msg,"\033[0;31m[%s] notify(mutex: %s), TR_CLUSTER_NOTIFYALL\n"
		      "\tvectorSize(wait_queue): %d\033[0m", __func__, mutex,
		      vectorSize(wait_queue));
        verbose_info(msg);
      }

      if(vectorSize(wait_queue)){
      //vector_t *sync_queue = (vector_t *) hashtableGet(syncHashtable, mutex);
        vector_t *sync_queue = Driver_getSyncQueue(job_id, mutex);
        int notify = vectorSize(sync_queue) == 0;
        for(int i=vectorSize(wait_queue)-1; i>=0; i--){

          sw = (sync_wait_t *) vectorRemove(wait_queue, i);
	  vectorRemoveElement(timedwait_queue, sw);
          vectorAdd(sync_queue, sw);

        }

        if(notify){

          sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
          int fd = sw->sc->fd;
#ifdef TESTING_WORKER_SC_TO
if(sw->sc->to) fd = sw->sc->to->fd; // TESTING
#endif
          int cmd = sw->cmd;
          printf("[%s] Send cmd: %d\n", __func__, cmd);
          write(fd, &cmd, INT_SIZE); //if(cmd == TR_CLUSTER_TIMEOUT)
          write(fd, &sw->job_id, INT_SIZE);
          write(fd, &sw->tid,    INT_SIZE);
          size_t len = strlen(mutex)+1;
          write(fd, &len, SIZE_SIZE);
          write(fd, mutex, len);

	  basic_info(cmd2char(cmd));
#ifdef TESTING_WORKER_SC_TO
        if(sw->sc->to && cmd == TR_CLUSTER_WAIT_RETURN){
		int rc;
		read(fd, &rc, sizeof(int));
		if(rc != 0){
			error_info("rc != 0");
		}
	}
#endif

          sw->cmd = TR_CLUSTER_SYNC_RETURN;
        }
      }

      int rc = 0;
      write(conn->fd, &rc, INT_SIZE);

    } else { // no?
      printf("[%s:%d] sync = %d, TODO\n", __func__, __LINE__, cmd);
    }

    printf("]/////\n\033[0m");

  pthread_mutex_unlock(&sync_mutex);
  return 0;
}

//int handleWaitAndNotify(supr_socket_conn_t *conn, char *mutex, int cmd, int job_id, int tid, void *timeout_expr, ssize_t length)
void __handleWaitAndNotify__(void *data)
{
  supr_socket_conn_t *conn = ((supr_socket_conn_t **)data)[0];
  size_t offset = sizeof(supr_socket_conn_t*);
  int *hd = (int*)(data + offset);
  int cmd = hd[0];
  int job_id = hd[1];
  int tid = hd[2];
  int len = hd[3];
  offset += 4*sizeof(int);
  double timeout = ((double*)(data+offset))[0];
  offset += sizeof(double);
  char *mutex = (char*) (data + offset);
  offset += len;
  size_t size = ((size_t*)(data+offset))[0];
  offset += sizeof(size_t);
  void *timeout_expr = size>0 ? data + offset : NULL;

  int rc = handleWaitAndNotify(conn, mutex, cmd, job_id, tid, timeout_expr,
		  size);

  free(data);
}

void clusterMallocPrint()
{
  int args[] = {CLUSTER_MALLOC_PRINT};
  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    if(sc->type == WORKER_CONN) {
      write(sc->fd, args, sizeof(args));
      // message:
      //fprintf(stderr, "[%s:CLUSTER_MALLOC_PRINT] WORKER: %s:%d\n", __func__, sc->host, sc->port);
    }
  }

}

/*
void removeJob(job_t *job)
{
  if(!job) return;
  int args[] = {CLUSTER_JOB_REMOVE, job->id};
  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    if(sc->type == WORKER_CONN) {
      write(sc->fd, args, sizeof(args));
      // message:
      fprintf(stderr, "[%s:CLUSTER_JOB_REMOVE(%d)] WORKER: %s:%d\n",
				  __func__, job->id, sc->host, sc->port);
    }
  }

  // free: MORE TODO...
  //Supr_decref(job);
  free(job->expr);
  if(FALSE){
  Supr_decref(job->tasks);
  Supr_decref(job->result);
  Supr_decref(job->taskrunners);
  Supr_decref(job->executors);
  pthread_mutex_destroy(&job->mutex);
  pthread_cond_destroy(&job->cond);
  free(job->combine_result); // ???
  }
  // Supr_decref(job->cbk);
  // Supr_decref(job->environment);
  // Supr_decref(job->attachment);
  // Supr_decref(job->dcl);
}
*/
static void Job_statusNotify(job_t *job, int state)
{
   if(!info_sc) return; // introduce and use job->user_sc?

   int job_id = job->id;
   const char *str_state = NULL;
   char buf[256];
   switch(state){
     case JOB_STATE_CANCELLED: str_state = "cancelled";
          break;
     case JOB_STATE_FINISHED: str_state = "finished";
          break;
     case JOB_STATE_TASKS_ASSIGNED:
          str_state = "assigned";
	  if(job->state >= JOB_STATE_TASKS_ASSIGNED)
	    return;
	  else 
	    job->state = JOB_STATE_TASKS_ASSIGNED;
          break;
     default:
          sprintf(buf, "unknown state: %d", state);
          str_state = buf;
          break;
   }
   int ntrs = job->taskrunners ? vectorSize(job->taskrunners): 0;

   so_t *so = NULL;

   BEGIN_R_EVAL();
     SEXP msg   = PROTECT(allocVector(VECSXP, 3));
     SEXP names = PROTECT(allocVector(STRSXP, 3));
     setAttrib(msg, R_NamesSymbol, names);
     setAttrib(msg, R_ClassSymbol, mkString("JobStatus"));
     SET_STRING_ELT(names, 0, mkChar("job"));
     SET_STRING_ELT(names, 1, mkChar("state"));
     SET_STRING_ELT(names, 2, mkChar("ntrs"));
     SET_VECTOR_ELT(msg, 0, ScalarInteger(job_id));
     SET_VECTOR_ELT(msg, 1, mkString(str_state));
     SET_VECTOR_ELT(msg, 2, ScalarInteger(ntrs));
     size_t len;
     so = SO_valueOf(msg, &len);
   END_R_EVAL();

   char *addr = "user";
   int len_addr = strlen(addr)+1;
   int len_raw  = (int) so->size;
   int hd[]={CLUSTER_MSG_SEND, len_addr, len_raw}; // an empty message , FIXME
   pthread_mutex_lock(info_sc->mutex);
      int fd = info_sc->fd;
      write(fd, hd, sizeof(hd));
      write(fd, addr, len_addr);
      write(fd, so+1, so->size);
      int rc;
      read(fd, &rc, sizeof(int));
   pthread_mutex_unlock(info_sc->mutex);

   free(so);
}

int handleByteMessage(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int h[2];
  ssize_t size = read(fd, h, 2*sizeof(int)); 

  /*
	   if(size != sizeof(h)) {
		   //sync...
             sprintf(Supr_curErrorBuf, "Error in read, %s", strerror(errno));
	     error_info(Supr_curErrorBuf); 
	     sleep(5);
	   }
	   */
  //printf("[%s] cmd = %d: BYTE_MSG\n", __func__, h[0]);

  int cmd = h[1];
  switch(cmd){
    case CLUSTER_TASKRUNNER_REGISTER: // send one subset along with tr_id? YES
	 {
	   int tr_id = -1;

	   int hd[2];
           size = read(fd, hd, sizeof(hd)); 
	   if(size != sizeof(hd)) {
		   //sync...
             sprintf(Supr_curErrorBuf, "Error in read, %s", strerror(errno));
	     error_info(Supr_curErrorBuf); 
	     write(fd, &tr_id, sizeof(int)); // -1: error
	     sleep(5);
	     return -1;
	   }
	   int job_id = hd[0], len = hd[1];
	   //{
		   conn->type = JOB_CONN;
		   conn->tid  = job_id; // FIXME?
	   //}

           //size = read(fd, &len, sizeof(int)); 
	   char tr_addr[len];
           size = read(fd, tr_addr, len);
	   
	   if(size != len) {
		   //sync...
             sprintf(Supr_curErrorBuf, "Error in read, %s", strerror(errno));
	     error_info(Supr_curErrorBuf); 
	     write(fd, &tr_id, sizeof(int)); // -1: error
	     sleep(5);
	     return -1;
	   } else if(strstr(tr_addr, ":")==NULL || strstr(tr_addr, "#")==NULL){
             sprintf(Supr_curErrorBuf, "Error in tr_add@%s, \"%s\", len: %d",
			    conn->host, tr_addr, len);
	     error_info(Supr_curErrorBuf); 
	     write(fd, &tr_id, sizeof(int)); // -1: error
	     sleep(5);
	     return -1;
	   } else if (Supr_options.verbose) {
	     verbose_info(tr_addr);
	   }

           job_t *job = findJob(job_id);

	   if(!job) {
             driver_warning("\033[0;34m[%s] no such a job\033[0m\n", __func__);
	     write(fd, &tr_id, sizeof(int));
             return 0;
	   }

	   pthread_mutex_lock(&job->mutex); 
	   if(job->result)
	   {
	     write(fd, &tr_id, sizeof(int));
	     pthread_mutex_unlock(&job->mutex); 
	     JOB_DECREF(job);
	     return 0; // never occurs ? FIXME
	   }

	   iterator_t *iter = job->tasks;
	   if(!iter->hasNext(iter->data)) { // No (more) tasks
	     write(fd, &tr_id, sizeof(int)); 
	     pthread_mutex_unlock(&job->mutex); 
	     JOB_DECREF(job);
             return 0;
	   }

	   so_t *task; // = (so_t *) iter->next(iter->data);
	   if(iter->next2){
	       task = (so_t *) iter->next2(iter->data, (void*) conn->host);
	   } else {
	       task = (so_t *) iter->next(iter->data);
	   }

	   if(!job->taskrunners){
             driver_warning("[BUGS] job->taskrunners = %p, send tr_id: %d\n",
			     job->taskrunners, tr_id);
	     write(fd, &tr_id, sizeof(int));
	     pthread_mutex_unlock(&job->mutex); 
	     JOB_DECREF(job);
             return 0;
	   }

	   tr_id = vectorSize(job->taskrunners);

	   write(fd, &tr_id, sizeof(int));
	   write(fd, task, sizeof(so_t)+task->size);

	   free(task); // FIXME?

	   vectorAdd(job->taskrunners, strdup(tr_addr));
	   job->count++;
	   char *str = strstr(tr_addr, "#");
	   *str = 0;
	   str = strdup(tr_addr);
	   if(!vectorAddIfNotExists(job->executors, str, wrapped_strcmp))
		   free(str);
	   
	   pthread_mutex_unlock(&job->mutex); 
	   JOB_DECREF(job);
	 } 
         return 0;
	 //break;
    case TR_NEXT_SUBSET:
	 {
	   int job_id, tr_id;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 

	   job_t *job = findJob(job_id);

	   if(job ){
             if(job->result == JOB_CANCELLED) {
	       so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0}; // return ERROR???
	       write(fd, &so, sizeof(so_t));
	       error_info("TR_NEXT_SUBSET: JOB_CANCELLED/SUPR_UNBOUND_VALUE");
	       JOB_DECREF(job);
	       return 0;
	     }
	   
	     iterator_t *iter = job->tasks;
	     if(iter->hasNext(iter->data)) {
	       so_t *task;
	       if(iter->next2){
	         task = (so_t *) iter->next2(iter->data, (void*) conn->host);
	       } else {
	         task = (so_t *) iter->next(iter->data);
	       }
	       write(fd, task, sizeof(so_t)+task->size);
	       //basic_info("TR_NEXT_SUBSET: Sent");
	       free(task); // FIXME?
	     } else {
//               driver_warning("\033[0;34m[%s] No tasks\033[0m\n", __func__);
	       so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	       write(fd, &so, sizeof(so_t));
	       //basic_info("TR_NEXT_SUBSET: no subset/SUPR_UNBOUND_VALUE");
	       pthread_mutex_lock(&job->mutex);
	         Job_statusNotify(job, JOB_STATE_TASKS_ASSIGNED);
	       pthread_mutex_unlock(&job->mutex);
	     }
	     JOB_DECREF(job);
	   } else {
		   /*
	     so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0}; // return ERROR???
	     write(fd, &so, sizeof(so_t));
	     */
	     /*
	       so_t so = {0,0,0,SUPR_ERRNO, NO_SUCH_A_JOB};
	       write(fd, &so, sizeof(so_t));
	      */
	     char err[256];
	     sprintf(err, "Error in TR_NEXT_SUBSET, cannot find job %d",job_id);
	     so_t so = {0,0,0,SUPR_ERROR,strlen(err)+1};
	     write(fd, &so, sizeof(so_t));
	     write(fd, err, so.size);
	     error_info(err);
	   }
	 }
	 return 0;

    case TASK_RESULTS:
	 {
	   int job_id, tr_id, ret_type;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 
           read(fd, &ret_type, sizeof(int)); // ignored -> return status?


	   /* if(ret_type == TR_TASK_STATUS_FAILURE || ret_type == TR_TASK_STATUS_CANCELLED)
	   {
	     char buf[256];
	     sprintf(buf, "[TASK: %d-%d] node: //%s:%d (%s), ret_type: %d",
			     job_id, tr_id,
			     conn->host, conn->port,
			     conn->type == WORKER_CONN?  "WORKER":"TR",
			     ret_type
			     );
	     //UserInfo_send(0, 0, buf);
	     // job.error.handler?
	     //basic_info(buf);
	     error_info(buf);
	   }
	   */

	   so_t so;
           read(fd, &so, sizeof(so_t)); // ignored
	   /*
	   {
		   char msg[256];
		   sprintf(msg, "{%d, %d, %d, %d (SUPR_JOB_CANCELLED=%d), %ld}",
				   so.ref_count,
				   so.mem_type,
				   so.sys_type,
				   so.obj_type, SUPR_JOB_CANCELLED,
				   so.size
				   ); 
		   basic_info(msg);
	   }
	   */
	   so_t *s = (so_t *)malloc(sizeof(so_t)+so.size);
	   memcpy(s, &so, sizeof(so_t));
	   if(so.size>0)
             read(fd, s+1, so.size);

	   int rc = 0;
	   //write(fd, &rc, sizeof(int));
	   so_t ret = {0,0,0,rc,0};
	   write(fd, &ret, sizeof(so_t));

	   /*
	   {
		   char msg[256];
		   sprintf(msg, "{%d, %d, %d, %d (SUPR_JOB_CANCELLED=%d), %ld}",
				   s->ref_count,
				   s->mem_type,
				   s->sys_type,
				   s->obj_type, SUPR_JOB_CANCELLED,
				   s->size
				   ); 
		   basic_info(msg);
	   }
	   */
	   
	   //if(ret_type == TR_TASK_STATUS_CANCELLED){ }

	   
	   if(ret_type == TR_TASK_STATUS_FAILURE ||
              ret_type == TR_TASK_STATUS_CANCELLED ){
	   
	     /*
	     if(s->obj_type == SUPR_JOB_CANCELLED){
	         error_info("SUPR_JOB_CANCELLED");
	     } else {
               BEGIN_R_EVAL();
	         SEXP val = PROTECT(R_bytesToObject(s+1, s->size));
	         PrintValue(val);

	       //
	       SEXP str_err;
	      
	       str_err = VECTOR_ELT(val, 2); // taskrunner name
	       const char *err = CHAR(STRING_ELT(str_err, 0));
	       //UserInfo_send(0, 0, err);
	       //basic_info(err);

	       str_err = VECTOR_ELT(val, 0); // R_curErrorBuf()
	       err = CHAR(STRING_ELT(str_err, 0));
	       //UserInfo_send(0, 0, err);
	       //error_info(err);
	       sprintf(Supr_curErrorBuf, "[job: %d, tr: %d] %s",
			       job_id, tr_id, err);
	       //error_info(Supr_curErrorBuf);
	       //
	         error_info(type2char(TYPEOF(val)));
	         UNPROTECT(1);

               END_R_EVAL();
	     }
	     */


	     // cancel the job?
	   
	     job_t *job = findJob(job_id);
	     if(!job) return -1;
	     pthread_mutex_lock(&job->mutex);
	       if(job->state != JOB_STATE_CANCELLED){

		       /* Make main do this...
			
	         int count = 0;
		 int buf[] = {TR_CLUSTER_INTERRUPT, job_id};
		 for(int i=vectorSize(socket_connections)-1; i >= 0; i--){
                   supr_socket_conn_t *sc = (supr_socket_conn_t *)
                        vectorElementAt(socket_connections, i);
                   if(sc->type == WORKER_CONN && sc->to){
                     write(sc->to->fd, buf, sizeof(buf));
		     int rc;
		     read(sc->to->fd, &rc, INT_SIZE); //
		     count += 1 - rc;
		     {
		       char msg[256];
		       sprintf(msg, "[TR_CLUSTER_INTERRUPT/CANCELL] job_id: %d, rc: %d",
                                 job_id, rc);
		       basic_info(msg);
		     }
		   } 
		 } 

		 task->fun = __handleErrorResult__;
		 */

                 main_thread_task_t *task = malloc(sizeof(main_thread_task_t));
		 task->fun = __handleErrorResult__;
                 task->data = job;
		 pthread_mutex_lock(main_thread_tasks->mutex);
                   vectorAdd(main_thread_tasks, task);
                 pthread_mutex_unlock(main_thread_tasks->mutex);

                 pthread_mutex_lock(&main_thread->mutex);
                   pthread_cond_signal(&main_thread->cond);
                 pthread_mutex_unlock(&main_thread->mutex);

	         job->state = JOB_STATE_CANCELLED;

	         Job_statusNotify(job, JOB_STATE_CANCELLED);
	       }
	     //  Supr_decref(job);
	     pthread_mutex_unlock(&job->mutex);
             JOB_DECREF(job);
	     //addDCLEvent(job, "", NULL);
	     //return -1;
	   }
	   


	   job_t *job = findJob(job_id);
	   if(!job) return -1;

//	   printf("taskrunners: %s\n", objectToString(job->taskrunners));
//
	   void *tr_addr = vectorSet(job->taskrunners, tr_id, s);

	   /*
	   if(ret_type == TR_TASK_STATUS_FAILURE ||
	      ret_type == TR_TASK_STATUS_CANCELLED
			   ){
	     char buf[256];
	     sprintf(buf, "[TASK: %d-%d, tr: %s], status: %s, count: %d/%d",
			     job_id, tr_id, (char*)tr_addr,
			     ret_type == TR_TASK_STATUS_FAILURE?"FAILURE"
			     :"\033[0;31mCANCELLED\033[0m", job->count,
			     vectorSize(job->taskrunners));
	     //UserInfo_send(0, 0, buf);
	     // job.error.handler?
	     //basic_info(buf);
	     error_info(buf);
	   } */

	   pthread_mutex_lock(&job->mutex);
	   basic_info("job %d status: %d / %d", job_id, job->count-1,
			     vectorSize(job->taskrunners)); 

//	   printf("[%s] free(%s)\n", __func__, (char*)tr_addr);
	   free(tr_addr);
	   job->count--;
	   if(job->count==0) {

	     if(job->state == JOB_STATE_CANCELLED)
	       cancelJob_cleanup_monitors(job);

	     if(job->tasks->hasNext(job->tasks->data)){
                 error_info("job->count==0 && job->tasks->hasNext()");
		 // invoke an error.handler?
		   //free(ob->tasks);
	     } //else
	     //{
	       //int rc = pthread_mutex_trylock(&job->mutex);
	       //if(rc == 0){

                 job->result = job->taskrunners;
                 job->taskrunners = NULL;

	         pthread_cond_broadcast(&job->cond);
	         //pthread_mutex_unlock(&job->mutex);
	       //} else { basic_info("rc != 0, FIXME..."); 
                 //job->result = job->taskrunners;
                 //job->taskrunners = NULL;
	         //rc = pthread_cond_broadcast(&job->cond);

	       
	       //} //addDCLEvent(job, "", NULL); //if(job->dcl)

	       addDCLEvent(job, "", NULL);
	     //}

	     // info user if info_sc?
	       /*
	     if(info_sc){
	       int hd[]={CLUSTER_MSG_SEND, 0, 0}; // an empty message , FIXME
               pthread_mutex_lock(info_sc->mutex);
                   write(info_sc->fd, hd, sizeof(hd));
                   int rc;
                   read(info_sc->fd, &rc, sizeof(int));
               pthread_mutex_unlock(info_sc->mutex);
             }
	     */
	     //pthread_mutex_lock(&job->mutex);
	     //Job_statusNotify(job, JOB_STATE_TASKS_ASSIGNED);
	     //Job_statusNotify(job, JOB_STATE_CANCELLED);
	     Job_statusNotify(job, JOB_STATE_FINISHED);
	     //pthread_mutex_unlock(&job->mutex);
	     // inform wrokers ...

	   }
//	   Supr_decref(job);
	   pthread_mutex_unlock(&job->mutex);
           JOB_DECREF(job);
	   
	 }
         return 0;
	 
    case TR_COMBINE:
	 {
	   int job_id, tr_id, id_no, len;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 
           read(fd, &id_no, sizeof(int)); 
//	   printf("[%s] TR_COMBINE: job_id=%d, tr_id=%d, id_no=%d\n", __func__, job_id, tr_id, id_no);
           read(fd, &len, sizeof(int)); 
	   char shm_name[len];
           read(fd, shm_name, len); 
//	   printf("[%s] TR_COMBINE: strlen=%d, shm_name: %s\n", __func__, len, shm_name);
	   combine(conn, job_id, tr_id, id_no, shm_name);
	   
	 }
         return 0;
	 
    case TR_COMBINE_BYKEY_INIT:
	 combine_bykey_init(conn);
	 return 0;

    case TR_COMBINE_BYKEY:
	 combine_bykey(conn);
	 return 0;

    case TR_CLUSTER_NOTIFY:
    case TR_CLUSTER_NOTIFYALL:
	 {
           int job_id, tid;
           size = read(fd, &job_id, INT_SIZE);
           size = read(fd, &tid,    INT_SIZE);

           size_t len;
           size = read(fd, &len, SIZE_SIZE);

//           printf("\033[0;31m(%s) mutex.length: %ld\n", cmd == TR_CLUSTER_NOTIFY?  "TR_CLUSTER_NOTIFY": "TR_CLUSTER_NOTIFYALL", len);
           char buf[len];
           size = read(fd, buf, len);
//           printf("\033[0;31mmutex: %s\n",buf);
#ifdef TR_WAIT_USE_TIME_EXPR
           //handleWaitAndNotify(conn, buf, cmd, job_id, tid, NULL, 0);
	   //{
	     size_t offset = sizeof(supr_socket_conn_t*) + 4*sizeof(int)+
		     sizeof(double);

	     size = 0;
	     void *ptr = malloc(offset + len + sizeof(size_t) + size);
	     ((supr_socket_conn_t**)ptr)[0] = conn;
	     int *hd = (int*)(ptr + sizeof(supr_socket_conn_t*));
	     hd[0] = cmd; 
	     hd[1] = job_id;
	     hd[2] = tid;
	     hd[3] = (int) len;
	     ((double*)(ptr + sizeof(supr_socket_conn_t*)+4*sizeof(int)))[0] =
		     0.0; // not used
	     memcpy(ptr+offset, buf, len);
	     memcpy(ptr+offset+len, &size, sizeof(size_t));
	   //}
	   //{
	     main_thread_task_t *task = malloc(sizeof(main_thread_task_t));
	     task->fun = __handleWaitAndNotify__;
	     task->data = ptr;
	     pthread_mutex_lock(main_thread_tasks->mutex);
	       vectorAdd(main_thread_tasks, task);
	     pthread_mutex_unlock(main_thread_tasks->mutex);

	     pthread_mutex_lock(&main_thread->mutex);
	       pthread_cond_signal(&main_thread->cond);
	     pthread_mutex_unlock(&main_thread->mutex);
	   //}
          

#else
	   error_info("Deprecated");
           handleWaitAndNotify(conn, buf, cmd, job_id, tid, 0);
#endif
	 }
	 return 0;

    case TR_PUT_PAR:
	 {
	   //basic_info("cmd: TR_PUT_PAR");
//MALLOC_MARK(__LINE__);
	   int job_id, tr_id, len;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 
           read(fd, &len, sizeof(int)); 

	   char var_name[len];
           read(fd, &var_name, len);
//	   printf("[PUT_PAR:%d] var_name: %s\n", __LINE__, var_name);
	   fprintf(stderr, "[PUT_PAR:%d] var_name: %s\n", __LINE__, var_name);

	   so_t so; // = {0,0,0,SUPR_UNBOUND_VALUE,0};
	   read(fd, &so, sizeof(so_t));
	   so_t *value = (so_t *) malloc(sizeof(so_t)+so.size);
	   read(fd, value + 1, so.size);
	   memcpy(value, &so, sizeof(so_t));

	   //if(job_id == -1)
	   if(job_id < 0)
	   {
	     pthread_mutex_lock(globalEnvironment->mutex);
	       so_t *s = hashtableGet(globalEnvironment, var_name);
	       SO_decref(s);
	       hashtablePut(globalEnvironment, strdup(var_name), value);
	     pthread_mutex_unlock(globalEnvironment->mutex);

	     so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0}; // FIXME
	     write(fd, &so, sizeof(so_t));
	     return -1;
	     /*
	     int rc = 0;
	     write(fd, &rc, INT_SIZE);
//MALLOC_MARK(__LINE__);
	     return 0;
	     */
	   }

	   job_t *job = findJob(job_id);

	   if(!job) {
		   /*
             sprintf(Supr_curErrorBuf, "cannot find job %d", job_id);
             error_info(Supr_curErrorBuf);
	     so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0}; // FIXME
	     write(fd, &so, sizeof(so_t));
	     return -1;
	     */

	     char msg[256];
	     sprintf(msg, "job %d not found", job_id);
	     error_info(msg);
	     char *err = msg;
	     so_t so = {0, 0, 0, SUPR_ERROR, strlen(err)+1};
	     write(conn->fd, &so, sizeof(so_t));
	     write(conn->fd, err, strlen(err)+1);
	     return -1;

	   }

	   // message:
	   //fprintf(stderr, "[PUT_PAR:%d] job->environment->free_data: %p\n", __LINE__, job->environment->free_data);
	   //fprintf(stderr, "[PUT_PAR:%d] job->dcl: %p\n", __LINE__, job->dcl);

	   pthread_mutex_lock(&job->mutex);
	   so_t *s = (so_t*) hashtableGet(job->environment, var_name);
//	   hashtablePut(job->environment, strdup(var_name), value);
	   hashtablePut(job->environment, strdup(var_name), value);

	   //driver_addEvent(job, cmd, job_id, tr_id, conn);
//           addDCLEvent(job, var_name, value);

	   if(s) {
	     write(fd, s, sizeof(so_t)+s->size);
	     //{ // FIXME?
	     //	free(s);
	     //}
	     //if(! job->dcl || job->dcl->sync )
	     //	free(s);
	     SO_decref(s);

	   } else {
	     so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	     write(fd, &so, sizeof(so_t));
	   }
//	   Supr_decref(job);
	   pthread_mutex_unlock(&job->mutex);
    JOB_DECREF(job);
//MALLOC_MARK(__LINE__);
	 }
	 return 0;

    case TR_REMOVE_PAR:
	 {
	   int job_id, tr_id, len;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 
           read(fd, &len, sizeof(int)); 

	   char var_name[len];
           read(fd, &var_name, len);

	   so_t *s = NULL;
	   //int do_free = FALSE;
	   int rc = 0;

	   if(job_id < 0)
	   {
	     pthread_mutex_lock(globalEnvironment->mutex);
	       //s = (so_t*) hashtableGet(globalEnvironment, var_name);
	       //so_t *s = hashtableGet(globalEnvironment, var_name);
	       //free(s);
	       rc = hashtableDelete(globalEnvironment, var_name);
	     pthread_mutex_unlock(globalEnvironment->mutex);
	   } else {
	     job_t *job = findJob(job_id);
	     if(job){
	       pthread_mutex_lock(&job->mutex);
	         //s = (so_t*) hashtableGet(job->environment, var_name);
	         rc = hashtableDelete(job->environment, var_name);
	       pthread_mutex_unlock(&job->mutex);
               JOB_DECREF(job);
	     } 
	   }

	 
	   so_t so = {0, 0, 0, SUPR_INT_ARRAY, 2*sizeof(int)};
	   char buf[sizeof(so_t)+so.size];
           memcpy(buf, &so, sizeof(so_t));
           int *x = (int*)(buf + sizeof(so_t));
           x[0] = 1;
           x[1] = rc == 0;
           write(fd, buf, sizeof(buf));
	 }
	 return 0;

    case TR_EXIST_PAR:
	 {
	   int job_id, tr_id, len;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 
           read(fd, &len, sizeof(int)); 

	   char var_name[len];
           read(fd, &var_name, len);

	   so_t *s = NULL;

	   if(job_id < 0)
	   {
	     pthread_mutex_lock(globalEnvironment->mutex);
	       s = (so_t*) hashtableGet(globalEnvironment, var_name);
	     pthread_mutex_unlock(globalEnvironment->mutex);
	   } else {
	     job_t *job = findJob(job_id);
	     if(job){
	       pthread_mutex_lock(&job->mutex);
	         s = (so_t*) hashtableGet(job->environment, var_name);
	      pthread_mutex_unlock(&job->mutex);
              JOB_DECREF(job);
	     } 
	   }

	   so_t so = {0, 0, 0, SUPR_INT_ARRAY, 2*sizeof(int)};
	   char buf[sizeof(so_t)+so.size];
           memcpy(buf, &so, sizeof(so_t));
           int *x = (int*)(buf + sizeof(so_t));
           x[0] = 1;
           x[1] = s != NULL;
           write(fd, buf, sizeof(buf));
	 }
	 return 0;

    case TR_LIST_PAR:
	 {
	   int job_id, tr_id, len;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 

	   so_t *s = NULL;
	   int do_free = FALSE;
	   char msg[256];
	   //if(job_id == -1)
	   if(job_id < 0)
	   {
	     pthread_mutex_lock(globalEnvironment->mutex);
	      
		 int nkeys;
		 char **keys = hashtableKeySet(globalEnvironment, &nkeys);
		 qsort(keys, nkeys, sizeof(char *), rjni_strcmp);

		 BEGIN_R_EVAL();
		   SEXP val = PROTECT(allocVector(STRSXP, nkeys));
		   for(int i=0; i<nkeys; i++){
                     SET_STRING_ELT(val, i, mkChar(keys[i]));
		   }
		   size_t size;
                   s = (so_t*)SO_valueOf(val, &size);
		   do_free = TRUE;
		   UNPROTECT(1);
		 END_R_EVAL();
		 free(keys);
	       
	     pthread_mutex_unlock(globalEnvironment->mutex);
	   } else {
	     job_t *job = findJob(job_id);
	     if(job){
	       pthread_mutex_lock(&job->mutex);
	   
		 int nkeys;
		 char **keys = hashtableKeySet(job->environment, &nkeys);
		 qsort(keys, nkeys, sizeof(char *), rjni_strcmp);

		 BEGIN_R_EVAL();
		   SEXP val = PROTECT(allocVector(STRSXP, nkeys));
		   for(int i=0; i<nkeys; i++){
                     SET_STRING_ELT(val, i, mkChar(keys[i]));
		   }
		   size_t size;
                   s = (so_t*)SO_valueOf(val, &size);
		   do_free = TRUE;
		   UNPROTECT(1);
		 END_R_EVAL();
		 free(keys);

	      pthread_mutex_unlock(&job->mutex);
              JOB_DECREF(job);
	     } else 
	       sprintf(msg, "job %d not found", job_id);
	   }

	   if(s) {
	     write(fd, s, sizeof(so_t)+s->size);
	   } else {
	     //so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	     //write(fd, &so, sizeof(so_t));
	     error_info(msg);
	     char *err = msg;
	     so_t so = {0, 0, 0, SUPR_ERROR, strlen(err)+1};
	     write(conn->fd, &so, sizeof(so_t));
	     write(conn->fd, err, strlen(err)+1);
	     return -1;
	   }

	   if(do_free) free(s);
	 }
	 return 0;

    case TR_GET_PAR:
	 {
	   int job_id, tr_id, len;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 
           read(fd, &len, sizeof(int)); 

	   char var_name[len];
           read(fd, &var_name, len);

//	   basic_info("cmd: TR_GET_PAR, var: %s", var_name);
//	   printf("[GET_PAR:%d] var_name: %s\n", __LINE__, var_name);

	   /*
	   so_t so; // = {0,0,0,SUPR_UNBOUND_VALUE,0};
	   read(fd, &so, sizeof(so_t));
	   so_t *value = (so_t *) malloc(sizeof(so_t)+so.size);
	   read(fd, value + 1, so.size);
	   memcpy(value, &so, sizeof(so_t));
	   */

	   /*
	   job_t *job = getJob(job_id);
	   so_t *s = (so_t*) hashtableGet(job->environment, var_name);
	   */

	   so_t *s = NULL;
	   //int do_free = FALSE;

	   //if(job_id == -1)
	   if(job_id < 0)
	   {
	     pthread_mutex_lock(globalEnvironment->mutex);
	       s = (so_t*) hashtableGet(globalEnvironment, var_name);
	       if(s) {
		       /*
                 if(s->obj_type == SUPR_REFERENCE) {
		   object_t *obj = (object_t*)((void**)(s+1))[0];
		   const char *str = obj->class->toString(obj->class, obj);
                   so_t *so = malloc(sizeof(so_t)+strlen(str)+1);
		   memcpy(so, s, sizeof(so_t));
		   memcpy(so+1, str, strlen(str)+1);
		   s = so;
		   do_free = TRUE;
		 }
		 */
	         write(fd, s, sizeof(so_t)+s->size);
	       } else {
		//       sprintf(msg, "object '%s' not found", var_name);
	         so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	         write(fd, &so, sizeof(so_t));
	       }
	     pthread_mutex_unlock(globalEnvironment->mutex);
	   } else {
	     job_t *job = findJob(job_id);
	     if(job){
	       pthread_mutex_lock(&job->mutex);
	         s = (so_t*) hashtableGet(job->environment, var_name);
		 if(s){
	           write(fd, s, sizeof(so_t)+s->size);
		 } else {
	           so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	           write(fd, &so, sizeof(so_t));
		 }
	      pthread_mutex_unlock(&job->mutex);
              JOB_DECREF(job);
	     } else { 
	       char msg[256];
	       sprintf(msg, "job %d not found", job_id);
	       error_info(msg);
	       char *err = msg;
	       so_t so = {0, 0, 0, SUPR_ERROR, strlen(err)+1};
	       write(conn->fd, &so, sizeof(so_t));
	       write(conn->fd, err, strlen(err)+1);
	     }
	   }

	   /*
	   if(s) {
	     //basic_info("cmd: TR_GET_PAR, var: %s, ret: %p", var_name, s);
	     write(fd, s, sizeof(so_t)+s->size);
	   } else {
	     //basic_info("cmd: TR_GET_PAR, var: %s, ret: %p", var_name, s);
	     //so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	     //write(fd, &so, sizeof(so_t));
	     error_info(msg);
	     char *err = msg;
	     so_t so = {0, 0, 0, SUPR_ERROR, strlen(err)+1};
	     write(conn->fd, &so, sizeof(so_t));
	     write(conn->fd, err, strlen(err)+1);
	     return -1;
	   }

	   if(do_free) free(s);
	   */
	 }
	 return 0;

    case CLUSTER_MALLOC_PRINT: // CLUSTER_JOB_REMOVE
	 {
	   int job_id; // not used ...
           read(fd, &job_id, INT_SIZE);

	   clusterMallocPrint();

	   fprintf(stderr, "\033[0;32m");
           MALLOC_PRINT;
	   fprintf(stderr, "\033[0m");
	   //{// TODO
	     so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	     write(fd, &so, sizeof(so_t));
	   //}
	 }
	 return 0;

	 /*
    case CLUSTER_JOB_REMOVE:
	 {
	   int job_id;
           read(fd, &job_id, INT_SIZE);

	   //message:
	   fprintf(stderr, "[%s] job_id: %d\n", __func__, job_id);
	   pthread_mutex_lock(jobs->mutex);

	     int njobs = vectorSize(jobs);
             //for(int i=0; i< njobs; i++)
             for(int i = njobs-1; i >= 0; i--)
	     {
                job_t *job = (job_t *) vectorElementAt(jobs, i);
	        if(job_id == -1 || job->id == job_id){
		  //message:
	          fprintf(stderr, "[%s:CLUSTER_JOB_REMOVE] job_id: %d\n",
				  __func__, job->id);
		  fflush(stderr);
                  vectorRemove(jobs, i);
	          removeJob(job);
		  if(job_id != -1)
		    break;
	        }
	     }
	   pthread_mutex_unlock(jobs->mutex);

	   //{// TODO
	     so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	     write(fd, &so, sizeof(so_t));
	   //}
	 }
	 return 0;
	 */

    case CLUSTER_JOB_INFO:
	 {
	   int job_id;
           read(fd, &job_id, INT_SIZE);
	   
	   so_t *s = NULL;
		   // lock ??
	   int njobs = vectorSize(jobs);

	   if(njobs == 0){
		   // TODO?
	   } else if(job_id == -1){
		   // lock ??
	     //int njobs = vectorSize(jobs);
	     BEGIN_R_EVAL();
	       SEXP row_names = PROTECT(allocVector(INTSXP,njobs));

	       int ncol = 0;
	       SEXP id = PROTECT(allocVector(INTSXP,njobs));     ncol++;
	       SEXP status = PROTECT(allocVector(STRSXP,njobs)); ncol++;

	       SEXP retval = PROTECT(allocVector(VECSXP,ncol));
	       SEXP names = PROTECT(allocVector(STRSXP,ncol));

               for(int i=0; i< njobs; i++){
                 job_t *job = (job_t *) vectorElementAt(jobs, i);

		 INTEGER(row_names)[i] = i+1;
		 INTEGER(id)[i] = job->id;
		 char *st = job->result ? "finished" : "----"; 
		 if(job->result == JOB_CANCELLED)
		   st = "cancelled"; 

		 SET_STRING_ELT(status, i, mkChar(st));

               }

	       SET_VECTOR_ELT(retval, 0, id);
	       SET_STRING_ELT(names,  0, mkChar("id"));

	       SET_VECTOR_ELT(retval, 1, status);
	       SET_STRING_ELT(names,  1, mkChar("status"));

	       setAttrib(retval, R_NamesSymbol, names);
	       setAttrib(retval, R_ClassSymbol, mkString("data.frame"));
	       setAttrib(retval, install("row.names"), row_names);
	       UNPROTECT(3+ncol);



	       size_t size;
               s = (so_t*)SO_valueOf(retval, &size);
	     END_R_EVAL();
	   } else {
	     job_t *job = findJob(job_id);
	     if(job){
	       BEGIN_R_EVAL();
	       pthread_mutex_lock(&job->mutex);
	         SEXP retval;
		 if(job->result == NULL){
		   retval = PROTECT(mkString("----"));
		 } else if(job->result == JOB_CANCELLED){
		   retval = PROTECT(mkString("cancelled"));
		 } else {
		   retval = PROTECT(mkString("finished"));
		 }
	         SEXP names = PROTECT(mkString("status"));
	         setAttrib(retval, R_NamesSymbol, names);
	         size_t size;
                 s = (so_t*)SO_valueOf(retval, &size);
	       END_R_EVAL();
//	       Supr_decref(job);
    JOB_DECREF(job);
	       pthread_mutex_unlock(&job->mutex);

	     } else {
	       // TODO ?...
	     }
	   }

	   if(s) {
	     write(fd, s, sizeof(so_t)+s->size);
	     free(s);
	   } else {
	     so_t so = {0,0,0,SUPR_UNBOUND_VALUE,0};
	     write(fd, &so, sizeof(so_t));
	   }
	 }
	 return 0;

	 /*
    case TR_COUNTDOWN_CREATE:
    case TR_COUNTDOWN_RESET:
	 {
	   int job_id, tr_id, max_count, len;
           read(fd, &job_id, sizeof(int)); 
           read(fd, &tr_id, sizeof(int)); 

           if(cmd == TR_COUNTDOWN_CREATE)
             read(fd, &max_count, sizeof(int)); 

           read(fd, &len, sizeof(int)); 

	   char var_name[len];
           read(fd, &var_name, len);
//	   printf("[COUNTDOWN_CREATE:%d] var_name: %s\n", __LINE__, var_name);

	   so_t so; // = {0,0,0,SUPR_UNBOUND_VALUE,0};
	   read(fd, &so, sizeof(so_t));
	   so_t *args = (so_t *) malloc(sizeof(so_t)+so.size);
	   read(fd, args + 1, so.size);
	   memcpy(args, &so, sizeof(so_t));

	   job_t *job = getJob(job_id);
	   if(cmd == TR_COUNTDOWN_CREATE){
	     so_t *s = (so_t*) hashtableGet(job->environment, var_name);
	     if(!s){
	       s = newCountdown(var_name, job_id, tr_id, max_count, args);
	       hashtablePut(job->environment, var_name, s);
	       write(fd, &so, sizeof(so_t));
	     }
	     write(fd, s, sizeof(so_t)+s->size);
	   } else {
	     so_t *s = (so_t*) hashtableGet(job->environment, var_name);
	     s = countdownReset(s, job_id, tr_id, args);
	     write(fd, s, sizeof(so_t)+s->size);
	   }
	 }
	 return 0;
	 */

    case TASKRUNNER_MESSAGE:
	 {
	   int job_id, tr_id, len;
           read(fd, &job_id, INT_SIZE); 
           read(fd, &tr_id,  INT_SIZE); 
           read(fd, &len,  INT_SIZE); 
	   char msg[len];
           read(fd, msg,  len); 
	   // message:
	   //fprintf(stderr, "\t[TR_MESSAGE, %ld], job_id: %d, tr_id: %d, len: %d, msg: %s\n", syscall(SYS_gettid), job_id, tr_id, len, msg);
	   so_t so = {0, 0, 0, 0, 0};
	   write(fd, &so, sizeof(so_t));

	   char buf[256+len];
	   sprintf(buf, "[TR_M: %d-%d] %s", job_id, tr_id, msg);
	   UserInfo_send(0, 0, buf);
	 }
	 return 0;

    case TR_NTASKRUNNERS:
	 {
	   int job_id;
	   size_t len;
           //ssize_t n = 
	   read(fd, &job_id, INT_SIZE); 
	   read(fd, &len, sizeof(size_t)); 

	   int ntrs = NA_INTEGER;

	   if(len){
	     char mutex[len];
	     read(fd, mutex, len);
	     fprintf(stderr, "[%s] monitor_name: %s\n", __func__, mutex);
             vector_t *wait_queue = Driver_getWaitQueue(job_id, mutex);

	     if(wait_queue) 
		     ntrs = vectorSize(wait_queue);

	   } else { 

	     job_t *job = findJob(job_id);
	     if(job) {
	       pthread_mutex_lock(&job->mutex);
	         ntrs = vectorSize(job->taskrunners);
//		 Supr_decref(job);
    JOB_DECREF(job);
	       pthread_mutex_unlock(&job->mutex);
	     }
	   }

	   //{
	     //write(fd, &ntrs, INT_SIZE);
	     //so_t so = {0, 0, 0, SUPR_INT_ARRAY, 2*sizeof(int), 1, ntrs};
	     so_t so = {0, 0, 0, SUPR_INT_ARRAY, 2*sizeof(int)};
	     char buf[sizeof(so_t)+so.size];
	     memcpy(buf, &so, sizeof(so_t));
	     int *x = (int*)(buf + sizeof(so_t));
	     x[0] = 1;
	     x[1] = ntrs;
	     fprintf(stderr, "[%s] sizeof(s): %ld, ntrs: %d\n",
			   __func__, sizeof(buf), ntrs);
	     //so_t *s = (so_t*) buf; int *y = (int*)s->val; fprintf(stderr, "\t%d, %d\n", y[0], y[1]);
	     write(fd, buf, sizeof(buf));
	   //}
	 }
	 return 0;

    case CLUSTER_MSG_SEND:
	 {
           int header[2];
           read(fd, header, sizeof(header));
           int len_addr = header[0];
           int len_raw  = header[1];
	   int len = 3*sizeof(int)+len_addr+len_raw;
	   void *bytes = malloc(len);
	   read(fd, bytes+3*sizeof(int), len_addr+len_raw);
	   ((int*) bytes)[0] = CLUSTER_MSG_SEND;
	   ((int*) bytes)[1] = header[0];
	   ((int*) bytes)[2] = header[1];

	   { // FIXME? move it to the end ...
	     so_t so = {0, 0, 0, SUPR_INT_ARRAY, 2*sizeof(int)};
	     char buf[sizeof(so_t)+so.size];
	     memcpy(buf, &so, sizeof(so_t));
	     int *x = (int*)(buf + sizeof(so_t));
	     x[0] = 1; // length
	     x[1] = 0; // values
	     write(fd, buf, sizeof(buf));
	   }

	   char *addr = (char*) bytes + 3*sizeof(int);
	  
	   if(Supr_options.verbose){
	     char msg[256];
	     sprintf(msg, "Received message for '%s'", addr);
	     basic_info(msg);
	   }
	   

	   if(strcmp(addr, "user")==0 || strcmp(addr, "driver")==0){
	     if(info_sc){
	       pthread_mutex_lock(info_sc->mutex);
	         write(info_sc->fd, bytes, len);
		 int rc;
	         read(info_sc->fd, &rc, sizeof(int));
	       pthread_mutex_unlock(info_sc->mutex);
	     } else {
	       error_info("cannot deliver message");
	     }
	   } else if(strstr(addr, ":")) { // addr = job_id:task_id
             int job_id  = atoi(addr);
             int tr_id = atoi(strstr(addr,":")+1);
	     char msg[256];
	     if(Supr_options.verbose){
	       sprintf(msg, "Received message for '%d:%d'", job_id, tr_id);
	       verbose_info(msg);
	     }

	     job_t *job = findJob(job_id); // handle error ...

             if(!job){
               sprintf(msg, "cannot find job: %d", job_id);
               error_info(msg);
	       /*
               char *err = msg;
               so_t so = {0, 0, 0, SUPR_ERROR, strlen(err)+1};
               write(conn->fd, &so, sizeof(so_t));
               write(conn->fd, err, strlen(err)+1);
               return;
	       */
             } else {
               pthread_mutex_lock(&job->mutex);
               char *trAddr = vectorElementAt(job->taskrunners, tr_id);

	       if(trAddr && strstr(trAddr, ":")){
	         char __host[strlen(trAddr)+1];
	         strcpy(__host, trAddr);
	         *strstr(__host,":") = 0;
		 char *host = strstr(__host, "//") ? strstr(__host, "//") +2 :
			 __host;
	         int port = atoi(strstr(trAddr, ":")+1);

                 //sprintf(msg, "Find worker '%s:%d' ...", host, port);
                 //basic_info(msg);

	         for(int i=vectorSize(socket_connections)-1; i>=0; i--){
                   supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
                   if(sc->type == WORKER_CONN && strcmp(sc->host, host)==0 &&
				 sc->port == port && sc->to){
                   
		     int cmd = CLUSTER_MSG_SEND_TO_TR;
		     write(sc->to->fd, &cmd, sizeof(int));
		     int n = strlen(trAddr)+1;
		     write(sc->to->fd, &n, sizeof(int));
		     write(sc->to->fd, trAddr, n);
		     write(sc->to->fd, bytes, len);
		     int rc;
	             read(sc->to->fd, &rc, sizeof(int));

		     //sprintf(msg, "Sent with rc: %d", rc);
		     //basic_info(msg);
		     break;

                   }
                 }
	       }
//	       Supr_decref(job);
    JOB_DECREF(job);
               pthread_mutex_unlock(&job->mutex);
	     }

	   } 

	   free(bytes);
	 }
	 return 0;


    case CLUSTER_MSG_BROADCAST:
         {
           int header[2];
           read(fd, header, sizeof(header));
           int len = header[1];
           void *ptr = malloc(3*sizeof(int)+len);
           read(fd, ptr + 3*sizeof(int), len);
	   ((int*)ptr)[0] = CLUSTER_MSG_BROADCAST;
	   ((int*)ptr)[1] = header[0]; // job_id
	   ((int*)ptr)[2] = header[1];
           //int rc = 0;
           //write(fd, &rc, sizeof(int));
	   { // FIXME?
	     so_t so = {0, 0, 0, SUPR_INT_ARRAY, 2*sizeof(int)};
	     char buf[sizeof(so_t)+so.size];
	     memcpy(buf, &so, sizeof(so_t));
	     int *x = (int*)(buf + sizeof(so_t));
	     x[0] = 1; // length
	     x[1] = 0; // values
	     write(fd, buf, sizeof(buf));
	   }

           //{

             int count = 0;
             for(int i=vectorSize(socket_connections)-1; i>=0; i--){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
               if(sc->type == WORKER_CONN){
		 if(sc->to){
                   ssize_t size = write(sc->to->fd, ptr, 3*sizeof(int)+len);
                   int rc;
                   size += read(sc->to->fd, &rc, sizeof(int));
                   if(size == 3*sizeof(int)+len) count ++;
		   //basic_info("Use worker-to connection!");
		   //
		   //need a separate thread to do this
		   //to avoid potential deadlock
		   //
		 } else {
                   ssize_t size = write(sc->fd, ptr, 3*sizeof(int)+len);
                   if(size == 3*sizeof(int)+len) count ++;
		 }
               }
             }
             free(ptr);

             if(Supr_options.verbose) {
                 char msg[256];
                 sprintf(msg, "Sent broadcast message to %d workers\n"
				 "\tfd: %d\n", count, fd);
                 verbose_info(msg);
             }
           //}
         }
         return 0;



    default:
	 printf("[%s] unknown cmd: %d\n", __func__, cmd);
	 break;
  }
  return -1;

}
void __handleByteMessage__(void *data)
{
  int rc = handleByteMessage((supr_socket_conn_t *)data);
}


void handleShutdown(supr_socket_conn_t *conn)
{
	/*
	int msg[] = {CLUSTER_SHUTDOWN, TRUE};
	int rc;

//	   if(msg[1]) { // all = TRUE => kill master and dfs_name?
             for(int i=vectorSize(socket_connections)-1; i>=0; i--){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
		       vectorElementAt(socket_connections, i);
	       if(   sc->type == DFS_NAMENODE_CONN 
	          || sc->type == MASTER_CONN ){

		  if(sc->type == MASTER_CONN) master_conn = NULL;

                  ssize_t size = write(sc->fd, msg, sizeof(msg));
		  shutdown(sc->fd, SHUT_WR); 
                  size = read(sc->fd, &rc, INT_SIZE); //?
	          printf("shutdown read response size: %ld, rc:%d\n", size, rc);
		  close(sc->fd);
		  vectorRemove(socket_connections, i);
	       } else if(   sc->type == USER_INFO){
		  shutdown(sc->fd, SHUT_WR);
		  close(sc->fd);
		  vectorRemove(socket_connections, i);
	       }
	     }
	   //}

//	   rc = 0;
//	   write(fd, &rc, INT_SIZE);
*/

// FIXME...           system_exit(CLUSTER_SHUTDOWN);

 
  char msg[1024];


  if(Supr_curStrError){
    char *err = malloc(strlen(Supr_curStrError) + strlen(__func__)
		    + strlen("<-")+1);
    sprintf(err, "%s<-%s", __func__, Supr_curStrError);
    Supr_curStrError = err;
  } else {
    Supr_curStrError = (char*)  __func__;
  }
  // wait for threads that are using info_sc ?
  pthread_mutex_lock(&Supr_syncMutex);
  /*
    if(info_sc){
      close(info_sc->fd);
      info_sc = NULL;
    }
    if(parent_sc){
      close(parent_sc->fd);
      parent_sc = NULL;
    }
    */
  pthread_mutex_unlock(&Supr_syncMutex);


  // 1. Close connections
  // basic_info("Close connections");

  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(socket_connections, i);
    close(sc->fd); // Supr_decref???
    free(sc);
  }

  // 2. Cancel pthreads
  // basic_info("Cancel pthreads");

  supr_thread_t *cth = pthread_getspecific(currentThreadKey);

  for(int i=vectorSize(threads)-1; i>=0; i--){
    supr_thread_t *th = vectorElementAt(threads, i);
    if(th != cth){
      int locked = !pthread_mutex_trylock(&th->mutex);
      if(locked){
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d, state: %s)", th->tid, th->pid, state2char(th->state));
      }else {
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d)", th->tid, th->pid);
      }
      fprintf(stderr, "%s\n", msg);

      int rc = pthread_cancel(th->ptid);
      if(locked){
        pthread_mutex_unlock(&th->mutex);
      }
      /*
      if(rc == 0){
	void *retval;
        int rc = pthread_join(th->ptid, &retval);
	if(retval == PTHREAD_CANCELED){
          fprintf(stderr, " pthread_join(%d, ...): PTHREAD_CANCELED\n",
			  th->tid);
	} else {
          fprintf(stderr, " pthread_join(%d, ...): %p\n",
			  th->tid, retval);
	}
      }
      */
    }
  }


//  pthread_mutex_unlock(&Supr_syncMutex);
  int rc = pthread_cancel(cth->ptid);
  //pthread_exit(NULL); //??


}

#define R_SERIALIZED_OBJECT 171117121
//#define R_SERIALIZED_OBJECT 825768241
extern class_t *Runnable_class;
void removeConn(supr_socket_conn_t *conn)
{
  // message:
  //fprintf(stderr, "\033[0;31m[%s, %ld] name: //%s:%d, fd: %d\033[0m\n", __func__, syscall(SYS_gettid), conn->host, conn->port, conn->fd);

	/*
  { // testing
    if(conn->type == MASTER_CONN){
	    return;
//      handleShutdown(conn);
    }
  }
  */
  if(Supr_options.verbose){
    char msg[256];
    sprintf(msg, "'%s' connection %s:%d is disconnected",
		  connTypeToStr(conn->type), conn->host, conn->port);
    verbose_info(msg);
  }

  { // testing
    if(conn->type == MAIN_USER_CONN){
      handleShutdown(conn);
    }
  }

  int conn_type = conn->type;
  int conn_port = conn->port;
  char host[strlen(conn->host)+1];
  memcpy(host, conn->host, strlen(conn->host)+1);

  //int type = conn->type;
  close(conn->fd);
  vectorRemoveElement(socket_connections, conn);



  if(conn->att){
    vector_t *att = (vector_t *) conn->att;
    for(int i=vectorSize(att)-1; i>=0; i--){
      object_t *obj = (object_t *) vectorRemove(att, i);
      if(obj->class == Runnable_class){
         run_t *r = (run_t *) obj;
	 r->run(r->data);
      }
    }
  }

  if(conn == usrInfoConn){
    usrInfoConn = NULL;
  }

  Supr_decref(conn); // FIXME?

  if(usrInfoConn){
#define COMMAND_TYPE 101
#define SOCKET_DISCONNECTION 801
    char buf[256+sizeof(host)];
    sprintf(buf, "%s://%s:%d is disconnected",
		 connTypeToStr(conn_type), host, conn_port);
    UserInfo_send(COMMAND_TYPE, SOCKET_DISCONNECTION, buf);
  }
  /*
  if(usrInfoConn){

#define COMMAND_TYPE 101
	     int type = COMMAND_TYPE;
             //write(usrInfoConn->fd, &type, INT_SIZE);
	     // FIXME
	     ssize_t size = Socket_send(usrInfoConn->fd, &type, INT_SIZE, 0);
	     if(size == -1) {
               fprintf(stderr, "\033[0;31m[%s] size: %ld,  usrInfoConn->ref_count: %d\033[0m\n", __func__,
		  size, usrInfoConn->ref_count);
               Supr_decref(usrInfoConn);
	       usrInfoConn = NULL;
	       return;
	     }
#define SOCKET_DISCONNECTION 801
	     int level = SOCKET_DISCONNECTION;
             //write(usrInfoConn->fd, &level, INT_SIZE);
	     size = Socket_send(usrInfoConn->fd, &level, INT_SIZE, 0);
	     if(size == -1) {
               fprintf(stderr, "\033[0;31m[%s] size: %ld,  usrInfoConn->ref_count: %d\033[0m\n", __func__,
		  size, usrInfoConn->ref_count);
               Supr_decref(usrInfoConn);
	       usrInfoConn = NULL;
	       return;
	     }
	     char buf[256+sizeof(host)];
	     sprintf(buf, "%s://%s:%d is disconnected",
		 connTypeToStr(conn_type), host, conn_port);
	     size_t len = strlen(buf) + 1;
	     size = Socket_send(usrInfoConn->fd, &len, SIZE_SIZE, 0);
	     if(size == -1) {
               fprintf(stderr, "\033[0;31m[%s] size: %ld,  usrInfoConn->ref_count: %d\033[0m\n", __func__,
		  size, usrInfoConn->ref_count);
               Supr_decref(usrInfoConn);
	       usrInfoConn = NULL;
	       return;
	     }
	     size = Socket_send(usrInfoConn->fd, buf, len, 0);
	     if(size == -1) {
               fprintf(stderr, "\033[0;31m[%s] size: %ld,  usrInfoConn->ref_count: %d\033[0m\n", __func__,
		  size, usrInfoConn->ref_count);
               Supr_decref(usrInfoConn);
	       usrInfoConn = NULL;
	       return;
	     }

	     {
               int rc;
	       // Socket_read?
	       read(usrInfoConn->fd, &rc, INT_SIZE);
               fprintf(stderr, "\033[0;32m[%s] rc: %d\033[0m\n", __func__, rc);
	     }
	     //write(usrInfoConn->fd, &len, SIZE_SIZE);
	     //write(usrInfoConn->fd, buf, len);
#undef SOCKET_DISCONNECTION

  }
  */
  /*
  if(type == DFS_NAMENODE_CONN){
                doCleanup();
     pthread_mutex_lock(&main_thread->mutex);
       main_thread->data = PTHREAD_INTERRUPTED;
       pthread_cond_signal(&main_thread->cond);
     pthread_mutex_unlock(&main_thread->mutex);
  }
  */
}

// return socket connections
void handleGetContext(supr_socket_conn_t *conn)
{
  int cmd, fd = conn->fd;
  read(fd, &cmd, INT_SIZE);
  int n = vectorSize(socket_connections); // LOCK?

  so_t *s = NULL;
  size_t size;

  BEGIN_R_EVAL();
   //SEXP val  = PROTECT(allocVector(VECSXP, 3));
   //SEXP names= PROTECT(allocVector(STRSXP, 3));
   /*
   SEXP conns= PROTECT(allocVector(STRSXP, n));
   for(int i=0; i < vectorSize(socket_connections); i++){
     supr_socket_conn_t *sc = (supr_socket_conn_t *)
	     vectorElementAt(socket_connections, i);

     char buf[256];
     sprintf(buf, "%s %s:%d %d", connTypeToStr(sc->type), sc->host,
		     sc->port, sc->pid);
     SET_STRING_ELT(conns, i, mkChar(buf));
   }
   */
   SEXP conns= PROTECT(CONS(R_NilValue, R_NilValue));
   SEXP t = conns;
   for(int i=0; i < vectorSize(socket_connections); i++){
     supr_socket_conn_t *sc = (supr_socket_conn_t *)
	     vectorElementAt(socket_connections, i);
     char buf[256];
     sprintf(buf, "//%s:%d::%d", sc->host, sc->port, sc->pid);
     SETCDR(t, CONS(mkString(buf), R_NilValue));
     t = CDR(t);
     sprintf(buf, "%s", connTypeToStr(sc->type));
     SET_TAG(t, install(buf));
   }

   //PrintValue(conns);

   s = SO_valueOf(CDR(conns), &size);
  END_R_EVAL();

  write(fd, s, size); // handle errors ...
  free(s);
}

extern void Html_sendError(supr_socket_conn_t *conn, const char *file_name);

//extern ssize_t send(int socket, const void *buffer, size_t length, int flags);

#define send(s, b, len, flags) Socket_send((s), (b), (len), (flags))

void Html_sendIndex(supr_socket_conn_t *conn)
{
  char *idx = "<!DOCTYPE html>\n<HEAD>\n<TITLE>Driver</TITLE>\n"
        "  <META charset=\"utf-8\">\n</HEAD>\n<BODY>\n<UL>\n"
        "\t<LI><a href=\"stdout.txt\">stdout</a></LI>\n"
        "\t<LI><a href=\"stderr.txt\">stderr</a></LI>\n"
        "\t<LI><a href=\"info.txt\">info</a></LI>\n"
        "</UL>\n</BODY>\n";

  const char *p_format = "HTTP/1.1 200 OK\r\nServer:SupR2\r\n"
          "Content-length: %ld\r\nContent-type:%s; charset=UTF-8\r\n\r\n";
  char *ct = "text/html";

  char protocol[strlen(p_format)+strlen(ct)+64];
  sprintf(protocol, p_format, strlen(idx), ct);

  send(conn->fd, protocol, strlen(protocol), 0);
  send(conn->fd, idx, strlen(idx), 0);
}


// copied from dfs_data.c
void handleHTTP_GET(supr_socket_conn_t *conn)
{
  int fd = conn->fd;

  size_t buf_size = 4096;
  unsigned char buf[buf_size+1];
  ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
  len = __read__(fd, buf, len);
  buf[len++] = 0;
  fprintf(stdout, "\033[0;36m[%s://%s:%d]\n\"%s\"\033[0m\n", connTypeToStr(conn->type), conn->host, conn->port, buf);

  char *file_name = strstr(buf, " /")+2;
  char *str = strstr(file_name, " HTTP/");
  *str = 0;

  unsigned char *content = NULL;
  char *ct = "text/plain";
  size_t content_size;

  struct stat sb;

  if(strlen(file_name)==0){
    Html_sendIndex(conn);
    return;
  } else if (strcmp(file_name, "info.txt")==0){
    char buf[1024];

    char *s = buf;

    sprintf(s, "Connections:\n"); s += strlen(s);
    for(int i = vectorSize(socket_connections) - 1; i>=0; i--){
      supr_socket_conn_t * sc = (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
      sprintf(s, "  %s://%s:%d\n", connTypeToStr(sc->type),
		      sc->host, sc->port); s += strlen(s);
    }

    content_size = strlen(buf);
    content = (unsigned char *) malloc(content_size); 
    memcpy(content, buf, content_size);
  } else if (strcmp(file_name, "stderr.txt")==0
                  || strcmp(file_name, "stdout.txt")==0 ){
    fflush(stdout);
    int rc = stat(file_name, &sb);
    if(rc == -1){
      Html_sendError(conn, file_name);
      return;
    }
    content_size = sb.st_size;
    content = (unsigned char *) malloc(sb.st_size);
    int file_fd = open(file_name, O_RDONLY);
    read(file_fd, content, sb.st_size);
    close(file_fd);
  } else {
    Html_sendError(conn, file_name);
    return;
  }

  char protocol[] = "HTTP/1.1 200 OK\r\n";
  char servName[] = "Server:SupR2\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  sprintf(cntLen, "Content-length: %ld\r\n", content_size);
  char cntType[256];
  snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n",
                  ct);

  send(fd, protocol, strlen(protocol), 0);
  send(fd, servName, strlen(servName), 0);
  send(fd, cntLen, strlen(cntLen), 0);
  send(fd, cntType, strlen(cntType), 0);

  send(fd, content, content_size, 0);

  free(content);



}

void handleClusterState(void *data)
{
  int cmd;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) data;
  int fd = conn->fd;
  read(fd, &cmd, sizeof(int));

  int len;
  read(fd, &len, sizeof(int));
  char sym[len];
  read(fd, sym, len);

   // TODO

  BEGIN_R_EVAL();
    SEXP r = PROTECT(allocVector(STRSXP, vectorSize(socket_connections)));
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
       		vectorElementAt(socket_connections, i);
	char *name = "";
        if(sc->type == DFS_NAMENODE_CONN){
		name = "dfs_name";
        } else if(sc->type == MASTER_CONN){
		name = "master";
        } else if(sc->type == WORKER_CONN){
		name = "worker";
        } else if(sc->type == DRIVER_CONN){
		name = "driver";
        } else if(sc->type == USER_CONN){
		name = "user";
        } else {
		name = "other"; // TODO
        }

	char buf[strlen(sc->host)+64];
	sprintf(buf, "%s//%s:%d:%d", name, sc->host, sc->port, sc->pid);
	SET_STRING_ELT(r, i, mkChar(buf));
    }

    // use shm instead?

    SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(r, CONS(R_NilValue, R_NilValue))));
    SEXP raw = eval(call, R_GlobalEnv);
    int len = LENGTH(raw);
    write(fd, &len, sizeof(int));
    write(fd, RAW(raw), len);
    UNPROTECT(2);
  END_R_EVAL();
}

supr_thread_t *startUI(shm_io_info_t *io);

void handleShmConnection(const char *shm_name)
{
  Cluster_sendSimpleMessage("shm_name:", msg_color, BASIC_INFO_TYPE, 0);
  Cluster_sendSimpleMessage(shm_name,    msg_color, BASIC_INFO_TYPE, 0);

  shm_io_info_t *io = shm_io_open(shm_name);
  char msg[1024];
  sprintf(msg, "[%s] (shm_io) io->out->pid: %d\n", __func__, io->out->pid);
  Cluster_sendSimpleMessage(shm_name,    msg_color, BASIC_INFO_TYPE, 0);
  
  sem_post(&io->out->sem_wait);
    //shm_io_write(io, io->out, shm_name, strlen(shm_name)+1);
  pid_t pid = getpid();
  shm_io_write(io, io->out, &pid, sizeof(pid_t));

  if(!user_io)
    user_io = io;

  supr_thread_t *io_th = startUI(io);
  vectorAdd(threads, io_th);
}

void handleCommand(supr_socket_conn_t *conn)
{
  int fd = conn->fd;

//if(!Supr_debug) basic_info("turn on Supr_debug"); Supr_debug = TRUE;

  //printf("\n[%s] %s, %d\n\n", __func__, __FILE__, __LINE__);
  //conn->print(conn);

  int cmd;
  {
    ssize_t len = 0;
    for( ; ; ) {
      len = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
      if (len == INT_SIZE)
	      break;
      else if(len <= 0){
	if(conn==info_sc) // delete me ... info_sc is not on the list
       	  info_sc = NULL;
        removeConn(conn);
	return;
      } 
    }


    if(Supr_options.debug && cmd != 208) { // FIXME
       sprintf(msg, "[recv] fd: %d, cmd: %d, %s", fd, cmd, cmd2char(cmd));
       //fprintf(stderr, "%s\n", msg);
       debug_info(msg);
    }
  }

  switch(cmd){

#ifdef write
#pragma message("\033[0;31mwrite is defined\033[0m\n")
#pragma message "1205. value of write(x, y, z) = " VALUE(write(x, y, z))
#endif
#ifdef read
#pragma message("\033[0;31mread is defined\033[0m\n")
#pragma message "1205. value of read(x, y, z) = " VALUE(read(x, y, z))
#endif


#define DO_CLUSTER_TEST
#ifdef  DO_CLUSTER_TEST
    case CLUSTER_TEST:
	 {
	   {
	     int size_rcv, size_snd, len = sizeof(int);
	     int rc = getsockopt(fd, SOL_SOCKET, SO_RCVBUF, &size_rcv, &len);
	     rc = getsockopt(fd, SOL_SOCKET, SO_SNDBUF, &size_snd, &len);
	     char buf[256];
	     int flags = fcntl(fd, F_GETFL);
	     if(flags == -1)
		     sprintf(buf, "SO_RCVBUF: %d, SO_SNDBUF: %d, Error: %s",
				     size_rcv, size_snd, strerror(errno));
	     else
		     sprintf(buf, "SO_RCVBUF: %d, SO_SNDBUF: %d, %s",
				     size_rcv, size_snd,
                      flags & O_NONBLOCK ? "NONBLOCK": "BLOCK");
	     basic_info(buf);

	     rc = getsockopt(fd, SOL_SOCKET, SO_RCVLOWAT, &size_rcv, &len);
	     rc = getsockopt(fd, SOL_SOCKET, SO_SNDLOWAT, &size_snd, &len);
	     sprintf(buf, "SO_RCVLOWAT: %d (=1?), SO_SNDLOWAT: %d (=1?)",
				     size_rcv, size_snd);
	     basic_info(buf);

	     struct timeval tv;
	     len = sizeof(struct timeval);
	     rc = getsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, &len);
	     sprintf(buf, "SO_RCVTIMEO: %ld (sec) and %ld (microsec.)",
			     tv.tv_sec, tv.tv_usec);
	     basic_info(buf);
	     rc = getsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, &len);
	     sprintf(buf, "SO_SNDTIMEO: %ld (sec) and %ld (microsec.)",
			     tv.tv_sec, tv.tv_usec);
	     basic_info(buf);
	   }

           ssize_t size = read(fd, &cmd, sizeof(int));
	   ssize_t len;
           size = read(fd, &len, sizeof(ssize_t));

	   char buf[256];
	   sprintf(buf, "read(fd, &len, sizeof(ssize_t)): %ld, len: %ld",
			   size, len);
	   basic_info(buf);

	   void *ptr = malloc(len);
           size = read(fd, ptr, len);
	   sprintf(buf, "read(fd, ptr, %ld): %ld", len, size);
	   basic_info(buf);

	   len = write(fd, &size, sizeof(ssize_t));
	   sprintf(buf, "write(fd, &size, sizeof(ssize_t)): %ld", len);
	   basic_info(buf);

	   if(size>0){
	     len = write(fd, ptr, size);
	     sprintf(buf, "write(fd, ptr, size): %ld", len);
	     basic_info(buf);
	     len = write(fd, &len, sizeof(ssize_t));
	     sprintf(buf, "write(fd, &len, sizeof(ssize_t)): %ld", len);
	     basic_info(buf);
	   }
	   free(ptr);
	 }
	 return;
#endif

    case WORKER_REGISTER:
	 {
           int msg[4];
           size_t size = read(fd, msg, sizeof(msg));
           conn->type = WORKER_CONN;
           conn->port = msg[1];
           conn->pid = msg[2];
           conn->tid = msg[3];
	   verbose_info("worker '%s:%d' is connected", 
	                 conn->host, conn->port);

	   //{
           conn->to = socketOpen2(conn->host, conn->port);
	   if(!conn->to)
	     error_info("cannot establish 'write-to' '%s:%d' connection", 
	                 conn->host, conn->port);
	   
	   //}


	   /*
	   if(worker_count_mutex){
	     pthread_mutex_lock(worker_count_mutex);

	       if(user_io){
	         int rc  = 1; // some positive int
                 shm_io_write(user_io, user_io->out, &rc, INT_SIZE);
	         char msg[strlen(conn->host)+32];

	         sprintf(msg, "worker://%s:%d is connected", conn->host,
	       		conn->port);
                 shm_io_write(user_io, user_io->out, msg, strlen(msg)+1);
	       }

	       
	     pthread_mutex_unlock(worker_count_mutex);
	   }
	   */

	 }
	 return;

    case WORKER_READY:
	 {
           int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
           //conn->type = WORKER_CONN;
           //conn->port = msg[1]; ntrs?
	   if(worker_count_mutex){
	     pthread_mutex_lock(worker_count_mutex);
	       worker_count--;

	       if(user_io){
	         int rc  = 1; // some positive int
                 shm_io_write(user_io, user_io->out, &rc, INT_SIZE);
	         char buf[strlen(conn->host)+32];

	         sprintf(buf, "worker://%s:%d?ntrs=%d is ready (%d)",
		 	conn->host, conn->port, msg[1], worker_count);
                 shm_io_write(user_io, user_io->out, buf, strlen(buf)+1);
	       }

	       if(worker_count <= 0)
	         pthread_cond_signal(worker_count_cond);
	       
	     pthread_mutex_unlock(worker_count_mutex);
	   }
	 }
	 return;

    case USER_REGISTER:
	 {
           int msg[3];
           size_t size = read(fd, msg, sizeof(msg));
           conn->type = USER_CONN;
           conn->pid  = msg[1];
           conn->port  = msg[2];

	   //printf("USER_REGISTER: pid=%d\n", conn->pid);
	   /*
	   {
	     char msg[1024];
	     sprintf(msg, "vectorSize(socket_connections): %d\n",
			     vectorSize(socket_connections));
	     Cluster_sendSimpleMessage(msg, msg_color, 0, 0);
	     sleep(10);
	   }
	   */
	 }
	 return;

    case CLUSTER_WHO:
	 {
	   read(fd, &cmd, INT_SIZE);
           int msg[] = {DRIVER_CONN, getpid(), geteuid()};
           write(fd, msg, sizeof(msg));
	 }
	 return;

    case CLUSTER_PING:
	 {
	   read(fd, &cmd, INT_SIZE);
           int cmd = CLUSTER_PONG;
           write(fd, &cmd, INT_SIZE);
	 }
	 return;

    case CLUSTER_EXECUTOR_REGISTER:
	 {
	   read(fd, &cmd, INT_SIZE);
           pid_t tid;
           read(fd, &tid, INT_SIZE);
	   conn->type = EXECUTOR_CONN;
	   conn->pid  = tid;
	 }
	 return;

    case CLUSTER_SHUTDOWN:
         {
           int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   /*
	   {
	     char buf[256];
	     sprintf(buf, "sc: '%s:%d', fd: %d, type: %s, read: %ld(=%ld?)",
		     conn->host, conn->port, fd, connTypeToStr(conn->type),
		     size, sizeof(msg));
	     basic_info(buf);
	   }
	   */
	   if(size != sizeof(msg)) {
	     error_info("size != sizeof(msg)");
             removeConn(conn);
	     return;
	   }
	   int rc = 0;
	   write(fd, &rc, sizeof(int));

	   //basic_info("SHUTTING DOWN ...");

	   Supr_curStrError = "SHUTDOWN";

	   handleShutdown(conn);
         }
         return;

    case CLUSTER_JOB_SUBMIT:
         {
	   int buf[2]; // {cmd, job_id}
           read(fd, buf, sizeof(buf));
	   //printf("[%s] cmd = %d, job_id=%d\n", __func__, buf[0], buf[1]);
	   //int job_id = buf[1];
	   //job_t *job = __job__;
	   int job_id = buf[1];
	   job_t *job = findJob(job_id);
	   if(!job) {
		   error_info("cannot find job %d", job_id);
		   return;
	   }
	   int count = 0;
	   //pthread_mutex_lock(&job->mutex);
	   // send worker the job expr...
	   for(int i = vectorSize(socket_connections)-1; i>=0; i--)
	   {
             supr_socket_conn_t * conn = (supr_socket_conn_t *) 
		     vectorElementAt(socket_connections, i);
	     if(conn->type == WORKER_CONN){

	       if(conn->to){
                 write(conn->to->fd, buf, sizeof(buf));
	         so_t *so = (so_t *) job->expr;
                 write(conn->to->fd, so, sizeof(so_t) + so->size);
	         //{
		       int rc;
		       read(conn->to->fd, &rc, INT_SIZE);
		       count += 1 - rc; // 1 + rc?
	         //}
	       } else {
                 write(conn->fd, buf, sizeof(buf));
	         so_t *so = (so_t *) job->expr;
                 write(conn->fd, so, sizeof(so_t) + so->size);
	         /*{
		       int rc;
		       read(conn->fd, &rc, INT_SIZE);
		       count += 1 - rc; // 1 + rc?
	         }*/
	         count++;
	       }
	     }
	   }
//	   Supr_decref(job);
    JOB_DECREF(job);
	   //pthread_mutex_unlock(&job->mutex);
	   write(fd, &count, INT_SIZE);
         }
         return;

    case CLUSTER_BYTE_MSG:
	 /*
	 {
	     main_thread_task_t *task = malloc(sizeof(main_thread_task_t));
	     task->fun = __handleByteMessage__;
	     task->data = conn;
	     pthread_mutex_lock(main_thread_tasks->mutex);
	       vectorAdd(main_thread_tasks, task);
	     pthread_mutex_unlock(main_thread_tasks->mutex);

	     pthread_mutex_lock(&main_thread->mutex);
	       pthread_cond_signal(&main_thread->cond);
	     pthread_mutex_unlock(&main_thread->mutex);
         }
         return;
	 */
          
	 //
	 if(handleByteMessage(conn)==0) 
		 return;
	 else 
		 break;
		 //

    case TR_CLUSTER_SYNC:
	 {
           ssize_t size = read(fd, &cmd, INT_SIZE);
	   size_t len;
           size += read(fd, &len, sizeof(size_t));
	   size_t offset = sizeof(supr_socket_conn_t*)+sizeof(int);
	   void *ptr = malloc(offset + len);
           size += read(fd, ptr + offset, len);
	   ((supr_socket_conn_t**)ptr)[0] = conn;
	   ((int *)(ptr + sizeof(supr_socket_conn_t*)))[0] = cmd;
	   {
	     int rc = 0;
	     write(fd, &rc, sizeof(int));
	     if(Supr_options.debug){
	       char msg[256];
               sprintf(msg, "Received cmd: %d (TR_CLUSTER_SYNC=%d), Sent rc: %d",
			     cmd, TR_CLUSTER_SYNC,
			     rc);
	       debug_info(msg);
	     }
	   }

	   main_thread_task_t *task = malloc(sizeof(main_thread_task_t));
	   task->fun = __handleSync__;
	   task->data = ptr;
	   pthread_mutex_lock(main_thread_tasks->mutex);
	     vectorAdd(main_thread_tasks, task);
	   pthread_mutex_unlock(main_thread_tasks->mutex);

	   pthread_mutex_lock(&main_thread->mutex);
	     pthread_cond_signal(&main_thread->cond);
	   pthread_mutex_unlock(&main_thread->mutex);
          
	 }
	 return;

    case TR_CLUSTER_UNSYNC:
         {
	   int cmd, job_id, tid;
           size_t size = read(fd, &cmd, INT_SIZE);
           read(fd, &job_id, INT_SIZE);
           read(fd, &tid,    INT_SIZE);

           size_t len;
           size = read(fd, &len, SIZE_SIZE);
           char buf[len];
           size = read(fd, buf, len);

	   {
	     int rc = 0;
	     write(fd, &rc, sizeof(int));
	     if(Supr_options.debug){
	       char msg[256];
               sprintf(msg, "Received cmd: %d (TR_CLUSTER_UNSYNC=%d), Sent rc: %d", cmd, TR_CLUSTER_UNSYNC, rc);
	       debug_info(msg);
	     }
	   }

	   size_t offset = sizeof(supr_socket_conn_t*) + 3*sizeof(int);
	   void *ptr = malloc(offset+len);
	   ((supr_socket_conn_t**)ptr)[0] = conn;
	   int *hd = (int *)(ptr + sizeof(supr_socket_conn_t*));
	   hd[0] = cmd;
	   hd[1] = job_id;
	   hd[2] = tid;
	   memcpy(ptr+offset, buf, len);

	   
           //handleSync(conn, job_id, tid, buf, cmd);
	   main_thread_task_t *task = malloc(sizeof(main_thread_task_t));
	   task->fun = __handleSync__;
	   task->data = ptr;
	   pthread_mutex_lock(main_thread_tasks->mutex);
	     vectorAdd(main_thread_tasks, task);
	   pthread_mutex_unlock(main_thread_tasks->mutex);

	   pthread_mutex_lock(&main_thread->mutex);
	     pthread_cond_signal(&main_thread->cond);
	   pthread_mutex_unlock(&main_thread->mutex);
          
	   if(Supr_options.debug){
	     char msg[256];
	     sprintf(msg, "\033[0;31mAdded to main_thread_tasks\033[0m");
	     basic_info(msg);
	   }
         }
         return;

    case TR_CLUSTER_WAIT:
         { // FIXME...
	   int cmd, job_id, tid;
           size_t size = read(fd, &cmd, INT_SIZE);
           read(fd, &job_id, INT_SIZE);
           read(fd, &tid,    INT_SIZE);

	   double timeout = 0;

	   if(cmd == TR_CLUSTER_WAIT)
             size = read(fd, &timeout, DOUBLE_SIZE);

	   /*
	   if(cmd == TR_CLUSTER_WAIT)
	   {
           printf("\033[0;31m[%s:%d:%s] %d: WAIT job_id: %d tid: %d timeout: %f\n",
                         __FILE__, __LINE__, __func__, cmd, job_id, tid, timeout);
	   }
	   else
	   {
           printf("\033[0;31m[%s:%d:%s] %d: TR_CLUSTER_NOTIFY\n",
                         __FILE__, __LINE__, __func__, cmd);
	   }
	   */
           size_t len;
           size = read(fd, &len, SIZE_SIZE);
           //printf("\033[0;31m[%s:%d:%s] mutex.length: %ld\n", __FILE__, __LINE__, __func__, len);
           char buf[len];
           size = read(fd, buf, len);
           //printf("\033[0;31m[%s:%d:%s] mutex: %s\n", __FILE__, __LINE__, __func__, buf);

#ifdef TR_WAIT_USE_TIME_EXPR
           {
             ssize_t size;
             read(fd, &size, sizeof(ssize_t));
             //unsigned char timeout_expr[size];
             //read(fd, timeout_expr, size);

             //handleWaitAndNotify(conn, buf, cmd, job_id, tid, timeout_expr, size);

	     // {conn, cmd, job_id, tid, timeout} timeout is not used ...
	     size_t offset = sizeof(supr_socket_conn_t*) + 4*sizeof(int)+
		     sizeof(double);

	     void *ptr = malloc(offset + len + sizeof(size_t) + size);
	     ((supr_socket_conn_t**)ptr)[0] = conn;
	     int *hd = (int*)(ptr + sizeof(supr_socket_conn_t*));
	     hd[0] = cmd; 
	     hd[1] = job_id;
	     hd[2] = tid;
	     hd[3] = (int) len;
	     ((double*)(ptr + sizeof(supr_socket_conn_t*)+4*sizeof(int)))[0] =
		     timeout;
	     memcpy(ptr+offset, buf, len);
	     memcpy(ptr+offset+len, &size, sizeof(size_t));
	     read(fd, ptr+offset+len+sizeof(size_t), size);

	     {
	       int rc = 0;
	       write(fd, &rc, sizeof(int));
	       if(Supr_options.debug){
	         char msg[256];
                 sprintf(msg, "Received cmd: %d (TR_CLUSTER_WAIT=%d), Sent rc: %d", cmd, TR_CLUSTER_WAIT, rc);
	         debug_info(msg);
	       }
	     }

	     main_thread_task_t *task = malloc(sizeof(main_thread_task_t));
	     task->fun = __handleWaitAndNotify__;
	     task->data = ptr;
	     pthread_mutex_lock(main_thread_tasks->mutex);
	       vectorAdd(main_thread_tasks, task);
	     pthread_mutex_unlock(main_thread_tasks->mutex);

	     pthread_mutex_lock(&main_thread->mutex);
	       pthread_cond_signal(&main_thread->cond);
	     pthread_mutex_unlock(&main_thread->mutex);
          

           }
#else
	   {
	       int rc = 0;
	       write(fd, &rc, sizeof(int));
	       error_info("Deprecated");
	   }
           handleWaitAndNotify(conn, buf, cmd, job_id, tid, timeout);
#endif

         }
         return;

    case TR_COUNTDOWN_DECREASE:
         {
		 error_info("Deprecated");
	   int cmd, job_id, tid;
           ssize_t size = read(fd, &cmd, INT_SIZE);
           read(fd, &job_id, INT_SIZE);
           read(fd, &tid,    INT_SIZE);

           size_t len;
           size = read(fd, &len, SIZE_SIZE);
//           printf("\033[0;31m[%s:%d:%s] mutex.length: %ld\n", __FILE__, __LINE__, __func__, len);
           char buf[len];
           size = read(fd, buf, len);
//           printf("\033[0;31m[%s:%d:%s] mutex: %s\n", __FILE__, __LINE__, __func__, buf);

//MALLOC_MARK(__LINE__);
           read(fd, &len, SIZE_SIZE);
           //char ptr[size];
	   void *ptr = malloc(len);
           size = read(fd, ptr, len);

//MALLOC_MARK(__LINE__);
	   handleCountdownDecrease(buf, conn, job_id, tid, ptr, len);
//MALLOC_MARK(__LINE__);

         }
         return;

    case CLUSTER_DRIVER_NULL:
	 {
	   int cmd;
           size_t size = read(fd, &cmd, INT_SIZE);
//	   printf("cmd: %d\n", cmd);
           write(fd, &cmd, INT_SIZE);
           read(fd, &cmd, INT_SIZE);
//	   printf("cmd: %d\n", cmd);
	 }
         return;

    case CLUSTER_MMAP_CONN:
	 {
	   int cmd;
           ssize_t size  = read(fd, &cmd, INT_SIZE);
	   size_t len;
           size  = read(fd, &len, SIZE_SIZE);
	   char file_name[len];
           size  = read(fd, file_name, len);
           supr_thread_t *th = startMMapUI(file_name);
	   int rc = th ? 0 : -1;
           size  = write(fd, &rc, INT_SIZE);
	   if(rc==0)
	     SocketConn_attach(conn, newRunnable(Thread_cancel, th));
	   // TODO: error message
	 }
         return;

    case CLUSTER_SHM_CONN:
	 { // TODO ...
	   int cmd;
           ssize_t size  = read(fd, &cmd, INT_SIZE);
	   int len;
           size  = read(fd, &len, INT_SIZE);
	   char file_name[len];
           size  = read(fd, file_name, len);
	   {
	        char msg[1024];
	   	sprintf(msg, "CLUSTER_SHM_CONN: %s\n", file_name);
	   	basic_info(msg);
	   }
	   int rc = 0;
           size  = write(fd, &rc, INT_SIZE);
	   handleShmConnection(file_name);
	 }
         return;

	 /*
    case DCL_CONN:
	 {
           ssize_t size; 
	   int cmd;        size  = read(fd, &cmd, INT_SIZE);
	   pid_t pid;      size  = read(fd, &pid, INT_SIZE);
           size_t len;     size  = read(fd, &len, SIZE_SIZE);
	   char name[len]; size  = read(fd, name, len);
	   // use pid, in addition??? later ...
	   char buf[strlen(name)+128];
	   sprintf(buf, "name: %s, pid: %d", name, pid);
	   UserInfo_send(0, 0, buf);

	   printf("Sent: %s\n", buf);

	   conn->type = DCL_CONN;

	   supr_socket_conn_t *existing_conn = NULL;
	   //Hashtable_put(globalEnvironment, strdup(name), conn);
	   pthread_mutex_lock(globalEnvironment->mutex);
	     existing_conn = hashtableGet(globalEnvironment, name);
	     hashtablePut(globalEnvironment, name, conn);
             //hashtablePut(globalEnvironment, ref, r);
	   pthread_mutex_unlock(globalEnvironment->mutex);
	   int rc = 0;
	   pthread_mutex_lock(socket_connections->mutex);
	     for(int i=0; i<vectorSize(socket_connections); i++){
	       supr_socket_conn_t *sc = (supr_socket_conn_t *)
		       vectorElementAt(socket_connections, i);
	       if(sc->type == USER_CONN
			       && sc->pid == pid
			       // && strcmp(sc->host, conn->host)==0
			       ){
	         size  = write(sc->fd, &rc, INT_SIZE);
	         printf("Wrote: //%s:%d, pid: %d\n", sc->host, sc->port, pid);

	       }
	     }
	     vectorRemoveElement(socket_connections, conn);
	   pthread_mutex_unlock(socket_connections->mutex);
	   //size  = write(fd, &rc, INT_SIZE);

	   if(existing_conn){
	     vectorRemoveElement(DCL_connections, existing_conn);
	     fprintf(stderr, "[%s] existing_conn->ref_count: %d\n",
			     __func__, existing_conn->ref_count);
	     Supr_decref(existing_conn);
	   }

	   vectorAdd(DCL_connections, conn);
	 }
         return;
	 */

    case USER_INFO_ENABLED:
	 {

	   { // testing
	     // take conn as the main user connection
	     conn->type = MAIN_USER_CONN;
	   }

	   int cmd;
           ssize_t size  = read(fd, &cmd, INT_SIZE);
	   int port;
           size  = read(fd, &port, INT_SIZE);
           usrInfoConn = socketOpen2(conn->host, port);

	   pthread_mutex_lock(special_socket_connections->mutex);
	     vectorAdd(special_socket_connections, usrInfoConn);
	   pthread_mutex_unlock(special_socket_connections->mutex);

	   //conn->port = port;
	   //conn->type = USER_INFO; // infor_server
	   usrInfoConn->port = port;
	   usrInfoConn->type = USER_INFO; // infor_server

	   int rc = -1;
	   if(usrInfoConn){
	     int type = 0;
             write(usrInfoConn->fd, &type, INT_SIZE);
	     int level = 0;
             write(usrInfoConn->fd, &level, INT_SIZE);
	     char buf[256];
	     sprintf(buf, "Established (driver-user) info connection");
	     size_t len = strlen(buf) + 1;
	     write(usrInfoConn->fd, &len, SIZE_SIZE);
	     write(usrInfoConn->fd, buf, len);

	     rc = 0;
	   } 

	   write(conn->fd, &rc, INT_SIZE);
	 }
         return;

    case CLUSTER_SET_OPTIONS:
	 {
	   read(fd, &cmd, sizeof(int));
	   supr_options_t options;
	   read(fd, &options, sizeof(supr_options_t));
	   //{
	     Supr_options.info = options.info;
	     Supr_options.debug = options.debug;
	     Supr_options.verbose = options.verbose;
	     //Supr_options.port = options.port;
	     Supr_options.level = options.level;
	     Supr_options.timeout = options.timeout;
	   //}
	   int rc = 0;
	   write(fd, &rc, INT_SIZE);

	   for(int i=vectorSize(socket_connections)-1; i >= 0; i--){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
             		vectorElementAt(socket_connections, i);
	       if(sc->type == DFS_NAMENODE_CONN
	          || sc->type == MASTER_CONN){

		  write(sc->fd, &cmd, sizeof(int));
		  write(sc->fd, &options, sizeof(supr_options_t));
		  int rc = read(sc->fd, &rc, sizeof(int));
	       }
	   }
	 }
         return;

    case USER_INTERRUPT:
	 {
           ssize_t size;
	   int cmd;            size  = read(fd, &cmd, INT_SIZE);
	   size_t len;         size  = read(fd, &len, SIZE_SIZE);
	   char intr_ref[len]; size  = read(fd, intr_ref, len);

	   verbose_info("interrupted: user, intr_ref: %s\n", intr_ref);
	   
	   int rc = -1;
           void *obj = hashtableGet(globalEnvironment, intr_ref);
	   if(obj){
	     so_t *so = (so_t*) obj;
	     if(so->obj_type == SUPR_REFERENCE)
		     obj = ((void**)(so+1))[0];
	     else
		     error_info("FIXME");

	     if(((object_t*)obj)->class == Runnable_class){
	       run_t *r = (run_t *) obj;
               basic_info("(%s) r: %s", r->class->name,
			       r->class->toString(r->class, r));
	       ((void**)r->data)[1] = currentThread();
	       ((void**)r->data)[2] = conn;
	       r->run(r->data);
	       rc = 0;
	     } else {
	       error_info("obj %p is not runnable", obj);
	       //int tid = atoi(intr_ref);
	       rc = -1;
	     }
	   }
	   //size  = write(fd, &rc, INT_SIZE);
	 }
         return;

    case TR_CLUSTER_INTERRUPT:
	 {
	   int buf[2];
           ssize_t size;
	   size  = read(fd, buf, sizeof(buf));
	   int job_id = buf[1];
	   fprintf(stderr, "[TR_CLUSTER_INTERRUPT] job_id: %d\n", job_id);

	   job_t *job = findJob(job_id);
	   int count = 0;

	   if(job){

	     for(int i=vectorSize(socket_connections)-1; i >= 0; i--){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
             		vectorElementAt(socket_connections, i);
	       if(sc->type == WORKER_CONN){
		 write(sc->fd, buf, sizeof(buf));
		 int rc;
		 read(sc->fd, &rc, INT_SIZE);
	         fprintf(stderr, "[TR_CLUSTER_INTERRUPT] job_id: %d, rc: %d\n",
				 job_id, rc);
		 count += 1 - rc;
	       }
	     }

	     pthread_mutex_lock(&job->mutex);
               job->result = JOB_CANCELLED;
	       cancelJob_cleanup_monitors(job);
//	       Supr_decref(job);
    JOB_DECREF(job);
	     pthread_mutex_unlock(&job->mutex);
	     
             if(!KEEP_JOB) removeDriverJob(job);
	   }

	   write(fd, &count, INT_SIZE);
	 }
         return;

    case CLUSTER_GET_CONTEXT:
	 handleGetContext(conn);
         return;

    case HTTP_GET:
         {
             conn->type = WEB_CLIENT_CONN;
             handleHTTP_GET(conn);
             //printf("[Datanode@%s] handled cmd %d\n", Supr_hostname, cmd);
         }
         return;

    case CLUSTER_CONNECT_MASTER:
         {
           size_t size = read(fd, &cmd, sizeof(int));
	   int len;
           read(fd, &len, sizeof(int));
	   char addr[len];
           read(fd, addr, len);
	   int rc = 0;
           write(fd, &rc, sizeof(int));

	   char *s = strstr(addr, ":");
	   if(s) {
	     *s=0; s++;
	     int  port = atoi(s);

	     master_conn = socketOpen2(addr, port);
	     if(master_conn) {
		   master_conn->port = port;
		   master_conn->type = MASTER_CONN;
		   vectorAdd(socket_connections, master_conn); 

		   int msg[] = {DRIVER_REGISTER, driverServerConn->port};
                   int size = write(master_conn->fd, msg, sizeof(msg));

		   // Get PID?
		   {
		     int msg[] = {GET_CONN_PID};
                     int size = write(master_conn->fd, msg, sizeof(msg));
		     int pid;
                     read(master_conn->fd, &pid, sizeof(int));
		     master_conn->pid = pid;
		     /*
		     char buf[256];
		     sprintf(buf, "master->pid: %d\n", pid);
		     basic_info(buf);
		     */
		   }
		  
		   // verify...
	           int rc = Supr_checkLogin(master_conn->fd, master_conn, "master");
                   if(rc != 0){
                     error_info("%s:%d. FIXME: Supr_checkLogin(MASTER, *)",
                                    __func__, __LINE__);
                   }
	     }

	     

	     /*
	     sprintf(msg, "master: '%s:%d', master_conn: %p",
		   addr, port, master_conn);
	     basic_info(msg);
	     */
	   }

	   if(Supr_syncObject){
	     if(Supr_syncObject == &Supr_syncCond){
	       pthread_mutex_lock(&Supr_syncMutex);
	         pthread_cond_signal(&Supr_syncCond);
	       pthread_mutex_unlock(&Supr_syncMutex);
	     }
	   }

	   if(info_sc){
	     cmd = CLUSTER_CONNECT_MASTER; // connected to the master
             write(info_sc->fd, &cmd, sizeof(int));
             write(info_sc->fd, &len, sizeof(int));
             write(info_sc->fd, addr, len);
             read(info_sc->fd, &rc, sizeof(int));
	   }

         }
         return;

    case CLUSTER_CONNECT_DFSNAME:
         {
           size_t size = read(fd, &cmd, sizeof(int));
	   int len;
           read(fd, &len, sizeof(int));
	   char addr[len];
           read(fd, addr, len);
	   int rc = 0;
           write(fd, &rc, sizeof(int));

	   char *s = strstr(addr, ":");
	   if(s) { *s=0; s++;
	     int port = atoi(s);
	     DFS_namenode = socketOpen2(addr, port);
	     if(DFS_namenode) {
		   DFS_namenode->port = port;
		   DFS_namenode->type = DFS_NAMENODE_CONN;
		   vectorAdd(socket_connections, DFS_namenode); 

		   { 
		     int msg[] = {GET_CONN_PID};
                     int size = write(DFS_namenode->fd, msg, sizeof(msg));
		     int pid;
                     read(DFS_namenode->fd, &pid, sizeof(int));
		     DFS_namenode->pid = pid;
		     /*
		     char buf[256];
		     sprintf(buf, "master->pid: %d\n", pid);
		     basic_info(buf);
		     */
		   }

		   {
		     supr_socket_conn_t *sc = socketOpen2(DFS_namenode->host,
				     DFS_namenode->port);
		     DFS_namenode = sc;
		     //basic_info("Added another DFS_namenode, 01/03/2022");
		   }
		   
		   // verify...
	           int rc = Supr_checkLogin(DFS_namenode->fd, DFS_namenode, "DFS");
                   if(rc != 0){
                     error_info("%s:%d. FIXME: Supr_checkLogin(DFS, *)",
                                    __func__, __LINE__);
                   }
	     }

	     /*
	     sprintf(msg, "[%s:%d:%s] dfs_name: %s:%d, DFS_namenode: %p",
		   __FILE__, __LINE__, __func__, addr, port, DFS_namenode);
	     Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);
	     */
	   }

	   if(Supr_syncObject){
	     if(Supr_syncObject == &Supr_syncCond){
	       pthread_mutex_lock(&Supr_syncMutex);
	         pthread_cond_signal(&Supr_syncCond);
	       pthread_mutex_unlock(&Supr_syncMutex);
	     }
	   }

	   if(info_sc){
	     cmd = CLUSTER_CONNECT_DFSNAME; // connected to the dfs namenode
             write(info_sc->fd, &cmd, sizeof(int));
             write(info_sc->fd, &len, sizeof(int));
             write(info_sc->fd, addr, len);
             read(info_sc->fd, &rc, sizeof(int));
	   }
         }
         return;

    case CLUSTER_WORKER_STARTED:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
	   int len;
           read(fd, &len, sizeof(int));
	   char addr[len];
           read(fd, addr, len);
	   int rc = 0;
           write(fd, &rc, sizeof(int));

	   sprintf(msg, "[%s:%d:%s] worker: %s", __FILE__, __LINE__, __func__,
			   addr);
	   Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

	   if(Supr_syncObject){
	     if(Supr_syncObject == &Supr_syncCond){
	       pthread_mutex_lock(&Supr_syncMutex);
	         Supr_syncObject = strdup(addr);
	         pthread_cond_signal(&Supr_syncCond);
	       pthread_mutex_unlock(&Supr_syncMutex);
	     }
	   }

         }
         return;

    case CLUSTER_STATE: // DELETEME
    case CLUSTER_CONTEXT_OBJECTS:
         {
	   handleClusterList(conn, socket_connections);
	 }
	 return;

    case CLUSTER_CONTEXT_EXISTS:
         {
	   handleClusterExists(conn, socket_connections);
	 }
	 return;

    case CLUSTER_CONTEXT_PUT:
         {
	   handleClusterAssign(conn, socket_connections);
	 }
	 return;

    case CLUSTER_CONTEXT_GET:
         {
	   handleClusterContextGet(conn, socket_connections);
	 }
	 return;

    case CLUSTER_CONTEXT_DOCALL:
         {
	   handleClusterContextDoCall(conn, SuprEnv);
	 }
	 return;

    case SET_CONN_PID:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
	   int pid;
           read(fd, &pid, sizeof(int));
	   conn->pid = pid;
	   int type;
           read(fd, &type, sizeof(int)); // ?
	   conn->type = type;
	   //int rc = 0; write(fd, &rc, sizeof(int)); // ?
	 }
	 return;

    case CLUSTER_PROC_CMD:
         {
           read(fd, &cmd, INT_SIZE);
           int len;
           read(fd, &len, INT_SIZE);
           char buf[len + strlen(conn->host)+1 ];
           read(fd, buf, len);
           char *s = buf + strlen(buf);
           sprintf(buf + strlen(buf), "@%s", conn->host);
           s = strstr(s, ".");
           if(s) *s = '\000';
           conn->cmd = strdup(buf);
           if(Supr_options.verbose)
             fprintf(stderr, "\033[0;36m\n%s\t[INFO] Connected\033[0m\n",
                           conn->cmd);
           int rc = 0;
           write(fd, &rc, INT_SIZE);
         }
         return;

    case INFO_SERVER_REGISTER:
         {
           read(fd, &cmd, INT_SIZE);
           int len;
           read(fd, &len, INT_SIZE);
           char buf[len];
           read(fd, buf, len);

	   free((char*)info_addr);
	   info_addr = strdup(buf);

	   basic_info(buf);
	   basic_info("\033[0;36mClosing info_sc ...\033[0m");
	   pthread_mutex_lock(&Supr_syncMutex);
	     if(info_sc){
               close(info_sc->fd);
	       free(info_sc);
	       info_sc = NULL;
	     }
	     if(strstr(buf, ":")) {
	       info_sc = trySocketOpen1(buf);
	       if(info_sc){
        info_sc->mutex = malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(info_sc->mutex, NULL);
                 Supr_registerSocketServer(driverServerConn, info_sc);
		 cmd = CLUSTER_PROC_CMD;
		 write(info_sc->fd, &cmd, sizeof(int));
		 len = strlen(proc_cmd)+1;
		 write(info_sc->fd, &len, sizeof(int));
		 write(info_sc->fd, proc_cmd, len);
		 int rc;
		 read(info_sc->fd, &rc, sizeof(int));
	       }
	     }
	   pthread_mutex_unlock(&Supr_syncMutex);
           int rc = 0;
           write(fd, &rc, INT_SIZE);

	   // Propagate to master and dfs...
	   // TODO ...
	   /*
	   for(int i = vectorSize(socket_connections)-1; i>=0; i--)
           {
             supr_socket_conn_t * conn = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
             if(conn->type == MASTER_CONN || conn->type == DFS_NAMENODE_CONN){
	       write(conn->fd, &cmd, sizeof(int));
	       write(conn->fd, &len, sizeof(int));
	       write(conn->fd, buf, len);
	       read(conn->fd, &rc, len); //?
	     }

	   }
	   */

	 }
	 return;

    case INFO_SERVER_GET:
         {
           read(fd, &cmd, INT_SIZE);
	   pthread_mutex_lock(&Supr_syncMutex);
	     if(info_sc){
	       char buf[strlen(info_sc->host)+32];
	       sprintf(buf, "%s:%d", info_sc->host, info_sc->port);
	       int len = strlen(buf) + 1;
               write(fd, &len, INT_SIZE);
               write(fd, buf, len);
	     } else {
	       int len = 1;
	       char c = 0;
               write(fd, &len, INT_SIZE);
               write(fd, &c, len);
	     }
	   pthread_mutex_unlock(&Supr_syncMutex);
           int rc;
           read(fd, &rc, INT_SIZE);
	 }
	 return;

    case CLUSTER_MSG_SEND:
         {
           int header[3];
           read(fd, header, sizeof(header));
           int len_addr = header[1];
           int len_raw = header[2];
           void *msg = malloc(sizeof(header) + len_addr+len_raw);
           memcpy(msg, header, sizeof(header));
           read(fd, msg+sizeof(header), len_addr);
           ssize_t size = read(fd, msg+sizeof(header)+len_addr, len_raw);
           int rc = 0;
           write(fd, &rc, sizeof(int));

	   /*
           {
             char buf[256];
             sprintf(buf, "conn_type: %s", connTypeToStr(conn->type));
             basic_info(buf);
           }
	   */
	   /*
           for(int i=vectorSize(socket_connections)-1; i>=0; i--){
             supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
             if(sc->type == DRIVER_CONN){
               int flags = fcntl(fd, F_GETFL); // FIXME
               if(flags & O_NONBLOCK){
                       fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
               }
               write(sc->fd, msg, sizeof(header) + len_addr+len_raw);
               read(sc->fd, &rc, sizeof(int));
             }
           }
	   */

	   char *addr = (char*) msg+sizeof(header);
	   if(addr && strcmp(addr, "user") == 0 && info_sc){
             write(info_sc->fd, msg, sizeof(header) + len_addr+len_raw);
             read(info_sc->fd, &rc, sizeof(int));
	     free(msg);
	   } else if(addr && strcmp(addr, "*") == 0){ // broadcast
             for(int i=vectorSize(socket_connections)-1; i>=0; i--){
	       supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
	       if(sc->type == WORKER_CONN){
		 int flags = fcntl(fd, F_GETFL); // FIXME
		 if(flags & O_NONBLOCK){
                       fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
		 }
		 write(sc->fd, msg, sizeof(header) + len_addr+len_raw);
		 read(sc->fd, &rc, sizeof(int));
	       } 
	     }
	     free(msg);
	   } else if(addr && strstr(addr, ":") || TRUE){ // TO ...
	   //} else {
             pthread_mutex_lock(messages->mutex); // FIXME...
               vectorAdd(messages, msg);
             pthread_mutex_unlock(messages->mutex);
	   }
         }
         return;



    case DFS_NAMENODE_ADDR:
         {
	   read(fd, &cmd, sizeof(int));
           for(int i=vectorSize(socket_connections)-1; i>=0; i--){
	       supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
	       if(sc->type == DFS_NAMENODE_CONN){
		 char addr[strlen(sc->host) + 64];
		 sprintf(addr, "%s:%d", sc->host, sc->port);
		 int len = strlen(addr)+1;
		 write(fd, &len, sizeof(int));
		 write(fd, addr, len);
		 return;
	       } 
	   }

	   int rc = -1;
	   write(fd, &rc, sizeof(int));
	 }
	 return;

    case DFS_MASTER_ADDR:
         {
	   read(fd, &cmd, sizeof(int));
           for(int i=vectorSize(socket_connections)-1; i>=0; i--){
	       supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
	       if(sc->type == MASTER_CONN){
		 char addr[strlen(sc->host) + 64];
		 sprintf(addr, "%s:%d", sc->host, sc->port);
		 int len = strlen(addr)+1;
		 write(fd, &len, sizeof(int));
		 write(fd, addr, len);
		 return;
	       } 
	   }

	   int rc = -1;
	   write(fd, &rc, sizeof(int));
	 }
	 return;

    default:
	 {
	   int rc = Supr_handleCommand(cmd, conn);
	   if(rc == -1){
             removeConn(conn);
	     return;
	   } else if(rc == 0){
		 return;
	   }
	 }
         //printf("[%s:%d] unknown cmd = %d\n", __func__, __LINE__, cmd);
         error_info("[%s:%d] unknown cmd: %d", __func__, __LINE__, cmd);
	 //printConn(conn);
	 conn->print(conn);
	 break;
  }

  char c;
  //int cmd;
  //size_t size = read(fd, &c, 1);
  //size_t size = __read__(fd, &c, 1);
  /*
  int cmd;
  size_t size = read(fd, &cmd, sizeof(int));
  //printf("[%s] size = %ld\n", __func__, size);

  if(size == 0) {
    printf("[%s] fd = %d is disconnected\n", __func__, fd);
    vectorRemoveElement(socket_connections, conn);
    socketDestroy(conn);

    return;
  } else {
    printf("read [%s] size = %ld, cmd = %d\n", __func__, size, cmd);
  }
  */

  errno = 0;

  while(TRUE){
    size_t size = recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT);
    if(size == -1){
	    printf("[%s] size = -1, no data ? %s\n", __func__, strerror(errno));
	    if(errno == EBADF){
              printf("\033[0;31m[%s] fd = %d is disconnected\033[0m\n", __func__, fd);
              vectorRemoveElement(socket_connections, conn);
              socketDestroy(conn);
	    }
	    return;
    } else if(size == 0){
       /*These  calls  return  the  number  of bytes received, or -1 if an error
       occurred.  In the event of an error,  errno  is  set  to  indicate  the
       error.

       When a stream socket peer has performed an orderly shutdown, the return
       value will be 0 (the traditional "end-of-file" return).

       The value 0 may also be returned if the requested number  of  bytes  to
       receive from a stream socket was 0. 
       */
	    printf("[%s] size = 0, %d, %s\n", __func__, errno, strerror(errno));
	    if(errno){
              vectorRemoveElement(socket_connections, conn);
              socketDestroy(conn);
	    }
	    return;
    } else {
	    read(fd, &c, 1);
	    printf(" %0x", c);
    }
  }

}

#undef read

extern size_t fileWrite(const char*, char *, size_t);
extern char *fileRead(const char* file); 
extern supr_socket_conn_t *socketOpen2(const char *host, int port);

void  pthread_key_destructor(void *data)
{
	printf("[%s] data= %p\n", __func__, data);
}

shm_io_info_t *master_io = NULL;

SEXP __startMaster(const char *port, int *master_port, SEXP args);
SEXP startMaster(const char *port, int *master_port)
{
  return __startMaster(port, master_port, R_NilValue);
}
SEXP __startMaster(const char *port, int *master_port, SEXP args)
{
  if(!SUPR_HOMESYS) suprHomeInit();

  char shm_name[128];
  sprintf(shm_name, "supr.master-%d-%d",geteuid(), getpid());
  //printf("[%d] %s\n", getpid(), shm_name);

  //SEXP shm_conn = R_shmCreate
  /*
  size_t block_size = sysconf(_SC_PAGE_SIZE);
  shm_io_info_t *io = shm_io_create(shm_name, block_size);

  master_io = io;

  SEXP r_io = PROTECT(R_MakeExternalPtr(io, null, null));
  setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
  setAttrib(r_io, R_NameSymbol, mkString(shm_name));
  UNPROTECT(1);
  */

  static int count = 0;
  sleep(count*10); count++;

  /*
  pid_t pid = fork();
  if(pid) {
    fprintf(stderr, "%s: child proc %d is to run \"%s\"\n", __func__, pid,
		    SYS_COMMAND_MASTER);
    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: \"%s\"\033[0m\n", (char*) ptr);
    ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: serverSocket: port = %d\033[0m\n",
                    ((int*) ptr)[0]);
    *master_port = ((int*) ptr)[0];
    return r_io;
  }
  */


  char CMD_PATH[PATH_MAX]; //sprintf(CMD_PATH, "%s/master", SUPR_HOMESYS);
  sprintf(CMD_PATH, "%s/%s", SUPR_HOMESYS, SYS_COMMAND_MASTER);
  //printf("cmd path: %s\n", CMD_PATH);

  char *ld_lib_path = getenv("LD_LIBRARY_PATH");
  if(!ld_lib_path) ld_lib_path = "";
  char ld_path[strlen("LD_LIBRARY_PATH")+strlen(SUPR_HOMESYS)+strlen("libs")+5];
  //sprintf(ld_path,"LD_LIBRARY_PATH=\"%s/libs\"", SUPR_HOMESYS);
  sprintf(ld_path,"LD_LIBRARY_PATH=%s/libs", SUPR_HOMESYS);
  char cmd_master[strlen(SUPR_HOMESYS)+strlen("bin/master")+5];
  sprintf(cmd_master,"%s/bin/master", SUPR_HOMESYS);

  sprintf(CMD_PATH, "/usr/bin/env");

  {
    char *argv_b[] = {
	  CMD_PATH, "env", ld_path, cmd_master,
	  //CMD_PATH, SYS_COMMAND_MASTER,
	  "-port", (char*) port,
	  "-shm", shm_name,
	  "-usr", Supr_usrHome,
	  "-sys", Supr_sysHome,
          (char*) NULL
    };

    char **argv = Exec_createArgs( (const char**) argv_b, args);

    int i=0;
    int use_window = FALSE;
    for(; argv[i]; i++) {
      //printf("argv[%d] %s\n", i, argv[i]);
      if( (strcmp(argv[i], "-stdout")==0||strcmp(argv[i], "-master.stdout")==0)
		     && argv[i+1] && strcmp(argv[i+1],"--window")==0) {
	      use_window = TRUE;
	      i++;
      }
    }
    //printf("use_window: %d\n\n", use_window);
    //if(use_window) { argv[i] = "--window"; }

    void *retval;
    int rc;

    //char hostname[256];
    //gethostname(hostname, 256);
    char buf[strlen(Supr_hostname)+strlen("Master@")+1];
    sprintf(buf, "Master@%s", Supr_hostname);
    char *window_name = buf;

    rc = SuprNode_create(window_name, argv, use_window, 60, &retval);
    Exec_freeArgs(argv);

    if(rc == -1 || retval == NULL){
      warning("%s", strerror(errno));
      return R_NilValue;
    }

    //shm_io_info_t *io = shm_io_create(shm_name, block_size);
    shm_io_info_t *io = (shm_io_info_t *) retval;
    master_io = io;

    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    //fprintf(stderr, "\033[0;34mshm_read: \"%s\"\033[0m\n", (char*) ptr);
    free(ptr);

    ptr = shm_io_read(io, io->in, &size, NULL);
    //fprintf(stderr, "\033[0;34mshm_read, pid: %d\033[0m\n", *((int*) ptr));
    free(ptr);

    ptr = shm_io_read(io, io->in, &size, NULL);
    //fprintf(stderr, "\033[0;34mshm_read: serverSocket: port = %d\033[0m\n", ((int*) ptr)[0]);
    *master_port = ((int*) ptr)[0];
    free(ptr);

    SEXP r_io = PROTECT(R_MakeExternalPtr(io, null, null));
    setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
    setAttrib(r_io, R_NameSymbol, mkString(shm_name));
    UNPROTECT(1);

    {
	    int status;
	    // FIXME, waitpid ...
    }

    return r_io;
     
  }

  /*
  if(out && strlen(out)){
    int rc  = execl(CMD_PATH, "master",
                  "-port", port,
                  "-shm", shm_name,
                  "-out", out,
          (char*) NULL);
    printf("[%s] run master: rc =  %d, %s\n", __func__, rc, strerror(errno));
    exit(0);
  }
  */

#define USE_XTERM
#ifdef  USE_XTERM
  char *argv[] = {
	  CMD_PATH,
	  "-port", (char*) port,
	  "-shm", shm_name,
          (char*) NULL
  };
  //int argc = sizeof(args)/sizeof(char*);
  //supr_xterm_t *xterm = supr_xterm2("master", argv); 
  supr_xterm_t *xterm = supr_xterm2("Master", argv); 
  printf("[%s] run master: xterm =  %p, %s\n", __func__, xterm,
		  strerror(errno));
#else

  int rc  = execl(CMD_PATH, "master",
                  "-port", port,
                  "-shm", shm_name,
          (char*) NULL);
  printf("[%s] run master: rc =  %d, %s\n", __func__, rc, strerror(errno));
#endif 

#undef USE_XTERM

  exit(0);

}

// fixme
int ping(supr_socket_conn_t *conn, int timeout)
{

  {

    int error;
    socklen_t len = INT_SIZE;
    int retval = getsockopt(conn->fd, SOL_SOCKET, SO_ERROR, &error, &len);
    //printf("error: %d, retval: %d\n", error, retval);
    if(retval != 0){
              printf("error in getting socket error code: %s\n",
                              strerror(retval));
    } 
    if(error != 0){
              printf("socket error: %s\n", strerror(error));
    } 

  }

  int cmd = CLUSTER_PING; 
  int fd = conn->fd;
  int rc = write(conn->fd, &cmd, sizeof(int));

  //printf(" Write, size: %d, cmd: %d\n", rc, cmd);

  if(rc != sizeof(int)) return -1;

  {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec = timeout;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns == -1){
        printf("ns: %d, error: %s\n", ns, strerror(errno));
        return -1;
      } else if(ns == 0){
        printf("ns: %d, error: %s\n", ns, strerror(errno));
        return -1;
      } else {
        rc = __read__(fd, &cmd, sizeof(int));
        //printf("ns: %d, rc: %d, cmd: %d\n", ns, rc, cmd);
        return rc;
      }
  }


  /*
  for(int i=0; i < timeout; i++){
    rc = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
    if(rc>0) {
      rc = __read__(fd, &cmd, sizeof(int));
      printf(" size: %d, cmd: %d\n", rc, cmd);
      break;
    }
    printf("rc: %d, .\n", rc);
    sleep(5);
  }
  */
  return rc;
}

void backend_cleanup(void *arg)
{
	supr_thread_t *cth = SUPR_CURRENT_THREAD();
	cth->state = THREAD_STATE_TERMINATED;

	/*
  vector_t *conns = (vector_t *) arg;
  if(driverServerConn) {
    printf("close(driverServerSocket)\n");
    close(driverServerConn->fd);
  }

  if(!conns) return;
  for(int i= vectorSize(conns)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)vectorElementAt(conns,i);
    printf("close(//%s:%d)\n", sc->host, sc->port);
    close(sc->fd);
    sc->class->finalize(sc->class, sc);
    vectorRemove(conns,i);
  }
  */
}

extern SEXP connectDFSNamenode(SEXP hostname, SEXP sport);
//extern supr_socket_conn_t *DFS_namenode;

// FIXME
supr_socket_conn_t *Driver_connectDFSNamenode(int silent)
{
  BEGIN_R_EVAL();
    int errorOccurred;

  /*
    SEXP call = PROTECT(LCONS(install("dyn.load"),
			    CONS(mkString("libsupr.so"), R_NilValue)));
    R_simpleTryEval(call, R_GlobalEnv, &errorOccurred);
    if(errorOccurred){
      printf("errorOccurred: %s\n", R_curErrorBuf());
      SEXP tb = SYMVALUE(install(".Traceback"));
      if(tb != R_UnboundValue)
        PrintValue(tb);
    }
    UNPROTECT(1);
    */

    SEXP expr = PROTECT(LCONS(install(".Call"),
			   CONS(mkString("connectDFSNamenode"), CONS(R_NilValue,
				    CONS(R_NilValue, R_NilValue)))));
    SEXP DFSNamenode = R_simpleTryEval(expr, R_GlobalEnv, &errorOccurred);
    if(errorOccurred){
      //printf("errorOccurred: %s\n", R_curErrorBuf());
      //SEXP tb = SYMVALUE(install(".Traceback"));
      //if(tb != R_UnboundValue)
        //PrintValue(tb);
    } else {
      printf("DFSNamenode:\n");
      PrintValue(DFSNamenode);

//      DFS_namenode = (supr_socket_conn_t *)R_ExternalPtrAddr(DFSNamenode);
    }
    UNPROTECT(1);

  END_R_EVAL();

  /*
  if(!DFS_namenode){
    printf("DFS_namenode: %p, FIXME\n", DFS_namenode);
    exit(0);
  } else {
    printf("DFS_namenode: %s:%d\n", DFS_namenode->host, DFS_namenode->port);
  }
  */

  return DFS_namenode;
}

// start and connect

extern supr_socket_conn_t *Supr_startDFSNamenode();
#define Driver_startDFSNamenode() Supr_startDFSNamenode()

// start and connect
supr_socket_conn_t *deprecated_Driver_startDFSNamenode()
{
  printf("\033[0;32mStart DFS_namenode...\033[0m\n");
  //printf("[%s]\n", __func__);

  char *_stdout = NULL;
  int rc = 0;
#ifndef RUN_AS_DAEMON_PROC
  errno = 0;
  rc = isatty(STDOUT_FILENO);
  if(errno) {
          printf("[%s] Error: %s STDOUT_FILENO: %d (%s:%d)\n", __func__,
                          strerror(errno), STDOUT_FILENO,
                          __FILE__, __LINE__);
          return NULL;
  }
  if(rc){
    char buf[PATH_MAX];
    int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
    if(rc) {
          printf("[%s] Error: %s (%s:%d)\n", __func__, strerror(errno),
                          __FILE__, __LINE__);
          return NULL;
    }
    printf("ttyname: %s\n", buf);
  }

//  char *_window = NULL;
  //{
  for(int i=0; i<cmd_argc; i++){
      //printf("argv[%d]: %s\n", i, cmd_argv[i]);
      if(strcmp(cmd_argv[i], "-dfs.stdout")==0 && i < cmd_argc-1)
              _stdout = cmd_argv[++i];
  }
  if(!_stdout){
    for(int i=0; i<cmd_argc; i++){
      if(strcmp(cmd_argv[i], "-stdout")==0 && i < cmd_argc-1)
              _stdout = cmd_argv[++i];
    }
  }
  //}
#endif

  printf("_stdout: %s\n", _stdout);
  fflush(stdout);
  //sleep(5);

//#define USE_XTERM 1
  char mmap_io_name[256];
  sprintf(mmap_io_name, "driver-dnn.%d.%d", geteuid(), getpid());
  mmap_io_t *mmap_io = mmap_io_create(mmap_io_name);

  if(!mmap_io) {
    fprintf(stderr, "Error: mmap_io_create, %s\n", strerror(errno));
    //fflush(stderr);
    exit(EXIT_FAILURE);
    //return NULL;
  }

  fprintf(stderr, "lock: &mmap_io->lock\n");

  pthread_mutex_lock(&mmap_io->lock);

  pid_t pid = fork();

  if(pid == -1){
    fprintf(stderr, "Error: fork, %s\n", strerror(errno));
    return NULL;
  }

  if(pid) {

    printf("\033[0;34m[%s] Wait...\033[0m\n", __func__);
    fflush(stdout);

    pthread_cond_wait(&mmap_io->cond, &mmap_io->lock);
    char *addr = mmap_io->buf;


    char *host = strstr(addr, "//")+2;
    char *str = strstr(host, ":");
    *str = 0;
    int port = atoi(str+1);
    printf("[%s] Connect %s...\n", __func__, addr);
    supr_socket_conn_t *sc = socketOpen2(host, port);
    printf("[%s] sc: %p\n", __func__, sc);
    //sc->port = port;
    fflush(stdout);

    pthread_mutex_unlock(&mmap_io->lock);

    mmap_io_close(mmap_io);
    if(*mmap_io_name == '/') unlink(mmap_io_name);
    else shm_unlink(mmap_io_name);

    if(sc)
      sc->port = port;


    //pthread_cond_wait(&mmap_io->nonzero, &mmap_io->lock);

    return sc;
    //return NULL;
  }

  SocketConn_closeAll(socket_connections, 0);
  // more to do, Exec_afterFork(...);

  pid = getpid();
  char DFS_CMD_PATH[PATH_MAX];
  {
     //sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src");
     sprintf(DFS_CMD_PATH, "%s", SUPR_HOMESYS);
     chdir(DFS_CMD_PATH);
  }

  //sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src/dfs_name");
  sprintf(DFS_CMD_PATH, "%s/%s", SUPR_HOMESYS, SYS_COMMAND_DFS_NAMENODE);

  //char *dir_name = "00"; //to do
  char sport[64];
  //sprintf(sport, "%d", 0);
  //if(USE_XTERM && rc)

  printf("Child proc started\n");
  fflush(stdout);

  if(rc && _stdout && strcmp(_stdout, "--window")==0)
  {
  printf("Child proc started, hmm FIMXE\n");
  fflush(stdout);
    char *argv[] = {
          DFS_CMD_PATH,
	  "-mc", mmap_io_name,
	  (char*)NULL, (char*)NULL, // (char*)NULL, 
          (char*) NULL
      };

    if(_stdout){ // FIXME
      int i=0;
      for(; argv[i]; ) i++;
      argv[i] = "-dfs.stdout";
      argv[i+1] = _stdout;
    }
    /*
    if(_window){ // FIXME
      int i=0;
      for(; argv[i]; ) i++;
      argv[i] = _window;
    }
    */

    char hostname[256];
    gethostname(hostname, 256);
    char buf[strlen(hostname)+strlen("Namenode@")+1];
    sprintf(buf, "Namenode@%s", hostname);
    char *window_name = buf;

    int use_window = TRUE;

    supr_xterm_t *xterm = supr_xterm3(window_name, argv, use_window); //dnn vs ddn
    if(xterm) {
      printf("[%s] run dfs_name: xterm =  %p\n", __func__, xterm);
    } else {
      printf("[%s] run dfs_name: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
    }

    //exit(0);

  } else {
  printf("Child proc started, continue\n");
  fflush(stdout);
	  /*
    int rc = execl(DFS_CMD_PATH, SYS_COMMAND_DFS_NAMENODE, // "dfs_name",
		    "-mc", mmap_io_name,
                  (char*) NULL);
    printf("[%s] run dfs_name: rc =  %d, %s\n", __func__, rc, strerror(errno));
    */

  /*
    char ld_path[strlen("LD_LIBRARY_PATH")+strlen(SUPR_HOMESYS)+strlen("libs")+5];
    sprintf(ld_path,"LD_LIBRARY_PATH=%s/libs", SUPR_HOMESYS);
    char cmd_dfs_name[strlen(SUPR_HOMESYS)+strlen("bin/dfs_name")+5];
    sprintf(cmd_dfs_name,"%s/bin/dfs_name", SUPR_HOMESYS);

    fprintf(stderr, "Start DFS_name with ld_path: %s\n", ld_path);
    fflush(stderr);

    int rc = execl("/usr/bin/env", "env",
		    ld_path,  cmd_dfs_name,
		    "-mc", mmap_io_name,
                  (char*) NULL);
    printf("[%s] run dfs_name: rc =  %d, %s\n", __func__, rc, strerror(errno));
    */
    pid = fork();
    if(pid < 0){
      perror("fork");
      exit(EXIT_FAILURE);
    }

    if(pid){
      Supr_message = (char*) malloc(256);
      sprintf(Supr_message, "[%s] Child proc %d of this proc %d is running dfs_name",
                    __func__, pid, getpid());
      int status;
      printf("waitpid: Wait\n");
      errno = 0;
      int rc = waitpid(pid, &status, 0);

      printf("(%s:%d) waitpid(%d, ...), rc: %d, err: %s\n",
                    __FILE__, __LINE__,
                    pid, rc, strerror(errno));
      printf("status: %d\n", status);
      if(status && WIFEXITED(status)) {
        printf("WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
      }
      fflush(stdout);

    } else {
      char cmd_path[PATH_MAX];
      sprintf(cmd_path, "%s/bin/%s", SUPR_HOMESYS, SYS_COMMAND_DFS_NAMENODE);
      int rc = execl(cmd_path,  SYS_COMMAND_DFS_NAMENODE,
		    "-mc", mmap_io_name,
                  (char*) NULL);
      printf("[%s] run dfs_name: rc =  %d, %s\n", __func__, rc, strerror(errno));
      exit(EXIT_FAILURE);
    }

  }

    exit(0);
  return NULL;

#undef USE_XTERM 
}

#define SIGNAL_CLUSTER_COND 7001


int backend_run(int port, sem_t *sem, supr_thread_t* th,
		supr_socket_conn_t *info_server)
{
//  pthread_cleanup_push(backend_run_cleanup, NULL);

  //sprintf(msg, "pid: %d", getpid());
  //basic_info(msg);
  //basic_info(__func__);

  pthread_cleanup_push(backend_cleanup, socket_connections);

  supr_socket_conn_t *serverConn = serverSocketOpen3(port, nports, cmd);

  if(!serverConn){
    if(notify_addr)
	    Supr_notify(notify_addr, Supr_hostname,  CLUSTER_CONNECT_DRIVER);
    exit(EXIT_FAILURE);
  }

  Supr_options.port = serverConn->port;


  serverConn->cmd = strdup("server");

  //basic_info(__func__);

  Supr_registerSocketServer(serverConn, info_sc);
  driverServerConn = serverConn;

  /*
  supr_socket_conn_t *serverConn;
  if( reuse_addr)
    serverConn = serverSocketOpen(port, reuse_addr);
  else
    serverConn = serverSocketOpen3(port, reuse_addr, cmd);
    */
  /*
  {
    char buf[128];
    sprintf(buf, "port: %d, serverConn: %s:%d", port,
			  serverConn->host, serverConn->port);
    Cluster_sendSimpleMessage(buf, "\033[0;33m", 0, 0);
  }
  */
  driverServerConn->type = DRIVER_CONN;
  driverServerConn->pid  = gettid();

  {
    th->conn = serverConn;
    pthread_mutex_lock(&th->mutex);
      sem_post(sem);
      pthread_cond_wait(&th->cond, &th->mutex);
    pthread_mutex_unlock(&th->mutex);
  }

  if(info_server) {
    info_sc = socketOpen2(info_server->host, info_server->port);
    cmd_argc = 1;
  }

  /*
  if(info_sc){
    //Cluster_sendSimpleMessage(__func__, "\033[0;33m", 0, 0);
    int fd = info_sc->fd;

    int cmd = CLUSTER_INFO;
    write(fd, &cmd, sizeof(int));

    char buf[8]; sprintf(buf, "\033[0;33m");
    write(fd, buf, sizeof(buf));
    int type = -1;
    write(fd, &type, sizeof(int));
    cmd = SIGNAL_CLUSTER_COND;
    write(fd, &cmd, sizeof(int));

    char msg[strlen(serverConn->host)+32];
    sprintf(msg, "%s:%d", serverConn->host, serverConn->port);
    ssize_t len = strlen(msg)+1;
    write(fd, &len, sizeof(ssize_t));
    write(fd, msg, len);
    int rc;
    read(fd, &rc, sizeof(int));
  }
  */


  {
    char fileName[strlen(SUPR_HOMEUSR)+strlen("/driver.log")+1];
    sprintf(fileName, "%s/driver.log", SUPR_HOMEUSR);
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\npid:%d\n", serverConn->port, getpid());
    size_t size = fileWrite(fileName, buf, strlen(buf)+1);
    //Cluster_sendSimpleMessage(buf, msg_color, 0, 0);
  }

  //Cluster_sendSimpleMessage(__FILE__, "\033[0;33m", 0, 0);


  socket_connections = newVector(TRUE);
  vectorAdd(socket_connections, serverConn); 


  /*
  if(master_addr && tryPingSocketServer1((char*)master_addr)==CLUSTER_PONG){
    master_conn = socketOpen1((char*)master_addr);
		   master_conn->port = port;
		   master_conn->type = MASTER_CONN;
    int msg[] = {DRIVER_REGISTER, serverConn->port};
    int size = write(master_conn->fd, msg, sizeof(msg));
    vectorAdd(socket_connections, master_conn); 

  }
  */

#define __BACKEND_START_MASTER 
#ifdef __BACKEND_START_MASTER 
  //
  if(!master_addr) {
      BEGIN_R_EVAL();
        SEXP addr = findVar(install("master"), SuprContextEnv);
	if(addr == R_UnboundValue)
	  master_addr = Supr_hostname;
	else 
	  master_addr = CHAR(asChar(addr));
      END_R_EVAL();
  }

  if(!strstr(master_addr, "+")){

    verbose_info("Check and connect to existing master://%s", master_addr);

    int pong = tryPingSocketServer1(master_addr);
    if(pong == CLUSTER_PONG){
      //master_conn = socketOpen1(master_addr);
      master_conn = trySocketOpen1(master_addr);
      if(master_conn){
	  master_conn->port = atoi(strstr(master_addr, ":")+1);
	  master_conn->type = MASTER_CONN;
	  int msg[] = {DRIVER_REGISTER, serverConn->port};
	  int size = write(master_conn->fd, msg, sizeof(msg));
          vectorAdd(socket_connections, master_conn); 

	  Cluster_sendSimpleMessage("connected to the master", msg_color,
			  BASIC_INFO_TYPE, 0);

	  int cmd = GET_CONN_PID;
	  write( master_conn->fd, &cmd, sizeof(int));
	  pid_t pid;
	  read( master_conn->fd, &pid, sizeof(int));
	  master_conn->pid = pid;

      }
    }
    if(!master_conn)
      basic_info("\033[0;33mcannot connect to master \"%s\"\033[0m",
		      master_addr);
    else { // verify...
	          int rc = Supr_checkLogin(master_conn->fd, master_conn, "master");
                  if(rc != 0){
                    error_info("%s:%d. FIXME: Supr_checkLogin(MASTER, *)",
                                    __func__, __LINE__);
                  }
    }
  } else {
    verbose_info("To start master://%s by the main thread", master_addr);
  }
    //
   
#else //__BACKEND_START_MASTER 
  int new_master = FALSE;

  for (int ii=0; ; ii++){

    //printf("\033[0;32m\n\n%d. Connect to master ...\033[0m\n", ii+1);
    //{
    char fileName[strlen(SUPR_HOMEUSR)+strlen("/master.log")+1];
    sprintf(fileName, "%s/master.log", SUPR_HOMEUSR);
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\n", serverConn->port);
    char *addr = fileRead(fileName);

    if(addr) {

      //printf("master.log: %s\n", addr);
      if(strncmp(buf, addr, len+1)==0){
        char *str = strstr(addr, "\npid:");
        pid_t master_pid  = atoi(strstr(str, ":")+1);
        //printf("same machine with pid: %d\n", master_pid);
        int rc = kill(master_pid, 0);
        if(rc == -1) {
          //printf("kill(%d, 0): %s\n", master_pid, strerror(errno));
	  addr = NULL;
        } /*else {
          printf("kill(%d, 0): %d\n", master_pid, rc);
        } */
      }
    }

    if(ii>0) addr = NULL;

    if(addr){
      char *str = strstr(addr, ":");
      int master_port = atoi(str+1);
      *str = 0;
      char *host = strstr(addr, "//")+2;
      master_conn = socketOpen2(host, master_port);
      if(master_conn && master_conn->fd != -1)
      {
	  master_conn->type = MASTER_CONN;
	  master_conn->port = master_port;
	  /*
	  master_conn->mutex = (pthread_mutex_t*)
		  malloc(sizeof(pthread_mutex_t));
	  pthread_mutex_init(master_conn->mutex, NULL);
	  */

	  int msg[] = {DRIVER_REGISTER, serverConn->port};
	  int size = write(master_conn->fd, msg, sizeof(msg));

	  printf("[Driver:%s] size = %d (%ld)\n", __func__, size,
			  sizeof(msg));
	  if(size == -1){
	    printf("Warning: %s\n", strerror(errno));
	    // destroy?
	    master_conn = NULL;
	  } else {
	    printf("Connected to master: //%s:%d\n", master_conn->host,
			    master_conn->port);
            vectorAdd(socket_connections, master_conn); 

	  }
//#undef DRIVER_REGISTER
      }
      //connections[conn->fd] = (supr_conn_t*) conn;
    }

  Cluster_sendSimpleMessage(__func__, "\033[0;33m", 0, 0);

    if(!master_conn){
      fprintf(stderr, "%d. Start master ...\n", __LINE__);
      new_master = TRUE;
      fprintf(stderr, "%d. Start master ...\n", __LINE__);
  Cluster_sendSimpleMessage("OKAY 0", "\033[0;33m", 0, 0);
      BEGIN_R_EVAL();
      fprintf(stderr, "%d. Start master ...\n", __LINE__);

  Cluster_sendSimpleMessage("OKAY 1", "\033[0;33m", 0, 0);
        SEXP args = PROTECT(CONS(R_NilValue, R_NilValue));
      fprintf(stderr, "%d. Start master ...\n", __LINE__);
	SEXP s = args;
	{
          for(int i=1; i<cmd_argc; i++) {
		  /*
            if(strcmp(cmd_argv[i], "--window")==0){
              SETCDR(s, CONS(mkString(cmd_argv[i]), R_NilValue));
	      s = CDR(s);
	    } else */
		  /*
	    if(strcmp(cmd_argv[i], "-stdout") && i < cmd_argc-1){
              SETCDR(s, CONS(mkString(cmd_argv[i+1]), R_NilValue));
	      s = CDR(s);
              SET_TAG(s, install(cmd_argv[i]+1));
	      i++;
	    } else if(strstr(cmd_argv[i], "-master") && i < cmd_argc-1){
              SETCDR(s, CONS(mkString(cmd_argv[i+1]), R_NilValue));
	      s = CDR(s);
	      if(strcmp("-master.stdout", cmd_argv[i]) 
			      || strcmp("--window", cmd_argv[i+1]) )
                SET_TAG(s, install(cmd_argv[i]+1));
	      i++;
	    }  else */
	    if(i < cmd_argc-1){
	      if(   strcmp(cmd_argv[i], "-stdout") == 0
	         || strcmp(cmd_argv[i], "-master.stdout") == 0
	         || strcmp(cmd_argv[i], "-worker.stdout") == 0
	         || strcmp(cmd_argv[i], "-taskrunner.stdout") == 0
	         || strcmp(cmd_argv[i], "-verbose") == 0
	         || strncmp(cmd_argv[i], "-nt", 3) == 0
	       	){

                SETCDR(s, CONS(mkString(cmd_argv[i+1]), R_NilValue));
	        s = CDR(s);
                SET_TAG(s, install(cmd_argv[i]+1));
	        i++;
	      }
	    }
	  }
          //printf("\n\033[0;33mstartMaster:\n");
	  //PrintValue(args);
	}
      //printf("\n\033[0;33mstartMaster:\n");
	int master_port;
        //SEXP shm_conn = startMaster("0", &master_port);

      fprintf(stderr, "%d. Start master ...\n", __LINE__);
  Cluster_sendSimpleMessage("Starting Master ...", "\033[0;33m", 0, 0);

        SEXP shm_conn = __startMaster("-1", &master_port, CDR(args));
	UNPROTECT(1);
  Cluster_sendSimpleMessage("Started Master!", "\033[0;33m", 0, 0);

      //printf("\n\033[0;33mstartMaster master_port = %d:\n", master_port);
       // PrintValue(shm_conn);
        defineVar(install("shm_conn"), shm_conn, R_GlobalEnv);
      //printf("\033[0m\n");

        master_conn = socketOpen2("localhost", master_port);
      fprintf(stderr, "%d. master_conn: %p\n", __LINE__, master_conn);
        if(master_conn && master_conn->fd != -1)
	{
//          vectorAdd(socket_connections, master_conn); 
//#define MASTER_CONN 3
	  master_conn->type = MASTER_CONN;
	  master_conn->port = master_port;
//#undef MASTER_CONN
//#define DRIVER_REGISTER 11
	  int msg[] = {DRIVER_REGISTER, serverConn->port};
	  int size = write(master_conn->fd, msg, sizeof(msg));
	  //printf("[Driver:%s] size = %d (%ld)\n", __func__, size, sizeof(msg));
	  if(size == -1){
	    printf("[Driver:%s] Error,  %s\n", __func__, strerror(errno));
	    // destroy?
	    master_conn = NULL;
	  } else {
            vectorAdd(socket_connections, master_conn); 

	  }
//#undef DRIVER_REGISTER

	  Driver_startedMaster = TRUE;
	} else {
          printf("Warning: cannot open socket... master_conn : %p\n"
			  "Error: %s\n", master_conn, strerror(errno));
	  sleep(600);
	}

      END_R_EVAL();


    }

      fprintf(stderr, "%d. master_conn: %p\n", __LINE__, master_conn);
  Cluster_sendSimpleMessage(__FILE__, "\033[0;33m", 0, 0);

    if(master_conn){
      //printf("\033[0;32m[%s] Master connection: %s:%d\033[0m\n", __func__, master_conn->host, master_conn->port);
      //int rc = ping(master_conn, 5);
      int rc = ping(master_conn, 13*60);

      if(rc>0) break;
    }
    master_conn = NULL; // destroy...

    if(ii>2) {
	    printf("Error: cannot connect to master\n");
	    break;
    } 
  //}

  }

  if(master_conn && strcmp(master_conn->host, "localhost")==0){
    char buf[256];
    gethostname(buf, 256);
    master_conn->host = strdup(buf);
  }

  // connectDFSNamenode
  Cluster_sendSimpleMessage(__func__, "\033[0;33m", 0, 0);

  if(master_conn) {
    fprintf(stderr, "Connected to master: //%s:%d\n", master_conn->host,
		    master_conn->port);
    printf("Connected to master: //%s:%d\n", master_conn->host,
		    master_conn->port);

    if(user_io){
      int rc = 1; // some positive integer
      shm_io_write(user_io, user_io->out, &rc, INT_SIZE);
      char msg[256];
      sprintf(msg, "%sconnected to master://%s:%d",
        new_master ? "started and ":"",
      	master_conn->host, master_conn->port);
      shm_io_write(user_io, user_io->out, msg, strlen(msg)+1);
    }
  }

  master_conn->mutex = (pthread_mutex_t*) malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(master_conn->mutex, NULL);


  if(notify_mutex){ // FIXME
    pthread_mutex_lock(notify_mutex);
      pthread_cond_signal(notify_cond);
    pthread_mutex_unlock(notify_mutex);
  }

  printf("Connect to DFS_namenode ...\n");
  Cluster_sendSimpleMessage("Connect to DFS_namenode ...\n", "\033[0;33m", 0, 0);

  supr_socket_conn_t *dfs_namenode = NULL;
  char path[PATH_MAX];

  if(Supr_dfsHome)
    sprintf(path, "%s/dfs_name.log", Supr_dfsHome);
  else if(Supr_usrHome)
    sprintf(path, "%s/dfs_name.log", Supr_usrHome);
  else 
    sprintf(path, "%s/.supr/dfs_name.log", getenv("HOME"));

  int new_dfs_name = FALSE; 
  if(access(path, F_OK)==0)
  {
    printf("Connect to dfs_name in %s ...\n", path);
    dfs_namenode = Driver_connectDFSNamenode(TRUE);
    printf("dfs_namenode: %p\n", dfs_namenode);
  }
#endif // __BACKEND_START_MASTER

#define __BACKEND_START_DFSNAME
#ifdef __BACKEND_START_DFSNAME
  //
  if(!dfs_addr) {
      BEGIN_R_EVAL();
        SEXP addr = findVar(install("dfs"), SuprContextEnv);
	if(addr == R_UnboundValue)
	  dfs_addr = Supr_hostname;
	else 
	  dfs_addr = CHAR(asChar(addr));
      END_R_EVAL();
  }

  if(!strstr(dfs_addr, "+")){

    verbose_info("Check and connect to DFS namenode://%s", dfs_addr);

    int pong = tryPingSocketServer1(dfs_addr);
    if(pong == CLUSTER_PONG){
      //DFS_namenode = socketOpen1(dfs_addr);
      DFS_namenode = trySocketOpen1(dfs_addr);
      if(DFS_namenode){
        DFS_namenode->type = DFS_NAMENODE_CONN;
        DFS_namenode->port = atoi(strstr(dfs_addr,":")+1);
        vectorAdd(socket_connections, DFS_namenode);

	int cmd = GET_CONN_PID;
	write( DFS_namenode->fd, &cmd, sizeof(int));
	pid_t pid;
	read( DFS_namenode->fd, &pid, sizeof(int));
	DFS_namenode->pid = pid;

	Cluster_sendSimpleMessage("connected to the dfs", msg_color,
			  BASIC_INFO_TYPE, 0);
		   {
		     supr_socket_conn_t *sc = socketOpen2(DFS_namenode->host,
				     DFS_namenode->port);
		     DFS_namenode = sc;
		     basic_info("Added another DFS_namenode, 01/03/2022");
		   }
      }
    }
    if(!DFS_namenode)
      basic_info("\033[0;33mcannot connect to dfs \"%s\"\033[0m", dfs_addr);
    else { // verify...
	          int rc = Supr_checkLogin(DFS_namenode->fd, DFS_namenode, "DFS");
                  if(rc != 0){
                    error_info("%s:%d. FIXME: Supr_checkLogin(DFS, *)",
                                    __func__, __LINE__);
                  }
    }
    
  } else {
    verbose_info("To connect DFS namenode://%s by the main thread", dfs_addr);
  }
    //
#else //__BACKEND_START_DFSNAME
  if(!dfs_namenode) {
    dfs_namenode = Driver_startDFSNamenode();
    new_dfs_name = TRUE;
  }

  if(dfs_namenode){

    //printf("dfs_namenode->type: %s\n", connTypeToStr(dfs_namenode->type));
    //printf("dfs_namenode->port: %d\n", dfs_namenode->port);

    vectorAdd(socket_connections, dfs_namenode);

    dfs_namenode->type = DFS_NAMENODE_CONN;
    //DFS_namenode = dfs_namenode;
    DFS_namenode = socketOpen2(dfs_namenode->host, dfs_namenode->port);
    if(DFS_namenode){
      DFS_namenode->type = DFS_NAMENODE_CONN; // why two connections, fixme
      DFS_namenode->port = dfs_namenode->port;
    } else {
      printf("Cannot connect to DFS_Namenode\n");
    }
  }

  if(DFS_namenode){
    printf("Connected to DFS_namenode: //%s:%d\n",
		  DFS_namenode->host, DFS_namenode->port);
  } else {
    printf("Error: Cannot connect to DFS_namenode\n");
  }

  if(user_io){
    int rc = 1; // some positive integer
    shm_io_write(user_io, user_io->out, &rc, INT_SIZE);
    char msg[256];
    if(DFS_namenode)
      sprintf(msg, "%sconnected to dfs_name://%s:%d",
	new_dfs_name ? "started and ":"",
      	DFS_namenode->host, DFS_namenode->port);
    else
      sprintf(msg, "cannot connect to dfs_name *****");
    shm_io_write(user_io, user_io->out, msg, strlen(msg)+1);
  }
#endif //__BACKEND_START_DFSNAME

  /*
  scToBackend = socketOpen(driverServerConn);
  scToBackend->mutex = malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(scToBackend->mutex, NULL);

  scToBackend->type = DRIVER_CONN;
  scToBackend->pid = getpid();
  scToBackend->cmd = strdup("connToBackend");

  {
    int msg[] = {SET_CONN_PID, (int)syscall(SYS_gettid), DRIVER_CONN};
    write(scToBackend->fd, msg, sizeof(msg));
  }
  */

  //// FIXME?////
  //vectorAdd(socket_connections, scToBackend); 
  /*
    {
	  char buf[256];
	  sprintf(buf, "\033[0;31mvectorSize(socket_connections): %d [%d]\033[0m",
			  vectorSize(socket_connections), __LINE__);
          Cluster_sendSimpleMessage(buf, msg_color, 0, 0);
    }
    */

  ////
  /*
  if(info_sc) {
    info_sc->type= INFO_CONN;
    vectorAdd(socket_connections, info_sc);
  }
  */

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);


  /*
  if(!DFS_namenode || !master_conn) {
    SuprErr_set("init error");
    int rc = -1;
    pthread_exit(&rc);
  }
  */

  /*
  if(notify_addr){
    supr_socket_conn_t *sc = socketOpen1(notify_addr);
    if(sc){
            int cmd = CLUSTER_CONNECT_DRIVER;
            write(sc->fd, &cmd, sizeof(int));
            char buf[strlen(serverConn->host)+32];
            sprintf(buf, "%s:%d", serverConn->host,
                            serverConn->port);
            int len = strlen(buf)+1;
            write(sc->fd, &len, sizeof(int));
            write(sc->fd, buf, len);
            int rc;
            read(sc->fd, &rc, sizeof(int));
            sprintf(msg, "Sent driver_addr %s to %s", buf, notify_addr);
            Cluster_sendSimpleMessage(msg, "\033[0;34m", BASIC_INFO_TYPE, 0);
            close(sc->fd);
            free(sc);
    } else {
            sprintf(msg, "Cannot connect to %s", notify_addr);
            Cluster_sendSimpleMessage(msg, "\033[0;34m", ERROR_INFO_TYPE, 0);
    }
  }
  */

  while(TRUE) {
      struct timeval tv;
      tv.tv_sec=1000;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      //int fd = serverConn->fd;
      int max_fd = 0;

      // lock ...
//      printf("\n");
      for(int i=0; i<vectorSize(socket_connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 

	//conn->print(conn);
        int fd = conn->fd;
        FD_SET(fd, &readfds);

	if(fd > max_fd) max_fd = fd;
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            printf("Warning (%s): select()=%d\n", __func__, ns);
      }

      for(int i = vectorSize(socket_connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
	       	continue;

	if(conn == serverConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(serverConn);
          //printf("[Driver:%s] clientConn->fd = %d\n", __func__, clientConn->fd);

	  if(clientConn && clientConn->fd != -1){
	    if(localhost && strcmp(clientConn->host, "localhost")==0)
		    clientConn->host = strdup(localhost);
            vectorAdd(socket_connections, clientConn); 

	    if(Supr_options.verbose) {
	      int flags = fcntl(fd, F_GETFL);
	      char buf[256];
	      sprintf(buf, "new connection '%s:%d', blocking status: \033[0;33m%s\033[0m",
			      clientConn->host, clientConn->port,
			      flags & O_NONBLOCK ? "non-blocking":
			      "blocking");
	      verbose_info(buf);
	    }
	  }
	} else {
          handleCommand(conn);
	}
      }

      //sleep(1);
  }



  sleep(60);
//  int k = FOPEN_MAX;

  pthread_cleanup_pop(TRUE);

  return 0;

}

//extern supr_thread_t *newThread(pthread_t ptid, pid_t, pid_t tid, int state);

void  timedwait_thread_run();

void timedwaitThreadRun_cleanup(void *data)
{
	supr_thread_t *cth = SUPR_CURRENT_THREAD();
	cth->state = THREAD_STATE_TERMINATED;
}

void *timedwaitThreadRun(void *arg)
{
  pthread_cleanup_push(timedwaitThreadRun_cleanup, NULL);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[0];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[1];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &sem);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  timedwait_thread_run();

  pthread_exit(th);
  pthread_cleanup_pop(TRUE);
  return NULL;
}

/*
void backend_cleanup(void *arg)
{
	fprintf(stderr, "[%s:%d:%s] exists\n", __FILE__, __LINE__, __func__);
	exit(EXIT_FAILURE); // TODO
}
*/

void *backendRun(void *arg)
{

  void *data = (void*) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  supr_socket_conn_t *info_server = (supr_socket_conn_t *) ((void **)arg)[3];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;
  pthread_setspecific(currentThreadKey, th);

  int port = ((int*)data)[0];

/*
  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);
*/

  //backend_run(port);
  pthread_cleanup_push(backend_cleanup, th);
    backend_run(port, sem, th, info_server);
  pthread_cleanup_pop(TRUE);

  pthread_exit(th);
  return NULL;
}

SEXP jobSubmit(SEXP);
SEXP help(SEXP);
SEXP clusterShutdown(SEXP);

typedef struct callable_struct {
  char *name;
  char *par_names;
  SEXP (*func)(SEXP args); // args: pairlist
  char *doc;
} callable_t;

callable_t R_callable_functions[] =
{
  { "help",   "(topic)",   help, "..." },
  { "shutdown",   "()",   clusterShutdown, "..." },
  { "submit", "(expr, data, ...)", jobSubmit, "..." },
};

SEXP jobSubmit(SEXP args){
  return R_NilValue;
}

SEXP help(SEXP topic){
  if(TYPEOF(topic) == NILSXP){
    return mkString("TO DO");
  } else {

    PrintValue(topic);

    const char *name = CHAR(asChar(topic));
    for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
      if(strcmp(R_callable_functions[i].name, name)==0){
        return mkString(R_callable_functions[i].doc);
      }
    }
    errorcall(R_NilValue, "no doc is available on '%s'", name);
    return R_UnboundValue;

  }
}

SEXP clusterShutdown(SEXP args){

  int cmd = CLUSTER_SHUTDOWN;
  for(int i=1; i<vectorSize(socket_connections); i++){
      
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
         vectorElementAt(socket_connections, i);

    write(conn->fd, &cmd, sizeof(int));
  
  }

  system_exit(cmd);

  return R_NilValue;
}


extern int (*shm_io_readInt)(shm_io_info_t *io);

// for checking
/*
void printSO(so_t *so)
{
  //switch(so->obj_type){
    BEGIN_R_EVAL();
      SEXP val = PROTECT(R_bytesToObject(so+1, so->size));
      PrintValue(val);
      UNPROTECT(1);
    END_R_EVAL();
  //}
}
*/

int vectorHasNext(void *data)
{ //	printf("[%s] data=%p\n", __func__, data);
  vector_t *vec = (vector_t *) data;
  return vec->size;
}
void *vectorNext(void *data)
{
  vector_t *vec = (vector_t *) data;
  int i = vec->size-1;
  void *elem = vectorElementAt(vec, i);
  vectorRemove(vec, i);
  return elem;
}
//void *vectorNext2(void *data, void *pref) { return vectorNext(data); }

extern class_t *Iterator_class;

iterator_t *vectorToIterator(vector_t *vec){

	/*
  iterator_t *iter = (iterator_t*) malloc(sizeof(iterator_t));
  
  iter->class = Iterator_class;
  iter->ref_count = REF_COUNT_INITIALIZER;
  iter->padding = 0;

  iter->hasNext =  vectorHasNext;
  iter->next =  vectorNext;
  iter->next2 = NULL;
  iter->data =  vec;
  */

  iterator_t *iter =  newIterator(vectorHasNext, vectorNext, vec);
  iter->next2 = NULL;

//	printf("[%s] iter=%p\n", __func__, iter);
  return iter;
}


typedef struct {

  class_t *class;
  int ref_count;
  int padding;

  char *name;
  int nlevels;
  int nsubsets;
  char **levels;
  char **subsets;
  unsigned char **locations;
  int init_nsubsets; // FIXME?
} dd_list_t;

/*
void DD_print(dd_list_t *list)
{
  fprintf(stdout, "list: %p, name: %s\nnlevels: %d\n", list, list->name, list->nlevels);
  for(int i=0; i<list->nlevels; i++){
    fprintf(stdout, "\t%d. %s\n", i+1, list->levels[i]);
  }

  fprintf(stdout, "nsubsets: %d\n", list->nsubsets);
  for(int i=0; i<list->nsubsets; i++){
    fprintf(stdout, "\t%d. %s\t", i+1, list->subsets[i]);
    for(int j=0; j<list->nlevels; j++){
      fprintf(stdout, " %d", list->locations[i][j]);
      fprintf(stdout, "\n");
    }
  }
}
*/

static const char *DD_listToString(class_t *class, void *data)
{
  return "DDList object";
}

static void DD_listFinalize(class_t *class, void *object)
{
  dd_list_t *list = (dd_list_t *) object;

  fprintf(stderr, "\033[0;34m[%s] Start\n", __func__);
  fprintf(stderr, "\033[0;34m[%s] list->nsubsets: %d\n", __func__,
		  list->nsubsets);
  fprintf(stderr, "\033[0;34m[%s] list->init_nsubsets: %d\n", __func__,
		  list->init_nsubsets);

  //for(int i=0; i<list->nsubsets; i++) free(list->locations[i]);
  for(int i=0; i<list->init_nsubsets; i++) free(list->locations[i]);
  free(list->locations);

  free(list->subsets);
  free(list->levels);

  fprintf(stderr, "[%s] free(list)...\n", __func__);
  free(list);
  fprintf(stderr, "[%s] TODO\n", __func__);
  fprintf(stderr, "[%s] Done!\033[0m\n", __func__);
}

class_t *DDList_class = NULL;

dd_list_t *newDDList(SEXP dd, const char *name)
{
fprintf(stderr, "LINE: %d\n", __LINE__); fflush(stderr);
  if(!DDList_class){
    DDList_class = newClass("DDList", DD_listToString, DD_listFinalize);
  }

  SEXP subsets = VECTOR_ELT(dd, 0);
  int n = LENGTH(dd) - 5; // FIXME
  SEXP levels = getAttrib(dd, install("data.nodes"));
  dd_list_t *list = (dd_list_t *) malloc(sizeof(dd_list_t));

  list->class = DDList_class;
  list->ref_count = REF_COUNT_INITIALIZER;
  list->padding = 0;

  list->name = strdup(name); // fixme

  list->nlevels = LENGTH(levels);
  list->levels = (char **)malloc(list->nlevels*sizeof(char*));
  for(int i=0; i<list->nlevels; i++)
	  list->levels[i] = (char*) CHAR(STRING_ELT(levels,i));

  list->nsubsets = LENGTH(subsets); 
  list->init_nsubsets = list->nsubsets;  
  list->subsets = (char **)malloc(list->nsubsets*sizeof(char*));
  for(int i=0; i<list->nsubsets; i++)
	  list->subsets[i] = (char*) CHAR(STRING_ELT(subsets,i));

  list->locations = (unsigned char **)
	  malloc(list->nsubsets*sizeof(unsigned char *));
  for(int i=0; i<list->nsubsets; i++) {
    list->locations[i] = malloc(list->nlevels*sizeof(unsigned char));
  }
  for(int k=0; k<list->nlevels; k++){
    SEXP col = VECTOR_ELT(dd, k+4);
    int *indicator  = INTEGER(col);
    for(int i=0; i<list->nsubsets; i++)
      list->locations[i][k] = indicator[i]==1;
  }

fprintf(stderr, "LINE: %d\n", __LINE__); fflush(stderr);
  //DD_print(list);
  return list;
}

int DD_hasNext(void *data)
{ //	printf("[%s] data=%p\n", __func__, data);
  dd_list_t *list = (dd_list_t *) data;
  return list->nsubsets;
}
void *DD_next2(void *data, void *pref)
{
  dd_list_t *list = (dd_list_t *) data;
  if(!pref) {
    printf("FIXME (%s:%d)\n", __FILE__, __LINE__);
    exit(0);
  }

//  printf("pref: %s\n", (char*) pref);
  //DD_print(list);


  char *host = (char *) pref;

  int map[list->nlevels];
  for(int k=0; k < list->nlevels; k++)
	  map[k] = k;

  int k = 0;
  for(; k < list->nlevels; k++){
    if(strstr(list->levels[k], host)){ // fixme?
      int mk = map[k];
      map[k] = map[0];
      map[0] = mk;
      break;
    }
  }

  int idx = list->nsubsets-1;
  if(k < list->nlevels){
    for(; idx >= 0; idx --){
       if(list->locations[idx][k]) break;
    }
    if(idx < 0) idx = list->nsubsets-1;
  }

  char *subset = list->subsets[idx];
  unsigned char *locations = list->locations[idx];

  int i = idx;
  for(; i < list->nsubsets-1; i++){
    list->subsets[i] = list->subsets[i+1];
    list->locations[i] = list->locations[i+1];
  }
  list->subsets[i] = subset;
  list->locations[i] = locations;

  list->nsubsets--;

  /*
  int n = 1;
  for(int k=0; k<list->nlevels; k++) 
	  if(locations[k]) n++;

  char **ret = (char**) malloc((n+1) *sizeof(char *));
  n = 0;
  ret[n++] = subset;
  for(int k=0; k<list->nlevels; k++) 
	  if(locations[k]) ret[n++] = list->levels[k];

  ret[n++] = NULL;

  for(int i=0; ret[i]; i++) {
    printf("%d. %s\n", ret[i]);
  }
  */


  size_t size = strlen(subset)+1 + strlen(list->name) + 1;
  int n=2;
  for(int k=0; k<list->nlevels; k++) 
    if(locations[k]) {
	    n++;
	    size += strlen(list->levels[k]) + 1;
    }
  size += (n+1)*sizeof(size_t);

  //printf("\033[0;31mn: %d\033[0m\n", n);

  void *ptr = malloc(sizeof(so_t)+size);
  so_t *so = (so_t*) ptr;
  so->ref_count  = 1;
  so->mem_type  =  0;
  so->sys_type  =  0;
  so->obj_type = SUPR_DD_SUBSET_LOCATIONS; //SUPR_STRING_ARRAY;
  so->size  = size;

  size_t *offset = (size_t*) so->val;
  offset[0] = n;
  offset++;
  size = sizeof(so_t) + (n+1)*sizeof(size_t);

//  memcpy(ptr+size, subset, strlen(subset)+1);
  memcpy(ptr+size, list->name, strlen(list->name)+1);
  offset[0] = size;
//  size += strlen(subset)+1;
  size += strlen(list->name)+1;
  offset++;

//  memcpy(ptr+size, list->name, strlen(list->name)+1);
  memcpy(ptr+size, subset, strlen(subset)+1);
  offset[0] = size;
//  size += strlen(list->name)+1;
  size += strlen(subset)+1;
  offset++;


  n = 0;
  for(int k=0; k<list->nlevels; k++)  {
    int mk = map[k];
    if(locations[mk]) {
	    offset[n++] = size;
	    memcpy(ptr+size, list->levels[mk], strlen(list->levels[mk]) + 1);
	    size += strlen(list->levels[mk]) + 1;
    }
  }


  return so;

}
//void *DD_next(void *data) { return DD_next2(data, NULL); }


iterator_t *DD_toIterator(dd_list_t *list){
	/*
  iterator_t *iter = (iterator_t*) malloc(sizeof(iterator_t));
  iter->hasNext =  DD_hasNext;
  iter->next =  NULL;
  iter->next2 =  DD_next2;
  iter->data =  list;
//      printf("[%s] iter=%p\n", __func__, iter);
  return iter;
  */

  iterator_t *iter =  newIterator(DD_hasNext, NULL, list);
  iter->next2 = DD_next2;
  return iter;
}

extern SEXP DD_list(SEXP name);
extern SEXP DD_open(SEXP name, SEXP create);

static void DFS_namenode_check()
{
  //printf("DFS_namenode: %p\n", DFS_namenode);
  if(!DFS_namenode) return;

  int cmd = CLUSTER_PING;
  ssize_t size = write(DFS_namenode->fd, &cmd, INT_SIZE);
  if(size != INT_SIZE) {
    printf("size: %ld (!=%d)\n", size, INT_SIZE);
    return;
  }

  size = read(DFS_namenode->fd, &cmd, INT_SIZE);
  if(size != INT_SIZE) {
    printf("size: %ld (!=%d)\n", size, INT_SIZE);
    return;
  }
  printf("Send: CLUSTER_PING=%d, Received=%d\n", CLUSTER_PING, cmd);
  
}

void STR_toIterator(void *data)
{ 
  iterator_t *iter = NULL;
	SEXP val = (SEXP) ((void**)data)[0];
                SEXP clazz = getAttrib(val, R_ClassSymbol);
		if(clazz != R_NilValue && strcmp(CHAR(asChar(clazz)),
					"DD")==0){
		  //basic_info(CHAR(asChar(val)));
		  //basic_info("DD_open:");
		  SEXP rc = PROTECT(DD_open(val, R_FalseValue)); // handle errors?
	//fprintf(stdout, "\nDD_open, rc: %p\n", rc);
		//  PrintValue(rc);
		  UNPROTECT(1);
//		  basic_info("DD_check:"); DFS_namenode_check();
		 // basic_info("DD_list:");
		  SEXP dd = PROTECT(DD_list(val));
	//fprintf(stdout, "\nDD_list: \n");
		//  PrintValue(dd);
		  //basic_info(type2char(TYPEOF(dd)));

		  iter = DD_toIterator(newDDList(dd, CHAR(asChar(val))));
		  UNPROTECT(1);
		} else {
                  vector_t *vec = newVector(FALSE);
	          for(int i=0; i<LENGTH(val); i++){
		    size_t size;
		    so_t *s = SO_valueOf(STRING_ELT(val, i), &size);
		    vectorAdd(vec, s);
		  }
		  iter = vectorToIterator(vec);
		}
	 ((void**)data)[0] = iter;
	     
}

iterator_t *soToIterator(so_t *so){


  if(so->obj_type != SUPR_SERIALIZED_ROBJ) return NULL; // TODO

  iterator_t *iter = NULL; //(iterator_t) malloc(sizeof(iterator_t));

    BEGIN_R_EVAL();
      SEXP val = PROTECT(R_bytesToObject(so+1, so->size));
      PrintValue(val); // use Try???
      switch(TYPEOF(val)){
        case VECSXP:
	     { // FIXME: use SO_valueOf and SO_toRObject ...
               vector_t *vec = newVector(FALSE);
//	printf("[%s] vec=%p\n", __func__, vec);
	       for(int i=0; i<LENGTH(val); i++){

                 //PrintValue(VECTOR_ELT(val,i)); 

		 size_t size;
                 void *ptr = R_objectToBytes(VECTOR_ELT(val,i), &size); 
                 so_t *s = (so_t*)malloc(sizeof(so_t)+size);
		 s->obj_type = SUPR_SERIALIZED_ROBJ;
		 s->size = size;
		 memcpy(s+1, ptr, size);
		 free(ptr);
		 vectorAdd(vec, s);
//	printf("[%s] 5 size=%ld, vec=%p, s=%p\n", __func__, size, vec, s);
	       }
	       iter = vectorToIterator(vec);
//	printf("[%s] iter=%p\n", __func__, iter);
	     }
	     break;

        case STRSXP: 

	     /*
	     { 
                SEXP clazz = getAttrib(val, R_ClassSymbol);
		if(clazz != R_NilValue && strcmp(CHAR(asChar(clazz)),
					"DD")==0){
		  basic_info(CHAR(asChar(val)));
		  basic_info("DD_open:");
		  SEXP rc = PROTECT(DD_open(val)); // handle errors?
	fprintf(stdout, "\nDD_open, rc: %p\n", rc);
		  PrintValue(rc);
		  UNPROTECT(1);
		  basic_info("DD_check:");
	          DFS_namenode_check();
		  basic_info("DD_list:");
		  SEXP dd = PROTECT(DD_list(val));
	fprintf(stdout, "\nDD_list: \n");
		  PrintValue(dd);
		  basic_info(type2char(TYPEOF(dd)));

		  iter = DD_toIterator(newDDList(dd, CHAR(asChar(val))));
		  UNPROTECT(1);
		} else {
                  vector_t *vec = newVector(FALSE);
	          for(int i=0; i<LENGTH(val); i++){
		    size_t size;
		    so_t *s = SO_valueOf(STRING_ELT(val, i), &size);
		    vectorAdd(vec, s);
		  }
		  iter = vectorToIterator(vec);
		}
	     }
	     */
	     {
	       void *data[] = {val};
	       Rboolean success = R_ToplevelExec(STR_toIterator, data);

	       iter = data[0];
	       if(!success) {
		       error_info(R_curErrorBuf());
		       iter = NULL;
	       }
	     }
	     break;

	default: break;
      }
      UNPROTECT(1);
    END_R_EVAL();
//	printf("[%s] iter=%p\n", __func__, iter);
  return iter;
}

void  sendJobResult(job_t *job, shm_io_info_t *io)
{
  if(!job->result) return;

  so_t *ret = NULL;
  BEGIN_R_EVAL();
        int n = vectorSize(job->result);
        SEXP val = PROTECT(allocVector(VECSXP, n));
        for(int i=n-1; i>=0; i--){
	  so_t *so = (so_t*) vectorElementAt(job->result, i);
          SEXP elem = PROTECT(R_bytesToObject(so+1, so->size));
	  SET_VECTOR_ELT(val, i, elem);
	  UNPROTECT(1);
        }
   //     PrintValue(val);
	size_t size;
        ret = SO_valueOf(val, &size);
        UNPROTECT(1);
  END_R_EVAL();
  shm_io_write(io, io->out, ret, sizeof(so_t)+ret->size);
  free(ret);

  if(!KEEP_JOB){
	  removeDriverJob(job);
	  /*
    pthread_mutex_lock(&jobs->mutex);
      for(int i = vectorSize(jobs) - 1; i >= 0; i--){
        job_t *j = vectorElementAt(jobs, i);
	if(j == job){
          vectorRemove(jobs, i);
	  break;
	}
      }
    pthread_mutex_unlock(&jobs->mutex);
    fprintf(stderr, "[%s] job->id: %d, job->ref_count: %d\n", __func__,
		    job->id, job->ref_count);

    pthread_mutex_lock(&job->mutex);
      Supr_decref(job);
    pthread_mutex_unlock(&job->mutex);
    */
  }
}

void Job_wait_interrupt(void *data)
{
  job_t *job = (job_t *) ((void**)data)[0];
  supr_thread_t *th = (supr_thread_t *) job->attachment;
  debug_info("WAIT_INTERRUPT");
  pthread_mutex_lock(&job->mutex);
    th->data = PTHREAD_INTERRUPTED;
    pthread_cond_signal(&job->cond);
  pthread_mutex_unlock(&job->mutex);

  supr_socket_conn_t *sc = (supr_socket_conn_t *) ((void**)data)[2];
  int rc = 0;
  write(sc->fd, &rc, sizeof(int));
}

void Job_setPar(void *data)
{
  job_t *job = (job_t *)((void**)data)[0];
  SEXP r_par =  (SEXP)((void**)data)[1];
  if(TYPEOF(r_par) != VECSXP)
	  error(_("expected 'list' object"));

  pthread_mutex_lock(&job->mutex);
     SEXP names = getAttrib(r_par, R_NamesSymbol);
     for(int i=0; i<LENGTH(r_par);  i++){
       const char *var_name = CHAR(STRING_ELT(names, i));
       size_t len;
       so_t *so = SO_valueOf(VECTOR_ELT(r_par, i), &len);
       hashtablePut(job->environment, strdup(var_name), so);
     }
  pthread_mutex_unlock(&job->mutex);

}

strbuf_t *strbuf = NULL;
// jobSubmit(so_t *expr, so_t *subset)
void handleJobSubmit(shm_io_info_t *io, void *bytes, size_t bytes_len)
{
  free(bytes); // FIXME??
//MALLOC_MARK(1);
  
  job_t *job = newJob(NULL, NULL);
  
  pthread_mutex_lock(jobs->mutex);
    shm_io_write(io, io->out, &job->id, sizeof(int));
  pthread_mutex_unlock(jobs->mutex);

  // get expr: [expr, envir, job_id] 
  size_t size;
  so_t *expr = (so_t*) shm_io_read(io, io->in, &size, NULL);

  so_t *data = (so_t*) shm_io_read(io, io->in, &size, NULL);
  // message:
  //fprintf(stderr, "[%s] data.size = %ld\n", __func__, size);
  /*
    BEGIN_R_EVAL();
      SEXP val = PROTECT(R_bytesToObject(so+1, so->size));
      PrintValue(val);
      UNPROTECT(1);
    END_R_EVAL();
    */
  //printSO(subsets);
  //printf("[%s] size = %ld\n", __func__, size);
  //int wait = shm_io_readInt(io);
  int wait;
  {
    int *wait_ptr = (int*) shm_io_read(io, io->in, &size, NULL);
    wait = *wait_ptr;
    /*
    char msg[1024];
    sprintf(msg, "wait_ptr: %p, size: %ld, wait: %d", wait_ptr, size, wait);
    basic_info(msg);
    free?
    */
  }
  //printf("User wait = %d\n", wait);

  so_t *err_handler = (so_t*) shm_io_read(io, io->in, &size, NULL);
  so_t *par = (so_t*) shm_io_read(io, io->in, &size, NULL);

  SEXP r_par = R_NilValue;
  SEXP r_err_handler = R_NilValue;

  BEGIN_R_EVAL();

    SEXP job_rho = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(job_rho, SuprEnv);
    char rho_name[32];
    sprintf(rho_name, "job.%d", job->id);
    defineVar(install(rho_name), job_rho, SuprJobEnv); // FIXME, rm ...
    UNPROTECT(1);

    // to be used later ...
    r_err_handler = SO_toRObject(err_handler, size);
    defineVar(install("error.handler"), r_err_handler, job_rho);
    free(err_handler);

    r_par = SO_toRObject(par, size);
    defineVar(install("par"), r_par, job_rho);
    free(par);

    // not used?
    //printf("job-specific Cluster.sharedObjects:\n");
    // message
    //fprintf(stdout, "job-specific Cluster.sharedObjects:\n");
    //PrintValue(r_par);
    // free
  END_R_EVAL();

  // read dcl_name
  /*
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  size  = *((size_t*)ptr);

  char dcl_name[size];
  free(ptr);
  int dcl_sync = 0;

  if(size){
    ptr = shm_io_read(io, io->in, &size, NULL);
    memcpy(dcl_name, ptr, size);
    free(ptr);
    printf("dcl_name: %s\n", dcl_name);

    ptr = shm_io_read(io, io->in, &size, NULL);
    dcl_sync = *((int*) ptr);
    free(ptr);
    fprintf(stderr, "dcl_name: %s\n", dcl_name);
    fprintf(stderr, "dcl_sync: %d\n", dcl_sync);

    if(!DCL_eventHandler) //DCL_eventHandler = 
      startDCLEventHandler();
  }
  */

//MALLOC_MARK(__LINE__);

  iterator_t *iter = soToIterator(data);
  free(data); // FIXME?

  if(!iter){
    int rc = -1;
    shm_io_write(io, io->out, &rc, sizeof(int));
    // err_msg:
    const char *err = R_curErrorBuf();
    if(!err) err = "";
    shm_io_write(io, io->out, (void*) err, strlen(err)+1);
    return;
  } // else { int rc = 0; shm_io_write(io, io->out, &rc, sizeof(int)); }

  if(!iter->hasNext(iter->data))
    error_info("!iter->hasNext(), FIXME");
  

//MALLOC_MARK(__LINE__);
  /* checking:
  while(iter->hasNext(iter->data))
  {
    so_t *so = (so_t *) iter->next(iter->data);
    BEGIN_R_EVAL();
      SEXP val = PROTECT(R_bytesToObject(so+1, so->size));
      PrintValue(val);
      UNPROTECT(1);
    END_R_EVAL();
  }
  */
  //job_t *job = newJob(expr, iter);
  job->expr  = expr;
  job->tasks = iter;

  if(TYPEOF(r_par) != NILSXP) { // par ??? environment
    void *data[] = {job, r_par};
    Rboolean success;
    BEGIN_R_EVAL();
      success = R_ToplevelExec(Job_setPar, data);
    END_R_EVAL();
  }


  /*
  if(strlen(dcl_name)) {
    job->dcl = (dcl_t *) malloc(sizeof(dcl_t));
    job->dcl->name = strdup(dcl_name);
    job->dcl->sync = dcl_sync;
    job->dcl->next = NULL;
    job->dcl->sc = NULL;

    job->dcl->mutex = NULL;
    job->dcl->cond = NULL;

    if(job->dcl->sync){
      job->dcl->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
      job->dcl->cond = (pthread_cond_t*) malloc(sizeof(pthread_cond_t));
      pthread_mutex_init(job->dcl->mutex, NULL);
      pthread_cond_init(job->dcl->cond, NULL);
    }

    pthread_mutex_lock(globalEnvironment->mutex);
      job->dcl->sc = (supr_socket_conn_t*)
	      hashtableGet(globalEnvironment, dcl_name);
    pthread_mutex_unlock(globalEnvironment->mutex);
  }
  */

  int buf[] = {CLUSTER_JOB_SUBMIT, job->id};

  if(wait){

    supr_thread_t *cth = currentThread();
    pthread_mutex_lock(&cth->mutex);
      cth->state = THREAD_STATE_WAITING;
      cth->data = NULL;
    pthread_mutex_unlock(&cth->mutex);

    char ref[64];
    sprintf(ref, "%d", cth->tid);

    cth->data = NULL;
    job->attachment = cth;
    void *intr_data[] = {job, NULL, NULL};
    run_t *r = newRunnable(Job_wait_interrupt, intr_data);

    pthread_mutex_lock(globalEnvironment->mutex);
      //hashtablePut(globalEnvironment, ref, r);

      basic_info("(%s) r: %s", r->class->name,
           r->class->toString(r->class, r));

      so_t *so = hashtableGet(globalEnvironment, ref);
      if(so){
        run_t *r = ((void **)(so + 1))[0];
	Supr_decref(r);
	free(so);
      }

      so = malloc(sizeof(so_t)+sizeof(void*));
      so->ref_count = REF_COUNT_INITIALIZER;
      so->mem_type = 0;
      so->sys_type = 0;
      so->obj_type = SUPR_REFERENCE;
      so->size = sizeof(void*);
      ((void **)(so + 1))[0] = r;
      hashtablePut(globalEnvironment, ref, so);

    pthread_mutex_unlock(globalEnvironment->mutex);

    int job_id = job->id;
    shm_io_write(io, io->out, &job_id, sizeof(int));

    shm_io_write(io, io->out, ref, strlen(ref)+1);

    //int isInterrupted = FALSE;

    pthread_mutex_lock(&job->mutex);

      pthread_mutex_lock(scToBackend->mutex);
        ssize_t size = write(scToBackend->fd, buf, sizeof(buf));
        int rc;
	size += read(scToBackend->fd, &rc, INT_SIZE);
	if(size != sizeof(buf) + INT_SIZE || rc != 0)
	
	verbose_info("size: %ld (=%ld?), rc/nworkers: %d", size,
			  sizeof(buf) + INT_SIZE , rc);

      pthread_mutex_unlock(scToBackend->mutex);

      //Cluster_sendSimpleMessage("Wait...", msg_color, DEFAULT_INFO_TYPE,0);
      pthread_cond_wait(&job->cond, &job->mutex);
    pthread_mutex_unlock(&job->mutex);

    //free(r);
    {
      void *r = hashtableGet(globalEnvironment, ref);
      hashtableDelete(globalEnvironment, ref);
      if(!globalEnvironment->free_data)
        free(r);
    }

    if(cth->data == PTHREAD_INTERRUPTED){ //int job_id = job->id;
      basic_info("\033[0;33m'wait' is changed to FALSE\033[0m");

      so_t so = {0, 0, 0, SUPR_PTHREAD_INTERRUPTED, 0};
      shm_io_write(io, io->out, &so, sizeof(so_t));
      cth->data = NULL;
      return;
    }
    cth->data = NULL;

//MALLOC_MARK(__LINE__);

    so_t *ret;
    if(job->state == JOB_STATE_CANCELLED){
      BEGIN_R_EVAL();
        int n = vectorSize(job->result);
        SEXP val = PROTECT(allocVector(VECSXP, n));
        for(int i=n-1; i>=0; i--){
	  so_t *so = (so_t*) vectorElementAt(job->result, i);
	  if(so){
	    if(so->obj_type == SUPR_JOB_CANCELLED){
              SET_VECTOR_ELT(val, i, mkString("Error: terminated"));
	    } else {
              SEXP elem = PROTECT(R_bytesToObject(so+1, so->size));
	      SET_VECTOR_ELT(val, i, elem);
	      UNPROTECT(1);
	    }
	  }
        }
        //PrintValue(val);
	setAttrib(val, R_ClassSymbol, mkString("SuprError"));
        ret = SO_valueOf(val, &size);
        UNPROTECT(1);
      END_R_EVAL();
//MALLOC_MARK(__LINE__);
      ShmCache_check();
      shm_io_write(io, io->out, ret, sizeof(so_t)+ret->size);
      ShmCache_check();
//MALLOC_MARK(__LINE__);
      free(ret);

      if(!KEEP_JOB)
        removeDriverJob(job);
    }  else if(job->result) {
      BEGIN_R_EVAL();
        int n = vectorSize(job->result);
        SEXP val = PROTECT(allocVector(VECSXP, n));
        for(int i=n-1; i>=0; i--){
	  so_t *so = (so_t*) vectorElementAt(job->result, i);
          SEXP elem = PROTECT(R_bytesToObject(so+1, so->size));
	  SET_VECTOR_ELT(val, i, elem);
	  UNPROTECT(1);
        }
        //PrintValue(val);
        ret = SO_valueOf(val, &size);
        UNPROTECT(1);
      END_R_EVAL();
//MALLOC_MARK(__LINE__);
      ShmCache_check();
      shm_io_write(io, io->out, ret, sizeof(so_t)+ret->size);
      ShmCache_check();
//MALLOC_MARK(__LINE__);
      free(ret);

      if(!KEEP_JOB)
        removeDriverJob(job);
    } else {
      so_t so = {0, 0, 0, SUPR_ERROR, 0};
      printf("[%s:%d] Error: job->result = null\n", __func__, __LINE__);
      shm_io_write(io, io->out, &so, sizeof(so_t));
    }

    // message:
    //fprintf(stderr,"[%s:%d] Done (wait = TRUE)\n", __func__, __LINE__);
    //fprintf(stderr,"\033[0m");

  } else { // return job_id...
    pthread_mutex_lock(scToBackend->mutex);
      write(scToBackend->fd, buf, sizeof(buf));
      int rc;
      read(scToBackend->fd, &rc, INT_SIZE);
      fprintf(stderr,"[%s:%d] rc: %d\n", __func__, __LINE__, rc);
    pthread_mutex_unlock(scToBackend->mutex);
    int job_id = job->id;
    shm_io_write(io, io->out, &job_id, sizeof(int));
  }

MALLOC_MARK(1024);
}

void handleJobGet(shm_io_info_t *io, void *bytes, size_t bytes_len)
{
  int job_id = ((int*) bytes)[1];
  double timeout = ((double*)(bytes+2*sizeof(int)))[0];
  printf("[%s] timeout = %f\n", __func__, timeout);
  job_t *job = findJob(job_id);
  free(bytes);

  if(!job){
    int result_available = CANNOT_FIND_JOB; // error: cannot find the job
    shm_io_write(io, io->out, &result_available, INT_SIZE);
    return;
  } 

  pthread_mutex_lock(&job->mutex);
  
  if(job->result == JOB_CANCELLED){
    int result_available = JOB_WAS_CANCELLED;
    shm_io_write(io, io->out, &result_available, INT_SIZE);
//    Supr_decref(job);
    JOB_DECREF(job);
    pthread_mutex_unlock(&job->mutex);
    return;
  }

  UserInfo_send(0, 0, __func__);

  int success = TRUE;

//  pthread_mutex_lock(&job->mutex);
    int result_available = job->result != NULL;
    shm_io_write(io, io->out, &result_available, INT_SIZE);

    if(! result_available ) {
     
      supr_thread_t *cth = currentThread();
      pthread_mutex_lock(&cth->mutex);
        cth->state = THREAD_STATE_WAITING;
        cth->data = NULL;
      pthread_mutex_unlock(&cth->mutex);
      /*
      interrupt_mutex = &job->mutex;
      interrupt_cond  = &job->cond;
      interrupt_thread = cth;
      cth->data = NULL;
      */

      char ref[64];
      sprintf(ref, "%d", cth->tid);
    
      cth->data = NULL;
      job->attachment = cth;
      void *intr_data[] = {job, NULL, NULL};
      run_t *r = newRunnable(Job_wait_interrupt, intr_data);

      pthread_mutex_lock(globalEnvironment->mutex);
        so_t *so = malloc(sizeof(so_t)+sizeof(void*));
        so->ref_count = REF_COUNT_INITIALIZER;
        so->mem_type = 0;
        so->sys_type = 0;
        so->obj_type = SUPR_REFERENCE;
        so->size = sizeof(void*);
        ((void **)(so + 1))[0] = r;
        hashtablePut(globalEnvironment, ref, so);
        //hashtablePut(globalEnvironment, ref, r);
      pthread_mutex_unlock(globalEnvironment->mutex);

      shm_io_write(io, io->out, ref, strlen(ref)+1);

      if(timeout>0) {
          struct timespec wait;
          clock_gettime(CLOCK_REALTIME, &wait);
          wait.tv_sec += (long) timeout;
          pthread_cond_timedwait(&job->cond, &job->mutex, &wait);
      } else {
          pthread_cond_wait(&job->cond, &job->mutex);
      }

      /*
      interrupt_mutex  = NULL;
      interrupt_cond   = NULL;
      interrupt_thread = NULL;
      */

      if(cth->data == PTHREAD_INTERRUPTED){

  UserInfo_send(0, 0, "PTHREAD_INTERRUPTED");

        printf("\033[0;31m[%s:%d] PTHREAD_INTERRUPTED\033[0m\n",
		      __func__, __LINE__);

        so_t so = {0, 0, 0, SUPR_PTHREAD_INTERRUPTED, 0};
        printf("\033[0;31m[%s:%d] PTHREAD_INTERRUPTED so.obj_type=%d\033[0m\n",
		      __func__, __LINE__, so.obj_type);
        shm_io_write(io, io->out, &so, sizeof(so_t));
	success = FALSE;

      } else if (!job->result){
        so_t so = {0, 0, 0, SUPR_PTHREAD_TIMEOUT, 0};
        shm_io_write(io, io->out, &so, sizeof(so_t));
	success = FALSE;

      } 
      cth->data = NULL;
    }
//    Supr_decref(job);
    JOB_DECREF(job);
  pthread_mutex_unlock(&job->mutex);

  if(success) 
    sendJobResult(job, io);

}

void handleJobIsDone(shm_io_info_t *io, void *bytes, size_t bytes_len)
{
  int job_id = ((int*) bytes)[1];
  job_t *job = findJob(job_id);
  free(bytes);

  if(!job){
    int isDone = CANNOT_FIND_JOB;
    shm_io_write(io, io->out, &isDone, INT_SIZE);
    return;
  }

  int isDone;
  pthread_mutex_lock(&job->mutex);
    isDone = job->result != NULL;
//    Supr_decref(job);
    JOB_DECREF(job);
  pthread_mutex_unlock(&job->mutex);

  /*
  struct {
    so_t so;
    int len;
    int  val[1];
  } s = {{0,0,0, SUPR_LGLSXP, 1}, 1, {isDone}};
  printf("[%s] sizeof(so_t)=%ld, sizeof(s)=%ld\n", __func__,
		  sizeof(so_t), sizeof(s));
  shm_io_write(io, io->out, &s, sizeof(s));
  */
  shm_io_write(io, io->out, &isDone, INT_SIZE);
}

//extern int socket_client(char *str, int port);

void cancelJob_cleanup_monitors(job_t *job)
{
  int job_id = job->id;

//  pthread_mutex_lock(&job->mutex);
    //basic_info("cleanup: sync monitors...");

    // cleanup: sync monitors...
         // Sync monitors
      pthread_mutex_lock(syncHashtable->mutex); // fixme? use a single mutex...
      pthread_mutex_lock(&sync_mutex);
        int n;
        char **keys = hashtableKeySet(syncHashtable, &n);
        qsort(keys, n, sizeof(char *), rjni_strcmp);
        for(int i=0; i<n; i++) {
          vector_t *queue = (vector_t *) hashtableGet(syncHashtable, keys[i]);
          //sprintf(msg, "\033[0;32m[sync_queue] name: %s, length: %d\033[0m", keys[i], vectorSize(queue));
          //basic_info(msg);
          for(int j = vectorSize(queue)-1; j>=0; j--){
            sync_wait_t *sw = (sync_wait_t *) vectorElementAt(queue, j);
            //sprintf(msg, "\n\t\033[0;33m%d. {host: %s, job_id: %d, tid: %d}\033[0m",/               j+1, sw->sc->host, sw->job_id, sw->tid);
            //basic_info(msg);
	    if(sw->job_id == job_id) vectorRemove(queue, j);
          }
	  if(vectorSize(queue)==0)
	    hashtableDelete(syncHashtable, keys[i]);
        }

	//
        keys = hashtableKeySet(waitHashtable, &n);
        qsort(keys, n, sizeof(char *), rjni_strcmp);
        for(int i=0; i<n; i++) {
          vector_t *queue = (vector_t *) hashtableGet(waitHashtable, keys[i]);
          sprintf(msg, "\033[0;32m[wait_queue] name: %s, length: %d\033[0m",
		  keys[i], vectorSize(queue));
          //basic_info(msg);
          for(int j=vectorSize(queue)-1; j>=0; j--){
            sync_wait_t *sw = (sync_wait_t *) vectorElementAt(queue, j);
            //sprintf(msg, "\n\t\033[0;33m%d. {host: %s, job_id: %d, tid: %d}\033[0m", j+1, sw->sc->host, sw->job_id, sw->tid);
            //basic_info(msg);
	    if(sw->job_id == job_id) vectorRemove(queue, j);
          }
	  if(vectorSize(queue)==0)
	    hashtableDelete(waitHashtable, keys[i]);
        }
	//

        {
          vector_t *queue = timedwait_queue;
          //sprintf(msg, "\033[0;32m[timedwait_queue] length: %d\033[0m", vectorSize(queue));
          //basic_info(msg);
          for(int j=0; j<vectorSize(queue); j++){
            sync_wait_t *sw = (sync_wait_t *) vectorElementAt(queue, j);
            //sprintf(msg, "%d. {host: %s, job_id: %d, tid: %d}", j+1, sw->sc->host, sw->job_id, sw->tid);
            //basic_info(msg);
	    if(sw->job_id == job_id) vectorRemove(queue, j);
          }
        }

	pthread_cond_signal(&timedwait_thread->cond);
      pthread_mutex_unlock(&sync_mutex);
      pthread_mutex_unlock(syncHashtable->mutex);

    //pthread_mutex_unlock(&job->mutex);
}

void handleJobCancel(shm_io_info_t *io, void *bytes, size_t bytes_len)
{
  int job_id = ((int*) bytes)[1];
  free(bytes);
  //fprintf(stderr, "[%s, %ld] job_id: %d\n", __func__, syscall(SYS_gettid), job_id);

#define USE_BACKEND_TO_CANCEL
#ifdef  USE_BACKEND_TO_CANCEL
	
    int buf[] = {TR_CLUSTER_INTERRUPT, job_id};
    pthread_mutex_lock(scToBackend->mutex);
      write(scToBackend->fd, buf, sizeof(buf));
      int rc;
      read(scToBackend->fd, &rc, INT_SIZE);
      fprintf(stderr, "[%s, %ld] job_id: %d, rc: %d\n", __func__, syscall(SYS_gettid), job_id, rc);
    pthread_mutex_unlock(scToBackend->mutex);

#else

  //int job_id = ((int*) bytes)[1];
  job_t *job = getJob(job_id);
  //free(bytes);


  if(job){
    pthread_mutex_lock(&job->mutex);

//  fprintf(stderr, "[%s] LOCKED\n", __func__);
    
    for(int i=0; i<vectorSize(job->executors); i++){
      char *addr = strdup((char*)vectorElementAt(job->executors, i));
      char *str = strstr(addr, ":");
      int port = atoi(str+1);
      *str = 0;
      str = strstr(addr, "//") + 2;
      int sc_fd = socket_client(str, port);
      int msg[] = {TR_CLUSTER_INTERRUPT, job_id};
      write(sc_fd, msg, sizeof(msg));
      int rc;
      read(sc_fd, &rc, INT_SIZE);
      free(addr);
      close(sc_fd);
    }

    pthread_mutex_unlock(&job->mutex);

//  fprintf(stderr, "[%s] UNLOCKED\n", __func__);
    job->result = JOB_CANCELLED;

    if(!KEEP_JOB)
      removeDriverJob(job);
  }

#endif

  so_t so = {0,0,0, SUPR_NILSXP, 0};
  shm_io_write(io, io->out, &so, sizeof(so));

}


void handleDriverInfo(shm_io_info_t *io, void *bytes, size_t bytes_len)
{
  int cmd = CLUSTER_DRIVER_NULL;
  // lock??
  pthread_mutex_lock(scToBackend->mutex);
    write(scToBackend->fd, &cmd, INT_SIZE);
    read(scToBackend->fd, &cmd, INT_SIZE);

  printf("cmd: %d\n", cmd);

  BEGIN_R_EVAL();

    int len = 0;
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
      if(sc->type == WORKER_CONN || sc->type == MASTER_CONN ||
         sc->type == DFS_NAMENODE_CONN || sc->type == USER_CONN)
        len ++;
    }

    SEXP val = PROTECT(allocVector(VECSXP, 2));
    SEXP addr = PROTECT(allocVector(STRSXP, len));
    SEXP type = PROTECT(allocVector(STRSXP, len));
    SEXP names= PROTECT(allocVector(STRSXP, 2));

    char buf[256];
    len = 0;
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
      if(sc->type == WORKER_CONN || sc->type == MASTER_CONN ||
         sc->type == DFS_NAMENODE_CONN || sc->type == USER_CONN) {
	sprintf(buf, "//%s:%d", sc->host, sc->port);
        SET_STRING_ELT(addr, len, mkChar(buf));
        SET_STRING_ELT(type, len, mkChar(connTypeToStr(sc->type)));
	len++;
      }
    }

    SET_VECTOR_ELT(val, 1, addr);
    SET_VECTOR_ELT(val, 0, type);
    SET_STRING_ELT(names, 1, mkChar("conn"));
    SET_STRING_ELT(names, 0, mkChar("type"));
    setAttrib(val, R_NamesSymbol, names);

    setAttrib(val, R_ClassSymbol, mkString("data.frame"));
    names = PROTECT(allocVector(INTSXP, len));
    for(int i=0; i<len; i++) INTEGER(names)[i] = i + 1;
    setAttrib(val, install("row.names"), names);



    size_t size;
    so_t *ret = SO_valueOf(val, &size);
    shm_io_write(io, io->out, ret, size);

    UNPROTECT(5);
  END_R_EVAL();

  write(scToBackend->fd, &cmd, INT_SIZE);
  pthread_mutex_unlock(scToBackend->mutex);
}

void stopMaster(shm_io_info_t *io, void *bytes, size_t bytes_len)
{
  int cmd = CLUSTER_DRIVER_NULL;
  // lock??
  pthread_mutex_lock(scToBackend->mutex);
  write(scToBackend->fd, &cmd, INT_SIZE);
  read(scToBackend->fd, &cmd, INT_SIZE);

  printf("echoed cmd: %d\n", cmd);

  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
      if(sc->type == MASTER_CONN){
	int cmd = CLUSTER_MASTER_STOP;
        write(sc->fd, &cmd, INT_SIZE);
	break;
      }
  }

  write(scToBackend->fd, &cmd, INT_SIZE);
  pthread_mutex_unlock(scToBackend->mutex);
}

void UI_cleanup(void *data){
	supr_thread_t *cth = SUPR_CURRENT_THREAD();
	cth->state = THREAD_STATE_TERMINATED;
	/*
  shm_io_info_t *io = (shm_io_info_t *) data;
  show_shm_io_info(io);
  io->in->padding = 0; // TODO
  show_shm_io_info(io);
  */
  // destroy ...
}

//
#define _GNU_SOURCE
#define __USE_GNU
#include <dlfcn.h>
//
jmp_buf jmp_env;



void UI_run_interrupt(void *data){
  supr_thread_t *cth =  currentThread();
  basic_info(cth->name);

  supr_thread_t *th =  (supr_thread_t *)((void**) data)[0];

  basic_info(th->name);

  pthread_mutex_lock(&th->mutex);
    int rc = pthread_kill(th->ptid, SIGINT);
  pthread_mutex_unlock(&th->mutex);
  sprintf(msg, "pthread_kill(%d, SIGINT): %d", th->tid, rc);
  basic_info(msg);
}

// All threads in a process share the set of signal handlers set up by sigaction(2) and its variants. ???
void UI_run(shm_io_info_t *io)
{
  if(!strbuf) strbuf = newStrbuf(sysconf(_SC_PAGE_SIZE));
  io->in->padding = gettid(); // to read cmd ...
  pthread_cleanup_push(UI_cleanup, io);

  supr_thread_t *cth = SUPR_CURRENT_THREAD();

  char ref[32];
  sprintf(ref, "%d", gettid());
  void *intr_data[]={cth, NULL, NULL};
  run_t *ref_run = newRunnable(UI_run_interrupt, intr_data);

  while(TRUE){

    //jmp_buf jmp_env;
    if(!setjmp(jmp_env)){

      pthread_mutex_lock(globalEnvironment->mutex);
        so_t *so = malloc(sizeof(so_t)+sizeof(void*));
        so->ref_count = REF_COUNT_INITIALIZER;
        so->mem_type = 0;
        so->sys_type = 0;
        so->obj_type = SUPR_REFERENCE;
        so->size = sizeof(void*);
        ((void **)(so + 1))[0] = ref_run;
        hashtablePut(globalEnvironment, ref, so);
        //hashtablePut(globalEnvironment, ref, ref_run);
      pthread_mutex_unlock(globalEnvironment->mutex);

      size_t size;
      pthread_mutex_lock(&cth->mutex);
     // cth->src_file = __FILE__;
     //cth->src_line = __LINE__;
        cth->state = THREAD_STATE_RUNNABLE;
      pthread_mutex_unlock(&cth->mutex);
      void *bytes = shm_io_read(io, io->in, &size, NULL);
      int cmd = ((int*)bytes)[0]; 

    // message:
    //fprintf(stderr, "[%s] byets: %p, sz: %ld, cmd = %d\n", __func__, bytes, size, cmd);

      switch(cmd){
        case DU_JOB_SUBMIT:
//           fprintf(stderr, "[%s] byets: %p, sz: %ld, cmd = %d (DU_JOB_SUBMIT)\n", __func__, bytes, size, cmd);
	   MALLOC_PRINT;
	   handleJobSubmit(io, bytes, size);
	   MALLOC_PRINT;
	   break;

        case DU_JOB_GET:
	   handleJobGet(io, bytes, size);
	   break;

        case DU_JOB_ISDONE:
	   handleJobIsDone(io, bytes, size);
	   break;

        case DU_JOB_CANCEL:
	   handleJobCancel(io, bytes, size);
	   break;

        case CLUSTER_DRIVER_INFO:
	   handleDriverInfo(io, bytes, size);
	   break;

        case CLUSTER_DRIVER_STOP:
	   {
	     int *args = (int*) bytes;
	     if(args[1]) 
	       stopMaster(io, bytes, size);
	     
	     Driver_shutdown(NULL); // no return; 
	   }
	   break;

        case DU_DISCONNECT:
	   {
	     int rc = 0;
    	     shm_io_write(io, io->out, &rc, INT_SIZE);
	     shm_io_close(io);

	     supr_thread_t *cth = currentThread();
	     pthread_mutex_lock(&cth->mutex);
	       cth->state = THREAD_STATE_TERMINATED;
	     pthread_mutex_unlock(&cth->mutex);
	     pthread_exit(NULL); // FIXME tell main_thread to join...

	   }
	   break;

        default: 
	   {
		   /*
	     int cmd = DU_ERROR;
	     strbuf->size = 0;
	     strbufPut(strbuf, &cmd, sizeof(int));
	     strbufPutStr(strbuf, "unknown command");
    	     //shm_io_write(io, io->out, &cmd, sizeof(int));
    	     shm_io_write(io, io->out, strbuf->buf, strbuf->size);
	     */

             free(bytes); // fixme for efficiency...

	     char err[256];
	     sprintf(err, "unknown command");
	     so_t *so = (so_t*)malloc(sizeof(so_t)+strlen(err)+1);
	     so->mem_type = SUPR_MEMTYPE_MEM;
	     so->obj_type = SUPR_ERROR;
	     so->size = strlen(err)+1;
	     memcpy(so->val, err, so->size);
    	     shm_io_write(io, io->out, so, sizeof(so_t)+so->size);

	   }
	   break;
      } 


    } else {
      basic_info("Interrupted. Reset the shm_io ...");
      int rc = shm_io_reset(io, 0);
      /*
      supr_thread_t *ss = (supr_thread_t *) cth->properties;
      pthread_mutex_lock(&ss->mutex);
        pthread_cond_signal(&ss->cond);
      pthread_mutex_unlock(&ss->mutex);
      */
      // (supr_thread_t*) intr_data[2] backend thread
      supr_socket_conn_t *sc = (supr_socket_conn_t *) intr_data[2];
      write(sc->fd, &rc, sizeof(int));
      // cth->properties = NULL;
    }
  }
  pthread_cleanup_pop(TRUE);
}

void mmapUI_cleanup(void *data)
{
	supr_thread_t *cth = SUPR_CURRENT_THREAD();
	cth->state = THREAD_STATE_TERMINATED;
	/*
  void **args = (void**) data;
  mmap_io_t *mmap_io = (mmap_io_t *) args[0];
  char *file_name = (char*) args[1];
  mmap_io_close(mmap_io);

  if(*file_name =='/') unlink(file_name);
  else shm_unlink(file_name);
  free(file_name);
  printf("\033[0;34mFIXME: [%s] is called\033[0m\n", __func__);
  */
}

void mmapUI_run(void **args){
  
  mmap_io_t *mmap_io = (mmap_io_t *) args[0];
  char *file_name = (char*) args[1];
  int rc;

  pthread_cleanup_push(mmapUI_cleanup, args);

  while(TRUE){
    printf("\033[0;31m[%s] Waiting ...\033[0m\n", __func__);
    pthread_cond_wait(&mmap_io->cond, &mmap_io->lock);

      if(mmap_io->data_size > INT_SIZE)
        printf("FIXME: [%s] %s\n", __func__, (char*) (mmap_io->buf+INT_SIZE));

      // fixme...
      int cmd = ((int*) mmap_io->buf)[0];
      printf("FIXME: [%s] cmd: %d\n", __func__, cmd);
      fflush(stdout);
      if(cmd == CLUSTER_MMAP_CLOSE){
        munmap((void *) mmap_io, sizeof(mmap_io_t) + mmap_io->buf_size);
        printf("[%s] close -> Exit\n", __func__);
        break;
      }

      switch(cmd){
        case CLUSTER_MMAP_CLOSE:
	     {
	     }
	     break;

	default: break;
      }

      sprintf(mmap_io->buf, "Response: %s", "Testing");

    pthread_cond_signal(&mmap_io->cond);
  }
  //rc = pthread_mutex_unlock(&mmap_io->lock);

  pthread_cleanup_pop(TRUE);
}

void DCLEventHandler_cleanup(void *data)
{
	supr_thread_t *cth = SUPR_CURRENT_THREAD();
	cth->state = THREAD_STATE_TERMINATED;
}

void DCLEventHandler_run(){

  pthread_cleanup_push(DCLEventHandler_cleanup, NULL);

  supr_thread_t *cth = currentThread();
  vector_t *events = newVector(FALSE);

  struct timeval tv;
  fd_set readfds;
  tv.tv_sec =60;
  tv.tv_usec=0;

  static int count = 0;

  pthread_mutex_lock(&cth->mutex);
  while(TRUE){
    //UserInfo_send(0, 0, __func__);

    pthread_mutex_lock(DC_events->mutex);
      for(int i=vectorSize(DC_events)-1; i>=0; i--)
        vectorAdd(events, vectorRemove(DC_events, i));
    pthread_mutex_unlock(DC_events->mutex);

    if(vectorSize(events) == 0)
      pthread_cond_wait(&cth->cond, &cth->mutex);
 
//MALLOC_MARK(__LINE__);
    for(int i=vectorSize(events)-1; i>=0; i--)
    {
      dc_event_t * e = (dc_event_t *) vectorRemove(events, i);

      // lock job?
      dcl_t *dcl = e->job->dcl;
      while(dcl){

        
	if(dcl->sc){
//	  printf("\033[0;36mvar_name: %s, dcl->sc: //%s:%d\033[0m\n", e->name, dcl->sc->host, dcl->sc->port);
//	  fprintf(stderr, "\033[0;36m\tcount: %d\033[0m\n", count++);
//	  fprintf(stderr, "\033[0;36m\ti: %d\033[0m\n", i);

	  for(;;){
	    int fd = dcl->sc->fd;
	    FD_ZERO(&readfds);
	    FD_SET(fd, &readfds);
	    int ns = select(fd + 1, &readfds, NULL, NULL, &tv);
//	    fprintf(stderr, "\033[0;36m\tns: %d\033[0m\n", ns);
	    if(ns > 0){
              int cmd;
	      ssize_t n = recv(fd, &cmd, INT_SIZE, MSG_PEEK | MSG_DONTWAIT);
	      if(n <= 0){
	        dcl->sc = NULL; // More to do...
                dcl = dcl->next;
	        continue;
	      }

	      read(fd, &cmd, INT_SIZE);

	      if(cmd == DCL_EVENT_GET){
                so_t so;
	        read(fd, &so, sizeof(so_t));
	        so_t *s = (so_t*) malloc(sizeof(so_t) + so.size);
	        memcpy(s, &so, so.size);
	        read(fd, s->val, s->size);

	        BEGIN_R_EVAL();
	          SEXP args = SO_toRObject(s, sizeof(so_t) + so.size);
		  //{
		  	free(s);
		  	s = NULL;
		  //}
//	          printf("\033[0;36margs: TODO ... 1\033[0m\n");
		  //PrintValue(args);

		  if(TYPEOF(args) == LISTSXP){
                    PROTECT(args);
		    SEXP s = args;
		    while(s != R_NilValue){
		      if(TAG(s) != R_NilValue){
		        size_t size;
                        so_t *so = SO_valueOf(CAR(s), &size);
		        char *name = strdup(CHAR(PRINTNAME(TAG(s)))); // FIXME
		        hashtablePut(e->job->environment, name, so);
		      }
                      s = CDR(s);
		    }
		    UNPROTECT(1);
		  }
//	          printf("\033[0;36margs: TODO ... 2\033[0m\n");

	        END_R_EVAL();

		//{
		if(s)
			free(s);
		//}

	        size_t len = strlen(e->name) + 1;
	        write(fd, &len, SIZE_SIZE);
	        write(fd, e->name, len);

	        if(e->value){
	          write(fd, e->value, sizeof(so_t) +  e->value->size);
	        }

	      } else { // to do ...
	        printf("\033[0;36mUnknown command: %d START\033[0m\n", cmd);
	        fprintf(stderr, "\033[0;36mUnknown command: %d START\033[0m\n", cmd);
	        for(;;){
		  unsigned char c;
	          ssize_t n = recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT);
		  if(n==1) fprintf(stderr, " %d", c);
	        }
	        fprintf(stderr, "\n");
	        printf("Unknown command: %d END\033[0m\n", cmd);
	        fprintf(stderr,"Unknown command: %d END\033[0m\n", cmd);
	      }
	      //break;
	    } else if (ns == 0) {
	      //fprintf(stderr, "\033[0;36m\twhoops, timeout\033[0m\n");
	      if(dcl->sync)
	        continue;
	    } else { // error
	      fprintf(stderr, "\033[0;36m\twhoops, error: %s\033[0m\n",
			    strerror(errno)); // timeout
	      //break;
	    }
	    break;
	  }
	}

	if(dcl->sync){
          pthread_mutex_lock(dcl->mutex);	
	    fprintf(stderr, "\033[0;36m\tSIGNAL\033[0m\n");
            pthread_cond_signal(dcl->cond);	
          pthread_mutex_unlock(dcl->mutex);	
	}

        dcl = dcl->next;


      }

      // delete the event

      if(!e->job->dcl->sync){

      //pthread_mutex_lock(&e->job->mutex);
        fprintf(stderr, "\033[0;36m\t[%s] e->job->ref_count: %d\033[0m\n",
		      __func__, e->job->ref_count);
        Supr_decref(e->job);
      //pthread_mutex_unlock(&e->job->mutex);
      //{
              SO_decref(e->value);
	      free(e->name);
	      free(e);
      //}
      }
    }
//MALLOC_MARK(__LINE__);

  }
  pthread_mutex_lock(&cth->mutex);

  pthread_cleanup_pop(TRUE);

}






//
void *thread_signal_run(void *arg)
{
  void **args = (void **)arg; 
  pthread_mutex_lock((pthread_mutex_t*)args[0]);
      pthread_cond_signal((pthread_cond_t*)args[1]);
  pthread_mutex_unlock((pthread_mutex_t*)args[0]);
}
//

extern pthread_t signalHandlerThread_ptid;

void UI_run_sigaction(int sig, siginfo_t *ip, void *context)
{
  sprintf(msg, "sig: %d", sig);
  basic_info("\033[0;31mREAD_INTERRUPT, TODO...\033[0m\n"); // jump back to ...
  
  //
  Dl_info __info__;    
  char msg[1024];
  for(int i=0; i < 3; i++){
    switch(i){
      case 0:
           {
             int __rc__ = dladdr(__builtin_return_address(0), &__info__);
             if(__rc__ == 0) break;
             sprintf(msg, "\033[0;32m[%d] fun: %s\033[0m\n", gettid(),
			     __info__.dli_sname);
             basic_info(msg);
	   }
	   break;
      case 1:
           {
             int __rc__ = dladdr(__builtin_return_address(1), &__info__);
             if(__rc__ == 0) break;
             sprintf(msg, "\033[0;32m[%d] fun: %s\033[0m\n", gettid(),
			     __info__.dli_sname);
             basic_info(msg);
	   }
	   break;
      case 2:
           {
             int __rc__ = dladdr(__builtin_return_address(2), &__info__);
             if(__rc__ == 0) break;
             sprintf(msg, "\033[0;32m[%d] fun: %s\033[0m\n", gettid(),
			     __info__.dli_sname);
             basic_info(msg);
	   }
	   break;
      case 3:
           {
             int __rc__ = dladdr(__builtin_return_address(3), &__info__);
             if(__rc__ == 0) break;
             sprintf(msg, "\033[0;32m[%d] fun: %s\033[0m\n", gettid(),
			     __info__.dli_sname);
             basic_info(msg);
	   }
	   break;
      default: break;
    }
  }
  //
  longjmp(jmp_env, 0);
}


void  Driver_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  supr_thread_t *cth = currentThread();

  sprintf(msg, "cth->name: %s, cth->tid: %d", cth->name, cth->tid);
  basic_info(msg);

  if(strcmp(cth->name, "shmio")==0){
    UI_run_sigaction(sig, ip, context);
    return; // not reached
  }

  if(cth != main_thread) {
    pthread_kill(main_thread->ptid, sig); // SIGINT
    return;
  }

  ssize_t size;
  void *mem_ptr;
  char *shm_name = Supr_signal_shm_open(getpid(), sig, &mem_ptr, &size);

  if(shm_name){ // TODO
    shm_unlink(shm_name);

    pid_t pid = *((pid_t*) mem_ptr);
    int cmd = *((int *)(mem_ptr + sizeof(pid_t)));
    char buf[256];
    sprintf(buf, "Received pid: %d, cmd: %d", pid, cmd);
    basic_info(buf);

    munmap(mem_ptr, size);
  } 

  if(Supr_curStrError){
    Cluster_sendSimpleMessage("Current Error:",msg_color, DEBUG_INFO_TYPE, 0);
    Cluster_sendSimpleMessage(Supr_curStrError,msg_color, DEBUG_INFO_TYPE, 0);
  }

  {
    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf) {
      char *msg = malloc(strlen(buf)+256);
      sprintf(msg, "\033[0;33m%s\033[0m", buf);
      Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
      free(msg);
    }

    free(buf);
  }

//  Driver_shutdown(NULL); // TODO
}

void  Driver_SigactionSIGUSR2(int sig, siginfo_t *ip, void *context)
{
}

void  Driver_SigactionSIGUSR1(int sig, siginfo_t *ip, void *context)
{

  if(pthread_equal(pthread_self(), signalHandlerThread_ptid)){
    printf("\033[0;33m[INFO][%s] handlerThread_ptid=%ld\033[0m\n\n", __func__,
                  signalHandlerThread_ptid);

    if(interrupt_mutex && interrupt_cond){
      pthread_mutex_lock(interrupt_mutex);
        pthread_cond_broadcast(interrupt_cond);
	interrupt_thread->data = PTHREAD_INTERRUPTED;
      pthread_mutex_unlock(interrupt_mutex);
    }

    /*
    supr_thread_t *th = currentThread();
    pthread_mutex_lock(&th->mutex);
      printf("[%s] currentThread: %s\n", __func__, objectToString(th));

      c_backtrace();

      void *data = th->data;
      th->data = PTHREAD_INTERRUPTED;

      char ref[64];
      sprintf(ref, "%d", th->tid);
      void **sync = (void **) hastableGet(globalEnvironment, ref);
      printf("[%s] sync[0]: %p\n", __func__, sync[0]);
      printf("[%s] __job__->mutex: %p\n", __func__,& __job__->mutex);
      printf("[%s] sync[1]: %p\n", __func__, sync[1]);
      printf("[%s] __job__->cond: %p\n", __func__, &__job__->cond);
      int rc = pthread_cond_signal((pthread_cond_t*)sync[1]);
      printf("[%s] rc: %d (%s)\n", __func__, rc, strerror(errno));
      //pthread_kill(th->ptid, SIGINT);

      //
      {
        pthread_t thread;
	int rc = pthread_create(&thread, NULL, thread_signal_run, sync);
      }
      //

    pthread_mutex_unlock(&th->mutex);
    */


  } else {
    printf("\033[0;37m[INFO][%s] pthread_self()=%ld -> %ld\033[0m\n",
                    __func__, pthread_self(), signalHandlerThread_ptid);
    pthread_kill(signalHandlerThread_ptid, sig);
  }

}


void *UI_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  //printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);

  pthread_setspecific(currentThreadKey, th);

  *sth = th;

  //int port = ((int*)data)[0];
  shm_io_info_t *io = (shm_io_info_t *)data;
  //printf("[%s] io: %p\n", __func__, io);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  UI_run(io);

  pthread_exit(th);
  return NULL;
}

void *mmapUI_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  //printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);

  pthread_setspecific(currentThreadKey, th);


  *sth = th;

  mmap_io_t *mmap_io = mmap_io_open((char*) data);

  if(!mmap) *sth = NULL; // set error code and message: TODO
  char *file_name = strdup((char*) data);

  pthread_mutex_lock(&mmap_io->lock);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  if(mmap_io) {
    void *args[] = {mmap_io, file_name};
    mmapUI_run(args);
    free(file_name);
  }

  pthread_exit(th);
  return NULL;
}

void *DCLEventHandler_init(void *arg)
{
//  void *data = (void*) ((void **)arg)[0];
//  printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[0];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[1];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &sem);

  pthread_setspecific(currentThreadKey, th);

  *sth = th;

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  DCLEventHandler_run();

  pthread_exit(th);
  return NULL;
}








supr_thread_t *startTimedwaitThread()
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&sem, &sth};
  int rc = pthread_create(&thread, NULL, timedwaitThreadRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  return sth;
}



supr_thread_t *startBackend(int port)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, &sem, &sth, NULL};
  int rc = pthread_create(&thread, NULL, backendRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  //printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

/*
supr_thread_t *startDriverBackend(int port, supr_socket_conn_t *info_server){
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, &sem, &sth, info_server};
  int rc = pthread_create(&thread, NULL, backendRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  return sth;
}
*/

supr_thread_t *startUI(shm_io_info_t *io)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {io, &sem, &sth};
  int rc = pthread_create(&thread, NULL, UI_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

supr_thread_t *startMMapUI(const char *file_name)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {(void*)file_name, &sem, &sth};
  int rc = pthread_create(&thread, NULL, mmapUI_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

supr_thread_t *startDCLEventHandler()
{
  if(!DCL_connections) DCL_connections = newVector(TRUE);
  if(!DC_events) DC_events = newVector(TRUE);

  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&sem, &sth};
  int rc = pthread_create(&thread, NULL, DCLEventHandler_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  DCL_eventHandler = sth;
//supr_thread_t *startDCLEventHandler();
  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}






void __R_init(int argc, char **argv){
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  //char *new_argv[] = {argv[0], "--vanilla", "--no-save", "--verbose"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);


  Rf_initialize_R(new_argc, new_argv);


  void *dummy;
  R_CStackStart = (unsigned long) &dummy;
  R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
  //R_Interactive = FALSE;
  setup_Rmainloop();

  R_thread_init();
}


// CheckConnectionStatus etc
void CheckStatus()
{
  int cmd = CLUSTER_DRIVER_NULL;

  pthread_mutex_lock(scToBackend->mutex);
    write(scToBackend->fd, &cmd, INT_SIZE);
    read(scToBackend->fd, &cmd, INT_SIZE);

    int nWorkers = 0;
    supr_socket_conn_t *master = NULL;
    supr_socket_conn_t *dfs_namenode = NULL;
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(socket_connections, i);
      if(sc->type == WORKER_CONN || sc->type == MASTER_CONN ||
         sc->type == DFS_NAMENODE_CONN || sc->type == USER_CONN)
      {
        fprintf(stderr, "%s: //%s:%d\n", connTypeToStr(sc->type),
			 sc->host, sc->port);
	if(sc->type == WORKER_CONN)
		nWorkers++;
        else if(sc->type == MASTER_CONN)
		master = sc;
        else if(sc->type == DFS_NAMENODE_CONN) // shouldn't be here?
		dfs_namenode = sc;
      }

        
    }

#define MIN_NUM_WORKERS  1
    if(nWorkers < MIN_NUM_WORKERS && dfs_namenode && master){
      int cmd = DFS_START_WORKERS;
      write(dfs_namenode->fd, &cmd, INT_SIZE);
      int n = MIN_NUM_WORKERS - nWorkers;
      write(dfs_namenode->fd, &n, INT_SIZE);

      char buf[256];
      sprintf(buf, "//%s:%d", master->host, master->port);
      size_t len = strlen(buf) + 1;

      write(dfs_namenode->fd, &len, SIZE_SIZE);
      write(dfs_namenode->fd, buf, len);
    }

    write(scToBackend->fd, &cmd, INT_SIZE);
  pthread_mutex_unlock(scToBackend->mutex);
}

extern int Supr_waitpid(const char *tmp_out, const char *tmp_err,
	const char *sock_addr, pid_t pid, int *status, const char *X11);


supr_socket_conn_t *Driver_startMaster(const char *addr){
  //supr_socket_conn_t *sc = NULL;

  basic_info("\033[0;33m%s(%s)\033[0m", __func__, addr);

  char *host = NULL;
  int port = -1;
  if(!addr || !strstr(addr,":")){
    host = strdup(Supr_hostname);
    port = Config_getPort("Master");
  } else {

    host = strdup(addr);
    char *s = strstr(host, ":");
    if(!s) return NULL;
    *s = 0; s++;
    port = atoi(s);
  }

  sprintf(msg, "Start master -port %s:%d ...", host, port);
  Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  char shm_name[256];
  sprintf(shm_name, "SUPR_DFSNAME_%d_%s", getpid(), __func__);
  sem_t *sem = (sem_t*) Supr_shm_create(shm_name, sizeof(sem_t));
  if(!sem)
    error(_("[%s:%d] Supr_shm_create(%s), %s"), __FILE__,__LINE__, shm_name,
		    strerror(errno));
  shm_unlink(shm_name);

  sem_init(sem, 1, 0);

  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {

//      fprintf(stderr, "\033[0;31m[%d] parent proc: %d\033[0m\n", __LINE__, getpid());

      int rc;
      pthread_mutex_lock(&Supr_syncMutex); // fixme ...

	sem_post(sem);

        Supr_syncObject = &Supr_syncCond;
        double timeout = 300;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

        rc = pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);

        Supr_syncObject = NULL;

      pthread_mutex_unlock(&Supr_syncMutex);

      if(rc == ETIMEDOUT){
	      basic_info("\033[0;33mError: TIMEDOUT\033[0m");
      } 
      else {

        {
          clock_gettime(CLOCK_REALTIME, &wait);
          save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
          sprintf(msg, "\033[0;33m%s master (in %g sec.)\033[0m",
		-save_time >= Supr_options.timeout?
		"\033[0;31mFailed to start\033[0m":"Started", -save_time);
          Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);
        }

        int status;
        int rc = waitpid(pid, &status, 0);
      }

      free(host);
      munmap(sem, sizeof(sem_t));

//basic_info("sleep(20)...");
//sleep(20); // checking master...
      return master_conn;
  }

  info_sc = NULL;
  if(info_addr) info_sc = socketOpen1(info_addr);

  sem_wait(sem);
  munmap(sem, sizeof(sem_t));

  char driver_addr[strlen(driverServerConn->host)+32];
  sprintf(driver_addr, "%s:%d", driverServerConn->host,driverServerConn->port);

  char tmp_out[256];
  char tmp_err[256];
  sprintf(tmp_out, "master-init-%d.out", getpid());
  sprintf(tmp_err, "master-init-%d.err", getpid());

  int out_fd = open(tmp_out, O_WRONLY| O_CREAT | O_TRUNC, 0600);
  int err_fd = open(tmp_err, O_WRONLY| O_CREAT | O_TRUNC, 0600);

  //int  in_fd = open(tmp, O_RDONLY);
  //dup2(in_fd, STDIN_FILENO);

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {
    /*
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    fprintf(stderr, "C (%s:%d) waitpid(%d, ...), rc: %d, err: %s\n",
                      __FILE__, __LINE__,
                      pid, rc, strerror(errno));
    */
    int status;
    errno = 0;
    int rc = Supr_waitpid(tmp_out, tmp_err, driver_addr, pid, &status,
	X11_str);
    exit(EXIT_SUCCESS);
  }

  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);

  if(strstr(host, "//")) host += 2;

  if(strcmp(Supr_hostname, host)==0 || strcmp(host, "localhost")==0){

    char path[strlen(Supr_sysHome) + strlen("/bin/master")+2];
    sprintf(path, "%s/bin/master",  Supr_sysHome);
    char port_str[32];
    sprintf(port_str, "%d", port);
    char level_str[32];
    sprintf(level_str, "%d", Supr_options.level);

    int rc = execl(path, path, // "-port", port_str,
	  strstr(addr,":")? "-port":"",
	  strstr(addr,":")?  (strstr(addr,":")+1) : "",
//                 "-usr", Supr_usrHome, "-sys", Supr_sysHome, // FIXME
 //                "-dfs", Supr_dfsHome,
		 "-info", info_addr?info_addr : "",
                 "-notify", driver_addr,
                 Supr_verbose ? "--verbose" : "",
                 Supr_debug ?  "--debug" : "",
                 Supr_infov ?  "--info" : "",
		 "-level", level_str,
                 (char *) NULL);


    return NULL; // not reached
  } else {
    basic_info("Start master on the remote host: %s", host);

    const char *format = "bash -c 'source .suprrc;"
         " $SUPR_SYS_HOME/bin/master -port %s"
         " -info %s -notify %s %s %s %s -level %d'";

    char ssh_arg[strlen(format) + 4096];

    sprintf(ssh_arg, format, // port,
                  strstr(addr,":")? (strstr(addr,":")+1):"0",
                  info_addr ? info_addr : "", driver_addr,
                Supr_verbose ? "--verbose" : "",
                Supr_debug ? "--debug" : "",
                Supr_infov ? "--info" : "", Supr_options.level);

    basic_info("ssh_arg: %s", ssh_arg);

    //int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    int rc = execl("/usr/bin/ssh", "ssh", "-Y", host, ssh_arg, (char*) NULL);

    exit(EXIT_SUCCESS); // not reached
    //exit(EXIT_FAILURE);
    return NULL;
  }
}

supr_socket_conn_t *Driver_startDFS(const char *addr);

void main_thread_start_dfsname(void *data){
  char *addr = (char*)data;
  if(addr) {
    supr_socket_conn_t *sc = Driver_startDFS(addr);
    free(addr);
  }
}


// local only
supr_socket_conn_t *Driver_startDFS(const char *addr){

  basic_info("%s(addr=%s)", __func__, addr);

  char *host = NULL;
  int port = -1;
  if(!addr || !strstr(addr,":")){
    host = strdup(Supr_hostname);
    port = Config_getPort("Namenode");
  } else {

    host = strdup(addr);
    char *s = strstr(host, ":");
    if(!s) return NULL;
    *s = 0; s++;
    port = atoi(s);
  }

  sprintf(msg, "Start dfs_name -port %s:%d ...", host, port);
  Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  char shm_name[256];
  sprintf(shm_name, "SUPR_DFSNAME_%d_%s", getpid(), __func__);
  sem_t *sem = (sem_t*) Supr_shm_create(shm_name, sizeof(sem_t));
  if(!sem)
    error(_("[%s:%d] Supr_shm_create, %s"), __FILE__,__LINE__, strerror(errno));
  shm_unlink(shm_name);

  sem_init(sem, 1, 0);

  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {

      int rc;

      pthread_mutex_lock(&Supr_syncMutex); // fixme ...

	sem_post(sem);

        Supr_syncObject = &Supr_syncCond;
        double timeout = Supr_options.timeout;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

        rc = pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);

        Supr_syncObject = NULL;

      pthread_mutex_unlock(&Supr_syncMutex);

      if(rc == ETIMEDOUT){
	      basic_info("\033[0;33mError: TIMEDOUT\033[0m");
      } 
      else {

        { //FIXME
          clock_gettime(CLOCK_REALTIME, &wait);
          save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
          sprintf(msg, "\033[0;33m%s dfs_name (in %g sec.)\033[0m",
		-save_time >= Supr_options.timeout?
		"\033[0;31mFailed to start\033[0m":"Started", -save_time);
          Cluster_sendSimpleMessage(msg, driver_color, VERBOSE_INFO_TYPE, 0);
        }

        int status;
        rc = waitpid(pid, &status, 0);
        if(!DFS_namenode) {
          sprintf(msg, "cannot start dfs_namenode");
          Cluster_sendSimpleMessage(msg, "\033[0;32m", 0, 0); // Warning ...
        }

      }

      munmap(sem, sizeof(sem_t));
      free(host);
      return DFS_namenode;
  }

  sem_wait(sem);
  munmap(sem, sizeof(sem_t));

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid) {
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    fprintf(stderr, "C (%s:%d) waitpid(%d, ...), rc: %d, err: %s\n",
                      __FILE__, __LINE__,
                      pid, rc, strerror(errno));
    exit(EXIT_SUCCESS);
  }

  char driver_addr[strlen(driverServerConn->host)+32];
  sprintf(driver_addr, "%s:%d", driverServerConn->host,driverServerConn->port);

  if(strstr(host, "//")) host += 2;

  if(strcmp(Supr_hostname, host)==0 || strcmp(host, "localhost")==0){

    basic_info("Start DFS on the local host: %s", host);

    char path[strlen(Supr_sysHome) + strlen("/bin/dfs_name")+2];
    sprintf(path, "%s/bin/dfs_name",  Supr_sysHome);
    char port_str[32];
    sprintf(port_str, "%d", port);
    char level_str[32];
    sprintf(level_str, "%d", Supr_options.level);


    int rc = execl(path, path, strstr(addr, ":")? "-port":"", 
		  strstr(addr, ":")?  (strstr(addr, ":")+1): "",
      //           "-usr", Supr_usrHome, "-sys", Supr_sysHome, // FIXME
       //          "-dfs", Supr_dfsHome,
		 "-info", info_addr ? info_addr : "",
                 "-notify", driver_addr,
                 Supr_verbose ? "--verbose" : "",
		 Supr_debug ?  "--debug" : "",
		 Supr_infov ?  "--info" : "",
		 "-level", level_str,
		 "-X11", X11_str ? X11_str:"_",
                 (char *) NULL);


    if(rc==-1)
      fprintf(stderr, "Error in %s\n\t%s\n\n", path, strerror(errno));

    return NULL; // not reached
  } else {
    basic_info("Start DFS on the remote host: %s", host);

    const char *format = "bash -c 'source .suprrc;" //" env;"
         " $SUPR_SYS_HOME/bin/dfs_name -port %s -X11 %s" // %d
         " -info %s -notify %s %s %s %s -level %d'";

    char ssh_arg[strlen(format) + 1024];

    const char *send_info_addr = NULL;
    //if(Supr_debug) send_info_addr = info_addr;
    if(TRUE || Supr_debug) send_info_addr = info_addr;

    sprintf(ssh_arg, format, // port,
                  strstr(addr,":")? (strstr(addr,":")+1):"0",
		  X11_str ? X11_str:"_",
		  info_addr ? info_addr : "", driver_addr,
                Supr_verbose ? "--verbose" : "",
                Supr_debug ? "--debug" : "",
                Supr_infov ? "--info" : "",
		Supr_options.level);

    //basic_info("ssh_arg: %s", ssh_arg);

    //int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    int rc = execl("/usr/bin/ssh", "ssh", "-Y", host, ssh_arg, (char*) NULL);

    if(rc==-1)
      fprintf(stderr, "Error in ssh -Y %s %s\n\t%s\n\n", host, ssh_arg,
      	strerror(errno));

    exit(EXIT_SUCCESS); // not reached
    //exit(EXIT_FAILURE);
    return NULL;

  }
}




#define USE_NEW_Driver_startWorkers
#ifdef  USE_NEW_Driver_startWorkers
supr_socket_conn_t *Driver_startWorker(char *addr, supr_socket_conn_t *master,
	       	supr_socket_conn_t *dfs){

  fprintf(stderr, "%d. %s(addr=%s, ...)", __LINE__, __func__, addr);
  basic_info("\033[034m%s(addr=%s)\033[0m", __func__, addr);
  //sprintf(msg, "addr: %s", addr);
  //Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  if(strstr(addr, "//")) addr = strstr(addr, "//") + 2;

  char *host = strdup(addr);
  char *s = strstr(host, ":");
  if(!s) return NULL;
  *s = 0; s++;
  int port = atoi(s);
  int nport = strstr(s, "+")?0:1;
 
  sprintf(msg, "\033[0;32mStart worker -port %s:%d%s ...\033[0m", host, port,
		  nports?"":"+");
  Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  char path[strlen(Supr_sysHome) + strlen("/bin/worker")+2];
  sprintf(path, "%s/bin/worker",  Supr_sysHome);
  char port_str[32];
  sprintf(port_str, "%d%s", port, nports?"":"+");

  char driver_addr[strlen(driverServerConn->host)+32];
  sprintf(driver_addr, "%s:%d", driverServerConn->host, driverServerConn->port);
  char master_addr[strlen(master->host)+32];
  sprintf(master_addr, "%s:%d", master->host, master->port);

  int verbose = 0;
  //if(Supr_options.info) verbose = 1;
  if(Supr_options.verbose) verbose = 1; //
  if(Supr_options.debug) verbose = 2;  // level = 1
  if(Supr_options.level) verbose++;  // level = 1


  const char *format = "bash -c 'source .suprrc;" //" env;"
         " $SUPR_SYS_HOME/bin/worker -port %s -X11 %s" // %d
	 " -master %s -ntrs  %d %s %s %s"
         " -dfs %s:%d %s %s -driver %s -notify %s -level %d%s'";

  char ssh_arg[strlen(format) + strlen(master_addr) + 256 + 8*PATH_MAX];
  int ntrs_int = 0;

  const char *send_info_addr = NULL;
  //if(Supr_debug) send_info_addr = info_addr;
  if(TRUE || Supr_debug) send_info_addr = info_addr;
  
  char verbose_str[64];
  verbose_str[0] = 0;
  if(verbose) sprintf(verbose_str, " -verbose %d", verbose);

  sprintf(ssh_arg, format, // port,
		  strstr(addr,":")? (strstr(addr,":")+1):"0",
		  X11_str? X11_str:"_", // "_": no? // FIXME
		  master_addr, ntrs_int, 
    		Supr_verbose ? "--verbose" : "",
	       	Supr_debug ? "--debug" : "",
	       	Supr_infov ? "--info" : "",
	       	dfs? dfs->host : "", dfs? dfs->port : -1,
	       	send_info_addr? "-info": "", send_info_addr? send_info_addr:"",
	       	driver_addr, driver_addr, Supr_options.level,
		verbose_str);

  Cluster_sendSimpleMessage(ssh_arg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  char shm_name[256];
  sprintf(shm_name, "SUPR_DFSNAME_%d_%s", getpid(), __func__);
  sem_t *sem = (sem_t*) Supr_shm_create(shm_name, sizeof(sem_t));
  if(!sem)
    error(_("[%s:%d] Supr_shm_create, %s"), __FILE__,__LINE__, strerror(errno));
  shm_unlink(shm_name);

  sem_init(sem, 1, 0);

  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {

      //sprintf(msg, "\033[0;31m[%d] parent proc: %d\033[0m\n", __LINE__, getpid());
      Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

      //supr_socket_conn_t *conn = NULL;

      double time_elapsed = 0.0;

      pthread_mutex_lock(&Supr_syncMutex); // fixme ...

	sem_post(sem);

        Supr_syncObject = &Supr_syncCond;
        double timeout = Supr_options.timeout;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

        pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);

        Supr_syncObject = NULL;

      pthread_mutex_unlock(&Supr_syncMutex);

      {
        clock_gettime(CLOCK_REALTIME, &wait);
        save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
	time_elapsed = -save_time;
                
        sprintf(msg, "\033[0;32m%s worker %s, pid: %d, cpid: %d. Time elapsed: %g\n\033[0m",
			time_elapsed >= Supr_options.timeout ?
			"\033[0;31mFailed to start\033[0m":"Started",
		       	host, getpid(), pid, time_elapsed);
        Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);
	if(Supr_syncObject == &Supr_syncCond)
	{
          sprintf(msg, "\033[0;31mcannot start %s\033[0m", host);
          Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);
	} else if(Supr_syncObject) {
          Cluster_sendSimpleMessage((char*) Supr_syncObject, "\033[0;32m", VERBOSE_INFO_TYPE, 0);
	  free(Supr_syncObject);
	}
	Supr_syncObject = NULL;
      }

//#ifndef TEST_KEEP_SSH_X11FORWARDING_ALIVE
      int status;
      int rc = waitpid(pid, &status, 0);
      fprintf(stderr, "P [%s] waitpid(pid=%d, &status, 0): %d, status: %d (%s:%d)\n",
           __func__, pid, rc, status, __FILE__, __LINE__ );
//#endif

      munmap(sem, sizeof(sem_t));

      fprintf(stderr, "\n\n");

      return NULL;
  }

// if use info_sc
  info_sc = NULL;
  if(info_addr) info_sc = socketOpen1(info_addr);
  

  sem_wait(sem);
  munmap(sem, sizeof(sem_t));

  char tmp_out[256];
  char tmp_err[256];
  sprintf(tmp_out, "worker-init-%d.out", getpid());
  sprintf(tmp_err, "worker-init-%d.err", getpid());

  int out_fd = open(tmp_out, O_WRONLY| O_CREAT | O_TRUNC, 0600);
  int err_fd = open(tmp_err, O_WRONLY| O_CREAT | O_TRUNC, 0600);
  //int  in_fd = open(tmp, O_RDONLY);
  

 // basic_info("out_fd: %d, err_fd: %d, in_fd: %d", out_fd, err_fd, in_fd);

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {
    int status;
    errno = 0;

    int rc = Supr_waitpid(tmp_out, tmp_err, driver_addr, pid, &status, X11_str);

    /*
    if(X11_str && strlen(X11_str) && strcmp(X11_str,"_")){
      sleep(10);
      exit(EXIT_SUCCESS);  // TODO...
    }
    */

/*
    int rc = waitpid(pid, &status, 0);

    basic_info("%s:%d. %s: waitpid(%d, ...), rc: %d, status: %d, %s %s\n",
                      __FILE__, __LINE__, strchr(__func__,'_')+1,
                      pid, rc, status, errno?"err: ":"", strerror(errno));

    if(rc == -1){
      error_info("err: %s", strerror(errno));
    } else if(WIFEXITED(status)){
      //basic_info("terminated normally, that is, by calling exit(3) or _exit(2), or by returning from main()");
      int exit_status = WIFEXITED(status);
      if(exit_status){
        basic_info("\033[0;31m===== ssh/execl exit status: %d (file: %s) =====\033[0m", exit_status, tmp);
        FILE * f_tmp = fopen(tmp, "r");
	if(f_tmp){
	  //
	  char buf[4096];
	  while(fgets(buf, sizeof buf, f_tmp)) {
	    char *s = strrchr(buf, '\n');
	    if(s) *s = 0;
	    basic_info("\033[0;31m%s\033[0m", buf);
	    //fprintf(stderr, "\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	  }
	  //
	  basic_info("\033[0;31m==== (file: %s) =====\n\033[0m", tmp);
	  fclose(f_tmp);
	}

	if(driver_addr) {
	  //Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_MASTER??);
	  //basic_info("1. notify %s", driver_addr);
	  Supr_notify(driver_addr, Supr_hostname, CLUSTER_CONNECT_MASTER);
	  //basic_info("2. notify %s", driver_addr);
	}
      } else {
        basic_info("\033[0;32mssh/execl exit status: %d\033[0m", exit_status);
      }

    } else {
      error_info("\033[0;31mterminated abnormally\033[0m");
      if(WIFSIGNALED(status)){
        int sig = WTERMSIG(status);
        error_info("\033[0;31m\tsignal: %d\033[0m", sig);
      } else {
      }
    }


    FILE * f_tmp = fopen(tmp, "r");

    if(f_tmp){
      char buf[4096];
      while(fgets(buf, sizeof buf, f_tmp)) {
        //basic_info("\033[0;33m%s: %s\033[0m", tmp, buf);
        fprintf(stderr, "%s", buf);
      }
      fclose(f_tmp);
    }

    close(out_fd);
    close(err_fd);
    close(in_fd);
    
    unlink(tmp);
*/
    exit(EXIT_SUCCESS);

  }

  /*
      int save_in  = dup(STDIN_FILENO);
      int save_out = dup(STDOUT_FILENO);
      int save_err = dup(STDERR_FILENO);
      */
   //dup2(in_fd, STDIN_FILENO);
   dup2(out_fd, STDOUT_FILENO);
   dup2(err_fd, STDERR_FILENO);

   fprintf(stdout, "OKAY -8\n");
   fprintf(stderr, "OKAY -8\n");
//
/* if use info_sc
  info_sc = NULL;
  if(info_addr) info_sc = socketOpen1(info_addr);
*/
  int rc = 0;
 
  
  if(strcmp(host, Supr_hostname)==0 || strcmp(host, "localhost")==0){

    //fprintf(stderr, "local, host: %s\n", host);
    char dfs_addr[1024];
    sprintf(dfs_addr, "%s:%d", dfs?dfs->host:"", dfs?dfs->port:0);
    //fprintf(stderr, "dfs_addr: %s\n", dfs_addr);
    //fprintf(stderr, "path: %s\n", path);
    //fflush(stderr);
    //basic_info("(local) %s", path);

    //sleep(1);
    char level_str[32];
    sprintf(level_str, "%d", Supr_options.level);

    char verbose_str[32];
    sprintf(verbose_str, "%d", verbose);

     rc = execl(path, path, // "-port", port_str,
	  strstr(addr,":")? "-port":"",
	  strstr(addr,":")?  (strstr(addr,":")+1) : "0",
//                 "-usr", Supr_usrHome, "-sys", Supr_sysHome, // FIXME
 //                "-dfs", Supr_dfsHome,
		 "-info", info_addr?info_addr : "",
                 "-driver", driver_addr,
                 "-notify", driver_addr,
                 "-dfs", dfs_addr,
                 "-ntrs", "0",
                 "-master", master_addr,
		 //"-v", verbose,
		 "-verbose", verbose_str,
                 Supr_verbose ? "--verbose" : "", // ... deprecated ...
                 Supr_debug ?  "--debug" : "",  // ... deprecated ...
                 Supr_infov ?  "--info" : "", // ... deprecated ...
		 "-level", level_str,
		 "-X11", X11_str,
                 (char *) NULL);
  } else {

    //fprintf(stderr, "remote, host: %s\n", host);

    /*
    const char *format = "bash -c 'source .suprrc;" //" env;"
         " $SUPR_SYS_HOME/bin/worker -port %d -master %s -ntrs  %d %s %s"
         " -usr %s -sys %s -dfs %s -driver %s'";

    char ssh_arg[strlen(format) + strlen(master) + 256 + 5*PATH_MAX];
    int ntrs_int = 0;
    sprintf(ssh_arg, format, port, master_addr, ntrs_int, 
    		Supr_verbose ? "--verbose" : "",
    		Supr_debug ? "--debug" : "",
	       	Supr_usrHome, Supr_sysHome, Supr_dfsHome, driver_addr);

    */


    basic_info("(remote) ssh [X11_str=%s] %s %s\n", X11_str, host, ssh_arg);

    //int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    if(verbose){
      char v[32];
      v[0] = '-';
      for(int i=0; i<verbose; i++) v[i+1] = 'v';
      v[verbose+1] = '\000';
      fprintf(stderr, "[stderr] ssh [X11_str=%s] %s %s %s\n", X11_str, v, host, ssh_arg);
      //rc = execl("/usr/bin/ssh", "ssh", "-Y", v, host, ssh_arg, (char*) NULL);
      rc = execl("/usr/bin/ssh", "ssh", v, host, ssh_arg, (char*) NULL);
    } else {
      fprintf(stderr, "[stderr] ssh -Y %s %s\n", host, ssh_arg);
      //rc = execl("/usr/bin/ssh", "ssh", "-Y", host, ssh_arg, (char*) NULL);
      rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    }


    /*
    fprintf(stderr, "Error: [%s] run worker: rc =  %d, %s\n", __func__,
       rc, strerror(errno));
       */
    //exit(EXIT_FAILURE);
  }

  if(rc == -1) {
      info_sc = NULL;
      if(info_addr) info_sc = socketOpen1(info_addr);
      error_info("%s, %s", __func__, strerror(errno));
      Supr_decref(info_sc);

      Supr_notify(driver_addr, Supr_hostname, CLUSTER_CONNECT_MASTER);
  }

  return NULL; // not reached
}

void Driver_startWorkers(supr_socket_conn_t *master, supr_socket_conn_t *dfs)
{
  //char master[256];
  //sprintf(master, "//%s:%d", driverServerConn->host,
  //               driverServerConn->port);
  //fprintf(stderr, "\033[0;34mmaster_conn: %p\n", master_conn);
  //fflush(stderr);
  //if(!master_conn) return;

  //fprintf(stderr, "master: //%s:%d\033[0m\n", master_conn->host, master_conn->port);
  //fflush(stderr);
  //sprintf(master, "//%s:%d", master_conn->host, master_conn->port);

  char cn_file[PATH_MAX];
  //sprintf(cn_file, "%s/conf/nodes", SUPR_HOMEUSR);
  sprintf(cn_file, "%s/supr.conf", Supr_usrHome);

  int rc = access(cn_file, R_OK);
  int fd = open(cn_file, O_RDWR, 0600);
  struct stat sb;
  if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {

        char buf[sb.st_size+1];
        read(fd, buf, sb.st_size);
        close(fd);

        char *name = "Worker";

        buf[sb.st_size] = 0;
        //fprintf(stdout, "conf/node, %s\n", buf);
        char *line = strtok(buf, "\n");
        char *namenode_line = NULL;
        while(line){
          for(; line; line++)
                  if(!isspace(*line)) break;
          if(!line) continue;

          fprintf(stdout, "\033[0;33m%s\033[0m\n", line);
          if(strncmp(line, name, strlen(name))==0)
          {
            //namenode_line = line;
            fprintf(stderr, "\033[0;34m* %s: %s\033[0m\n", name, line);

	    char *addr = strstr(line, "//");
	    if(addr){
               addr += 2;
	       //int pong = tryPingSocketServer1(addr);
	       //if(pong != CLUSTER_PONG){
               fprintf(stderr, "\n\n");
                 Driver_startWorker(line, master, dfs);
	       //}
	    }
            //Driver_startWorker(line, master, dfs);
          }
          line = strtok(NULL, "\n");
        }
  } else {
        fprintf(stdout, "Error: %s, %s\n", cn_file, strerror(errno));
  }
  fflush(stdout);

}
#endif

void main_thread_start_master(void *data){
  char *addr = (char*)data;
  if(addr) {
    supr_socket_conn_t *sc = trySocketOpen1(addr);
    if(!sc) {
      sc = Driver_startMaster(addr);
    }
    free(addr);
  }

#ifdef DRIVER_START_WORKERS

  if(master_conn) Driver_startWorkers(master_conn, DFS_namenode);

#endif

}

void REPL_cleanup(void *data){
	supr_thread_t *cth = SUPR_CURRENT_THREAD();
	cth->state = THREAD_STATE_TERMINATED;
	sleep(1);
  exit(EXIT_SUCCESS);
}

// FIXME: manage info_sc ...
void  R_REPL(supr_thread_t *this_thread, int argc, char **argv)
{
  pthread_cleanup_push(REPL_cleanup, NULL);
//  printf("[%s]\n", __func__);

  SUPR_setSignalHandler(Driver_SigactionSIGINT, Driver_SigactionSIGUSR1,
		 Driver_SigactionSIGUSR2);

  //if(!DFS_namenode || !master_conn) 
  // start master if necessary
  // start dfs if necessary

  //
  if(!master_conn) {

    supr_socket_conn_t *conn  = Driver_startMaster(master_addr);
    pthread_mutex_lock(&Supr_syncMutex);
	  master_conn = conn;
    pthread_mutex_unlock(&Supr_syncMutex);
  }


  if(!DFS_namenode) {

    sprintf(msg, "[%s:%d:%s] Driver_startDFS(%s)", __FILE__, __LINE__,
		    __func__, dfs_addr);
    Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

    supr_socket_conn_t *conn = Driver_startDFS(dfs_addr);
    pthread_mutex_lock(&Supr_syncMutex);
	  DFS_namenode = conn;
    pthread_mutex_unlock(&Supr_syncMutex);
  }

  //

  
#ifdef DRIVER_START_WORKERS
  if(master_conn) Driver_startWorkers(master_conn, DFS_namenode);
  //let master to start...
  //or add mew one if neccessary?
#endif

  int i=0;
  verbose_info("main thread is ready");

  while(TRUE){
    while(TRUE){
      main_thread_task_t *task = NULL;
      pthread_mutex_lock(main_thread_tasks->mutex);
        if(vectorSize(main_thread_tasks))
          task = (main_thread_task_t *) vectorRemove(main_thread_tasks,0);
      pthread_mutex_unlock(main_thread_tasks->mutex);
      if(task == NULL) break;

      BEGIN_R_EVAL();
        Rboolean success = R_ToplevelExec(task->fun, task->data);
        if(!success)
	      error_info(R_curErrorBuf());
      END_R_EVAL();
      free(task);
    }

    pthread_mutex_lock(&main_thread->mutex);
      int rc = pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
    pthread_mutex_unlock(&main_thread->mutex);

	  /*
    double timeout;
    BEGIN_R_EVAL();
      SEXP sOptions = install(".Options");
      SEXP options = SYMVALUE(sOptions);
      if(TYPEOF(options) == LISTSXP){
         printf("LISTSXP: %s\n", type2char(TYPEOF(options)));
	 while(options != R_NilValue){
           if(strcmp(CHAR(PRINTNAME(TAG(options))), "timeout")==0){
		   timeout =asReal(CAR(options));
		   break;
	   }
	   options  = CDR(options);
	 }
      } else {
         printf("%s\n", type2char(TYPEOF(options)));
      }
    END_R_EVAL();

    if(i==0) timeout =1; else timeout *= i;
    i++;

    struct timespec wait;
    clock_gettime(CLOCK_REALTIME, &wait);
    wait.tv_sec += (long) timeout;

    pthread_mutex_lock(&this_thread->mutex);
      printf("wait: %f\n", timeout);

      //pthread_cond_timedwait(&this_thread->cond, &main_thread->mutex, &wait);
      int rc = pthread_cond_wait(&this_thread->cond, &main_thread->mutex);
      if(rc == 0 && this_thread->fun){
        BEGIN_R_EVAL();
	  errno = 0;
	  int success = R_ToplevelExec(this_thread->fun, this_thread->data);
	  if(!success) { // error_info
	    basic_info(R_curErrorBuf());
	    if(errno)
	      basic_info(strerror(errno));
	  }
	  this_thread->fun = NULL;
	  this_thread->data = NULL;
        END_R_EVAL();
      } else {
	      sprintf(msg, "rc: %d (man pthread_cond_wait)", rc);
      }

      //CheckStatus();

    pthread_mutex_unlock(&this_thread->mutex);

    printf("[%s] eval\n", __func__);
    // eval ...
    */
  }
  pthread_cleanup_pop(TRUE);
}

extern void doCleanups();

int system_exit(int n){
  // cleanups later...
	/*
  if(cleanups){
    for(int i=vectorSize(cleanups)-1; i>=0; i--){
      do_t *cleanup = (do_t *) vectorElementAt(cleanups, i);
      printf("[%s] do_cleanup %p\n", __func__, cleanup);
      cleanup->_do_(cleanup->data);
    }
  }
  */

  doCleanups();

  char path[PATH_MAX];
  sprintf(path, "%s/driver.log", Supr_usrHome);
  unlink(path);

  //sleep(30);

  exit(n);
}

void test__do_(void *data)
{
	printf("[%s] %s\n", __func__, (char*)data);
}


/*
void  Driver_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));

  printf("\033[0;31mmain_thread = <%p>\033[0m\n", main_thread);
  if(main_thread){
    printf("\033[0;31mmain_thread->tid : %d\033[0m\n", main_thread->tid);
    printf("\033[0;31mmain_thread->ptid: %ld\033[0m\n", main_thread->ptid);
    printf("\033[0;31mmain_thread->mutex.__data.__owner: %d\033[0m\n",
                    main_thread->mutex.__data.__owner);
  }

  printf("\033[0;31m R_REPL: <%p>, %lx\033[0m\n", R_REPL, (long) R_REPL);
  printf("\033[0;31m pthread_cond_wait: <%p>, %lx\033[0m\n", pthread_cond_wait,
                  (long) pthread_cond_wait);
  c_backtrace();

  printf("\033[0;31mpthreads: %s\033[0m\n", objectToString(threads));
  for(int i=0; i<vectorSize(threads); i++){
    supr_thread_t * th = (supr_thread_t *) vectorElementAt(threads, i);
    if(th == currentThread()) continue;
    pthread_kill(th->ptid, SIGINT);
  }

  if(currentThread() != main_thread){
    pthread_mutex_lock(&main_thread->mutex);
      pthread_cond_signal(&main_thread->cond);
    pthread_mutex_unlock(&main_thread->mutex);
    pthread_exit(NULL);
  }


  exit(1);
  //R_oldIntAct.sa_sigaction(sig, ip, context);

}
*/


extern int Config_getPort(const char* name);

#define USE_DOT_SUPRRC
#ifdef  USE_DOT_SUPRRC
/*
void Driver_startWorker(char *addr, const char *master, int argc, char** argv)
{
  fprintf(stderr, "[%s] addr: %s\n", __func__, addr);

  static int nlocalhost = 0;

  char *host = strstr(addr, "//")+2;
  char *port_str = strstr(host, ":");
  *port_str = 0;

  port_str++;
  int port_int = atoi(port_str);
  char *ntrs = strstr(port_str, "ntrs=");
  int ntrs_int = 0;
  if(ntrs){
    ntrs += strlen("ntrs=");
    ntrs_int = atoi(ntrs);
  }

  if(strcmp(host, "localhost")==0)
    host = Supr_hostname;

  if(strcmp(host, Supr_hostname)==0)
  {
    nlocalhost ++;
    if(nlocalhost>1) return;
  }

  pid_t pid = fork();



  if(pid == -1) {
    fprintf(stderr, "Error: fork(), %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  } else if(pid) {
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    fprintf(stderr, "[%s] waitpid(pid=%d, &status, 0): %d, status: %d\n",
		    __func__, pid, rc, status);

    if(status == 0){
      pthread_mutex_lock(worker_count_mutex);
        worker_count++;
      pthread_mutex_unlock(worker_count_mutex);
    } else { // FIXME?
      pthread_mutex_lock(worker_count_mutex);
	fprintf(stderr, "Warning: %s (%s), status: %d\n",
		__func__, host, status);
        worker_count++;
      pthread_mutex_unlock(worker_count_mutex);
    }
    
    if(status && WIFEXITED(status)) {
      fprintf(stderr, "WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
      fprintf(stderr, "WEXITSTATUS(status): %d, ssh %s ...\n",
		       WEXITSTATUS(status), host);
    }
    return;
  } else {
  
    //const char *format = "source .suprrc;" //" env;"
    //    " $SUPR_SYS_HOME/bin/worker -port %d -master %s -ntrs  %d -verbose %s"
    //    " -usr %s -sys %s -dfs %s";
    const char *format = "bash -c 'source .suprrc;" //" env;"
         " $SUPR_SYS_HOME/bin/worker -port %d -master %s -ntrs  %d -verbose %s"
         " -usr %s -sys %s -dfs %s'";

    char ssh_arg[strlen(format) + strlen(master) + 256 + 3*PATH_MAX];
    sprintf(ssh_arg, format, port_int, master, ntrs_int, 
    		Supr_verbose ? "TRUE" : "FALSE", Supr_usrHome,
		Supr_sysHome, Supr_dfsHome);

    fprintf(stderr, "ssh %s %s\n", host, ssh_arg);
    int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    fprintf(stderr, "Error: [%s] run worker: rc =  %d, %s\n", __func__,
       rc, strerror(errno));
    exit(EXIT_FAILURE);
  }
}
*/

#else
// fixme
void Driver_startWorker(char *addr, const char *master, int argc, char** argv)
{
  fprintf(stderr, "[%s] addr: %s\n", __func__, addr);

  errno = 0;
  int rc = isatty(STDOUT_FILENO);
  if(errno) {
          printf("[%s] Error: %s STDOUT_FILENO: %d (%s:%d)\n", __func__,
                          strerror(errno), STDOUT_FILENO,
                          __FILE__, __LINE__);
          return;
  }
  if(rc){
    char buf[PATH_MAX];
    int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
    if(rc) {
          printf("[%s] Error: %s (%s:%d)\n", __func__, strerror(errno),
                          __FILE__, __LINE__);
          return;
    }
    printf("ttyname: %s\n", buf);
  }

  char *_window = NULL;
  for(int i=0; i<argc; i++){
    printf("argv[%d]: %s\n", i, argv[i]);
    if(strcmp(argv[i], "-worker.stdout")==0 && i <argc-1 &&
       strcmp(argv[i+1], "--window")==0)
       _window = "--window";
  }

#define USE_XTERM 1
  pid_t pid = fork();
  if(pid)
    return;


  SocketConn_closeAll(socket_connections, 0);

  pid = getpid();
  char CMD_PATH[PATH_MAX];
  sprintf(CMD_PATH, "/usr/bin/ssh");
  char ssh_arg[strlen("'cd supr/src; worker -port -master --window'") + strlen(addr)
        + strlen(master)+2];

  char *hostname = strstr(addr, "//")+2;
  char *str = strstr(hostname, ":");
  *str = 0; str++;
  sprintf(ssh_arg, "'cd supr/src; worker -port %s -master %s%s'", str, master,
                  _window? " --window":""); // FIXME

  if(_window){
    // ssh -Y host 'gnome-terminal --window -- /bin/bash -c "cd supr/src; T"'
    char ssh_arg[1024];
    sprintf(ssh_arg, "'gnome-terminal --window -- /bin/bash -c \"sleep 60; cd supr/src;"
                   " worker -port %s -master %s; exec bash\"'", str,
                   master);

    printf("\033[0;32mhostname: %s\033[0m\n", hostname);
    printf("\033[0;32mssh_arg: %s\033[0m\n", ssh_arg);

    int rc = execl("/usr/bin/ssh",  "ssh", hostname, ssh_arg, (char*) NULL);
    /*
    char cmd[1024];
    sprintf(cmd, "ssh %s %s", hostname, ssh_arg);
    printf("\033[0;32mcmd: %s\033[0m\n", cmd);
    int rc = system(cmd);
    */

    printf("[%s] run worker: rc =  %d, %s\n", __func__, rc, strerror(errno));
    exit(0);

  }


  //char *dir_name = "00"; //to do
  if(USE_XTERM && rc){

    char *X11 = "-Y";
    char *argv[] = {
          CMD_PATH, X11, hostname, ssh_arg,
          (char*) NULL
      };

    char window_name[256];
    sprintf(window_name, "Worker@%s", hostname);
    supr_xterm_t *xterm = supr_xterm3(window_name, argv, _window != NULL);
    if(xterm) {
      printf("[%s] run worker: xterm =  %p\n", __func__, xterm);
    } else {
      printf("[%s] run worker: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
    }

    exit(0);

  } else {
    int rc = execl(CMD_PATH, "ssh",
                  hostname, ssh_arg,
                  (char*) NULL);
    printf("[%s] run worker: rc =  %d, %s\n", __func__, rc, strerror(errno));
    exit(0);
  }

}
#endif

#ifndef USE_NEW_Driver_startWorkers
void Driver_startWorkers(int argc, char **argv, )
{
  char master[256];
  //sprintf(master, "//%s:%d", driverServerConn->host,
   //               driverServerConn->port);
  fprintf(stderr, "\033[0;34mmaster_conn: %p\n", master_conn);
  fflush(stderr);
  if(!master_conn) return;

  fprintf(stderr, "master: //%s:%d\033[0m\n", master_conn->host,
	master_conn->port);
  fflush(stderr);
  sprintf(master, "//%s:%d", master_conn->host, master_conn->port);

  char cn_file[PATH_MAX];
  //sprintf(cn_file, "%s/conf/nodes", SUPR_HOMEUSR);
  sprintf(cn_file, "%s/supr.conf", Supr_usrHome);

  int rc = access(cn_file, R_OK);
  int fd = open(cn_file, O_RDWR, 0600);
  struct stat sb;
  if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {

        char buf[sb.st_size+1];
        read(fd, buf, sb.st_size);
        close(fd);

        char *name = "Worker";

        buf[sb.st_size] = 0;
        //fprintf(stdout, "conf/node, %s\n", buf);
        char *line = strtok(buf, "\n");
        char *namenode_line = NULL;
        while(line){
          for(; line; line++)
                  if(!isspace(*line)) break;
          if(!line) continue;

          fprintf(stdout, "\033[0;33m%s\033[0m\n", line);
          if(strncmp(line, name, strlen(name))==0)
          {
            //namenode_line = line;
            fprintf(stderr, "\033[0;34m* %s: %s\033[0m\n", name, line);
            Driver_startWorker(line, master, argc, argv);
            //sleep(2);
            //break;
          }
          line = strtok(NULL, "\n");
        }
  } else {
        fprintf(stdout, "Error: %s, %s\n", cn_file, strerror(errno));
  }
  fflush(stdout);
}
#endif // USE_NEW_Driver_startWorkers

void  Driver_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));

  char msg[256];
  sprintf(msg, "ip->si_fd: %d", ip->si_fd);
  basic_info(msg);
  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    if(sc->fd == ip->si_fd){
      sprintf(msg, "ip->si_fd: %d, sc: '%s:%d'", ip->si_fd,
		      sc->host, sc->port);
      basic_info(msg);
      break;
    }
  }

  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s] %s pid=%d, tid=%ld\033[0m\n", proc_cmd,
		    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);
}


/* Make it simple
 *
 * stdout: driver/driver.out
   */

extern int setDir(const char *dir_path, const char *subdir); // util.c

extern void runAsDaemon(char *dir);


char *driverDir()
{
  if(!Supr_usrHome)
    Supr_usrHome = getenv("SUPR_USR_HOME"); // FIXME

  char path[PATH_MAX];
  struct stat sb;
  if(!Supr_usrHome) {
     char *home = getenv("HOME"); // FIXME
     if(!home){
           fprintf(stderr, "No home directory is avialable");
           return NULL;
     }
     sprintf(path, "%s/.supr", home);
     if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
       Supr_usrHome = strdup(path);
     else if(mkdir(path, 0700) != -1)
       Supr_usrHome = strdup(path);
  }
  
  if(!Supr_usrHome) {
           fprintf(stderr, "No usr.home is avialable");
           return NULL;
  }
  
  sprintf(path, "%s/%s", Supr_usrHome, SYS_COMMAND_DRIVER);
  
  if(stat(path, &sb) == -1) {
    if(mkdir(path, 0700) == -1){
      perror(path);
      return NULL;
    }
  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    return NULL;
  }
  
  return strdup(path);
}

static const char *__doc__ =
"driver [-port n] [--verbose] [--debug] [--info] [--help]\n"
"\t[-info addr] [-notify addr] [-shm name] [-master addr]\n"
"\t[-dfs addr]";


#define DEFAULT_DRIVER_TIMEOUT 60


static char *getDefaultAddr(const char *which){
  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  struct stat sb;
  int fd = open(path, O_RDONLY);
  if(fd != -1 && fstat(fd, &sb) != -1) {

    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    buf[sb.st_size] = 0;
    close(fd);

    char *s = buf;
    while((s = strstr(s, which)) && (s = strstr(s, "//"))){
      char *t = strstr(s, "\n") + 2;
      if(t) {*t=0; t++;}
      if(strstr(s, Supr_hostname)){
         s = strdup(s);
         break;
      }
      s = t;
    }

    if(s) return s;
  }

  char buf[strlen(Supr_hostname)+32];
  sprintf(buf, "%s:1024+", Supr_hostname);
  return strdup(buf);
}


char *cmd_is_running(const char *dir, const char *cmd, char **file_name_addr){
  char path[PATH_MAX];
  if(dir) strcpy(path, dir);
  else getcwd(path, PATH_MAX);
  char *log = NULL;
  while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
  sprintf(path+strlen(path), "/%s.log", cmd);
  *file_name_addr = strdup(path);
  if(access(path, F_OK)==0){
    struct stat statbuf;
    int fd = open(path, O_RDONLY);
    int rc = fstat(fd, &statbuf);
    if(rc==0 && fd !=-1){
      log = malloc(statbuf.st_size+1);
      read(fd, log, statbuf.st_size);
      log[statbuf.st_size] = 0;
    }
    close(fd);
  }

  return log;
}



void rmConnLog()
{
  char path[PATH_MAX];
  while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
  sprintf(path, "%s/%s.log", Supr_usrHome, cmd);
  unlink(path);
}

extern pid_t main_pid;

void send_ExitInfo(){
  if(getpid() != main_pid) return;

  if(info_sc){
      close(info_sc->fd);
      info_sc = NULL;
  }

  /*
  if(info_addr){
    if(info_sc) close(info_sc->fd);
    //int rc = pthread_mutex_trylock(&Supr_syncMutex);
    //if(rc != 0) {
        pthread_mutex_destroy(&Supr_syncMutex);
        pthread_mutex_init(&Supr_syncMutex, NULL);

      char *hostname = strdup(info_addr);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      info_sc = socketOpen2(hostname, port);
      if(info_sc) {
        info_sc->mutex = malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(info_sc->mutex, NULL);

        info_sc->port = port;
        int cmd = CLUSTER_PROC_CMD;
        write(info_sc->fd, &cmd, sizeof(int));
        int len = strlen(proc_cmd)+1;
        write(info_sc->fd, &len, sizeof(int));
        write(info_sc->fd, proc_cmd, len);
        int rc;
	ssize_t size = timed_read(info_sc->fd, &rc, sizeof(int));
      }
      free(hostname);
    //} else pthread_mutex_unlock(&Supr_syncMutex);
  }
  */


  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  basic_info(__func__);
  if(cth) basic_info(cth->name);
  else return;

  supr_socket_conn_t *sc = NULL;
  if(info_addr && (sc = trySocketOpen1(info_addr))){
    int fd = sc->fd;

    int cmd = CLUSTER_PROC_CMD;
    write(fd, &cmd, sizeof(int));
    int len = strlen(proc_cmd)+1;
    write(fd, &len, sizeof(int));
    write(fd, proc_cmd, len);
    int rc;
    read(fd, &rc, sizeof(int));

    char msg[1024];

    if(Supr_options.verbose){
    for(int i=0; threads && i<vectorSize(threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);

      // msg_header?
      cmd = CLUSTER_INFO;
      write(fd, &cmd, sizeof(int));
      unsigned char buf[8]; 
      snprintf(buf, 8, "%s", msg_color); 
      write(fd, buf, sizeof(buf));
      int type = DEFAULT_INFO_TYPE;
      write(fd, &type, sizeof(int));
      int level = 0; // not used
      write(fd, &level, sizeof(int));

      sprintf(msg, "\033[0;33m%s:%d: %s, tid: %d, state: %s, \tname: %s\033[0m",
		    __FILE__, __LINE__, __func__, 
		    th->tid, state2char(th->state), th->name);

      ssize_t len_msg = strlen(msg)+1;
      write(fd, &len_msg, sizeof(ssize_t));
      write(fd, msg, len_msg);
      read(fd, &rc, sizeof(int));
    }
    }

    cmd = CLUSTER_INFO;
    write(fd, &cmd, sizeof(int));
    unsigned char buf[8]; 
    snprintf(buf, 8, "%s", msg_color); 
    write(fd, buf, sizeof(buf));
    int type = DEFAULT_INFO_TYPE;
    write(fd, &type, sizeof(int));
    int level = 0; // not used
    write(fd, &level, sizeof(int));

    sprintf(msg, "\033[0;35m%d %s[%s], .., terminated\033[0m",
		    getpid(), __func__, Supr_curStrError);

    ssize_t len_msg = strlen(msg)+1;
    write(fd, &len_msg, sizeof(ssize_t));
    write(fd, msg, len_msg);
    read(fd, &rc, sizeof(int));

  } else {
    fprintf(stderr, "func: %s[%s], this tid: %ld, pid: %d ..., terminated",
		    __func__, Supr_curStrError,
		    syscall(SYS_gettid),  getpid());
  }

	/*
  if(getpid() != main_pid)
	  return;

  basic_info(__func__);
  char buf[1024];
  sprintf(buf,"pid: %d, ...", getpid());
  basic_info(buf);
  //sleep(120);
  */
}


SEXP driver_cluster_job(SEXP S_job_id){
  SEXP retval = R_NilValue;
  int job_id = asInteger(S_job_id);
  char msg[1024];

  job_t *job = findJob(job_id);
  /*
    for(int i=0; i < vectorSize(jobs); i++){
      job = (job_t *) vectorElementAt(jobs, i);
      if(job->id == job_id) break; else job = NULL;
    }
    */
  if(job){
    pthread_mutex_lock(&job->mutex);
      // Tasks
      iterator_t *iter = job->tasks;

      // Task runners
      vector_t *taskrunners = job->taskrunners;

      // Executors
      vector_t *executors = job->executors;

      // Sync monitors
      pthread_mutex_lock(&sync_mutex);
	int n;
        char **keys = hashtableKeySet(syncHashtable, &n);
	qsort(keys, n, sizeof(char *), rjni_strcmp);
	for(int i=0; i<n; i++) {
	  vector_t *queue = (vector_t *) hashtableGet(syncHashtable, keys[i]);
	  sprintf(msg, "name: %s, length: %d", keys[i], vectorSize(queue));
	  basic_info(msg);
	  for(int j=0; j<vectorSize(queue); j++){
            sync_wait_t *sw = (sync_wait_t *) vectorElementAt(queue, j);
	    sprintf(msg, "%d. {host: %s, job_id: %d, tid: %d}",
			    j+1, sw->sc->host, sw->job_id, sw->tid); 
	    basic_info(msg);
	  }
	}

        keys = hashtableKeySet(waitHashtable, &n);
	qsort(keys, n, sizeof(char *), rjni_strcmp);
	for(int i=0; i<n; i++) {
	  vector_t *queue = (vector_t *) hashtableGet(waitHashtable, keys[i]);
	  sprintf(msg, "name: %s, length: %d", keys[i], vectorSize(queue));
	  basic_info(msg);
	  for(int j=0; j<vectorSize(queue); j++){
            sync_wait_t *sw = (sync_wait_t *) vectorElementAt(queue, j);
	    sprintf(msg, "%d. {host: %s, job_id: %d, tid: %d}",
			    j+1, sw->sc->host, sw->job_id, sw->tid); 
	    basic_info(msg);
	  }
	}

      pthread_mutex_unlock(&sync_mutex);
    pthread_mutex_unlock(&job->mutex);
    JOB_DECREF(job);
  }
    
  return retval;
}

SEXP driver_cluster_jobs(){

  pthread_mutex_lock(jobs->mutex);

  int n = vectorSize(jobs);

  if(n == 0) {
    pthread_mutex_unlock(jobs->mutex);
    return R_NilValue;
  }

  int m = 3;
  SEXP retval;
  BEGIN_R_EVAL();
    retval = PROTECT(allocVector(VECSXP, m));
    setAttrib(retval, R_ClassSymbol, mkString("data.frame"));
//    SEXP row_names = PROTECT(allocVector(STRSXP, n));
    SEXP names = PROTECT(allocVector(STRSXP, m));
    setAttrib(retval, R_NamesSymbol, names);

    SET_STRING_ELT(names, 0, mkChar("id"));
    SET_STRING_ELT(names, 1, mkChar("is.done"));
    SET_STRING_ELT(names, 2, mkChar("ntr"));

    SEXP id = PROTECT(allocVector(INTSXP, n));
    SEXP isDone = PROTECT(allocVector(LGLSXP, n));
    SEXP ntr = PROTECT(allocVector(INTSXP, n));

    SET_VECTOR_ELT(retval, 0, id);
    SET_VECTOR_ELT(retval, 1, isDone);
    SET_VECTOR_ELT(retval, 2, ntr);

    SEXP row_names = PROTECT(allocVector(STRSXP, n));
    setAttrib(retval, install("row.names"), row_names);
    char buf[256];

    for(int i=0; i < vectorSize(jobs); i++){
      job_t *job = (job_t *) vectorElementAt(jobs, i);
      INTEGER(id)[i] = job->id;
      INTEGER(isDone)[i] = job->result != NULL;
      INTEGER(ntr)[i] = vectorSize(job->taskrunners);
      sprintf(buf, "%d:", i+1);
      SET_STRING_ELT(row_names, i, mkChar(buf));
    }

    UNPROTECT(6);
  END_R_EVAL();

  pthread_mutex_unlock(jobs->mutex);
  return retval;
}


int main(int argc, char **argv)
{
  //proc_cmd = argv[0];
  //while(strstr(proc_cmd, "/")) proc_cmd = strstr(proc_cmd, "/")+1;

  __start_master_fun__ = main_thread_start_master;
  __start_dfsname_fun__ = main_thread_start_dfsname;
  __cluster_jobs_ptr__  = driver_cluster_jobs;
  __cluster_job_ptr__  = driver_cluster_job;

  int port = -1;
  //SocketConn_reuseAddr = TRUE; // wrong name

  cmd = "driver";

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--verbose")==0){
      Supr_options.verbose = Supr_verbose = TRUE;
    } else if(strcmp(argv[i], "--debug")==0){
      Supr_options.debug = Supr_debug = TRUE;
    } else if(strcmp(argv[i], "--info")==0){
      Supr_options.info = Supr_infov = TRUE;
    } else if(strcmp(argv[i], "-master")==0 && i+1 < argc){
	    master_addr = argv[++i];
    } else if(strcmp(argv[i], "-dfs")==0 && i+1 < argc){
	    dfs_addr = argv[++i];
    } else if(strcmp(argv[i], "-notify")==0 && i+1 < argc){ // TODO
	    notify_addr = argv[++i];
    } else if(strcmp(argv[i], "-level")==0 && i+1 < argc){ // TODO
      Supr_options.level = atoi(argv[++i]);
    } else if(strcmp(argv[i], "-port")==0 && i < argc-1){
       port = atoi(argv[++i]);
       if(port < 1024) port = 1024;
       if(strstr(argv[i], "+")) nports = 0;
    } else if(strcmp(argv[i], "-X11")==0 && i < argc-1){
       X11_str = argv[++i];
    }
  }

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-info")==0 && i+1 < argc){
      info_addr = strdup(argv[i+1]);
      char *hostname = strdup(info_addr);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      info_sc = socketOpen2(hostname, port);
      if(info_sc) {
        info_sc->mutex = malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(info_sc->mutex, NULL);

        info_sc->port = port;
	int cmd = CLUSTER_PROC_CMD;
        write(info_sc->fd, &cmd, sizeof(int));
        int len = strlen(proc_cmd)+1;
        write(info_sc->fd, &len, sizeof(int));
        write(info_sc->fd, proc_cmd, len);
	int rc;
        ssize_t size = timed_read(info_sc->fd, &rc, sizeof(int));
	if(size == -1){
	   fprintf(stderr, "%s:%d. (info_sc) timed_read: %s\n", __FILE__,
			   __LINE__, strerror(errno));
	}
      }
      verbose_info(argv[0]);
      free(hostname);
      break;
    }
  }

  //for(int i=0; i<argc; i++) verbose_info(argv[i]);
  //for(int i=0; i<argc; i++) basic_info(argv[i]);
  argv_info(argc, argv);

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--help")==0){
      fprintf(stderr, "%s\n", __doc__);
      exit(EXIT_SUCCESS);
    }
  }




#ifdef RUN_AS_DAEMON_PROC
  char *dir = driverDir();
  if(!dir) {
    char buf[1024];
    sprintf(buf, "Error in mkDriverDir, %s", strerror(errno));
    Cluster_sendSimpleMessage(buf, "\033[0;32m", VERBOSE_INFO_TYPE, 0);
    exit(EXIT_FAILURE);
  }

  runAsDaemon(dir);

  main_pid = getpid();
  atexit(send_ExitInfo);

  char *cmd_log = NULL;
  char *file_name = NULL;
  pid_t driver_pid;
  if(cmd_log = cmd_is_running(Supr_usrHome, cmd, &file_name)) {
    sprintf(msg, "Warning: %s exists,\n%s", file_name, cmd_log);
    Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);

    if(strstr(cmd_log, "pid:")){
      pid_t pid = atoi(strstr(cmd_log, "pid:") + 4);
      driver_pid = pid;
      errno = 0;
      int rc = kill(pid, 0);
      if(rc == 0){
        basic_info("kill(%d, 0): %d, %s", pid, rc, strerror(errno));
      } else if(rc == -1 && errno == ESRCH){
        sprintf(msg, "kill(%d, 0): %s", pid, strerror(errno));
        Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
        char path[PATH_MAX];
        sprintf(msg, "Removing %s", file_name);
        Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
        unlink(file_name);
        free(cmd_log);
        free(file_name);
        cmd_log = NULL;
      }
    } else {
      error_info("pid not found");
    }
  }

  if(cmd_log){
    if(nports){
      if(notify_addr){
        Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_DRIVER);
      }
      Cluster_sendSimpleMessage("q(\"no\")", msg_color, ERROR_INFO_TYPE, 0);
      exit(EXIT_FAILURE);
    } else {
      kill(driver_pid, SIGKILL);
      basic_info("ignore driver.log: %s", cmd_log);
      free(cmd_log);
      free(file_name);
      cmd_log = NULL;
    }
  }


 
  {
    struct sigaction sa;
    sa.sa_sigaction = Driver_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, &R_oldSegvAct);
  }

  //

  if(FALSE && info_addr){
    char *hostname = strdup(info_addr);
    char *s = strstr(hostname, ":");
    if(s) *s = 0; s++;
    int port = atoi(s);
    info_sc = socketOpen2(hostname, port);
    if(info_sc) {
        info_sc->port = port;
	int cmd = CLUSTER_PROC_CMD;
        write(info_sc->fd, &cmd, sizeof(int));
        char *proc_cmd = argv[0];
        while(strstr(proc_cmd, "/"))
          proc_cmd = strstr(proc_cmd, "/")+1;
        int len = strlen(proc_cmd)+1;
        write(info_sc->fd, &len, sizeof(int));
        write(info_sc->fd, proc_cmd, len);
	int rc;
        read(info_sc->fd, &rc, sizeof(int));
    }
    Cluster_sendSimpleMessage("Reconnected", "\033[0;32m", VERBOSE_INFO_TYPE, 0);
    Cluster_sendSimpleMessage(argv[0], "\033[0;32m", VERBOSE_INFO_TYPE, 0);

    char CWD_PATH[PATH_MAX]; 
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "CWD: %s", CWD_PATH);
    Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);


    free(hostname);
  } else if(Supr_infov){
      char CWD_PATH[PATH_MAX]; 
      getcwd(CWD_PATH, PATH_MAX);
      sprintf(msg, "CWD: %s", CWD_PATH);
      Cluster_sendSimpleMessage(msg, "\033[0;32m", BASIC_INFO_TYPE, 0);
  }

  if(Supr_debug){
    char buf[256];
    sprintf(buf, "driver pid: %d", getpid());
    Cluster_sendSimpleMessage(buf, "\033[0;32m", DEBUG_INFO_TYPE, 0);
  }


//

  //
  //-------------------------------------------------
  //
  // output goes to driver/stdout.txt and stderr.txt
  //
  if(Supr_verbose){
    char buf[256];
    char msg[1024];
    snprintf(msg, 1024, "host: %s, ppid: %d, pid: %d\nTime: %s\n",
                  Supr_hostname, getppid(), getpid(),
                  Exec_timestamp(buf, sizeof(buf)));
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }
#endif
  /*
  {
	  FILE *out = fopen("/dev/pts/46", "w");
	  dup2(fileno(out), STDOUT_FILENO);
	  dup2(fileno(out), STDERR_FILENO);
  }
  */

  //Supr_verbose = TRUE;

  //if(!DriverJob_class){
	  class_init(); 
  //}
  
  JOB_CANCELLED = malloc(sizeof(int)); // FIXME
 

#define SUPR_DEBUG
#ifndef SUPR_DEBUG
  int devNull = open("/dev/null", O_WRONLY);
  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);
  dup2(devNull, STDERR_FILENO);
  dup2(devNull, STDOUT_FILENO);
#endif

//	  printf("\n\n\n---------------Driver --------------\n");
  for(int i=0; i<argc; i++) fprintf(stdout, " %s", argv[i]);
  fprintf(stdout, "\n");// fflush(stdout);

  cmd_argv = argv;
  cmd_argc = argc;

  char name[256];
  gethostname(name, 256);
  localhost = strdup(name);

  Cluster_sendSimpleMessage(localhost, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  if(!special_socket_connections)
    special_socket_connections = newVector(TRUE);

  // FIXME
  void *dummy = NULL;
  PTHREAD_NOTIFIED = &dummy;

  //pthread_key_create(&currentThreadKey, NULL);

    // testing
  //printf("Initializing ...\n");
  {
    //cleanups = newVector(TRUE); // init by dl_init
    run_t *test_do = (run_t *)malloc(sizeof(run_t));
    test_do->data = "\033[0;31mTESTING\033[0m";
    test_do->run = test__do_;
    vectorAdd(cleanups, test_do);
  }

  int rc = setpgrp(); // set process group to itself
  if(rc == -1) {
      printf("Error: %s\n", strerror(errno));
  }
  //for(int i=0; i<argc; i++){ printf("%d. %s\n", i, argv[i]); }

//  int port = -1; // default => ENV, CONF
  char *shm_name = NULL;

  char *_stdout = NULL;

  for(int i=0; i<argc; i++){
     if(strcmp(argv[i], "-port")==0 && i < argc-1)
       port = atoi(argv[++i]);
     else if(strcmp(argv[i], "-shm")==0 && i < argc-1)
       shm_name = argv[++i];
     else if(strstr(argv[i],"-driver") && strstr(argv[i],"stdout") && i<argc-1)
       _stdout = argv[++i];
     else if(strcmp(argv[i], "-reuse.addr")==0 && i < argc-1)
     {
       if(strcmp(argv[++i], "FALSE")==0) SocketConn_reuseAddr = FALSE;
     }
  }

  suprHomeInit();

  if(port <= 0) {
  //  char *port_str = getenv("SUPR_DRIVER_PORT");
   // port = port_str ?  atoi(port_str) : Config_getPort("Driver");
     char *addr = getDefaultAddr("Driver");

    //if(!addr) backend_exit();

    port = atoi(strstr(addr, ":")+1);
    if(strstr(strstr(addr, ":")+1, "+"))
            nports = 0;
    else
            nports = 1;
    fprintf(stderr, "[%s] default port: %d\n", __func__, port);

    sprintf(msg, "use default addr: %s", addr);
    Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
    free(addr);

  }
  
  atexit(rmConnLog);


  // open shm_io
  shm_io_info_t *io = NULL;
  if(shm_name){

    Cluster_sendSimpleMessage("shm_name:", msg_color, VERBOSE_INFO_TYPE, 0);
    Cluster_sendSimpleMessage(shm_name,    msg_color, VERBOSE_INFO_TYPE, 0);

    io = shm_io_open(shm_name);
    {
      printf("[%s] (shm_io) io->out->pid: %d\n", __func__, io->out->pid);
      //if(io->out->pid)
    }
    sem_post(&io->out->sem_wait);
    //shm_io_write(io, io->out, shm_name, strlen(shm_name)+1);
    pid_t pid = getpid();
    shm_io_write(io, io->out, &pid, sizeof(pid_t));

    user_io = io;
  }

  PTHREAD_INTERRUPTED = malloc(1);

  threads = newVector(TRUE);
  jobs = newVector(TRUE);
  globalEnvironment = newHashtable(TRUE);

  DCL_connections = newVector(FALSE);

//vector_t *
//  DCL_connections = newVector(TRUE);

  printf("\n\nInitializing R ...\n");
  if(Supr_verbose)
    Cluster_sendSimpleMessage("Initializing R", "\033[0;32m", VERBOSE_INFO_TYPE, 0);
  __R_init(argc, argv);

  if(Supr_verbose)
    Cluster_sendSimpleMessage("Initialized R", "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  /*
  {
    char msg[256];
    sprintf(msg, "R@driver is initialized");
    int len = strlen(msg)+1;
    shm_io_write(io, io->out, &len, INT_SIZE);
    shm_io_write(io, io->out, msg, len);
  }
  */


#ifndef SUPR_DEBUG
  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
#endif


  // used to debug ...
  {
    struct sigaction sa;
    sa.sa_sigaction = Driver_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, &R_oldSegvAct);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = Driver_SigactionSIGINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldIntAct);
  }

  {
    //sigaction(SIGPIPE, &sa, &R_oldPipeAct);
    struct sigaction sa;
    sa.sa_sigaction = Driver_SigactionSIGPIPE;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGPIPE, &sa, &R_oldPipeAct);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = Driver_SigactionAbort;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGABRT, &sa, NULL);
  }



  //printf("> source(\"library(supr3)\")\n");
  verbose_info("> source(\"librayr(supr3)\")");
  supr_options_t save_supr_options;
  memcpy(&save_supr_options, &Supr_options, sizeof(supr_options_t));


  BEGIN_R_EVAL();
  //{
  
    /* context.c/Rboolean R_ToplevelExec(void (*fun)(void *), void *data)
    RCNTXT thiscontext;
    RCNTXT * volatile saveToplevelContext;
    volatile SEXP topExp, oldHStack, oldRStack, oldRVal;
    volatile Rboolean oldvis;
    Rboolean result;

    PROTECT(topExp = R_CurrentExpr);
    PROTECT(oldHStack = R_HandlerStack);
    PROTECT(oldRStack = R_RestartStack);
    PROTECT(oldRVal = R_ReturnedValue);
    oldvis = R_Visible;
    R_HandlerStack = R_NilValue;
    R_RestartStack = R_NilValue;
    saveToplevelContext = R_ToplevelContext;

    begincontext(&thiscontext, CTXT_TOPLEVEL, R_NilValue, R_GlobalEnv,
                 R_BaseEnv, R_NilValue, R_NilValue);
    if (SETJMP(thiscontext.cjmpbuf))
        result = FALSE;
    else {
        R_GlobalContext = R_ToplevelContext = &thiscontext;
        fun(data);
        result = TRUE;
    }
    endcontext(&thiscontext);

    R_ToplevelContext = saveToplevelContext;
    R_CurrentExpr = topExp;
    R_HandlerStack = oldHStack;
    R_RestartStack = oldRStack;
    R_ReturnedValue = oldRVal;
    R_Visible = oldvis;
    UNPROTECT(4);
*/
    Rboolean errorOccurred = FALSE;
    RCNTXT thiscontext;
    static RCNTXT  * volatile __R_ToplevelContext = NULL;
    if(!__R_ToplevelContext){
      __R_ToplevelContext  = R_GlobalContext;
      while(__R_ToplevelContext->nextcontext)
        __R_ToplevelContext = __R_ToplevelContext->nextcontext;
    }

    supr_thread_t *cth = currentThread();

    // save
    memcpy(cth->cjmpbuf, __R_ToplevelContext->cjmpbuf, sizeof(jmp_buf));
    int savePPStackTop = R_PPStackTop;

    begincontext(&thiscontext, CTXT_TOPLEVEL, R_NilValue, R_GlobalEnv,
                 R_BaseEnv, R_NilValue, R_NilValue);

#define SUPR_DEBUG
#ifndef SUPR_DEBUG
  int devNull = open("/dev/null", O_WRONLY);
  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);
  dup2(devNull, STDERR_FILENO);
  dup2(devNull, STDOUT_FILENO);
#endif

      if (SETJMP(thiscontext.cjmpbuf))
      {
        errorOccurred = TRUE;
	const char *errbuf = R_curErrorBuf();
	printf("Error: %s (%s:%d)\n ", errbuf, __FILE__, __LINE__);
	sleep(10);
      } else {
      //{
        memcpy(__R_ToplevelContext->cjmpbuf, thiscontext.cjmpbuf,
		       	sizeof(jmp_buf));

	if(TRUE){

          SEXP check_lib = PROTECT(LCONS(install(".libPaths"), R_NilValue));
	  SEXP lib =  eval(check_lib, R_GlobalEnv);
	  fprintf(stdout, ".libPaths():\n");
	  PrintValue(lib);
	  UNPROTECT(1);

          SEXP call = PROTECT(LCONS(install("library"),
                           CONS(mkString(PACKAGE_NAME), R_NilValue)));
          eval(call, R_GlobalEnv);
          UNPROTECT(1);
	} else {
          SEXP call = PROTECT(LCONS(install("source"),
                           CONS(mkString("driver_init.R"), R_NilValue)));
          eval(call, R_GlobalEnv);
          UNPROTECT(1);
	}
      //}
      }

#ifndef SUPR_DEBUG
  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
#endif

    endcontext(&thiscontext);

    if(TRUE){
      Rprintf("\033[0;32mSupr_sysHome: %s\n", Supr_sysHome);
      Rprintf("Supr_usrHome: %s\033[0m\n", Supr_usrHome);
    }

    // restore
    memcpy(__R_ToplevelContext->cjmpbuf, cth->cjmpbuf, sizeof(jmp_buf));
    R_PPStackTop = savePPStackTop;
  //}
  END_R_EVAL();

  memcpy(&Supr_options, &save_supr_options, sizeof(supr_options_t));
  Supr_infov = Supr_options.info;
  Supr_debug = Supr_options.debug;
  Supr_verbose = Supr_options.verbose;

  //syncHashtable = newHashtable(FALSE);
  syncHashtable = newHashtable(TRUE);
  waitHashtable = newHashtable(FALSE);

  if(Supr_verbose)
  Cluster_sendSimpleMessage("The initial R evaluation finished", "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  free(main_thread->name);
  main_thread->name = strdup(__func__);
  if(vectorSize(threads) == 0)
    vectorAdd(threads, main_thread);
  main_thread_tasks = newVector(TRUE);

  pthread_mutex_lock(&main_thread->mutex);

    supr_thread_t *backend = startBackend(port);

    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);

    free(backend->name);
    backend->name = strdup("backend");
    vectorAdd(threads, backend);
    backendThread = backend;

  //printf("startTimedwaitThread...\n");
    timedwait_queue = newVector(FALSE);
    timedwait_thread  = startTimedwaitThread();
    free(timedwait_thread->name);
    timedwait_thread->name = strdup("sync"); // sync server
    vectorAdd(threads, timedwait_thread);

    //supr_socket_conn_t *conn = (supr_socket_conn_t *)
    //  vectorElementAt(socket_connections, 0);
  pthread_mutex_unlock(&main_thread->mutex);

#define __DRIVER_START_WORKERS
#ifndef __DRIVER_START_WORKERS


  /*
#ifdef DRIVER_START_WORKERS
  //int worker_count = 0;
//pthread_mutex_t *worker_count_mutex = NULL;
//pthread_cond_t  *worker_count_cond = NULL;
  worker_count_mutex = (pthread_mutex_t*) malloc(sizeof(pthread_mutex_t));
  worker_count_cond  = (pthread_cond_t*) malloc(sizeof(pthread_cond_t));
  pthread_mutex_init(worker_count_mutex, NULL);
  pthread_cond_init(worker_count_cond, NULL);
  //pthread_mutex_lock(worker_count_mutex);
  
  notify_mutex = (pthread_mutex_t*) malloc(sizeof(pthread_mutex_t));
  notify_cond = (pthread_cond_t*) malloc(sizeof(pthread_cond_t));
  pthread_mutex_init(notify_mutex, NULL);
  pthread_cond_init(notify_cond, NULL);
  pthread_mutex_lock(notify_mutex);
#endif
  // start backend
  //printf("startBackend thread...\n");
  Cluster_sendSimpleMessage("Starting driverBackend ...", "\033[0;32m", VERBOSE_INFO_TYPE, 0);
  supr_thread_t *backend = startBackend(port);
  vectorAdd(threads, backend);
  backendThread = backend;

  //printf("startTimedwaitThread...\n");
  timedwait_queue = newVector(FALSE);
  timedwait_thread  = startTimedwaitThread();
  free(timedwait_thread->name);
  timedwait_thread->name = strdup("sync"); // sync server
  vectorAdd(threads, timedwait_thread);


#ifdef DRIVER_START_WORKERS
//  Master_startWorkers(argc, argv, Worker_useWindow);

  pthread_mutex_lock(&main_thread->mutex);

    pthread_cond_wait(notify_cond, notify_mutex);
    fprintf(stderr, "\n\n\033[0;32mDriver_startWorkers: start\033[0m\n\n");
    Driver_startWorkers(argc, argv);
  pthread_mutex_unlock(notify_mutex);

  pthread_mutex_destroy(notify_mutex);
  pthread_cond_destroy(notify_cond);
  free(notify_mutex);
  free(notify_cond);
  fprintf(stderr, "\n\n\033[0;32mDriver_startWorkers: done!\033[0m\n\n");
#endif

#ifndef DRIVER_START_WORKERS
  Cluster_sendSimpleMessage("Waiting for backend ...", "\033[0;32m", VERBOSE_INFO_TYPE, 0);
  pthread_mutex_lock(&main_thread->mutex);
#endif
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
      vectorElementAt(socket_connections, 0);
    //printf("main:");
    //conn->print(conn);


#ifdef DRIVER_START_WORKERS
    pthread_mutex_lock(worker_count_mutex);
      if(worker_count) {
        double timeout = DEFAULT_DRIVER_TIMEOUT;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        wait.tv_sec += (long) timeout;

        int rc = pthread_cond_timedwait(worker_count_cond, worker_count_mutex,
		 &wait);
        //if(rc == ETIMEDOUT){ }
      }
    pthread_mutex_unlock(worker_count_mutex);
#endif

    if(io) {

      void *err = SuprErr_get();
      if(err){
        fprintf(stderr, "Error: ... FIXME ... \n");
        // FAILUER
	int rc = -1;
        shm_io_write(io, io->out, &rc, INT_SIZE);
	exit(EXIT_FAILURE);
      }

#ifdef DRIVER_START_WORKERS
      pthread_mutex_lock(worker_count_mutex);
        if(worker_count){
          // WARNING
	  fprintf(stderr, "Warning: wait for workers to be ready, TIMEOUT\n");
	  int rc = worker_count;
          shm_io_write(io, io->out, &rc, INT_SIZE);
	  char *msg = "Warning: wait for workers to be ready, TIMEOUT";
          shm_io_write(io, io->out, msg, strlen(msg)+1);
	} else {
          int rc = 0;
          shm_io_write(io, io->out, &rc, INT_SIZE);
	}
	user_io = NULL;
      pthread_mutex_unlock(worker_count_mutex);
#else
      int rc = 0;
      shm_io_write(io, io->out, &rc, INT_SIZE);
#endif

      // SUCCESS, SERVER_PORT
      shm_io_write(io, io->out, &conn->port, INT_SIZE);

    } 
    
  pthread_mutex_unlock(&main_thread->mutex);

  Cluster_sendSimpleMessage("Notified by the backend. Continue ...", "\033[0;32m", VERBOSE_INFO_TYPE, 0);


  //setDir(SUPR_HOMEUSR, SYS_COMMAND_DRIVER);
  //Exec_setStdout(SYS_COMMAND_DRIVER, _stdout);

  // start User interface ?
  if(io){
    supr_thread_t *ui = startUI(io);
    free(ui->name);
    ui->name = strdup("shmio");
    vectorAdd(threads, ui);
  }



  //if(Driver_startedMaster) //
    //Driver_startWorkers(argc, argv);
  //sleep(10);

  if(Supr_verbose)
    Cluster_sendSimpleMessage("Waiting for backend ...", "\033[0;32m", VERBOSE_INFO_TYPE, 0);
  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
    //supr_socket_conn_t *conn = (supr_socket_conn_t *)
    //  vectorElementAt(socket_connections, 0);
  pthread_mutex_unlock(&main_thread->mutex);
  if(Supr_verbose)
    Cluster_sendSimpleMessage("Notified by the backend. Continue ...", "\033[0;32m", VERBOSE_INFO_TYPE, 0);
  */

#endif // __DRIVER_START_WORKERS

  // connection to backend
  if(!driverServerConn) {
    char *netstat = Cluster_netstat_C(port, NULL);
    basic_info(netstat);

    if(notify_addr)
      Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_DRIVER);
    
    exit(EXIT_FAILURE);
  }

  scToBackend = socketOpen(driverServerConn);
  if(!scToBackend) {
    char *netstat = Cluster_netstat_C(port, NULL);
    basic_info(netstat);

    if(notify_addr)
      Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_DRIVER);
    
    exit(EXIT_FAILURE);
  }

  if(notify_addr){
    char buf[strlen(driverServerConn->host)+32];
    sprintf(buf, "%s:%d", driverServerConn->host, driverServerConn->port);
    Supr_notify(notify_addr, buf, CLUSTER_CONNECT_DRIVER);
  }

  scToBackend->mutex = malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(scToBackend->mutex, NULL);

  scToBackend->type = DRIVER_CONN;
  scToBackend->pid = getpid();
  {
    int msg[] = {SET_CONN_PID, (int)syscall(SYS_gettid), DRIVER_CONN};
    write(scToBackend->fd, msg, sizeof(msg));

    int fd = scToBackend->fd;
    int cmd = CLUSTER_PROC_CMD;
    write(fd, &cmd, INT_SIZE);
    char *cmd_str = "DriverClient";
    int len = strlen(cmd_str) + 1;
    write(fd, &len, INT_SIZE);
    write(fd, cmd_str, len);
    int rc = 0;
    read(fd, &rc, INT_SIZE);
  }

  // start User interface ?
  if(io){
    supr_thread_t *ui = startUI(io);
    free(ui->name);
    ui->name = strdup("shmio");
    vectorAdd(threads, ui);
  }
  
  // start R_eval service
  R_REPL(main_thread, argc, argv);
  /*
  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
  pthread_mutex_unlock(&main_thread->mutex);
  */
  

  exit(1);
}

