
/*
gcc -fPIC -I"$JAVA_HOME/include" -I"$JAVA_HOME/include/linux" -I"/usr/share/R/include" -L/usr/lib/R/lib -L"." -o RTaskRunner RTaskRunner.c -pthread -lrt -lR -lrjni
*/


#include "supr.h"
#include "util.h"
#include <sys/prctl.h>

//#define dupstr(str)  memcpy(malloc(strlen(str)+1), str, strlen(str)+1)

#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)

#define strdup(ptr) __supr_strdup__((ptr), __func__, __FILE__, __LINE__)


#ifdef PrintValue
#undef PrintValue
#endif


#define PrintValue printf("\033[0;31m(%s:%d)\033[0m ", __FILE__, __LINE__); Rf_PrintValue

#define USE_SUPR_SERIALIZE

//#define __USE_INTSIG__ // don't use it
#define __USE_SIGUSR1__
#define __USE_SIGUSR2__

//#define DRIVER_MALLOC_DEBUG 1
#ifdef DRIVER_MALLOC_DEBUG
extern SEXP Malloc_print();
#define MALLOC_PRINT   Malloc_print()
void *__MALLOC_DEBUG_MARK__(size_t s)
{
        return malloc(s);
}
#define MALLOC_MARK(s) __MALLOC_DEBUG_MARK__(s)
#else
#define MALLOC_PRINT
#define MALLOC_MARK(s)
#endif

#ifndef _
#define _(x) (x)
#endif



extern SEXP R_lsInternal(SEXP env, Rboolean all);

extern SEXP Taskrunner_messages();
extern SEXP (*__cluster_messages_ptr__)();
extern SEXP Taskrunner_recv();
extern SEXP (*__cluster_recv_ptr__)();

extern const char *info_addr;
extern supr_socket_conn_t *info_sc;
#define msg_color "\033[0;31m"
char *myR_simpleTraceback();

extern SEXP Supr_namespace;
extern SEXP SuprJobEnv;
extern SEXP Rf_deparse1m(SEXP call, Rboolean abbrev, int);
// from Defn.h
#define DEFAULTDEPARSE          1089


extern void R_CheckUserInterrupt(void); 
extern int R_interrupts_pending;
//extern int R_interrupts_suspended;

static struct sigaction R_oldactInt;
static struct sigaction R_oldactSegv;

static int worker_port = 0;

extern FILE *R_Consolefile;
extern FILE *R_Outputfile;

extern void (*ptr_R_ProcessEvents)();
void Supr_CheckInterrupt();
void Supr_CheckInterrupt_init();

//#define __TESTING__
/*
#ifdef __TESTING__

typedef struct VECTOR_SEXPREC {
    SEXPREC_HEADER;
    struct vecsxp_struct vecsxp;
} VECTOR_SEXPREC, *VECSEXP;

typedef union { VECTOR_SEXPREC s; double align; } SEXPREC_ALIGN;

#endif
*/

//#include <R_ext/Defn.h>
//#include <R_ext/Callbacks.h>
//#include "Defn.h"
//#include <setjmp.h>


//#include "rjni.h"

//extern SEXP R_CStackStart;
extern unsigned long R_CStackStart;
extern unsigned long R_CStackLimit;
extern int R_Interactive;
extern void run_Rmainloop(void);
extern vector_t *threads;
extern supr_thread_t *main_thread;
//extern SEXP JobEnv_init();

extern void myR_SigactionSegv(int sig, siginfo_t *ip, void *context);
extern void c_backtrace();

// use SIGUSR1 for Thread-Proc main signal?
/*
char *Thread_SigactionSIGUSR1_buf = NULL;
void Thread_SigactionSIGUSR1(int sig, siginfo_t *ip, void *context)
{
   printf("\033[0;31m%s: IS CALLED\033[0m\n", __func__);
   if(Thread_SigactionSIGUSR1_buf){
     printf("\033[0;31m%s: IS CALLED, data: %s\033[0m\n", __func__,
		     Thread_SigactionSIGUSR1_buf);
   }
   exit(0); // TODO
}
*/


static shm_io_info_t *__io__ = NULL;



int isDCLInterrupted = FALSE;
int isDisconnected = FALSE;

size_t __dcl_read__(int fd, void *ptr, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /* else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(listenfd, &readfds) = %d\n", __func__,
               FD_ISSET(fd, &readfds));
      } */
    }

    int n = read(fd, ptr + len,  size - len);
    //printf("[%s] isDCLInterrupted = %d n = %d\n", __func__, isDCLInterrupted, n);
    if(isDCLInterrupted) {
//      isDCLInterrupted = FALSE;
    //  return -1;
	    // clean...???
      errorcall(R_NilValue, "interrupted");
    } else if(n == -1) {
      errorcall(R_NilValue, "SIGPIPE?");
    } else if(n == 0) {
      printf("[%s] disconnected\n", __func__);
      isDisconnected = TRUE;
      errorcall(R_NilValue, "disconnected");
    }
    //if(n == -1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  return len;
}

// testing
extern size_t (*__read__)(int, void *, size_t);


#include <readline/readline.h>
#include <readline/history.h>

extern pthread_mutex_t Supr_syncMutex;
extern pthread_mutex_t Supr_syncCond;

/*
void main_exit_cleanup(void *data){
  fprintf(stderr, "%s\n", __func__);
}
// handleShutdown
void *main_exit(void *arg)
{
  char msg[1024];

  pthread_cleanup_push(main_exit_cleanup, NULL);
  
  if(Supr_curStrError){
    char *err = malloc(strlen(Supr_curStrError) + strlen(__func__)
                    + strlen("<-")+1);
    sprintf(err, "%s<-%s", __func__, Supr_curStrError);
    Supr_curStrError = err;
  } else {
    Supr_curStrError = (char*)  __func__;
  }
  // wait for threads that are using info_sc ?
  pthread_mutex_lock(&Supr_syncMutex);
    if(info_sc){
      close(info_sc->fd);
      info_sc = NULL;
    }
    if(parent_sc){
      close(parent_sc->fd);
      parent_sc = NULL;
    }
  pthread_mutex_unlock(&Supr_syncMutex);

   // 2. Cancel pthreads
  //supr_thread_t *cth = pthread_getspecific(currentThreadKey);
  supr_thread_t *cth = NULL;

  for(int i=vectorSize(threads)-1; i>=0; i--){
    supr_thread_t *th = vectorElementAt(threads, i);
    if(th != cth){
      int locked = !pthread_mutex_trylock(&th->mutex);
      if(locked){
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d, state: %s)", th->tid, th->pid, state2char(th->state));
      }else {
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d)", th->tid, th->pid);
      }
      fprintf(stderr, "%s\n", msg);

      int rc = pthread_cancel(th->ptid);
      if(locked){
        pthread_mutex_unlock(&th->mutex);
      }
    }
  }

  int rc = pthread_cancel(pthread_self());
  pthread_cleanup_pop(TRUE);
}
*/

// handler...
void Taskrunner_sigaction(int sig, siginfo_t *ip, void *context)
{
//  static int nthreads = 0;

  switch(sig){
    case SIGHUP:
         {
	   //basic_info("SIGHUP"); // FIXME
//	   exit(EXIT_FAILURE);
	   fprintf(stderr, "[SIGHUP] si_pid: %d\n", ip->si_pid);
	   fprintf(stderr, "si_code: %d (SI_USER: %d)\n", ip->si_code, SI_USER);
	 }
	 break;

    case SIGTERM:
         {
	   //basic_info("SIGHUP"); // FIXME
	   fprintf(stderr, "[SIGTERM] si_pid: %d\n", ip->si_pid);
	   fprintf(stderr, "si_code: %d (SI_USER: %d)\n", ip->si_code, SI_USER);
//	   exit(EXIT_FAILURE);
	 }
	 break;

    case SIGPIPE:
         {
	   //basic_info("SIGHUP"); // FIXME
	   fprintf(stderr, "[SIGPIPE] si_fd: %d\n", ip->si_fd);
//	   exit(EXIT_FAILURE);
	 }
	 break;

	 /*
    case SIGINT:
         {
	    basic_info("\033[0;31mSIGINT\033[0m");
            ptr_R_ProcessEvents = Supr_CheckInterrupt;
	 }
	 break;
	 */

    default:
         {
	   basic_info("Not implemented");
	 }
	 //break;
	 return;
  }

  info_sc = NULL; parent_sc = NULL;
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;

  exit(EXIT_FAILURE);

  
  //if(nthreads ==0)
  //{
	  /*
      sigset_t sig_set;
      sigemptyset(&sig_set);
      //sigaddset(&sig_set, SIGINT);
      sigaddset(&sig_set, SIGTERM);
      sigaddset(&sig_set, SIGHUP);
      sigaddset(&sig_set, SIGPIPE);
      pthread_sigmask(SIG_BLOCK, &sig_set, NULL);
      //pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);

    pthread_t thread;
    */
    /*
    sem_t sem;
    sem_init(&sem, 1, 0);
    supr_thread_t *sth = NULL;
    void *arg[] = {&port, &sem, &sth};
    int rc = pthread_create(&thread, NULL, backend_init, arg);
    */
  //  int rc = pthread_create(&thread, NULL, main_exit, NULL);

    /*
    sem_wait(&sem);
    sem_destroy(&sem);

    pthread_mutex_lock(&sth->mutex);
      pthread_cond_signal(&sth->cond);
    pthread_mutex_unlock(&sth->mutex);
    return sth;
    */

 //   nthreads ++;

  //}

}
 
void  myR_SigactionDCLInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  c_backtrace();

  //if(isDCLInterrupted) exit(1);
  fprintf(stderr, "\033[0;31m[%s] FIXME: EXIT (%s, %d)\033[0m\n", __func__,
           __FILE__, __LINE__);
//  exit(1);

//  char *line = readline (">>> ");
//  printf("%s\n", line);
//  int c;
//  read(3, &c, 1);


  isDCLInterrupted = TRUE;

  if(FALSE && __io__){
    int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
    shm_io_write(__io__, __io__->out, array, sizeof(array));
  }
//  errorcall(R_NilValue, "segmentation fault"); //??? FIXME
//  exit(1); // not good...

  if(R_oldactInt.sa_sigaction)
    R_oldactInt.sa_sigaction(sig, ip, context);

}

int isTaskrunnerInterrupted = FALSE;
extern int R_isInterrupted;
char interrupt_message_buf[256];

extern char *shm_prefix;

// Rboolean R_ToplevelExec(void (*fun)(void *), void *data);
/*
static void Taskrunner_backtrace(void *data){
  SEXP call = PROTECT(LCONS(install("traceback"), CONS(ScalarInteger(0),
                        R_NilValue)));
  SEXP val = PROTECT(eval(call, R_GlobalEnv));
}
*/

void Taskrunner_unserialize(void *data)
{
  void **args = (void **) data;
  unsigned char *ptr = args[0];
  ssize_t size = *((ssize_t*)args[1]);
  {
    char msg[1024];
    sprintf(msg, "func: %s, ptr: %p, size: %ld", __func__, ptr, size);
    Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
  }
  SEXP raw = PROTECT(allocVector(RAWSXP, (int) size));
  memcpy(RAW(raw), ptr, size);
  SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
  SEXP val = PROTECT(eval(call, R_GlobalEnv));
  *((SEXP *)args[2]) = val;
  UNPROTECT(2);
}



void  *Thread_SigactionTaskRunnerInt(void *data)
{
  sem_t *sem = (sem_t *) ((void **)data)[0];
  supr_thread_t **sth = (supr_thread_t **) ((void **)data)[1];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
          syscall(SYS_gettid), THREAD_STATE_NEW, (unsigned long) &sem);
  *sth = th;
  
  pthread_setspecific(currentThreadKey, th);

  save_cstackstart = R_CStackStart;
  R_CStackStart = ((supr_thread_t*)pthread_getspecific(currentThreadKey))->R_CStackStart;

  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
  //c_backtrace();
  {
    char msg[1024];
    sprintf(msg, "func: %s, hostname: %s, pid: %d", __func__, Supr_hostname, getpid());
    Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);

    char shm_name[256];
    sprintf(shm_name, "%s-%d-taskrunner", shm_prefix, getpid());
    ssize_t size;
    unsigned char *ptr = Supr_shm_open(shm_name, &size);
    sprintf(msg, "func: %s, ptr: %p, size: %ld", __func__, ptr, size);
    Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);

    if(ptr){
      //BEGIN_R_EVAL();
      //END_R_EVAL();
      //Rboolean success = R_ToplevelExec(void (*fun)(void *), void *data);
      SEXP val;
      void *args[] = {ptr, &size, &val};
      Rboolean success = R_ToplevelExec(Taskrunner_unserialize, args);

      if(success){
        PROTECT(val);
	fprintf(stderr, "val:\n");
	PrintValue(val);
	fprintf(stderr, "// val\n");
	SEXP expr = PROTECT(Rf_deparse1m(val, 0, DEFAULTDEPARSE));
	fprintf(stderr, "{expr:\n");
	PrintValue(expr);
	fprintf(stderr, "}// expr\n");
        Cluster_sendSimpleMessage("expr: {", msg_color, DEFAULT_INFO_TYPE, 0);
	for(int i=0; i<LENGTH(expr); i++){
          Cluster_sendSimpleMessage(CHAR(STRING_ELT(expr, i)),
			  msg_color, DEFAULT_INFO_TYPE, 0);
	}
        Cluster_sendSimpleMessage("} // expr", msg_color, DEFAULT_INFO_TYPE, 0);
        UNPROTECT(2);
      } else {
        sprintf(msg, "\033[0;31mfunc: %s, Taskrunner_unserialize: %s\033[0m",
		      __func__, R_curErrorBuf());
        Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
      }

      int port = parent_sc->port + 1;
      int reuse_addr = FALSE; // wrong concept... use static or dynamic port ???
      supr_socket_conn_t *serverConn = serverSocketOpen3(port,reuse_addr,proc_cmd);
      if(serverConn){
        // port
	      sprintf(msg, "port: %d", serverConn->port);
	      basic_info(msg);
              close(serverConn->port); // TODO
              free(serverConn);
      } else {
	      // -1, strerror(errno);
	      sprintf(msg, "Error in serverSocketOpen: %s", strerror(errno));
	      basic_info(msg);
      }
      // sem_post(sem);

      //vectorAdd(socket_connections, serverConn);


      munmap(ptr, size);
      shm_unlink(shm_name);
    } else {
      sprintf(msg, "\033[0;31mfunc: %s, Supr_shm_open(%s): %s\033[0m",
		      __func__, shm_name, strerror(errno));
      Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
    }

    /*
    char *R_traceback = myR_simpleTraceback();
    Cluster_sendSimpleMessage(R_traceback, msg_color, DEFAULT_INFO_TYPE, 0);

    int i=0;
    for(RCNTXT *cntxt_ptr = R_GlobalContext; cntxt_ptr;
      	cntxt_ptr = cntxt_ptr->nextcontext){
        sprintf(msg, "[%d] cntxt_ptr: %p", i, cntxt_ptr);
        Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
    }
    sprintf(msg, "R_CStackStart: %0lx", R_CStackStart);
    void *dummy= NULL;
    sprintf(msg, "&dummy: %p", &dummy);
    Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);

    printf("\tR_CStackStart - dummy: %0lx\n", 
			R_CStackStart - ((unsigned long) &dummy));
    */

    //int rc = R_ToplevelExec(Taskrunner_backtrace, NULL);
    /*
    SEXP call = PROTECT(LCONS(install("traceback"), CONS(ScalarInteger(0),
                        R_NilValue)));
    SEXP val = PROTECT(eval(call, R_GlobalEnv));
    if(TYPEOF(val) == LISTSXP){
      while(TYPEOF(val) != NILSXP){
        const char *line = CHAR(asChar(CAR(val)));
        Cluster_sendSimpleMessage(line, msg_color, DEFAULT_INFO_TYPE, 0);
        val = CDR(val);
      }
    } else {
      Cluster_sendSimpleMessage("FIXME", msg_color, DEFAULT_INFO_TYPE, 0);
    }
    */

  }

  isTaskrunnerInterrupted = TRUE;
  R_isInterrupted = TRUE;

  R_CStackStart = save_cstackstart;

  sem_post(sem);

  pthread_exit(NULL);
}

extern tr_cntxt_t tr_cntxt;

void  myR_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{

	basic_info("\033[0;31mSIGINT\033[0m");
	shm_io_info_t *io = tr_cntxt.io;
	// SIG_BLOCK...
	if(io){
          sem_wait(&io->err->sem_wr);
	    sprintf((char*)(io->err+1), "interrupted");
	    io->err->data_size = strlen((char*)(io->err+1));
          sem_post(&io->err->sem_wr);
	}
        ptr_R_ProcessEvents = Supr_CheckInterrupt;
	return;

  /*
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&sem, &sth};

  int rc = pthread_create(&thread, NULL, Thread_SigactionTaskRunnerInt, arg);

  sem_wait(&sem);
  sem_destroy(&sem);
  void *retval;
  Cluster_sendSimpleMessage("pthread_join", msg_color, DEFAULT_INFO_TYPE, 0);
  pthread_join(thread, &retval);
  Cluster_sendSimpleMessage("finalize", msg_color, DEFAULT_INFO_TYPE, 0);
  sth->class->finalize(sth->class, sth);
  Cluster_sendSimpleMessage("finalize", msg_color, DEFAULT_INFO_TYPE, 0);
  // destory th ... FIXME ThreadFinishFinalizer???
  */
}



char *cntxt2str(){
  char *s = malloc(256);
  sprintf(s, "\033[0;32mpid=%d, job_id=%d, tr_id=%d, %s\033[0m",
		  tr_cntxt.pid,  tr_cntxt.job_id,
		  tr_cntxt.tr_id, tr_cntxt.io->shm_info.shm_name);
  return s;
}

void  (*myTryEval_SigactionInt)(int sig, siginfo_t *ip, void *context) =NULL;

extern void sendDriverMessage(shm_io_info_t *io, int job_id, int tr_id, const char *msg);
extern void rjni_io_err_write(shm_io_info_t *io, const char *msg);

#define  BACKTRACE_SIZE 256
#include <execinfo.h>

char *myC_backtrace()
{
  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  size = backtrace(array, BACKTRACE_SIZE);
  strings = backtrace_symbols(array, size);

  int length = 0;
  for (i = 0; i < size; i++) //fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    length += strlen(strings[i]) + 1;
  
  char *str = (char*)malloc(length);
  char *s = str;
  for (i = 0; i < size; i++){
    memcpy(s, strings[i], strlen(strings[i]));
    s += strlen(strings[i]);
    *s = i== (size-1) ? 0 : '\n';
    s++;
  }

  free(strings);
  
  return str;
}

extern void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write);

char *myR_simpleTraceback();
//extern int isInterrupted;

void  myR_SigactionTaskRunnerUsr1(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__, pthread_self());
//  c_backtrace();

  {
    size_t size;
    fprintf(stderr, "\033[0;31m[%s] Read shm_io->err ...\033[0m\n", __func__);
    void *ptr = shm_io_read(tr_cntxt.io, tr_cntxt.io->err, &size, 0);
    int cmd = *((int*)ptr);
    fprintf(stderr, "\033[0;31m[%s] cmd: %d\033[0m\n", __func__, cmd);
    if(cmd == CLUSTER_SHUTDOWN){
      fprintf(stderr, "\033[0;31m[%s] cmd: CLUSTER_SHUTDOWN\033[0m\n",
		      __func__);
      exit(0);
    } else if(cmd == CLUSTER_INTERRUPT){ // INTERRUPT/JOB_CANCEL
      fprintf(stderr, "\033[0;31m[%s] cmd: CLUSTER_INTERRUPT\033[0m\n",
		      __func__);
      R_isInterrupted = TRUE;
      //kill(getpid(), SIGINT);
      return;
     // exit(0);
    }
  }

  int can_read  = tr_cntxt.io->in->data_size > 0;
  int can_write = tr_cntxt.io->out->data_size == 0;
  char buf[256];
  sprintf(buf, "shm_io: can_read = %s, can_write = %s (without blocking)\n",
		  can_read? "TRUE":"FALSE",
		  can_write? "TRUE":"FALSE");


  // R_backtrace...
  char *c_msg = cntxt2str();
  char *b_msg = myC_backtrace();
  char *r_msg = myR_simpleTraceback();
  char *msg = malloc(strlen(buf)+1+strlen(c_msg)+1 + strlen(b_msg)+1 + strlen(r_msg));
  sprintf(msg, "%s\n%s\n%s\n%s", buf, c_msg, b_msg, r_msg);
  rjni_io_err_write(tr_cntxt.io, msg);

  //sendDriverMessage(tr_cntxt.io, tr_cntxt.job_id, tr_cntxt.tr_id, msg);

  fprintf(stderr, "%s", msg);

  //sem_wait(&tr_cntxt.io->err->sem_wr);
  //sem_post(&tr_cntxt.io->err->sem_wr);

  free(b_msg);
  free(c_msg);
  free(r_msg);
  free(msg);

  /*
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }
  */
  //errorcall(R_NilValue, "SIGUSR1 interrupted");
  R_isInterrupted = TRUE;
  
  rjni_shm_io_state(tr_cntxt.io, &can_read, &can_write);
}

void  myR_SigactionTaskRunnerUsr2(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n",
		  __func__, pthread_self());
  c_backtrace();

  R_isInterrupted = TRUE;

  int rc = sem_trywait(&__io__->err->sem_wr);
  fprintf(stderr, "\033[0;31m[%s] sem_trywait : %d\033[0m\n", __func__, rc);
  char *msg = "interrupted";
  if(rc == 0){
    msg = (char*) (__io__->err+1);
    msg[__io__->err->data_size-1] = 0;
    fprintf(stderr, "\033[0;31m[%s] message = %s\033[0m\n", __func__, msg);
    __io__->err->data_size = 0;
    sem_post(&__io__->err->sem_wr);
  }
  if(strlen(msg)==0) msg = "interrupted";
  int size = strlen(msg);
  if(sizeof(interrupt_message_buf)-1 < size)
	  size = sizeof(interrupt_message_buf)-1;
  memcpy(interrupt_message_buf, msg, size);
  interrupt_message_buf[size] = 0;

  
  kill(getpid(), SIGINT);

}


/*
void  myTryEval_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n",
		  __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  c_backtrace();

  int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
  shm_io_write(__io__, __io__->out, array, sizeof(array));

  exit(1);
}
*/





/*
typedef struct shm_struct {
  size_t size;
  sem_t sem_w; // by java thread
  sem_t sem_r; // by java thread
} shm_struct_t;

typedef struct _shm_info {
  char *shm_name;
  void *mem_ptr;
} shm_info_t;
*/

//JNIEXPORT jlong JNICALL Java_RJNI_shmOpen (JNIEnv *javaEnv, jobject thisObj, jstring jshm_name)

/*
shm_info_t *shmOpen(const char *cshm_name) {
//  const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv, jshm_name, NULL);
  printf("[%s] cshm_name: %s\n", __func__, cshm_name);
  shm_info_t *shm_ptr = malloc(sizeof(shm_struct_t));

  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  size_t segment_size = sysconf(_SC_PAGE_SIZE);

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  close(fd);
  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);
//  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);

  shm_ptr->mem_ptr = mem_ptr;

  shm_struct_t * ssp = (shm_struct_t *)mem_ptr;
  ssp->size = segment_size;
  //sem_init(&ssp->sem_w, 1, 0);
  //sem_init(&ssp->sem_r, 1, 0);
  //sem_wait(&ssp->sem_w); sem_wait(&ssp->sem_r);
  int val;
  sem_getvalue(&ssp->sem_w, &val);
  printf("[%s] sem_getvalue(&ssp->sem_w, &val): %d\n", __func__, val);
  sem_getvalue(&ssp->sem_r, &val);
  printf("[%s] sem_getvalue(&ssp->sem_r, &val): %d\n", __func__, val);

  return shm_ptr;
}
*/

typedef void (*sighandler_t)(int);

//this worked 
void myTryEval_SIGINT_handler(int sig){
  fprintf(stderr, "[%s] is called on %d\n", __func__, getpid()); 
  fprintf(stdout, "[%s] is called on %d\n", __func__, getpid()); 
}

extern char *__r2str(SEXP x, char *buf, int buf_size, int debug);

char *sexp2char(SEXP x)
{
   int buf_size = 128*200;
   char buf[buf_size];
   //char *s = __r2str(x, buf, buf_size, 0);
   char *s = __r2str(x, buf, buf_size, 0);
   char *c = malloc(strlen(s)+1);
   memcpy(c, s, strlen(s)+1);
   return c;
}

char *myR_simpleTraceback()
{
  RCNTXT *cntxt = R_GlobalContext;
  int len  = 0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    len += strlen(c)+1+1+32;
    fprintf(stderr, "cntxt = %p: %s\n", cntxt, c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  char *str = malloc(len);
  char *s = str;
  cntxt = R_GlobalContext;
  int i=0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    if(i){ *s ='\n'; s++;}

    char b[16];
    sprintf(b, "%d: ", i++);
    memcpy(s, b, strlen(b));
    s += strlen(b);

    memcpy(s, c, strlen(c));
    s += strlen(c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  *s = 0;
  return str;
}


//extern int R_PPStackTop
//extern const char *R_curErrorBuf();
//SEXP R_myTryEval(SEXP expr, SEXP env, int *errorOccurred)
void R_myTryEval(void *data)
{
  void **args = (void **) data;
  SEXP expr = (SEXP) args[0];
  SEXP env = (SEXP) args[1];
  *((SEXP*) args[2]) = eval(expr, env);

	/*
#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue
//#define SETJMP(x) setjmp(x)

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  } 


#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));


  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      val = eval(expr, env);
      UNPROTECT(1);

    } else {

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  //UNPROTECT(1);

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n", 
		    __FILE__, __LINE__, save, R_PPStackTop);
  }

  return val;



//#undef SETJMP(x) 
#undef null
#undef R_ToplevelContext
  */
}

extern int R_SignalHandlers;


/*
typedef struct shm_data_header {
  int type;
  int padding;
  size_t size;
} shm_data_header_t;
*/
// Cluster.java:
//#define TASK_RESULTS 303
//#define TASK_EXIT    304

extern int (*get_shm_identityCode)(void);

int  tr_get_shm_identityCode()
{
  static int code = 0;
  //fprintf(stderr, "code = %d\n", code); 
  return code++;
}

static size_t __page_size__ = 0;
#define SHM_BLOCK_SIZE (2*__page_size__)

static socket_conn_t *__socket_conn__ = NULL;

extern SEXP SUPR_socketConnect(SEXP hostname, SEXP port, SEXP endian_str); 
extern SEXP SUPR_socketWrite(SEXP conn, SEXP x, SEXP endian_str);
extern SEXP SUPR_socketRead(SEXP conn, SEXP what, SEXP _n, SEXP endian_str); 
extern SEXP SUPR_socketReadObject(SEXP conn, SEXP env); 
extern SEXP SUPR_socketClose(SEXP conn); 
extern SEXP socketReadDCLEvent(SEXP socket_conn, SEXP env);

void  dcl_error(const char *driver_host, int driver_port, int job_id,
	       	const char *msg, SEXP env)
{
  printf("%s: driver_host=%s\n", __func__, driver_host);
  printf("%s: driver_port=%d\n", __func__, driver_port);
  printf("%s: msg=%s\n", __func__, msg);

  SEXP host   = PROTECT(mkString(driver_host));
  SEXP port   = PROTECT(ScalarInteger(driver_port));
  SEXP endian = PROTECT(mkString("big"));
  SEXP conn   = PROTECT(SUPR_socketConnect(host, port, endian)); 

  SEXP x  = PROTECT(ScalarInteger(DCL_JOB_ERROR));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(ScalarInteger(job_id));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(mkString(msg));
  SUPR_socketWrite(conn, x, R_NilValue);

  SEXP ret  = SUPR_socketReadObject(conn, env); 
  UNPROTECT(7);


  printf("[%s] return\n", __func__);
  PrintValue(ret);

}


/*
typedef struct sync_info_struct {
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  void (*run)(void *data);
  void *data;
  sem_t           sem_wait;
  sem_t           sem_notify;
} sync_info_t;
*/


void *rjni_shm_open(const char *cshm_name, size_t *size);

// argv[0] -DCL -port port -shm shm_name -name name
// depreciated
#define SKIP_847
#ifdef SKIP_847
int data_change_listener(int argc, char **argv)
{
	basic_info("deprecated: FIXME ...");
}
#else
int data_change_listener(int argc, char **argv)
{
  // parse args

  const char *driver_host = "localhost";
  int driver_port = 0;
  const char *shm_name = NULL;

  const char *dcl_name = "default";

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-port")==0 && i+1 < argc) {
      driver_port = atoi(argv[i+1]);
      i++;
    } else if(strcmp(argv[i], "-shm")==0 && i+1 < argc) {
      shm_name = argv[i+1];
      i++;
    } else if(strcmp(argv[i], "-name")==0 && i+1 < argc) {
      dcl_name = argv[i+1];
      i++;
    }
  }

  if(!driver_port){ // FIXME
    char *driver_log_file = "DriverDir/Driver.log";
    int fd = open(driver_log_file, O_RDONLY, 0600);
    if(fd != -1){
      struct stat statbuf;
      int rc = fstat(fd, &statbuf);
      if(rc == -1) {
        printf("[%s] Error (%s, %d): %s\n", __func__, __FILE__, __LINE__, strerror(errno));
      }
      size_t size = statbuf.st_size; // printf("%s: size=%ld\n", driver_log_file, size);
      char buf[size+1];
      read(fd, buf, size);
      close(fd); // printf("%s: %s\n", driver_log_file, buf);
      char *str = strstr(buf, ":");
      *str = 0;

      str++; // printf("%s: \"%s\"\n", driver_log_file, str);
      driver_port = atoi(str);

      driver_host = strdup(buf+2);
      printf("%s: driver_host=%s\n", driver_log_file, driver_host);
      printf("%s: driver_port=%d\n", driver_log_file, driver_port);

    } else {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      exit(1);
    }
  }

  shm_io_info_t *io = NULL;
  /*
  if(shm_name){
    __page_size__  = sysconf(_SC_PAGE_SIZE);
    __io__ = io = shm_io_create(shm_name, SHM_BLOCK_SIZE);
  //tr_cntxt.io = io;
  }
  */

  tr_cntxt.io = io;
  tr_cntxt.pid = getpid();

  // initialize R
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);
  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();
  }

  myTryEval_SigactionInt = myR_SigactionDCLInt;

  // add/change signal handler
#ifdef __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sa.sa_sigaction = myR_SigactionDCLInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
  }
#endif

  __read__ = __dcl_read__;

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }

  SEXP res = R_NilValue;

  {
    SEXP call = PROTECT(LCONS(install("source"),
                            CONS(mkString("jR.R"), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);

    //printf("\033[0;32m\n\n[%s] OKAY 00\n\n\033[0m", __func__);
  }

  SEXP socket_conn = R_NilValue;
  SEXP env = R_GlobalEnv;

  if(driver_port) {
    SEXP host = PROTECT(mkString(driver_host));
    SEXP port = PROTECT(ScalarInteger(driver_port));
    SEXP endian = PROTECT(mkString("big"));
    socket_conn = PROTECT(SUPR_socketConnect(host, port, endian));
    __socket_conn__ = R_ExternalPtrAddr(socket_conn);
    //printf("[%s] socket fd = %d\n\n", __func__, __socket_conn__->fd);
 
    defineVar(install("socket.conn"), socket_conn, R_GlobalEnv); // fixme
    UNPROTECT(4);
  }

  // # register as the default listener
//#define DCL_CONN 4
  SEXP x = PROTECT(ScalarInteger(DCL_CONN));
  //printf("\033[0;33m"); PrintValue(socket_conn);
  SEXP y = SUPR_socketWrite(socket_conn, x, R_NilValue);
  //printf("[%s] y = ", __func__); PrintValue(y); printf("[%s] OKAY 01\n", __func__);

  y = SUPR_socketWrite(socket_conn, install(dcl_name), R_NilValue);
  //printf("[%s] dcl_name = %s y = ", __func__, dcl_name);
  //PrintValue(y); printf("[%s] OKAY 02\n", __func__);
  UNPROTECT(1);


  int job_id = -1;
  int tr_id = -1;
  tr_cntxt.job_id = job_id;
  tr_cntxt.tr_id =  tr_id;

  SEXP envir = env;

  defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);
  defineVar(install(TR_TR_ID), ScalarInteger(tr_id), envir);
  SEXP ioPtr = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
  defineVar(install(TR_TR_IO), ioPtr, envir);
  UNPROTECT(1);


  SEXP expr = R_NilValue;

  int X11 = TRUE;

  SEXP event = R_NilValue;


  if(shm_name){
	  /*
	  sleep(2);
	  {
		  int value = 0;
  sem_t *sem = sem_open(shm_name, O_EXCL);

  if(sem == SEM_FAILED) {
          printf("Error: sem_open, %s\n", strerror(errno));
          errorcall(R_NilValue, "sem_open, %s:%d", __FILE__, __LINE__);
  }

  sem_post(sem);
  sem_close(sem);

	  }
	  */

	 
    size_t size;
    void *mem_ptr = rjni_shm_open(shm_name, &size);
    printf("5/6: [%s] shm_name = %s\n", __func__, shm_name);
    printf("5/6: [%s] size = %ld, mem_ptr = %p\n", __func__, size, mem_ptr);

    /*
    sync_info_t *info = (sync_info_t *) mem_ptr;
    pid_t pid = ((pid_t*)(info+1))[0];
    printf("5/6: [%s] pid = %d, RDriver.pid = %d\n", __func__, getpid(), pid);
    pid = getpid();
    memcpy(info + 1, &pid, sizeof(pid_t));

    //shm_name = 
    //memcpy(((void*)(info + 1)) + sizeof(pid_t), shm_name, strlen(shm_name)+1);
    //__page_size__  = sysconf(_SC_PAGE_SIZE);
    //__io__ = io = shm_io_create(shm_name, SHM_BLOCK_SIZE);
    //tr_cntxt.io = io;

    sem_wait(&info->sem_wait);
    sem_post(&info->sem_notify);
    */
    sem_t *sem_wr = (sem_t *) mem_ptr;
    pid_t pid = ((pid_t*)(sem_wr+1))[0];
    printf("[%s] pid = %d, RDriver.pid = %d\n", __func__, getpid(), pid);
    pid = getpid();
    memcpy(sem_wr + 1, &pid, sizeof(pid_t));

    sem_post(sem_wr);
    munmap(mem_ptr, size);
   
  }

  while(TRUE){

    printf("\033[0;32m\n[%d] Next Job\n\033[0m", getpid()); 
    isDCLInterrupted = FALSE;
    isDisconnected   = FALSE;

    int errorOccurred;
    
    int save = R_PPStackTop;

    fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);

    int pi_envir;
    PROTECT_WITH_INDEX(envir, &pi_envir);
    int pi;
    PROTECT_WITH_INDEX(expr, &pi);


    SEXP nextEvent = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("socketReadDCLEvent"),
	    CONS(socket_conn, CONS(envir, R_NilValue)))));

    SEXP event = PROTECT(R_myTryEval(nextEvent, envir, &errorOccurred));

    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(event, 0)));

      if(isDCLInterrupted){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
        break;
      } else if(isDisconnected){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "disconnected");
        break;
      } else {
        UNPROTECT(4);
        continue;
      }
    } else if(TYPEOF(event) == NILSXP){
        UNPROTECT(4);
	continue;
    }
    defineVar(install("event"), event, envir);
    //PrintValue(event);

    const char *event_name = CHAR(PRINTNAME(VECTOR_ELT(event, 2))); // FIXME
    //printf("\033[031m[%s] event_name = \"%s\"\n", __func__, event_name);
    if(strcmp(event_name, "new()")==0){

       SEXP event_value = VECTOR_ELT(event, 3); // FIXME
       printf("event_value:\n"); PrintValue(event_value);

       printf("expr:\n");
       expr = VECTOR_ELT(event_value, 0); // FIXME
       REPROTECT(expr, pi);
       PrintValue(expr);

       job_id = INTEGER(VECTOR_ELT(event_value, 2))[0]; // FIXME
       printf("job_id: %d\n", job_id);
       defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);

       printf("envir:\n");
       envir = VECTOR_ELT(event_value, 1); // FIXME
       //REPROTECT(envir, pi_envir);
       if(TYPEOF(envir) == NILSXP){
         envir =  allocSExp(ENVSXP);
         REPROTECT(envir, pi_envir);
       //} else if(TYPEOF(envir) == VECSXP){
       } else if(TYPEOF(envir) != ENVSXP){
         dcl_error(driver_host, driver_port, job_id,
		 "invalid environment variable", R_GlobalEnv);
       }
       SET_ENCLOS(envir, R_GlobalEnv);
       PrintValue(envir);

    } else {
      printf("[%s] Whoops: event_name = \"%s\"\n", __func__, event_name);
      UNPROTECT(4);
      continue;
    }
    printf("\033[0m\n");
    if(save + 4 != R_PPStackTop) {
      fprintf(stderr, "Warning: save + 4 = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save + 4, R_PPStackTop, __FILE__, __LINE__);
    }

    SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
    //printf("[%s] errorOccurred = %d\n", __func__, errorOccurred);
    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
      dcl_error(driver_host, driver_port, job_id, CHAR(STRING_ELT(res, 0)), envir);
    } else 
      PrintValue(res);

    
    if(isDCLInterrupted){
      fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
      break;
    }

    if(!errorOccurred)
      UNPROTECT(5);

    if(save != R_PPStackTop) {
      fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);
    }

  }

  //if(R_Interactive) run_Rmainloop();

  fprintf(stderr, "\033[0;31m%s\033[0m", "exit");
  exit(0);

}
#endif // SKIP_847

void  Taskrunner_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));
  sleep(120);
  c_backtrace();
  printf("\n\033[0;31m");
  switch(ip->si_code){
    case SEGV_MAPERR:
         fprintf(stderr, "Address not mapped.\n");
         break;
    case SEGV_ACCERR:
         fprintf(stderr, "Access to this address is not allowed.\n");
         break;
    default:
         fprintf(stderr, "Unknown reason.\n");
         break;
  }

  sleep(120);

  printf("\n\033[0m\nR_oldSegvAct.sa_sigaction:\n");
  R_oldactSegv.sa_sigaction(sig, ip, context);
  //exit(1);
}

int out_fd = STDOUT_FILENO;
int err_fd = STDERR_FILENO;

#define __USE_SIGPIPE__
/*
#ifdef __USE_SIGPIPE__

void  Taskrunner_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{

  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
 
  fprintf(stderr,"\n\033[0;31m>>>>>>>>    %s, pid: %d    <<<<<<<<<<<<\033[0m\n\n",
                  __func__, getpid());

  fprintf(stderr, "\n\033[0;31m[%s] sig: %d, pid: %d, job_id: %d, tr_id: %d\033[0m\n\n",
                  __func__, sig, getpid(), tr_cntxt.job_id, tr_cntxt.tr_id);

  fprintf(stderr, "\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));

  c_backtrace();

  //sleep(300);
  exit(EXIT_FAILURE);
}

#endif
*/

#define USE_OUTPUT_FILES
#ifdef  USE_OUTPUT_FILES

void Taskrunner_useOutputFiles(const char *worker_dir, int out_fd, int err_fd)
{
  char path[PATH_MAX];
  sprintf(path, "%s/%d", worker_dir, getpid());
  DIR *dir = opendir(path);

  if(dir)
	  closedir(dir);
  else  if (mkdir(path, 0700) == -1){
	  fprintf(stderr, "Error: mkdir(%s, 700), %s\n", path,strerror(errno)); 
	  return;
  }

  int fd;

  sprintf(path, "%s/%d/stdout.txt", worker_dir, getpid());
  fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if(fd == -1) {
	  fprintf(stderr, "Error: open(%s, 700), %s\n", path, strerror(errno)); 
  } else {
	  dup2(fd, STDOUT_FILENO);
  }

  sprintf(path, "%s/%d/stderr.txt", worker_dir, getpid());
  fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if(fd == -1) {
	  fprintf(stderr, "Error: open(%s, 700), %s\n", path, strerror(errno)); 
  } else {
	  dup2(fd, STDERR_FILENO);
  }

}

#endif

//extern SEXP R_thread_init();
extern pid_t main_pid;

void send_ExitInfo(){

  if(getpid() != main_pid) return;

  {
    shm_io_info_t *io = tr_cntxt.io;
    if(io) {
      sem_wait(&io->err->sem_wr);
        sprintf((char*)(io->err+1), "TERMINATED");
        io->err->pid = getpid();
        io->err->data_size = strlen((char*)(io->err+1));
      sem_post(&io->err->sem_wr);

      int cmd = TR_EXIT;
      shm_io_write(io, io->out, &cmd, sizeof(int));
    }
  }

  fprintf(stderr, "%s, pid: %d, main_pid: %d\n", __func__, getpid(), main_pid);

  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  fprintf(stderr, "cth: %p\n", cth); //basic_info(__func__);
  if(cth) //basic_info(cth->name);
    fprintf(stderr, "cth->name: %s\n", cth->name);
  else return;

  return; // FIXME ...

  supr_socket_conn_t *sc = NULL;
  if(info_addr && (sc = trySocketOpen1(info_addr))){
    int fd = sc->fd;

    int cmd = CLUSTER_PROC_CMD;
    write(fd, &cmd, sizeof(int));
    int len = strlen(proc_cmd)+1;
    write(fd, &len, sizeof(int));
    write(fd, proc_cmd, len);
    int rc;
    read(fd, &rc, sizeof(int));

    char msg[1024];

    for(int i=0; threads && i<vectorSize(threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);

      // msg_header?
      cmd = CLUSTER_INFO;
      write(fd, &cmd, sizeof(int));
      unsigned char buf[8];
      snprintf(buf, 8, "%s", msg_color);
      write(fd, buf, sizeof(buf));
      int type = DEFAULT_INFO_TYPE;
      write(fd, &type, sizeof(int));
      int level = 0; // not used
      write(fd, &level, sizeof(int));

      sprintf(msg, "\033[0;33m%s:%d: %s, tid: %d, state: %s, \tname: %s\033[0m",
                    __FILE__, __LINE__, __func__,
                    th->tid, state2char(th->state), th->name);

      ssize_t len_msg = strlen(msg)+1;
      write(fd, &len_msg, sizeof(ssize_t));
      write(fd, msg, len_msg);
      read(fd, &rc, sizeof(int));
    }

    cmd = CLUSTER_INFO;
    write(fd, &cmd, sizeof(int));
    unsigned char buf[8];
    snprintf(buf, 8, "%s", msg_color);
    write(fd, buf, sizeof(buf));
    int type = DEFAULT_INFO_TYPE;
    write(fd, &type, sizeof(int));
    int level = 0; // not used
    write(fd, &level, sizeof(int));

    sprintf(msg, "\033[0;35m%s:%d: %s[%s], .., terminated\033[0m",
                    __FILE__, __LINE__, __func__, Supr_curStrError);

    ssize_t len_msg = strlen(msg)+1;
    write(fd, &len_msg, sizeof(ssize_t));
    write(fd, msg, len_msg);
    read(fd, &rc, sizeof(int));

  } else {
    fprintf(stderr, "func: %s[%s], this tid: %ld, pid: %d ..., terminated",
                    __func__, Supr_curStrError,
                    syscall(SYS_gettid),  getpid());
  }
}




static const char *__doc__ ="  taskrunner [--help] ..."
        "..."
        "... TODO ...\n";



void run(void *ptr);
char **__argv = NULL;
static int terminate = FALSE;

void main_cleanup(void *data)
{
    fprintf(stderr, "%s\n", __func__);
    sleep(1);
    exit(EXIT_SUCCESS);
}

//static pthread_mutex_t R_eval_mutex = PTHREAD_MUTEX_INITIALIZER;

void Supr_CheckInterrupt_init()
{
  shm_io_info_t *io = tr_cntxt.io;
  if(!io) {
    error_info("'tr_cntxt.io' not found");
    return;
  }

  //char *err = NULL;
  sem_wait(&io->err->sem_wr);
    if(io->err->data_size){
      //err = malloc(strlen((char*)(io->err+1))+1);
      //sprintf(err, "%s", (char*)(io->err+1));
      io->err->pid = 0;
      io->err->data_size = 0;
    }
  sem_post(&io->err->sem_wr);

  /*
  if(err){
    basic_info(err);
    char buf[strlen(err)+1];
    strcpy(buf, err);
    free(err);
  }
  */
}

void Supr_CheckInterrupt()
{
  shm_io_info_t *io = tr_cntxt.io;
  if(!io) {
    error_info("'tr_cntxt.io' not found");
    return;
  }

  char *err = NULL;
  sem_wait(&io->err->sem_wr);
    if(io->err->data_size){
      err = malloc(strlen((char*)(io->err+1))+1);
      sprintf(err, "%s", (char*)(io->err+1));
      io->err->pid = 0;
      io->err->data_size = 0;
    }
  sem_post(&io->err->sem_wr);

  if(err){
    //basic_info(err);
    char buf[strlen(err)+1];
    strcpy(buf, err);
    free(err);
    error(_(buf));
  }


  /*
  int cmd = TR_CHECK_INTERRUPT;
  shm_io_write(io, io->out, &cmd, sizeof(int));

  size_t size;
  //so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  //SEXP val = SO_toRObject(so, size);
  //free(so);
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  int rc = ((int*) ptr)[0];
  {
	  char msg[256];
	  sprintf(msg, "rc: %d", rc);
	  basic_info(msg);
  }
  switch(rc){
    case TR_CLUSTER_INTERRUPT: // cancel job
	 {
           ptr_R_ProcessEvents = NULL;
           int rc = pthread_mutex_trylock(&R_eval_mutex);
	   if(rc != 0){
             ptr_R_ProcessEvents = NULL;
	     error(_("JOB CANCELLED"));
	   } else {
             pthread_mutex_unlock(&R_eval_mutex);
	     basic_info("TR_CLUSTER_INTERRUPT: ignored");
	   }
	 }
	 break;

    defaut:
	 break;
  }
  */
}


#define STATE_UNINITIALIZED 0
#define STATE_INITIALIZED 1
#define STATE_JOB_ASSIGNED 2
#define STATE_JOB_EVAL 3
#define STATE_RESULT_SEND 4

static int tr_state = STATE_UNINITIALIZED;

/*
void  sendTaskError(void *data)
{
  SEXP ro = PROTECT(allocVector(VECSXP, 3));
  SEXP names = PROTECT(allocVector(STRSXP, 3));
  setAttrib(ro, R_NamesSymbol, names);

  SET_STRING_ELT(names, 0, mkChar("error"));
  SEXP err = PROTECT(mkString(R_curErrorBuf()));
  SET_VECTOR_ELT(ro,    0, err);
  UNPROTECT(1);

  {
        SEXP call = PROTECT(LCONS(install(".traceback"), R_NilValue));
        SEXP tb = PROTECT(eval(call, R_GlobalEnv));
        setAttrib(err, install(".traceback"), tb);
        UNPROTECT(2);
  }

  {
        SEXP warnings = findVar(install("last.warning"), R_BaseEnv);
        if(warnings != R_UnboundValue){
          SET_VECTOR_ELT(ro, 1, warnings);
          SET_STRING_ELT(names, 1, mkChar("warnings")); // return code
        } else {
          SET_VECTOR_ELT(ro, 1, R_NilValue);
          SET_STRING_ELT(names, 1, mkChar("warnings")); // return code
        }
  }

  {
        SEXP s = PROTECT(allocVector(STRSXP, 3));
        SEXP n = PROTECT(allocVector(STRSXP, 3));
        SET_VECTOR_ELT(ro, 2, s);
	SET_STRING_ELT(names, 2, mkChar("taskrunner"));

        SET_STRING_ELT(s, 0, mkChar(Supr_hostname));
        SET_STRING_ELT(s, 1, mkChar(__argv[1]));
        char pid[32];
        sprintf(pid, "%d", getpid());
        SET_STRING_ELT(s, 2, mkChar(pid));
        SET_STRING_ELT(n, 0, mkChar("host"));
        SET_STRING_ELT(n, 1, mkChar("shm"));
        SET_STRING_ELT(n, 2, mkChar("pid"));
        setAttrib(s, R_NamesSymbol, n);
        UNPROTECT(2);
  }

  size_t size;
  so_t *so = SO_valueOf(ro, &size);

  void *array = malloc(sizeof(int) + sizeof(size_t) + 4*sizeof(int) + size);
  ((int*)array)[0] = TR_SEND_DRIVER;
  ((size_t *)(array+sizeof(int)))[0] = 4*sizeof(int) + size;
  int *header = (int*) (array + sizeof(int) + sizeof(size_t));
  header[0] = TASK_RESULTS;
  header[1] = tr_cntxt.job_id;
  header[2] = tr_cntxt.tr_id;
  header[3] = TR_TASK_STATUS_FAILURE;
  memcpy(array+sizeof(int) + sizeof(size_t) +4*sizeof(int), so, size);
  --so->ref_count;
  if(so->ref_count == 0) free(so);
  
  if(FALSE){
  shm_io_info_t *io = (shm_io_info_t *) data;
  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int)); 

  shm_io_write(io, io->out, array, 4*sizeof(int)+ size);
  free(array);
  }

  supr_socket_conn_t *parent_sc = socketOpen2(Supr_hostname, worker_port);
  if(parent_sc){
    int fd = parent_sc->fd;
    ssize_t n = write(fd, array, sizeof(int) + sizeof(size_t) + 4*sizeof(int) + size);
    // if(n == -1) ...
    pid_t pid = getpid();
    write(fd, &pid, sizeof(pid_t));  

    int rc;
    read(fd, &rc, sizeof(int));
    // if(n == -1) ...
    free(array);
  } else {
    fprintf(stderr, "Cannot connect to worker\n");
    fflush(stderr);
    basic_info("\033[0;31mCannot connect to worker\033[0m");
  } 


  UNPROTECT(1);

  exit(EXIT_FAILURE);
  //error_info("TODO");
}
*/

//static int Supr_errorOccurred = FALSE;

void do_testing(void *data){
  char *what = (char*) data;

  if(strcmp(what, "info")==0){
    char msg[256];
    sprintf(msg, "R> info(\"%s:%d\")", Supr_hostname, getpid());

    basic_info("\033[0;34meval(call, R_GlobalEnv) ...\033[0m");
    SEXP call = PROTECT(LCONS(install("info"), 
    	CONS(mkString(msg), R_NilValue)));
    eval(call, R_GlobalEnv);
    basic_info("\033[0;34m// eval(call, R_GlobalEnv) \033[0m");
    UNPROTECT(1);
  }
}

//int Taskrunner(int argc, char **argv);

// see supr.c
#define SUPR_INFO   3012


int Taskrunner_sendSimpleMessage(const char *msg, const char *color,
	 int type, int level) {
  int rc = -1;
  if(!msg)  return rc;

  static char *host = NULL;
  static int port = -1;

  if(!host){ // && level > 0?
    if(info_addr){ // && level > 0?
      host = strdup(info_addr);
      char *s = strchr(host, ':');
      if(s) { *s = 0; s++;}
      port = atoi(s);
    }
  }

  if(host){ // && level > 0?
    //supr_socket_conn_t *sc = socketOpen1(info_addr);
    //int fd = sc->fd;
    int fd = socket_client(host, port);
    if(fd == -1) return -1;

    char buf[strlen(msg)+1+strlen(proc_cmd)+strlen(Supr_hostname)+64];
    char host[strlen(Supr_hostname)+1];
    memcpy(host, Supr_hostname, strlen(Supr_hostname)+1);
    char *s = strchr(host, '.'); if(s) *s = 0;
    //sprintf(buf, "[INFO@%s-%d.%s]", proc_cmd, getpid(), host);
    sprintf(buf, "[INFO@tr-%d.%s]", getpid(), host);
    sprintf(buf+strlen(buf), " %s", msg);
    msg = buf;

    int cmd = SUPR_INFO;
    write(fd, &cmd, sizeof(int));
    int len = strlen(msg)+1;
    write(fd, &len, sizeof(int));
    write(fd, msg, len);
    read(fd, &rc, sizeof(int));
    close(fd);
  }
  return rc;
}

int main(int argc, char **argv)
{
  Supr_sendSimpleMessage = Taskrunner_sendSimpleMessage;

  pthread_cleanup_push(main_cleanup, NULL);

  __cluster_messages_ptr__ = Taskrunner_messages;
  __cluster_recv_ptr__ = Taskrunner_recv;

  proc_cmd = argv[0];
  while(strstr(proc_cmd, "/")) proc_cmd = strstr(proc_cmd, "/")+1;
  __argv = argv;
  Supr_debug = TRUE;
  char msg[1024];

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--help")==0){
      fprintf(stderr, "%s\n", __doc__);
      exit(EXIT_SUCCESS);
    } else if(strcmp(argv[i], "-info")==0 && ++i < argc){
	    info_addr = argv[i];
fprintf(stderr, "%s:%d. FIXME\n", __FILE__, __LINE__);
/* // FIXME
	    if(strstr(info_addr, ":"))
	      info_sc = socketOpen1(info_addr);
	    else info_addr = NULL;
*/
    } else {
      fprintf(stderr, "\targv[%d] %s\n", i, argv[i]);
    }
  }

  //fprintf(stderr, "info_sc: %p\n", info_sc);
  if(info_sc){
	info_sc->port = atoi(strstr(info_addr, ":")+1);
        int cmd = CLUSTER_PROC_CMD;
        write(info_sc->fd, &cmd, sizeof(int));
        char *proc_cmd = argv[0];
        while(strstr(proc_cmd, "/"))
          proc_cmd = strstr(proc_cmd, "/")+1;
        int len = strlen(proc_cmd)+1;
        write(info_sc->fd, &len, sizeof(int));
        write(info_sc->fd, proc_cmd, len);
        int rc;
        read(info_sc->fd, &rc, sizeof(int));
	/*
	Cluster_sendSimpleMessage(argv[0], msg_color, DEBUG_INFO_TYPE, 0);
	sprintf(msg, "hostname: %s, pid: %d", Supr_hostname, getpid());
	Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
	*/
  }

  main_pid = getpid();
  atexit(send_ExitInfo);

  int tid = (int) syscall(SYS_gettid);

  int rc = prctl(PR_SET_PDEATHSIG, SIGHUP);
  if(rc == -1) {
	  basic_info("Error in prtctl");
	  basic_info(strerror(errno));
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = Taskrunner_sigaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGHUP, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = Taskrunner_sigaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGTERM, &sa, NULL);
  }
  
  {
    struct sigaction sa;
    sa.sa_sigaction = Taskrunner_sigaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGPIPE, &sa, NULL);
  }

  /*
  {
    struct sigaction sa;
    sa.sa_sigaction = Taskrunner_sigaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, NULL);
  }
  */

  ptr_R_ProcessEvents = NULL;
  
  /*
  {
    struct sigaction sa;
    sa.sa_sigaction = Thread_SigactionSIGUSR1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }
  */



  /*
  {
    char name[128];
    sprintf(name, "Taskrunner: %d", tid);
    char CMD_PATH[PATH_MAX];
    sprintf(CMD_PATH, "%s/task", SUPR_HOMESYS);
    char *args[argc+1];
    memcpy(args, argv, argc*sizeof(char*));
    args[argc] = (char*) NULL;
    supr_xterm_t *xterm = supr_xterm2(name, args);
    sleep(30);
    exit(0);
  }
  */
  
  // sys_dir
  char sys_dir[PATH_MAX];
  char *cwd = getcwd(sys_dir, PATH_MAX);

      fprintf(stderr, "\tcwd %s\n", cwd);

  //int worker_port = 0;

  //char hostname[256];
  //gethostname(hostname, 256);
  printf("\033[0;34mhost: %s, sys_dir: %s\n==================\n", Supr_hostname, sys_dir);
  char *worker_dir = NULL;
  for(int i=0; i<argc; i++){
     printf("[%d] %s\n", i, argv[i]); 
     if(i< argc-1){
       if(strcmp(argv[i], "-worker.dir")==0) {
         worker_dir = argv[++i];
         printf("[%d] %s\n", i, argv[i]); 
       } else if(strcmp(argv[i], "-worker.port")==0) {
         worker_port = atoi(argv[++i]);
         printf("[%d] %s (port: %d)\n", i, argv[i], worker_port); 
       }
     }
  }
  printf("\n====================\nworker.dir: %s\n\n\033[0m", worker_dir);
  fflush(stdout);

  if(!worker_dir){

	  /*
    char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
    int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE;  // Rf_initialize_R set this based on isatty 
    printf("R_CStackStart: %0lx\n", R_CStackStart);
    setup_Rmainloop();

    int i=0;
    for(RCNTXT *cntxt_ptr = R_GlobalContext; cntxt_ptr;
      	cntxt_ptr = cntxt_ptr->nextcontext){
        printf("\t[%d] cntxt_ptr: %0lx, R_CStackStart - cntxt_ptr: %0lx\n", i, (unsigned long)cntxt_ptr,
			R_CStackStart - ((unsigned long)cntxt_ptr));
	if(!cntxt_ptr->nextcontext){
          printf("\tcntxt_ptr->cjmpbuf:  %0lx\n", (unsigned long)cntxt_ptr->cjmpbuf);
          printf("\t&cntxt_ptr->cjmpbuf: %0lx\n", (unsigned long)&cntxt_ptr->cjmpbuf);
		
	}
    }

    //int rc = R_ToplevelExec(Taskrunner_backtrace, NULL);
    SEXP call = PROTECT(LCONS(install("library"),
			    CONS(mkString(PACKAGE_NAME), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);
    R_thread_init();

    myR_SigactionTaskRunnerInt(SIGINT, NULL, NULL);
    */

    exit(EXIT_FAILURE);
  }


  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);


  int worker_fd = -1;
  if(worker_port){
    /*
    int sc_fd = socket_client(Supr_hostname, worker_port);
    if(sc_fd != -1){
      printf("Info: socket_client, connected!, fd: %d\n", sc_fd);
      int cmd = TR_PRINT_STDOUT;
      write(sc_fd, &cmd, INT_SIZE);
      int pid = getpid();
      write(sc_fd, &pid, INT_SIZE);
      dup2(sc_fd, STDOUT_FILENO);
      dup2(sc_fd, STDERR_FILENO);
      worker_fd  = sc_fd;

      //FIXME
      int msg[] = {SET_CONN_PID, getpid(), TASKRUNNER_CONN};
      write(worker_fd, msg, sizeof(msg));

      // int cmd = CLUSTER_TASKRUNNER_REGISTER;
      // write(sc_fd, &cmd, INT_SIZE);
      //write(sc_fd, &pid, INT_SIZE);

    } else {
      printf("Error: socket_client, %s\n", strerror(errno));
    }
    */
    parent_sc = trySocketOpen2(Supr_hostname, worker_port);
  }

  /*
  if(parent_sc && info_sc) {
    close(info_sc->fd);
    free(info_sc); // FIXME
    info_sc = NULL;

    int msg[] = {SET_CONN_PID, getpid(), TASKRUNNER_CONN};
    write(parent_sc->fd, msg, sizeof(msg));
  }
  */

#ifdef  USE_OUTPUT_FILES
  Taskrunner_useOutputFiles(worker_dir, out_fd, err_fd);
#endif

  {
    char path[PATH_MAX];
    sprintf(path, "%s/tr_dir", cwd);
    chdir(path);
    printf("[%s] getcwd: %s\n", __func__,  getcwd(path, PATH_MAX));
  }



  myTryEval_SigactionInt = myR_SigactionTaskRunnerInt;
  //myTryEval_SigactionInt = myTryEval_SigactionTaskRunnerInt;

#define DATA_CHANGE_LISTENER   "-DCL"
  for(int i=0; i<argc; i++){
     if(strcmp(argv[i], DATA_CHANGE_LISTENER)==0)
       return data_change_listener(argc, argv);
  }
#undef DATA_CHANGE_LISTENER  


  char *shm_name = argv[1];

  shm_io_info_t *io = shm_io_open(shm_name);

  __io__ = io;

  tr_cntxt.io = io;
  tr_cntxt.pid = getpid();
  tr_cntxt.firstSubset = R_UnboundValue;
  
  get_shm_identityCode = tr_get_shm_identityCode;
 


 
  char buf[256];
  //sprintf(buf, "\033[0;32m%d: Hello %d!\033[0m", getpid(), getppid());
  sprintf(buf, "%d: Hello %d!", getpid(), getppid());
  shm_io_write(io, io->out, buf, strlen(buf)+1);

  // read worker server port
  {
    size_t size;
    int *port = (int*) shm_io_read(io, io->in, &size, NULL);
    tr_cntxt.port = *port;
    char hostname[256];
    gethostname(hostname, sizeof(hostname));
    tr_cntxt.host = strdup(hostname);
    printf("[%s] Worker server conn: //%s:%d\n", __func__, tr_cntxt.host,
		    tr_cntxt.port);
  }
  
  //shm_io_write(io, io->out, buf, strlen(buf)+1);


  // Start R
  //char *argv[] = {"REmbeddedPostgres", "--gui=none", "--silent"};
  //char *new_argv[] = {"Java_HelloJNI"};
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  //printf("\033[0;31mR_CStackStart = %ld\n\033[0m", R_CStackStart);
  //printf("R_CStackLimit = %ld\n", R_CStackLimit);
  //printf("R_Interactive = %d\n", R_Interactive);

#define NOT_USE_DEV_NULL_FOR_INIT

  //Rf_initEmbeddedR(argc, argv);
  // start a large stack-size pthread???
  // set JVM stack size
  {
#ifdef USE_DEV_NULL_FOR_INIT
    int devNull = open("/dev/null", O_WRONLY);
    int out_fd = dup(STDOUT_FILENO);
    int err_fd = dup(STDERR_FILENO);
    dup2(devNull, STDERR_FILENO);
    dup2(devNull, STDOUT_FILENO);

    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();

    dup2(out_fd, STDOUT_FILENO);
    dup2(err_fd, STDERR_FILENO);
#else
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();
#endif
  }

  //{
     //printf("R_Outputfile: %p\n",  R_Outputfile);
     //printf("R_Consolefile: %p\n", R_Consolefile);
     //PrintValue(mkString("Hello, Taskrunner!"));
  //}
 
  //
#define __USE_SIGINT__
#ifdef __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionInt;
    sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
  }
#endif
//
  
 
  {
    struct sigaction sa;
    sa.sa_sigaction = Taskrunner_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, &R_oldactSegv);
  }
 
  /*
#ifdef __USE_SIGUSR1__
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }
#endif

#ifdef __USE_SIGUSR2__
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);
  }
#endif
  
#ifdef __USE_SIGPIPE__
   {
    struct sigaction sa;
    sa.sa_sigaction = Taskrunner_sigaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGPIPE, &sa, NULL);
  }
#endif
*/

  SEXP res = R_NilValue;

  SEXP task_info = R_NilValue;
  {
    SEXP call = PROTECT(LCONS(install("library"),
			    CONS(mkString(PACKAGE_NAME), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);
    R_thread_init();

    task_info = findVar(install("task.info"), Supr_namespace);
    char tr_name[strlen(Supr_hostname)+32];
    sprintf(tr_name, "%s:%d", Supr_hostname, getpid());
    SETCAR(task_info, mkString(tr_name));
    fprintf(stdout, "task_info:\n");
    PrintValue(task_info);
  }

/*
  if(info_addr){
     defineVar(install("info"), SuprContextEnv, mkString(info_addr));
     SEXP call = PROTECT(LCONS(install("info"),
			    CONS(mkString(PACKAGE_NAME),  R_NilValue)));
     eval(call, R_GlobalEnv);
  }
*/
  //JobEnv_init();

  if(!threads) {
	  threads = newVector(TRUE);
	  vectorAdd(threads, main_thread);
  }

//#define STATE_JOB_ASSIGNED 2
//#define STATE_JOB_EVAL 3
//#define STATE_RESULT_SEND 4
  tr_state = STATE_INITIALIZED;


  {
    char *what = "__info";
    Rboolean success = R_ToplevelExec(do_testing,  what);
    if(!success){
      error_info("Error in R_ToplevelExec(run, ptr): %s",
		      R_curErrorBuf());
    }
  }

  while(TRUE) { 
    
    //isTaskrunnerInterrupted = FALSE;
    R_isInterrupted = FALSE;
    terminate = FALSE;

    tr_cntxt.firstSubset = R_UnboundValue;
    SETCDR(task_info, R_NilValue);
    // clean SuprJobEnv ...

    size_t size;
    //char *_shm_name=NULL;

    fprintf(stderr, "\033[0;32m");
    MALLOC_PRINT;
    fprintf(stderr, "\033[0m");
    fflush(stderr);

#define SHMCACHE_REMOVE_ALL
#ifdef  SHMCACHE_REMOVE_ALL
    fprintf(stderr, "\033[0;36m");
    ShmCache_clear();
    MALLOC_PRINT;
    fprintf(stderr, "\033[0m");
    fflush(stderr);
#endif


MALLOC_MARK(1);
MALLOC_MARK(__LINE__);

    //fprintf(stderr, "\n[INFO] Ready for the next task ...\n");
    if(Supr_options.debug){
      sprintf(msg, "%s: ready for the next job ...", argv[0]);
      debug_info(msg);
    }
    //fflush(stdout);
    /*
    if(worker_fd != -1){
      //int form_feed = 12;
      //write(worker_fd, &form_feed, INT_SIZE);
      unsigned char flush_str[] = {'\033', 'f', 'l', 'u', 's', 'h'}; // FIXME
      write(worker_fd, &flush_str, sizeof(flush_str));
      fflush(stdout);
    }
    */
    //fprintf(stderr, "[%s] Ready for the next job ...\n", __func__);
    // { printf("[%s] No error\n", __func__); PrintValue(res); }
    //void *ptr = shm_io_read(io, io->in, &size, NULL);

    //run(ptr);
    Rboolean success = R_ToplevelExec(run, io);
    if(success){
      if(Supr_options.debug){
        sprintf(msg, "R_ToplevelExec(run, ptr): success");
        debug_info(msg);
      }
    } else {
      sprintf(msg, "Error in R_ToplevelExec(run, ptr): %s",
		      R_curErrorBuf());
      error_info(msg);
      /*
      if( tr_state >= STATE_JOB_ASSIGNED &&
          tr_state <  STATE_RESULT_SEND){
        Rboolean success = R_ToplevelExec(sendTaskError, io);
	if(!success){
          exit(EXIT_FAILURE);
	}
      }
      */
    }

    int cmd = TR_NEXT_JOB;
    shm_io_write(io, io->out, &cmd, sizeof(int));

    //if(Supr_errorOccurred) exit(EXIT_FAILURE);
  }

  pthread_cleanup_pop(TRUE);

  return 0;
}

int Taskrunner_exit()
{
	exit(EXIT_SUCCESS); // TODO?
}

void run(void *__io)
{
  ptr_R_ProcessEvents = NULL;
  Supr_CheckInterrupt_init();

  char msg[1024];
  int tid = (int) syscall(SYS_gettid);
  size_t size;

  SEXP task_info = findVar(install("task.info"), Supr_namespace);
//{

  shm_io_info_t *io = (shm_io_info_t *) __io;

    void *ptr = shm_io_read(io, io->in, &size, NULL);
    int cmd = ((int*) ptr)[0];

    //printf("[%s:%d] Command: %d %s\n", __func__, tid,  cmd, cmd2str(cmd));
    //fprintf(stderr, "Command: %d %s\n",  cmd, cmd2str(cmd));
    //free(ptr);
    if(Supr_options.debug){
      sprintf(msg, "[%s:%d] Command: %d %s", __func__, tid,  cmd, cmd2str(cmd));
      debug_info(msg);
    }
    
    if(cmd ==  TR_EXIT)  {
      free(ptr); Taskrunner_exit();
    } else if(cmd == TR_NEW_JOB){


      int job_id = ((int*)ptr)[1];
      free(ptr);
      // message:
      //fprintf(stderr, "[%s] .job_id = %d, Continue ...\n", __func__, job_id);

      ptr = shm_io_read(io, io->in, &size, NULL);
      //printf("\n[%s] size = %ld, Continue ...\n", __func__, size);

      int myid = -1; // for this job

      {
        if(tr_cntxt.bc_sync){
          broadcast_lock_t* bc = tr_cntxt.bc_sync;
	  munmap(bc, sizeof(broadcast_lock_t) +strlen(bc->shm_name)+1);
          tr_cntxt.bc_sync = NULL;
	}

        char shm_name[256];
        sprintf(shm_name, "%s-%d-bc-%d-sync", shm_prefix, getppid(), job_id);
        ssize_t size;
        void *bc_shm_ptr = Supr_shm_open(shm_name, &size);
	if(!bc_shm_ptr) {
		char msg[256];
		sprintf(msg, "cannot open %s", shm_name);
		error_info(msg);
	}
        tr_cntxt.bc_sync = (broadcast_lock_t*) bc_shm_ptr;
        tr_cntxt.bc_id = 0;


	if(Supr_options.verbose)
	  verbose_info(shm_name);
      }

      {
        defineVar(install("job"), ScalarInteger(job_id), SuprJobEnv);

        defineVar(install(".job.id"), ScalarInteger(job_id), R_GlobalEnv);
        //defineVar(install("tr.id"), ScalarInteger(NA_INTEGER), R_GlobalEnv);
	/*
        defineVar(install("tr.id"), R_UnboundValue, R_GlobalEnv);
        defineVar(install(".tr.id"), R_UnboundValue, R_GlobalEnv);
        defineVar(install("tr.id"), R_NilValue, R_GlobalEnv);
        defineVar(install(".tr.id"), R_NilValue, R_GlobalEnv);
	*/

	//SEXP task_info = findVar(install("task.info"), Supr_namespace);
	SETCDR(task_info, CONS(ScalarInteger(job_id), R_NilValue));
	SET_TAG(CDR(task_info), install("job.id"));
	fprintf(stdout, "task_info:\n");
	PrintValue(task_info);



	/*
	char name[strlen(Supr_hostname)+32];
	sprintf(name, "%s:%d", Supr_hostname, getpid());
        defineVar(install(".tr.name"), mkString(name), R_GlobalEnv);
	*/
	// task.info$tr.name // taskrunner.name
        //defineVar(install("tr"), mkString(name), SuprJobEnv);
	// TODO ...

	/*
	 * .Internal(remove(mkString(".tr.id"), R_GlobalEnv, R_FalseValue)) ??
	 * .Internal(remove(mkString("tr.id"), <environment>, FALSE))
	 *
	SEXP job_info = PROTECT(CONS(ScalarInteger(job_id), R_NilValue));
	SET_TAG(job_info, install("job.id"));
        defineVar(install(".JobInfoList"), job_info, R_GlobalEnv);
	SETCDR(job_info, CONS(mkString(name), R_NilValue));
	job_info = CDR(job_info);
	SET_TAG(job_info, install("tr.name"));
	*/
      }

      tr_cntxt.job_id = job_id;
      tr_cntxt.tr_id =  -1;
      
      { // register
        cmd = TR_JOB_REGISTER;
        shm_io_write(io, io->out, &cmd, sizeof(int));

        size_t _size;
        //char *_shm_name=NULL;
        void *id = shm_io_read(io, io->in, &_size, NULL);
	myid = ((int*)id)[0];
        //printf("\n[%s] myid = %d, Continue ...\n", __func__, myid);
        // message:
        //fprintf(stderr, "[%s] .tr.id = %d, Continue ...\n", __func__, myid);
	free(id);
	if(myid == -1){
          //cmd = TR_NEXT_JOB;
          //shm_io_write(io, io->out, &cmd, sizeof(int));
	  free(ptr);
	  return; //continue;
	}
      }

      if(myid == -1){
        free(ptr);
        //cmd = TR_NEXT_JOB;
        //shm_io_write(io, io->out, &cmd, sizeof(int));
	return; //continue;
      }

      {
        //defineVar(install("tr.id"), ScalarInteger(myid), R_GlobalEnv);
        //defineVar(install("tr"), ScalarInteger(myid+1), SuprJobEnv);
        defineVar(install(".tr.id"), ScalarInteger(myid+1), R_GlobalEnv);

//	SEXP task_info = findVar(install("task.info"), Supr_namespace);
	SEXP  tr_id =  PROTECT(CONS(ScalarInteger(myid+1), CDR(task_info)));
	SETCDR(task_info, tr_id);
	UNPROTECT(1);
	SET_TAG(tr_id, install("task.id"));
	fprintf(stdout, "task_info:\n");
	PrintValue(task_info);

      }
      fprintf(stderr, "[INFO] Run, .job_id: %d, .tr_id: %d\n", job_id, myid);

      tr_cntxt.tr_id = myid;

      tr_state = STATE_JOB_ASSIGNED;

      so_t *so = (so_t*) ptr;
      so->ref_count = 1;
      SEXP ro = PROTECT(SO_toRObject(ptr, size));
      if(so->ref_count)
      free(ptr);

      // read the subset
      ptr = shm_io_read(io, io->in, &size, NULL);
      so = (so_t*) ptr;
      so->ref_count = 1;
      SEXP subset = PROTECT(SO_toRObject(ptr, size));
      if(so->ref_count)
      free(ptr);

      SEXP envir = VECTOR_ELT(ro, 1);
      if(envir == R_NilValue) {
        //envir = R_GlobalEnv;
        envir =  PROTECT(allocSExp(ENVSXP));
        SET_VECTOR_ELT(ro, 1, envir);
	UNPROTECT(1);
      } 



      SET_ENCLOS(envir, R_GlobalEnv); // FIXME 
      //SET_ENCLOS(envir, SuprJobEnv);//SuprJobEnv=JobEnv_createObjectTableEnv
      //SET_ENCLOS(SuprJobEnv, R_GlobalEnv);

      defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);
      defineVar(install(TR_TR_ID), ScalarInteger(myid), envir);
      //SEXP ioPtr=PROTECT(R_MakeExternalPtr(io, install("future"),R_NilValue));
      SEXP ioPtr = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
      defineVar(install(TR_TR_IO), ioPtr, envir);

      //defineVar(install(".firstSubset"), subset, envir);
      defineVar(install("firstSubset"), subset, SuprJobEnv);
      tr_cntxt.firstSubset = subset;
        
      //defineVar(install("tr"), ScalarInteger(myid), SuprJobEnv);

      tr_shm_init(job_id, myid);

      int errorOccurred;
      //SEXP res = PROTECT(R_tryEval(VECTOR_ELT(ro,0), R_GlobalEnv,
      //		    &errorOccurred));

      //SEXP res = PROTECT(R_tryEval(VECTOR_ELT(ro, 0), envir,
      //		    &errorOccurred));

      int save = R_PPStackTop;


      SEXP res = R_UnboundValue;
      void *args[] = {VECTOR_ELT(ro, 0), envir, &res};
      //Rboolean success = R_ToplevelExec(R_myTryEval, args);

//#define STATE_RESULT_SEND 4
      tr_state = STATE_JOB_EVAL;

      //pthread_mutex_lock(&R_eval_mutex);
      ptr_R_ProcessEvents = Supr_CheckInterrupt;
      errorOccurred = !R_ToplevelExec(R_myTryEval, args);
      ptr_R_ProcessEvents = NULL;
      //pthread_mutex_unlock(&R_eval_mutex);

      //Supr_errorOccurred = errorOccurred;



      if(errorOccurred) res = mkString(R_curErrorBuf());

      // terminate if errorOccurred
      /*
      if(errorOccurred) {
        R_ToplevelExec(sendTaskError, io);
        exit(EXIT_FAILURE);
      }
      */

      PROTECT(res);

      if(errorOccurred) {
        SEXP call = PROTECT(LCONS(install(".traceback"), R_NilValue));
	SEXP tb = PROTECT(eval(call, R_GlobalEnv));
	setAttrib(res, install(".traceback"), tb);
	UNPROTECT(2);
      }

      if(Supr_options.debug){
        sprintf(msg, "R_ToplevelExec(R_myTryEval, args): %s", 
		      errorOccurred?"FAILURE":"SUCCESS");
        debug_info(msg);
      }

      if(R_PPStackTop <= save) {
        basic_info("FIXME: shouldon't occurre");
        fprintf(stderr, "[%s, %d] save %d, R_PPStackTop = %d\n",
		     __FILE__, __LINE__,  save, R_PPStackTop);
	PROTECT(ro);
	PROTECT(res);
      }


      SET_VECTOR_ELT(ro, 0, res);
      //SET_VECTOR_ELT(ro, 1, ScalarInteger(errorOccurred));
      //SET_VECTOR_ELT(ro, 2, mkString(argv[1])); // taskrunner.shm
      {
        //char name[strlen(Supr_hostname) + 32];
	//sprintf(name, "%s:%d", Supr_hostname, getpid());
        //SET_VECTOR_ELT(ro, 2, mkString(name));
	SEXP s = PROTECT(allocVector(STRSXP, 3));
	SEXP n = PROTECT(allocVector(STRSXP, 3));
        SET_VECTOR_ELT(ro, 2, s);
        SET_STRING_ELT(s, 0, mkChar(Supr_hostname));
        SET_STRING_ELT(s, 1, mkChar(__argv[1]));
	char pid[32];
	sprintf(pid, "%d", getpid());
        SET_STRING_ELT(s, 2, mkChar(pid));
        SET_STRING_ELT(n, 0, mkChar("host"));
        SET_STRING_ELT(n, 1, mkChar("shm"));
        SET_STRING_ELT(n, 2, mkChar("pid"));
	setAttrib(s, R_NamesSymbol, n);
	UNPROTECT(2);
      }

      SEXP names = getAttrib(ro, R_NamesSymbol);
      if(errorOccurred)
        SET_STRING_ELT(names, 0, mkChar("error"));
      else
        SET_STRING_ELT(names, 0, mkChar("value"));
      //SET_STRING_ELT(names, 1, mkChar("rc")); // return code
      SET_STRING_ELT(names, 2, mkChar("taskrunner")); // return code

      // warnings???
      
      {
        SEXP warnings = findVar(install("last.warning"), R_BaseEnv);
	if(warnings != R_UnboundValue){
          SET_VECTOR_ELT(ro, 1, warnings);
          SET_STRING_ELT(names, 1, mkChar("warnings")); // return code
	} else {
          SET_VECTOR_ELT(ro, 1, R_NilValue);
          SET_STRING_ELT(names, 1, mkChar("warnings")); // return code
	}
      }
     

      {
         size_t buf_size = 128*200;
	 char buf[buf_size];
//	 fprintf(stderr, "result to return: %s\n", __r2str(ro, buf, buf_size, 0));
//	 fprintf(stdout, "result to return: %s\n", __r2str(ro, buf, buf_size, 0));
//	 fprintf(stderr, "isInterrupted: %d\n\n", R_isInterrupted);
//	 fprintf(stdout, "isInterrupted: %d\n\n", R_isInterrupted);
	 terminate = R_isInterrupted;
	 //isInterrupted = 0;

	 if(R_isInterrupted){
	   fprintf(stderr, "exit: %d\n\n", R_isInterrupted);
//	   fprintf(stdout, "exit: %d\n\n", R_isInterrupted);
	   /*
	   int can_read, can_write;
           rjni_shm_io_state(io, &can_read, &can_write);
	   if(can_write){
             int cmd = TR_CLUSTER_INTERRUPT;
             shm_io_write(io, io->out, &cmd, sizeof(int));
	   }
	   if(can_read){
	     size_t size;
             void *ptr = shm_io_read(io, io->in, &size, NULL);
	     free(ptr);
	   }
	   */
#ifdef __INTERRUPT_AS_EXIT__
           exit(1);
#endif
	 }

      }


      PrintValue(ro);

#ifdef USE_SUPR_SERIALIZE
      size_t size;
      //void *raw = SUPR_serialize(ro, R_GlobalEnv, &size);
      so = SO_valueOf(ro, &size);

MALLOC_MARK(__LINE__);

      cmd = TR_SEND_DRIVER;
      shm_io_write(io, io->out, &cmd, sizeof(int));

      {
         void *array = malloc(4*sizeof(int) + size);

	 int *header = (int*) array;
	 header[0] = TASK_RESULTS;
	 header[1] = job_id;
	 header[2] = myid;
//#define SERIALIZED_R_OBJ 100
//#define SO_OBJ 100
	 //header[3] = SO_OBJ; // fixme
	 // try -> return code: 0 success, -1 error
	 header[3] = errorOccurred ?
		 TR_TASK_STATUS_FAILURE : TR_TASK_STATUS_SUCCESS;

	 //memcpy(array+4*sizeof(int), raw, size);
	 memcpy(array+4*sizeof(int), so, size);
	 --so->ref_count;
	 if(so->ref_count == 0) free(so);
	 /*
  int can_read  = tr_cntxt.io->in->data_size > 0;
  int can_write = tr_cntxt.io->out->data_size == 0;
  */
         shm_io_write(io, io->out, array, 4*sizeof(int)+ size);
	 free(array);


         ptr = shm_io_read(io, io->in, &size, NULL);
	 
	 //printf("[%s] Received %ld bytes\n", __func__, size);
	 /*
	 if(size==4){
	   printf("[%s] Received integer %d \n", __func__, ((int*)ptr)[0]);
	 }
	 */
	 // ignore?
	 //{
	 	free(ptr);
	 //}
      }

      //UNPROTECT(3);
      UNPROTECT(R_PPStackTop);

MALLOC_MARK(__LINE__);

#else
///////////////////////////////////////
      SEXP call = PROTECT(LCONS(install("serialize"),
                         CONS(ro, CONS(R_NilValue, R_NilValue))));
      SEXP raw = PROTECT(eval(call, R_GlobalEnv));

      cmd = TR_SEND_DRIVER;
      shm_io_write(io, io->out, &cmd, sizeof(int));
      //shm_io_write(io, io->out, RAW(raw), LENGTH(raw));
      {

#ifdef __TESTING__
         void *array = malloc(4*sizeof(int) +LENGTH(raw)
			 +sizeof(SEXPREC_ALIGN));
#else
         void *array = malloc(4*sizeof(int) + sexp_len + LENGTH(raw)); 
#endif

	 int *header = (int*) array;
	 header[0] = TASK_RESULTS;
	 header[1] = job_id;
	 header[2] = myid;
#define SERIALIZED_R_OBJ 100
	 //header[3] = SERIALIZED_R_OBJ;
	 header[3] = errorOccurred ?
		 TR_TASK_STATUS_FAILURE : TR_TASK_STATUS_SUCCESS;

#ifdef __TESTING__
	 memcpy(array+4*sizeof(int), raw, sizeof(SEXPREC_ALIGN) + LENGTH(raw));
         shm_io_write(io, io->out, array, 4*sizeof(int)+LENGTH(raw)
			 +sizeof(SEXPREC_ALIGN));
#else
	 //memcpy(array+4*sizeof(int), RAW(raw), LENGTH(raw));
         //shm_io_write(io, io->out, array, 4*sizeof(int)+LENGTH(raw));
	 memcpy(array+4*sizeof(int), raw, sexp_len + LENGTH(raw));
         shm_io_write(io, io->out, array, 4*sizeof(int)+ sexp_len + LENGTH(raw));
	 printf("4*sizeof(int)+LENGTH(raw)=%ld\n", 4*sizeof(int)+LENGTH(raw));
#endif

         ptr = shm_io_read(io, io->in, &size, &_shm_name);
	 printf("[%s] Received %ld bytes\n", __func__, size);
	 if(size==4){
	   printf("[%s] Received integer %d \n", __func__, ((int*)ptr)[0]);
	 }
	 // ignore?

#ifdef __TESTING__
	 printf("***** sizeof(SEXPREC_ALIGN) - (RAW(raw) - raw) = %d\n",
	         sizeof(SEXPREC_ALIGN) - ((long)RAW(raw) - (long) raw));
#endif
      }

      tr_state = STATE_RESULT_SEND;

      /*
extern void R_CheckUserInterrupt(void); 
extern int R_interrupts_pending;
extern int R_interrupts_suspended;
*/

//      UNPROTECT(6);
      UNPROTECT(5);
#endif

//      cmd = TR_NEXT_JOB;
//      shm_io_write(io, io->out, &cmd, sizeof(int));

      //fprintf(stderr, "[1] R_interrupts_pending = %d\n", R_interrupts_pending);
      //fprintf(stdout, "[1] R_interrupts_pending = %d\n", R_interrupts_pending);
    } else {
	    TODO();
    }
    //fprintf(stderr, "[2] R_interrupts_pending = %d\n", R_interrupts_pending);
    //fprintf(stdout, "[2] R_interrupts_pending = %d\n", R_interrupts_pending);
MALLOC_MARK(__LINE__);

    if(terminate) // if(isInterrupted)
    {
      fprintf(stderr, "[%s] isInterrupted = %d\n", __func__,
			    R_isInterrupted);
      cmd = TR_EXIT;
      char buf[256];
      memcpy(buf, &cmd, sizeof(int));
      sprintf(buf+sizeof(int), "interrupted");
      shm_io_write(io, io->out, &buf, sizeof(int)+strlen(buf+sizeof(int)));
      Taskrunner_exit(); //break;
    }
//}
  
  //R_Interactive = FALSE;  /* Rf_initialize_R set this based on isatty */
  //if(R_Interactive) run_Rmainloop();

 // Rf_endEmbeddedR(0);

//  return 0;
}

