
#include "supr.h"
#include "util.h"


#include <netinet/tcp.h>


#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)

char *connTypeToStr(int type){
  switch(type){
    case SOCKET_CONN: return "SOCKET";
    case MASTER_CONN: return "MASTER";
    case DRIVER_CONN: return "DRIVER";
    case WORKER_CONN: return "WORKER";
    case USER_CONN:   return "USER";
    case MAIN_USER_CONN:   return "MAIN_USER";
    case INFO_CONN:        return "INFO_CONN";
    case DFS_NAMENODE_CONN: return "NAMENODE";
    case DFS_DATANODE_CONN: return "DATANODE";
    case TASKRUNNER_CONN: return "TASKRUNNER";
    case SOCKET_SERVER: return "SERVER";
    case USER_INFO: return "USER_INFO"; // FIXME
    case WEB_CLIENT_CONN: return "WEB_CLIENT_CONN"; // FIXME
    //case TASKRUNNER_CONN: return "TASKRUNNER";
    case TR_PRINT_STDOUT: return "TASKRUNNER_OUTPUT";

    default: break;
  }
  return "Unknown type";
}

#ifndef _
#define _(x) (x)
#endif



extern void c_backtrace();
extern int Supr_verbose;
extern int SocketConn_reuseAddr;

static void Socket_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));
  c_backtrace();
}

extern supr_socket_conn_t *Supr_findConnection(int fd); 

ssize_t Socket_send(int socket, const void *buffer, size_t length, int flags)
{
//#define FIND_CONNECTION
#ifdef  FIND_CONNECTION
  {
    supr_socket_conn_t *sc = Supr_findConnection(socket);
    if(sc){
      fprintf(stderr, "\tconn[name: %s:%d, type: %s]\n", sc->host, sc->port,
		      connTypeToStr(sc->type));
    } else {
      fprintf(stderr, "\tUnknown connection (fd: %d)\n", socket);
    }
    fflush(stderr);
  }
#endif

  struct sigaction savePipeAct;
  struct sigaction sa;
  sa.sa_sigaction = Socket_SigactionSIGPIPE;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
  sigaction(SIGPIPE, &sa, &savePipeAct);

  signal(SIGPIPE, SIG_IGN);

  ssize_t size = send(socket, buffer, length, flags);

  sigaction(SIGPIPE, &savePipeAct, NULL);

  if(size == -1){
    fprintf(stderr, "Error: send, %s\n", strerror(errno));
    // do long jump ?
  //}
  //{
    supr_socket_conn_t *sc = Supr_findConnection(socket);
    if(sc){
      fprintf(stderr, "\tconn[name: %s:%d, type: %s, fd: %d]\n",
		      sc->host, sc->port, connTypeToStr(sc->type), sc->fd);
    } else {
      fprintf(stderr, "\tUnknown connection (fd: %d)\n", socket);
    }
    fflush(stderr);
  }
  
  return size;
}

#define gettid() ((int)syscall(SYS_gettid))


/*
ssize_t timed_read(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec = (int) Supr_options.timeout;
      tv.tv_usec=0;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
              if(ns == 0) {
                //      errno = EWOULDBLOCK;
                // error_info(strerror(errno));
                error_info("[timeout] gdb -p %d; gdb -p %d", getpid(), gettid());
		return -1;
              } else {
                error_info(strerror(errno));
                return -1;
              }
      }
    }

    ssize_t n = read(fd, buf + len,  size - len);

    if(n <= 0){
      char err[256];
      sprintf(err, "read, n = %ld, %s\n", n, strerror(errno));
      error_info(err);
      return -1;
    }


    len += n;
  }
  return size;
}
*/


/*
int Conn_confirm_send(int sockfd, char *buf, int len){

	  basic_info("pid: %d, login: %s", getpid(), buf);
	  write(sockfd, &len, sizeof(int));
	  write(sockfd, buf, len);
	  int rc;
	  ssize_t size = timed_read(sockfd, &rc, sizeof(int));
	  if(size != sizeof(int) || rc != 0) {
	          basic_info("size: %ld, rc: %d", size, rc);
		  close(sockfd);
		  return -1;
		  //sockfd = -1;
	  }

	  return sockfd;
}
*/


#define CONN_ACCEPTABLE 1

int isAcceptable(supr_conn_t *conn){
  return conn->type & CONN_ACCEPTABLE;
}

// socket

void SocketConn_closeAll(vector_t *conns, int do_shutdown)
{
  basic_info("%s. pid: %d, conss: %p", __func__, getpid(), conns);
  if(conns->mutex)
    pthread_mutex_lock(conns->mutex);
  for(int i=vectorSize(conns)-1; i>=0; i--){
    supr_socket_conn_t *sc = vectorRemove(conns, i);
    int rc;
    if(do_shutdown){
      rc  = shutdown(sc->fd, SHUT_RDWR);
      if(rc == -1) {
        printf("Error in shutdown: %s\n", strerror(errno));
      }
    }

    rc = close(sc->fd);
    if(rc == -1) {
      printf("Error in close: %s\n", strerror(errno));
    }
  }
  if(conns->mutex)
    pthread_mutex_unlock(conns->mutex);
}


#define MAX_PENDING_CONNECTIONS 100
static int T_maxPendingConnections = MAX_PENDING_CONNECTIONS;

#define USE_NONBLOCKING_SOCKET

int __socket_server(int _port, int *port, int reuse_addr)
{
  //printf("%s(port=%d, reuse_addr=%d) \n", __func__, _port, reuse_addr);

  struct sockaddr_in serv_addr;
  int listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if(listenfd == -1) // fixme - don't call errorcall ...
     errorcall(R_NilValue, "[c] socket: %s", strerror(errno));

  if(reuse_addr){
    int val = 1;
    int rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &val, INT_SIZE);
    if(rc == -1)
      printf("warning in setsockopt(%d, ...): %s\n", listenfd, strerror(errno));
  }

#ifdef USE_NONBLOCKING_SOCKET
  { // 10/21/2019 try non-blocking mode
//    print_caller_info(0);
//    print_caller_info(1);
    int flags = fcntl(listenfd, F_GETFL);
    //printf("\033[0;31m%s: %d\033[0m\n", __func__, flags & O_NONBLOCK);
    //printf("\033[0;31m%s: listen_fd = %d\033[0m\n", __func__, listenfd);
    fcntl(listenfd, F_SETFL, O_NONBLOCK);
  }
#endif

  void *ptr = memset(&serv_addr, '0', sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(_port);

  int b = 0;
  int rc;
  while((rc = bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)))
		  ==-1){

	 
	  if(errno == EADDRINUSE && reuse_addr){
            int val = 1;
	    rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &val, INT_SIZE);
	    if(rc == 0) break;
	    printf("error in setsockopt(%d, port=%d, ...): %s\n", listenfd,
			    _port, strerror(errno));
	    fprintf(stderr, "Error in setsockopt(%d, port=%d, ...): %s\n", listenfd,
			    _port, strerror(errno));

	  } 
      b++;
      if(b>100) break;
      serv_addr.sin_port = htons(++_port);
  }

  //printf("[%s] bind: rc = %d\n", __func__, rc);

  if(b>100) {
    c_backtrace();
    errorcall(R_NilValue, "[c] bind: %s", strerror(errno));
  }

  if(listen(listenfd, T_maxPendingConnections)==-1)
      errorcall(R_NilValue, "[c] bind: %s\n", gai_strerror(errno));

//  printf("[%s] listenfd: %d\n", __func__, listenfd);
//  printf("[%s] port: %d\n", __func__, _port);
//  printf("[%s] port: %d\n", __func__, serv_addr.sin_port);

  *port = _port;
  return listenfd;
}


int __socket_server4(int _port, int *port, int reuse_addr, const char *cmd,
		int do_warning)
{
  struct sockaddr_in serv_addr;
  int listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if(listenfd == -1) // fixme - don't call errorcall ...
     errorcall(R_NilValue, "[c] socket: %s", strerror(errno));

  if(reuse_addr){
    int val = 1;
    int rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &val, INT_SIZE);
    if(rc == -1) {
      char buf[1024];
      sprintf(buf, "Warning in setsockopt(%d, ...): %s\n", listenfd, strerror(errno));
      basic_info(buf);
    }
  }

#ifdef USE_NONBLOCKING_SOCKET
  { // 10/21/2019 try non-blocking mode
//    print_caller_info(0);
//    print_caller_info(1);
    int flags = fcntl(listenfd, F_GETFL);
    //printf("\033[0;31m%s: %d\033[0m\n", __func__, flags & O_NONBLOCK);
    //printf("\033[0;31m%s: listen_fd = %d\033[0m\n", __func__, listenfd);
    //fcntl(listenfd, F_SETFL, O_NONBLOCK);
    fcntl(listenfd, F_SETFL, flags | O_NONBLOCK);
  }
#endif

  void *ptr = memset(&serv_addr, '0', sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(_port);

  int rc = bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

  if(rc == -1) {
    //char buf[1024];
    if(do_warning)
      basic_info("Warning in bind(fd=%d, [port=%d, ...]): %s\n", listenfd, _port,
		    strerror(errno));
    //basic_info(buf);
    /*
    if(errno == EADDRINUSE){
      return -1;
    }
    */
    if(listenfd > 0) close(listenfd);
    return -1;
  }

  if(listen(listenfd, T_maxPendingConnections)==-1)
      errorcall(R_NilValue, "[c] bind: %s\n", gai_strerror(errno));

  *port = _port;
  return listenfd;
}


int socket_server4(int _port, int *port, int reuse_addr, const char *cmd,
		int do_warning)
{
  return __socket_server4(_port, port, reuse_addr, cmd, do_warning);
}

int socket_server(int _port, int *port, int reuse_addr)
{
  if(_port)
    return __socket_server(_port, port, reuse_addr);

  static int min_port = 0, max_port = 55535; // 65535; // FIXME

  if(!min_port){
	  //min_port = 1024;
	  min_port = 16384;
	  max_port = 49152; // [16384, 49152)
	  //min_port = 7000;
	  //srandom((unsigned int) 7100);
	  unsigned int seed = geteuid();
	  srandom((unsigned int) seed);
  }

  int fd = -1;

  while(fd < 0){
    long rn = random();
    int this_port = (int) (min_port + rn % (max_port - min_port));
    //printf("[%s] try port: %d\n", __func__, this_port);
    //fd =  __socket_server(this_port, port, reuse_addr);
    fd =  __socket_server(this_port, port, FALSE);
//    if(*port != this_port)
//      printf("Warning: random port %d to %d\n", this_port, *port);
    if(fd < 0) sleep(1);
  }

  return fd;
}

int server_accept(int listenfd, struct sockaddr_in *pclientAddr)
{
//  struct sockaddr_in clientAddr;
  socklen_t addrlen = sizeof(struct sockaddr_in);

//int connfd = accept(listenfd, (struct sockaddr*) &clientAddr, &addrlen);
  int connfd = accept(listenfd, (struct sockaddr*) pclientAddr, &addrlen);

  if(connfd==-1) {
          printf("connfd==-1!\n\tlistenfd=%d\n\t%s\n",
                         listenfd, strerror(errno));
//          print_caller_info(0);
//          print_caller_info(1);
    return connfd;
  } else {
    //printf("\tsin_family = %d (short AF_INET=%d)\n", clientAddr.sin_family,
    //printf("\tsin_family = %d (short AF_INET=%d)\n", pclientAddr->sin_family, AF_INET);
    //printf("\tsin_port = %u (unsigned short)\n", clientAddr.sin_port);
    //printf("\tsin_port = %u (unsigned short)\n", pclientAddr->sin_port);
    //char *ip = inet_ntoa(clientAddr.sin_addr);
    char *ip = inet_ntoa(pclientAddr->sin_addr);
    //printf("\tip in dots-and-numbers format = %s\n", ip);
    char hostname[1024];
    char service[1024];
    //getnameinfo((const struct sockaddr *)&clientAddr,
    getnameinfo((const struct sockaddr *)pclientAddr,
                   sizeof(struct sockaddr_in),
                   hostname, 128,  service, 128, 0);
    //printf("\thostname:  %s\n", hostname);
    //printf("\tservice:   %s\n", service); // e.g., "http"
  }
  return connfd;
}

#define DO_CONN_CHECK
#ifdef DO_CONN_CHECK
static void Conn_check(const char *hostname, int port)
{
   //char *format = "ssh %s 'lsof -i TCP | grep %d >> %s'";

   char template[64];
   sprintf(template, "/tmp/supr_XXXXXX");
   int fd = mkstemp(template);
   FILE *file = fdopen(fd, "w");

   if(strcmp(hostname, Supr_hostname)==0){
     char *format = "lsof -i TCP >> %s";
     char cmd[strlen(format) + strlen(template)+1];
     sprintf(cmd, format, template);
     system(cmd);


   } else {
     char *format = "ssh %s 'lsof -i TCP >> %s'";
     char cmd[strlen(format) + strlen(hostname) + strlen(template)+1];
     sprintf(cmd, format, hostname, template);
     system(cmd);
   }

   char cmd[strlen("cat %s") + strlen(template)+1];
   sprintf(cmd, "cat %s", template);
   system(cmd);
   fclose(file);
   close(fd);
   unlink(template);
}

#endif

extern int Supr_debug;
extern vector_t *socket_connections;
extern char *cmd;
extern char *Cluster_netstat_C(int port, char *args);


int socket_client(const char *hostname, int port_int)
{

	//
	/*
  {
    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    int save_debug = Supr_debug;
    Supr_debug = TRUE;
    if(buf)
      Cluster_sendSimpleMessage(buf, "\033[0;31m", DEBUG_INFO_TYPE, 0);
      //fprintf(stderr,"[%s%d%s:%s]\n%s\n", buf);

    Supr_debug = save_debug;
    free(buf);
    fprintf(stderr, "vectorSize(socket_connections): %d, tid: %ld\n", 
		    vectorSize(socket_connections), syscall(SYS_gettid));
    {
	    char buf[256];
            sprintf(buf, "vectorSize(socket_connections): %d, tid: %ld\n", 
		    vectorSize(socket_connections), syscall(SYS_gettid));
            Cluster_sendSimpleMessage(buf, "\033[0;31m", 0, 0);

    }
  }
  */
  //

  char port[8];
  sprintf(port, "%d",  port_int);

  struct addrinfo hints;
  struct addrinfo *result, *rp;

  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_INET;    /* Allow IPv4 or IPv6 */
  hints.ai_socktype = SOCK_STREAM; /* Datagram socket */
  hints.ai_flags = AI_PASSIVE;    /* For wildcard IP address */
  hints.ai_protocol = 0;

  int s = getaddrinfo(hostname, port, &hints, &result);
  if(s!=0) {
      char msg[1024];
      sprintf(msg, "Error: %s", strerror(errno));
      basic_info(msg);
      return -1;
  }

  int sockfd = 0;
  for (rp = result; rp != NULL; rp = rp->ai_next) {
    sockfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
    if (sockfd  == -1) {
      char msg[1024];
      sprintf(msg, "Warning: socket, %s", strerror(errno));
      basic_info(msg);
#ifdef DO_CONN_CHECK
      Conn_check(hostname, port_int);
#endif
      continue;
    }
    if (connect(sockfd, rp->ai_addr, rp->ai_addrlen) != -1)
	    break;
    /*
    else {
      char msg[1024];
      sprintf(msg, "errno: %d, error: %s", errno, strerror(errno));
      basic_info(msg);
    }
    */

    close(sockfd);
  }

  if(rp == NULL) {
    error_info("connect('%s:%d'), %s", hostname, port_int, strerror(errno));
    
    if(errno == ECONNREFUSED && strcmp(hostname, Supr_hostname)==0){
      char *netstat = Cluster_netstat_C(port_int, NULL);
      if(strstr(netstat, "LISTEN"))
        error_info("too many pendding connections? Check with netstat:");
      else 
        error_info("no server is available. Check with netstat:");
      error_info(netstat);
      free(netstat);
    } 
    return -1;
  }

  /*
   * When connect() hangs it is usually because you connect to an address that is behind a firewall and the firewall just drops your packets with no response. It keeps trying to connect for around 2 minutes on Linux and then times out and return an error.
   */

  /*
  {// testing
             int flags =1;
             int rc = setsockopt(sockfd, SOL_TCP, TCP_NODELAY,
                      (void *)&flags, sizeof(flags));
             if(rc == -1) perror("setsockopt");
  }
  */

  /*
  {
    pid_t tid = syscall(SYS_gettid);
    int cmd = SET_CONN_PID;
    write(sockfd, &cmd, sizeof(int));
    write(sockfd, &tid, sizeof(int));
    int type = -1;
    write(sockfd, &type, sizeof(int));
    //int rc; read(sockfd, &rc, sizeof(int));
//    if(cmd && strcmp(cmd, "driver")==0 && vectorSize(socket_connections)==4)
  }
  */

  /*
  if(sockfd != -1 && Supr_login){
    basic_info("pid: %d, host: %s, cmd: %s", getpid(), Supr_hostname, proc_cmd);
    sockfd = Conn_confirm_send(sockfd, Supr_login, strlen(Supr_login)+1);
    if(sockfd == -1){
      basic_info("Socket connection security violation:\n\tlogin: %s@%s -> %s:%d",
		      Supr_login, Supr_hostname, hostname, port_int);
    }
  }
  */

  return sockfd;
}

/*
typedef struct socket_conn_struct {
  int fd;
  int endian;
  int native_endian;
} socket_conn_t;
*/


#define null R_NilValue
//#define SOCKET_CONN 2




void socketConnectionPrint(supr_socket_conn_t *sc)
{
  int flags = fcntl(sc->fd, F_GETFL);
  printf("\033[0;37m[%s] [type: %s, fd: %d, port: %d, blocking=%d, host: %s]\033[0m\n",
		  __func__, connTypeToStr(sc->type),
		  sc->fd, sc->port, ! ((flags & O_NONBLOCK) > 0),
		  sc->host);
}

char *SocketConn_addr(supr_socket_conn_t *sc)
{
  size_t len = strlen(sc->host);
  char buf[len + 128];
  sprintf(buf, "//%s:%d", sc->host, sc->port);
  return strdup(buf);
}

static const char *socketConnToChar(class_t *class, void *object)
{
  supr_socket_conn_t *sc = (supr_socket_conn_t *) object;
  int flags = fcntl(sc->fd, F_GETFL);
  char buf[256];
  sprintf(buf,
  "\033[0;37m[%s] [type: %s, fd: %d, port: %d, blocking=%d, host: %s]\033[0m\n",
		  __func__, connTypeToStr(sc->type),
		  sc->fd, sc->port, ! ((flags & O_NONBLOCK) > 0), sc->host);
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(256);
  // reset
  sb->size = 0;
  sb->buf[0] = 0;
  strbufPutStr(sb, buf);
  return sb->buf;
}


static void socketConnFinalize(class_t *class, void *object)
{
  supr_socket_conn_t *sc = (supr_socket_conn_t *) object;
  if(Supr_options.verbose)
    fprintf(stderr, "\033[0;36m[%s]\033[0m host: %s, type: %s, fd: %d, cmd: %s\n",
    __func__, sc->host, // sc->port,
    connTypeToStr(sc->type), sc->fd, sc->cmd);
  close(sc->fd);
  free((char*)sc->host);
  if(sc->mutex){
    pthread_mutex_destroy(sc->mutex);
    free(sc->mutex);
  }
  free(sc);
}

/*
static class_t *SocketConn_class()
{
  static class_t *class = NULL;
  if(!class) class = newClass("SocketConn",
		  socketConnToChar,
		  socketConnFinalize);
  return class;
}
*/

static class_t __SocketConn_class = {"SocketConn", socketConnToChar,
       			socketConnFinalize};

class_t *SocketConn_class = &__SocketConn_class;

supr_socket_conn_t *newSocketConnection(int fd, int port, int isServer,
		const char *host)
{
//  if(!SocketConn_class) SocketConn_class = newClass("SocketConn", socketConnToChar, socketConnFinalize);
  //conn->class = SocketConn_class();
  if(fd == -1) {
    char msg[1024];
    sprintf(msg,"\033[0;31m[%s] FIXME: %s:%d\033[0m\n", __func__, __FILE__, __LINE__);
    basic_info(msg);
    return NULL;
    //exit(1);
  }

  supr_socket_conn_t *conn = malloc(sizeof(supr_socket_conn_t));
  conn->class = SocketConn_class;
  conn->ref_count = REF_COUNT_INITIALIZER;
  conn->fd = fd;
  conn->type = SOCKET_CONN;
  conn->port = port;
  conn->print = socketConnectionPrint;
  conn->host = _dupstr(host);
  conn->mutex = NULL;
  conn->cmd = NULL;
  conn->att = NULL;
  conn->pid = 0;
  conn->tid = 0;
  conn->to = NULL;
  return conn;
}


supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr)
{
  int server_port = -1; 
  int serverfd = socket_server(port, &server_port, reuse_addr);

  if(serverfd == -1) // fixme
    errorcall(null, "[%s] %s", __func__, strerror(errno));

  //printf("%s: port: %d, fd: %d\n", __func__, server_port, serverfd); 

  char buf[256];
  gethostname(buf, sizeof(buf));
  supr_socket_conn_t *s = newSocketConnection(serverfd, server_port, TRUE, buf);
  s->type = SOCKET_SERVER;
  return s;
}

// CLOSE_WAIT works for reuser ... but not TIMEWAIT
supr_socket_conn_t *__serverSocketOpen3(int port, int reuse_addr, const char *cmd, int do_warning)
{
  int server_port = -1; 
  int serverfd = socket_server4(port, &server_port, reuse_addr, cmd, do_warning);

  if(serverfd == -1) // fixme
	  return NULL;
    //errorcall(null, "[%s] %s", __func__, strerror(errno));

  //printf("%s: port: %d, fd: %d\n", __func__, server_port, serverfd); 

  char buf[256];
  gethostname(buf, sizeof(buf));
  supr_socket_conn_t *s = newSocketConnection(serverfd, server_port, TRUE, buf);
  s->type = SOCKET_SERVER;
  return s;
}


extern char **TrustedHosts;
extern int   nTrustedHosts;
static int host_strcmp(const void *a, const void *b)
{
//	fprintf(stderr, "a: %p (%s)\n",  a, *((char * const *) a)); 
//	fprintf(stderr, "b: %p (%s)\n",  b, *((char * const *) b)); 
  return strcmp(*((char * const *) a), *((char * const *) b));
}


supr_socket_conn_t *serverSocketAccept(supr_conn_t *serverConn)
{
  int serverfd = serverConn->fd;

  socklen_t addrlen = sizeof(struct sockaddr_in);

  struct sockaddr_in clientAddr;
  struct sockaddr_in *pclientAddr = &clientAddr;

  int clientfd = accept(serverfd, (struct sockaddr*) pclientAddr, &addrlen);

  //printf("clientfd = %d\n", clientfd); 
  if(clientfd == -1) {
	  perror(strerror(errno));
	  return NULL;
  }

  /*
  if(Supr_login){ // verify...
     int len;
	basic_info("%s 003", __func__);
     read(clientfd, &len, sizeof(int));
     char buf[len];
     read(clientfd, buf, len);
	basic_info("%s len: %d, buf: %s, login: %s", __func__, len, buf, Supr_login);
     int rc = 0;
     if(strcmp(buf, Supr_login)){
     	  error_info("%s: wrong login/username %s", __func__, buf);
          rc = -1;
	  write(clientfd, &rc, sizeof(int));
	  return NULL;
     } else {
       write(clientfd, &rc, sizeof(int));
     }
	basic_info("%s 008", __func__);
  }
  */

  char hostname[1024];
  char service[1024];
  getnameinfo((const struct sockaddr *) &clientAddr,
                   sizeof(struct sockaddr_in),
                   hostname, 128,  service, 128, 0);

  if(strcmp(hostname, "localhost")==0) {
    int len = gethostname(hostname, 1024);
  }

/*
#include <netinet/in.h>

struct sockaddr_in {
    short            sin_family;   // e.g. AF_INET
    unsigned short   sin_port;     // e.g. htons(3490)
    struct in_addr   sin_addr;     // see struct in_addr, below
    char             sin_zero[8];  // zero this if you want to
};

struct in_addr {
    unsigned long s_addr;  // load with inet_aton()
};

Example:
struct sockaddr_in myaddr;
int s;

myaddr.sin_family = AF_INET;
myaddr.sin_port = htons(3490);
inet_aton("63.161.169.137", &myaddr.sin_addr.s_addr);

s = socket(PF_INET, SOCK_STREAM, 0);
bind(s, (struct sockaddr*)myaddr, sizeof(myaddr));
*/
  /*
  { // IP/ip address:
    struct in_addr ipAddr = pclientAddr->sin_addr;
    char str[INET_ADDRSTRLEN];
    inet_ntop( AF_INET, &ipAddr, str, INET_ADDRSTRLEN );
    fprintf(stderr, "\033[0;35m[%s:%d] %s: str: %s\n\033[0m",
		    __FILE__, __LINE__, __func__, str);
  }
  */

  //return newSocketConnection(clientfd, -1, FALSE, hostname); // 

  supr_socket_conn_t *sc = newSocketConnection(clientfd, -2, FALSE, hostname);

  // add ip info
  memcpy(&sc->sin_addr, &pclientAddr->sin_addr, sizeof(struct in_addr));

  if(Supr_verbose) { // IP/ip address:
 //   struct in_addr ipAddr = pclientAddr->sin_addr;
    char str[INET_ADDRSTRLEN];
  //  inet_ntop( AF_INET, &ipAddr, str, INET_ADDRSTRLEN );
    inet_ntop( AF_INET, &sc->sin_addr, str, INET_ADDRSTRLEN );
//    fprintf(stderr, "\033[0;35m[%s:%d] %s: str: %s\n\033[0m", __FILE__, __LINE__, __func__, str);
    unsigned char *ip = (unsigned char *) &sc->sin_addr;
    fprintf(stderr, "\033[0;35m[%s:%d:%s] IP by unsigned char: %d.%d.%d.%d\n\033[0m",
                    __FILE__, __LINE__, __func__, ip[0], ip[1], ip[2], ip[3]);
  }

  if(TrustedHosts && ! bsearch(&sc->host, TrustedHosts, nTrustedHosts,
			  sizeof(char*), host_strcmp)){
    close(sc->fd); // FIXME
    free(sc);
    error_info("\033[0;35m refused conntection from %s, check TrustedHosts\033[0m",
                    sc->host);
    sc = NULL;
  } 

  if(sc)
    sc->client_port = ntohs(clientAddr.sin_port);


  return sc;

}

supr_socket_conn_t *socketOpen(supr_socket_conn_t *serverConn)
{
  int sc_fd = socket_client(serverConn->host, serverConn->port);
  if(sc_fd == -1){
    char msg[1024];
    sprintf(msg, "Error in %s, %s", __func__, strerror(errno));
    Cluster_sendSimpleMessage(msg, "\033[0;31m", ERROR_INFO_TYPE, 0);
  }
  //return newSocketConnection(sc_fd, -1, FALSE, serverConn->host);
  return newSocketConnection(sc_fd, serverConn->port, FALSE, serverConn->host);
}

/*
extern int DFLT_SO_RCVBUF;
extern int DFLT_SO_SNDBUF;
extern int DFLT_NONBLOCK;
*/



supr_socket_conn_t *socketOpen2(const char *host, int port)
{
  int sc_fd = socket_client(host, port);
  //printf("[%s] fd:  %d, host: %s, port: %d\n", __func__, sc_fd, host, port);

  if(sc_fd == -1) return NULL;

  //if(Supr_options.debugs)
  /*
  if(DFLT_SO_RCVBUF == 0) {
    int size_rcv, size_snd, len = sizeof(int);
    int rc = getsockopt(sc_fd, SOL_SOCKET, SO_RCVBUF, &size_rcv, &len);
    rc = getsockopt(sc_fd, SOL_SOCKET, SO_SNDBUF, &size_snd, &len);
    {
      int KEEPALIVE = TRUE;
      rc = setsockopt(sc_fd, SOL_SOCKET, SO_KEEPALIVE, &KEEPALIVE, &len);
    }
    int KEEPALIVE;
    rc = getsockopt(sc_fd, SOL_SOCKET, SO_KEEPALIVE, &KEEPALIVE, &len);

    char buf[256];
    int flags = fcntl(sc_fd, F_GETFL);
    if(flags == -1) 
      sprintf(buf, "SO_RCVBUF: %d, SO_SNDBUF: %d, Error: %s",
		      size_rcv, size_snd, strerror(errno));
    else
      sprintf(buf, "SO_RCVBUF: %d, SO_SNDBUF: %d, %s, KEEPALIVE: %d", size_rcv, size_snd,
		      flags & O_NONBLOCK ? "NONBLOCK": "BLOCK", KEEPALIVE);
    basic_info(buf);
    DFLT_SO_RCVBUF = size_rcv;
    DFLT_SO_SNDBUF = size_snd;
    DFLT_NONBLOCK  = flags & O_NONBLOCK;
  }
  */
  
  //return newSocketConnection(sc_fd, -1, FALSE, host);
  return newSocketConnection(sc_fd, port, FALSE, host);
}

void socketDestroy(supr_socket_conn_t *sc)
{ // FIXME
  close(sc->fd);
  free(sc);
}


/*
size_t socketWrite(supr_socket_conn_t *sc, void *buf, size_t buf_size)
{
}
*/

/*
#define THREAD_STATE_NEW 0
typedef struct supr_thread_struct {
  pthread_t ptid;
  pid_t pid;
  pid_t tid;
  int state;
  sem_t sem;
} supr_thread_t;
*/

//extern supr_thread_t *newThread(pthread_t ptid, pid_t pid, pid_t tid, int state)
	;
/*
supr_thread_t *newThread(pthread_t ptid, pid_t pid, pid_t tid, int state)
{
  supr_thread_t *th = malloc(sizeof(supr_thread_t));
  th->ptid  = ptid;
  th->pid   = pid;
  th->tid   = tid;
  th->state = state;

  pthread_mutex_init(&th->mutex, NULL);
  pthread_cond_init(&th->cond, NULL);

  return th;
}
*/

void thread_destructor(void *data)
{
}

void *shmMonitorRun(void *arg)
{
  void *data = (void*) ((void **)arg)[0]; 
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1]; 
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2]; 

  supr_thread_t *th = newThread(pthread_self(), getpid(),
		  syscall(SYS_gettid), THREAD_STATE_NEW,(unsigned long) &data);
  *sth = th;

  pthread_key_t th_key;
  pthread_key_create(&th_key, thread_destructor);
  pthread_setspecific(th_key, th);


  supr_socket_conn_t *serverConn = (supr_socket_conn_t *) data;
  data += sizeof(supr_conn_t *);
  char *shm_name = (char*) data;
  printf("[%s] shm_name = \"%s\"\n", __func__, shm_name);

  supr_socket_conn_t *sock_conn = socketOpen(serverConn);


  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  pthread_exit(th);
  return NULL;
}

supr_thread_t *newShmMonitor(void *data)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth;
  void *arg[] = {data, &sem, &sth};
  int rc = pthread_create(&thread, NULL, shmMonitorRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  if(rc == -1)
    errorcall(null,"[%s] %s", __func__, strerror(errno));

  return sth;
}

int __simple_socket_server(int _port, int *listenfd_addr, int reuse_addr)
{
  struct sockaddr_in serv_addr;
  int listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if(listenfd == -1) // fixme - don't call errorcall ...
     fprintf(stderr, "[c] socket: %s\n", strerror(errno));
     //errorcall(R_NilValue, "[c] socket: %s", strerror(errno));

  fprintf(stderr, "listenfd: %d\n", listenfd);

  if(reuse_addr){
    int val = 1;
    int rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &val, INT_SIZE);
    if(rc == -1)
      printf("warning in setsockopt(%d, ...): %s\n", listenfd, strerror(errno));
  }

#ifdef USE_NONBLOCKING_SOCKET
  { 
    int flags = fcntl(listenfd, F_GETFL);
    fcntl(listenfd, F_SETFL, O_NONBLOCK);
  }
#endif

  void *ptr = memset(&serv_addr, '0', sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(_port);

  int rc = bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

  if(rc == 0)
    *listenfd_addr = listenfd;
  else {
	  if(listenfd >0 ) close(listenfd);
    *listenfd_addr = -1;
  }

  return rc;
}


/*
supr_socket_conn_t *serverSocketOpen3(int port, int nports, const char *cmd)
{
  supr_socket_conn_t *sc = __serverSocketOpen3(port, FALSE, cmd);
  if(sc){
    fprintf(stderr, "%s, port: %d, sc->port: %d\n", __func__, port, sc->port);
    if(port == sc->port) 
	    return sc;
    else {
      fprintf(stderr, "%s, FIXME port: %d, sc->port: %d\n", __func__, port, sc->port);
      exit(1); // shouldn't happen
    }
  }

  fprintf(stderr, "%s, sc: %p, err: %s\n", __func__, sc, strerror(errno));

  if(reuse_addr){
    errno = 0;
    sc = __serverSocketOpen3(port, TRUE, cmd);
    if(!sc) {
      fprintf(stderr, "Error in %s(%d, TRUE, %s), %s\n",
		     __func__, port, cmd, strerror(errno));
      return NULL;
    }
    while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
    char msg[1024];
    sprintf(msg, "%s: Check and kill servers on port %d...", __func__, port);
    Cluster_sendSimpleMessage(msg, "\033[0;33m", DEFAULT_INFO_TYPE, 0);

    vector_t *killed_cmds = newVector(FALSE);

    //Supr_killSocketServer(cmd, port, killed_cmds);
    Supr_killSocketServer2(port, killed_cmds);

    for(int i=vectorSize(killed_cmds)-1; i>=0; i--) {
      char *s = (char*) vectorRemove(killed_cmds, i);
//      fprintf(stderr, "[%d] [%s:%d] %s: %s, pid: %d\n", i+1, __FILE__, __LINE__,  __func__, s, getpid());
      char buf[1024];
      sprintf(buf, "[%d] %s:", i, __func__);
      Cluster_sendSimpleMessage(buf, "\033[0;33m", DEFAULT_INFO_TYPE, 0);
      Cluster_sendSimpleMessage(s, "\033[0;33m", DEFAULT_INFO_TYPE, 0);
      free(s);
    }

    vectorDestroy(killed_cmds);
  
  } else { // find next free port

    port++; if(port < 1024) port = 1024;
    for(;port < 65354; port++){
       sc = __serverSocketOpen3(port, FALSE, cmd);
       if(sc)  {
         fprintf(stderr, "%s, %s:%d:%d\n",__func__,sc->host, sc->port, sc->fd);
	 break;
       } else {
         fprintf(stderr, "Warning in %s (%d, FALSE, %s), %s\n", __func__,
			port, cmd, strerror(errno));
       }
    }

  }

  return sc;
 
}
*/

supr_socket_conn_t *serverSocketOpen3(int port, int nports, const char *cmd)
{
  supr_socket_conn_t *sc = NULL;
  if(nports == 1){

    errno = 0;
    sc = __serverSocketOpen3(port, SocketConn_reuseAddr, cmd, TRUE);
    /*
    if(sc) return sc;

    if(!sc) {
      fprintf(stderr, "Error in %s(%d, %d, %s), %s\n",
		     __func__, port, nports, cmd, strerror(errno));
      return NULL;
    }
    while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
    char msg[1024];
    sprintf(msg, "%s: Check and kill servers on port %d...", __func__, port);
    Cluster_sendSimpleMessage(msg, "\033[0;33m", DEFAULT_INFO_TYPE, 0);

    vector_t *killed_cmds = newVector(FALSE);

    //Supr_killSocketServer(cmd, port, killed_cmds);
    Supr_killSocketServer2(port, killed_cmds);

    for(int i=vectorSize(killed_cmds)-1; i>=0; i--) {
      char *s = (char*) vectorRemove(killed_cmds, i);
//      fprintf(stderr, "[%d] [%s:%d] %s: %s, pid: %d\n", i+1, __FILE__, __LINE__,  __func__, s, getpid());
      char buf[1024];
      sprintf(buf, "[%d] %s:", i, __func__);
      Cluster_sendSimpleMessage(buf, "\033[0;33m", DEFAULT_INFO_TYPE, 0);
      Cluster_sendSimpleMessage(s, "\033[0;33m", DEFAULT_INFO_TYPE, 0);
      free(s);
    }

    vectorDestroy(killed_cmds);
    */
  
  } else { // find next free port
    //port++; if(port < 1024) port = 1024;
    if(port < 1024) port = 1024;
    int max_port = nports == 0 ? 65354 : (port+nports);
    for(;port < max_port; port++){
       sc = __serverSocketOpen3(port, SocketConn_reuseAddr, cmd, FALSE);
       if(sc)  break;
       //else  fprintf(stderr, "Warning in %s (%d, FALSE, %s), %s\n", __func__, port, cmd, strerror(errno));
    }
  }

  return sc;
 
}




ssize_t Socket_available(supr_socket_conn_t *sc){
  int fd = sc->fd;
  struct timeval tv;
  fd_set readfds, writefds;

      tv.tv_sec= Supr_options.timeout;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0) {
        //socketDestroy(sc);
        return 0;
      }

      unsigned char buf[4096];
      return recv(fd, buf, sizeof(buf), MSG_PEEK | MSG_DONTWAIT);
}

supr_socket_conn_t *trySocketOpen2(const char *hostname, int port){
  supr_socket_conn_t *sc = socketOpen2(hostname, port);
  if(!sc) return NULL;

  char msg[1024];
  int fd = sc->fd;
  struct timeval tv;
  fd_set readfds, writefds;

  { // writable?
//      fd_set readfds, writefds;

      tv.tv_sec=5;
      tv.tv_usec=50000;

      FD_ZERO(&writefds);
      FD_SET(fd, &writefds);

      int ns = select(fd+1, NULL, &writefds, NULL, &tv);
      if(ns <= 0) {
          
	if(ns == -1){
	  sprintf(msg, "Error: %s", strerror(errno));
	  basic_info(msg);
	}
        socketDestroy(sc);
	return NULL;
      }
  }
  int cmd = CLUSTER_PING;
  int rc = write(fd, &cmd, sizeof(int));
  if(rc == -1){
	  sprintf(msg, "Error: %s", strerror(errno));
	  basic_info(msg);
	  close(fd);
	  free(sc); // FIXME
	  return NULL;
  }
  { // readable?
      tv.tv_sec=5;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0) {
	if(ns == -1){
	  sprintf(msg, "Error: %s", strerror(errno));
	  basic_info(msg);
	} else {
	  sprintf(msg, "Warning: wait to read TIMEDOUT");
	  basic_info(msg);
	}
        socketDestroy(sc);
	return NULL;
      }
  }

  rc = read(fd, &cmd, sizeof(int));
  if(rc == -1 || cmd != CLUSTER_PONG){
	  sprintf(msg, "Error: %s", strerror(errno));
	  basic_info(msg);
	  close(fd);
	  free(sc); // FIXME
	  return NULL;
  }
  return sc;
}

supr_socket_conn_t *trySocketOpen1(const char *address){
  char *host = strdup(address);
  char *s = strstr(host, ":");
  if(!s) {
	  free(host); 
	  return NULL;
  }
  *s = 0; s++;
  char *h = strstr(host, "//")? strstr(host, "//")+2 :  host;

  supr_socket_conn_t *sc = trySocketOpen2(h, atoi(s));
  free(host);
  return sc;
}


int tryPingSocketServer2(const char *hostname, int port){
  supr_socket_conn_t *sc = socketOpen2(hostname, port);
  if(!sc) return -1;

  int fd = sc->fd;
  struct timeval tv;
  fd_set readfds, writefds;

  { // writable?
      fd_set readfds, writefds;

      tv.tv_sec=5;
      tv.tv_usec=50000;

      FD_ZERO(&writefds);
      FD_SET(fd, &writefds);

      int ns = select(fd+1, NULL, &writefds, NULL, &tv);
      if(ns <= 0) {
        socketDestroy(sc);
	return -2;
      }

      int cmd = CLUSTER_PING;
      write(fd, &cmd, sizeof(int));
  }

//  { // readable?
      tv.tv_sec=5;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0) {
        socketDestroy(sc);
	errno = ETIMEDOUT;
	return -3;
      }

      int cmd;
      read(fd, &cmd, sizeof(int));
      socketDestroy(sc);


      return cmd;
  //}
}

int tryPingSocketServer1(const char *address){
  char *host = strdup(address);
  char *s = strstr(host, ":");
  if(!s) {
	  free(host); return -4;
  }
  *s = 0; s++;
  char *h = strstr(host, "//")? strstr(host, "//")+2 :  host;

  int rc = tryPingSocketServer2(h, atoi(s));
  free(host);
  return rc;
}

supr_socket_conn_t *socketOpen1(const char *address){
  char *host = strdup(address);
  char *s = strstr(host, ":");
  if(!s) {
	  free(host); return NULL;
  }
  *s = 0; s++;
  int port = atoi(s);
  char *h = strstr(host, "//")? strstr(host, "//")+2 :  host;
  supr_socket_conn_t *sc = socketOpen2(h, port);
  free(host);
  if(sc) sc->port = port;
  return sc;
}

int nextFreePort(int port)
{
  port++;
  while(TRUE){
    int fd = socket_client("localhost", port);
    if(fd == -1) return port;
    close(fd);
    port++;
    if(port < 1024 || port >65535) return -1;
  }
}

