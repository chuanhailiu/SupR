
#include <pthread.h>

#ifndef __UTIL_H__ 
#define __UTIL_H__ 

/*
typedef struct list_node_struct {
  struct list_node_struct *next;
  void *data;
} list_node_t;

typedef struct list_struct {
  
} list_t;
*/

/*
typedef struct class_struct {
  char *toString(void *data);
} class_t;
*/

typedef struct vector_struct {
  class_t *class;
  int ref_count;
  int padding;
  pthread_mutex_t *mutex;
  int size;
  int buf_size;
  void **elements;
  void (*free_data)(void *);
//  void *prev_allocated_elements; // debug
} vector_t;


typedef struct iterator_struct {
  class_t *class;
  int ref_count;
  int padding;
  int (*hasNext)(void *data);
  void *(*next)(void *data);
  void *(*next2)(void *data, void *pref);
  void *data;
} iterator_t;


typedef struct hashnode_struct {
  char *key;
  void *data;
  struct hashnode_struct *next;
} __HashNode,  *HashNode;

//typedef int uint32_t;
typedef __uint32_t uint32_t;


typedef struct {
  class_t *class;
  int ref_count;
  int padding;

  pthread_mutex_t *mutex;
  void (*free_data)(void *); // free node->data

//  size_t (*fn)(char *); // hash function
  uint32_t (*fn)(const char *);
//  void *privateDFS; // 05/31/2016
  HashNode lookup[];

} hashtable_t, *HashTable; //__HashTable,  *HashTable;




typedef struct {
  class_t *class;
  int ref_count;
  int padding;
  pid_t pid;
  pid_t ppid;
  char *pts;
  int fd0;
  int fd1;
  int fd2;
  char *shm_name;
  size_t segment_size;
  void *mem_ptr;
} supr_xterm_t; // xterm_info

#define hashtablePut hashtable_set
#define hashtableGet hashtable_find
#define hashtableDelete hashtable_delete
#define hashtableKeySet hashtable_keys
#define hashtableDestroy hashtable_destroy
#define hashtableSize hashtable_size

//typedef struct string_struct { } string_t;


#ifdef __UTIL_MAIN__
#define util_extern
#else
#define util_extern extern
#endif

util_extern int vscprintf(supr_socket_conn_t *sc, const char *format, ...);

util_extern void *Supr_shm_create(const char *shm_name, ssize_t size);
util_extern void *Supr_shm_open(const char *shm_name, ssize_t *size);

//util_extern void SUPR_setSignalHandler();

util_extern int Supr_crc32(char *buf, int size, uint32_t *cval, off_t *clen);


//util_extern string_t *String_new(const char *format, ...);
util_extern int wrapped_strcmp(const void *a, const void *b);
util_extern char *__mk_tmpnam__(const char *prefix, const char *suffix); 
util_extern char *__supr_strdup__(const char *p, const char *, const char *,
	       	int);

//util_extern void (*__hashtable_data_free)(void *);
util_extern int SuprNode_create(const char *name, char **argv,
	       	int use_tty, double timeout, void **retval);



#ifdef __UTIL_MAIN__
vector_t *newVector(int sync);
void *vectorAdd(vector_t *vec, void *elem);
void *vectorAddElementAt(vector_t *vec, int idx, void *elem);
void *vectorAddIfNotExists(vector_t *vec, void *elem,
	       	int (*cmp)(const void *, const void*));
void *vectorElementAt(vector_t *vec, int i);
void *vectorRemove(vector_t *vec, int i);
void *vectorSet(vector_t *vec, int i, void *elem);
void *vectorRemoveElement(vector_t *vec, void *elem);
int vectorSize(vector_t *vec);
int vectorDestroy(vector_t *vec);

uint32_t defaultFnBJ (const char *key);
HashTable create_hashtable(uint32_t (*fn)(const char *));
void hashtable_destroy(HashTable tbl);
int hashtable_set(HashTable tbl, const char *key, void *data);
int hashtable_delete(HashTable tbl, char *key);
void *hashtable_find (HashTable tbl, const char *key);
//static void hashtable_debug (HashTable tbl, char *desc);
char **hashtable_keys (HashTable tbl, int *size);
int hashtable_size (HashTable tbl);

hashtable_t *newHashtable(int sync);

iterator_t *newIterator(int (*hasNext)(void *), void *(*next)(void *), void *);
int iteratorHasNext(iterator_t *);
void *iteratorNext(iterator_t *);

supr_xterm_t *supr_xterm2(const char *name, char **argv);

int File_remove(const char *);

void *__supr_malloc__(size_t size, const char* func, const char *file,
	       	int line);
void *__supr_realloc__(void *ptr, size_t size, const char *func,
	       	const char *file, int line);
void __supr_free__(void *p, const char *func, const char *file, int line);
void __supr_malloc_init__();
void __supr_malloc_print__();
#else

extern vector_t *newVector(int sync);
extern void *vectorAdd(vector_t *vec, void *elem);
extern void *vectorAddElementAt(vector_t *vec, int idx, void *elem);
extern void *vectorAddIfNotExists(vector_t *vec, void *elem,
	       	int (*cmp)(const void *, const void*));
extern void *vectorElementAt(vector_t *vec, int i);
extern void *vectorRemove(vector_t *vec, int i);
extern void *vectorSet(vector_t *vec, int i, void *elem);
extern void *vectorRemoveElement(vector_t *vec, void *elem);
extern int vectorSize(vector_t *vec);
extern int vectorDestroy(vector_t *vec);

extern uint32_t defaultFnBJ (const char *key);
extern HashTable create_hashtable(uint32_t (*fn)(const char *));
extern void hashtable_destroy(HashTable tbl);
extern int hashtable_set(HashTable tbl, const char *key, void *data);
extern int hashtable_delete(HashTable tbl, char *key);
extern void *hashtable_find (HashTable tbl, const char *key);
//static void hashtable_debug (HashTable tbl, char *desc);
//char **hashtable_keys (HashTable tbl, int *size);
extern char **hashtable_keys (HashTable tbl, int *size);
extern int hashtable_size (HashTable tbl);

extern hashtable_t *newHashtable(int sync);

extern iterator_t *newIterator(int (*hasNext)(void *), void *(*next)(void *),
	       	void *);
extern int iteratorHasNext(iterator_t *);
extern void *iteratorNext(iterator_t *);

extern supr_xterm_t *supr_xterm2(const char *name, char **argv);

extern int File_remove(const char *);
extern void *__supr_malloc__(size_t size, const char *func,
	       	const char *file, int line);
extern void *__supr_realloc__(void *p, size_t size, const char *func,
	       	const char *file, int line);
extern void __supr_free__(void *p, const char *func, const char *file, int line);
extern void __supr_malloc_init__();
extern void __supr_malloc_print__();
#endif

#endif
