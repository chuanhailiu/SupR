
#include "supr.h"

#define __UTIL_MAIN__
#include "util.h"

#include <sys/types.h>
#include <sys/wait.h>


#define VECTOR_INITIAL_BUFFER_SIZE 8


#define _GNU_SOURCE
#define __USE_GNU
#include <dlfcn.h>

#define print_caller_info(which)        \
do {    \
   Dl_info __info__;    \
   int __rc__ = dladdr(__builtin_return_address(which), &__info__);     \
   if(__rc__) 	\
   	fprintf(stderr, "\033[0;32m[%d] fun: %s (%s:%d)\033[0m\n", getpid(), __info__.dli_sname, __FILE__, __LINE__);      \
} while (0)


extern SEXP SuprJobEnv;
extern void addCleanups(void (*)(void *), void*);
void shm_cleanup(void *data);

int vscprintf(supr_socket_conn_t *sc, const char *format, ...)
{
    if(!sc) return -1;
    va_list ap;
    va_start(ap, format);
    return vdprintf(sc->fd, format, ap);
}

void *Supr_shm_create(const char *shm_name, ssize_t size){

  errno = 0;
  int fd = shm_open(shm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  if(fd == -1){
        shm_unlink(shm_name);
	return NULL;
  }

//  addCleanups(shm_cleanup, strdup(shm_name));

  size_t segment_size = size == 0 ?  sysconf(_SC_PAGE_SIZE) : size;
  int rc = ftruncate(fd, segment_size);
  if(rc != 0) return NULL;

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) return NULL;
  close(fd);
  return mem_ptr;
}

void *Supr_shm_open(const char *shm_name, ssize_t *size){
    int fd = shm_open(shm_name, O_RDWR, 0600);
    if(fd == -1){
        shm_unlink(shm_name);
        return NULL;
    }

    struct stat statbuf;
    int rc = fstat(fd, &statbuf);
    if(rc == -1) return NULL;
    ssize_t segment_size = statbuf.st_size;

    void *mem_ptr = mmap(0,segment_size,PROT_READ|PROT_WRITE, MAP_SHARED,fd,0);
    if(mem_ptr == MAP_FAILED) return NULL;

    *size = segment_size;
    close(fd);
    return mem_ptr;
}


extern SEXP R_TrueValue;
extern SEXP R_FalseValue;

//static
void removeVar(SEXP symbol, SEXP rho)
{
    SEXP list = PROTECT(allocVector(STRSXP, 1));
    SET_STRING_ELT(list, 0, PRINTNAME(symbol));
    SEXP call = PROTECT(LCONS(install(".Internal"),
        CONS(LCONS(install("remove"),
            CONS(list, CONS(rho, CONS(R_FalseValue, R_NilValue)))),
                R_NilValue)));
    PrintValue(call);
    eval(call, R_GlobalEnv);
    UNPROTECT(2);
}

//extern FILE *stdlog;

//const char *src_func;
//const char *src_file;
//int src_line;
void __src_info(const char *func, const char *file, int line)
{
//  if(stdlog) fprintf(stdlog, "%s (%s:%d) ", func, file, line); else
    fprintf(stdout, "%s (%s:%d) ", func, file, line);
}

void util_info(const char *format, ...)
{
    va_list ap;
    supr_thread_t *cth = currentThread();
    if(cth) fprintf(stdout, "[INFO %d %d]", cth->pid, cth->tid);
    va_start(ap, format);
    vprintf(format, ap);

    fflush(stdout);
}

void futil_info(FILE *stream, const char *format, ...)
{
    va_list ap;
    supr_thread_t *cth = currentThread();
    if(cth) fprintf(stream, "[INFO %d %d]", cth->pid, cth->tid);
    va_start(ap, format);
    vfprintf(stream, format, ap);

    fflush(stream);
}

#define printf __src_info(__func__, __FILE__, __LINE__); util_info
#define printf __src_info(__func__, __FILE__, __LINE__); util_info
//#define fprintf __src_info(__func__, __FILE__, __LINE__); futil_info

void  __print_sem_error__(int en, const char *file, int line,
	       	const char *func)
{
  fprintf(stderr, "[%s:%d] Error in %s: %s\n", file, line, func, strerror(en));
  switch(en){
    case EINTR:
         fprintf(stderr, "\tThe call was interrupted by a signal handler\n");
	 break;

    case EAGAIN:
         fprintf(stderr,
"\tThe operation could not be performed without blocking (i.e., the\n"
"\t semaphore currently has the value zero).\n");
	 break;

    case ETIMEDOUT:
         fprintf(stderr,
"\tThe call timed out before the semaphore could be locked\n");
	 break;
    default: break;
  }
}

#define print_sem_error(en)  __print_sem_error__(en, __FILE__, __LINE__, __func__)

extern supr_thread_t *main_thread;
extern int Supr_verbose;

extern ssize_t Socket_send(int socket, const void *buffer, size_t length, int flags);

#define send(s, b, len, flags) Socket_send((s), (b), (len), (flags))

void Html_sendError(supr_socket_conn_t *conn, const char *file_name)
{
        char protocol[] = "HTTP/1.1 404 Not Found\r\n";
        char servName[] = "Server:simple web server\r\n";
        char cntType[] = "Content-type:text/html\r\n\r\n";

        //char content[] = "<html><head><title>SupR2</title></head>" "<body><p><center><h3>Error 400: couldn't find the requested object" "</h3></center></p></body></html>";

        char content[1024];
        sprintf(content, "<html><head><title>SupR2</title></head>"
                        "<body><p><center><h3>Error 404:"
                        " couldn't find the requested object</h3><a>%s</a>"
                        "</center></p></body></html>", file_name);
        //char cntLen[]   = "Content-length:2048\r\n";

        char cntLen[256];
        sprintf(cntLen, "Content-length:%ld\r\n", strlen(content));

        int fd = conn->fd;
        send(fd, protocol, strlen(protocol), 0);
        send(fd, servName, strlen(servName), 0);
        send(fd, cntLen, strlen(cntLen), 0);
        send(fd, cntType, strlen(cntType), 0);
        send(fd, content, strlen(content), 0);

        //removeConn(conn);
        return;
}

// ct: content type
void Html_sendFile(supr_socket_conn_t *conn, const char *file_name,
		const char* ct)
{
  //fprintf(stderr, "file_name: %s\n", file_name);
	/*
  if(strncmp(file_name, "data", strlen("data"))==0) {
    fprintf(stderr, "OKAY? file_name: %s\n", file_name);
    Html_sendFileList(conn, file_name);
    return;
  }
  */

  char path[PATH_MAX];
  if(strcmp(file_name, "stdout.txt")==0 ||strcmp(file_name, "stderr.txt")==0 ){
    fflush(stdout);
    //sprintf(path, "%s/%s.%d.%s", html_dir, Supr_hostname, getpid(), file_name);
    sprintf(path, "%s", file_name);
  /*} else if(strcmp(file_name, "stdlog.txt")==0 && stdlog != NULL ){
    fflush(stdlog);
    sprintf(path, "%s", Supr_stdlog_filename);
    */
  } else if(strstr(file_name, "/stdout.txt")||strstr(file_name, "/stderr.txt")){
    sprintf(path, "%s", file_name);
  } else if(*file_name =='/' ){
    sprintf(path, "%s", file_name);
  } else { // TODO ...
    Html_sendError(conn, file_name);
    return;
  }

  //fprintf(stderr, "path: %s\n", path);

  int file_fd = open(path, O_RDONLY);
  struct stat sb;
  if(file_fd == -1 || fstat(file_fd, &sb) == -1){
    Html_sendError(conn, file_name);
    return;
  }


  char protocol[] = "HTTP/1.1 200 OK\r\n";
  char servName[] = "Server:SupR2\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  char cntType[256];

  sprintf(cntLen, "Content-length: %ld\r\n", sb.st_size);
  char buf[sb.st_size];
  read(file_fd, buf, sb.st_size);
  close(file_fd);

  //char *ct = "image/webp";
  //char *ct = "text/plain";
  {
     const char *s = file_name + strlen(file_name)-1;
     while(s != file_name && *s != '.')
             s--;
     s++;
     if(strcmp(s, "html")==0){
       ct = "text/html";
     }
  }

  snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n",
                  ct);

  int fd = conn->fd;
  send(fd, protocol, strlen(protocol), 0);
  send(fd, servName, strlen(servName), 0);
  send(fd, cntLen, strlen(cntLen), 0);
  send(fd, cntType, strlen(cntType), 0);

  send(fd, buf, sizeof(buf), 0);
}



// debug: munmap_chunk(): invalid pointer ... has something to do with free

//int munmap(void *addr, size_t length);
int __supr_debug_munmap(void *addr, size_t length, const char *func,
		const char *file, int line)
{
  supr_thread_t *cth = currentThread();
  if(cth)
  {
    printf("[%d %d] __supr_debug_munmap(%p, %ld) <-- %s (%s:%d)\n",
		  cth->pid, cth->tid, addr, length, func, file, line); 
  }
  else {
    printf("__supr_debug_munmap(%p, %ld) <-- %s (%s:%d)\n",
		  addr, length, func, file, line); 
  }

  return munmap(addr, length);
}

//#define munmap(a, l) __supr_debug_munmap((a), (l), __func__,	\ __FILE__, __LINE__)


//pthread_t signalHandlerThread_ptid = 0;
//unsigned int signalHandlerThread_tid = 0;

// malloc: for debugging...

/*
void *__sys_realloc(void *ptr, size_t size, const char*file, int line)
{
  printf("%s(%p, %ld, %s, %d)\n", __func__, ptr, size, file, line);
  return realloc(ptr, size);
}

#ifndef __SYS_REALLOC__
#define __SYS_REALLOC__(ptr, size) __sys_realloc((ptr), (size), __FILE__, __LINE__)
#endif
*/

//// testing
extern int (*ptr_R_ReadConsole)(const char *prompt, unsigned char *buf, int len, int addtohistory); 

SEXP __R_ReadConsole()
{
  char buf[256];
  buf[255] = 0;
  int count = ptr_R_ReadConsole("ptr_R_ReadConsole: ", buf, 255, 0);
  return mkString(buf);
}
////

void c_backtrace();

extern vector_t *__classes__;
char *localhost = NULL;
static vector_t * supr_malloc = NULL;
extern vector_t *cleanups;

//#define USE_MALLOC_HOOK
#ifdef  USE_MALLOC_HOOK
#include <malloc.h>

extern void *(*__MALLOC_HOOK_VOLATILE __malloc_hook)(size_t, const void *);
extern void *(*__MALLOC_HOOK_VOLATILE __realloc_hook)(void *ptr, size_t size, const void *caller);
extern void (*__MALLOC_HOOK_VOLATILE __free_hook)(void *ptr, const void *caller);
//extern void (*__malloc_initialize_hook)(void);

static void *(*__MALLOC_HOOK_VOLATILE old_malloc_hook)(size_t, const void *);
static void *(*__MALLOC_HOOK_VOLATILE old_realloc_hook)(size_t, const void *, const void *);

static void * my_malloc_hook(size_t size, const void *caller)
{
           void *result;

           /* Restore all old hooks */
           __malloc_hook = old_malloc_hook;

           /* Call recursively */
           result = malloc(size);

           /* Save underlying hooks */
           old_malloc_hook = __malloc_hook;

	   {
   		Dl_info __info__; 
   		int __rc__ = dladdr(caller, &__info__);
		const char *func = __info__.dli_sname;
		if(func && strcmp(__info__.dli_sname, "xmalloc")
		        && strcmp(__info__.dli_sname, "_nc_doalloc")
				) {
                /* printf() might call malloc(), so protect it too. */
                  printf("\033[0;35mmalloc(%u) called from %p (%s) returns %p ",
                   (unsigned int) size, caller, __info__.dli_sname, result);
	   
   		  //Dl_info __info__; 
   		//int __rc__ = dladdr(caller, &__info__);
   		  printf(" fun: %s\033[0m\n", __info__.dli_sname);
		}
	   
	   }

           /* Restore our own hooks */
           __malloc_hook = my_malloc_hook;

           return result;
}



static void * my_realloc_hook(void *ptr, size_t size,  const void *caller)
{
           void *result;

	   {
   		Dl_info __info__; 
   		int __rc__ = dladdr(caller, &__info__);
		const char *func = __info__.dli_sname;
		if(func && strcmp(__info__.dli_sname, "xmalloc")
		        && strcmp(__info__.dli_sname, "_nc_doalloc")
				) {
                /* printf() might call malloc(), so protect it too. */
printf("\033[0;31mrealloc(%u) called from %p (%s) with ptr %p\n",
                   (unsigned int) size, caller, __info__.dli_sname, ptr);
	   
   		  //Dl_info __info__; 
   		//int __rc__ = dladdr(caller, &__info__);
		}
	   
	   }

           /* Restore all old hooks */
           __realloc_hook = old_realloc_hook;

           /* Call recursively */
           result = realloc(ptr, size);

           /* Save underlying hooks */
           old_realloc_hook = __realloc_hook;

	   {
   		Dl_info __info__; 
   		int __rc__ = dladdr(caller, &__info__);
		const char *func = __info__.dli_sname;
		if(func && strcmp(__info__.dli_sname, "xmalloc")
		        && strcmp(__info__.dli_sname, "_nc_doalloc")
				) {
                /* printf() might call malloc(), so protect it too. */
printf("\033[0;31mrealloc(%u) called from %p (%s) returs %p\n",
                   (unsigned int) size, caller, __info__.dli_sname, result);
	   
   		  //Dl_info __info__; 
   		//int __rc__ = dladdr(caller, &__info__);
		}
	   }
	   
           /* printf() might call malloc(), so protect it too. */
	   /*
           printf("\033[0;35mrealloc(%u) called from %p returns %p\n",
                   (unsigned int) size, caller, result);
	   {
   		Dl_info __info__; 
   		int __rc__ = dladdr(caller, &__info__);
   		printf("[%d] \033[0;31mfun: %s\033[0m\n", getpid(), __info__.dli_sname);
		char *a = "0xffffffff128438a0";
		char b[256];
		sprintf(b, "%p", result);
		if(strcmp(a, b)==0) kill(getpid(), SIGSEGV);
	   }
	   */

           /* Restore our own hooks */
           __realloc_hook = my_realloc_hook;

           return result;
}



//static void my_init_hook() { }
#endif

void __supr_malloc_init__()
{
#ifdef  USE_MALLOC_HOOK
  
//  old_malloc_hook = __malloc_hook;
//  __malloc_hook = my_malloc_hook;
  old_realloc_hook = __realloc_hook;
  __realloc_hook = my_realloc_hook;
//  __malloc_initialize_hook = my_init_hook;
#endif

  //printf("[%s] supr_malloc: <%p>\n", __func__, supr_malloc);
  if(supr_malloc) return; // already initialized

  if(!localhost){ // delete me? see Supr_hostname
    char name[256];
    if(gethostname(name, 256) == -1)
      errorcall(R_NilValue, "gethostname, %s", strerror(errno));
    localhost = strdup(name);
  }


  //vector_t *vec = (vector_t *) __SYS_MALLOC__(sizeof(vector_t));
  /*
  vector_t *vec = (vector_t *) malloc(sizeof(vector_t));
  vec->class = NULL;
  */


  
  vector_t *vec = newVector(FALSE);
  vec->mutex = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
    pthread_mutexattr_t RecursiveMutexAttr;
    pthread_mutexattr_init(&RecursiveMutexAttr);
    pthread_mutexattr_settype(&RecursiveMutexAttr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(vec->mutex, &RecursiveMutexAttr);
    pthread_mutexattr_destroy(&RecursiveMutexAttr);

  /*
  vec->size = 0;
  vec->buf_size = VECTOR_INITIAL_BUFFER_SIZE;
  vec->elements = (void **) malloc(sizeof(void *) * vec->buf_size);
  */

  //DEBUG
//      vec->prev_allocated_elements = vec->elements;


  if(!__classes__){
    __classes__ = newVector(TRUE);
    vectorAdd(__classes__, __classes__->class);
  }

  supr_malloc = vec;

  //cleanups = newVector(TRUE);
}

void __supr_malloc_fini__()
{
  __classes__ = NULL; // FIXME FREE
  for(int i=vectorSize(__classes__)-1; i>=0; i--){
    class_t *c = (class_t *) vectorRemove(__classes__, i);
    if(Supr_verbose){
      fprintf(stderr, "%d: (class) %s\n", i,  c->name);
    }
    // free? Check... if it uese dynamic memory...
  }
  // run cleanups?
  cleanups = NULL;
}


typedef struct supr_malloc_struct {
  void  *ptr;
  size_t size;
  const char  *func;
  const char  *file;
  int    line;
  int    ref_count;
} supr_malloc_t;


void __supr_malloc_print3__(const char* prefix, supr_malloc_t *p, int idx)
{
   /*if(stdlog) {
     fprintf(stdlog, "pid = %d [%s] %4d: %6ld %4d \t%s (%s:%d)\n", getpid(),
	  prefix, idx, p->size, p->ref_count, p->func, p->file, p->line);
   } else {
   */



//     printf("pid = %d [%s] %4d: %6ld %4d \t%s (%s:%d)\n", getpid(),
//	  prefix, idx, p->size, p->ref_count, p->func, p->file, p->line);

     fprintf(stderr, "pid = %d [%s] %4d: %6ld %4d \t%s (%s:%d)\n", getpid(),
	  prefix, idx, p->size, p->ref_count, p->func, p->file, p->line);


   //}
}

void __supr_malloc_print__()
{
//	return;

   pthread_mutex_lock(supr_malloc->mutex);
     for(int i=0; i<vectorSize(supr_malloc); i++){
       supr_malloc_t *p = (supr_malloc_t *)vectorElementAt(supr_malloc, i);
       __supr_malloc_print3__(__func__, p, i);
     }
   pthread_mutex_unlock(supr_malloc->mutex);
}

SEXP Malloc_print()
{
  __supr_malloc_print__();
  //supr_malloc = NULL;
  //supr_malloc = NULL;
  return R_NilValue;
}

//#define __MALLOC_DEBUG__

void *__supr_malloc__(size_t size, const char *func, const char *file, int line){

   if(!supr_malloc){
//     printf("%s(%ld, %s, %s, %d) calls malloc(%ld)\n", __func__, size, func, file, line, size);
     return malloc(size);
   }

   supr_malloc_t *p = (supr_malloc_t *) malloc(sizeof(supr_malloc_t) + size);
   if(!p){
     {
       char msg[1024];
       sprintf(msg, "Error: %s(%ld, %s, %s, %d), %s\npid: %d, tid: %ld", __func__,
           size, func, file, line, strerror(errno),
	   getpid(), syscall(SYS_gettid));
       sleep(120); // for tmp gdb debug
     }

     printf("Error: %s(%ld, %s, %s, %d), %s\n", __func__,
	   size, func, file, line, strerror(errno));
     exit(1);
   }
   p->ptr = p + 1;
   p->size = size;
   p->func = func;
   p->file = file;
   p->line = line;
   p->ref_count = 1;
   pthread_mutex_lock(supr_malloc->mutex);
       vectorAdd(supr_malloc, p);
#ifdef __MALLOC_DEBUG__
       __supr_malloc_print3__(__func__, p, vectorSize(supr_malloc)-1);
#endif
   pthread_mutex_unlock(supr_malloc->mutex);
   
//printf("\033[0;36m[%s] return: <%p>\033[0m\n", __func__, p->ptr);

   return p->ptr;
}

void *__supr_realloc__(void *ptr, size_t size, const char *func,	
	       	const char *file, int line){

   if(!supr_malloc){
     printf("%s(%p, %ld, %s, %s, %d) calls realloc(%p, %ld)\n", __func__,
	   ptr, size, func, file, line, ptr, size);
     return realloc(ptr, size);
   }

   supr_malloc_t *p = NULL;

   pthread_mutex_lock(supr_malloc->mutex);
       p = vectorRemoveElement(supr_malloc, ptr-sizeof(supr_malloc_t));
       if(p) {
         char prefix[256];
	 sprintf(prefix, "\033[0;34m%s(%p, %ld, %s, %s:%d)\033[0m",__func__,
			ptr, size, func, file, line);
         //__supr_malloc_print3__(prefix, p, -1);
       }
   pthread_mutex_unlock(supr_malloc->mutex);

   if(!p){
//print_caller_info(0);
//print_caller_info(1);
//print_caller_info(2);
//print_caller_info(3);
     if(ptr != supr_malloc->elements && ptr != __classes__->elements) {
       printf("%s(%p, %ld, %s, %s, %d) calls realloc(%p, %ld)\n", __func__,
	   ptr, size, func, file, line, ptr, size);
       //c_backtrace();
     }
     return realloc(ptr, size);
   }

   p = (supr_malloc_t *) realloc(p, sizeof(supr_malloc_t) + size);

   p->ptr = p + 1;
   p->size = size;
   p->func = func;
   p->file = file;
   p->line = line;
   p->ref_count = 1;
   pthread_mutex_lock(supr_malloc->mutex);
       vectorAdd(supr_malloc, p);
       //__supr_malloc_print3__(__func__, p, vectorSize(supr_malloc)-1);
   pthread_mutex_unlock(supr_malloc->mutex);
   
   return p->ptr;
}

int free_debug_on = FALSE;
SEXP enableDebug()
{
  free_debug_on = TRUE;
  return R_NilValue;
}

void __supr_free__(void *ptr, const char *func, const char *file, int line){

//  printf("\033[0;35m[%s] FREE  %s:%d, p=<%p>\033[0m\n", __func__,file,line,ptr);
    if(free_debug_on) 
   {
     printf("\033[0;35m[%s] FREE %s:%d, p=<%p>\033[0m\n", __func__,file,line,ptr);
   }

   supr_malloc_t *p = NULL;
  
   pthread_mutex_lock(supr_malloc->mutex);
       p = vectorRemoveElement(supr_malloc, ptr-sizeof(supr_malloc_t));
#ifdef __MALLOC_DEBUG__
       if(p) {
         char prefix[256];
	 sprintf(prefix, "\033[0;32m%s <- %s(%s:%d)\033[0m\n\t",__func__, func,
			 file, line);
         __supr_malloc_print3__(prefix, p, -1);
       }
#endif
   pthread_mutex_unlock(supr_malloc->mutex);

   if(!p){
//     printf("\033[0;35m[%s] FIXME %s:%d\033[0m\n", __func__, file, line);
     if(free_debug_on) 
     {
       printf("\033[0;35m[%s] FIXME %s:%d\033[0m\n", __func__, file, line);
     }
     free(ptr);
     return;
   }
   
   p->ref_count --;

   if(p->ref_count==0)
   {
//     printf("\033[0;35m[%s] FREE 1 %s:%d, p=<%p>\033[0m\n", __func__,file,line,p);
     free(p);
//     printf("\033[0;35m[%s] FREE 2 %s:%d\033[0m\n", __func__, file, line);
   }
}


void __supr_malloc_finalize()
{
  if(Supr_verbose)
    __supr_malloc_print__();
}

char *__supr_strdup__(const char *ptr, const char *func, const char *file,
	       	int line){
  int len = strlen(ptr) + 1;
  char *p = (char*)__supr_malloc__(len, func, file, line);
  memcpy(p, ptr, len);
  return p;
}

#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)
#define strdup(ptr) __supr_strdup__((ptr), __func__, __FILE__, __LINE__)


int wrapped_strcmp(const void *a, const void *b)
{
  //return strcmp(*((char **) a), *((char **) b));
  return strcmp((char *) a, (char *) b);
}


char *__mk_tmpnam__(const char *prefix, const char *suffix)
{
  static size_t idx = 0; // not thread-save, using static variables
  char buf[256];
  const char *str = suffix + strlen(suffix);
  for(; str != suffix; str--)
	  if(*str == '.'){
		  str++;
		  break;
	  }

  sprintf(buf, "%s-%d-%d-%ld.%s", prefix, geteuid(), getpid(), idx++, str);
  return strdup(buf);
}


// FIXME, not thread safe
const char *__toString__(void *ptr)
{
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(1024);
  sb->size = 0;
  sb->buf[0] = 0;
  // to do ...
  sprintf(sb->buf, "<%p>", ptr);
  sb->size = strlen(sb->buf);
  return sb->buf; 
}

static const char *vectorToString(class_t *class, void *data)
{
//	printf("[%s] is called\n", __func__);
  vector_t *vec = (vector_t *) data;
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(1024);

  sb->size = 0;
  sb->buf[0] = 0;

  strbufPutStr(sb, "(");
  strbufPutStr(sb, class->name);
  strbufPutStr(sb, ") [");
  for(int i=0; i<vectorSize(vec); i++){
//    char buf[128];
//    sprintf(buf, "<%p>", vectorElementAt(vec, i));
    const char *buf = __toString__(vectorElementAt(vec, i));
    if(i>0) strbufPutStr(sb, ", ");
    strbufPutStr(sb, (char*) buf);
  }
  strbufPutStr(sb, "]");
 
  return sb->buf; 
}


// Files for dfs
int File_remove(const char *pathname)
{
  return remove(pathname);
}

int vectorDestroy(vector_t *vec);
void vectorFinalize(class_t *class, void *object)
{
  vector_t *obj = (vector_t *) object;
  vectorDestroy(obj);
}

vector_t *newVector(int sync)
{
  static class_t *class = NULL;
  if(!class) class = newClass("Vector", vectorToString, vectorFinalize);

  vector_t *vec = (vector_t *) malloc(sizeof(vector_t));
  vec->class = class;
  vec->ref_count = REF_COUNT_INITIALIZER;

//  printf("[%s] Vector_class: %p\n", __func__, vec->class);

  if(sync){
    vec->mutex = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(vec->mutex, NULL);
  } else
	  vec->mutex = NULL;

  vec->size = 0;
  vec->buf_size = VECTOR_INITIAL_BUFFER_SIZE;
  vec->elements = (void **) malloc(sizeof(void *) * vec->buf_size);

  vec->free_data = NULL;

  return vec;
}

// use realloc ...
void *vectorAdd(vector_t *vec, void *elem)
{
  if(vec->size == vec->buf_size) {
      vec->buf_size += 1 + vec->buf_size/2;
      /*
      void **elements = vec->elements;
      vec->elements = (void **) malloc(sizeof(void *) * vec->buf_size);
      memcpy(vec->elements, elements, vec->size*sizeof(void*));
      free(elements);
      */
      //vec->elements = (void **) malloc(sizeof(void *) * vec->buf_size);
//#define VECTOR_DEBUG
#ifdef  VECTOR_DEBUG
      supr_thread_t *cth = currentThread();
      printf("\n[tid: %d][%s] <%p, %p>\n", cth?cth->tid:-1, __func__, vec->prev_allocated_elements, vec->elements);
      if(vec->prev_allocated_elements != vec->elements){
	      printf("Error: (%s:%d)\n", __FILE__, __LINE__);
	      exit(1);
      }
#endif
      vec->elements = (void **) realloc(vec->elements,
		      	sizeof(void *) * vec->buf_size);
//      printf("[%s] <prev: %p, new: %p>\n\n", __func__, vec->prev_allocated_elements, vec->elements);
#ifdef  VECTOR_DEBUG
      vec->prev_allocated_elements = vec->elements;
#endif
  }
  vec->elements[vec->size++] = elem;
  
  return elem;
}

void *vectorAddElementAt(vector_t *vec, int idx, void *elem)
{
  if(vec->size == vec->buf_size) {
      vec->buf_size += 1 + vec->buf_size/2;
      void **elements = vec->elements;
      vec->elements = (void **) malloc(sizeof(void *) * vec->buf_size);
      /*
      for(int i=0; i<vec->size; i++){ vec->elements[i] = elements[i]; }
      */
      memcpy(vec->elements, elements, vec->size*sizeof(void*));
      free(elements);
  }

  if(idx >= vec->size || idx < 0)
    vec->elements[vec->size++] = elem;
  else {
    for(int i=vec->size-1; i>= idx; i--) 
      vec->elements[i+1] = vec->elements[i];
    vec->size++;
    vec->elements[idx] = elem;
  }
  
  return elem;
}

int compare_dflt(const void *a, const void*b)
{
//  return a==b ? 0:1;
	return (unsigned long) a - (unsigned long) b;
}

void *vectorAddIfNotExists(vector_t *vec, void *elem,
	       	int (*compare)(const void *, const void*))
{
  if(!compare) compare = compare_dflt;
  for(int i=0; i<vec->size; i++){
    if(compare(elem, vec->elements[i])==0) 
	    return NULL;
  }
  return vectorAdd(vec, elem);
}

void *vectorElementAt(vector_t *vec, int i)
{
  if(i<0 || i>= vec->size) return NULL;
  //return i < vec->size ?  vec->elements[i] : NULL;
  return vec->elements[i];
}

void *vectorRemove(vector_t *vec, int i)
{
  if( i >= vec->size) return NULL;
  void *elem = vec->elements[i];
  vec->size--;
  for(; i<vec->size ; i++)
    vec->elements[i] = vec->elements[i+1];

  return elem;
}

void *vectorRemoveElement(vector_t *vec, void *elem)
{
  for(int i=0; i<vec->size; i++){
    if(vec->elements[i] == elem) {
      vectorRemove(vec, i);
      return elem;
    }
  }
  return NULL;
}

void *vectorSet(vector_t *vec, int i, void *elem)
{
  
  if(i<0 || i>= vec->size){
    pthread_kill(pthread_self(), SIGSEGV);
  }

  void *e = vec->elements[i];
  vec->elements[i] = elem;
  return e;
}

int vectorSize(vector_t *vec)
{
  return vec ? vec->size: 0;
}




int vectorDestroy(vector_t *vec)
{
  //print_caller_info(0);
  //print_caller_info(1);

  if(vec->mutex) {
    pthread_mutex_destroy(vec->mutex);
    free(vec->mutex);
  }

  if(vec->free_data){
    for(int i=0; i<vectorSize(vec); i++){
      vec->free_data(vectorElementAt(vec, i));
    }
  }

  free(vec->elements);
  free(vec);
}

//iterator


const char *iteratorToChar(class_t *class, void *object)
{
  iterator_t *iter = (iterator_t *) object;
  return iter->class->name; // FIXME
}

void iteratorFinalize(class_t *class, void *object)
{
  fprintf(stderr, "\033[0;31m[%s] Start\n", __func__);
  iterator_t *iter = (iterator_t *) object;

  class_t *c = getClass(iter->data);
  fprintf(stderr, "\t class of data: %s\n", c ? c->name : NULL);
  if(c){
    if(strcmp(c->name, "Vector")==0){
      fprintf(stderr, "\t size of data: %d, data ref_count: %d\n",
	      vectorSize(iter->data), ((object_t*)iter->data)->ref_count);
      Supr_decref(iter->data);
    } else if(strcmp(c->name, "DDList")==0){
      Supr_decref(iter->data);
    }
  }

  free(object); // FIXME
  fprintf(stderr, "[%s] TODO/Done !\033[0m\n", __func__);

}

static class_t __Iterator_class = {"Iterator", iteratorToChar,
       	iteratorFinalize};

class_t *Iterator_class = &__Iterator_class;

iterator_t *newIterator(int (*hasNext)(void *), void *(*next)(void *),
	       	void *data)
{
	/*
  if(!Iterator_class){
   Iterator_class = newClass("Iterator", iteratorToChar, iteratorFinalize);
  }
  */
  iterator_t *iter = (iterator_t *)malloc(sizeof(iterator_t));
  iter->class = Iterator_class;
  iter->ref_count = REF_COUNT_INITIALIZER;

  iter->hasNext = hasNext;
  iter->next = next;
  iter->data = data;
  return iter;
}

// use macro?
int iteratorHasNext(iterator_t *iter)
{
  return  iter->hasNext(iter->data); 
}

void *iteratorNext(iterator_t *iter)
{
  return  iter->next(iter->data); 
}


//hashtable

static
const char *hashtableToString(class_t *class, void *data)
{
  hashtable_t *tbl = (hashtable_t *) data;
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(1024);

  sb->size = 0;

  int size;
  char **keys = hashtable_keys(tbl, &size); 
  strbufPutStr(sb, "[");
  for(int i=0; i<size; i++){
    if(i) strbufPutStr(sb, ", ");
    strbufPutStr(sb, keys[i]);
    strbufPutStr(sb, " = ");
    
    void *val = hashtable_find(tbl, keys[i]);
    class_t *class = getClass(val);
    if(class){
      strbufPutStr(sb, (char*) class->toString(class, val));
    } else {
      char buf[64];
      sprintf(buf, "<%p>", val);
      strbufPutStr(sb, buf);
    }
  }
  strbufPutStr(sb, "]");


  return sb->buf;
}

static void hashtableFinalize(class_t *class, void *object)
{
  hashtable_t *tbl = (hashtable_t *) object;

  fprintf(stderr, "\033[0;34m[%s] Start\n", __func__);
  hashtable_destroy(tbl);
  fprintf(stderr, "[%s] free(tbl)...\n", __func__);
  free(tbl);
  fprintf(stderr, "[%s] TODO\n", __func__);
  fprintf(stderr, "[%s] Done!\033[0m\n", __func__);
}

hashtable_t *newHashtable(int sync)
{
  static class_t *class = NULL;
  if(!class) class = newClass("Hashtable", hashtableToString,hashtableFinalize);

  hashtable_t *tbl = create_hashtable(NULL);
  tbl->class = class;
  tbl->ref_count = REF_COUNT_INITIALIZER;
  if(sync){
    tbl->mutex = (pthread_mutex_t*) malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(tbl->mutex, NULL);
  } else {
    tbl->mutex = NULL;
  }
  tbl->free_data = NULL;
  return tbl;
}



// checksum???

#define USE_CHECKSUM
#ifdef USE_CHECKSUM
#define CRC(crc, ch)     (crc = (crc >> 8) ^ crctabb[(crc ^ (ch)) & 0xff])

static const uint32_t crctabb[256] = {
    0x00000000, 0x77073096, 0xee0e612c, 0x990951ba,
    0x076dc419, 0x706af48f, 0xe963a535, 0x9e6495a3,
    0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
    0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91,
    0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de,
    0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
    0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec,
    0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5,
    0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
    0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b,
    0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940,
    0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
    0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116,
    0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f,
    0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
    0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d,
    0x76dc4190, 0x01db7106, 0x98d220bc, 0xefd5102a,
    0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
    0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818,
    0x7f6a0dbb, 0x086d3d2d, 0x91646c97, 0xe6635c01,
    0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
    0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457,
    0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c,
    0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
    0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2,
    0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb,
    0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
    0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9,
    0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086,
    0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
    0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4,
    0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad,
    0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
    0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683,
    0xe3630b12, 0x94643b84, 0x0d6d6a3e, 0x7a6a5aa8,
    0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
    0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe,
    0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7,
    0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
    0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5,
    0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252,
    0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
    0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60,
    0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79,
    0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
    0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f,
    0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04,
    0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
    0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a,
    0x9c0906a9, 0xeb0e363f, 0x72076785, 0x05005713,
    0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
    0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21,
    0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e,
    0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
    0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c,
    0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45,
    0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
    0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db,
    0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0,
    0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
    0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6,
    0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf,
    0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
    0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d,
};

int Supr_crc32(char *buf, int size, uint32_t *cval, off_t *clen)
{
    uint32_t lcrc = ~0;
    if (size < 0) return 1 ;

    for (; size--; buf++) CRC(lcrc, *buf) ;

    *clen = size; // not used?
    *cval = ~lcrc ;
    return 0 ;
}

int (*cfncn)(char *, int, uint32_t *, off_t *) = Supr_crc32;

#endif



// Local function to locate a key

#include <search.h>


// Simple hash function from K&R.
uint32_t defaultFnKnR (const char *key) {
  static int HASHSZ = 101; // a prime number
  if (key == NULL) return HASHSZ;

  uint32_t hashval;
  for (hashval = 0; *key != '\0'; key++)
          hashval = (uint32_t)(*key) + 31 * hashval;
  return hashval % HASHSZ;
}

// Bob Jenkins' hashing function.
#define mixBits(a,b,c) { \
            a -= b; a -= c; a ^= (c >> 13); \
            b -= c; b -= a; b ^= (a <<  8); \
            c -= a; c -= b; c ^= (b >> 13); \
            a -= b; a -= c; a ^= (c >> 12); \
            b -= c; b -= a; b ^= (a << 16); \
            c -= a; c -= b; c ^= (b >>  5); \
            a -= b; a -= c; a ^= (c >>  3); \
            b -= c; b -= a; b ^= (a << 10); \
            c -= a; c -= b; c ^= (b >> 15); \
}

uint32_t defaultFnBJ (const char *key) {
  uint32_t a = 0x9e3779b9;
  uint32_t b = 0x9e3779b9;
  uint32_t c = 0;

  // Return table size if no data to hash.
  if (key == NULL) return 256;

  uint32_t sz = strlen (key);
  size_t left = sz;
  while (left >= 12) {
    a +=   (uint32_t)key[ 0]
            + ((uint32_t)key[ 1] <<  8)
            + ((uint32_t)key[ 2] << 16)
            + ((uint32_t)key[ 3] << 24);
    b +=   (uint32_t)key[ 4]
            + ((uint32_t)key[ 5] <<  8)
            + ((uint32_t)key[ 6] << 16)
            + ((uint32_t)key[ 7] << 24);
    c +=   (uint32_t)key[ 8]
            + ((uint32_t)key[ 9] <<  8)
            + ((uint32_t)key[10] << 16)
            + ((uint32_t)key[11] << 24);
    mixBits (a, b, c);
    key += 12;
    left -= 12;
  }

  c += sz;
  switch (left) {
    case 11 : c += ((uint32_t)key[10] << 24);
    case 10 : c += ((uint32_t)key[ 9] << 16);
    case  9 : c += ((uint32_t)key[ 8] <<  8);
    case  8 : b += ((uint32_t)key[ 7] << 24);
    case  7 : b += ((uint32_t)key[ 6] << 16);
    case  6 : b += ((uint32_t)key[ 5] <<  8);
    case  5 : b +=  (uint32_t)key[ 4];
    case  4 : a += ((uint32_t)key[ 3] << 24);
    case  3 : a += ((uint32_t)key[ 2] << 16);
    case  2 : a += ((uint32_t)key[ 1] <<  8);
    case  1 : a +=  (uint32_t)key[ 0];
  }
  mixBits (a, b, c);
  // Return hash, adjusted for table size.
  return c & 0xff;
}


#ifndef VALUE_TO_STRING
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)
#endif



#ifdef malloc
//#pragma message("\033[0;31mmalloc is defined\033[0m\n")
//#pragma message "1205. value of malloc(x) = " VALUE(malloc(x))
#endif

#ifdef free
//#pragma message("\033[0;31mfree is defined\033[0m\n")
//#pragma message "1210. value of free(x) = " VALUE(free(x))
#endif



void *__malloc__(size_t size)
{
  return malloc(size);
}

static void locate (HashTable tbl, const char *key,
                int *pEntry, HashNode *pPrev,
                HashNode *pNode)
{
  *pEntry = tbl->fn (key);
  *pPrev = NULL;
  *pNode = tbl->lookup[*pEntry];
  while (*pNode != NULL) {
    if (strcmp (key, (*pNode)->key) == 0)
            break;
    *pPrev = *pNode;
    *pNode = (*pNode)->next;
  }
}

#define DFLT_HASHTBL_BJ 0
// Create a hash table, giving only the hashing function.
HashTable create_hashtable(uint32_t (*fn)(const char *))
{
  if (fn == NULL)
    fn = DFLT_HASHTBL_BJ ? defaultFnBJ : defaultFnKnR;

  uint32_t numEntries = fn (NULL);

  HashTable tbl = __malloc__(sizeof (hashtable_t) // (__HashTable)
                  + numEntries * sizeof (HashNode));
  tbl->fn = fn;
  for (uint32_t i = 0; i < numEntries; i++)
          tbl->lookup[i] = NULL;
  return tbl;
}

//void (*__hashtable_data_free)(void *) = NULL;

// Destroys a hash table, freeing all data.
void hashtable_destroy(HashTable tbl)
{
  uint32_t numEntries = tbl->fn (NULL);
  for (uint32_t i = 0; i < numEntries; i++) {
    HashNode node = tbl->lookup[i];
    while (node != NULL) {
      HashNode next = node->next;
      free (node->key);
      //free (node->data);
      if(tbl->free_data) tbl->free_data(node->data);
      free (node);
      node = next;
    }
  }
  //free(tbl); //?
}

// Set a hash value (key/data), creating it if it doesn't already exist.
int hashtable_set(HashTable tbl, const char *key, void *data)
{
  int entry;
  HashNode prev, node;
  locate (tbl, key, &entry, &prev, &node);
  if (node != NULL) {
    //free (node->data);
  //fprintf(stderr, "\033[0;31mOld node %p is not freed\033[0m\n", node->data);
    //node->data = newdata;
    if(tbl->free_data) tbl->free_data(node->data);
    node->data = data;
    return 0;
  }

  //node = __malloc__ (sizeof (__HashNode));
  node = malloc(sizeof (__HashNode));
  //message:
  //fprintf(stderr, "\033[0;32m[%s] key: %s, sizeof (__HashNode): %ld\n", __func__, key, sizeof (__HashNode));

  node->key = strdup (key);
  //node->data = dupstr (data); // FIXME ...
  node->data = data;
  /*
  if ((node->key == NULL) || (node->data == NULL)) {
    free (node->key);
    free (node->data);
    free (node);
    return -1;
  }
  */
  node->next = tbl->lookup[entry];
  tbl->lookup[entry] = node;

  return 0;
}

// Delete a hash entry, returning error if not found.
// 
int hashtable_delete(HashTable tbl, char *key)
{
  int entry;
  HashNode prev, node;

  locate (tbl, key, &entry, &prev, &node);

  if (node == NULL) return -1;

  if (prev != NULL) prev->next = node->next;
  else tbl->lookup[entry] = node->next;

  free (node->key);
  //free (node->data); ??

  if(tbl->free_data) tbl->free_data(node->data);

  free (node);

  return 0;
}

// Find a hash entry, and return the data. If not found, returns NULL.
void *hashtable_find (HashTable tbl, const char *key)
{
  int entry;
  HashNode prev, node;
  locate (tbl, key, &entry, &prev, &node);

  if (node == NULL) return NULL;

  return node->data;
}

// Output debugging info about the hash table.
static void hashtable_debug (HashTable tbl, char *desc)
{
  uint32_t numEntries = tbl->fn (NULL);

  printf ("=====: %s %d entries\n", desc, numEntries);

  for (uint32_t i = 0; i < numEntries; i++) {
    if (tbl->lookup[i] != NULL) {
      int sz = 0;
      printf ("Entry #%3d:", i);
      HashNode node = tbl->lookup[i];
      while (node != NULL) {
        printf (" ['%s' = <%p>]", node->key, node->data);
        node = node->next;
        sz++;
      }
      printf (", size=%d\n", sz);
    }
  }
  printf ("\n");
}

// list all hashed objects
char **hashtable_keys (HashTable tbl, int *size)
{
  uint32_t numEntries = tbl->fn (NULL);

  int sz = 0;
  for (uint32_t i = 0; i < numEntries; i++) {
    if (tbl->lookup[i] != NULL) {
      HashNode node = tbl->lookup[i];
      while (node != NULL) {
        node = node->next;
        sz++;
      }
    }
  }
  char **keys = __malloc__(sizeof(char*)*sz);
  sz = 0;
  for(uint32_t i = 0; i < numEntries; i++) {
    if (tbl->lookup[i] != NULL) {
      HashNode node = tbl->lookup[i];
      while (node != NULL) {
        keys[sz++] = node->key;
        node = node->next;
      }
    }
  }
  *size = sz;
  return keys;
}

int hashtable_size(HashTable tbl)
{
  uint32_t numEntries = tbl->fn (NULL);

  int sz = 0; // keep size in HashTable??? // or use a stack???
  for (uint32_t i = 0; i < numEntries; i++) {
    if (tbl->lookup[i] != NULL) {
      HashNode node = tbl->lookup[i];
      while (node != NULL) { // printf (" ['%s' = <%p>]", node->key, node->data);
        node = node->next;
        sz++;
      }
    }
  }
  return sz;
}

/******************************* testing **********************/

#define DEFAULT_HASH_FUN_NULL 0
#define DEFAULT_HASH_FUN_BJ 1
#define DEFAULT_HASH_FUN_KnR 2



void test_hashtable()
{
  uint32_t (*fun)(const char *);
  int hashfun = DEFAULT_HASH_FUN_BJ;
  switch(hashfun){
    case DEFAULT_HASH_FUN_NULL: fun = NULL;
         break;
    case DEFAULT_HASH_FUN_BJ: fun = defaultFnBJ;
         break;
    case DEFAULT_HASH_FUN_KnR: fun = defaultFnKnR;
         break;
    default: fun = NULL;
  }

  HashTable tbl = create_hashtable(fun);

  char *val_1 = strdup("Value_1");
  int rc =  hashtable_set(tbl, "object_1", val_1);
  printf("hashtable_set(tbl, \"object_1\", val_1): %d\n", rc);
  char *val_2 = strdup("Value_2");
  rc =  hashtable_set(tbl, "object_2", val_2);
  printf("hashtable_set(tbl, \"object_2\", val_2): %d\n", rc);

  void *v1 = hashtable_find (tbl, "object_1");
  printf("hashtable_find(tbl, \"object_1\"): %s\n", (char*) v1);

  rc = hashtable_delete (tbl, "object_1");
  printf("hashtable_delete(tbl, \"object_1\"): %d\n", rc);


  int size;
  char **keys = hashtable_keys (tbl, &size);
  printf("keys (%d):\n", size);
  for(int i=0; i<size; i++){
	  printf(" %s", keys[i]);
  }
  printf("\n\n");
//  sleep(10);
}





int setDir(const char *dir_path, const char *subdir)
{
  char buf[strlen(dir_path)+strlen(subdir)+2];

  DIR* dir = opendir(dir_path);
  if(!dir){
    printf("[%s] Error: opendir, %s\n", __func__, strerror(errno));
    return -1;
  } else {
	  /*
    struct dirent *dp;
    while((dp = readdir (dir))){
      printf("[%s] %s\n", __func__, dp->d_name);
    }
    */
    closedir(dir);
  }

  sprintf(buf, "%s", dir_path);

  char b[strlen(subdir)+2];
  sprintf(b, "%s/", subdir);
  char *s = b;
  while(s && strstr(s, "/")){
    char *name = s;
    s =  strstr(s, "/");
    *s = 0; s++;
    sprintf(buf+strlen(buf), "/%s", name);
    //printf("buf::: %s\n", buf);
    dir = opendir(buf);
    if(!dir){ // create
      if(mkdir(buf, 0700)==-1){
        printf("[%s] Error: mkdir, %s\n", __func__, strerror(errno));
        return -1;
      } /* else {
        printf("[%s] mkdir(%s, 0700)\n", __func__, buf);
      } */
    } else {
      closedir(dir);
    }
  }

  //printf("s::: %s\n", s);

  sprintf(buf, "%s/%s", dir_path, subdir);
  //printf("[chdir]: %s\n", buf);
  int rc = chdir(buf);
  if(rc == -1)
  {
     printf("[%s] Error: chdir(%s), %s\n", __func__, buf, strerror(errno));
  }
  return rc;
}

// { , , res, data};
/*
static HashTable shmMemTable = NULL;
static HashTable tmpMemTable = NULL;
static R_allocator_t suprAllocator = { supr_malloc, supr_free, NULL, NULL};

void supr_malloc_init(void *arg)
{
  uint32_t (*hashfun)(const char *) = defaultFnBJ;
  shmMemTable = create_hashtable(hashfun);
  tmpMemTable = create_hashtable(hashfun);
  suprAllocator.res = NULL;
  suprAllocator.data = shmMemTable;
}
*/



/*
#include <jni.h>        // JNI header provided by JDK
#include <stdio.h>      // C Standard IO Header
#include <errno.h>
#include <sys/types.h> 
#include <unistd.h>   
#include <sys/shm.h> 
#include <semaphore.h> 
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <time.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>

#include <string.h>

#include <pthread.h>

#include "RJNI.h"   // Generated

#include <Rembedded.h>


#define USE_RINTERNALS	// to use SEXPREC_ALIGN

#include <Rinternals.h>
#include <R.h>
//#include <Rmath.h>

#include <R_ext/Parse.h>

#include "myRdefn.h"

#define __RJNI_MAIN__
#include "rjni.h"

#include <sys/syscall.h>
#include <readline/readline.h>
#include <readline/history.h>

// network
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>

void c_backtrace();
int isInterrupted = 0;
int javaExceptionOccurred = FALSE;
*/
/*

//void *rjni_shm_create(const char *cshm_name, size_t size);
*/


#define GDB_BUFFER_SIZE 100000
char GDB_BUFFER[GDB_BUFFER_SIZE];

char *gdb_trace(int id, int full)
{
    char *trace_cmd = full? "thread apply all bt full" : "thread apply all bt";
  static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

  if(id == 0) id = syscall(SYS_gettid);

  char str_id[16];
  sprintf(str_id, "(LWP %d)", id);

  pthread_mutex_lock(&mutex);

  int pipefd_out[2];
  int rc = pipe(pipefd_out);
  if(rc==-1) printf("[c] pipe, %s\n", strerror(errno));

  int pipefd_in[2];
  rc = pipe(pipefd_in);
  if(rc==-1) printf("[c] pipe, %s\n", strerror(errno));

  int cpid;
  if((cpid = fork())) {
    // out and in are wrt gdb
    FILE *cmd_output = fdopen(pipefd_out[0], "r");
    FILE *cmd_input = fdopen(pipefd_in[1], "w");
    close(pipefd_out[1]); // Close writing end of pipe
    close(pipefd_in[0]);

    int n = 5; // 2*len+3;
    char *cmds[n];
    int cmdlen = 64;
    char cmd_buf[n*cmdlen];
    for(int i=0; i<n; i++)
      cmds[i] = cmd_buf+(i*cmdlen);

    int k=0;
    sprintf(cmds[k++], "attach %d", getpid());
    //    sprintf(cmds[k++], "info stack");
    sprintf(cmds[k++], "info threads");
    sprintf(cmds[k++], "%s", trace_cmd);

    sprintf(cmds[k++], "quit");
    sprintf(cmds[k++], "y");


    fprintf(stderr, "\033[0;34m\n");
    printf("\033[0;33m[%s:%d] gdb commands (id = %d):\n\033[0m",
                    __FILE__, __LINE__, id);
//    int cmd_len = 1; 

    for(int i=0; i<n; i++) {

      printf("(gdb) \033[0;32m%s\n\033[0m", cmds[i]);
      fprintf(cmd_input, "%s\n", cmds[i]);
//      cmd_len += strlen(cmds[i]);
    }
    printf("\033[0;33m[%s:%d]// gdb commands //\n\033[0m", __FILE__, __LINE__);
        fflush(cmd_input);

    /*
    char _cmds[cmd_len];
    for(int i=0; i<n; i++)
      sprintf(_cmds + strlen(_cmds), "%s\n", cmds[i]);

    fprintf(cmd_input, "%s", _cmds);
    fflush(cmd_input);
    sleep(1);
    */



    //int cmd_idx = 0;


    char buf[1024];
    //char out[1024];

    char *word = "Detaching from program:";

    int collect = FALSE;
    char *s = GDB_BUFFER;
    char *t;
    size_t out_len = 0;
    //int m;
    char *m;
    while (m = fgets(buf, sizeof(buf), cmd_output)) {

            /*
      if(id == -1) {
        if(!collect){
          if((t=strstr(buf, "Thread")) && strstr(t, "LWP"))
            collect = TRUE;
          else continue; // skip the header
        }
      } else if(!collect){
        if((t=strstr(buf, "Thread")) && (t = strstr(t, "Thread")) &&
                        strstr(t, str_id))
              collect = TRUE;
        continue;
      } else if(strncmp(buf, "#",1)) collect = FALSE;
      */

            /*
      int k = strlen(buf);
      if(s+k < GDB_BUFFER+GDB_BUFFER_SIZE-1){
          sprintf(s, "%s", buf);
          s += k;
      }
      */

//      printf("\033[0;32m%s\033[0m",buf);

      int k = strlen(buf);
      if(strstr(buf, "Reading symbols")==NULL && out_len+k < GDB_BUFFER_SIZE-1){
          sprintf(GDB_BUFFER + out_len, "%s", buf);
          out_len += k;
      }

      /*
      if(strstr(buf, "(gdb)")) {
        fprintf(cmd_input, "%s\n", cmds[cmd_idx++]);
//        fflush(cmd_input);
      }
      */

      if(strstr(buf, word)) {
        fprintf(stderr, "\033[0;34m[%s:%d] %s\n\033[0m",
                        __FILE__, __LINE__, buf);
              break;
      }
    }

    fclose(cmd_output);
    fclose(cmd_input);

    int status;
    //wait(&status);
    waitpid(cpid, &status, 0);
//    printf("\033[0mgdb return status: %d\n", status);
//    printf("\033[0;32m%s\033[0m\n", GDB_BUFFER);
    //pthread_mutex_unlock(&mutex);
    //return GDB_BUFFER;

    char *out = malloc(strlen(GDB_BUFFER)+1);
    strcpy(out, GDB_BUFFER); //, strlen(GDB_BUFFER)+1);
    pthread_mutex_unlock(&mutex);
    return out;

  } else {

    dup2(pipefd_out[1], STDOUT_FILENO); // Duplicate writing end to stdout
    close(pipefd_out[0]);
    close(pipefd_out[1]);

    dup2(pipefd_in[0], STDIN_FILENO);
    close(pipefd_in[0]);
    close(pipefd_in[1]);

// use environment variables ??
#ifdef __MACH__
    char *path = "/opt/local/bin/ggdb";
    int ret = execl(path, "ggdb", (char *)0);
#else
    char *path = "/usr/bin/gdb";
    int ret = execl(path, "gdb", (char *)0);
#endif
    exit(ret);
  }
  return NULL; //never reached
}

//char *gdb_trace(int id, int full)
SEXP __gdb_trace()
{
  const char *s = gdb_trace(0, FALSE);
  fprintf(stdout, "%s\n", s);
  return R_NilValue;
}


static int SUPR_HEADER[] = {SUPR, 0, 0, 0};

extern tr_cntxt_t tr_cntxt;

#define SUPR_HEADER_SIZE  sizeof(SUPR_HEADER)

#define sys_error() 	\
	do {	\
		c_backtrace();	\
   		errorcall(R_NilValue, "[%s] system BUG (%s, %d)",	\
			   __func__, __FILE__, __LINE__);	\
	} while(0)
#define not_implemented() 	\
	do {	\
		errorcall(R_NilValue, "[%s, (%s, %d)] not implemented",	\
				__func__, __FILE__, __LINE__);	\
	} while(0)


/*
#define _GNU_SOURCE
#include <dlfcn.h>

#define print_caller_info(which)        \
do {    \
   Dl_info __info__;    \
   int __rc__ = dladdr(__builtin_return_address(which), &__info__);     \
   printf("[%d] fun: %s\n", gettid(), __info__.dli_sname);      \
} while (0)
*/

// socket

/*
#define MAX_PENDING_CONNECTIONS 100
static int T_maxPendingConnections = MAX_PENDING_CONNECTIONS;


int socket_server(int _port, int *port)
{
  struct sockaddr_in serv_addr;
  int listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if(listenfd == -1) // fixme - don't call errorcall ...
     errorcall(R_NilValue, "[c] socket: %s", strerror(errno));

#ifdef USE_NONBLOCKING_SOCKET
  { // 10/21/2019 try non-blocking mode
//    print_caller_info(0);
//    print_caller_info(1);
    int flags = fcntl(listenfd, F_GETFL);
    printf("\033[0;31m%s: %d\033[0m\n", __func__, flags & O_NONBLOCK);
    printf("\033[0;31m%s: listen_fd = %d\033[0m\n", __func__, listenfd);
    fcntl(listenfd, F_SETFL, O_NONBLOCK);
  }
#endif

  void *ptr = memset(&serv_addr, '0', sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(_port);

  int b = 0;
  while(bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr))==-1){
      b++;
      if(b>100) break;
      serv_addr.sin_port = htons(++_port);
  }
  if(b>100)
    errorcall(R_NilValue, "[c] bind: %s", strerror(errno));

  if(listen(listenfd, T_maxPendingConnections)==-1)
      errorcall(R_NilValue, "[c] bind: %s\n", gai_strerror(errno));

//  printf("listenfd: %d\n", listenfd);
//  printf("port: %d\n", _port);

  *port = _port;
  return listenfd;
}

int server_accept(int listenfd, struct sockaddr_in *pclientAddr)
{
//  struct sockaddr_in clientAddr;
  socklen_t addrlen = sizeof(struct sockaddr_in);

  //int connfd = accept(listenfd, (struct sockaddr*) &clientAddr, &addrlen);
  int connfd = accept(listenfd, (struct sockaddr*) pclientAddr, &addrlen);

  if(connfd==-1) {
          printf("connfd==-1!\n\tlistenfd=%d\n\t%s\n",
                         listenfd, strerror(errno));
//          print_caller_info(0);
//          print_caller_info(1);
    return connfd;
  } else {
    //printf("\tsin_family = %d (short AF_INET=%d)\n", clientAddr.sin_family,
    //printf("\tsin_family = %d (short AF_INET=%d)\n", pclientAddr->sin_family, AF_INET);
    //printf("\tsin_port = %u (unsigned short)\n", clientAddr.sin_port);
    //printf("\tsin_port = %u (unsigned short)\n", pclientAddr->sin_port);
    //char *ip = inet_ntoa(clientAddr.sin_addr);
    char *ip = inet_ntoa(pclientAddr->sin_addr);
    //printf("\tip in dots-and-numbers format = %s\n", ip);
    char hostname[1024];
    char service[1024];
    //getnameinfo((const struct sockaddr *)&clientAddr,
    getnameinfo((const struct sockaddr *)pclientAddr,
                   sizeof(struct sockaddr_in),
                   hostname, 128,  service, 128, 0);
    //printf("\thostname:  %s\n", hostname);
    //printf("\tservice:   %s\n", service); // e.g., "http"
  }
  return connfd;
}


int socket_client(const char *hostname, int port_int)
{
  char port[8];
  sprintf(port, "%d",  port_int);

  struct hostent *he = gethostbyname(hostname);

  if(he == NULL){
      errorcall(R_NilValue, "[%d] [c] gethostbyname(%s): %s\n", getpid(),
                     hostname, gai_strerror(errno));
  }

  struct addrinfo hints;
  struct addrinfo *result, *rp;

  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_INET;    // Allow IPv4 or IPv6 
  hints.ai_socktype = SOCK_STREAM; // Datagram socket //
  hints.ai_flags = AI_PASSIVE;    // For wildcard IP address
  hints.ai_protocol = 0;

  int s = getaddrinfo(hostname, port, &hints, &result);
  if(s!=0) {
//    pthread_mutex_unlock(&socket_client_mutex);
    errorcall(R_NilValue, "[c] getaddrinfo: %s\n", gai_strerror(s));
  }

  int sockfd = 0;
  for (rp = result; rp != NULL; rp = rp->ai_next) {
    sockfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
    if (sockfd  == -1) continue;
    if (connect(sockfd, rp->ai_addr, rp->ai_addrlen) != -1) break;
    close(sockfd);
  }

  return sockfd;
}
*/

/*
typedef struct socket_conn_struct {
  int fd;
  int endian;
  int native_endian;
} socket_conn_t;
*/

static void SUPR_socket_finalizer(SEXP s)
{
  socket_conn_t *s_conn = (socket_conn_t *) R_ExternalPtrAddr(s);
  close(s_conn->fd);
  free(s_conn);
}

extern int socket_client(const char *, int);

SEXP SUPR_socketConnect(SEXP hostname, SEXP port, SEXP endian_str)
{
  int socket_fd = socket_client( CHAR(STRING_ELT(hostname,0)),
		 INTEGER(port)[0]);

  int native_endian = -1;
  int endian = LITTLE_ENDIAN;
  if(native_endian == -1){
    unsigned int i = 1;
    char *c = (char*) &i;
    native_endian = (*c) ? LITTLE_ENDIAN : BIG_ENDIAN;
    endian = native_endian;

  }

  if(TYPEOF(endian_str) != NILSXP){
    if(strcmp(CHAR(STRING_ELT(endian_str, 0)), "little")==0)
	    endian = LITTLE_ENDIAN;
    else if(strcmp(CHAR(STRING_ELT(endian_str, 0)), "big")==0)
	    endian = BIG_ENDIAN;
    else errorcall(R_NilValue, "unknown 'endian'"); 
  }

  socket_conn_t *s_conn = malloc(sizeof(socket_conn_t));
  s_conn->fd = socket_fd;
  s_conn->endian = endian;
  s_conn->native_endian = native_endian;
  
  SEXP conn = PROTECT(R_MakeExternalPtr(s_conn, R_NilValue, R_NilValue));
  setAttrib(conn, R_ClassSymbol, mkString("suprSocketConnection"));
  R_RegisterCFinalizerEx(conn, SUPR_socket_finalizer, TRUE);

  UNPROTECT(1);
  return conn;
}

#include <endian.h>
#include <stdint.h>
//#define LITTLE_ENDIAN 0
//#define BIG_ENDIAN 1
// java use endian = "big" as default endian
SEXP SUPR_socketWrite(SEXP conn, SEXP x, SEXP endian_str)
{
  socket_conn_t *s_conn = (socket_conn_t *) R_ExternalPtrAddr(conn);
  int endian = s_conn->endian;
  int native_endian = s_conn->native_endian;

  if(TYPEOF(endian_str) != NILSXP){
    if(strcmp(CHAR(STRING_ELT(endian_str, 0)), "little")==0)
	    endian = LITTLE_ENDIAN;
    else if(strcmp(CHAR(STRING_ELT(endian_str, 0)), "big")==0)
	    endian = BIG_ENDIAN;
    else errorcall(R_NilValue, "unknown 'endian'"); 

    s_conn->endian = endian;
  }

  int fd = s_conn->fd;
  printf("[%s] x = ", __func__);
  PrintValue(x);

  int size = 0;
  switch(TYPEOF(x)){
    case INTSXP: // fixme
         { 
           int n = LENGTH(x);
	   if(endian != native_endian) {
	     if(endian == BIG_ENDIAN) {
               for(int i=0; i<n; i++) INTEGER(x)[i] = htobe32(INTEGER(x)[i]);
	     } else {
               for(int i=0; i<n; i++) INTEGER(x)[i] = htole32(INTEGER(x)[i]);
	     }
	   }
	   size = write(fd, INTEGER(x), n*sizeof(int));
	 }
	 break;
    case SYMSXP: // as char * or java.lang.String
         { 
	
	   {
           const char *name = CHAR(PRINTNAME(x));
	   int len = strlen(name); // + 1;
	   int intVal = len;
	   if(endian != native_endian) {
             intVal = endian == BIG_ENDIAN ? htobe32(intVal) : htole32(intVal);
	   }
	   printf("[%s] Sent intVal = %d\n", __func__, intVal);
	   size = write(fd, &intVal, sizeof(int));
	   size += write(fd, name, len);
	   }
	   
		 /*
           const char *name = CHAR(PRINTNAME(x));
	   int n = strlen(name);
	   int size = SUPR_HEADER_SIZE + n;
	   size = endian == BIG_ENDIAN ?  htobe32(size) : htole32(size);
	   write(fd, &size, sizeof(int));

           unsigned char buf[SUPR_HEADER_SIZE];
           supr_header_t *h = (supr_header_t *) buf;
	   
	   h->id     = SUPR;
	   h->type   = SUPR_SYMSXP;
	   h->length = n;
	   h->padding= 0;
	  
	   write(fd, h, SUPR_HEADER_SIZE);
	   write(fd, name, n);
	   */

	 }
	 break;

    case STRSXP: // fixme
         { 
           int n = LENGTH(x);

	   {
	     int size = SUPR_HEADER_SIZE;
	     for(int i=0; i<n; i++)
	       size += sizeof(int) + strlen(CHAR(STRING_ELT(x, i)));

	     printf("[%s] size = %d\n", __func__, size);

	     size = endian == BIG_ENDIAN ?  htobe32(size) : htole32(size);
	     write(fd, &size, sizeof(int));
	   }

	   // change java code to use native byte order ??

           unsigned char buf[SUPR_HEADER_SIZE];
           supr_header_t *h = (supr_header_t *) buf;
	   
	   h->id     = SUPR;
	   h->type   = SUPR_STRSXP;
	   h->length = n;
	   h->padding= 0;
	  
	   write(fd, h, SUPR_HEADER_SIZE);

	   for(int i=0; i<n; i++){
	     const char *str = CHAR(STRING_ELT(x, i));
             int len = strlen(str);
	     write(fd, &len, sizeof(int));
	     write(fd, str, len);
	   }
	 }
	 break;

    default:
       	 errorcall(R_NilValue, "not implemented");
	 break;
  }
  return ScalarInteger(size);
}

SEXP SUPR_socketRead(SEXP conn, SEXP what, SEXP _n, SEXP endian_str)
{
	// checking ...
  socket_conn_t *s_conn = (socket_conn_t *) R_ExternalPtrAddr(conn);
  
  int endian = s_conn->endian;
  int native_endian = s_conn->native_endian;

  if(TYPEOF(endian_str) != NILSXP){
    if(strcmp(CHAR(STRING_ELT(endian_str, 0)), "little")==0)
	    endian = LITTLE_ENDIAN;
    else if(strcmp(CHAR(STRING_ELT(endian_str, 0)), "big")==0)
	    endian = BIG_ENDIAN;
    else errorcall(R_NilValue, "unknown 'endian'"); 

    s_conn->endian = endian;
  }

  int fd = s_conn->fd;

  int n = INTEGER(_n)[0];
  SEXP val = R_NilValue;
  size_t size;

  switch(TYPEOF(what)){
    case INTSXP:
         { 
           val = PROTECT(allocVector(INTSXP, n));
	   void *p = DATAPTR(val);
	   size_t i=0;
	   size = n*sizeof(int);
	   do {
	     i += read(fd, p+i, size-i);
	   } while(i < size);

	   if(endian != native_endian) {
	     if(endian == BIG_ENDIAN) {
               for(int i=0; i<n; i++)
		       INTEGER(val)[i] = be32toh(INTEGER(val)[i]);
	     } else {
               for(int i=0; i<n; i++) {
		       INTEGER(val)[i] = le32toh(INTEGER(val)[i]);
	       }
	     }
	   } 
	 }
	 break;
    default:
       	 errorcall(R_NilValue, "not implemented");
	 break;
  }
  UNPROTECT(1);
  return val;
}

size_t __rjni_read__(int fd, void *ptr, size_t size)
{
  size_t len = 0;
  for(; len < size; ){
    int n = read(fd, ptr + len,  size - len);
    if(n == -1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  return len;
}

size_t (*__read__)(int, void *, size_t) = __rjni_read__;


SEXP SUPR_socketReadObject(SEXP conn, SEXP env)
{
  socket_conn_t *s_conn = (socket_conn_t *) R_ExternalPtrAddr(conn);
  int fd = s_conn->fd;

  unsigned char buf[SUPR_HEADER_SIZE];
  __read__(fd, buf,  SUPR_HEADER_SIZE);
  /*
  int len  = 0;
  for(; len <SUPR_HEADER_SIZE; ){
    int n = read(fd, buf,  SUPR_HEADER_SIZE - len);
    if(n==-1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  */

  supr_header_t *h = (supr_header_t *) buf;
  if(h->id != SUPR) sys_error();

  SEXP val=R_NilValue;

//  printf("[%s] type = %d\n", __func__, h->type);

  switch(h->type){

    case SUPR_SYMSXP:
	 { int len = h->length;
	   char b[len];
	   __read__(fd, b,  len);
	   if(b[len-1]) sys_error();
	   val = install(b);
	 }
	 break;

    case SUPR_INT_ARRAY: //INTSXP:
	 { int len = h->length;
	   val = allocVector(INTSXP, len);
	   __read__(fd, DATAPTR(val),  len*sizeof(int));
	 }
	 break;

    //case SUPR_RAWSXP:
    case SUPR_SERIALIZED_ROBJ:
	 { int len = h->length;
	   val = PROTECT(allocVector(RAWSXP, len));
	   __read__(fd, DATAPTR(val),  len);
	   SEXP call = PROTECT(LCONS(install("unserialize"),
				   CONS(val, R_NilValue)));
	   val = eval(call, env);
	   UNPROTECT(2);
	 }
	 break;

    case SUPR_NILSXP: //INTSXP:
	 break;

    default:
	 errorcall(R_NilValue, "not implemented type (%d)", h->type);
         break;
  }

  return val;
}

SEXP socketReadDCLEvent(SEXP socket_conn, SEXP env)
{
    SEXP n     = PROTECT(SUPR_socketReadObject(socket_conn, env));
    //printf("[%s] sequence id = ",__func__); PrintValue(n);
    if(TYPEOF(n) == NILSXP)
    {
	    UNPROTECT(1);
	    return R_NilValue;
    }
    SEXP jobj  = PROTECT(SUPR_socketReadObject(socket_conn, env));
    SEXP name  = PROTECT(SUPR_socketReadObject(socket_conn, env));
    SEXP value = PROTECT(SUPR_socketReadObject(socket_conn, env));
//    printf("[%s] value = ",__func__); PrintValue(value);

    SEXP event = PROTECT(allocVector(VECSXP, 4));
    SEXP names = PROTECT(allocVector(STRSXP, 4));

    SET_VECTOR_ELT(event, 0, n);
    SET_VECTOR_ELT(event, 1, jobj);
    SET_VECTOR_ELT(event, 2, name);
    SET_VECTOR_ELT(event, 3, value);

    SET_STRING_ELT(names, 0, mkChar("n"));
    SET_STRING_ELT(names, 1, mkChar("object"));
    SET_STRING_ELT(names, 2, mkChar("name"));
    SET_STRING_ELT(names, 3, mkChar("value"));

    setAttrib(event, R_NamesSymbol, names);
    setAttrib(event, R_ClassSymbol, mkString("DCLeven"));
    UNPROTECT(6);
    return event;
}

  
SEXP SUPR_socketClose(SEXP conn)
{
  //close(INTEGER(conn)[0]);
  socket_conn_t *s_conn = (socket_conn_t *) R_ExternalPtrAddr(conn);
  close(s_conn->fd);
  s_conn->fd = -1;

  return R_NilValue; 
}

/*
typedef struct sync_info_struct {
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  void (*run)(void *data);
  void *data;
  sem_t		  sem_wait; 
  sem_t           sem_notify;
} sync_info_t;


void *monitorRun(void *arg)
{
  sync_info_t *info = (sync_info_t *) arg;

  printf("2: WAIT (1)...\n");
  pthread_mutex_lock(&info->mutex);
  printf("3: CONTINUE(1)...\n");

    printf("4: run/WAIT (2)...\n");
    info->run(info->data); //sem_wait(&info->sem_notify);
    pthread_cond_signal(&info->cond);
    //printf("CONTINUE(2)...\n");

  pthread_mutex_unlock(&info->mutex);
}
*/

/*
int monitorThread(pthread_t *thread, sync_info_t *info)
{
//  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  void *arg[] = {data, &sem};
  //int rc = pthread_create(&thread, NULL, monitorRun, arg);
  int rc = pthread_create(thread, NULL, monitorRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);
  return rc;
}
*/


/*
void wrapped_sem_wait(void *data)
{
  sem_t *sem = (sem_t *) data;
  sem_wait(sem);
}

void wrapped_sem_post(void *data)
{
  sem_t *sem = (sem_t *) data;
  sem_post(sem);
}
*/


//#define dupstr(str)  memcpy(malloc(strlen(str)+1), str, strlen(str)+1)

supr_xterm_t *supr_xterm3(const char *name, char **args, int new_window);
supr_xterm_t *supr_xterm2(const char *name, char **args)
{
  
  int new_window = FALSE;
  for(int i=0; args[i]; i++){
      if(strcmp(args[i], "--window")==0){
        new_window = TRUE;
        //for(; args[i]; i++) args[i] = args[i+1];
	break;
      }
  }

  return supr_xterm3(name, args, new_window);
}

supr_xterm_t *supr_xterm3(const char *name, char **args, int new_window)
{
 
  int rc;
  if(new_window){
    rc = setpgrp(); 
    if(rc == -1) 
      printf("Error: %s\n", strerror(errno));
  }

  supr_xterm_t *xterm = (supr_xterm_t *) malloc(sizeof(supr_xterm_t));

  // --geometry
//  char *_cmd = "gnome-terminal --hide-menubar --tab=SupR_Default --title \"TESTING\" -e pab -e 'sh -c \"pts gdm; sleep 10; exec bash\"' --tab --title \"SupR\" - e cat ";

//  char cmd[strlen(_cmd)+1024];
//  sprintf(cmd, "gnome-terminal --hide-menubar");

  xterm->pid = 0; // fixme
  xterm->ppid = 0;
  xterm->pts = NULL;
  xterm->fd0 = -1;
  xterm->fd1 = -1;
  xterm->fd2 = -1;

  // start a new window
  const char *terminal_cmd = "gnome-terminal --hide-menubar --geometry 80x24";
  //const char *window_with_profile = "--window-with-profile=Default"; 
  //const char *tab = "--tab-with-profile=Default"; // start a tab
  const char *window_with_profile = "--window"; 
  const char *tab = "--tab"; // start a tab
  const char *which = new_window ? window_with_profile : tab;

  size_t len = strlen("; exec bash\"")+1;
  len += strlen(terminal_cmd)+1;
  len += strlen(which)+1;
  len += strlen(name)+1;
  len += strlen(" %s --title \"%s\" -- bash -c \"")+1;
  for(int i=0; args[i]; i++) len += strlen(args[i])+1;

  char cmd[len];

  //sprintf(cmd, "%s %s --title \"%s\" -- bash -c \"", terminal_cmd, which, name);
  sprintf(cmd, "%s %s --title \"%s\" -- sh -c \"", terminal_cmd, which, name);

  for(int i=0; args[i]; i++)
    sprintf(cmd+strlen(cmd), " %s", args[i]);

#define NOT_KEEP_ALIVE
#ifdef  KEEP_ALIVE
  sprintf(cmd+strlen(cmd), "; exec bash\"");
#else
  //sprintf(cmd+strlen(cmd), "\"'");
  sprintf(cmd+strlen(cmd), "\"");
#endif

  //printf("\r\033[0;37m\033[0;31mcmd: %s\033[0m\n", cmd);
  //rc = system(cmd);
  rc = execl("/bin/sh", "sh", "-c", cmd, (char*) NULL);

  // The exec() functions return only if an error has occurred.

  
  printf("\r\033[0;37m[%s] \033[0;31mcmd: %s, rc: %d\033[0m\n", __func__,
		  cmd, rc);

  return xterm;
}


// use_tty is optional
// returns a mmap_io_t, socket_conn_t, or shm_io_t pointer
// as required by execl
// argv[0] must be the absolute path of the command
// argv[1] must be the name of the command
// change use_tty to use_window
int SuprNode_create(const char *name, char **argv, int use_tty,
	       	double timeout, void **retval)
{
  int argc = 0;
  char *mmap_io_name = NULL;
  char *shm_io_name = NULL;
  char *host_name = NULL; // TODO

  mmap_io_t *mmap_io = NULL;
  shm_io_info_t *shm_io = NULL;

  if(!argv[0] || !argv[1]) {
	  return -1; // set errno?
  }
//  char *cmd = argv[1]; FIXME...

  char *_stdout = NULL;

  //printf("[%s] argv:\n", __func__);
  for(; argv[argc]; argc++) {
     if(strcmp(argv[argc], "-mm")==0){
    //   printf("\t%s %s\n", argv[argc], argv[argc+1]);
       mmap_io_name = argv[++argc];
     } else if(argv[argc+1] && strcmp(argv[argc], "-shm")==0){
       //printf("\t%s %s\n", argv[argc], argv[argc+1]);
       shm_io_name = argv[++argc];
     } else if(strcmp(argv[argc], "-host")==0){
       //printf("\t%s %s\n", argv[argc], argv[argc+1]);
       host_name = argv[++argc];
     } else if(argv[argc+1] && strstr(argv[argc], "stdout")){
       _stdout = argv[++argc];
     } else if(strcmp(argv[argc], "--window")){
       _stdout = argv[argc];
     } else {
       //printf("\t%s\n", argv[argc]);
     }
  }

  if(mmap_io_name){
    mmap_io = mmap_io_create(mmap_io_name);
    pthread_mutex_lock(&mmap_io->lock);
  }
  if(shm_io_name){
    size_t block_size = 8*sysconf(_SC_PAGE_SIZE); // FIXME
    shm_io = shm_io_create(shm_io_name, block_size);
    //shm_io->in->pid = getpid();
  }

  pid_t pid = fork();


  if(pid){
    int rc = 0;
    if(mmap_io_name){
      if(timeout > 0){
	struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        wait.tv_sec += (long) timeout;
	//printf("\t[%s] %d Wait ...\n", __func__, getpid());
        rc = pthread_cond_timedwait(&mmap_io->cond, &mmap_io->lock, &wait);
      } else {
	//printf("\t[%s] %d Wait ...\n", __func__, getpid());
        rc = pthread_cond_wait(&mmap_io->cond, &mmap_io->lock);
      }
      if(retval) *retval = mmap_io;
    } else if(shm_io_name){
      if(timeout > 0){
        struct timespec ts;
       	if (clock_gettime(CLOCK_REALTIME, &ts) == -1)
	{
       	  printf("[%s] Error: clock_gettime, %s", __func__, strerror(errno));
	}
       	ts.tv_sec += (long) timeout;
	
	//printf("\t[%s] %d Wait ...\n", __func__, getpid());

       	rc = sem_timedwait(&shm_io->in->sem_wait, &ts);
	if(rc && Supr_verbose){
          printf("rc: %d, err: %s\n", rc, strerror(errno));
	}
      } else {
	//printf("\t[%s] %d Wait ...\n", __func__, getpid());
       	rc = sem_wait(&shm_io->in->sem_wait);
      }
      if(retval) *retval = shm_io;
    } else {
      if(retval) *retval = NULL;
    }
    //printf("Return, rc: %d, shm_io: %p\n\n", rc, shm_io);
    return rc;
  }

  supr_thread_t *cth = currentThread();
  if(cth){
    cth->ptid = pthread_self();
    cth->pid = getpid();
    cth->tid = syscall(SYS_gettid);
    free(cth->name);
    char buf[256];
    sprintf(buf, "Thread.%d", cth->tid);
    cth->name = strdup(buf);
    main_thread = cth;
  }

  Supr_verbose = FALSE;

  /*
  if(_stdout && strlen(_stdout) && strcmp(_stdout, "--window")){ // fixme?
    char *path = argv[0]; // printf("path: %s\n", path);
  // remove argv[0] from argv;
    for(int i = 0; argv[i]; ) {
      argv[i] = argv[++i]; // printf("argv[%d] %s\n", i, argv[i]);
    }
    int rc = execv(path, argv);

    printf("[%s] name: %s, rc =  %d, %s\n", __func__, name, rc, strerror(errno));

    //return 0; // exit(0);
    exit(0);
  }
  */

#define USE_TTY 1

  //use_tty = strcmp(_stdout, "--window")==0 ? USE_TTY : 0; // FIXME

  int use_window = use_tty;

  switch(use_tty){
    case USE_TTY:
         {
	   errno = 0;
    	   int rc = isatty(STDOUT_FILENO);
           if(errno) {
             printf("[%s] Error: %s STDOUT_FILENO: %d (%s:%d)\n", __func__,
                          strerror(errno), STDOUT_FILENO,
                          __FILE__, __LINE__);
             use_window = FALSE;
	     break;
	   }

	   if(rc){
	     char buf[PATH_MAX];
	     int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
	     if(rc) {
	       printf("[%s] Error: %s (%s:%d)\n", __func__, strerror(errno),
                          __FILE__, __LINE__);
               use_window = FALSE;
	       break;
	     }
//	     printf("ttyname: %s\n", buf);
	   }

	   // remove argv[1] from argv;
	   for(int i = 1; argv[i]; ) argv[i] = argv[++i];

//	   printf("\t[%s] %d Call supr_xterm2\n", __func__, getpid());
	   supr_xterm_t *xterm = supr_xterm3(name, argv, use_window);
	   printf("\033[0m\n");
	   if(xterm) {
//	     printf("[%s] name: %s, xterm =  %p\n", __func__, name, xterm);
	   } else {
	     printf("[%s] name: %s, xterm =  %p, %s\n", __func__, name, xterm,
             	strerror(errno));
	   } 
	 }
// printf("[%s] %d %ld EXIT\n", __func__, getpid(), syscall(SYS_gettid));
	 exit(0); // no return

    default: break;
  }
#undef USE_TTY

  char *path = argv[0];
  // remove argv[0] from argv;
  for(int i = 0; argv[i]; ) argv[i] = argv[++i];
  int rc = // execl
	  execv(path, argv);

  printf("[%s] name: %s, rc =  %d, %s\n", __func__, name, rc, strerror(errno));

  return 0; // exit(0);

}



supr_xterm_t *supr_xterm(const char *name) // FIXME
{
  supr_xterm_t *xterm = (supr_xterm_t *) malloc(sizeof(supr_xterm_t));

  char *_cmd = "gnome-terminal --hide-menubar --tab=SupR_Default --title \"TESTING\" -e pab -e 'sh -c \"pts gdm; sleep 10; exec bash\"' --tab --title \"SupR\" - e cat ";
  char cmd[strlen(_cmd)+1024];
  sprintf(cmd, "gnome-terminal --hide-menubar");

  xterm->pid = 0;
  xterm->ppid = 0;
  xterm->pts = NULL;
  xterm->fd0 = -1;
  xterm->fd1 = -1;
  xterm->fd2 = -1;

  char shm_name[128];
  size_t segment_size = sysconf(_SC_PAGE_SIZE);
  sprintf(shm_name, "SUPR_%d_%d_DCL", geteuid(), getpid());
  //sprintf(cmd+strlen(cmd), " --tab=SupR_Default"
   //                 " -e 'sh -c \"RTaskRunner -DCL -name %s; exec bash\"'", name); // ???

  sprintf(cmd+strlen(cmd), " --tab=SupR_Default"
                    " -e 'sh -c \"RTaskRunner -DCL -shm %s -name %s\"'",
		   shm_name, name); // ???
  printf("\r\033[0;37m[%s] cmd: %s\n", __func__, cmd);
  printf("[%s] segment_size: %ld\n", __func__, segment_size);

  void *mem_ptr = rjni_shm_create(shm_name, segment_size);

  /*
  {
	  size_t size;
	  void *p = rjni_shm_open(shm_name, &size);
          printf("[%s] size: %ld, p = %p\n", __func__, size, p);
  }
  */

  sem_t *sem_wr = (sem_t *) mem_ptr;

  sem_init(sem_wr, 1, 0);
  pid_t pid = getpid();
  memcpy(sem_wr+1, &pid, sizeof(pid_t));

  int rc;
  {
    rc = system(cmd); //using fork anyway...not good?
    if(rc!=0) perror(cmd);

    struct timespec ts;
    if (clock_gettime(CLOCK_REALTIME, &ts) == -1)
        errorcall(R_NilValue, "clock_gettime");
    ts.tv_sec += 30;

    rc = sem_timedwait(sem_wr, &ts);
    //rc = sem_wait(sem_wr);

    pid = ((pid_t*)(sem_wr+1))[0];
    printf("DCL.pid = %d, RDriver.pid = %d\n", pid, getpid());

    sem_destroy(sem_wr);
    munmap(mem_ptr, segment_size);
    unlink(shm_name);
  }
  
  printf("\r\n\033[0m");
 // printf("pid = %d\n", ((pid_t*)(sem_wr+1))[0]);


/*
  {
    sync_info_t *info = (sync_info_t *) mem_ptr;
    pthread_mutex_init(&info->mutex, NULL);
    pthread_cond_init(&info->cond, NULL);
    sem_init(&info->sem_wait, 1, 0);
    sem_init(&info->sem_notify, 1, 0);

    pid_t pid = getpid();
    memcpy(info+1, &pid, sizeof(pid_t));

    info->run  = wrapped_sem_post;
    info->data = &info->sem_wait;

    pthread_mutex_lock(&info->mutex);

      rc = system(cmd); //using fork anyway...not good?
      if(rc!=0) perror(cmd);

      pthread_t thread;
      rc = pthread_create(&thread, NULL, monitorRun, info);
      if(rc!=0) perror(strerror(errno));

      printf("1: waiting...\n");

      rc = pthread_cond_wait(&info->cond, &info->mutex);
      if(rc != 0) errorcall(R_NilValue, "pthread_cond_wait");
      printf("continue (1)...\n");

      rc = sem_wait(&info->sem_notify);
      if(rc != 0) errorcall(R_NilValue, "sem_wait");
      printf("5/6: continue (2)...\n");

      pid = ((pid_t*)(info+1))[0];
      printf("DCL.pid = %d, RDriver.pid = %d\n", pid, getpid());

    pthread_mutex_unlock(&info->mutex);

    pthread_mutex_destroy(&info->mutex);
    pthread_cond_destroy(&info->cond);
    sem_destroy(&info->sem_wait);
    sem_destroy(&info->sem_notify);

    munmap(mem_ptr, segment_size);
    unlink(shm_name);

  }
*/

  /*
  int value = 0;
  sem_t *sem = sem_open(shm_name, O_CREAT | O_EXCL, 0600, value);
  if(sem == SEM_FAILED && errno == EEXIST)
          sem = sem_open(name, O_EXCL);

  if(sem == SEM_FAILED) {
          printf("Error: sem_open, %s\n", strerror(errno));
          errorcall(R_NilValue, "sem_open, %s:%d", __FILE__, __LINE__);
  }

  rc = sem_timedwait(sem, &ts);

  if(rc == 0){
          printf("Good: closing sem\n");
	  sem_close(sem);
	  sem_unlink(shm_name);
  }

  */

/*
  xterm->shm_name = dupstr(shm_name);
  xterm->segment_size = segment_size;
  xterm->mem_ptr = mem_ptr;
  */
  xterm->shm_name = NULL;
  xterm->segment_size = 0;
  xterm->mem_ptr = NULL;

  /*
  rc = system(cmd); //using fork anyway...not good?
  if(rc!=0) perror(cmd);
  */

  //munmap(mem_ptr, segment_size);
  // shm_unlink(shm_name);

  return xterm;
}

extern SEXP RList_findVar(const char *name, SEXP list);
/*
static SEXP RList_findVar(const char *name, SEXP list)
{
  if(TYPEOF(list) != LISTSXP) 
	  return R_UnboundValue;

  while(list != R_NilValue){
    if(TAG(list) != R_NilValue
       && strcmp(CHAR(PRINTNAME(TAG(list))), name)==0)
	    return CAR(list);
    list = CDR(list);
  }
  return R_UnboundValue;
}
*/

SEXP Thread_openXTerm(SEXP args)
{
  SEXP tty = RList_findVar("tty", args);

  if(tty != R_UnboundValue){
    //int fd = open(CHAR(asChar(tty)), O_RDWR);
    int fd = open(CHAR(asChar(tty)), O_WRONLY);
    if(fd==-1) printf("Error: %s\n", strerror(errno));
    int dup_fd = dup2(fd, STDOUT_FILENO);
    if(dup_fd==-1) printf("Error: %s\n", strerror(errno));
    dup_fd = dup2(fd, STDERR_FILENO);
    if(dup_fd==-1) printf("Error: %s\n", strerror(errno));

    fd = open(CHAR(asChar(tty)), O_RDONLY);
    dup_fd = dup2(fd, STDIN_FILENO);
    if(dup_fd==-1) printf("Error: %s\n", strerror(errno));
    /*
    dup2(0, fd);
    dup2(1, fd);
    dup2(2, fd);
    */
    printf("Okay?\n");
    return R_NilValue;
  }


  int pid = fork();

  if(pid) return ScalarInteger(pid);

  execl("/usr/bin/gnome-terminal", "gnome-terminal", NULL);


  return R_NilValue;
  // echo hello >/dev/pts/14
  // cat /dev/pts/14
  // find a program's tty???
}

/* Do Supr.sink(), similar to
   sink(file = NULL, append = FALSE, type = c("output", "message"),
    split = FALSE)
?
*/

/*
SEXP Supr_sink(SEXP file, SEXP append, SEXP type, SEXP split)
{
  error(_("unimplemented"));
}
*/

#define _(s) (s)

static void Xterm_SigactionInt(int sig, siginfo_t *ip, void *context)
{
    //fprintf(stderr, "\033[0;32m[%s] sig: %d\033[0m\n", __func__, sig);
}

extern SEXP Supr_addDevice(SEXP device); // pts ... FIXME

// start an xterm with the cmd xterm
SEXP Supr_xterm(SEXP args)
{
  char template[128];
  sprintf(template, "/tmp/supr_XXXXXX");
  int fd = mkstemp(template);
  if(fd == -1)
	  error(_("mkstemp, %s"), strerror(errno));

  struct sigaction oldIntAct;

  struct sigaction sa;
  sa.sa_sigaction = Xterm_SigactionInt;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_ONSTACK | SA_SIGINFO;

  sigaction(SIGINT, &sa, NULL);

  int pid = fork();

  if(pid) {
	  /*
    int status;
    int rc = waitpid(pid, &status, 0);
    if(rc != pid || status!=0)
      error(_("waitpid, status: %d, %s"), status, strerror(errno));
      */
    //fprintf(stderr, "%d is waiting for %d to interrupt...\n", getpid(), pid);
    int timeout = 120; 
    unsigned int seconds_left = sleep(timeout);
    if(seconds_left==0){
      close(fd);
      unlink(template);
      sigaction(SIGINT, &oldIntAct, NULL);
      error(_("timeout (%s sec)"), timeout);
    }
    //fprintf(stderr, "continue\n");

    SEXP retval = R_NilValue;
    //int _fd = open(template, O_RDONLY);
    //close(fd);
    //fd = _fd;
    struct stat sb;
    while(retval  == R_NilValue){
      if(fstat(fd, &sb)!=-1){
	    char buf[sb.st_size+1];
	    if(sb.st_size == 0) {
		sleep(1);
    		//int _fd = open(template, O_RDONLY);
    		//close(fd);
    		//fd = _fd;
		continue;
	    }
            //fprintf(stderr, "template: %s\n", template);
            //fprintf(stderr, "sb.st_size: %ld\n", sb.st_size);
	    //off_t pos = lseek(fd, 0, SEEK_CUR);
            //fprintf(stderr, "pos: %ld\n", pos);
	    lseek(fd, 0, SEEK_SET);
	    read(fd, buf, sb.st_size);
	    buf[sb.st_size] = 0;
	    char *s = strstr(buf, "\n");
	    if(s) *s = 0;
	    retval = mkString(buf);
	    int pid = atoi(s+1);
	    setAttrib(retval, install("pid"), ScalarInteger(pid));
	    Supr_addDevice(retval);
      }
    }
    close(fd);
    unlink(template);
    sigaction(SIGINT, &oldIntAct, NULL);

    return retval;
  } else {

    //execl("/usr/bin/gnome-terminal", "gnome-terminal", NULL);
    //fprintf(stderr, "\033[0;31mtemplate: %s\n\033[0m", template);
    close(fd);
    //char *format = "'/usr/bin/tty >> %s; cat %s; kill -INT %d; bash'";
    char *format = "/bin/sh -c '/usr/bin/tty >> %s; echo $$ >> %s; kill -INT %d;"
	   	" bash'";
    char cmd[strlen(format)+ 2 * strlen(template)+1+32];
    sprintf(cmd, format, template, template, getppid());

    SEXP xterm = RList_findVar("xterm", args);

    if(xterm != R_UnboundValue){
      const char *file = CHAR(asChar(xterm));
      const char *s = file;
      while(s && strstr(s, "/")) s = strstr(s, "/") + 1;
      if(strcmp(s, "gnome-terminal")==0){
        //char *format = "/bin/csh -c \"/usr/bin/tty >> %s; /bin/cat %s; kill -INT %d; /bin/csh\"";
        //char cmd[strlen(format)+ 2 * strlen(template)+1+32];
        //sprintf(cmd, format, template, template, getppid());
	      /*
        char *format = "/bin/csh";
        char cmd[strlen(format)+ 2 * strlen(template)+1+32];
        sprintf(cmd, format);
        execl(file, s, "--", cmd, (char*) NULL);
	*/
 
        //char *format = "%s -- /bin/sh -c \"/usr/bin/tty >> %s;"
	//	" kill -INT %d; /bin/sh\"";
        //char *format = "%s -- /bin/sh -c \"/usr/bin/tty >> %s;"
	//	" echo $$ >> %s; kill -INT %d; bash\"";
        char *format = "%s -- /bin/sh -c 'echo $$; /usr/bin/tty >> %s;"
		" echo $$ >> %s; kill -INT %d; bash'";
        char cmd[strlen(format)+ strlen(file)+2*strlen(template)+1+32];
        sprintf(cmd, format, file, template, template, getppid());
        //fprintf(stderr, "\033[0;31mxterm ... cmd: %s\n\033[0m", cmd);
	int rc = execl("/bin/sh", "sh", "-c", cmd, (char*) NULL);

      } else { // FIXME
        //fprintf(stderr, "\033[0;31mxterm ... cmd: %s\n\033[0m", cmd);
        execl(file, s, "-e", cmd, (char*) NULL);
      }
    } else {
      //fprintf(stderr, "\033[0;31m[%d] xterm ... cmd: %s\n\033[0m", getpid(), cmd);
      int rc = execl("/usr/bin/xterm", "xterm", "-e", cmd, (char*) NULL);
      if(rc == -1){
        fprintf(stderr, "\033[0;31m[%d] xterm ... error: %s\n\033[0m", 
		     getpid(), strerror(errno));
      }
    }
    
    error(_("execl"));
    exit(EXIT_FAILURE);
  }

}







SEXP SUPR_dataChangeListener(SEXP name)
{
  pid_t getpid();
  //char buf[256];
  const char* cname = CHAR(STRING_ELT(name, 0));
  //sprintf(buf, "SUPR_%d_%d_%s", geteuid(), getpid(), cname);

  supr_xterm_t *xterm = supr_xterm(cname); // FIXME

  SEXP val = PROTECT(mkString(cname));
  SEXP ptr = PROTECT(R_MakeExternalPtr(xterm, R_NilValue, R_NilValue));
  setAttrib(val, install("dcl.addr"), ptr);
  setAttrib(val, R_ClassSymbol, mkString("dcl"));
  UNPROTECT(2);
  return val;
}


#define SEXP_OFFSET sizeof(SEXPREC_ALIGN)

#define USE_SUPR_SERIALIZE







// the size argument is used (yet?)
SEXP supr2r(supr_header_t *x, size_t size, SEXP env);

//#define DEBUG_SEGV

//#include <R_ext/Defn.h>
//#include <R_ext/Callbacks.h>
//#include "Defn.h"
//#include <setjmp.h>

//extern SEXP R_CStackStart;
extern unsigned long R_CStackStart;
extern unsigned long R_CStackLimit;
extern int R_Interactive;
extern void run_Rmainloop(void);
 
/*
static volatile JNIEnv *javaEnv = NULL;
static volatile jobject javaObj = NULL;
static volatile jobject javaCaller = NULL;
static volatile jclass callerClass = NULL;
*/
//static JNIEnv *javaEnv = NULL;
//static jobject javaObj = NULL;
//static jobject javaCaller = NULL;
//static jclass callerClass = NULL;
//static jclass rjniClass = NULL;

static SEXP TR_serialize(SEXP x, SEXP env);
static SEXP TR_unserialize(SEXP x, SEXP env);

void *SUPR_serialize(SEXP x, SEXP env, size_t *size);
SEXP SUPR_unserialize(void *x, SEXP env, size_t size);
// signal handlers
// sa.sa_sigaction = myR_SigactionSegv;

static  struct sigaction R_oldact;
static  struct sigaction R_oldactInt;
static  struct sigaction R_oldactUsr1;
static  struct sigaction Java_oldact;
//static  struct sigaction Java_oldactInt;
//static  struct sigaction Java_oldactUsr1;

//static int javaDriver_PID = 0; // change variable name...
//static int rDriver_PID = 0;
static pthread_t javaDriver_pthread_id = 0;
static pid_t javaDriver_pthread_tid = 0;

#define  BACKTRACE_SIZE 100
#include <execinfo.h>

void c_backtrace()
{
  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  fprintf(stderr, "\033[0;32m[Process %d (%ld)] C_backtrace :\033[0m\n",
		  getpid(), pthread_self());

  size = backtrace(array, BACKTRACE_SIZE); // return_addrs
  strings = backtrace_symbols(array, size);
  for (i = 1; i < size; i++) {
    fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
//    fprintf(stdout, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);

    if(i<1) {
      char *str = strdup(strings[i]);
      char *fname = strtok(str, "(");
      char *func = strtok(NULL, ")");
      char *na_addr = NULL;
      if(*func == '+') {
        na_addr = func+1;
	func = NULL;
      } else {
        for(na_addr = func; *na_addr; na_addr++){
		if(*na_addr=='+'){
		  *na_addr = 0;
		   na_addr++;
		   break;
		}
	}
      }

      // a hexadecimal offset into the function,

      char *return_addr = strtok(NULL, "[");
      return_addr = strtok(NULL, "]");

      // sscanf(pos, "%2hhx", );
      long a = strtol(na_addr, NULL, 16);
      long offset = a;

      fprintf(stderr, "from: %s, func: %s, na_addr: %s[%lx/%p], return_addr: %p\n", 
		      fname, func, na_addr,
		      strtol(na_addr, NULL, 16),
		      (void*)a,
		      array[i]);
      free(str);
      Dl_info info;
      void *r_addr = array[i] + offset;
      int rc = dladdr(r_addr, &info);
      if(rc) {
        printf("%p fname: %s, sname:%s\n", r_addr, info.dli_fname, info.dli_sname);
      } else {
        printf("Error: %s\n", dlerror());
      }
    }
  }
  free(strings);  // malloced by backtrace_symbols


}

void do_backtrace(void *data){
  //char **str_addr = (char**) data;

  vector_t *trace = (vector_t *) data;
  char buf[1024];

  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  size = backtrace(array, BACKTRACE_SIZE); // return_addrs
  strings = backtrace_symbols(array, size);
  for (i = 1; i < size; i++) {
    fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    vectorAdd(trace, strdup(strings[i]));
//    fprintf(stdout, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);

    if(i<1) {
      char *str = strdup(strings[i]);
      char *fname = strtok(str, "(");
      char *func = strtok(NULL, ")");
      char *na_addr = NULL;
      if(*func == '+') {
        na_addr = func+1;
	func = NULL;
      } else {
        for(na_addr = func; *na_addr; na_addr++){
		if(*na_addr=='+'){
		  *na_addr = 0;
		   na_addr++;
		   break;
		}
	}
      }

      char *return_addr = strtok(NULL, "[");
      return_addr = strtok(NULL, "]");

      long a = strtol(na_addr, NULL, 16);
      long offset = a;

      sprintf(buf, "from: %s, func: %s, na_addr: %s[%lx/%p], return_addr: %p\n", 
		      fname, func, na_addr,
		      strtol(na_addr, NULL, 16),
		      (void*)a,
		      array[i]);
//      vectorAdd(trace, strdup(buf));
      free(str);
      Dl_info info;
      void *r_addr = array[i] + offset;
      int rc = dladdr(r_addr, &info);
      if(rc) {
//        sprintf(buf, "%p fname: %s, sname:%s\n", r_addr, info.dli_fname, info.dli_sname);
      } else {
//        sprintf(buf, "Error: %s\n", dlerror());
      }
//      vectorAdd(trace, strdup(buf));
    }
  }
  free(strings);  // malloced by backtrace_symbols
}

int strbuf_put(char *buf, int pos, const char *x, int buf_size)
{
//fprintf(stderr, "[%s] x=%s\n", __func__, x);
   int k = strlen(x);
   char y[k+1];
   memcpy(y, x, k+1);
   int m = buf_size - pos - 2;
   if(m<=0) return pos;
   if(k>m) {
     y[m+1] = '0';
     k = m;
   }
   memcpy(buf+pos, y, strlen(y)+1);
//fprintf(stderr, "[%s] buf=%s\n", __func__, buf);
   return pos + strlen(y);
}

char *__r2str(SEXP x, char *buf, int buf_size, int debug)
{

  static int indentation = 0;

  int type = TYPEOF(x);
  int n=0;
  const char *c = type2char(type);
  if(debug){
    n = strbuf_put(buf, n, "(", buf_size);
    n = strbuf_put(buf, n, c, buf_size);
    n = strbuf_put(buf, n, ")", buf_size);
  }
  switch(type){
    case NILSXP:
	    {
              n = strbuf_put(buf, n, "NULL", buf_size);
	    }
	    break;
    case ENVSXP:
	    {
              n = strbuf_put(buf, n, "<environment>", buf_size);
	    }
	    break;
    case INTSXP:
	    {
	      int len = LENGTH(x);
	      for(int i=0; i<len; i++){
	        char b[32];
		sprintf(b, " %d", INTEGER(x)[i]);
                n = strbuf_put(buf, n, b, buf_size);
	      }
	    }
	    break;
    case REALSXP:
	    {
	      int len = LENGTH(x);
	      for(int i=0; i<len; i++){
	        char b[64];
		sprintf(b, " %f", REAL(x)[i]);
                n = strbuf_put(buf, n, b, buf_size);
	      }
	    }
	    break;
    case LGLSXP:
	    {
	      int len = LENGTH(x);
	      for(int i=0; i<len; i++){
	        char b[32];
		sprintf(b, " %s", INTEGER(x)[i]?"TRUE":"FALSE");
                n = strbuf_put(buf, n, b, buf_size);
	      }
	    }
	    break;
    case STRSXP:
	    {
	      int len = LENGTH(x);
              n = strbuf_put(buf, n, "[", buf_size);
	      for(int i=0; i<len; i++){
		if(i>0)
                  n = strbuf_put(buf, n, ", ", buf_size);
                n = strbuf_put(buf, n, "\"", buf_size);
                n = strbuf_put(buf, n, CHAR(STRING_ELT(x, i)), buf_size);
                n = strbuf_put(buf, n, "\"", buf_size);
	      }
              n = strbuf_put(buf, n, "]", buf_size);
	    }
	    break;
    case VECSXP:
	    { int len = LENGTH(x);
	      SEXP names = getAttrib(x, R_NamesSymbol);
              n = strbuf_put(buf, n, "[", buf_size);
	      for(int i=0; i<len; i++){
		if(i>0)
                  n = strbuf_put(buf, n, ", ", buf_size);
		if(TYPEOF(names)!=NILSXP){
		  const char* name = CHAR(STRING_ELT(names, i));
                  n = strbuf_put(buf, n, name, buf_size);
                  n = strbuf_put(buf, n, "=", buf_size);
		}
                char *b = __r2str(VECTOR_ELT(x,i), buf+n, buf_size-n, debug);
		n += strlen(b);
	      }
              n = strbuf_put(buf, n, "]", buf_size);
	    }
	    break;
    case DOTSXP:
              n = strbuf_put(buf, n, "...", buf_size);
	    break;
    case SYMSXP:
            n = strbuf_put(buf, n, CHAR(PRINTNAME(x)), buf_size);
	    break;
    case EXPRSXP:
	    {
                n = strbuf_put(buf, n, "\033[0;34m{\n", buf_size);
                char *b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		n += strlen(b);
                n = strbuf_put(buf, n, "\n...\n}\033[0m\n", buf_size);
	    }
	    break;
    case LANGSXP:
	    {
	      char *b;
	      if(TYPEOF(CAR(x))==SYMSXP){
	        if(strcmp(CHAR(PRINTNAME(CAR(x))), "=") == 0
                  ||(strcmp(CHAR(PRINTNAME(CAR(x))), "+") == 0 &&
			  TYPEOF(CDDR(x)) != NILSXP
		    )
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "::") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), ":::") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "==") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "!=") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "&&") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "||") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "<=") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), ">=") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "/") == 0
	          || strcmp(CHAR(PRINTNAME(CAR(x))), "*") == 0) { // fixme

                  b = __r2str(CADR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

                  n = strbuf_put(buf, n, " ", buf_size);
                  b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, " ", buf_size);

                  b = __r2str(CDDR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

		} else if(strcmp(CHAR(PRINTNAME(CAR(x))), "$") == 0
		   || strcmp(CHAR(PRINTNAME(CAR(x))), "[") == 0
		   || strcmp(CHAR(PRINTNAME(CAR(x))), "[[") == 0
				){
                  b = __r2str(CADR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

                  b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

                  b = __r2str(CDDR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

		  if(strcmp(CHAR(PRINTNAME(CAR(x))), "[") == 0)
                    n = strbuf_put(buf, n, "]", buf_size);
		  else if(strcmp(CHAR(PRINTNAME(CAR(x))), "[[") == 0)
                    n = strbuf_put(buf, n, "]]", buf_size);

		} else if(strstr(CHAR(PRINTNAME(CAR(x))), "<-")){
		      // fixme
                  b = __r2str(CADR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

                  n = strbuf_put(buf, n, " ", buf_size);
                  b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, " ", buf_size);

                  b = __r2str(CDDR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
		} else if(strcmp(CHAR(PRINTNAME(CAR(x))), "while")==0
		   || strcmp(CHAR(PRINTNAME(CAR(x))), "function")==0
				){
                  b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

                  n = strbuf_put(buf, n, "(", buf_size);
                  b = __r2str(CADR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, ")\n", buf_size);

                  //b = __r2str(CDDR(x), buf+n, buf_size-n, debug);
                  b = __r2str(CADDR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);

		  if(TYPEOF(CDDDR(x)) != NILSXP){
		     for(int i=0; i<indentation; i++)
                       n = strbuf_put(buf, n, "\t", buf_size);
                     n = strbuf_put(buf, n, "\033[0;37m# ignored (", buf_size);
                     n = strbuf_put(buf, n, type2char(TYPEOF(CDDDR(x))),
				     buf_size);
                     n = strbuf_put(buf, n, ") ", buf_size);
                     b = __r2str(CDDDR(x), buf+n, buf_size-n, debug);
		     n += strlen(b);
                     n = strbuf_put(buf, n, "\033[0m\n", buf_size);
		  }

		} else if(strcmp(CHAR(PRINTNAME(CAR(x))), "if")==0){
                  b = __r2str(CAR(x), buf+n, buf_size-n, debug); // if
		  n += strlen(b);

                  n = strbuf_put(buf, n, "(", buf_size); // cond
                  b = __r2str(CADR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, ")\n", buf_size);

                    b = __r2str(CADDR(x), buf+n, buf_size-n, debug);
		    n += strlen(b);

		  if(TYPEOF(CDDDR(x)) != NILSXP){
		    for(int i=0; i<indentation; i++)
                      n = strbuf_put(buf, n, "\t", buf_size);
                    n = strbuf_put(buf, n, "else", buf_size);

                    b = __r2str(CDDDR(x), buf+n, buf_size-n, debug);
		    n += strlen(b);
		  }

		} else if(strcmp(CHAR(PRINTNAME(CAR(x))), "{")==0){

		  for(int i=0; i<indentation; i++)
                    n = strbuf_put(buf, n, "\t", buf_size);
		  indentation ++;

                  n = strbuf_put(buf, n, "{\n", buf_size);

	          SEXP s = CDR(x);
	          while(TYPEOF(s)!=NILSXP) {

		    for(int i=0; i<indentation; i++)
                      n = strbuf_put(buf, n, "\t", buf_size);

	            if(TYPEOF(TAG(s)) != NILSXP)
		    { // uncommon?
                      char *b = __r2str(TAG(s), buf+n, buf_size-n, debug);
		      n += strlen(b);
                      n = strbuf_put(buf, n, "=", buf_size);
		    }

                    char *b = __r2str(CAR(s), buf+n, buf_size-n, debug);
		    n += strlen(b);

		    s = CDR(s);
                    n = strbuf_put(buf, n, "\n", buf_size); 
	          }

		  indentation --;
		  for(int i=0; i<indentation; i++)
                    n = strbuf_put(buf, n, "\t", buf_size);
                  n = strbuf_put(buf, n, "}\n", buf_size);

		} else if(strcmp(CHAR(PRINTNAME(CAR(x))), "!")==0){
                  n = strbuf_put(buf, n, "!", buf_size);
                  b = __r2str(CDR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
		} else {
			/*
                  n = strbuf_put(buf, n, "\033[0;31m [TODO:", buf_size);
                  b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, "] \033[0m", buf_size);
		  */

                  b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, "(", buf_size);
                  b = __r2str(CDR(x), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, ")", buf_size);
		}
	      } else {
                b = __r2str(CAR(x), buf+n, buf_size-n, debug);
		n += strlen(b);
                n = strbuf_put(buf, n, "(", buf_size);
                b = __r2str(CDR(x), buf+n, buf_size-n, debug);
		n += strlen(b);
                n = strbuf_put(buf, n, ")", buf_size);
	      }
	    }
	    break;
    case LISTSXP:
	    {
	      SEXP s = x;
	      while(TYPEOF(s)!=NILSXP) {
	        if(s != x)
		{
                  n = strbuf_put(buf, n, ", ", buf_size);
		}
	        if(TYPEOF(TAG(s)) != NILSXP)
		{
                  char *b = __r2str(TAG(s), buf+n, buf_size-n, debug);
		  n += strlen(b);
                  n = strbuf_put(buf, n, " = ", buf_size);
		}

                char *b = __r2str(CAR(s), buf+n, buf_size-n, debug);
		n += strlen(b);

		s = CDR(s);
	      }
	    }
	    break;
    default: 
	    {
		  char w[256];
		  sprintf(w, "<not implemented for type: %d, %s>", TYPEOF(x),
				  type2char(TYPEOF(x))); 
                  n = strbuf_put(buf, n, w, buf_size);
	    }
	    break;
  }
  return buf;
}

char *r2str(SEXP x, char *buf, int buf_size){
  return __r2str(x, buf, buf_size, 1);
}

extern char *info_addr;
extern supr_socket_conn_t *info_sc;
//extern int Supr_sendSimpleMessage(const char *msg, const char *color, int type, int level);


void  myR_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  if(info_addr){
    char msg[256];
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s] pid=%d, tid=%ld\033[0m\n",
                    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Supr_sendSimpleMessage(msg, "\033[0;31m", DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Supr_sendSimpleMessage(buf, "\033[0m", DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);
  exit(1);

}

void  myR_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  if(info_addr){
    char msg[256];
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s] pid=%d, tid=%ld\033[0m\n",
                    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Supr_sendSimpleMessage(msg, "\033[0;31m", DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Supr_sendSimpleMessage(buf, "\033[0m", DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);
  exit(1);

}



// backend
/*
void  myJava_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
		  __func__);
  c_backtrace();
  printf("\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
	  pthread_self());
  switch(ip->si_code){
    case SEGV_MAPERR:
         fprintf(stderr, "Address not mapped.\n");
         break;
    case SEGV_ACCERR:
         fprintf(stderr, "Access to this address is not allowed.\n");
         break;
    default:
         fprintf(stderr, "Unknown reason.\n");
         break;
  }
  //Java_oldact.sa_sigaction(sig, ip, context);
  exit(1);
}
*/

/*


void  SUPR_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  if(pthread_equal(pthread_self(), signalHandlerThread_ptid)){
    printf("\033[0;33m[INFO][%s] handlerThread_ptid=%ld\033[0m\n\n", __func__,
		  signalHandlerThread_ptid);
    supr_thread_t *th = currentThread();
    pthread_mutex_lock(&th->mutex);
      printf("[%s] currentThread: %s\n", __func__, objectToString(th));
    pthread_mutex_unlock(&th->mutex);
  } else {
    printf("\033[0;37m[INFO][%s] pthread_self()=%ld -> %ld\033[0m\n",
		    __func__, pthread_self(), signalHandlerThread_ptid);
    pthread_kill(signalHandlerThread_ptid, sig);
  }
}

void  SUPR_SigactionSIGUSR1(int sig, siginfo_t *ip, void *context)
{
 
}

*/

/*
SEXP R_setJavaDriverPID(SEXP pid){

  javaDriver_PID = INTEGER(pid)[0];
  rDriver_PID = getpid();

  return R_NilValue;
}
*/

/*
void printAllThreadStackTrace(){
  if(!*javaEnv) return;
  jclass tc = (*javaEnv)->FindClass(javaEnv, "Ljava/lang/Thread");
  if(tc==NULL){
    printf("[%s] cannot find Ljava/lang/Thread\n", __func__);
    return;
  }
  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "interrupt", "()V");
  if(midCallBack == NULL)
    printf("\033[0;31mmidCallBack = NULL\033[0m\n");
}
*/


/*
void  myR_SigactionInt(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<<<<\033[0m\n\n", __func__);
  printf("\n\033[0;31m[%s] interrupt \033[0m\n\n", __func__);
  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "interrupt", "()V");
  if(midCallBack == NULL){
    printf("\033[0;31mmidCallBack = NULL\033[0m\n");
  } else {
    (*javaEnv)->CallVoidMethod(javaEnv, javaCaller, midCallBack);
  }


  printf("\n\033[0;31m[%s] TODO\033[0m\n\n", __func__);

  //R_oldactInt.sa_sigaction(sig, ip, context);

}
*/

static void *rjni_getExternalPtr(const char *name, SEXP env);
/*
typedef struct socket_conn_struct {
  int fd;
  int endian;
  int native_endian;
} socket_conn_t;
*/

//#define   DRIVER_SYNC_NOTIFY  31
//#define   DRIVER_INTERRUPT  32

//static char jSyncObject[256] = {0};
// testing
/*

SEXP  socket_sync_interrupt(SEXP obj_ref)
{
  socket_conn_t *s_conn = (socket_conn_t *) // FIXME
	  rjni_getExternalPtr("socket.conn", R_GlobalEnv);

  //if(!jSyncObject) jSyncObject = "";
  const char *ref = jSyncObject;
  if(TYPEOF(obj_ref) == STRSXP)
    ref = CHAR(STRING_ELT(obj_ref,0));

  unsigned char buf[2*sizeof(int)+strlen(ref)];
  sprintf(buf+2*sizeof(int), "%s",ref);

  int *intVal = (int*) buf;
  intVal[0] =  DRIVER_INTERRUPT; // DRIVER_SYNC_NOTIFY;
  intVal[1] = (int) strlen(ref);

  if(s_conn->endian == BIG_ENDIAN) {
    printf("[%s] to BIG_ENDIAN\n", __func__);
    for(int i=0; i<2; i++)
      intVal[i] = htobe32(intVal[i]);
  } else {
    for(int i=0; i<2; i++)
      intVal[i] = htole32(intVal[i]);
  }

  printf("[%s] write (..., [%d, %d, ...]\n", __func__, intVal[0], intVal[1]);
  write(s_conn->fd, buf, sizeof(buf));

  printf("[%s] read an int value ....\n", __func__);
  size_t len = 0;
  size_t size = sizeof(int);
  while(len < size){
    len += read(s_conn->fd, buf+len, size-len);
  }
  printf("[%s] read (intVal = %d)\n", __func__, be32toh(*((int*)buf)));

  return R_NilValue; 
}

SEXP  socket_sync_notify(SEXP obj_ref)
{
  socket_conn_t *s_conn = (socket_conn_t *) // FIXME
	  rjni_getExternalPtr("socket.conn", R_GlobalEnv);

  //if(!jSyncObject) jSyncObject = "";
  const char *ref = jSyncObject;
  if(TYPEOF(obj_ref) == STRSXP)
    ref = CHAR(STRING_ELT(obj_ref,0));

  unsigned char buf[2*sizeof(int)+strlen(ref)];
  sprintf(buf+2*sizeof(int), "%s",ref);

  int *intVal = (int*) buf;
  intVal[0] =  DRIVER_SYNC_NOTIFY;
  intVal[1] = (int) strlen(ref);

  if(s_conn->endian == BIG_ENDIAN) {
    printf("[%s] to BIG_ENDIAN\n", __func__);
    for(int i=0; i<2; i++)
      intVal[i] = htobe32(intVal[i]);
  } else {
    for(int i=0; i<2; i++)
      intVal[i] = htole32(intVal[i]);
  }

  printf("[%s] write (..., [%d, %d, ...]\n", __func__, intVal[0], intVal[1]);
  write(s_conn->fd, buf, sizeof(buf));

  printf("[%s] read an int value ....\n", __func__);
  size_t len = 0;
  size_t size = sizeof(int);
  while(len < size){
    len += read(s_conn->fd, buf+len, size-len);
  }
  printf("[%s] read (intVal = %d)\n", __func__, be32toh(*((int*)buf)));

  return R_NilValue; 
}

*/

//static int R_isInterrupted = FALSE;
/*
void  R_SigactionInt(int sig, siginfo_t *ip, void *context)
{

  printf("\033[0;31m[%s] interrupt (kill %d)\033[0m\n", __func__, javaDriver_PID);
  //c_backtrace();

  R_isInterrupted = TRUE;

//#define TEST_SOCKET_NOTIFY
#ifdef TEST_SOCKET_NOTIFY
//  socket_sync_notify(R_NilValue);
  socket_sync_interrupt(R_NilValue);
#else
  //kill(javaDriver_PID, SIGUSR1);
  kill(javaDriver_PID, SIGUSR1);
#endif
  //kill(javaDriver_PID, SIGINT);
  
  sigaction(SIGINT, &R_oldactInt, NULL);
  //errorcall(R_NilValue, "Interrupted");
}
*/


#define SUPR_SIG_BLOCK(sig)     do      {       \
  sigset_t __mask__;    \
  sigset_t __orig_mask__;       \
  sigemptyset (&__mask__);      \
  sigaddset (&__mask__, (sig)); \
  if(sigprocmask(SIG_BLOCK, &__mask__, &__orig_mask__) < 0)     \
     errorcall(R_NilValue, "sigprocmask, %s", strerror(errno))

#define SUPR_SIG_UNBLOCK(sig)   \
  if(sigprocmask(SIG_SETMASK, &__orig_mask__, NULL) < 0)        \
     errorcall(R_NilValue, "sigprocmask, %s", strerror(errno)); \
} while(0)

#define RJNI_SIG_BLOCK(sig)     do      {       \
  sigset_t __mask__;    \
  sigset_t __orig_mask__;       \
  sigemptyset (&__mask__);      \
  sigaddset (&__mask__, (sig)); \
  if(sigprocmask(SIG_BLOCK, &__mask__, &__orig_mask__) < 0)     \
     fprintf(stderr, "sigprocmask, %s", strerror(errno));	\
  if(pthread_sigmask(SIG_BLOCK, &__mask__, &__orig_mask__) < 0)     \
     fprintf(stderr, "sigprocmask, %s", strerror(errno));	\
} while(0)

/*
void  myJava_SigactionInt(int sig, siginfo_t *ip, void *context)
{
  printf("\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  printf("\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
	  pthread_self());
  c_backtrace();
}
*/


/*
#define SIGHUP           1
#define SIGINT           2
#define SIGQUIT          3
#define SIGILL           4
#define SIGTRAP          5
#define SIGABRT          6
#define SIGIOT           6
#define SIGBUS           7
#define SIGFPE           8
#define SIGKILL          9
#define SIGUSR1         10
#define SIGSEGV         11
#define SIGUSR2         12
#define SIGPIPE         13
#define SIGALRM         14
#define SIGTERM         15
#define SIGSTKFLT       16
#define SIGCHLD         17
#define SIGCONT         18
#define SIGSTOP         19
#define SIGTSTP         20
#define SIGTTIN         21
#define SIGTTOU         22
#define SIGURG          23
#define SIGXCPU         24
#define SIGXFSZ         25
#define SIGVTALRM       26
#define SIGPROF         27
#define SIGWINCH        28
#define SIGIO           29
#define SIGPOLL         SIGIO
#define SIGPWR          30
#define SIGSYS          31
*/

typedef struct char_intValue {
  const char *name;
  int   value;
} char_intValue_t;

char_intValue_t sigal_table [] = {
  {"SIGINT", SIGINT},
  {"SIGSEGV", SIGSEGV},
  {"SIGUSR1", SIGUSR1},
  {"SIGUSR2", SIGUSR2},
  {"SIGPIPE", SIGPIPE}
};


int signalNameToInt(const char *name)
{
  for(int i=0; i<sizeof(sigal_table)/sizeof(char_intValue_t); i++){
    if(strcmp(name, sigal_table[i].name)==0)
      return sigal_table[i].value;
  }
  return -1;
}

/*
void R_setIntsigHandler()
{
    R_isInterrupted = FALSE;

    struct sigaction sa;
    sa.sa_sigaction = R_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
    //printf("[%s] Java_oldactInt.sa_sigaction = %p\n", __func__, R_oldactInt.sa_sigaction);
    //RJNI_SIG_BLOCK(SIGINT);
}
void R_resetIntsigHandler()
{
  R_isInterrupted = FALSE;
  sigaction(SIGINT, &R_oldactInt, NULL);
}
*/
  
/*
JNIEXPORT jint JNICALL Java_RJNI_toInt(JNIEnv *javaEnv, jobject thisObj,
		jstring jSignalName){

  const char *c_name = (*javaEnv)->GetStringUTFChars(javaEnv,
		  jSignalName, NULL);

  jint sig = signalNameToInt(c_name); 
  fprintf(stderr, "[%s] %s -> %d\n", __func__, c_name, sig);

  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jSignalName, c_name);

  return sig;
}

JNIEXPORT void JNICALL Java_RJNI_killR(JNIEnv *javaEnv, jobject thisObj,
		jlong jshm_ptr, jint rPID, jint signal, jstring jMessage){

  int rc;
  pid_t pid = (pid_t) rPID;
  printf("[%s] rPID = %d\n", __func__, pid);
  rc = kill(pid, signal < 0 ? SIGINT: signal);
  printf("[%s] rc = %d  errno=%d, (EINVALID=%d, EPERM=%d, ESRCH=%d)\n", __func__, rc, errno, EINVAL, EPERM, ESRCH);
  printf("[%s] signal = %d (SIGINT=%d)\n", __func__, signal < 0 ? SIGINT: signal, SIGINT);


  const char *c_message = (*javaEnv)->GetStringUTFChars(javaEnv,
		  jMessage, NULL);

  printf("[%s] jMessage = %s\n", __func__, c_message);




  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  rc = sem_trywait(&io->err->sem_wr);
  if(rc == 0)
  {
    //char *err_msg = "Error occurred"; // use error code...???
    printf("[%s] rc = %d, c_message = %s\n", __func__, rc, c_message);
    if(strlen(c_message) >= io->err->buffer_size){
      memcpy(io->err+1, c_message, io->err->buffer_size);
      ((char*) (io->err+1))[io->err->buffer_size-1] = 0;
    } else 
      memcpy(io->err+1, c_message, strlen(c_message)+1);
    io->err->data_size = strlen((char*)(io->err+1))+1;
    //io->err->pid = getpid();
    sem_post(&io->err->sem_wr);
  }


  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jMessage, c_message);
  

}

static void print_jClassName(const char *prefix, JNIEnv *javaEnv, jobject classObj)
{
      printf("\033[0;37m%s(\"%s\", %p, %p)\033[0m\n", __func__,
		      prefix, javaEnv, classObj);

      jclass jc = (*javaEnv)->GetObjectClass(javaEnv, classObj); // jc = java.lang.Class
      jmethodID jmid = (*javaEnv)->GetMethodID(javaEnv,
		  jc, "getName", "()Ljava/lang/String;");
      if(jmid == NULL){ printf("\033[0;31m[%s] %s, jmid (getName) = NULL\033[0m\n",
		      __func__, prefix);
          return; }

      jstring jValue =  (*javaEnv)->CallObjectMethod(javaEnv, classObj, jmid);
      if(jValue == NULL){ printf("\033[0;31m[%s] %s, jValue  = NULL\033[0m\n",
		      __func__, prefix);
          return; }

      const char *cValue = (*javaEnv)->GetStringUTFChars(javaEnv, jValue, NULL);
      printf("[%s] %s, class name = %s\n", __func__, prefix, cValue);
      (*javaEnv)->ReleaseStringUTFChars(javaEnv, jValue, cValue);
}

// synchronized .... FIXME
JNIEXPORT void JNICALL Java_RJNI_setInterrupted(JNIEnv *env, jobject thisObj){
  isInterrupted = TRUE;
}
*/


// used by UI_thread
/*
void SUPR_setSignalHandler(){
  
  //{
    pid_t ppid = getppid();
    printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] ppid = %d\n",
		    __func__, ppid);

    pid_t pid = getpid();
    pid_t pgid = getpgrp();
    printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] pid = %d\tpgid = %d\n",
		   __func__, pid, pgid);

    if(pgid == ppid){
      int rc = setpgrp(); // set process group to itself
      if(rc == -1)
        printf("Error: %s\n", strerror(errno));

      pid = getpid();
      pgid = getpgrp();
      printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] pid = %d\tpgid = %d\n",
		   __func__, pid, pgid);
    }

  //}

  signalHandlerThread_ptid = pthread_self();
  signalHandlerThread_tid = ((unsigned int)syscall(SYS_gettid));
  printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] pthread.self()=%ld, tid=%d\033[0m\n",
	  __func__, signalHandlerThread_ptid, signalHandlerThread_tid);

  {
    struct sigaction sa;
    sa.sa_sigaction = SUPR_SigactionSIGUSR1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, &Java_oldactUsr1);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = SUPR_SigactionSIGINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &Java_oldactInt);
    //RJNI_SIG_BLOCK(SIGINT);
  }
 
}
*/

/*
static void print_jClassName(const char *prefix, JNIEnv *javaEnv, jobject classObj);

JNIEXPORT void JNICALL Java_RJNI_initialize (JNIEnv *env, jobject thisObj) {
  javaEnv = env;
  javaObj = thisObj;
  fprintf(stderr, "\033[0;32m[%s] javaEnv = %p, javaObj = %p\033[0m\n\n",
		  __func__, javaEnv, javaObj);
}

JNIEXPORT void JNICALL Java_RJNI_init (JNIEnv *env, jobject thisObj,
		jobject theCaller) {


  javaEnv = env;
  javaObj = thisObj;
  javaCaller = theCaller;
  callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);

  print_jClassName("_init ?Driver", javaEnv, callerClass);
  print_jClassName("_init ?RJNI", javaEnv,
		  (*javaEnv)->GetObjectClass(javaEnv, javaObj));

  printf("\n");
 
  {
    jclass jc = (*javaEnv)->GetObjectClass(javaEnv, callerClass);
    jmethodID jmid = (*javaEnv)->GetMethodID(javaEnv,
		  jc, "getName", "()Ljava/lang/String;");
    if(jmid == NULL){ printf("\033[0;31mjmid (getName) = NULL\033[0m\n");
          return; }

    jstring jValue =  (*javaEnv)->CallObjectMethod(javaEnv, callerClass, jmid);
    if(jValue == NULL){ printf("\033[0;31mjValue  = NULL\033[0m\n");
          return; }

    const char *cValue = (*javaEnv)->GetStringUTFChars(javaEnv, jValue, NULL);
    printf("[%s] class name = %s\n", __func__, cValue);
    (*javaEnv)->ReleaseStringUTFChars(javaEnv, jValue, cValue);
  }

}
*/



void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write);

/*
JNIEXPORT void JNICALL Java_RJNI_shmClear (JNIEnv *javaEnv,
	       	jobject javaObj,
	       	jint rPID,
	       	jlong jshm_ptr
		) {
  // interrupt R
  kill((int)rPID, SIGINT);
  printf("\033[0;31m[%s] kill(%d, %d)\n", __func__, (int)rPID, SIGINT);

  // clear shm_io
  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  int can_read  = io->in->data_size > 0;
  int can_write = io->out->data_size == 0;

  while(io->in->data_size){
    size_t size;
    //char *shm_name = NULL; // not used
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    printf("[%s] read %ld bytes\n", __func__, size);
    free(ptr);
    sleep(1);
  }

  rjni_shm_io_state(io, &can_read, &can_write);

  sleep(1);

  if(io->out->pid) {
    sem_wait(&io->err->sem_wr);
    char *err_msg = "Error occurred"; // use error code...???
    memcpy(io->err+1, err_msg, strlen(err_msg)+1);
    io->err->data_size = strlen(err_msg)+1;
    io->err->pid = getpid();
    sem_post(&io->err->sem_wr);



    kill((int)rPID, SIGUSR1);
    unsigned char c = 2;
    shm_io_write(io, io->out, &c, 1);
  }

  rjni_shm_io_state(io, &can_read, &can_write);

  printf("\ncan_read = %s, can_write = %s\n\033[0m\n",
		  can_read?"TRUE":"FALSE",
		  can_write?"TRUE":"FALSE");
}
*/

void rjni_io_err_write(shm_io_info_t *io, const char *msg)
{
  sem_wait(&io->err->sem_wr);
    int len = strlen(msg);
    if(io->err->buffer_size < len)
       len = io->err->buffer_size;
    memcpy(io->err+1, msg, len);
    io->err->data_size = len;
    //io->err->pid = getpid();
  sem_post(&io->err->sem_wr);
}

char *rjni_io_err_read(shm_io_info_t *io, size_t *size)
{
  sem_wait(&io->err->sem_wr);
    size_t len = io->err->data_size;
    *size = len;
    char *c = malloc(len);
    memcpy(c, io->err+1, len);
    io->err->data_size = 0;
    //io->err->pid = 0;
  sem_post(&io->err->sem_wr);
  return c;
}

// Java_RJNI_createWorkerNativeMonitor
/*
JNIEXPORT void JNICALL Java_RJNI_createWorkerMonitor
  (JNIEnv *javaEnv, jobject thisObject, jstring masterAddr, jstring jshm_name)
{ // TODO
  static sem_t *sem = NULL;
  if(!sem){
    const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv,
		    jshm_name, NULL);
    sem = (sem_t *) rjni_shm_create(cshm_name, sizeof(sem_t));
    (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);
    sem_init(sem, 1, 0);
  }
}
*/




// DCL: data change listener
sem_t DCL_sem_main;
/*
jobject jevent;

JNIEXPORT void JNICALL Java_RJNI_DCL_handle (JNIEnv *env, jobject thisObj,
		jobject event) {
   jevent = event; // use a list later ...
   sem_post(&DCL_sem_main); 
}
// Implementation of the native method sayHello()
//JNIEXPORT void JNICALL Java_HelloJNI_startR
JNIEXPORT void JNICALL Java_RJNI_startR (JNIEnv *env, jobject thisObj,
		jobject theCaller) {
  printf("Hello World!\n");

  javaEnv = env;
  javaObj = thisObj;
  javaCaller = theCaller;
  callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);
  

  //char *argv[] = {"REmbeddedPostgres", "--gui=none", "--silent"};
  //// you must specify '--save', '--no-save' or '--vanilla'
  char    *argv[] = {"Java_R", "--vanilla", "--no-save"};
  //char *new_argv[] = {argv[0], "--vanilla", "--no-save"};

  int argc = sizeof(argv)/sizeof(argv[0]);

  printf("[%s] pthread_self() = %ld\n", __func__, pthread_self());
  printf("\033[0;37mR_CStackStart = %ld\n", R_CStackStart);
  printf("R_CStackLimit = %ld\033[0m\n", R_CStackLimit);
  printf("\033[0;37m         =======================================\033[0m\n");


  //Rf_initEmbeddedR(argc, argv);
  // start a large stack-size pthread???
  // set JVM stack size
  {
    Rf_initialize_R(argc, argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    printf("R_CStackStart = %ld\n", R_CStackStart);
    printf("R_CStackLimit = %ld\n", R_CStackLimit);
    //R_Interactive = TRUE; 
    R_Interactive = FALSE; 
    setup_Rmainloop();
  }

  // signal handlers
 
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGSEGV, &sa, &R_oldact);
  }


  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGINT, &sa, &R_oldactInt);
  }


 
  

  {
    SEXP e, tmp;
    int errorOccurred;
    ParseStatus status;

    tmp = PROTECT(mkString("print(1:10)"));
    e = PROTECT(R_ParseVector(tmp, 1, &status, R_NilValue));
    PrintValue(e);
    SEXP res = R_tryEval(VECTOR_ELT(e,0), R_GlobalEnv, &errorOccurred);
    if(errorOccurred){
      PrintValue(res);
//      jump_now();
//Rf_resetStack(1);
    }

    char *outCStr = "OutChar";
    jstring jstr = (*env)->NewStringUTF(env, outCStr);

    const char *inCStr = (*env)->GetStringUTFChars(env, jstr, NULL);
    printf("In C, the received string is: %s\n", inCStr);

   // void ReleaseStringUTFChars(JNIEnv *env, jstring string, const char *utf);
   // Informs the VM that the native code no longer needs access to utf.

#ifndef DEBUG_SEGV
    (*env)->ReleaseStringUTFChars(env, jstr, inCStr); // ???
#endif

  }
    RJNI_SIG_BLOCK(SIGSEGV);


  sem_init(&DCL_sem_main, 1, 0);
  while(TRUE){
    //SEXP call = PROTECT(LCONS(install("X11"), R_NilValue));
    //eval(call, R_GlobalEnv);
    //UNPROTECT(1);
    printf("[%s] R .... TODO\n", __func__);
    sem_wait(&DCL_sem_main);
    printf("[%s] R .... TODO\n", __func__);
    sleep(100);
  }

  //if(R_Interactive) run_Rmainloop();

  Rf_endEmbeddedR(0);

  return;
}
*/

/*
JNIEXPORT jlong JNICALL Java_RJNI_getpid (JNIEnv *env, jobject thisObj){
  long pid = getpid();
  return pid;
}

JNIEXPORT jlong JNICALL Java_RJNI_geteuid (JNIEnv *env, jobject thisObj){
  long pid = geteuid();
  return pid;
}

JNIEXPORT jlong JNICALL Java_RJNI_gettid (JNIEnv *env, jobject thisObj){
  return syscall(SYS_gettid);
}

JNIEXPORT jlong JNICALL Java_RJNI_getptid (JNIEnv *env, jobject thisObj){
  return pthread_self();
}
*/



typedef struct shm_struct {
  size_t size;
  sem_t sem_w; // by java thread
  sem_t sem_r; // by java thread
} shm_struct_t;

int tr_shm_init(int job_id, int tr_id)
{
  /*
  char shm_name[256];
  sprintf(shm_name, "RTR_%d_TASK_%d_%d", geteuid(), job_id, tr_id);
  int fd = shm_open(shm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  if(fd == -1){
      //if(errno == EEXIST){
        shm_unlink(shm_name);
	errorcall(R_NilValue, "[shm_open(%s)] %s (%s, %d)", shm_name,
			      strerror(errno), __FILE__, __LINE__);
      //}
  } else {
      close(fd);
      shm_unlink(shm_name);
  }
  */

  return 0;
}

/*
create and destroy:
 shm_name;
 mem_ptr;
 size;

in:
  [...][ ... w_offset  ... r_offset ...] or [ ... r_offset  ... w_offset ...]

out:
  [...][ ... w_offset  ... r_offset ...] or [ ... r_offset  ... w_offset ...]

 */

//extern vector_t *cleanups;

extern void ShmCache_add(const char *name, size_t size, void *att);

void shm_cleanup(void *data){
  char *name =  (char*)data;
  shm_unlink(name);
  basic_info("shm_unlink /dev/shm/%s", name);
}

void *rjni_shm_create(const char *cshm_name, size_t size)
{

  int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  size_t segment_size = size; // sysconf(_SC_PAGE_SIZE);
  int rc = ftruncate(fd, segment_size);
  if(rc != 0) {
    printf("[%s] ERROR: ftruncate(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  close(fd);

  //addCleanups(shm_cleanup, strdup(cshm_name));
  ShmCache_add(cshm_name, segment_size, NULL);

  return mem_ptr;
}

shm_io_info_t *shm_io_create(const char *cshm_name, size_t block_size) 
{

  shm_io_info_t *io = malloc(sizeof(shm_io_info_t));
  shm_info_t *shm_ptr = &io->shm_info;


  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  size_t segment_size = 3*block_size; // sysconf(_SC_PAGE_SIZE);
  int rc = ftruncate(fd, segment_size);
  if(rc != 0) {
    printf("[%s] ERROR: ftruncate(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  close(fd);

  //{ printf("[%s] %s : %d\n", __func__, (char*) _dupstr(cshm_name), __LINE__);
  //addCleanups(shm_cleanup, strdup(cshm_name));

  char *__cshm_name = malloc(strlen(cshm_name)+1);
  memcpy(__cshm_name, cshm_name, strlen(cshm_name)+1);
  addCleanups(shm_cleanup, __cshm_name);
  //} printf("[%s] %s : %d\n", __func__, (char*)_dupstr(cshm_name), __LINE__);

  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);
  shm_ptr->mem_ptr = mem_ptr;
  shm_ptr->size = segment_size;

  //printf("\033[0;31mio: %p, mem_ptr: %p, size: %ld\033[0m\n", io, mem_ptr, segment_size);

  for(int i=0; i<3; i++){
    shm_io_block_t *block = (shm_io_block_t*) (mem_ptr + i*block_size);
    block->size = i==0 ? segment_size : block_size;
    sem_init(&block->sem_wait, 1, 0);
    sem_init(&block->sem_wr, 1, 1);
    sem_init(&block->sem_yield, 1, 0);
    block->pid = 0;
    block->buffer_size = block_size - sizeof(shm_io_block_t);
    block->data_size = 0;
  }

  io->in = mem_ptr + 0*block_size;
  io->out = mem_ptr + 1*block_size;
  io->err = mem_ptr + 2*block_size;
  return io;
}

/*
int shm_io_reset(shm_io_info_t *io, shm_io_block_t *in)
{
  shm_info_t *shm_ptr = &io->shm_info;
  printf("[%s] proc %d created the shm_io? %s\n", __func__, getpid(),
		  in == shm_ptr->mem_ptr ? "TRUE" : "FALSE");
  void *mem_ptr = shm_ptr->mem_ptr;

  shm_io_block_t *block = (shm_io_block_t*) mem_ptr;
  size_t block_size = block->size/3;
  int val;

  for(int i=0; i<3; i++){
    block = i==0 ? io->in : (i==1 ? io->out : io->err);

    //sem_init(&block->sem_wait, 1, 0);
    sem_getvalue(&block->sem_wait, &val);
    if(val == 1) sem_wait(&block->sem_wait);
    sem_getvalue(&block->sem_wait, &val);
    printf("[%s] valueOf(sem_wait): %d", __func__, val);

    //sem_init(&block->sem_wr, 1, 1);
    sem_getvalue(&block->sem_wr, &val);
    if(val == 0) sem_post(&block->sem_wr);
    sem_getvalue(&block->sem_wr, &val);
    printf(", valueOf(sem_wr): %d", val);

    //sem_init(&block->sem_yield, 1, 0);
    sem_getvalue(&block->sem_yield, &val);
    if(val == 1) sem_wait(&block->sem_yield);
    sem_getvalue(&block->sem_yield, &val);
    printf(", valueOf(sem_yield): %d\n", val);

    block->pid = 0;
    block->data_size = 0;
  }

}
*/

// use io->err for this
int shm_io_reset(shm_io_info_t *io, int step)
{
  shm_info_t *shm_ptr = &io->shm_info;
  void *mem_ptr = shm_ptr->mem_ptr;
  shm_io_block_t *block = (shm_io_block_t*) mem_ptr;
  size_t block_size = block->size/3;
  int val;


  int rc = 0;
  switch(step){
    case 0: // reset
	  { 
		  block = io->err;
		  do { 
			  sem_getvalue(&block->sem_wait, &val);
			  if(val == 0) break;
			  sem_wait(&block->sem_wait);
		  } while(TRUE); 
		  
		  do { 
			  sem_getvalue(&block->sem_wr, &val); 
			  if(val == 0) break; 
			  sem_wait(&block->sem_wr); 
		  } while(TRUE); 
		  
		  do {
			  sem_getvalue(&block->sem_yield, &val);
			  if(val == 0) break;
			  sem_wait(&block->sem_yield);
		  } while(TRUE); 
		  
		  block->pid = getpid();
		  block->padding = (int) syscall(SYS_gettid); 

		  block = io->in;
		  sem_post(&block->sem_wr);
		  block = io->out;
		  sem_post(&block->sem_wr);

		  block = io->err;
		  sem_post(&block->sem_wr); 
		  
		  char *data_ptr = (char*)(block + 1);
		  sprintf(data_ptr, "Reset");
		  block->data_size = strlen("Reset")+1; 
		  sem_post(&block->sem_wait);
		  
		  basic_info("\033[0;31mstep 0\033[0m");
	  }
	  break;

    case 1:  // testing
	  { 
		  block = io->err;
		  sem_wait(&block->sem_wait);
		  block->pid = getpid();
		  block->padding = (int) syscall(SYS_gettid);
		  basic_info((char*) ( block + 1));
		  basic_info("\033[0;31mstep 1\033[0m");
	  }
	  break;

    default: break; // error
  }
  return rc;
}

static int processName(int pid, char *buf, int buf_size){
  char path[PATH_MAX];
  sprintf(path, "/proc/%d/exe", pid);
  ssize_t n = readlink(path, buf, buf_size-1);
  buf[n] = 0;
  return n;
}	

#define  PRINT_SHM_IO_BLOCK_INFO(block, page_size)	\
do {	\
  fprintf(stderr, "\tsize: %ld (%ld pages)\n", block->size,	\
		  block->size/page_size);	\
  int wait, wr, yield;	\
  sem_getvalue(&block->sem_wait, &wait);	\
  sem_getvalue(&block->sem_wr, &wr);	\
  sem_getvalue(&block->sem_yield, &yield);	\
  fprintf(stderr, "\tsem_values: [wait=%d (0), wr=%d (1), yield=%d (0)]\n",	\
		    wait, wr, yield);	\
  fprintf(stderr, "\tpid=%d padding=%d buffer_size=%ld data_size=%ld\n",	\
  block->pid, block->padding, block->buffer_size, block->data_size);	\
  if(block->data_size == 0 && block->pid){	\
    char buf[PATH_MAX];	\
    processName(block->pid, buf, PATH_MAX);	\
    fprintf(stderr, "\t\033[0;33m[pid=%d%s] is waiting to read\033[0m\n",	\
		    block->pid, buf);	\
  } else if(block->data_size && block->pid){	\
    char buf[PATH_MAX];	\
    processName(block->pid, buf, PATH_MAX);	\
    fprintf(stderr, "\t\033[0;33m[pid=%d%s] is waiting to write\033[0m\n",	\
		    block->pid, buf);	\
  }	\
} while(0)
// and info?
void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write)
{
  if(!io) return;
  size_t page_size = sysconf(_SC_PAGE_SIZE);
  shm_info_t *shm_ptr = &io->shm_info;
//  fprintf(stderr, "\n[%s] this pid: %d (tid=%d)\n", __func__, getpid(), ((unsigned int)syscall(SYS_gettid)));
  //fprintf(stderr, "[%s] shm_name: %s\n", __func__, shm_ptr->shm_name);
  //fprintf(stderr, "[%s] mem_ptr:  %p\n", __func__, shm_ptr->mem_ptr);
  //fprintf(stderr, "[%s] size:     %ld (%ld pages)\n", __func__, shm_ptr->size, shm_ptr->size/page_size);
  //fprintf(stderr, "\n[%s] in:   %p [block pos=%d]\n", __func__, io->in, io->in == shm_ptr->mem_ptr? 0:1);
  
  /*
  {
    shm_io_block_t *block = io->in;
    PRINT_SHM_IO_BLOCK_INFO(block, page_size);
  }
  */

  //fprintf(stderr, "\n[%s] out:  %p [block_pos=%d]\n", __func__, io->out, io->out == shm_ptr->mem_ptr? 0:1);
  /*
  {
    shm_io_block_t *block = io->out;
    PRINT_SHM_IO_BLOCK_INFO(block, page_size);
  }
  */

//  fprintf(stderr, "\n[%s] err:  %p [block_pos=%d]\n", __func__, io->err, 2);
  /*
  {
    shm_io_block_t *block = io->err;
    PRINT_SHM_IO_BLOCK_INFO(block, page_size);
  }
  */
//  fprintf(stderr, "\n");

  *can_read  = io->in->data_size > 0; // can read without blocking
  *can_write = io->out->data_size == 0; // can write without blocking
}

SEXP R_shmIOState(SEXP shm_conn){
  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);
  int can_read, can_write;
  rjni_shm_io_state(io, &can_read, &can_write);
  //char *line = readline (">>> ");
  //printf("echo: %s\n", line);
  SEXP val = PROTECT(allocVector(LGLSXP, 2));
  LOGICAL(val)[0] = can_read;
  LOGICAL(val)[1] = can_write;
  SEXP names = PROTECT(allocVector(STRSXP, 2));
  SET_STRING_ELT(names, 0, mkChar("can_read"));
  SET_STRING_ELT(names, 1, mkChar("can_write"));
  setAttrib(val, R_NamesSymbol, names);
  UNPROTECT(2);
  return val;
}

int supr_shm_exists(const char *cshm_name)
{
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1)
    return FALSE;
  close(fd);
  return TRUE;
}

void *supr_shm_open(const char *cshm_name, size_t *size)
{
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1){
    fprintf(stderr, "\033[0;31m[%s] ERROR: shm_open(%s), %s\033[0m\n", __func__,
		    cshm_name, strerror(errno));
    printf("\033[0;31m[%s] ERROR: shm_open(%s), %s\033[0m\n", __func__,
		    cshm_name, strerror(errno));
    //sleep(60);
    return 0;
  }

  struct stat statbuf;
  int rc = fstat(fd, &statbuf);
  if(rc == -1) {
    printf("[%s] ERROR: fstat(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    TODO();
    return NULL;
  }
  size_t segment_size = statbuf.st_size;
  *size = segment_size;

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    TODO();
    return 0;
  }

  close(fd);

  return mem_ptr;
}

void *rjni_shm_open(const char *cshm_name, size_t *size)
{
  //print_caller_info(0); print_caller_info(1); print_caller_info(2);
  return supr_shm_open(cshm_name, size);
}

shm_io_info_t *shm_io_open(const char *cshm_name)
{
  //printf("[%s] cshm_name: %s\n", __func__, cshm_name);
  verbose_info(cshm_name);

  shm_io_info_t *io = malloc(sizeof(shm_io_info_t));
  shm_info_t *shm_ptr = &io->shm_info;

  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  struct stat statbuf;
  int rc = fstat(fd, &statbuf);
  if(rc == -1) {
    TODO();
    return NULL;
  }
  size_t segment_size = statbuf.st_size;

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    TODO();
    return 0;
  }

  close(fd);

  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);
  shm_ptr->mem_ptr = mem_ptr;
  shm_ptr->size = segment_size;

  size_t block_size = segment_size/3;
  io->in  = mem_ptr + 1*block_size;
  io->out = mem_ptr + 0*block_size;
  io->err = mem_ptr + 2*block_size;

  return io;
}

int shm_io_close(shm_io_info_t *io)
{
  fprintf(stderr, "Warning: unimplemented %s (%s:%d)\n", __func__,
  		__FILE__, __LINE__);
  return 0;
}

/*
JNIEXPORT jlong JNICALL Java_RJNI_shmCreate (JNIEnv *javaEnv, jobject thisObj,
		jstring jshm_name){
  const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv,
		  jshm_name, NULL);
  {
  printf("[%s] cshm_name: %s\n", __func__, cshm_name);
  shm_info_t *shm_ptr = malloc(sizeof(shm_struct_t));

  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  size_t segment_size = sysconf(_SC_PAGE_SIZE);
  int rc = ftruncate(fd, segment_size);
  if(rc != 0) {
    printf("[%s] ERROR: ftruncate(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
		    strerror(errno));
    return 0;
  }

  close(fd);
  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);

  shm_ptr->mem_ptr = mem_ptr;

  shm_struct_t * ssp = (shm_struct_t *)mem_ptr;
  ssp->size = segment_size;
  sem_init(&ssp->sem_w, 1, 0);
  sem_init(&ssp->sem_r, 1, 0);
  //sem_wait(&ssp->sem_w); sem_wait(&ssp->sem_r);

  return (long) shm_ptr;
  }

  size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
  shm_io_info_t *io = shm_io_create(cshm_name, block_size);
#ifndef DEBUG_SEGV
  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);
#endif

  return (long) io;
}

JNIEXPORT jlong JNICALL Java_RJNI_shmOpen (JNIEnv *javaEnv, jobject thisObj,
		jstring jshm_name){
  const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv,
		  jshm_name, NULL);

  shm_io_info_t *io = shm_io_open(cshm_name);

  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);
  return (long) io;
}
*/

void  myR_SigactionSIGUSR1(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m[%s] is called\033[0m\n", __func__);
  c_backtrace();
}

SEXP R_shmCreate(SEXP r_shm_name)
{
  size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
  const char * cshm_name = CHAR(STRING_ELT(r_shm_name,0));
  shm_io_info_t *io = shm_io_create(cshm_name, block_size);

  SEXP r_io = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
  setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
  setAttrib(r_io, R_NameSymbol, r_shm_name);
  UNPROTECT(1);
#define SET_SIGUSR1_HANDLER
#ifdef SET_SIGUSR1_HANDLER
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSIGUSR1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }
#endif
  return r_io;
}

SEXP R_shmWrite(SEXP shm_conn, SEXP x){

  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);

  printf("[%s] io=%p\n", __func__, io);

  void *ptr = NULL;
  size_t size = 0;

  if(TYPEOF(x) == STRSXP){
    const char * p = CHAR(STRING_ELT(x, 0)); // FIXME
    ptr = (void*) p;
    size = strlen(p)+1;
  } else {
    errorcall(R_NilValue, "not implemented (%s, %d)", __FILE__, __LINE__);
  }

  size_t n = shm_io_write(io, io->out, ptr, size);
  return R_NilValue;
}

SEXP R_shmRead(SEXP shm_conn){

  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);

  //printf("[%s] io=%p\n", __func__, io);

  size_t size;
  void *ptr = shm_io_read(io, io->in, &size, NULL);

  SEXP ret_value = R_NilValue;
  int type = ((int*) ptr)[0];
#define intsxp  13
  switch(type){
    case intsxp: 
	 {
	   int len = ((int*) ptr)[1];
	   ret_value = PROTECT(allocVector(INTSXP, len));
	   int *val = (int*)(ptr+ 2*sizeof(int));
	   for(int i=0; i<len; i++)
             INTEGER(ret_value)[i] = val[i];
	 }
	 break;
    default:
	 errorcall(R_NilValue, "unknown object type");
	 break;
  }
#undef intsxp

  free(ptr);
  UNPROTECT(1);
  return ret_value;
}

int shm_io_destroy (shm_io_info_t *io){
//printf("io: %p\n", io);		
  if(!io) return 0;
	/*
		{
  printf("[%s] shm_ptr->shm_name = %s\n", __func__, shm_ptr->shm_name);
  shm_struct_t * ssp = (shm_struct_t *)shm_ptr->mem_ptr;
  size_t segment_size = ssp->size;
  sem_destroy(&ssp->sem_w);
  sem_destroy(&ssp->sem_r);
  munmap(shm_ptr->mem_ptr, segment_size);
  shm_unlink(shm_ptr->shm_name);
  free(shm_ptr->shm_name);
  free(shm_ptr);
  return 0;
  }
  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  */

  shm_info_t *shm_ptr = &io->shm_info;
  size_t segment_size = shm_ptr->size;

  if(Supr_verbose){
    printf("[%s] shm_ptr->shm_name = %s\n", __func__, shm_ptr->shm_name);
    printf("\033[0;34mio: %p, mem_ptr: %p, size: %ld\033[0m\n",
		  io, shm_ptr->mem_ptr, shm_ptr->size);
  }

  size_t block_size = segment_size/3;
  for(int i=0; i<3; i++){
    shm_io_block_t *block = (shm_io_block_t *)(shm_ptr->mem_ptr + i*block_size);
    sem_destroy(&block->sem_wait);
    sem_destroy(&block->sem_wr);
    sem_destroy(&block->sem_yield);
  }


  munmap(shm_ptr->mem_ptr, segment_size);

  shm_unlink(shm_ptr->shm_name);
  //printf("[%s] free shm_ptr->shm_name\n", __func__);
  free(shm_ptr->shm_name);

  {
    shm_ptr->shm_name = NULL;
    io->in = NULL;
    io->out = NULL;
    io->err = NULL;
  }

  free(io);
  return 0;
}

/*
JNIEXPORT jint JNICALL Java_RJNI_shmDestroy (JNIEnv *env, jobject thisObj,
		jlong jshm_ptr){
		{
  shm_info_t *shm_ptr = (shm_info_t *) jshm_ptr;
  printf("[%s] shm_ptr->shm_name = %s\n", __func__, shm_ptr->shm_name);
  shm_struct_t * ssp = (shm_struct_t *)shm_ptr->mem_ptr;
  size_t segment_size = ssp->size;
  sem_destroy(&ssp->sem_w);
  sem_destroy(&ssp->sem_r);
  munmap(shm_ptr->mem_ptr, segment_size);
  shm_unlink(shm_ptr->shm_name);
  free(shm_ptr->shm_name);
  free(shm_ptr);
  return 0;
  }
  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  shm_info_t *shm_ptr = &io->shm_info;
  size_t segment_size = shm_ptr->size;

  printf("[%s] shm_ptr->shm_name = %s\n", __func__, shm_ptr->shm_name);

  size_t block_size = segment_size/3;
  for(int i=0; i<3; i++){
    shm_io_block_t *block = (shm_io_block_t *)(shm_ptr->mem_ptr + i*block_size);
    sem_destroy(&block->sem_wait);
    sem_destroy(&block->sem_wr);
    sem_destroy(&block->sem_yield);
  }

  munmap(shm_ptr->mem_ptr, segment_size);
  shm_unlink(shm_ptr->shm_name);
  //printf("[%s] free shm_ptr->shm_name\n", __func__);
  free(shm_ptr->shm_name);
  //printf("[%s] free io\n", __func__);
  free(io);
  return 0;
}

JNIEXPORT jint JNICALL Java_RJNI_shmWait (JNIEnv *env, jobject thisObj,
		jlong jshm_ptr, jint jwr){
  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  shm_info_t *shm_ptr = (shm_info_t *) &io->shm_info;
  size_t block_size = shm_ptr->size/3;
  int rc = -1;
  if(jwr >= 0 && jwr <= 2){
    shm_io_block_t *block = (shm_io_block_t *)(shm_ptr->mem_ptr+jwr*block_size);
    rc = sem_wait(&block->sem_wait);
  }
  return rc;
}

JNIEXPORT jint JNICALL Java_RJNI_shmPost (JNIEnv *env, jobject thisObj,
		jlong jshm_ptr, jint jwr){
  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  shm_info_t *shm_ptr = (shm_info_t *) &io->shm_info;
  size_t block_size = shm_ptr->size/3;
  int rc = -1;
  if(jwr >= 0 && jwr <= 2){
    shm_io_block_t *block = (shm_io_block_t *)(shm_ptr->mem_ptr+jwr*block_size);
    rc = sem_post(&block->sem_wait);
  }
  return rc;
}
*/

// use padding variable for error flag???

//#define USE_ERROR_FLAG
//#define TEST_USR1_INTERRUPT

/*
int SUPR_CheckUserInterrupt()
{
  if(javaEnv){
    fprintf(stderr, "[JAVA] isInterrupted = %s\n", isInterrupted ? "TRUE" : "FALSE");
  } else {
    extern int R_interrupts_pending;
    fprintf(stderr, "isInterrupted = %s\n", isInterrupted ? "TRUE" : "FALSE");
    fprintf(stderr, "R_interrupts_pending = %s\n",
		    R_interrupts_pending ? "TRUE" : "FALSE");
    R_CheckUserInterrupt();
  }
  return isInterrupted;
} 
*/

//extern int isInterrupted;
int javaEnv = FALSE; // deleteme

#define shm_io_read_CheckUserInterrupt() do {		\
  if (R_isInterrupted) {	\
    if(javaEnv){	\
        int *cmd = malloc(sizeof(int));	\
        cmd[0] = TR_CLUSTER_INTERRUPT;	\
        return cmd;	\
    } else {	\
      R_CheckUserInterrupt();	\
    }	\
  }	\
} while(0)

#define shm_io_write_CheckUserInterrupt() do {		\
  if (R_isInterrupted) {	\
    if(javaEnv){	\
        return -1;	\
    } else {	\
      R_CheckUserInterrupt();	\
    }	\
  }	\
} while(0)

size_t shm_io_write(shm_io_info_t *io_info, shm_io_block_t *out,
	       	void *src, size_t size)
{
//printf("[%s] OKAY 1 block=%d\n", __func__, io_info->shm_info.mem_ptr == out?0:1);
//printf("[%s] OKAY 1 mem_ptr=%p, out=%p\n", __func__, io_info->shm_info.mem_ptr, out);
#ifdef USE_ERROR_FLAG
  if(io_info->err->pid) {
    printf("\033[0;31m[%s: pid=%d, R=%d, Java=%d] Error: %s\033[0m\n", __func__,
		    getpid(), rDriver_PID, javaDriver_PID,
		    (char*)(io_info->err+1));
    if(io_info->err->pid != getpid()) {
      sem_wait(&io_info->err->sem_wr);
        io_info->err->pid = 0;
        io_info->err->data_size = 0;
        char err[strlen((char*)(io_info->err+1))+1];
        sprintf(err, "%s", (char*)(io_info->err+1));
      sem_post(&io_info->err->sem_wr);
      if(rDriver_PID == getpid())
        errorcall(R_NilValue, "%s", err);
    }
    return 0; // reset???
  }
#endif

#ifdef TEST_USR1_INTERRUPT
  isInterrupted = 0;
  while(TRUE) {
    sem_wait(&out->sem_wr);

    if(SUPR_CheckUserInterrupt()) return 0; else break;

    /*
    if(isInterrupted)
    {
      fprintf(stderr, "Interrupted (%s, %d)\n", __FILE__, __LINE__);
      isInterrupted = 0;
    } else 
	    break;
	    */
  }
#else
  shm_io_write_CheckUserInterrupt();
  sem_wait(&out->sem_wr);
#endif


//printf("[%s] OKAY 1.1\n",__func__);
  if(out->data_size > 0){ // yield for data to be read
    int val;
    sem_getvalue(&out->sem_yield, &val);
    while(val > 0) {

#ifdef TEST_USR1_INTERRUPT
      isInterrupted = 0;
      while(TRUE) {
        sem_wait(&out->sem_yield);
        if(SUPR_CheckUserInterrupt()) return 0; else break;
	/*
        if(isInterrupted)
	{
          fprintf(stderr, "Interrupted (%s, %d)\n", __FILE__, __LINE__);
          isInterrupted = 0;
	} else 
	    break;
	    */
      }
#else
      shm_io_write_CheckUserInterrupt();
      sem_wait(&out->sem_yield);
#endif

      sem_getvalue(&out->sem_yield, &val);
    } 
    out->pid = getpid();
    sem_post(&out->sem_wr);

#ifdef TEST_USR1_INTERRUPT
    isInterrupted = 0;
    while(TRUE) {
      sem_wait(&out->sem_yield); // gcc -ggdb ... and do gdb -p PID # in the same directory
      if(SUPR_CheckUserInterrupt()) return 0; else break;
      /*
      if(isInterrupted) {
        fprintf(stderr, "Interrupted (%s, %d)\n", __FILE__, __LINE__);
        isInterrupted = 0;
      }
      else 
	    break;
	    */
    }
#else
    shm_io_write_CheckUserInterrupt();
    sem_wait(&out->sem_yield);
#endif
  }
//printf("[%s] OKAY 2\n",__func__);

  out->data_size = size;
  if(size <= out->buffer_size){
    memcpy(out+1, src, size);
  } else {
    shm_info_t *shm_info = &io_info->shm_info;
    char *suffix = out == io_info->out ? ".1":".0";
    char *shm_name = (char*)(out+1);
    sprintf(shm_name, "%s%s", shm_info->shm_name, suffix);
    shm_header_t *shm_header= (shm_header_t *)
	    rjni_shm_create(shm_name, sizeof(shm_header_t)+size);
    if(shm_header){
      memcpy(shm_header+1, src, size);
      shm_header->ref_count = 0;
    } else { TODO(); return -1; }
  }

//printf("[%s] OKAY 3\n",__func__);
  if(out->pid){
//printf("[%s] OKAY 5 out->pid=%d\n", __func__, out->pid);
	  out->pid = 0;
	  sem_post(&out->sem_yield);
  } else {
	  sem_post(&out->sem_wr);
  }

  return size;
}

//void *malloc(size_t size);
/*
typedef void *(*custom_alloc_t)(R_allocator_t *allocator, size_t);
typedef void  (*custom_free_t)(R_allocator_t *allocator, void *);

struct R_allocator {
    custom_alloc_t mem_alloc; // malloc equivalent 
    custom_free_t  mem_free;  // free equivalent 
    void *res;                // reserved (maybe for copy) - must be NULL
    void *data;               // custom data for the allocator implementation 
};
*/

/*
#include<R_ext/Rallocators.h>

void *supr_alloc(R_allocator_t *allocator, size_t size)
{
  //if(!allocator.data) error...
  supr_header_t *h = (supr_header_t *) allocator.data;
	return NULL;
}

void  supr_free(R_allocator_t *allocator, void *p)
{
}

R_allocator_t __myR_allocator_struct__ = {
    //(custom_alloc_t)
    supr_alloc,
    //(custom_free_t)
    supr_free,
    NULL,
    NULL
  };
R_allocator_t *myR_allocator = &__myR_allocator_struct__;
  */

/*
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)

//VALGRIND_LEVEL is 0
//#pragma message(VAR_NAME_VALUE(VALGRIND_LEVEL))
//#pragma message(VAR_NAME_VALUE(LCONS))
//#pragma message(VAR_NAME_VALUE(CHK(x)))
*/

#ifdef malloc

//#pragma message("\033[0;31mmalloc is defined\033[0m\n")

//#define mall p000000(x)

#ifndef VALUE_TO_STRING
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)
#endif

//#pragma message "value of malloc(x) = " VALUE(malloc(x))

#endif

// duplicate
void *__mallocAndCopy__(size_t size, const void *src)
{
  void *p = malloc(size);
  memcpy(p, src, size);
  return p;
}

void *__SEXP_mallocAndCopy__(size_t size, const void *src)
{
  if(src && size > sizeof(supr_header_t)){ // testing
    supr_header_t *h = (supr_header_t *) src;
    if(h->id == SUPR && h->type == SUPR_SERIALIZED_ROBJ){
      fprintf(stderr, "[%s] __malloc__\n", __func__);
      supr_header_t *h = (supr_header_t *) src;
      //SEXP raw = PROTECT(allocVector(RAWSXP, h->length));
      SEXP raw = allocVector(RAWSXP, h->length);
      memcpy(DATAPTR(raw), h+1, h->length);
      return raw;
    }
  } 

  errorcall(R_NilValue, "[%s] (%s, %d)", __func__, __FILE__, __LINE__);
  
  return NULL;
}

SEXP shm_io_readRObject(shm_io_info_t *io_info, shm_io_block_t *in, SEXP env)
{
  size_t size;
  SEXP raw = (SEXP) shm_io_read(io_info, in,  &size, __SEXP_mallocAndCopy__);
  SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
  SEXP val = eval(call, env);

  UNPROTECT(2);
  return val;
}

//malloc_t __malloc__ = SUPR_malloc;

// included shm_io_info_t *io_info for testing...
void *shm_io_read(shm_io_info_t *io_info, shm_io_block_t *in, size_t *size,
		malloc_t mallocAndCopy)
{
  if(!mallocAndCopy) mallocAndCopy = __mallocAndCopy__;
#ifdef USE_ERROR_FLAG
  if(io_info->err->pid) {
    printf("\033[0;31m[%s: pid=%d, R=%d, Java=%d] Error: %s\033[0m\n", __func__,
		    getpid(), rDriver_PID, javaDriver_PID,
		    (char*)(io_info->err+1));
    if(io_info->err->pid != getpid()) {
      sem_wait(&io_info->err->sem_wr);
        io_info->err->pid = 0;
        io_info->err->data_size = 0;
        char err[strlen((char*)(io_info->err+1))+1];
        sprintf(err, "%s", (char*)(io_info->err+1));
      sem_post(&io_info->err->sem_wr);
      if(rDriver_PID == getpid())
        errorcall(R_NilValue, "%s", err);
    }
    *size = 0;
    return NULL; // reset???
  }
#endif

#ifdef TEST_USR1_INTERRUPT
  isInterrupted = 0;
  while(TRUE) {
    sem_wait(&in->sem_wr);
    if(SUPR_CheckUserInterrupt()) return 0; else break;
    /*
    if(isInterrupted) {
      fprintf(stderr, "Interrupted (%s, %d)\n", __FILE__, __LINE__);
      isInterrupted = 0;
    }
    else 
	    break;
	    */
  }
#else
  shm_io_read_CheckUserInterrupt();
  sem_wait(&in->sem_wr);
#endif

  if(in->data_size == 0){
//printf("[%s] OKAY 1.1\n", __func__);
    int val;
    sem_getvalue(&in->sem_yield, &val);
    while(val > 0) {
#ifdef TEST_USR1_INTERRUPT
      isInterrupted = 0;
      while(TRUE) {
        sem_wait(&in->sem_yield);
        if(SUPR_CheckUserInterrupt()) return 0; else break;
	/*
        if(isInterrupted)
	{
          fprintf(stderr, "Interrupted (%s, %d)\n", __FILE__, __LINE__);
          isInterrupted = 0;
	}
        else 
	    break;
	    */
      }
#else
      shm_io_read_CheckUserInterrupt();
      sem_wait(&in->sem_yield);
#endif
      sem_getvalue(&in->sem_yield, &val);
    } 
    in->pid = getpid();
    sem_post(&in->sem_wr);
#ifdef TEST_USR1_INTERRUPT
    isInterrupted = 0;
    while(TRUE) {
      sem_wait(&in->sem_yield);
      if(SUPR_CheckUserInterrupt()) return 0; else break;
      /*
      if(isInterrupted)
      {
        fprintf(stderr, "Interrupted (%s, %d)\n", __FILE__, __LINE__);
        isInterrupted = 0;
      }
      else 
	    break;
	    */
    }
#else
    shm_io_read_CheckUserInterrupt();
    int rc = sem_wait(&in->sem_yield);
    if(rc == -1){
      fprintf(stderr, "sem_wait: %s\n", strerror(errno));
      char buf[256];
      sprintf(buf, "sem_wait: %s\n", strerror(errno));
      basic_info(buf);
      //print_sem_error(errno);
      *size = 0;
      return NULL;
    }
#endif
  }
//printf("[%s] OKAY 2\n", __func__);

  //void *ptr = malloc(in->data_size);
  //void *ptr = malloc(in->data_size, in+1);
  void *ptr = NULL;
  if(in->data_size <= in->buffer_size){
    ptr = mallocAndCopy(in->data_size, in+1);
    //memcpy(ptr, in+1, in->data_size);
  } else {
    /*
    char *shm_name = malloc(strlen((char*)(in+1))+1);
    sprintf(shm_name, "%s", (char*)(in+1));
    shm_header_t *shm_header= (shm_header_t *) rjni_shm_open(shm_name, size);
    */
	  /*
    shm_header_t *shm_header= (shm_header_t *) rjni_shm_open(
		    (char*)(in+1), size);
		    */
    char shm_name[strlen((char*)(in+1))+1];
    sprintf(shm_name, "%s", (char*)(in+1));
    shm_header_t *shm_header= (shm_header_t *) rjni_shm_open(shm_name, size);
    if(*size != sizeof(shm_header_t) + in->data_size){
	    TODO();
	    free(ptr);
	    return NULL;
    }
    ptr = mallocAndCopy(in->data_size, shm_header+1);
    //memcpy(ptr, shm_header+1, in->data_size);

    if(shm_header->ref_count==0){
      munmap(shm_header, *size);
      shm_unlink(shm_name);
    }

  }

  *size = in->data_size;
  in->data_size = 0;

  if(in->pid){
    in->pid = 0;
    sem_post(&in->sem_yield);
  } else {
    sem_post(&in->sem_wr);
  }

  return ptr;
}

/*
JNIEXPORT jlong JNICALL Java_RJNI_shmWrite (JNIEnv *javaEnv, jobject thisObj,
		jlong jshm_ptr, jbyteArray java_array){

  jsize length = (*javaEnv)->GetArrayLength(javaEnv, java_array);
  jboolean isCopy;
  char *array = (*javaEnv)->GetByteArrayElements(javaEnv, java_array, &isCopy);

  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  size_t size = shm_io_write(io, io->out, array, length);
#ifndef DEBUG_SEGV
  if(isCopy){
    (*javaEnv)->ReleaseByteArrayElements(javaEnv, java_array, array, JNI_ABORT);
  }
#endif

//  printf("\033[0;33m[%s] isCopy = %d\033[0m\n", __func__, isCopy);
  return length;
}
*/

/*
JNIEXPORT jbyteArray JNICALL Java_RJNI_shmRead (JNIEnv *javaEnv,
	       	jobject thisObj, jlong jshm_ptr){

  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  size_t size;
  //char *tmp_shm_name = NULL; // no used for now...
//  printf("[%s] shm_name = %s\n", __func__, io->shm_info.shm_name);
  //void *array = shm_io_read(io->in, &size, &tmp_shm_name);
  void *array = shm_io_read(io, io->in, &size, NULL);
  jsize length = (jsize) size;
  jbyteArray jarray = (*javaEnv)->NewByteArray(javaEnv, length);
  (*javaEnv)->SetByteArrayRegion(javaEnv, jarray, 0,  length, array);

  free(array);

  return jarray;
}
*/

/*
JNIEXPORT jbyteArray JNICALL Java_RJNI_shmReadErrorStream (JNIEnv *javaEnv,
	       	jobject thisObj, jlong jshm_ptr){
  shm_io_info_t *io = (shm_io_info_t *) jshm_ptr;
  size_t size;
  //char *tmp_shm_name = NULL; // no used for now...

  //printf("\033[0;31m[%s] is called\n", __func__);

  int rc = sem_trywait(&io->err->sem_wr);
  void *array;
  if(rc == 0){
    size = sizeof(int)+ io->err->data_size;
    array = malloc(size);
    memcpy(array, &rc, sizeof(int));
    memcpy(array + sizeof(int), io->err+1, io->err->data_size);
    io->err->data_size = 0;
    sem_post(&io->err->sem_wr);
  } else {
    char *err = strerror(errno);
    size = sizeof(int)+strlen(err);
    array = malloc(size);
    memcpy(array, &rc, sizeof(int));
    memcpy(array + sizeof(int), err, strlen(err));
  }

  jsize length = (jsize) size;
  jbyteArray jarray = (*javaEnv)->NewByteArray(javaEnv, length);
  (*javaEnv)->SetByteArrayRegion(javaEnv, jarray, 0,  length, array);

  free(array);

  return jarray;
}
*/


/*
jbyteArray r2jbyteArray(SEXP x, SEXP env){
  
    //printf("[%s] type2char(TYPEOF(x)) = %s\n", __func__, type2char(TYPEOF(x)));

    SEXP call = PROTECT(LCONS(install("serialize"),
                        CONS(x, CONS(R_NilValue, R_NilValue))));
    //PrintValue(call);
    SEXP raw_vec = PROTECT(eval(call, env));
    //char *data_ptr=(char*) RAW(raw_vec);// or DATAPTR(raw_vec);?
    jsize size = LENGTH(raw_vec);


    jbyteArray ja = (*javaEnv)->NewByteArray(javaEnv, size);
    (*javaEnv)->SetByteArrayRegion(javaEnv, ja, 0, size, RAW(raw_vec));
    // for now
    UNPROTECT(2);
    return ja;

}
*/

// return is iterator...
int shm_io_write_javaObject(shm_io_info_t *io, SEXP x, SEXP env, SEXP *iter,
		const char *className)
{

  SEXP class = getAttrib(x, R_ClassSymbol);
  if(TYPEOF(class) != NILSXP){
    printf("[%s] ",__func__);
    PrintValue(class);
    const char *class_name = CHAR(STRING_ELT(class, 0));
    if(strcmp(class_name, "iterator")==0){
      printf("[%s] class_name = %s\n", __func__, class_name);
      char *class_name = "java.util.Iterator";
      shm_io_write(io, io->out, class_name, strlen(class_name));
      char *shm_name = io->shm_info.shm_name; // use io->err
      //sprintf(shm_name, "/dev/shm/testing");
      shm_io_write(io, io->out, shm_name, strlen(shm_name));
      *iter = x;
      return 1;
    } else  if(strcmp(class_name, "jObject")==0){
      char *class_name = "java.lang.Object";
      shm_io_write(io, io->out, class_name, strlen(class_name));
      char *ref_name = R_ExternalPtrAddr(x);
      shm_io_write(io, io->out, ref_name, strlen(ref_name));
      return 0;
    }
  }

  switch(TYPEOF(x)){
    case NILSXP:
	 { // "java.util.Object" ?
	   unsigned char c = 0; // byte 
	   shm_io_write(io, io->out, &c, 1);
	 }
	 break;
    case STRSXP:
	 {
           if(className && strcmp(className, "java.lang.String")==0){
	     char *class_name = "java.lang.String";
	     shm_io_write(io, io->out, class_name, strlen(class_name));
	     char *val = (char*) CHAR(STRING_ELT(x,0));
	     shm_io_write(io, io->out, val, strlen(val));
	   } else {
	     int n = LENGTH(x);
	   //char *class_name = "[java.lang.String";
	     char *class_name = "[Ljava.lang.String;";
	     shm_io_write(io, io->out, class_name, strlen(class_name));
	     shm_io_write(io, io->out, &n, sizeof(int));
	     for(int i=0; i<n; i++){
	       char *val = (char*) CHAR(STRING_ELT(x, i));
	       shm_io_write(io, io->out, val, strlen(val));
	     }
	   }
	 }
	 break;
    case SYMSXP:
	 {
	   char *class_name = "java.lang.String";
	   shm_io_write(io, io->out, class_name, strlen(class_name));
	   char *val = (char*) CHAR(PRINTNAME(x));
	   shm_io_write(io, io->out, val, strlen(val));
	 }
	 break;
    case INTSXP:
	 { // FIXME by using parTypes???
           if(className){
		 printf("[%s] className = %s\n", __func__, className);
             if(strcmp(className, "java.lang.Integer")==0
                || strcmp(className, "java.lang.Object")==0){
	       char *class_name = "java.lang.Integer";
	       shm_io_write(io, io->out, class_name, strlen(class_name));
	       int *val = (int*) INTEGER(x);
	       shm_io_write(io, io->out, val, sizeof(int));
	     } else if (strcmp(className, "[I")==0){
	       char *class_name = "[I";
	       shm_io_write(io, io->out, class_name, strlen(class_name));
	       int *val = (int*) INTEGER(x);
	       int len = LENGTH(x);
	       shm_io_write(io, io->out, &len, sizeof(int));
	       shm_io_write(io, io->out, val, sizeof(int)*LENGTH(x));
	     } else {
	       errorcall(R_NilValue, "unknown type '%s'", className);
	     }
	   } else {
	     char *class_name = "java.lang.Integer";
	     shm_io_write(io, io->out, class_name, strlen(class_name));
	     int *val = (int*) INTEGER(x);
	     shm_io_write(io, io->out, val, sizeof(int));
	   }
	 }
	 break;
    case REALSXP:
	 { // FIXME by using parTypes???
	   char *class_name = "java.lang.Integer";
	   shm_io_write(io, io->out, class_name, strlen(class_name));
	   double *val = (double*) REAL(x);
	   shm_io_write(io, io->out, val, sizeof(double));
	 }
	 break;
    case VECSXP: // for now
	 {
	   int n = LENGTH(x);
	   char *class_name = "[Ljava.lang.Object;";
	   shm_io_write(io, io->out, class_name, strlen(class_name));
	   shm_io_write(io, io->out, &n, sizeof(int));
	   for(int i=0; i<n; i++){
             shm_io_write_javaObject(io, VECTOR_ELT(x, i), env, iter, NULL);
	   }
	 }
    default: // FIXME
	 {
		 // "java.util.Object" ?
	   unsigned char c = 0; // byte 
	   shm_io_write(io, io->out, &c, 1);
	   warning("[%s] not implemented type: %s", __func__,
			   type2char(TYPEOF(x)));
	 }
	 break;
  }
  return 0;
}

SEXP R_asChar(SEXP x) {
  return STRING_ELT(x, 0);
}

SEXP shm_io_read_javaRFuture(SEXP shm_conn, shm_io_info_t *io, SEXP env);

/*
SEXP shm_io_read_javaObject(SEXP shm_conn, shm_io_info_t *io, SEXP env)
{
  // class name:
  size_t size;

  //printf("\033[0;31m[%s] R> Read Class Name ...\033[0m\n", __func__);
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  if(size == 0){
    warning("shm_io_read is interrupted (?) FIXME (%s, %d)",__FILE__, __LINE__);
    ptr = shm_io_read(io, io->in, &size, NULL);
  }

  //printf("\033[0;31m[%s] size = %ld\033[0m\n", __func__, size);


  
  if(size ==1  && *((unsigned char*) ptr) < 8) {
    unsigned char rc = *((unsigned char*) ptr);
    free(ptr);
    printf("\033[0;31m[%s] size = %ld, rc = %d\033[0m\n", __func__, size, rc);
    if(rc == 0)
      return R_NilValue;
    else 
      errorcall(R_NilValue, "rc = %d (%s, %d)", rc, __FILE__, __LINE__);
    //else {
      //shm_io_reset(io, io->in);
      //kill(javaDriver_PID, SIGUSR1);
      //errorcall(R_NilValue, "Exception (...)");
      //return R_NilValue;
    //}
  }

  char *className = (char*)ptr;
  if(className[size-1]!=0){
    className = malloc(size+1);
    memcpy(className, ptr, size);
    className[size] = 0;
    free(ptr);
  }

  //printf("\033[0;31m[%s] className = \"%s\"\033[0m\n", __func__, className);

  if(strcmp(className, "java.util.Vector")==0){
    free(className);

    ptr = shm_io_read(io, io->in, &size, NULL);
    //printf("[%s] size = %ld\n", __func__, size);
    int n = ((int*)ptr)[0];

    SEXP val = PROTECT(allocVector(VECSXP, n)); 
    for(int i=0; i<n; i++)
      SET_VECTOR_ELT(val, i, shm_io_read_javaObject(shm_conn, io, env));
    UNPROTECT(1);
    return val;
  } else if(strcmp(className, "[Ljava.lang.String;")==0){
    ptr = shm_io_read(io, io->in, &size, NULL);
    int n = ((int*)ptr)[0];
    free(ptr);
    SEXP val = PROTECT(allocVector(STRSXP, n));
    for(int i=0; i<n; i++){
      ptr = shm_io_read(io, io->in, &size, NULL);
      char *str = (char*) ptr;
      if(str[size-1]!=0){
        str = (char*) malloc(size+1); memcpy(str, ptr, size); str[size] = 0;
        free(ptr);
      }
      SET_STRING_ELT(val, i, mkChar(str));
      free(str);
    }
    UNPROTECT(1);
    return val;

  } else if(strcmp(className, "DDInfo")==0){
    // read dd_name
    //printf("[%s] className = %s\n", __func__, className);
    ptr = shm_io_read(io, io->in, &size, NULL);
    char *str = (char*) ptr;
    if(str[size-1]!=0){
      str = (char*) malloc(size+1); memcpy(str, ptr, size); str[size] = 0;
      free(ptr);
    }
    //printf("[%s] dd_name = %s\n", __func__, str);
    SEXP dd = PROTECT(allocVector(VECSXP, 2));
    SET_VECTOR_ELT(dd, 0, mkString(str)); free(str);
    SEXP names = PROTECT(allocVector(STRSXP, 2));
    SET_STRING_ELT(names, 0, mkChar("name"));
    SET_STRING_ELT(names, 1, mkChar("subsets"));
    setAttrib(dd, R_NamesSymbol, names);

    //SEXP dd_name = PROTECT(mkString(str)); free(str);
    //SEXP dd = PROTECT(allocSExp(ENVSXP));
    //SET_ENCLOS(dd, env);
    //defineVar(install("name"), dd_name, dd); 
    // read size
    ptr = shm_io_read(io, io->in, &size, NULL);
    int t_size = ((int*)ptr)[0];
    free(ptr);

    SEXP subsets = PROTECT(allocVector(VECSXP, t_size));
    SET_VECTOR_ELT(dd, 1, subsets);
    names = PROTECT(allocVector(STRSXP, t_size));


    //printf("[%s] size = %d\n", __func__, t_size);
    for(int i=0; i<t_size; i++){
      ptr = shm_io_read(io, io->in, &size, NULL);
      char *str = (char*) ptr; // key
      if(str[size-1]!=0){
        str = (char*) malloc(size+1); memcpy(str, ptr, size); str[size] = 0;
        free(ptr);
      }
      SEXP val = PROTECT(shm_io_read_javaObject(shm_conn, io, env));
      //defineVar(install(str), val, dd);
      SET_STRING_ELT(names, i, mkChar(str));
      SET_VECTOR_ELT(subsets, i, val);
      free(str);
      UNPROTECT(1);
    }
    setAttrib(subsets, R_NamesSymbol, names);
    UNPROTECT(4);
    setAttrib(dd, R_ClassSymbol, mkString("DD"));
    return dd;

  } else if(strcmp(className, "java.lang.Boolean")==0){
    free(className);
    ptr = shm_io_read(io, io->in, &size, NULL);
    //printf("[%s] size = %ld\n", __func__, size);
    SEXP val = ScalarLogical((int) ((unsigned char*) ptr)[0]);
    free(ptr);
    return val;

  } else if(strcmp(className, "java.lang.String")==0){
    free(className);

    ptr = shm_io_read(io, io->in, &size, NULL);
    //printf("[%s] size = %ld\n", __func__, size);

    char *str = ptr;
    if(str[size-1]){
      str = malloc(size+1);
      memcpy(str, ptr, size);
      str[size] = 0;
      free(ptr);
    }
    SEXP val = mkString(str);
    free(str);
    return val;

  } else if(strcmp(className, "java.lang.Integer")==0){
    free(className);

    ptr = shm_io_read(io, io->in, &size, NULL);
    //printf("[%s] size = %ld\n", __func__, size);

    int val = ((int*)ptr)[0];
    free(ptr);
    return ScalarInteger(val);

  } else if(strcmp(className, "[B")==0){// take it as serialized R obj...for now
    free(className);

    ptr = shm_io_read(io, io->in, &size, NULL);
    //printf("[%s] size = %ld\n", __func__, size);
#ifdef USE_SUPR_SERIALIZE
    SEXP val = supr2r((supr_header_t *) ptr, size, env);
    free(ptr);
    return val;
    // check ...
#else
    if(FALSE){ // fixme by using a single secheme ??
      size -= 4*sizeof(int);

      SEXP raw = PROTECT(allocVector(RAWSXP, size));
      memcpy(RAW(raw), ptr+4*sizeof(int), size);
      free(ptr);

      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
      SEXP val  = PROTECT(eval(call, env));
      UNPROTECT(3);
      return val;
    } else {
      SEXP raw = (SEXP) ptr;

      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
      SEXP val  = PROTECT(eval(call, env));
      free(ptr);
      UNPROTECT(2);
      return val;
    } 
#endif

  } else if (strstr(className, "RFuture")) {
    free(className);
    return shm_io_read_javaRFuture(shm_conn, io, env);
  } else if (strstr(className, "Exception")) {
    ptr = shm_io_read(io, io->in, &size, NULL);
    //printf("[%s] size = %ld\n", __func__, size);

    char *str = ptr;
    if(str[size-1]){
      str = malloc(size+1);
      memcpy(str, ptr, size);
      str[size] = 0;
      free(ptr);
    }
    char errmsg[strlen(str)+2 + strlen(className)+1];
    sprintf(errmsg, "%s: %s", className, str);
    free(str);
    free(className);

    javaExceptionOccurred = TRUE;

    errorcall(R_NilValue, "%s", errmsg);
  } else {
//    printf("\033[0;31m[%s: TODO] className = \"%s\"\033[0m\n", __func__, className);
//    return R_NilValue;
    ptr = shm_io_read(io, io->in, &size, NULL);
    char *str = ptr;
    if(str[size-1]){
      str = malloc(size+1);
      memcpy(str, ptr, size);
      str[size] = 0;
      free(ptr);
    }

    SEXP name = PROTECT(mkString(str));
    SEXP val = PROTECT(R_MakeExternalPtr(str, R_NilValue, name));
    setAttrib(val, R_ClassSymbol, mkString("jObject"));
    setAttrib(val, R_NameSymbol, name);
    UNPROTECT(2);
    return val;

    //free(str);
  }

}
*/

//#define ERROR_SUCCESS 0
typedef struct str_error_struct {
  int err_no;
  const char *errstr;
} str_error_t;

static str_error_t strerrors[] = {
  {0, "success"},
  {1, "failure"}
};

static const char *R_strerror(int err_no){
	/*
  switch(err_no){ // use "data base"?
	  case ERROR_SUCCESS: return "success";
  }
  */
  for(int i=0; i<sizeof(strerrors)/sizeof(str_error_t); i++)
    if(strerrors[i].err_no == err_no) return strerrors[i].errstr;

  fprintf(stderr, "Unknown error nomber (%d)\n", err_no);
  return "Unknown error";
}

SEXP R_try_shmRead(SEXP shm_conn, SEXP env)
{
  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);
  int can_read  = io->in->data_size > 0; // can read without blocking
  if(can_read){
    size_t size;
    //char *shm_name = NULL; // not used yet
    unsigned char *bytes = shm_io_read(io, io->in, &size, NULL);
    SEXP raw = allocVector(RAWSXP, size);
    memcpy(RAW(raw), bytes, size);
    free(bytes);
    return raw;
  } else {
    return R_NilValue;
  }
}

/*
static void SUPR_resetIntsigHandler (void *ptr){
  fprintf(stderr, "[%s] R_isInterrupted = %d\n", __func__, R_isInterrupted);

  SEXP shm_conn = (SEXP) ((void **)ptr)[0];
  SEXP env = (SEXP) ((void **)ptr)[1];

  R_resetIntsigHandler();

  if(javaExceptionOccurred){
    javaExceptionOccurred = FALSE;
    shm_io_info_t *io = (shm_io_info_t *) ((void **)ptr)[2];

    // read the sync obj reference
    printf("[%s] Read sync object reference ...\n", __func__);
    //SEXP val= PROTECT(shm_io_read_javaObject(shm_conn, io, env));
    size_t size;
    void *p = shm_io_read(io, io->in, &size, NULL);
    printf("[%s] Read sync object reference ... size = %ld\n", __func__, size);
    printf("[%s] Read sync object reference ... className = %s\n",
		    __func__, (char*)p);
    free(p);
    p = shm_io_read(io, io->in, &size, NULL);
    printf("[%s] Read sync object reference ... size = %ld\n", __func__, size);
    printf("[%s] Read sync object reference ... reference = %s\n",
		    __func__, (char*)p);

    //sprintf(jSyncObject, "%s", (char*) p);
    memcpy(jSyncObject, p, size);
    jSyncObject[size] = 0;

    free(p);

    
    // io reset
    shm_io_reset(io, io->in);

    // notify
    printf("[%s] notify ...\n", __func__);
    socket_sync_notify(R_NilValue);
  }
}
*/

// J_eval
/*
SEXP R_java_eval(SEXP shm_conn,
	       	SEXP class,
	       	SEXP fun,
	        SEXP argTypes,
	        SEXP jObject,
	       	SEXP args,
	        SEXP env)
{
  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);
  const char *jm_class = CHAR(STRING_ELT(class, 0));
  const char *jm_name  = CHAR(STRING_ELT(fun, 0));
  int argc = LENGTH(args);


  RCNTXT cntxt;
  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
		 R_NilValue, R_NilValue);

    R_isInterrupted = FALSE;
    R_setIntsigHandler();

    int line = __LINE__;
    cntxt.cend = SUPR_resetIntsigHandler;
    void *cenddata[] = {shm_conn, env, io};
    cntxt.cenddata = cenddata; // &io; //&line;

#define CALL_METHOD 102
    // [cmd, argc, class_name, method_name] -- fixme: make use of parTypes
    int cmd = CALL_METHOD;
    char jm[2*sizeof(int)+strlen(jm_class)+strlen(jm_name)+2];
    memcpy(jm, &cmd, sizeof(int));
    memcpy(jm+sizeof(int), &argc, sizeof(int));
    sprintf(jm+2*sizeof(int), "%s#%s", jm_class, jm_name);
    size_t size = shm_io_write(io, io->out, jm, sizeof(jm));
    char *shm_name = NULL; // not used yet

    line = __LINE__;

    int *rc = shm_io_read(io, io->in, &size, NULL);
    if(rc[0]) {
      int err_no = rc[0];
      free(rc);
      errorcall(R_NilValue, "%s", R_strerror(rc[0]));
    }
    free(rc);
#undef CALL_METHOD

    //{ // argTypes: writeString
    if(TYPEOF(argTypes) != NILSXP)
      shm_io_write(io, io->out, (void*) CHAR(STRING_ELT(argTypes,0)),
	    strlen(CHAR(STRING_ELT(argTypes,0)))+1); // no +1??
    else {
      char *s = "";
      shm_io_write(io, io->out, s, strlen(s)+1); // no +1??
    }
    //}

    SEXP iter = R_NilValue;
    //{ // Object:
    shm_io_write_javaObject(io, jObject, env, &iter, NULL);
    //}

    int has_iterator = 0;
    char *types[argc];

    //char str[strlen(CHAR(STRING_ELT(argTypes,0)))+1];
    char *s = TYPEOF(argTypes) == NILSXP ? NULL 
	    : malloc(strlen(CHAR(STRING_ELT(argTypes,0)))+1);
    char *str = s;
    if(s){
      memcpy(s, CHAR(STRING_ELT(argTypes,0)),
		      strlen(CHAR(STRING_ELT(argTypes,0)))+1);
      //printf("[%s]  %s\n", __func__, s);
      for(int i=0; i<argc; i++){
        types[i] = s; //      printf("[%s:%d/%d]  %s\n", __func__, (i+1), argc, types[i]);
        while(*s && *s != '#') s++;
	line = __LINE__;
        if(*s==0 && i < argc-1) 
          errorcall(R_NilValue, "invalid argments 'parTypes' and 'args'");
        *s = 0;
        s++; //      printf("[%s:%d/%d]  %s\n", __func__, (i+1), argc, types[i]);
      }
    } else {
      for(int i=0; i<argc; i++) types[i] = NULL;
    }

    for(int i=0; i<argc; i++){
//      printf("[%s:%d/%d]  %s\n", __func__, (i+1), argc, types[i]);
    
      int hi = shm_io_write_javaObject(io, VECTOR_ELT(args, i), env, &iter,
		    types[i]);
      if(hi) 
        has_iterator = 1;
    }
    if(str) free(str);

    if(has_iterator){ // testing

      while(TRUE){
        size_t size;
        //char *shm_name = NULL; // not used yet
	line = __LINE__;
        char *rc = shm_io_read(io, io->in, &size, NULL);
        //printf("\033[0;34m[%s:iterator] %s\033[0m\n", __func__, rc);
        if(strcmp(rc, "hasNext")==0){
          free(rc);

          SEXP call = PROTECT(LCONS(install("hasNext"), R_NilValue));
	  SEXP val = PROTECT(eval(call, iter));

          int hasNext = LOGICAL(val)[0];
	  UNPROTECT(2);

          shm_io_write(io, io->out, &hasNext, sizeof(int));
	  if(!hasNext)
       	    break;
        } else if(strcmp(rc, "getNext")==0){
          free(rc);

          SEXP call = PROTECT(LCONS(install("getNext"), R_NilValue));
	  SEXP val = PROTECT(eval(call, iter));


	  if(TYPEOF(val)==VECSXP){ // FIXME
            const char *name = CHAR(STRING_ELT(VECTOR_ELT(val,0), 0));
#ifdef USE_SUPR_SERIALIZE
	    size_t size;
	    void *raw = SUPR_serialize(VECTOR_ELT(val,1), env, &size);
	    unsigned char *ptr = malloc(strlen(name)+1+size);
	    memcpy(ptr, name, strlen(name));
	    unsigned char c = '#';
	    memcpy(ptr + strlen(name), &c, 1);
	    memcpy(ptr + strlen(name)+ 1, raw, size);
            shm_io_write(io, io->out, ptr, strlen(name)+ 1+ size);
	    free(ptr);
#else
	  SEXP raw = TR_serialize(VECTOR_ELT(val,1), env);
	  size_t len = (long)RAW(raw)-(long)raw+LENGTH(raw);
	  unsigned char *ptr = malloc(strlen(name)+1+len);
	  memcpy(ptr, name, strlen(name));
	  unsigned char c = '#';
	  memcpy(ptr + strlen(name), &c, 1);
	  memcpy(ptr + strlen(name)+ 1, raw, len);
          shm_io_write(io, io->out, ptr, strlen(name)+ 1+len);
	  free(ptr);
#endif
	    UNPROTECT(2);
	  } else {
#ifdef USE_SUPR_SERIALIZE
	    size_t size;
	    void *raw = SUPR_serialize(val, env, &size);
            shm_io_write(io, io->out, raw, size);
#else
	  SEXP raw = TR_serialize(val, env);
          shm_io_write(io, io->out, raw, (long)RAW(raw)-(long)raw+LENGTH(raw));
	  UNPROTECT(2);
#endif
	  }

        }
      }
    }

    line = __LINE__;

    SEXP val= shm_io_read_javaObject(shm_conn, io, env);


  endcontext(&cntxt);
  return val;
}
*/

typedef struct R_future {
  char *name; // TODO
} R_future_t;

static void R_future_finalizer(SEXP f)
{
  R_future_t *future = (R_future_t*) R_ExternalPtrAddr(f);
  printf("\033[0;31m[%s] is called\033[0m\n", __func__);
}

//extern SEXP R_CurrentExpression;

#ifdef USE_JAVA

extern shm_io_info_t *driver_io;

/* supr.h:
typedef struct supr_object_struct {
  int ref_count;
  int mem_type;
  int sys_type;
  int obj_type;
  size_t size; // data_size, followed by data
} so_t;

 */

// handle error ... through signal??
/*
int shm_io_readInt(shm_io_info_t *io)
{
  size_t data_size;
  int *intVal = (int*) shm_io_read(io, io->in, &data_size, NULL);
  return intVal[0];
}

int shm_io_writeInt(shm_io_info_t *io, int val)
{
  return shm_io_write(io, io->in, &val, sizeof(int));
}

void shm_io_writeSuprObject(shm_io_info_t *io, SEXP r_object)
{
  size_t size;
  void *data = R_objectToBytes(r_object, &size);
  so_t *so = malloc(sizeof(so_t) + size);

  so->ref_count  = 0;
  so->mem_type  =  0; // TODO
  so->sys_type  =  0;
  so->obj_type = SUPR_SERIALIZED_ROBJ;
  so->size  = size;

  memcpy(so + sizeof(so_t), data,  size);
  size_t n = shm_io_write(io, io->out, so, sizeof(so_t) + size);
  free(so); // fixme by using strbuf...
}
*/

/*
SEXP __R_cluster_eval(SEXP expr, SEXP x, SEXP envir, SEXP par,
	       	SEXP env, SEXP wait, SEXP dcl, SEXP dcl_expr, SEXP dcl_envir)
{
  shm_io_info_t *io = driver_io;//(shm_io_info_t *) R_ExternalPtrAddr(shm_conn);

  if(TYPEOF(x) == VECSXP){
  } else {
    errorcall(R_NilValue, "not implemented for %s data type",
		    type2char(TYPEOF(x)));
  }

  int cmd = DU_JOB_SUBMIT;
  size_t n = shm_io_write(io, io->out, &cmd, sizeof(int));

  size_t data_size;
  int job_id = shm_io_readInt(io);

  // args
  SEXP ee = PROTECT(allocVector(VECSXP, 3));
  SEXP expr_names = PROTECT(allocVector(STRSXP, 3));
  SET_VECTOR_ELT(ee, 0, expr);
  SET_VECTOR_ELT(ee, 1, envir);
  SET_VECTOR_ELT(ee, 2, ScalarInteger(job_id));
  SET_STRING_ELT(expr_names, 0, mkChar("expr"));
  SET_STRING_ELT(expr_names, 1, mkChar("envir"));
  SET_STRING_ELT(expr_names, 2, mkChar("id"));
  setAttrib(ee, R_NamesSymbol, expr_names);

  shm_io_writeSuprObject(io, ee);
  shm_io_writeSuprObject(io, x);
  shm_io_writeInt(io, LOGICAL(wait)[0]);


  return R_NilValue;


  //static int job_id = 0;

  if(LOGICAL(wait)[0]){
    R_isInterrupted = FALSE;
    R_setIntsigHandler();
  }

  // Call java method
  char *jm_class = "Driver";
  char *jm_name  = "submitJob";
  char *jm_par   = "(Ljava/lang/String;Ljava/lang/String;Ljava/util/Hashtable;[B;Ljava/lang/String;[B;I)Ljava/lang/Object;";

#define CALL_METHOD 101
  int cmd = CALL_METHOD;
  char jm[sizeof(int)+strlen(jm_class)+strlen(jm_name)+strlen(jm_par)+3];
  memcpy(jm, &cmd, sizeof(int));
  sprintf(jm+sizeof(int), "%s#%s#%s", jm_class, jm_name, jm_par);
  size_t n = shm_io_write(io, io->out, jm, sizeof(jm));
#undef CALL_METHOD

  char job_name[128];
  sprintf(job_name, "job.%d", (job_id+1));
  n = shm_io_write(io, io->out, job_name, strlen(job_name));

  char *dd_name = NULL; // "mydata_02";
  if(TYPEOF(x)==SYMSXP){
    dd_name = (char*) CHAR(PRINTNAME(x));
  } else if(TYPEOF(x)==STRSXP){
    dd_name = (char*) CHAR(STRING_ELT(x,0));
  } else {
	  errorcall(R_NilValue, "invalid argument 'x'");
  }
  

  n = shm_io_write(io, io->out, dd_name, strlen(dd_name));



if(FALSE){
  SEXP ee = PROTECT(allocVector(VECSXP, 3));
  SEXP expr_names = PROTECT(allocVector(STRSXP, 3));

  SET_VECTOR_ELT(ee, 0, expr);
  SET_VECTOR_ELT(ee, 1, envir);
  SET_VECTOR_ELT(ee, 2, ScalarInteger(job_id++));
  SET_STRING_ELT(expr_names, 0, mkChar("expr"));
  SET_STRING_ELT(expr_names, 1, mkChar("envir"));
  SET_STRING_ELT(expr_names, 2, mkChar("id"));
  setAttrib(ee, R_NamesSymbol, expr_names);
}
 

#ifdef USE_SUPR_SERIALIZE
  size_t size;
  void *raw = SUPR_serialize(ee, env, &size);
  n = shm_io_write(io, io->out, raw, size);
  free(raw);

  //// add dcl and dcl_expr

  char *dcl_name = NULL; // "mydata_02";
  if(TYPEOF(dcl)==SYMSXP){
    dcl_name = (char*) CHAR(PRINTNAME(dcl));
  } else if(TYPEOF(dcl)==STRSXP){
    dcl_name = (char*) CHAR(STRING_ELT(dcl,0));
  } else {
    errorcall(R_NilValue, "invalid argument 'dcl'");
  }

  n = shm_io_write(io, io->out, dcl_name, strlen(dcl_name));

  SET_VECTOR_ELT(ee, 0, dcl_expr);
  SET_VECTOR_ELT(ee, 1, dcl_envir);
  SET_VECTOR_ELT(ee, 2, ScalarInteger(job_id - 1));
  SET_STRING_ELT(expr_names, 0, mkChar("expr"));
  SET_STRING_ELT(expr_names, 1, mkChar("envir"));
  SET_STRING_ELT(expr_names, 2, mkChar("id"));

  setAttrib(ee, R_NamesSymbol, expr_names);

  raw = SUPR_serialize(ee, env, &size);
  n = shm_io_write(io, io->out, raw, size);
  free(raw);
  ////

  int c_wait = LOGICAL(wait)[0];
  n = shm_io_write(io, io->out, &c_wait, sizeof(int));

  UNPROTECT(2);
#else
  SEXP call = PROTECT(LCONS(install("serialize"), CONS(ee, CONS(R_NilValue,
					  R_NilValue))));
  SEXP raw = PROTECT(eval(call, env));
//  n = shm_io_write(io, io->out, RAW(raw), LENGTH(raw));
  n = shm_io_write(io, io->out, raw, (long)RAW(raw)-(long)raw + LENGTH(raw));

  int c_wait = LOGICAL(wait)[0];
  n = shm_io_write(io, io->out, &c_wait, sizeof(int));

  UNPROTECT(4);
#endif

if(FALSE){
  size_t size;
  char *shm_name = NULL;
  void *ptr = shm_io_read(io, io->in, &size, &shm_name);
  printf("[%s] size = %ld\n", __func__, size);
}

  //R_isInterrupted = FALSE;
  //R_setIntsigHandler();
//  return R_NilValue;

  if(LOGICAL(wait)[0]){

    printf("[%s] Read sync object reference ...\n", __func__);
    SEXP val= PROTECT(shm_io_read_javaObject(shm_conn, io, env));

    printf("[%s] sync object reference (sizeof(jSyncObject)=%ld):\n",
		    __func__, sizeof(jSyncObject));
    PrintValue(val);
    if(TYPEOF(val)==EXTPTRSXP){
      printf("[%s] sync object reference: %s\n", __func__,
		      CHAR(STRING_ELT(getAttrib(val, R_NameSymbol),0)));
      printf("[%s] sync object reference: %s\n", __func__, (char*)
		      R_ExternalPtrAddr(val));
      sprintf(jSyncObject, "%s", (char*) R_ExternalPtrAddr(val));
    }


    val= PROTECT(shm_io_read_javaObject(shm_conn, io, env));
    if(R_isInterrupted) {
      warning("interrupted cluster_eval");
      R_resetIntsigHandler();
      SEXP class = getAttrib(val, R_ClassSymbol);
      if(TYPEOF(class) != NILSXP){
        warning("\033[0;33mreturn(an object of %s)\033[0m",
		       	CHAR(STRING_ELT(class, 0)));
      }
    }
    UNPROTECT(2);
    {
	    //PrintValue(R_CurrentExpression);
    }
    return val;
  } else { // get a future object ... // use shm???
    size_t size;
    //char *shm_name = NULL;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    printf("[%s] size = %ld\n", __func__, size);
    free(ptr);
    return shm_io_read_javaRFuture(shm_conn, io, env);
  }
}
*/


SEXP shm_io_read_javaRFuture(SEXP shm_conn, shm_io_info_t *io, SEXP env)
{
    size_t size;
    //char *shm_name = NULL;
    void *ptr = shm_io_read(io, io->in, &size, NULL);

    printf("[%s] size = %ld\n", __func__, size);
    printf("[%s] ((char*)ptr)[size-1] = %d\n", __func__, ((char*)ptr)[size-1]);
    char *f_name = (char*) ptr;
    if(f_name[size-1]){
      f_name = malloc(size+1);
      memcpy(f_name, ptr, size);
      f_name[size] = 0;
      free(ptr);
    }
    //SEXP val = mkString(f_name);

    SEXP ret = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(ret, env);

    R_future_t *future = (R_future_t *) malloc(sizeof(R_future_t));
    SEXP val = PROTECT(R_MakeExternalPtr(future, install("future"),
			    mkString(f_name)));
    free(f_name);
    R_RegisterCFinalizerEx(val, R_future_finalizer, TRUE);

    defineVar(install("java_future"), val, ret);
    UNPROTECT(1);

    // get(timeout)
    SEXP fun = PROTECT(allocSExp(CLOSXP));
    SEXP formals = PROTECT(CONS(ScalarInteger(0), R_NilValue));
    SET_TAG(formals, install("timeout"));
    SET_FORMALS(fun, formals);
    SET_CLOENV(fun, ret);
    SEXP doCall = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("R_future_get"), CONS(shm_conn,
		    CONS(install("timeout"), CONS(val, R_NilValue))))));
    SEXP body = PROTECT(LCONS(install("{"), R_NilValue));
    SETCDR(body, CONS(doCall, R_NilValue));
    SET_BODY(fun, body);
    // SETCDR(body, CONS(LCONS(last_func, null), CONS(doCall, null)));
    defineVar(install("get"), fun, ret);
    UNPROTECT(4);

    fun = PROTECT(allocSExp(CLOSXP));
    formals = PROTECT(CONS(ScalarLogical(1), R_NilValue));
    SET_TAG(formals, install("mayInterruptIfRunning"));
    SET_FORMALS(fun, formals);
    SET_CLOENV(fun, ret);
    doCall = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("R_future_cancel"), CONS(shm_conn,
		    CONS(install("mayInterruptIfRunning"),
			    CONS(val, R_NilValue))))));
    body = PROTECT(LCONS(install("{"), R_NilValue));
    SETCDR(body, CONS(doCall, R_NilValue));
    SET_BODY(fun, body);
    // SETCDR(body, CONS(LCONS(last_func, null), CONS(doCall, null)));
    defineVar(install("cancel"), fun, ret);
    UNPROTECT(4);

    fun = PROTECT(allocSExp(CLOSXP));
    SET_FORMALS(fun, R_NilValue);
    SET_CLOENV(fun, ret);

    doCall = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("R_future_isDone"), CONS(shm_conn,
		    CONS(val, R_NilValue)))));
    body = PROTECT(LCONS(install("{"), R_NilValue));
    SETCDR(body, CONS(doCall, R_NilValue));
    SET_BODY(fun, body);

    defineVar(install("is.done"), fun, ret);
    UNPROTECT(3);

    fun = PROTECT(allocSExp(CLOSXP));
    SET_FORMALS(fun, R_NilValue);
    SET_CLOENV(fun, ret);

    doCall = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("R_future_isCancelled"), CONS(shm_conn,
		    CONS(val, R_NilValue)))));
    body = PROTECT(LCONS(install("{"), R_NilValue));
    SETCDR(body, CONS(doCall, R_NilValue));
    SET_BODY(fun, body);

    defineVar(install("is.cancelled"), fun, ret);
    UNPROTECT(3);



    setAttrib(ret, R_ClassSymbol, mkString("future"));

    UNPROTECT(1);

    return ret;
}


SEXP R_future_get(SEXP shm_conn, SEXP r_timeout, SEXP future_ptr)
{
  double c_timeout = 0.0;
  if(TYPEOF(r_timeout) == REALSXP) 
    c_timeout = REAL(r_timeout)[0];
  else if(TYPEOF(r_timeout) == INTSXP) 
    c_timeout = INTEGER(r_timeout)[0];

  printf("[%s] c_timeout = %f\n", __func__, c_timeout);

  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);

  SEXP r_name = R_ExternalPtrProtected(future_ptr);
  const char *c_name = CHAR(STRING_ELT(r_name, 0));

  printf("[%s] c_timeout = %f, c_name=%s\n", __func__, c_timeout, c_name);

  unsigned char args[sizeof(int)+sizeof(double)+strlen(c_name)+1];
  ((int*)args)[0] = R_FUTURE_GET;
  memcpy(args+sizeof(int), &c_timeout, sizeof(double));
  memcpy(args+sizeof(int) + sizeof(double), c_name, strlen(c_name)+1);

  {
    R_isInterrupted = FALSE;
    R_setIntsigHandler();
  }

  shm_io_write(io, io->out, args, sizeof(args));
  
  SEXP val= shm_io_read_javaObject(shm_conn, io, R_GlobalEnv);

  if(R_isInterrupted) {
    errorcall(R_NilValue, "interrupted cluster_eval");
  } else {
    R_resetIntsigHandler();
    return val;
  }

  return val; // not reached
}



SEXP R_future_cancel(SEXP shm_conn, SEXP
	       	mayInterruptIfRunning
		, SEXP future_ptr)
{
  int c_mi = 0;
  if(TYPEOF(mayInterruptIfRunning) == REALSXP) 
    c_mi = REAL(mayInterruptIfRunning)[0]!=0;
  else if(TYPEOF(mayInterruptIfRunning) == INTSXP) 
    c_mi = INTEGER(mayInterruptIfRunning)[0]!=0;
  else if(TYPEOF(mayInterruptIfRunning) == LGLSXP) 
    c_mi = LOGICAL(mayInterruptIfRunning)[0]!=0;

  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);

  SEXP r_name = R_ExternalPtrProtected(future_ptr);
  const char *c_name = CHAR(STRING_ELT(r_name, 0));

  unsigned char args[2*sizeof(int)+strlen(c_name)+1];
  ((int*)args)[0] = R_FUTURE_CANCEL;
  ((int*)args)[1] = c_mi;
  memcpy(args+2*sizeof(int), c_name, strlen(c_name)+1);
  shm_io_write(io, io->out, args, sizeof(args));
  
  SEXP val= shm_io_read_javaObject(shm_conn, io, R_GlobalEnv);
  return val;
}

SEXP R_future_isDone(SEXP shm_conn, SEXP future_ptr)
{
  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);

  SEXP r_name = R_ExternalPtrProtected(future_ptr);
  const char *c_name = CHAR(STRING_ELT(r_name, 0));

  //printf("[%s] c_name=%s\n", __func__, c_name);

  unsigned char args[sizeof(int)+strlen(c_name)+1];
  ((int*)args)[0] = R_FUTURE_ISDONE;
  memcpy(args+sizeof(int), c_name, strlen(c_name)+1);
  shm_io_write(io, io->out, args, sizeof(args));
  
  SEXP val= shm_io_read_javaObject(shm_conn, io, R_GlobalEnv);
  return val;
}

SEXP R_future_isCancelled(SEXP shm_conn, SEXP future_ptr)
{
  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);

  SEXP r_name = R_ExternalPtrProtected(future_ptr);
  const char *c_name = CHAR(STRING_ELT(r_name, 0));

  printf("[%s] c_name=%s\n", __func__, c_name);

  unsigned char args[sizeof(int)+strlen(c_name)+1];
  ((int*)args)[0] = R_FUTURE_ISCANCELED;
  memcpy(args+sizeof(int), c_name, strlen(c_name)+1);
  shm_io_write(io, io->out, args, sizeof(args));
  
  SEXP val= shm_io_read_javaObject(shm_conn, io, R_GlobalEnv);
  return val;
}

#endif


//SEXP jR_mr(SEXP x, SEXP map, SEXP envir, SEXP par, SEXP env)
/*
SEXP jR_mr(SEXP x, SEXP map, SEXP envir, SEXP par, SEXP env)
{
  //PrintValue(env);
  static int job_id = 0;

  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "submitJob",
		  "(Ljava/lang/String;Ljava/lang/String;Ljava/util/Hashtable;[B)Ljava/lang/Object;");
  if(midCallBack == NULL){ printf("\033[0;31mmidCallBack = NULL\033[0m\n");
	  return R_NilValue; }

  char cjob_name[128];
  sprintf(cjob_name, "job.%d", (job_id+1));
  jstring jjob_name = (*javaEnv)->NewStringUTF(javaEnv, cjob_name);
  if(jjob_name == NULL){ printf("jjob_name = NULL\n"); return R_NilValue; }

  const char *cdd_name = "mydata_02";
  jstring jdd_name = (*javaEnv)->NewStringUTF(javaEnv, cdd_name);
  if(jdd_name == NULL){ printf("jdd_name = NULL\n"); return R_NilValue; }

  jclass hashtableClass = (*javaEnv)->FindClass(javaEnv,
		  "java/util/Hashtable");
  if(hashtableClass == NULL){
	  printf("\033[0;31mhashtableClass = NULL\033[0m\n");
	  return R_NilValue; }

  jmethodID cidCallBack = (*javaEnv)->GetMethodID(javaEnv, hashtableClass,
		  "<init>", "()V");
  if(cidCallBack == NULL){ printf("\033[0;31mcidCallBack = NULL\033[0m\n");
	  return R_NilValue; }

  jobject jpar = (*javaEnv)->NewObject(javaEnv, hashtableClass,
		  cidCallBack);
  if(jpar == NULL){ printf("\033[0;31mjpar = NULL\033[0m\n");
	  return R_NilValue; }

  {
    jmethodID putCallBack = (*javaEnv)->GetMethodID(javaEnv, hashtableClass,
		  "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
    if(putCallBack == NULL){ printf("\033[0;31mputCallBack = NULL\033[0m\n");
	  return R_NilValue; }

    SEXP par_names = getAttrib(par, R_NamesSymbol);
    int n = LENGTH(par_names);
    for(int i=0; i<n; i++){
       const char *ckey = CHAR(STRING_ELT(par_names, i));
       jstring jkey = (*javaEnv)->NewStringUTF(javaEnv, ckey);
       if(jkey == NULL){ printf("jkey = NULL\n"); return R_NilValue; }

       SEXP val = VECTOR_ELT(par, i);
       jbyteArray jval = r2jbyteArray(val, env);
       (*javaEnv)->CallObjectMethod(javaEnv, jpar, putCallBack, jkey, jval);
    }
  }

  SEXP ee = PROTECT(allocVector(VECSXP, 3));
  SEXP expr_names = PROTECT(allocVector(STRSXP, 3));

  SET_VECTOR_ELT(ee, 0, map);
  SET_VECTOR_ELT(ee, 1, envir);
  SET_VECTOR_ELT(ee, 2, ScalarInteger(job_id++));
  SET_STRING_ELT(expr_names, 0, mkChar("expr"));
  SET_STRING_ELT(expr_names, 1, mkChar("envir"));
  SET_STRING_ELT(expr_names, 2, mkChar("id"));
  setAttrib(ee, R_NamesSymbol, expr_names);

  //jbyteArray rExpr = r2jbyteArray(map, env);
  jbyteArray rExpr = r2jbyteArray(ee, env);

  UNPROTECT(2);

  // submit
  jobject jValue = (*javaEnv)->CallObjectMethod(javaEnv, javaCaller,
		  midCallBack,
		  jjob_name, jdd_name, jpar, rExpr);
  if(jValue == NULL){ printf("\033[0;31mjValue = NULL\033[0m\n");
	  return R_NilValue; }

  //printf("\nJavaCallBack: done\n");

  // jValue is a vector of objects
  jclass jValueClass = (*javaEnv)->GetObjectClass(javaEnv, jValue);
  jmethodID toArray_idCallBack = (*javaEnv)->GetMethodID(javaEnv, jValueClass,
		  "toArray", "()[Ljava/lang/Object;");
  if(toArray_idCallBack == NULL){
	  printf("\033[0;31mtoArray_idCallBack = NULL\033[0m\n");
	  return R_NilValue; }

  jobject jArray = (*javaEnv)->CallObjectMethod(javaEnv, jValue,
		  toArray_idCallBack);
  if(jArray == NULL){ printf("\033[0;31mjArray = NULL\033[0m\n");
	  return R_NilValue; }

  jsize length = (*javaEnv)->GetArrayLength(javaEnv, jArray);
  //printf("length = %d\n", length);

  SEXP rVector = PROTECT(allocVector(VECSXP, length-1));
  for (int i = 1; i < length; i++) {
    jbyteArray jbytes = (*javaEnv)->GetObjectArrayElement(javaEnv, jArray, i);
    jsize len = (*javaEnv)->GetArrayLength(javaEnv, jbytes);
    jboolean isCopy;
    void *array = (*javaEnv)->GetByteArrayElements(javaEnv, jbytes, &isCopy);

    size_t size = len - 4*sizeof(int);
    SEXP raw = PROTECT(allocVector(RAWSXP, size));
    memcpy(RAW(raw), array+4*sizeof(int), size);
    SEXP call = PROTECT(LCONS(install("unserialize"),
                                CONS(raw, R_NilValue)));
    SEXP ro = PROTECT(eval(call, R_GlobalEnv));

    //printf("Info: ROBJ (%s):\n", type2char(TYPEOF(ro)));
    //PrintValue(ro);
    SET_VECTOR_ELT(rVector, i-1, ro);
    UNPROTECT(3);
#ifndef DEBUG_SEGV
    if(isCopy){
      (*javaEnv)->ReleaseByteArrayElements(javaEnv, jbytes, array, JNI_ABORT);
    }
#endif
  }
  UNPROTECT(1);
  return rVector;
  //return R_NilValue;
}
*/

/*
SEXP R_startWorkers(SEXP shm_conn)
{
  // Call java method
  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(shm_conn);
  char *jm_class = "Driver";
  char *jm_name  = "startWorkers";
  char *jm_par   = "()V";

#define CALL_METHOD 101
  int cmd = CALL_METHOD;
  char jm[sizeof(int)+strlen(jm_class)+strlen(jm_name)+strlen(jm_par)+3];
  memcpy(jm, &cmd, sizeof(int));
  sprintf(jm+sizeof(int), "%s#%s#%s", jm_class, jm_name, jm_par);
  size_t n = shm_io_write(io, io->out, jm, sizeof(jm));
#undef CALL_METHOD

  return R_NilValue;
}
*/

// start workers (by DFSNodes/DataManagers)
/*
SEXP jdfs_startWorkers(){
  //jclass callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);
  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "startWorkers", "()V");
  if(midCallBack == NULL){ printf("midCallBack = NULL\n"); return R_NilValue; }

  (*javaEnv)->CallVoidMethod(javaEnv, javaCaller, midCallBack);
  return R_NilValue;
}
*/

/*
SEXP jdfs_stopWorkers(){
  //jclass callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);
  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "stopWorkers", "()V");
  if(midCallBack == NULL){ printf("midCallBack = NULL\n"); return R_NilValue; }

  (*javaEnv)->CallVoidMethod(javaEnv, javaCaller, midCallBack);
  return R_NilValue;
}
*/

/*
SEXP jdfs_startMaster(){
  //jclass callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);
  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "startMaster", "()V");
  if(midCallBack == NULL){ printf("midCallBack = NULL\n"); return R_NilValue; }

  (*javaEnv)->CallVoidMethod(javaEnv, javaCaller, midCallBack);
  return R_NilValue;
}
*/

/*
SEXP jdfs_stopMaster(){
  //jclass callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);
  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "stopMaster", "()V");
  if(midCallBack == NULL){ printf("midCallBack = NULL\n"); return R_NilValue; }

  (*javaEnv)->CallVoidMethod(javaEnv, javaCaller, midCallBack);
  return R_NilValue;
}
*/

/*
SEXP dfs_rm(SEXP dd_name) {
  jclass callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);

  const char *cdd_name = CHAR(STRING_ELT(dd_name, 0));
  jstring jdd_name = (*javaEnv)->NewStringUTF(javaEnv, cdd_name);
  if(jdd_name == NULL){ printf("jdd_name = NULL\n"); return R_NilValue; }

  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "removeDD", "(Ljava/lang/String;)[Ljava/lang/Object;");
  if(midCallBack == NULL){ printf("midCallBack = NULL\n"); return R_NilValue; }

  jobjectArray java_array = (*javaEnv)->CallObjectMethod(javaEnv, javaCaller,
                  midCallBack, jdd_name);
  if(java_array == NULL){
    printf("java_ret = NULL\n");
    return R_NilValue;
  }

  // TODO
  return R_NilValue;
}
*/

/*
SEXP dfs_ls(SEXP dd_name){
  jclass callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);

  //jstring jdd_name = (*javaEnv)->NewStringUTF(javaEnv, "mydata_02");
  const char *cdd_name = CHAR(STRING_ELT(dd_name, 0));
  jstring jdd_name = (*javaEnv)->NewStringUTF(javaEnv, cdd_name);
  if(jdd_name == NULL){ printf("jdd_name = NULL\n"); return R_NilValue; }

  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "listDD", "(Ljava/lang/String;)[Ljava/lang/Object;");
  if(midCallBack == NULL){ printf("midCallBack = NULL\n"); return R_NilValue; }

  jobjectArray java_array = (*javaEnv)->CallObjectMethod(javaEnv, javaCaller,
                  midCallBack, jdd_name);
  if(java_array == NULL){ printf("java_ret = NULL\n"); return R_NilValue; }

  jsize length = (*javaEnv)->GetArrayLength(javaEnv, java_array);
  //printf("length = %d\n", length);
  SEXP rString = PROTECT(allocVector(STRSXP, length));
  for (int i = 0; i < length; i++) {
    jobject objString = (*javaEnv)->GetObjectArrayElement(javaEnv,
		    java_array, i);
    const char *resultCStr = (*javaEnv)->GetStringUTFChars(javaEnv,
		  objString, NULL);
    SET_STRING_ELT(rString, i, mkChar(resultCStr));
#ifndef DEBUG_SEGV
    (*javaEnv)->ReleaseStringUTFChars(javaEnv, objString, resultCStr);
#endif
  }
  UNPROTECT(1);
  return rString;
}
*/

/*
SEXP dfs_open(SEXP dd_name){

  //jclass thisClass = (*javaEnv)->GetObjectClass(javaEnv, javaObj);
  jclass callerClass = (*javaEnv)->GetObjectClass(javaEnv, javaCaller);

  jstring jdd_name = (*javaEnv)->NewStringUTF(javaEnv, "mydata_02");
  if(jdd_name == NULL){ printf("jdd_name = NULL\n"); return R_NilValue; }

  //jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass, "openDD", "(Ljava/lang/String;)Ljava/lang/Object;");
  //jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass, "openDD", "(Ljava/lang/String;)Ljava/lang/String;");
  jmethodID midCallBack = (*javaEnv)->GetMethodID(javaEnv, callerClass,
		  "openDD", "(Ljava/lang/String;)[Ljava/lang/Object;");
  if(midCallBack == NULL){ printf("midCallBack = NULL\n"); return R_NilValue; }

  //jobject java_ret = (*javaEnv)->CallObjectMethod(javaEnv, javaCaller, midCallBack, jdd_name);
//  if(java_ret == NULL){ printf("java_ret = NULL\n"); }


  jstring java_ret = (*javaEnv)->CallObjectMethod(javaEnv, javaCaller,
		  midCallBack, jdd_name);
  if(java_ret == NULL){ printf("java_ret = NULL\n"); }

  const char *resultCStr = (*javaEnv)->GetStringUTFChars(javaEnv,
		  java_ret, NULL);

  //SEXP jdd = PROTECT(R_MakeExternalPtr(java_ret, R_NilValue, R_NilValue));
  //UNPROTECT(1);
  //return R_MakeExternalPtr(java_ret, R_NilValue, R_NilValue);

  printf("java_ret: %s\n", resultCStr);
  SEXP rString = PROTECT(mkString(resultCStr));

  (*javaEnv)->ReleaseStringUTFChars(javaEnv, java_ret, resultCStr);
  UNPROTECT(1);
  return rString;
 

  jobjectArray java_array = (*javaEnv)->CallObjectMethod(javaEnv, javaCaller,
                  midCallBack, jdd_name);
  if(java_array == NULL){ printf("java_ret = NULL\n"); return R_NilValue; }

  jsize length = (*javaEnv)->GetArrayLength(javaEnv, java_array);
  //printf("length = %d\n", length);
  SEXP rString = PROTECT(allocVector(STRSXP, length));
  for (int i = 0; i < length; i++) {
    jobject objString = (*javaEnv)->GetObjectArrayElement(javaEnv,
		    java_array, i);
    const char *resultCStr = (*javaEnv)->GetStringUTFChars(javaEnv,
		  objString, NULL);
    SET_STRING_ELT(rString, i, mkChar(resultCStr));
#ifndef DEBUG_SEGV
    (*javaEnv)->ReleaseStringUTFChars(javaEnv, objString, resultCStr);
#endif
  }
  UNPROTECT(1);
  return rString;
}
*/

/*
JNIEXPORT jlong JNICALL Java_RJNI_getObjectAddr
  (JNIEnv *javaEnv, jobject thisObject, jobject jObj){
  return (jlong) jObj;
}

JNIEXPORT jobject JNICALL Java_RJNI_getObjectFromAddr
  (JNIEnv *javaEnv, jobject theCaller, jlong javaLongValue)
{
  return (jobject) javaLongValue;
}
*/


/*
char *cmd2str(int cmd){
  switch(cmd){
    case TR_EXIT: return "TR_EXIT"; // cmd
    case TR_NEW_JOB: return "TR_NEW_JOB"; // cmd array
    case TR_SEND_DRIVER: return "TR_SEND_DRIVER"; // cmd array
    case TR_JOB_RESULT: return "TR_JOB_RESULT"; // cmd array
    case TR_NEXT_SUBSET: return "TR_NEXT_SUBSET"; // cmd array
    default: break;
  }

  return "Unknown Command";
}
*/

SEXP TR_getNextSubset(SEXP env){
  
	// FIXME
#define USE_SUPR_OBJECT_T
#ifdef  USE_SUPR_OBJECT_T

  if(tr_cntxt.firstSubset != R_UnboundValue) {
    SEXP ret = tr_cntxt.firstSubset;
    tr_cntxt.firstSubset = R_UnboundValue;
    //defineVar(install("firstSubset"), R_UnboundValue, env);
    //removeVar(install("firstSubset"), env);
    removeVar(install("firstSubset"), SuprJobEnv);
    return ret;
  }

  int job_id = tr_cntxt.job_id;
  int tr_id = tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;


  int args[] = {TR_NEXT_SUBSET, job_id, tr_id};
  shm_io_write(io, io->out, args, sizeof(args));
  size_t size;
  so_t * so = (so_t*)  shm_io_read(io, io->in, &size, NULL);

  {
	  char msg[256];
	  sprintf(msg, "so: %p, size: %ld", so, size);
  }

  SEXP val = SO_toRObject(so, size);
  free(so);

  return val;
#else


  SEXP rjob_id = findVar(install(TR_JOB_ID), env);
  if(rjob_id == R_UnboundValue){
    errorcall(R_NilValue, "cannot find %s", TR_JOB_ID);
  }
  int job_id = INTEGER(rjob_id)[0];

  SEXP rtr_id = findVar(install(TR_TR_ID), env);
  if(rtr_id == R_UnboundValue){
    errorcall(R_NilValue, "cannot find %s", TR_TR_ID);
  }
  int tr_id = INTEGER(rtr_id)[0];

  SEXP rtr_io = findVar(install(TR_TR_IO), env);
  if(rtr_io == R_UnboundValue){
    errorcall(R_NilValue, "cannot find %s", TR_TR_IO);
  }
  shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(rtr_io);
  


  int args[] = {TR_NEXT_SUBSET, job_id, tr_id};
  //fprintf(stderr, "[%s] sizeof(args) = %ld\n", __func__, sizeof(args));
  shm_io_write(io, io->out, args, sizeof(args));
  size_t size;
  //char *shm_name; //??
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  fprintf(stderr, "[%s] size = %ld\n", __func__, size);
  fprintf(stdout, "[%s] size = %ld\n", __func__, size);

  if(size < sizeof(supr_header_t)){
    fprintf(stderr, "[%s] size = %ld\n", __func__, size);
    warningcall(R_NilValue, "treat received data of %ld bytes as NULL",
		   size); 
    free(ptr);
    return R_NilValue;
  }

#ifdef USE_SUPR_SERIALIZE

  SEXP subset = supr2r(ptr, size, env);
  free(ptr);
  return subset;

#else

  if(size < 4) {
    free(ptr);
    return R_NilValue;
  }

#define R_OBJECT 504

 
  SEXP subset = R_NilValue;
  int type = ((int*)ptr)[0];
  //fprintf(stdout, "[%s] type = %d\n", __func__, type);
  switch(type){
    case TR_DD_SUBSET:
         subset = mkString(ptr+sizeof(int));
	 break;
    case TR_INT_VALUE:
         subset = ScalarInteger(((int*)ptr)[1]);
	 break;
    case R_OBJECT:
	 {
	   SEXP call = PROTECT(LCONS(install("unserialize"),
			 CONS((SEXP)(ptr+sizeof(int)), R_NilValue)));
	   subset = eval(call, env); 
	   UNPROTECT(1);
	 }
	 break;
    default: {
		     printf("[%s] TODODODOD (%s, %d)\n", __func__,
				     __FILE__, __LINE__);
		     fprintf(stderr, "[%s] TODODODOD (%s, %d)\n", __func__,
				     __FILE__, __LINE__);
		     break;
	     }
  }
#endif


  free(ptr);
  return subset;
#endif
#undef USE_SUPR_OBJECT_T
}

static SEXP TR_serialize(SEXP x, SEXP env){
  SEXP call = PROTECT(LCONS(install("serialize"),
			  CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP val = eval(call, env);
  UNPROTECT(1);
  return val;
}

static SEXP TR_unserialize(SEXP x, SEXP env){
  SEXP call = PROTECT(LCONS(install("unserialize"),
			  CONS(x, R_NilValue)));
  SEXP val = eval(call, env);
  UNPROTECT(1);
  return val;
}




void *SUPR_serialize(SEXP x, SEXP env, size_t *_size){
  // TODO:
  // to store LCONS(install("serialize"), ... 
  //static SEXP supr_env = R_NilValue;

  SEXP call = PROTECT(LCONS(install("serialize"),
			  CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = eval(call, env);
  size_t size = sizeof(supr_header_t) + LENGTH(raw);
  *_size =  size;
  supr_header_t *supr_header = malloc(size);
  supr_header->id = SUPR;
  supr_header->type = SUPR_SERIALIZED_ROBJ;
  supr_header->length = LENGTH(raw);
  //supr_header->padding = 0;

  memcpy(supr_header, supr_header, sizeof(supr_header_t));

  memcpy(supr_header + 1, DATAPTR(raw), LENGTH(raw));
  UNPROTECT(1);
  return supr_header;
}

static void SUPR_unserialize_backtrace(void *ptr){
  c_backtrace();
}

//#define __TESTING_R_IN__
#ifdef __TESTING_R_IN__
static int __InChar(R_inpstream_t in){
  return 0;
}
static void __InBytes(R_inpstream_t in, void *array, int size){
}
static SEXP __InPersistHookFunc(SEXP x, SEXP y){
	return R_NilValue;
}

static void __OutChar(R_outpstream_t out, int value){
}
static void __OutBytes(R_outpstream_t in, void *array, int size){
}
static SEXP __OutPersistHookFunc(SEXP x, SEXP y){
	return R_NilValue;
}

R_inpstream_t __create_R_inpstream(void *data)
{
  R_inpstream_t in = malloc(sizeof(struct R_inpstream_st));

  in->data = data;
  in->type = R_pstream_binary_format;
  in->InChar = __InChar;
  in->InBytes = __InBytes;
  in->InPersistHookFunc = __InPersistHookFunc;
  in->InPersistHookData = R_NilValue;

  return in;
}	

R_outpstream_t __create_R_outpstream(void *data)
{
  R_outpstream_t out = malloc(sizeof(struct R_outpstream_st));
  out->data = data;
  out->type = R_pstream_binary_format;
  out->version = 0 ;// ???
  out->OutChar = __OutChar;
  out->OutBytes = __OutBytes;
  out->OutPersistHookFunc = __OutPersistHookFunc;
  out->OutPersistHookData = R_NilValue;
  return out;
}

SEXP TS(SEXP x){

  unsigned char buf[128*16];
  R_outpstream_t out = __create_R_outpstream(buf);

  R_Serialize(x, out);
  return R_NilValue;
}

#endif

// call R_Unserialize???
SEXP SUPR_unserialize(void *x, SEXP env, size_t size){
  supr_header_t *supr_header = (supr_header_t *) x;
  if(supr_header->id != SUPR || supr_header->type != SUPR_SERIALIZED_ROBJ)
	  sys_error(); // no return

  int len = supr_header->length;
  SEXP raw = PROTECT(allocVector(RAWSXP, len)); 
  memcpy(DATAPTR(raw), supr_header + 1, len);

#define __TESTING_SUPR__
#ifdef __TESTING_SUPR__
#define null R_NilValue

  RCNTXT cntxt;
  begincontext(&cntxt, CTXT_CCODE, null, R_BaseEnv, R_BaseEnv, null, null);

      cntxt.cend = SUPR_unserialize_backtrace;
      cntxt.cenddata = x;

      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
      SEXP val = eval(call, env);
      UNPROTECT(2);

  endcontext(&cntxt);

#undef null

#else
  SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
  SEXP val = eval(call, env);
  UNPROTECT(2);
#endif
#undef __TESTING_SUPR__
  return val;
}


SEXP supr2r(supr_header_t *x, size_t size, SEXP env){


  supr_header_t *h = (supr_header_t *) x;
  if(h->id != SUPR) {
          fprintf(stderr, "[%s (%s, %d)] size = %ld\n", __func__, __FILE__, __LINE__,
			  size);
	  if(size > 4*sizeof(int)) {
	    int *intVal = (int *) x;
            fprintf(stderr, "[%s] header (%d, %d, %d, %d)\n", __func__,
			    intVal[0], intVal[1], intVal[2], intVal[3]);
	  }
	  sys_error();
  }

  SEXP val = R_NilValue;
  switch(h->type){
    case SUPR_SERIALIZED_ROBJ:
         {
	   // length 0 is used as NULL ?? 
	   int *z = (int*) x;
	   //fprintf(stderr, "header [%d, %d, %d, %d]\n", z[0], z[1], z[2], z[3]);
	   if(z[2]==0){
             val = R_NilValue; // or list(); See countAndGet
	   } else 
             val = SUPR_unserialize(h, env, size);
	 }
	 break;
    case SUPR_INT_ARRAY:
	 {
           int len = h->length;
	   val = allocVector(INTSXP, len);
	   memcpy(DATAPTR(val), h+1, len*sizeof(int));
	 }
	 break;
    case SUPR_STRSXP:
	 { // fixme
           int len = h->length; // == 1 for now
	   val = allocVector(STRSXP, len);
	   char *str = (char*)(h+1);
	   str += sizeof(int);
	   SET_STRING_ELT(val, 0, mkChar((char*)( str )));
	 }
	 break;
    case SUPR_VECSXP:
	 {
           int len = h->length;
	   val = PROTECT(allocVector(VECSXP, len));
	   void *p = x + 1;
	   for(int i=0; i<len; i++){
	     size_t size = *((int*)p);
	     p += sizeof(int);
             SEXP elem = supr2r( (supr_header_t*) p, size, env);
	     SET_VECTOR_ELT(val, i, elem);
	     p += size;
	   }
	   UNPROTECT(1);
	 }
	 break;
    case SUPR_ERROR:
	 {
           int len = h->length; // == 1??
	   char *msg = (char*)(h+1);
	   int n = *((int*)msg);
	   msg += sizeof(int);
	   char buf[n+1];
	   sprintf(buf, "%s", msg);
	   free(x);
	   errorcall(R_NilValue, "%s", buf);
	 }
	 break;
    case SUPR_JOB_CANCELLED:
	 {
            val = mkString("JOB_CANCELLED"); // FIXME?
	 }
	 break;
    default:
	 //not_implemented();
	 errorcall(R_NilValue, "[%s (%s, %d) type=%d not implemented", __func__,
			 __FILE__, __LINE__, h->type);
	 break;
  }

  return val;
}

static int rjni_getIntValue(const char *name, SEXP env){
  SEXP rValue = findVar(install(name), env);
  if(rValue == R_UnboundValue)
    errorcall(R_NilValue, "cannot find %s", name);
  if(TYPEOF(rValue) != INTSXP)
    errorcall(R_NilValue, "invalid type of %s", name);
  if(LENGTH(rValue) != 1)
    warning("length(%s) = %d", name, LENGTH(rValue));
  return INTEGER(rValue)[0];
}

static void *rjni_getExternalPtr(const char *name, SEXP env){
  SEXP rValue = findVar(install(name), env);
  if(rValue == R_UnboundValue)
    errorcall(R_NilValue, "cannot find %s", name);
  if(TYPEOF(rValue) != EXTPTRSXP)
    errorcall(R_NilValue, "invalid type of %s", name);
  return R_ExternalPtrAddr(rValue);
}

extern int (*get_shm_identityCode)(void);

// return: {value, rc, count} with value = true value if successful
// (rc = 0), Null if rc = 1 ("DON'T KNOW"), error message otherwise
// 
// delete me ...
// 
SEXP __TR_combine(SEXP x, SEXP combine, SEXP env)
{

	// use tr_cntxt...
  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);

  //int args[] = {TR_COMBINE, job_id, tr_id};
  int args[] = {TR_COMBINE, job_id, tr_id, 0};
  SEXP result = R_NilValue;

  int pi;
  PROTECT_WITH_INDEX(x, &pi);

  while(TRUE){
    //shm_io_write(io, io->out, args, sizeof(args));
    char shm_name[256];

    int id_no = get_shm_identityCode ?  get_shm_identityCode() : 0;

    {
#ifdef USE_SUPR_SERIALIZE
      size_t size;
      void *raw = SUPR_serialize(x, env, &size);
      sprintf(shm_name, "RTR_%d_TASK_%d_%d_%d", geteuid(), job_id, tr_id,
		      id_no);
      void *mem_ptr = rjni_shm_create(shm_name, size);
      memcpy(mem_ptr, raw, size);
#else
      SEXP raw = TR_serialize(x, env);
      sprintf(shm_name, "RTR_%d_TASK_%d_%d_%d", geteuid(), job_id, tr_id,
		      id_no);
      size_t size = ((long) RAW(raw) - (long) raw) + LENGTH(raw);
      void *mem_ptr = rjni_shm_create(shm_name, size);
      memcpy(mem_ptr, raw, size);
#endif

      munmap(mem_ptr, size);

      args[3] = id_no;
      shm_io_write(io, io->out, args, sizeof(args));
    }
    size_t size;
    //char *_shm_name; //??
    void *ptr = shm_io_read(io, io->in, &size, NULL);

    if(size < 4) {
      fprintf(stderr, "[%s] (size<4): %d\n", __func__, ((char*)ptr)[0]);
      if(((char*)ptr)[0]==1)
        result = x;
      else
        result = R_NilValue;
      free(ptr);
      break;
    } else {
      
	    {
               shm_unlink(shm_name);
	    }

      int buf_size = 256;
      char buf[buf_size];
      {
        fprintf(stderr, "[%s] combine(x=%s, )\n", __func__,
		       	r2str(x, buf, sizeof(buf)));
      }
      PrintValue(x);
      char *str = (char*) ptr;
      if(str[size-1]){
        warning("str[size-1]= %d (%s, %d)", str[size-1], __FILE__, __LINE__);
/*
 0 : ./librjni.so(c_backtrace+0x2e) [0x7f795c2b3728]
 1 : ./librjni.so(myR_SigactionSegv+0x35) [0x7f795c2b4404]
 2 : /lib/x86_64-linux-gnu/libpthread.so.0(+0x12890) [0x7f795c0a3890]
 3 : /usr/lib/libR.so(+0x172fa3) [0x7f795c637fa3]
 4 : /usr/lib/libR.so(+0x175fc3) [0x7f795c63afc3]
 5 : /usr/lib/libR.so(+0x124358) [0x7f795c5e9358]
 6 : /usr/lib/libR.so(Rf_eval+0x310) [0x7f795c5ffcc0]
 7 : /usr/lib/libR.so(Rf_eval+0x4e0) [0x7f795c5ffe90]
 8 : /usr/lib/libR.so(+0x13b48c) [0x7f795c60048c]
 9 : /usr/lib/libR.so(+0x13b9d4) [0x7f795c6009d4]
10 : /usr/lib/libR.so(+0x12f273) [0x7f795c5f4273]
11 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
12 : /usr/lib/libR.so(+0x13b48c) [0x7f795c60048c]
13 : /usr/lib/libR.so(+0x13b9d4) [0x7f795c6009d4]
14 : /usr/lib/libR.so(+0x12f273) [0x7f795c5f4273]
15 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
16 : /usr/lib/libR.so(+0x13b48c) [0x7f795c60048c]
17 : /usr/lib/libR.so(+0x13b9d4) [0x7f795c6009d4]
18 : /usr/lib/libR.so(+0x12f273) [0x7f795c5f4273]
19 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
20 : /usr/lib/libR.so(+0x13c99f) [0x7f795c60199f]
21 : /usr/lib/libR.so(Rf_applyClosure+0x173) [0x7f795c6026e3]
22 : /usr/lib/libR.so(+0x1316e2) [0x7f795c5f66e2]
23 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
24 : /usr/lib/libR.so(+0x13c99f) [0x7f795c60199f]
25 : /usr/lib/libR.so(Rf_applyClosure+0x173) [0x7f795c6026e3]
26 : /usr/lib/libR.so(+0x1316e2) [0x7f795c5f66e2]
27 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
28 : /usr/lib/libR.so(+0x13b48c) [0x7f795c60048c]
29 : /usr/lib/libR.so(+0x13b9d4) [0x7f795c6009d4]
30 : /usr/lib/libR.so(+0x12f273) [0x7f795c5f4273]
31 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
32 : /usr/lib/libR.so(+0x13b48c) [0x7f795c60048c]
33 : /usr/lib/libR.so(+0x13b9d4) [0x7f795c6009d4]
34 : /usr/lib/libR.so(+0x12f273) [0x7f795c5f4273]
35 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
36 : /usr/lib/libR.so(+0x13b48c) [0x7f795c60048c]
37 : /usr/lib/libR.so(+0x13b9d4) [0x7f795c6009d4]
38 : /usr/lib/libR.so(+0x12f273) [0x7f795c5f4273]
39 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
40 : /usr/lib/libR.so(+0x13c99f) [0x7f795c60199f]
41 : /usr/lib/libR.so(Rf_applyClosure+0x173) [0x7f795c6026e3]
42 : /usr/lib/libR.so(+0x1316e2) [0x7f795c5f66e2]
43 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
44 : /usr/lib/libR.so(+0x13c99f) [0x7f795c60199f]
45 : /usr/lib/libR.so(Rf_applyClosure+0x173) [0x7f795c6026e3]
46 : /usr/lib/libR.so(+0x1316e2) [0x7f795c5f66e2]
47 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
48 : /usr/lib/libR.so(+0x13c99f) [0x7f795c60199f]
49 : /usr/lib/libR.so(Rf_applyClosure+0x173) [0x7f795c6026e3]
50 : /usr/lib/libR.so(+0x1316e2) [0x7f795c5f66e2]
51 : /usr/lib/libR.so(Rf_eval+0x190) [0x7f795c5ffb40]
52 : /usr/lib/libR.so(+0x13c99f) [0x7f795c60199f]
53 : /usr/lib/libR.so(Rf_applyClosure+0x173) [0x7f795c6026e3]
54 : /usr/lib/libR.so(Rf_eval+0x35a) [0x7f795c5ffd0a]
55 : /usr/lib/libR.so(+0x11c567) [0x7f795c5e1567]
56 : /usr/lib/libR.so(Rf_warningcall+0x94) [0x7f795c5e1644]
57 : /usr/lib/libR.so(Rf_warning+0x1b3) [0x7f795c5e1823]
58 : ./librjni.so(TR_combine+0x58a) [0x7f795c2bcd5b]
*/
	void *_ptr = ptr;
	ptr = malloc(size+1);
	memcpy(ptr, _ptr, size);
	((char*)ptr)[size] = 0;
	free(_ptr);
	str = (char*) ptr;
      }
      fprintf(stderr, "size = %ld, strlen((char*)ptr) = %ld\n",
		      size, strlen(str));
      fprintf(stderr, "[%s] str = %s\n", __func__, str);

      void *mem_ptr = rjni_shm_open((char*)ptr, &size); // fixme?
      
      fprintf(stderr, "[%s] mem_ptr = %p\n", __func__, mem_ptr);
      if(!mem_ptr)
	      errorcall(R_NilValue, "[%s] %s", str, strerror(errno));

#ifdef USE_SUPR_SERIALIZE
      SEXP y = PROTECT(SUPR_unserialize(mem_ptr, env, size));
      PROTECT(y); // FIXME
#else
      SEXP call = PROTECT(LCONS(install("unserialize"),
			      CONS((SEXP)mem_ptr, R_NilValue)));
      SEXP y = PROTECT(eval(call, env));
#endif

      {
        fprintf(stderr, "[%s] combine(, y=%s)\n", __func__, 
		       	r2str(x, buf, sizeof(buf)));
      }

      PrintValue(y);

      if(TYPEOF(x) == NILSXP) { // fix me
        x = y;
        REPROTECT(x, pi);
        UNPROTECT(2);
      } else if(TYPEOF(y) == NILSXP) { // fix me
        UNPROTECT(2);
      } else {
        SEXP call = PROTECT(LCONS(combine, CONS(x, CONS(y, R_NilValue))));
        x = eval(call, env);
        REPROTECT(x, pi);
        UNPROTECT(3);
      }

      munmap(mem_ptr, size);
//#define TESTING_NO_UNLINK
#ifndef TESTING_NO_UNLINK
      shm_unlink((char*)ptr);
#endif

      free(ptr);
//      fprintf(stderr, "[%s] combined value (x+%d): %d\n", __func__,
//		      INTEGER(y)[0], INTEGER(x)[0]);
      printf("[%s] combined value:\n", __func__);
      {
        fprintf(stderr, "[%s] combined value: x=%s\n", __func__,
		       	r2str(x, buf, sizeof(buf)));
      }
      PrintValue(x);
    }
  }
  UNPROTECT(1);
  return result;
}

//#define TASKRUNNER_MESSAGE 308

void sendDriverMessage(shm_io_info_t *io, int job_id, int tr_id,
	       	const char *msg){
  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));
  char array[4*sizeof(int)+strlen(msg)+1];
  int *header = (int*) array;
  header[0] = TASKRUNNER_MESSAGE;
  header[1] = job_id;
  header[2] = tr_id;
  header[3] = strlen(msg)+1; //0; // padding?
  memcpy(array+4*sizeof(int), msg, strlen(msg)+1);
  shm_io_write(io, io->out, array, 4*sizeof(int)+strlen(msg)+1);
  size_t size;
  //char *_shm_name = NULL;
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  //fprintf(stderr, "[%s] received %ld bytes from the driver\n", __func__, size);
  free(ptr);
}

static int rjni_strcmp(const void *a, const void *b)
{
  
	/*
  char **x = (char **) a;
  char **y = (char **) b;
#define DEBUG TRUE
if(DEBUG) {
printf("<%p>:<%p>|\n", a, b);
printf("y=%s\n", *y);
printf("x=%s\n", *x);
printf("%s:%s|\n", *x, *y);
}
//  return strcmp(*x, *y);
*/

  return strcmp(*((char **) a), *((char **) b));
}

typedef struct name_int_struct {
  char *name; 
  int value;
//  void *value;
} name_int_t;


name_int_t sig_name_value[] = {
/*
#define SIGHUP           SIGHUP           1
#define SIGINT           2
#define SIGQUIT          3
#define SIGILL           4
#define SIGTRAP          5
#define SIGABRT          6
#define SIGIOT           6
#define SIGBUS           7
#define SIGFPE           8
#define SIGKILL          9
#define SIGUSR1         10
#define SIGSEGV         11
#define SIGUSR2         12
#define SIGPIPE         13
#define SIGALRM         14
#define SIGTERM         15
#define SIGSTKFLT       16
#define SIGCHLD         17
#define SIGCONT         18
#define SIGSTOP         19
#define SIGTSTP         20
#define SIGTTIN         21
#define SIGTTOU         22
#define SIGURG          23
#define SIGXCPU         24
#define SIGXFSZ         25
#define SIGVTALRM       26
#define SIGPROF         27
#define SIGWINCH        28
#define SIGIO           29
#define SIGPOLL         SIGIO
// #define SIGLOST         29
#define SIGPWR          30
#define SIGSYS          31
#define SIGUNUSED       31
*/
  {"SIGINT", SIGINT},
  {"SIGUSR1", SIGUSR1}, 
  {"SIGUSR2", SIGUSR2}, 
};

static int signalValueOf(const char *name){
  for(int i=0; i<sizeof(sig_name_value)/sizeof(name_int_t); i++){
    if(strcmp(sig_name_value[i].name, name)==0)
	    return sig_name_value[i].value;
  }
  return -1;
}

SEXP R_kill(SEXP signal_name, SEXP env)
{
  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);

  int sig = signalValueOf(CHAR(STRING_ELT(signal_name,0)));
  if(sig == -1)
    errorcall(R_NilValue, "unknown signal '%s'", STRING_ELT(signal_name,0));

  return mkString("TODO");
}


// create a named countdown object at the driver 
// countdouwn(name, max_count, init_value, value_combine_function, action_function)


SEXP TR_getContext(SEXP env)
{

  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);

  SEXP val = PROTECT(allocVector(VECSXP, 3));
  SEXP names = PROTECT(allocVector(STRSXP, 3));
  SET_VECTOR_ELT(val, 0, ScalarInteger(job_id));
  SET_STRING_ELT(names, 0, mkChar("job_id"));
  SET_VECTOR_ELT(val, 1, ScalarInteger(tr_id));
  SET_STRING_ELT(names, 1, mkChar("tr_id"));
  SET_VECTOR_ELT(val, 2, mkString(io->shm_info.shm_name));
  SET_STRING_ELT(names, 2, mkChar("shm_name"));
  setAttrib(val, R_NamesSymbol, names);

  printf("[%s] Taskrunner Context:\n", __func__);
  PrintValue(val);
  fflush(stdout);
	  

  UNPROTECT(2);
  return val;
 
  //return env;
}

SEXP TR_sendDriver(SEXP x, SEXP env)
{
  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);

  char *msg = (char*)CHAR(STRING_ELT(x,0));
  /*
  char buf[128+strlen(msg)];
  sprintf(buf, "[INFO:%d_%d] %s", job_id, tr_id, msg);

  sendDriverMessage(io, job_id, tr_id, buf);
  */
  sendDriverMessage(io, job_id, tr_id, msg);

  int can_read, can_write;
  rjni_shm_io_state(io, &can_read, &can_write);
  //fprintf(stderr, "\033[0;33m[%s] can_read=%d, can_write=%d\033[0m\n", __func__, can_read, can_write);
  SEXP val = PROTECT(allocVector(LGLSXP, 2));
  LOGICAL(val)[0] = can_read;
  LOGICAL(val)[1] = can_write;
  SEXP names = PROTECT(allocVector(STRSXP, 2));
  SET_STRING_ELT(names, 0, mkChar("can_read"));
  SET_STRING_ELT(names, 1, mkChar("can_write"));
  setAttrib(val, R_NamesSymbol, names);
  UNPROTECT(2);

  return val;
}

// change to use SUPR_serialize ...
// delete me
static SEXP __TR_combine_bykey(SEXP x, SEXP combine, SEXP env)
{

  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);


  int pi;
  PROTECT_WITH_INDEX(x, &pi);

  if(TYPEOF(x) == VECSXP){
    SEXP s = x;
    x =  PROTECT(allocSExp(ENVSXP));
    REPROTECT(x, pi);  
    UNPROTECT(1);
    SET_ENCLOS(x, R_EmptyEnv);
    SEXP keys = getAttrib(s, R_NamesSymbol);
    int len = LENGTH(keys);
    for(int i=0; i<len; i++){
      const char *key = CHAR(STRING_ELT(keys, i));
      if(key) defineVar(install(key), VECTOR_ELT(s, i), x);
    }
  } else if(TYPEOF(x) != ENVSXP){
    errorcall(R_NilValue, "invalid argument of type %s",
		    type2char(TYPEOF(x)));
  }

  SEXP keys = PROTECT(R_lsInternal(x, TRUE));
  int nkeys = LENGTH(keys);

  // a simple implementation
  char **key_ptrs = malloc(nkeys*sizeof(char*));
  for(int i=0; i<nkeys; i++){
    const char *key = CHAR(STRING_ELT(keys, i));
    key_ptrs[i] = (char*) key;
  }
  qsort(key_ptrs, nkeys, sizeof(char *), rjni_strcmp);

  SEXP rawVector = PROTECT(allocVector(VECSXP, nkeys));
  size_t size = sizeof(int) + nkeys*(2*sizeof(size_t));
  size_t key_size = 0;
  size_t val_size = 0;
#ifdef USE_SUPR_SERIALIZE
  void  **raw_vector = malloc(nkeys*sizeof(void*));
  size_t *len_vector = malloc(nkeys*sizeof(size_t));
#endif
  for(int i=0; i<nkeys; i++){
    const char *key = key_ptrs[i];
    printf("[%s] key[%d] %s\n", __func__, i, key);
    key_size  += strlen(key) + 1;
    SEXP val = findVar(install(key), x);

#ifdef USE_SUPR_SERIALIZE
    // FIXME
    //SEXP call = PROTECT(LCONS(install("serialize"),
//		    CONS(val, CONS(R_NilValue, R_NilValue))));

    //SEXP raw = PROTECT(eval(call, env));
    //SET_VECTOR_ELT(rawVector, i, raw);
    //UNPROTECT(2);
    //val_size += sizeof(size_t) + LENGTH(raw);
    size_t len;
    raw_vector[i] = SUPR_serialize(val, env, &len);
    len_vector[i] = len;
    val_size += sizeof(size_t) + len;
#else
    SEXP call = PROTECT(LCONS(install("serialize"),
		    CONS(val, CONS(R_NilValue, R_NilValue))));

    SEXP raw = PROTECT(eval(call, env));
    SET_VECTOR_ELT(rawVector, i, raw);
    UNPROTECT(2);
    val_size += sizeof(size_t) + (long)RAW(raw) - (long) raw + LENGTH(raw);
#endif
  }
  size += key_size + val_size;

  // sizeof(size_t) = sizeof(void *)

  // qsort keys 
  /* shm_mem struct:
   * [len][keyAddr/Off][valAddr/Off]    
   * [[key ...0]]
   * [[size val ...]]
   */
  char shm_name[256]; // CBK - Combine By Key
  sprintf(shm_name, "RTR_%d_TASK_%d_%d_CBK", geteuid(), job_id, tr_id);
  void *mem_ptr = rjni_shm_create(shm_name, size);
  size_t key_offset = sizeof(int) + nkeys*(2*sizeof(size_t));
  size_t val_offset = key_offset + key_size;
  void *ptr = mem_ptr;
  *((int*) ptr) = nkeys;
  ptr += sizeof(int);
  size_t *idx = (size_t*)(mem_ptr + sizeof(int));
  for(int i=0; i<nkeys; i++){
    *idx = key_offset;
    *(idx + nkeys) = val_offset;
    idx++;
    const char *key = key_ptrs[i];
    memcpy(mem_ptr + key_offset, key, strlen(key)+1);
    key_offset += strlen(key)+1;

#ifdef USE_SUPR_SERIALIZE
    // FIXME
    /*
    SEXP raw = VECTOR_ELT(rawVector, i);
    size_t len = LENGTH(raw);
    memcpy(mem_ptr + val_offset, &len, sizeof(size_t));
    val_offset += sizeof(size_t);
    memcpy(mem_ptr + val_offset, DATAPTR(raw), len);
    val_offset += len;
    */
    size_t len = len_vector[i];
    memcpy(mem_ptr + val_offset, &len, sizeof(size_t));
    val_offset += sizeof(size_t);
    memcpy(mem_ptr + val_offset, raw_vector[i], len);
    val_offset += len;
#else
    SEXP raw = VECTOR_ELT(rawVector, i);
    size_t len = (long)RAW(raw) - (long) raw + LENGTH(raw);
    memcpy(mem_ptr + val_offset, &len, sizeof(size_t));
    val_offset += sizeof(size_t);
    memcpy(mem_ptr + val_offset, raw, len);
    val_offset += len;
#endif
  }
  free(key_ptrs);
  // checking
  /*
  {
    int n = *((int*)mem_ptr);
    printf("[%s] nkeys = %d\n", __func__, n);
    size_t *_key_offset = (size_t*)(mem_ptr + sizeof(int));
    size_t *_val_offset = mem_ptr + sizeof(int) + n*sizeof(size_t);
    for(int i=0; i<n; i++){
      char *key = (char*)(mem_ptr + _key_offset[i]);
      printf("[%s] key[%d] = %s\n", __func__, i,  key);
      void *val = (void*)(mem_ptr + _val_offset[i] + sizeof(size_t));
      SEXP rval = PROTECT(LCONS(install("unserialize"),
		    CONS((SEXP) val, R_NilValue)));
      rval = PROTECT(eval(rval, env));
      PrintValue(rval);
      UNPROTECT(2);
    }
  }
  */

  {
    int args[] = {TR_COMBINE_BYKEY, job_id, tr_id};
    char *buf = malloc(sizeof(args)+ strlen(shm_name)+1 + key_size);
    memcpy(buf, args, sizeof(args));
    memcpy(buf + sizeof(args), shm_name, strlen(shm_name)+1);
    size_t offset = sizeof(args)+ strlen(shm_name)+1;

    int n = *((int*)mem_ptr);
    memcpy(buf + offset, mem_ptr + sizeof(int)+2*n*sizeof(size_t), key_size);
    size_t *_key_offset = (size_t*)(mem_ptr + sizeof(int));

    char keySeparator = ';';
    char *str = buf + sizeof(args)+ strlen(shm_name);
    for(int i=0; i<key_size; i++) {
      if(str[i] == 0) str[i] = keySeparator;
    }

    printf("[%s] buf+ = %s\n", __func__, buf+sizeof(args));
    sendDriverMessage(io, job_id, tr_id, buf+sizeof(args));
    
    shm_io_write(io, io->out, buf, sizeof(args)+strlen(shm_name)+1 + key_size);
  }
  munmap(mem_ptr, size);
 
  int cbk_rc = -1; // return code
  //SEXP ret_val = R_UnboundValue;
  int key_idx = 0;
 
  while(TRUE)
  {
    size_t size;
    //char *_shm_name; //??
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    printf("[%s] size = %ld, val = %d\n", __func__, size, ((char *)ptr)[0]);
    if(size<4){
      free(ptr);
      break;
    }

    char *str = (char*) ptr;
#define SEPARATOR ';'
    printf(" * [%s]  Received = %s\n", __func__, str);
    char *key = str;
    while(*str){
      //printf(" ~ ~ [%s]  %s\n", __func__, key);
      if(*str == SEPARATOR){ *str = 0; str++; break; }
      str++;
    }
    printf(" ~ [%s]  key = %s\n", __func__, key);
    char dupkey[strlen(key)+1];
    sprintf(dupkey, "%s", key);
    key = dupkey;

    int i=0;

    SEXP reduced = R_UnboundValue;
    int pi;
    PROTECT_WITH_INDEX(reduced, &pi);

    while(TRUE){
      char *shm_name = str;
      if(*str == 0) break;
      while(*str){
        //printf(" ~ ~ [%s]  %s\n", __func__, shm_name);
        if(*str == SEPARATOR){ *str = 0; str++; break; }
        str++;
      }
      i++;
      printf(" ~ [%d]  shm_name = %s\n\n", i, shm_name);

      {
	size_t size;
        void *mem_ptr = rjni_shm_open(shm_name, &size); // fixme?

        //{
        int n = *((int*)mem_ptr);
        printf("[%s] nkeys = %d\n", __func__, n);
        size_t *_key_offset = (size_t*)(mem_ptr + sizeof(int));
	int idx = 0;
	for(; idx < n; idx++){ // use bsearch ??? later ...
          char *__key = (char*)(mem_ptr + _key_offset[idx]);
          //printf("[%s] __key[%d] = %s\n", __func__, i,  __key);
          if(strcmp(key, (char*)(mem_ptr + _key_offset[idx]))==0)
	    break;
	}
	if(idx == n) 
          errorcall(R_NilValue, "ERROR (%s, %d)", __FILE__, __LINE__);

        size_t *_val_offset = mem_ptr + sizeof(int) + n*sizeof(size_t);

        //for(int i=0; i<n; i++){
          //char *key = (char*)(mem_ptr + _key_offset[i]);
          //printf("[%s] key[%d] = %s\n", __func__, i,  key);
          //void *val = (void*)(mem_ptr + _val_offset[i] + sizeof(size_t));
// SEXP SUPR_unserialize(void *x, SEXP env, size_t size)
// void *SUPR_serialize(SEXP x, SEXP env, size_t *size);
#ifdef USE_SUPR_SERIALIZE
	// FIXME
	/*
	size_t len = *((size_t *) (mem_ptr + _val_offset[idx]));
	SEXP raw = PROTECT(allocVector(RAWSXP, (int) len));
        void *val = (void*)(mem_ptr + _val_offset[idx] + sizeof(size_t));
	memcpy(DATAPTR(raw), val, len);
        SEXP rval = PROTECT(LCONS(install("unserialize"),
		    CONS(raw, R_NilValue)));
		    */
	size_t len = *((size_t *) (mem_ptr + _val_offset[idx]));
        void *val = (void*)(mem_ptr + _val_offset[idx] + sizeof(size_t));
	SEXP rval = PROTECT(SUPR_unserialize(val, env, len));
#else
        void *val = (void*)(mem_ptr + _val_offset[idx] + sizeof(size_t));
        SEXP rval = PROTECT(LCONS(install("unserialize"),
		    CONS((SEXP) val, R_NilValue)));
#endif
        rval = PROTECT(eval(rval, env));
	printf("Value: \n");
        PrintValue(rval);

	if(reduced == R_UnboundValue){
	  reduced = rval;
	} else {
          SEXP call = PROTECT(LCONS(combine,
		  CONS(reduced, CONS(rval, R_NilValue))));
	  reduced = eval(call, env);
	  UNPROTECT(1);
	}
	REPROTECT(reduced, pi);
#ifdef USE_SUPR_SERIALIZE
        //UNPROTECT(3);
        UNPROTECT(2);
#else
        UNPROTECT(2);
#endif

	printf("key = %s, Reduced Value: \n", key);
        PrintValue(reduced);

        //}
        //}
	munmap(mem_ptr, size);
	  
      }
    }
    if(str != ptr + size - 1){
      char *str = (char*) ptr;
      fprintf(stderr, "CHECK: %s\n", str);
      while(*str && *str != ';'){
	      str++;
      }
      str++;
      fprintf(stderr, "CHECK: %d (%c)\n", *(str-1), *(str-1));
      fprintf(stderr, "CHECK: %s\n", str);
      errorcall(R_NilValue, "ERROR (%s, %d)", __FILE__, __LINE__);
    }

    while(TRUE) { // cluster-level combine by key 
#ifdef USE_SUPR_SERIALIZE

      SEXP call = R_NilValue; // PROTECT(LCONS(install("serialize"), CONS(reduced, CONS(R_NilValue, R_NilValue))));
      SEXP raw = R_NilValue; // PROTECT(eval(call, env));
     
      size_t size;
      void *_raw = SUPR_serialize(reduced, env, &size);

      char shm_name[256]; // CBK - Combine By Key
      sprintf(shm_name, "RTR_%d_TASK_%d_%d_CBK_%d", geteuid(),
		      job_id, tr_id, key_idx++);
     
      void *mem_ptr = rjni_shm_create(shm_name, size);
      memcpy(mem_ptr, _raw, size);
      //UNPROTECT(2);
      munmap(mem_ptr, size);

#else
      SEXP call = PROTECT(LCONS(install("serialize"),
		    CONS(reduced, CONS(R_NilValue, R_NilValue))));
      SEXP raw = PROTECT(eval(call, env));

      char shm_name[256]; // CBK - Combine By Key
      sprintf(shm_name, "RTR_%d_TASK_%d_%d_CBK_%d", geteuid(),
		      job_id, tr_id, key_idx++);
     
      size_t size = (long)RAW(raw) - (long)raw + LENGTH(raw);
      void *mem_ptr = rjni_shm_create(shm_name, size);
      memcpy(mem_ptr, raw, size);
      UNPROTECT(2);
      munmap(mem_ptr, size);
#endif

      // CL: cluster-level?
      char key_value[strlen(key)+1+strlen(shm_name)+1];
#define STRING_SEPARATOR '\n'
      sprintf(key_value, "%s%c%s", key, STRING_SEPARATOR, shm_name);
#undef STRING_SEPARATOR
      int args[] = {TR_COMBINE_BYKEY, job_id, tr_id};
      char buf[sizeof(args)+strlen(key_value)+1];
      memcpy(buf, args, sizeof(args));
      memcpy(buf + sizeof(args), key_value, strlen(key_value)+1);

      int cmd = TR_SEND_DRIVER;
      shm_io_write(io, io->out, &cmd, sizeof(int));

      shm_io_write(io, io->out, buf, sizeof(buf));

      //char *_shm_name; //??
      void *ptr = shm_io_read(io, io->in, &size, NULL);
      printf("[%s] size = %ld, val = %d\n", __func__, size, ((char *)ptr)[0]);
      if(size<4){
        cbk_rc = ((unsigned char *)ptr)[0];
        free(ptr);
        break;
      }

      char *addr = (char*) ptr;
      printf("\033[0;32m[%s] addr: %s\033[0m\n", __func__, addr);
      ((int*)ptr)[0] = TR_GET_VALUE;
      shm_io_write(io, io->out, ptr, size);
      free(ptr);

#ifdef USE_SUPR_SERIALIZE
      //ptr = shm_io_read(io, io->in, &size, NULL);
      //printf("[%s] size = %ld\n", __func__, size);
      SEXP rval = PROTECT(shm_io_readRObject(io, io->in, env));
#else
      ptr = shm_io_read(io, io->in, &size, NULL);
      printf("[%s] size = %ld\n", __func__, size);
#endif

#ifdef USE_SUPR_SERIALIZE
      //SEXP rval = PROTECT(SUPR_unserialize(ptr, env, size));
      //free(ptr);
#else
      raw = (SEXP) ptr;
      call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
      SEXP rval = PROTECT(eval(call, env));
      free(ptr);
#endif
      call = PROTECT(LCONS(combine, CONS(reduced, CONS(rval, R_NilValue))));
      reduced = eval(call, env);
      REPROTECT(reduced, pi);
#ifdef USE_SUPR_SERIALIZE
      UNPROTECT(2);
#else
      UNPROTECT(3);
#endif
      printf("\033[0;33mCluster-level combined value: \n\033[0m");
      PrintValue(reduced);
    }

    /*
    if(ret_val == R_UnboundValue){
      ret_val = PROTECT(CONS(reduced, R_NilValue)); 
      SET_TAG(ret_val, install(key));
    } else {
      SEXP a = PROTECT(CONS(reduced, R_NilValue));
      SET_TAG(a, install(key));
      SETCDR(ret_val, a);
      UNPROTECT(1);
    }
    */

    UNPROTECT(1); // reduced
    free(ptr);
#undef SEPARATOR

    // TODO
    //break;
    int args[] = {TR_COMBINE_BYKEY, job_id, tr_id};
    shm_io_write(io, io->out, args, sizeof(args));
  }

  //if(ret_val != R_UnboundValue){ UNPROTECT(1); }
  UNPROTECT(3);
  // TODO

  //return ret_val; // R_NilValue;
  return ScalarLogical(cbk_rc == 0); // combine_bykey is completed
                                     // Driver/rjobs[job-id]/rExp/result
}

char *my_strtok(char *str, const char *delim)
{
  static char *p = NULL;
  if(str) p = str; else if(!p) return NULL;
  char *r = p;
  int m = strlen(delim);
  while(*p){
    int found = TRUE;
    for(int i=0; i<m;i++){
      if(p[i] != delim[i]) { found = FALSE; break; }
    }
    if(found){ *p = 0; p += m; break; }
    p++;
  }
  if(*p==0) p = NULL;
  return r;
}

// SUPR_serialize ??
/*
SEXP Driver_cluster_get(const char *name, SEXP rEnv)
{
  jmethodID jmid = (*javaEnv)->GetMethodID(javaEnv, callerClass,
                  "get", "(Ljava/lang/String;)Ljava/lang/Object;");
  if(jmid == NULL){ printf("\033[0;31mjmid (get) = NULL\033[0m\n");
          return R_NilValue; }

  jstring jname = (*javaEnv)->NewStringUTF(javaEnv, name);
  if(jname == NULL){ printf("jname = NULL\n"); return R_NilValue; }

  jobject jValue = (*javaEnv)->CallObjectMethod(javaEnv, javaCaller,
		  jmid, jname);
  if(jValue == NULL){ printf("jValue = NULL\n"); return R_NilValue; }

  jclass jValueClass = (*javaEnv)->GetObjectClass(javaEnv, jValue);
  if(jValueClass == NULL){ printf("jValueClass = NULL\n"); return R_NilValue; }

  // Class.getName():
  jclass jClassClass = (*javaEnv)->FindClass(javaEnv, "java/lang/Class");
  if(jClassClass == NULL){ printf("jClassClass = NULL\n"); return R_NilValue; }

  jmid = (*javaEnv)->GetMethodID(javaEnv,
		  jClassClass, "getName", "()Ljava/lang/String;");
  if(jmid == NULL){ printf("\033[0;31mjmid (getName) = NULL\033[0m\n");
          return R_NilValue; }

  jstring jValueClassName = (jstring) (*javaEnv)->CallObjectMethod(javaEnv,
		  jValueClass, jmid);
  if(jValueClassName == NULL){
	  printf("\033[0;31mjValueClassName = NULL\033[0m\n");
          return R_NilValue; }

  const char *cValueClassName = (*javaEnv)->GetStringUTFChars(javaEnv,
		  jValueClassName, NULL);
  printf("[%s] jValue.getClass().getName(): %s\n", __func__, cValueClassName);

  //SEXP rValueClassName = mkString(cValueClassName);

  SEXP rReturnValue = R_NilValue;
  if(strcmp(cValueClassName, "java.lang.String")==0){
    const char *cValue = (*javaEnv)->GetStringUTFChars(javaEnv, jValue, NULL);
    rReturnValue = PROTECT(mkString(cValue));
    (*javaEnv)->ReleaseStringUTFChars(javaEnv, jValue, cValue);
  } else if(strcmp(cValueClassName, "[B")==0){ //jintArray 
    jsize length = (*javaEnv)->GetArrayLength(javaEnv, (jbyteArray)jValue);
    jboolean isCopy;
    unsigned char *array = (*javaEnv)->GetByteArrayElements(javaEnv, jValue,
		    &isCopy);
    {
      //rReturnValue = PROTECT(allocVector(RAWSXP, length));
      //memcpy(RAW(rReturnValue), array, length);
      SEXP call = PROTECT(LCONS(install("unserialize"),
			      CONS((SEXP) array, R_NilValue)));
      rReturnValue = eval(call, rEnv);
      UNPROTECT(1);
      PROTECT(rReturnValue);
    }

    if(isCopy)
      (*javaEnv)->ReleaseByteArrayElements(javaEnv, jValue, array, JNI_ABORT);
  } else if(strcmp(cValueClassName, "[I")==0){ //jintArray 
    jsize length = (*javaEnv)->GetArrayLength(javaEnv, (jintArray)jValue);
    jboolean isCopy;
    int *array = (*javaEnv)->GetIntArrayElements(javaEnv, jValue, &isCopy);
    rReturnValue = PROTECT(allocVector(INTSXP, length));
    memcpy(INTEGER(rReturnValue), array, sizeof(int)*length);
    if(isCopy)
      (*javaEnv)->ReleaseIntArrayElements(javaEnv, jValue, array, JNI_ABORT);
  } else if(strcmp(cValueClassName, "[D")==0){ //jintArray 
    jsize length = (*javaEnv)->GetArrayLength(javaEnv, (jdoubleArray)jValue);
    jboolean isCopy;
    double *array = (*javaEnv)->GetDoubleArrayElements(javaEnv, jValue,
		    &isCopy);
    rReturnValue = PROTECT(allocVector(REALSXP, length));
    memcpy(REAL(rReturnValue), array, sizeof(double)*length);
    if(isCopy)
      (*javaEnv)->ReleaseDoubleArrayElements(javaEnv, jValue, array, JNI_ABORT);
  } else{
    char cValue[strlen(cValueClassName)+strlen("A java object of class ")+1];
    sprintf(cValue, "JAVA: (%s) object", cValueClassName);
    rReturnValue = PROTECT(mkString(cValue));
  }

  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jValueClassName, cValueClassName);

  UNPROTECT(1);
  return rReturnValue;
}
*/

SEXP Driver_cluster_get(const char* name, SEXP env)
{
	errorcall(R_NilValue, "JNK");
	return R_NilValue;
}

// Change the name to Cluster_get ??
SEXP TR_cluster_get(SEXP x, SEXP env)
{
  const char *name = NULL;

  if(TYPEOF(x)==STRSXP) {// get a vector of values???
    if(LENGTH(x) == 0) errorcall(R_NilValue, "invalid argument x");
    else if(LENGTH(x) > 1) warning("length(x) > 1");

    name = CHAR(STRING_ELT(x, 0));
  } else if(TYPEOF(x)==SYMSXP)
    name = CHAR(PRINTNAME(x));
  else 
    errorcall(R_NilValue, "invalid argument x");

  /*
  if(strstr(name, "//"))
  {
	  if(FALSE){
    char uri[strlen(name)+1];
    memcpy(uri, name, strlen(name)+1);
    char *scheme = uri;
    char *addr = strstr(uri, "//");
    if(addr == uri) {
      scheme = NULL;
    } else {
      *(addr-1) = '\000';
    }

    //addr   = my_strtok(addr, "#");
    addr   = strtok(addr, "#");
    printf("name=%s: \n\tscheme=%s\n\taddr=%s\n", name, scheme, addr);

    while(TRUE){
      //char *fregment   = my_strtok(NULL, "#");
      char *fregment   = strtok(NULL, "#");
      if(!fregment) break;
      printf("\tfregment: %s\n", fregment);
    }
	  }
    SEXP rValue = findVar(install(TR_TR_IO), env);
    if(rValue != R_UnboundValue && TYPEOF(rValue) == EXTPTRSXP)
    { // for TaskRunners
      shm_io_info_t *io = (shm_io_info_t *) R_ExternalPtrAddr(rValue);
    } else { // for R Driver(s)
    }

    return R_NilValue;
  }
  */

  if(findVar(install(TR_TR_ID), env) == R_UnboundValue) { // Driver
    return Driver_cluster_get(name, env);
  }

  SEXP rIO = findVar(install(TR_TR_IO), env);

  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);

//sendDriverMessage(io, job_id, tr_id, __func__);

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));

  unsigned char args[sizeof(int)+strlen(name)+1];
  cmd = TR_CLUSTER_GET;
  memcpy(args, &cmd, sizeof(int));
  memcpy(args + sizeof(int), name, strlen(name)+1);

  shm_io_write(io, io->out, args, sizeof(args));

  size_t size;
  //char *_shm_name; //??
  void *ptr = shm_io_read(io, io->in, &size, NULL);
//sendDriverMessage(io, job_id, tr_id, "OKAY 2");
  printf("[%s] size = %ld, val[0] = %d\n", __func__, size, ((char *)ptr)[0]);
  if(size<4){
    int ret = ((char *)ptr)[0];
    free(ptr);
    //errorcall(R_NilValue, "cannot find \"%s\"", name);
    return ScalarInteger(ret);
  }

  { // testing
    //*(ptr + size -1) = 0;
    char *type = (char*) ptr;
    *(type + size -1) = 0;
    printf("[%s] type = \"%s\"\n", __func__, type);
    char *kv = type + strlen(type)+1 + 1;
    printf("[%s] type = \"%s\"\n", __func__, kv);

    /*
    char *st = my_strtok(kv, "{");
    printf("[%s] st = \"%s\"\n", __func__, st);
    printf("[%s] st = \"%s\"\n", __func__, st+strlen(st)+1);
    */
    int i=0;
    char *key = my_strtok(kv, "=");
    // use an env object???
    //SEXP rval = PROTECT(CONS(R_NilValue, R_NilValue));
    SEXP rval = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(rval, R_EmptyEnv);
    while(TRUE){
	    i++; if(i>300) break;
      if(!key) break;
      char *val = my_strtok(NULL, ", ");
      if(!val) break;
      printf("[%s] <KEY = %s, VALUE = %s>\n", __func__, key, val);

      /*
      SETCDR(s, CONS(mkString(val), R_NilValue));
      s = CDR(s);
      SET_TAG(s, install(key));
      */
      defineVar(install(key), mkString(val), rval);
      key = my_strtok(NULL, "=");
      if(!key) break;
    }
    UNPROTECT(1);
    return rval;
  }

  return ScalarInteger(2019);
}


// change to use SUPR_serialize
static SEXP __TR_put_par(SEXP name, SEXP value, SEXP rjob_id, SEXP env)
{
//	fprintf(stderr, "[%s] OKAY 1\n", __func__);
  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);

  if(TYPEOF(rjob_id) == INTSXP && LENGTH(rjob_id)>0){
    job_id = INTEGER(rjob_id)[0];
  }

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));

  const char * c_name = CHAR(STRING_ELT(name, 0));

  void *raw =  NULL;
  void *c_raw = NULL;
  int len =0;
  if(strcmp(c_name, "tr.counts")==0){ //testing
    //int *intVal = INTEGER(value);
    len = LENGTH(value);
    int header[] = {SUPR, SUPR_INT_ARRAY, len};
    c_raw = raw = malloc(sizeof(int)*len+sizeof(header));
    memcpy(raw, header, sizeof(header));
    memcpy(raw+sizeof(header), DATAPTR(value), sizeof(int)*len);
    len = sizeof(int)*len+sizeof(header);  
    fprintf(stderr, "[%s] (tr.counts) len = %d\n", __func__, len);
  } else {
#ifdef USE_SUPR_SERIALIZE
//    void *SUPR_serialize(SEXP x, SEXP env, size_t *size);
// SEXP SUPR_unserialize(void *x, SEXP env, size_t size);
    size_t size;
    raw = SUPR_serialize(value, env, &size);
    len = (int) size;
#else
    raw =  TR_serialize(value, env);
    //len = (long) RAW(raw) - (long) raw + LENGTH(raw); //sizeof(SEXPREC) +...;
    len =  SEXP_OFFSET + LENGTH(raw); //sizeof(SEXPREC) +...;
#endif
  }

  unsigned char bytes[3*sizeof(int)+strlen(c_name)+1+len];
  int args[] = {TR_PUT_PAR, job_id, tr_id};
  memcpy(bytes, args, sizeof(args));
  memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);
  memcpy(bytes+sizeof(args) + strlen(c_name)+1, raw, len);
  shm_io_write(io, io->out, bytes, sizeof(bytes));

  if(c_raw) free(c_raw);

  printf("[%s] len=%d\n", __func__, len);
  fflush(stdout);
  fprintf(stderr, "[%s] len=%d\n", __func__,len);
  size_t size;
  //char *_shm_name; // not used
  void *ptr = shm_io_read(io, io->in, &size, NULL);

  if(size<4){
    errorcall(R_NilValue, "%s(%s,...)", __func__, c_name);
    free(ptr);
  } else { // TODO
    free(ptr);
  }

  return R_NilValue; // TODO
}


// change to use SUPR_serialize
static SEXP __TR_get_par(SEXP name, SEXP rjob_id, SEXP env)
{
//	fprintf(stderr, "[%s] OKAY 1\n", __func__);
  int job_id = rjni_getIntValue(TR_JOB_ID, env);
  int tr_id = rjni_getIntValue(TR_TR_ID, env);
  shm_io_info_t *io = (shm_io_info_t *) rjni_getExternalPtr(TR_TR_IO, env);

  if(TYPEOF(rjob_id) == INTSXP && LENGTH(rjob_id)>0){
    job_id = INTEGER(rjob_id)[0];
  }

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));

  int args[] = {TR_GET_PAR, job_id, tr_id};
  const char * c_name = CHAR(STRING_ELT(name, 0));
  unsigned char bytes[sizeof(args)+strlen(c_name)+1];
  memcpy(bytes, args, sizeof(args));
  memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);
  shm_io_write(io, io->out, bytes, sizeof(bytes));

  size_t size;
  //char *_shm_name; // not used
  void *ptr = shm_io_read(io, io->in, &size, NULL);

  printf("[%s] size=%ld\n", __func__, size);
  fflush(stdout);
  fprintf(stderr, "[%s] size=%ld, c_name = %s\n", __func__, size, c_name);

  if(strcmp(c_name, "tr.counts")==0){// special variables stored in Driver
    fprintf(stderr, "[%s] Special variable %s\n", __func__, c_name);
    fprintf(stderr, "[%s] Special variable SUPR_HEADER_SIZE=%ld\n",
		    __func__, SUPR_HEADER_SIZE);
    if(((int*) ptr)[0] != SUPR) {
      free(ptr);
      errorcall(R_NilValue, "%s(%s,...) [%s, %d]", __func__, c_name,
		      __FILE__, __LINE__);
    }

    SEXP val = R_NilValue;
    int type = ((int*) ptr)[1];

    fprintf(stderr, "[%s] Special variable type = %d\n", __func__, type);
    for(int i=0; i<size/sizeof(int); i++)
    {
               fprintf(stderr, "[%s] %d\n", __func__, ((int*)ptr)[i]);
    }

    switch(type){
      case SUPR_INT_ARRAY:
           {
             int n = ((int*) ptr)[2];
	     for(int i=0; i<n; i++)
	     {
               fprintf(stderr, "[%s] Special variable int value%d\n",
			       __func__, ((int*)ptr)[i+4]);
	     }
	     val = allocVector(INTSXP, n);
	     memcpy(DATAPTR(val), ptr + SUPR_HEADER_SIZE, n*sizeof(int));
	   }
	   break;
      default: free(ptr);
           errorcall(R_NilValue, "%s(%s,...) Not implemented type %d ",
			   __func__, c_name, type);
           break;
    }

    free(ptr);
    return val;
  }
  // TODO
  /*
  SEXP x = allocVector(INTSXP, 1);
  int SEXPREC_SIZE = (int)((long) INTEGER(x) - (long) x);
  */

  if(size<4){
    free(ptr);
    errorcall(R_NilValue, "%s(%s,...)", __func__, c_name);
    /*
  } else if(size<SEXPREC_SIZE){
    int len = size/sizeof(int);
    SEXP val = allocVector(INTSXP, len);
    memcpy(INTEGER(val), ptr, size);
    free(ptr);
    return val;
    */
  } else {
#ifdef USE_SUPR_SERIALIZE
//    void *SUPR_serialize(SEXP x, SEXP env, size_t *size);
// SEXP SUPR_unserialize(void *x, SEXP env, size_t size);
    SEXP val = SUPR_unserialize(ptr, env, size);
#else
    SEXP val = TR_unserialize((SEXP)ptr, env);
#endif
    free(ptr);
    return val;
  }
}

void show_shm_io_info(shm_io_info_t *io){
   
  print_caller_info(0);

  fprintf(stderr, "%s:%d:%s: %p\n", __FILE__, __LINE__, __func__, io);
  if(!io) return;

/*
typedef struct shm_io_info {
  shm_io_block_t *in;
  shm_io_block_t *out;
  shm_io_block_t *err; // or msg
  shm_info_t shm_info;
} shm_io_info_t;
*/ 
  size_t page_size = sysconf(_SC_PAGE_SIZE);
  shm_info_t *shm_ptr = &io->shm_info;
  fprintf(stderr, "this pid: %d (tid=%ld)\n", getpid(), syscall(SYS_gettid));
  fprintf(stderr, "io->shm_info:\n");
  fprintf(stderr, "\tshm_name: %s\n", shm_ptr->shm_name);
  fprintf(stderr, "\tmem_ptr:  %p\n", shm_ptr->mem_ptr);
  fprintf(stderr, "\tsize:     %ld (%ld pages)\n", shm_ptr->size, shm_ptr->size/page_size);
  fprintf(stderr, "io->in:   %p [block pos=%d]\n", io->in, io->in == shm_ptr->mem_ptr? 0:1);

  {
    shm_io_block_t *block = io->in;
    PRINT_SHM_IO_BLOCK_INFO(block, page_size);
  }

  fprintf(stderr, "\nio->out:  %p [block_pos=%d]\n", io->out, io->out == shm_ptr->mem_ptr? 0:1);
  {
    shm_io_block_t *block = io->out;
    PRINT_SHM_IO_BLOCK_INFO(block, page_size);
  }

  fprintf(stderr, "\nio->err:  %p [block_pos=%d]\n", io->err, 2);
  {
    shm_io_block_t *block = io->err;
    PRINT_SHM_IO_BLOCK_INFO(block, page_size);
  }
  fprintf(stderr, "\n");




  
}




















