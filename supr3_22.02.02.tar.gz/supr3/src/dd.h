
#include "supr.h"
#include "util.h"

#ifndef __DD_H__
#define __DD_H__


#define Hashtable_put hashtable_set
#define Hashtable_get hashtable_find
#define Hashtable_delete hashtable_delete
#define Hashtable_keySet hashtable_keys
#define Hashtable_destroy hashtable_destroy
#define Hashtable_size hashtable_size

typedef struct stat dd_stat_t;

typedef struct dd_struct {
  class_t *class;
  int ref_count;
  int dir_fd;
  char *name;
  hashtable_t *values; 
  void *att; // attachment
} dd_t;

typedef struct namenode_value_struct {
  class_t *class;
  int ref_count;
  int padding;
  dd_stat_t stat;
  vector_t *addr;
} nn_value_t;

extern char *SocketConn_addr(supr_socket_conn_t *sc);

#ifdef __DD_MAIN__
#define dd_extern
#else
#define dd_extern extern
#endif

dd_extern dd_t *newDD(const char *name);
dd_extern void DD_init();
dd_extern nn_value_t *newNamenodeValue();

dd_extern DIR *__opendir__(const char *name); 
dd_extern int __rmdir__(const char *name, int recursive); 
dd_extern int __mkdir__(const char *name);

dd_extern void  DD_stat_print(dd_stat_t *stat);

dd_extern size_t SocketConn_writeString(supr_socket_conn_t* sc, const char *s);
dd_extern char *SocketConn_readString(supr_socket_conn_t*, char *b, size_t );
dd_extern size_t SocketConn_writeInt(supr_socket_conn_t* sc, int val);
//dd_extern int SocketConn_readInt(supr_socket_conn_t* sc);
dd_extern size_t SocketConn_writeSO(supr_socket_conn_t *sc, so_t *so);
dd_extern so_t *SocketConn_readSO(supr_socket_conn_t *sc);
dd_extern SEXP SocketConn_readRObject(supr_socket_conn_t *sc);

#endif

