

#include<sys/types.h>

#ifndef __USE_XOPEN
#define __USE_XOPEN
#endif

#ifndef __USE_XOPEN2KXSI
#define __USE_XOPEN2KXSI
#endif


#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 600 
#endif

#ifndef __USE_XOPEN_EXTENDED
#define __USE_XOPEN_EXTENDED
#endif


#include<stdlib.h>
#include <stdio.h>
#include <fcntl.h>

#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>

//#include <fcntl.h>

#include <time.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>



#include <Rembedded.h>
#include <Rinternals.h>
#include <R.h>
//#include <Rmath.h>
#include <R_ext/Parse.h>

//#include <setjmp.h>
#include "myRdefn.h"


#include <sys/syscall.h>
#include <readline/readline.h>
#include <readline/history.h>

// network
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <setjmp.h>

#ifndef SUPR3
#define SUPR3
#endif

#define TR_WAIT_USE_TIME_EXPR

#ifdef SUPR3
#define PACKAGE_NAME "supr3"
#define INFO_WARNING 1
#define WARNING_INFO_TYPE 1
#define INFO_ERROR 2
#define ERROR_INFO_TYPE 2
#define DEFAULT_INFO_TYPE 3
#define INFO_DFS_ERROR 4
#define DRIVER_INFO_TYPE 5
#define WORKER_INFO_TYPE 6
#define DFSNAME_INFO_TYPE 7
#define DFSDATA_INFO_TYPE 8
#endif
//#define _GNU_SOURCE
//#include <dlfcn.h>


//#include <sys/ipc.h>
//#include <sys/msg.h>

//#include <sys/types.h>

#include <dirent.h>
#include <sys/vfs.h>

//#ifndef __SYS_MALLOC__
//#define __SYS_MALLOC__(size) malloc(size)
//#endif

#ifndef __RJINI_H__
#define __RJINI_H__

#define SYS_COMMAND_MASTER "master"
#define SYS_COMMAND_DRIVER "driver"
#define SYS_COMMAND_WORKER "worker"
#define SYS_COMMAND_TASKRUNNER "taskrunner"
#define SYS_COMMAND_DFS_NAMENODE "dfs_name"
#define SYS_COMMAND_DFS_DATANODE "dfs_data"
#define SYS_SUPR_CONF_FILENAME "supr.conf"

#define DRIVER_START_WORKERS
#ifndef DRIVER_START_WORKERS
#define MASTER_START_WORKERS
#endif

/* See myRdefn
#ifndef VALUE_TO_STRING

#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)

#endif

#ifdef JMP_BUF
#pragma message "value of malloc = " VALUE(JMP_BUF)
#endif


#ifndef R_USE_SIGNALS
#define R_USE_SIGNALS
#endif
#ifndef HAVE_POSIX_SETJMP
#define HAVE_POSIX_SETJMP
#endif

#ifdef SETJMP
#undef SIGJMP_BUF
#undef SIGSETJMP
#undef SIGLONGJMP
#undef JMP_BUF
#undef SETJMP
#undef LONGJMP
#endif
// from R/src/include/Defn.h

#ifdef R_USE_SIGNALS
#ifdef HAVE_POSIX_SETJMP
# define SIGJMP_BUF sigjmp_buf
# define SIGSETJMP(x,s) sigsetjmp(x,s)
# define SIGLONGJMP(x,i) siglongjmp(x,i)
# define JMP_BUF sigjmp_buf
# define SETJMP(x) sigsetjmp(x,0)
# define LONGJMP(x,i) siglongjmp(x,i)
#else
# define SIGJMP_BUF jmp_buf
# define SIGSETJMP(x,s) setjmp(x)
# define SIGLONGJMP(x,i) longjmp(x,i)
# define JMP_BUF jmp_buf
# define SETJMP(x) setjmp(x)
# define LONGJMP(x,i) longjmp(x,i)
#endif
#endif
*/


/*
#ifdef JMP_BUF
#pragma message "value of JMP_BUF = " VALUE(JMP_BUF)
#pragma message "value of SETJMP = " VALUE(SETJMP(x))
#pragma message "value of LONGJMP = " VALUE(LONGJMP(x,y))
#endif
*/

#define error_info(...) real_info(ERROR_INFO_TYPE, __FILE__, __LINE__, __func__, __VA_ARGS__)

#define basic_info(...) do {	\
  if(Supr_options.info || Supr_options.verbose || Supr_options.debug)	\
  real_info(DEFAULT_INFO_TYPE, __FILE__, __LINE__, __func__, __VA_ARGS__); \
} while(0)

#define verbose_info(...) do {	\
  if(Supr_options.verbose || Supr_options.debug)	\
  real_info(VERBOSE_INFO_TYPE, __FILE__, __LINE__, __func__, __VA_ARGS__); \
} while(0)

#define debug_info(...) do {	\
  if(Supr_options.debug)	\
  real_info(DEBUG_INFO_TYPE, __FILE__, __LINE__, __func__, __VA_ARGS__); \
} while(0)

#define __verbose(...) do {	\
  if(Supr_options.info)	\
    real_info(__DEBUG_INFO_TYPE, __FILE__, __LINE__, __func__, __VA_ARGS__); \
} while(0)

//#endif
//#endif



#define SEMAPHORE_BUF_SIZE 4096
struct mmap_io_struct { // change the name
        char *file_name;
        pthread_mutex_t lock;
        pthread_cond_t cond; //nonzero;
        unsigned int count; // not used
        int cmd;
        pid_t parent_pid; // not used?
        pid_t child_pid;
        size_t buf_size;
        size_t data_size;
        unsigned char buf[0];
};

typedef struct mmap_io_struct semaphore_t;
typedef struct mmap_io_struct sem_io_t;
typedef struct mmap_io_struct mmap_io_t;


extern void (*ptr_R_Busy)(int);
extern unsigned long R_CStackStart;

/*
  void *dummy;  \
  currentThread()->save_CStackStart = R_CStackStart;   \
  R_CStackStart = (unsigned long) &dummy	\
  if(currentThread()->R_GlobalContext)	\
	R_GlobalContext = currentThread()->R_GlobalContext
	*/

//  R_CStackStart = currentThread()->save_CStackStart;   \
//  currentThread()->R_GlobalContext = R_GlobalContext;	\

//  unsigned long __save__R_CStackStart = R_CStackStart;	\
//  RCNTXT *__save__R_GlobalContext = R_GlobalContext;	\

typedef struct vector_struct vector_t;
typedef struct supr_socket_conn_struct supr_socket_conn_t;

typedef struct supr_options_struct {
  int verbose;
  int debug;
  int info;
  int port; // min port, the str expr is sprintf(char *, "%d+", port)
  int level; // level of message details
  int ncpu;
  int xterm; 
  int padding; // 
  double timeout;
// ...
} supr_options_t;

//#define TEST_KEEP_SSH_X11FORWARDING_ALIVE




#define Cluster_sendSimpleMessage(m, c, t, l) do {      \
        if(Supr_infov && ((t) == 0 || (t) == BASIC_INFO_TYPE))  \
                Supr_sendSimpleMessage((m), (c), (t), (l));     \
        else if(Supr_verbose && (t) == VERBOSE_INFO_TYPE)       \
                Supr_sendSimpleMessage((m), (c), (t), (l));     \
        else if(Supr_debug && (t) == DEBUG_INFO_TYPE)   \
                Supr_sendSimpleMessage((m), (c), (t), (l));     \
        else if((t) == ERROR_INFO_TYPE)   \
                Supr_sendSimpleMessage((m), (c), (t), (l));     \
        else if((t) == DEFAULT_INFO_TYPE)   \
                Supr_sendSimpleMessage((m), (c), (t), (l));     \
        else if((t) == __DEBUG_INFO_TYPE)   \
                Supr_sendVerboseMessage((m), (c), (t), (l));     \
} while(0)

#define state2char(s) Thread_stateToString(s)


#ifdef __SUPR_MAIN__
SEXP read_rso(const char *file_name);
void Supr_serialize1(void *data);
void Supr_unserialize1(void *data);
int Supr_refcnt(void *data);
void Supr_incref(void *data);
void Supr_decref(void *data);
int  nports = 1;
void Supr_registerSocketServer(supr_socket_conn_t *server, supr_socket_conn_t *info_sc);
void real_info(int type, const char *SourceFilename, int SourceLineno,
	       	const char *funName, const char *fmt, ...);
void __sys_warning__(const char *s, const char *file, int line, const char *func);
void Supr_debug2(pid_t pid, char **output);
void  Supr_checkRBCNodeStack();	 // delete me
int  Supr_killSocketServer(const char*syscmd, int port, void *);
int  Supr_killSocketServer2(int port, void *);
void handleClusterList(void *data, vector_t *socket_connections);
void handleClusterExists(void *data, vector_t *socket_connections);
void handleClusterAssign(void *data, vector_t *socket_connections);
void handleClusterContextGet(void *data, vector_t *socket_connections);
void handleClusterContextDoCall(void *data, SEXP env);
supr_options_t Supr_options = {FALSE, FALSE, FALSE, 1024, 0, 0, 0, 0,  60.0};
int (*Supr_sendSimpleMessage)(const char *msg, const char *color, int type,
                int level);
const char *Thread_stateToString(int state);
void Supr_notify(const char *dest, const char *src, int cmd);
int Supr_who3(const char *addr, int *pid_addr, supr_socket_conn_t **sc_addr);
int Supr_who4(const char *hostname, int port, int *pid_addr,
                supr_socket_conn_t **sc_addr);
SEXP Supr_mkError(const char *str);
char * Config_getAddr(char *name);
void argv_info(int argc, char **argv);
int Supr_sendVerboseMessage(const char *msg, const char *color, int type,
                int level);
#else
extern void (*System_shutdown)(void *data); 
extern int (*Cluster_handleCommand)(supr_socket_conn_t *conn);
extern int Supr_sendVerboseMessage(const char *msg, const char *color, int type,
                int level);
extern void (*Supr_do_ncpu_ptr)(int ncpu);
extern void (*Supr_do_xterm_ptr)(int xterm, int interactive);
extern void argv_info(int argc, char **argv);
extern char * Config_getAddr(char *name);
extern ssize_t timed_read(int fd, void *buf, size_t size);
extern SEXP read_rso(const char *file_name);
extern char *Supr_curErrorBuf;
extern ssize_t Supr_curErrorBuf_size;
extern char *Supr_curStrError;
extern void Supr_serialize1(void *data);
extern void Supr_unserialize1(void *data);
extern int Supr_refcnt(void *data);
extern void Supr_incref(void *data);
extern void Supr_decref(void *data);
extern int  nports;
extern supr_socket_conn_t *parent_sc;
extern char *Supr_signal_shm_create(pid_t pid, int sig, int cmd, void *msg, ssize_t len);
extern char *Supr_signal_shm_open(pid_t pid, int sig, void **mem_addr, ssize_t *size_addr);
extern char *proc_cmd;
extern char *shm_prefix;
extern char *Supr_curStrError;
extern void Supr_registerSocketServer(supr_socket_conn_t *server, supr_socket_conn_t *info_sc);
extern void real_info(int type, const char *SourceFilename, int SourceLineno,
	       	const char *funName, const char *fmt, ...);
extern void __sys_warning__(const char *s, const char *file, int line, const char *func);
extern void  Supr_checkRBCNodeStack(); // delete me
extern void Supr_debug2(pid_t pid, char **output);
extern int  Supr_killSocketServer(const char*syscmd, int port, void *);
extern int  Supr_killSocketServer2(int port, void *);
extern void handleClusterList(void *data, vector_t *socket_connections);
extern void handleClusterExists(void *data, vector_t *socket_connections);
extern void handleClusterAssign(void *data, vector_t *socket_connections);
extern void handleClusterContextGet(void *data, vector_t *socket_connections);
extern void handleClusterContextDoCall(void *data, SEXP env);
extern supr_options_t Supr_options;
extern SEXP SuprContextEnv;
extern int (*Supr_sendSimpleMessage)(const char *msg, const char *color, int type,
                int level);
extern const char *Thread_stateToString(int state);
extern void Supr_notify(const char *dest, const char *src, int cmd);
extern int Supr_who3(const char *addr, int *pid_addr, supr_socket_conn_t **sc_addr);
extern int Supr_who4(const char *hostname, int port, int *pid_addr,
                supr_socket_conn_t **sc_addr);
extern SEXP Supr_mkError(const char *str);
#endif

extern  R_bcstack_t *R_BCNodeStackTop, *R_BCNodeStackEnd;
extern  SEXP R_lock();
extern  SEXP R_unlock();

#define LOCK_R() __supr_R_Busy(TRUE)
#define UNLOCK_R() __supr_R_Busy(FALSE)


#define BEGIN_R_EVAL()     do      {       \
	R_lock();	\
	save_cstackstart = R_CStackStart;	\
	R_CStackStart = ((supr_thread_t*)pthread_getspecific(currentThreadKey))->R_CStackStart;


//  __supr_R_Busy(TRUE)
//  __supr_R_Busy(FALSE);	\


extern unsigned long save_cstackstart;

#define END_R_EVAL()   \
	R_CStackStart = save_cstackstart;	\
	R_unlock();	\
} while(0)

//  R_GlobalContext = __save__R_GlobalContext;	\
//  R_CStackStart = __save__R_CStackStart;	\

#define sys_warning(s) __sys_warning__((s), __FILE__, __LINE__, __func__)

// not use this
#define BEGIN_R_FREE()     do      {       \
    sys_warning("delete BEGIN_R_FREE")
//  R_CStackStart = currentThread()->save_CStackStart;   \
//  ptr_R_Busy(FALSE)

//  ptr_R_Busy(TRUE);	\
//  currentThread()->save_CStackStart = R_CStackStart;   \
//  void *dummy;  \
//  R_CStackStart = (unsigned long) &dummy;	\

#define END_R_FREE()   \
} while(0)



#define TODO() printf("\033[0;31m]%s (%s:%d) TODO\033[0m\n", __func__, __FILE__, __LINE__);

#define _dupstr(x) memcpy(malloc(strlen(x)+1), (x), strlen(x)+1)
#define INT_SIZE  4
#define SIZE_SIZE 8
#define DOUBLE_SIZE 8






typedef struct class_struct {
  char *name;
  const char *(*toString)(struct class_struct *, void *);
  void (*finalize)(struct class_struct *, void *);
} class_t;



typedef struct run_struct {
  class_t *class;
  int ref_count;
  int padding; // reserved ?
  void (*run)(void *);
  void *data;
} run_t;



typedef struct object_struct {
  class_t *class;
  int ref_count;
  int padding; // reserved ?
} object_t;

typedef struct wrapped_object_struct {
  class_t *class;
  int ref_count;
  int padding; // reserved ?
  void *ptr;
} wrapped_object_t;

typedef struct extended_object_struct {
  class_t *class;
  int ref_count;
  int padding; // reserved ?
  unsigned char ext[0];
} extended_object_t;

#define REF_COUNT_INITIALIZER 1

// FIXME
#define classOf(x) ((object_t *)x)->class
#define objectToString(x) ((object_t *)(x))->class->toString(	\
		((object_t *)(x))->class, (x))

#define Object_toString(x) ((object_t *)(x))->class->toString(	\
		((object_t *)(x))->class, (x))

#define newString(x) new_string((x), __FILE__, __LINE__)

//#define String_new(x) new_string((x), __FILE__, __LINE__)


typedef struct strbuf_struct {
  class_t *class;
  int ref_count;
  int padding;
  unsigned char *buf;
  size_t size;
  size_t buf_size;
} strbuf_t;


/*
typedef struct R_thread_ext_struct {
  char *name;
  SEXP value;
} R_thread_ext_t;
*/

//typedef struct supr_socket_conn_struct supr_socket_conn_t;
typedef struct supr_thread_struct supr3_thread_t;

typedef struct supr_thread_struct {
  class_t *class;
  int ref_count;
  int padding;
  pthread_t ptid;
  pid_t pid;
  pid_t tid;
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  supr_socket_conn_t *conn; //supr3
  SEXP sharedEnv; //supr3


  void (*fun)(void *);
  void *data;
  void *properties; // FIXME, used now for executors

  int state;
  int save_R_PPStackTop; //r_ext_len; //SEXP R_thread; -> // R_thread_ext ?

  SEXP R_thread;
  //unsigned long save_CStackStart;
  RCNTXT *R_GlobalContext;
  unsigned long R_CStackStart;
  char *name;

  char *where; // file:line, for debugging...
  //jmp_buf cjmpbuf;
  JMP_BUF cjmpbuf;
  run_t *runnable;

  // checking for now ... delete me
  R_bcstack_t *save_R_BCNodeStackTop;   // position at BEGIN_R_EVAL[_LOCK]
  R_bcstack_t *R_BCNodeStackTop;	// position at BEGIN_R_EVAL[_UNLOCK]

  void *save_BCNodeStack;
  RCNTXT *R_ToplevelContext; // testing

  // R_eval state: 0 - before R_EVAL, 1 - in R_EVAL, 2 - in R_FREE 
  int R_eval_state;
  int not_used; 

} supr_thread_t;

typedef struct string_struct {
  class_t *class;
  int ref_count;
  int padding;
  size_t length;
  char *str;
  // for debugging memory management
  //char *src_file;
  //int src_line;
  //int ref_count;
} string_t;

typedef struct String_struct {
  class_t *class;
  int ref_count;
  int padding;
  size_t length;
  char str[0];
  // char *str;
} *String;


typedef struct user_job_struct {
  class_t *class;
  int ref_count;
  int padding;
  int id;
  int status; // fixme
  int (*is_done)(int id);
  void *(*get)(int id, double timeout);
  int (*cancel)(int id);
  void (*R_finalizer)(SEXP s);
  void *result;
} user_job_t;


#ifdef __SUPR_MAIN__
int R_isInterrupted = FALSE;
//class_t *Supr_classes = NULL; // registered classes
#define supr_extern
#else
extern int R_isInterrupted;
//extern class_t *Supr_classes = NULL; // registered classes
#define supr_extern extern
#endif

//supr_extern class_t *Supr_classes; // registered classes
//supr_extern class_t *SuprClass_register(class_t *c);
//supr_extern class_t *SuprClass_get(void *object);
//supr_extern const char *SuprClass_name(class_t *c);


supr_extern int Supr_infov;
supr_extern int Supr_verbose;
supr_extern int Supr_debug;
supr_extern char *Supr_hostname;
supr_extern char *Supr_login;
supr_extern char *Supr_username;
supr_extern char **Supr_argv;

supr_extern void Supr_do_xterm(int use_xterm, int interactive);
supr_extern int Supr_gdb_C(int proc, int interactive, supr_thread_t **,
		char **xterm_name);

supr_extern int Supr_handleCommand(int cmd, supr_socket_conn_t *conn);
supr_extern int Supr_checkLogin(int fd, supr_socket_conn_t *conn, char *server);
supr_extern ssize_t timed_read(int fd, void *buf, size_t size);

supr_extern int Exec_setStdout(const char *cmd, const char *out);

supr_extern char **Exec_createArgs(const char **argv_b, SEXP args);
supr_extern void Exec_freeArgs(char **argv);

supr_extern void (*Supr_free)(void *ptr);
supr_extern void *(*Supr_malloc)(size_t size);
supr_extern void *(*Supr_realloc)(void *ptr, size_t size);
//supr_extern void *(*Supr_calloc)(size_t nmemb, size_t size);

supr_extern int Supr_refcnt(void *data);
supr_extern void Supr_incref(void *data);
supr_extern void Supr_decref(void *data);

supr_extern SEXP R_thread_init();
supr_extern void __save_R_PPStack();
supr_extern void __restore_R_PPStack();
supr_extern int __supr_R_Busy(int busy);

//supr_extern mmap_io_t *semaphore_create(char *semaphore_name);
supr_extern mmap_io_t *mmap_io_create(char *semaphore_name);
//supr_extern mmap_io_t *semaphore_open(char *semaphore_name);
supr_extern mmap_io_t *mmap_io_open(char *semaphore_name);
//void semaphore_post(semaphore_t *semap);
//void semaphore_wait(semaphore_t *semap);
//supr_extern void semaphore_close(semaphore_t *semap);
supr_extern void mmap_io_close(semaphore_t *semap);


//supr_extern pthread_key_t save_R_CStackStartKey;

supr_extern int supr_init();
supr_extern void ShmCache_add(const char *name, size_t size, void *att);
supr_extern int ShmCache_inc_ref(const char *name);
supr_extern int ShmCache_dec_ref(const char *name);
supr_extern void ShmCache_check();
supr_extern void ShmCache_clear();

supr_extern int Thread_callStack_dl();

supr_extern void SUPR_setSignalHandler(
		void (*int_action)(int, siginfo_t *, void *),
                void (*usr1_action)(int, siginfo_t *, void *),
                void (*usr2_action)(int, siginfo_t *, void *)
		);
supr_extern SEXP R_setJavaDriverPID(SEXP pid);

//supr_extern int isInterrupted();

supr_extern pthread_key_t currentThreadKey;
supr_extern pthread_key_t interruptThreadKey;
supr_extern pthread_key_t stacktraceKey;
supr_extern pthread_key_t taskrunnerThreadKey;


supr_extern supr_thread_t *currentThread();

supr_extern class_t *getClass(void *);

supr_extern class_t *newClass(char *name,
	       	const char *(*toString)(class_t *, void *),
	       	void (*finalize)(class_t *, void *)
		);
supr_extern strbuf_t *newStrbuf(size_t size);
supr_extern strbuf_t *Strbuf_resize(strbuf_t *sb, size_t size);
supr_extern strbuf_t *strbufPut(strbuf_t *, const void *p, size_t size);
supr_extern char *cmd2str(int cmd);
supr_extern strbuf_t *strbufPutStr(strbuf_t *sb, const char *str);
supr_extern void *R_objectToBytes3(SEXP object, size_t *size, size_t offset);
supr_extern void *R_objectToBytes(SEXP object, size_t *size);
supr_extern SEXP R_bytesToObject(void *data, size_t length);
supr_extern SEXP R_objectToRaw(SEXP object); // serialize(object, NULL) 
supr_extern SEXP R_rawToObject(SEXP icon);

supr_extern SEXP SO_toRObject(void *ptr, size_t size);
//supr_extern so_t *SO_error(const char *msg);
//supr_extern so_t *SO_valueOf(SEXP r_object, size_t *length);


supr_extern supr_thread_t *newThread(pthread_t, pid_t, pid_t tid, int state,
		unsigned long C_StackStart);
supr_extern void threadDestroy(supr_thread_t *th);

supr_extern SEXP TR_sync_eval(SEXP expr, SEXP mutex, SEXP env);

supr_extern string_t *new_string(char *str, char *file, int line);
//supr_extern size_t stringObjectSize(string_t *s);
supr_extern size_t stringLength(string_t *s);
supr_extern size_t writeString(int fd, string_t *s);

//supr_extern int shm_io_readInt(shm_io_info_t *io);
//supr_extern int shm_io_writeInt(shm_io_info_t *io, int val);

supr_extern supr_thread_t *Thread_main_init();
supr_extern SEXP Thread_new(SEXP expr, SEXP args, SEXP error_handler,
	       	SEXP env, SEXP name, SEXP isProcess);
supr_extern SEXP Thread_start(SEXP thread, SEXP dots);
#ifdef SUPR3
supr_extern SEXP Thread_join(SEXP thread_env, SEXP useProxy);
#else
supr_extern SEXP Thread_join(SEXP thread_env);
#endif

//supr_extern string_t *String_new(const char* format, ...);
supr_extern String String_new(const char* format, ...);


// SUPR
// byte array types
// array structure: [[4 bytes for SUPR][4 bytes for object type]...]

typedef struct socket_conn_struct {
  class_t *class;
  int ref_count;
  int padding;
  int fd;
  int endian;
  int native_endian;
} socket_conn_t;


typedef struct supr_header_struct {
  int id; // = SUPR
  int type; 
  int length;
  int padding;
} supr_header_t;

void *SUPR_serialize(SEXP x, SEXP env, size_t *size);
SEXP SUPR_unserialize(void *x, SEXP env, size_t size);
SEXP supr2r(supr_header_t *x, size_t size, SEXP env);

// object_type via file suffix conventions ???:
#define FILE_SUFFIX_SUPR_OBJECT  1
#define FILE_SUFFIX_R_DATA       2
#define FILE_SUFFIX_TEXT         3
#define FILE_SUFFIX_TEXT_CSV     4
#define FILE_SUFFIX_TEXT_TAB     5
#define FILE_SUFFIX_R_OBJECT     6  // serialized R object
#define FILE_SUFFIX_UNKNOWN_TYPE 0


#define SUPR  598  /* some number */
#define SUPR_SERIALIZED_ROBJ  101  //
#define SUPR_ERROR            102  //
#define SUPR_UNBOUND_VALUE    103  //
#define SUPR_KEEP_VALUE    103  // ??
#define SUPR_PTHREAD_TIMEOUT    104  //
#define SUPR_PTHREAD_INTERRUPTED    105  //
#define SUPR_SHM_NAME    106  //
#define SUPR_URI         107  //
#define SUPR_FILE        108  //
#define SUPR_R_OBJECT    111  //
#define SUPR_SO_ARRAY    112  //
#define SUPR_DD_SUBSET_LOCATIONS   113	//
#define SUPR_STRING_ARRAY    114	//
#define SUPR_REFERENCE       120    //
#define TASKRUNNER_INTERRUPTED    121  //
#define SUPR_JOB_CANCELLED 122

#define SUPR_MEMTYPE_MEM      0  //
#define SUPR_MEMTYPE_SHM      1  //
#define SUPR_MEMTYPE_TMP      2  //
#define SUPR_MEMTYPE_FILE     3  //

// object types, modified from R SEXP types ... TODO

#define SUPR_NILSXP       0    /* nil = NULL */
#define SUPR_SYMSXP       1    /* symbols */ // used for char *
#define SUPR_LISTSXP      2    /* lists of dotted pairs */
#define SUPR_CLOSXP       3    /* closures */
#define SUPR_ENVSXP       4    /* environments */
#define SUPR_PROMSXP      5    /* promises: [un]evaluated closure arguments */
#define SUPR_LANGSXP      6    /* language constructs (special lists) */
#define SUPR_SPECIALSXP   7    /* special forms */
#define SUPR_BUILTINSXP   8    /* builtin non-special forms */
#define SUPR_CHARSXP      9    /* "scalar" string type (internal only)*/
#define SUPR_LGLSXP      10    /* logical vectors */
/* 11 and 12 were factors and ordered factors in the 1990s */

#define SUPR_INT_ARRAY   13    /* integer vectors */ // USED

#define SUPR_REALSXP     14    /* real variables */
#define SUPR_CPLXSXP     15    /* complex variables */
#define SUPR_STRSXP      16    /* string vectors */
#define SUPR_DOTSXP      17    /* dot-dot-dot object */
#define SUPR_ANYSXP      18    /* make "any" args work.
                             Used in specifying types for symbol
                             registration to mean anything is okay  */
#define SUPR_VECSXP      19    /* generic vectors */
#define SUPR_EXPRSXP     20    /* expressions vectors */
#define SUPR_BCODESXP    21    /* byte code */
#define SUPR_EXTPTRSXP   22    /* external pointer */
#define SUPR_WEAKREFSXP  23    /* weak reference */
#define SUPR_RAWSXP      24    /* raw bytes */
#define SUPR_S4SXP       25    /* S4, non-vector */

/* used for detecting PROTECT issues in memory.c */
#define SUPR_NEWSXP      30    /* fresh node creaed in new page */
#define SUPR_FREESXP     31    /* node released by GC */

#define SUPR_FUNSXP      99    /* Closure or Builtin or Special */




typedef struct __shm_info {
  char *shm_name;
  void *mem_ptr;
  size_t size; // multiple of 3
} shm_info_t;

typedef struct shm_io_block { // block_header
  size_t size; // shm_segment: {([shm_size, ] ...)([1, ...] ...) ([2, ...] ...)}
  sem_t sem_wait; 
  sem_t sem_wr; 
  sem_t sem_yield;
  int   pid; // used for waiting to read or write
  int   padding;
  size_t buffer_size; // block_size - sizeof(shm_io_block_t)
  size_t data_size;
} shm_io_block_t;

typedef struct shm_io_info {
  shm_io_block_t *in; 
  shm_io_block_t *out;
  shm_io_block_t *err; // or msg
  shm_info_t shm_info;
} shm_io_info_t;

typedef struct shm_header {
  int ref_count;
  int padding;
} shm_header_t;



typedef struct broadcast_lock_struct {
  pthread_rwlock_t rwlock;
  pthread_mutex_t mutex;
  pthread_cond_t cond;
  long bc_id;
  int destroy;
  int padding;
  char shm_name[0];
} broadcast_lock_t;



typedef struct tr_cntxt_struct {
  shm_io_info_t *io;
  int job_id;
  int tr_id;
  int port;
  pid_t pid;
  char *host;
  SEXP firstSubset;
  broadcast_lock_t *bc_sync; // worker.c: broadcast_t
  long bc_id;
} tr_cntxt_t;

typedef struct supr_object_struct {
  int ref_count; // or command???
  int mem_type;
  int sys_type;
  int obj_type;
  size_t size; // actual data size of val
  unsigned char val[0];
} so_t;

supr_extern so_t *SO_valueOf(SEXP, size_t *size);
supr_extern so_t *SO_error(const char *msg);

supr_extern void SO_incref(so_t *s); // change it to 
supr_extern void SO_decref(so_t *s);
//supr_extern int SO_finalize(so_t *s);

//tr_cntxt_t tr_cntxt = {NULL, -1, -1, 0};

#define TR_EXIT    100
#define TR_NEW_JOB 101
#define TR_SEND_DRIVER 102
#define TR_JOB_RESULT 103
#define TR_NEXT_JOB 104
#define TR_JOB_REGISTER 105
#define TR_NEXT_SUBSET 306
#define TR_COMBINE 307
#define TASKRUNNER_MESSAGE 308
#define TR_COMBINE_BYKEY 309
#define TR_COMBINE_BYKEY_INIT 310
#define TR_GET_VALUE 311
#define TR_NTASKRUNNERS 312
#define TR_RECV_MSG 313
#define TR_GET_MSG 314

#define THREAD_PROC_GET 321
#define THREAD_PROC_PUT 323	// assign
#define THREAD_PROC_LOCK 325
#define THREAD_PROC_UNLOCK 327
#define THREAD_PROC_WAIT 329
#define THREAD_PROC_NOTIFY 331
#define THREAD_PROC_EXIT 335


#define TR_DD_SUBSET   502
#define TR_INT_VALUE   503

#define TR_JOB_ID ".job_id"
#define TR_TR_ID ".tr_id"
#define TR_TR_IO ".tr_io"

#define CBK_FINISHED 0
#define TR_CLUSTER_GET 351
#define TR_CHECK_INTERRUPT 355

#define CLUSTER_STATE 353


#define TASK_RESULTS 303
#define TASK_EXIT    304


//#define TR_CLUSTER_TIMEOUT 380
#define TR_CLUSTER_SYNC 381
#define TR_CLUSTER_SYNC_RETURN   391
#define TR_CLUSTER_WAIT 382
#define TR_CLUSTER_WAIT_RETURN 682
#define TR_CLUSTER_WAIT_TIMEOUT 683
#define TR_CLUSTER_NOTIFY 383
#define TR_CLUSTER_NOTIFYALL 384
#define TR_CLUSTER_INTERRUPT 385
#define TR_CLUSTER_UNSYNC 386
#define TR_CANCELED       394
#define TR_PUT_PAR        395
#define TR_GET_PAR        396
#define TR_EXIST_PAR        387
#define TR_LIST_PAR        388
#define TR_REMOVE_PAR      389
#define R_FUTURE_GET      397
#define R_FUTURE_ISDONE   398
#define R_FUTURE_ISCANCELED   399
#define R_FUTURE_CANCEL   361
#define TR_CLUSTER_WAIT_TIMEOUT_EXPR 362

#define TR_COUNTDOWN_CREATE 370
#define TR_COUNTDOWN_DECREASE 371
#define TR_COUNTDOWN_COUNT 372
#define TR_COUNTDOWN_RESET 373
#define TR_COUNTDOWN_RELEASE 374

#define CLUSTER_PING 510
#define CLUSTER_PONG 511
#define CLUSTER_INFO 512
#define CLUSTER_PROC_CMD 513
#define CLUSTER_INFO_DISCONNECT 514

#define CLUSTER_EXECUTOR_REGISTER 519
#define SOCKET_SERVER_REGISTER 520
#define INFO_SERVER_REGISTER 521
#define INFO_SERVER_GET 522

#define CLUSTER_GET_WORKER_ADDR 531
#define CLUSTER_GET_DATANODE_ADDR 532

#define DCL_CONN  901
#define DCL_EVENT_GET  902
#define DCL_JOB_ERROR 905

//#define dupstr(str)  memcpy(malloc(strlen(str)+1), (str), strlen(str)+1)

// conn

#define CONN_OPEN_MAX 64

typedef struct supr_conn_struct {
  class_t *class;
  int ref_count;
  int padding;
  int fd;
  int type;
  struct supr_conn_struct *prev;
  struct supr_conn_struct *next;
} supr_conn_t;

#define SocketConn_destroy(sc) (sc)->class->finalize((sc)->class, (sc))
#define Thread_destroy(th) (th)->class->finalize((th)->class, (th))
#define Vector_destroy(v) (v)->class->finalize((v)->class, (v))
#define String_destroy(s) (s)->class->finalize((s)->class, (s))

//#define toString(obj) (obj)->class->toString((obj)->class, (obj))

#define CLUSTER_INTERRUPT 19 // FXIME

#define CLUSTER_SHUTDOWN 0
#define SOCKET_CONN 1
#define MASTER_CONN 2
#define DRIVER_CONN 3
#define WORKER_CONN 4
#define DFS_NAMENODE_CONN 5
#define DFS_DATANODE_CONN 6
#define INFO_CONN 7
#define USER_CONN 8
#define INFO_CONN_SERVER 9
#define WEB_CLIENT_CONN 10
#define MAIN_USER_CONN 11
#define TASKRUNNER_CONN 12
#define EXECUTOR_CONN 13
#define JOB_CONN 14

#define HTTP_GET  542393671
#define HTTP_POST 1414745936


#define USER_INFO_ENABLED 5011
#define USER_INTERRUPT 5013

#define BASIC_INFO_TYPE 6000
#define DEBUG_INFO_TYPE 6001
#define VERBOSE_INFO_TYPE 6002
// ENABLE_INFO ?
#define SET_BASIC_INFO 6003  
#define SET_DEBUG 6004
#define SET_VERBOSE 6005
#define SET_CONN_PID 6006
#define GET_CONN_PID 6007
#define CLUSTER_SET_OPTIONS 6008
//#define ERROR_INFO_TYPE 6007
#define CLUSTER_LOGIN 6009
#define __DEBUG_INFO_TYPE 6011


#define DRIVER_REGISTER 13
#define WORKER_REGISTER 14
#define WORKER_READY 15
#define DFS_DATANODE_REGISTER 16
#define INFO_REGISTER 17
#define USER_REGISTER 18
#define CLUSTER_WHO 20


//#define MASTER_INFO 22
#define DRIVER_INFO 23
#define USER_INFO 27
#define SOCKET_SERVER 29
//#define WORKER_INFO 24
#define CLUSTER_JOB_SUBMIT 1001
#define CLUSTER_JOB_INFO   1002
//#define CLUSTER_JOB_REMOVE  1004
#define CLUSTER_MALLOC_PRINT  1004
#define CLUSTER_DRIVER_STOP 1003
#define CLUSTER_DRIVER_INFO 1005
#define CLUSTER_DRIVER_NULL 1007
#define CLUSTER_MASTER_NULL 1007
#define CLUSTER_WORKER_NULL 1007
#define CLUSTER_MASTER_STOP 1009
#define CLUSTER_WORKER_STOP 1011

#define CLUSTER_CONNECT_MASTER 1012
#define CLUSTER_MMAP_CONN 1013
#define CLUSTER_CONNECT_DFSNAME 1014
#define CLUSTER_MMAP_CLOSE 1015
#define CLUSTER_WORKER_STARTED 1016
#define CLUSTER_SHM_CONN 1017
#define CLUSTER_CONNECT_DRIVER 1018
#define CLUSTER_DFSDATANODE_STARTED 1020

#define CLOSE_CONN 1019
#define CLUSTER_GET_CONTEXT 1021

#define CLUSTER_CONTEXT_GET 1022
#define CLUSTER_CONTEXT_PUT 1023
#define CLUSTER_CONTEXT_OBJECTS 1024
#define CLUSTER_CONTEXT_EXISTS 1025
#define CLUSTER_CONTEXT_REMOVE 1026

#define CLUSTER_CONNECT_THREADSERVER 1027

#define THREADSERVER_STARTED 1028
#define CLUSTER_CONTEXT_DOCALL 1029
#define CLUSTER_CONTEXT_EVAL 1030

#define CLUSTER_START_MASTER 1031
#define CLUSTER_START_DFS_NAMENODE 1032

#define CLUSTER_MSG_SEND 1040
#define CLUSTER_MSG_RECV 1041
#define CLUSTER_MSG_BROADCAST 1042
#define CLUSTER_MSG_SEND_TO_TR 1043

#define CLUSTER_TEST 1050

#define CLUSTER_TASKRUNNER_REGISTER 302
#define CLUSTER_BYTE_MSG   208
#define TR_TASK_STATUS_SUCCESS 0
#define TR_TASK_STATUS_FAILURE -1
#define TR_TASK_STATUS_CANCELLED 2

#define SUPR_INTERRUPT 3010

// null operation:
#define DFS_DD_NULL     2010

#define DFS_DD_LIST     2011
#define DFS_DD_CREATE   2013
#define DFS_DD_CREATE_RETURN   2014
#define DFS_DD_PUT      2015
#define DFS_DD_PUT_RETURN      2016
#define DFS_DD_PERSIST  2017
#define DFS_DD_PERSIST_RETURN  2018
#define DFS_DD_UPDATE   2019 
#define DFS_DD_UPDATE_RETURN   2020 
#define DFS_DD_OPEN     2021
#define DFS_DD_OPEN_RETURN     2022
#define DFS_DD_REMOVE   2023
#define DFS_DD_GET      2025
#define DFS_DD_REPLICATE 2027
#define DFS_DD_REPLICATE_RETURN 2028
#define DFS_DD_CLOSE    2029
#define DFS_DD_CLOSE_RETURN    2030
#define DFS_DD_INFO     2031
#define DFS_DD_INFO_RETURN     2032
#define DFS_DD_OPTION     2033
#define DFS_DD_OPTION_RETURN     2034
#define DFS_DD_MOVE     2035
#define DFS_DD_MOVE_RETURN     2036

#define DFS_DD_DATANODE_INFO     2037
#define DFS_DD_GET_LOCAL_DATANODE_PID     2039
#define DFS_NAMENODE_ADDR 2038
#define DFS_MASTER_ADDR 2040


#define DFS_START_WORKERS     2041
#define DFS_STOP_WORKERS     2043
#define CLUSTER_START_WORKERS     2045

#define CLUSTER_SET_NTRS     2047

#define DFS_DD_EXISTS     2051
#define DFS_DD_EXISTS_RETURN     2052

#define DFS_DDT_CALL     2053
#define DFS_DDT_CALL_CANCEL     2054

#define TR_PRINT_STDOUT     2061
#define TR_PRINT_STDERR     2062

// persist levels
#define DFS_DD_PERSIST_NULL_LEVEL  0
#define DFS_DD_PERSIST_MEM_LEVEL   1
#define DFS_DD_PERSIST_SHM_LEVEL   2
#define DFS_DD_PERSIST_TMP_LEVEL   3
#define DFS_DD_PERSIST_FILE_LEVEL  4
/*
typedef struct dd_struct {
  hashtable_t *subsets;
} dd_t;
*/
/*
typedef struct supr_conn_struct {
  class_t *class;
  int ref_count;
  int padding;
  int fd;
  int type;
  struct supr_conn_struct *prev;
  struct supr_conn_struct *next;
} supr_conn_t;
*/

//#define SocketConn_destroy(sc) (sc)->class->finalize((sc)->class, (sc))

typedef struct supr_socket_conn_struct {
  class_t *class;
  int ref_count;
  int pid; //int padding;
  int fd;
  int type;
//  struct supr_conn_struct *prev;
//  struct supr_conn_struct *next;
  void (*print)(struct supr_socket_conn_struct *sc); // for development only?
  const char *host; // socket_conn_addr
  int port;
  int efd; // used for shm redirction
  pthread_mutex_t *mutex;
  struct in_addr sin_addr;
  int tid;
  int client_port;
  char *cmd; // process cmd
  struct supr_socket_conn_struct *to; // used by driver...
  void *att; // attachment
} supr_socket_conn_t;

#define __USE_LOCAL_GET__

#define FD_writeString(fd, str) do {	\
	size_t len = strlen(str) + 1;	\
	write((fd), &len, SIZE_SIZE);	\
	write((fd), (str), len);	\
} while(0)

#ifdef __CONN_MAIN__
void socketDestroy(supr_socket_conn_t *sc); 
supr_socket_conn_t *socketOpen(supr_socket_conn_t *serverConn);
supr_socket_conn_t *socketOpen2(const char *host, int port);
int socket_client(char *str, int port);
supr_socket_conn_t *socketOpen1(const char *address);
int tryPingSocketServer2(const char *hostname, int port);
int tryPingSocketServer1(const char *address);
supr_socket_conn_t* trySocketOpen2(const char *hostname, int port);
supr_socket_conn_t* trySocketOpen1(const char *addr);
supr_thread_t *startDebugThread(int port, const char * info_addr); 
supr_socket_conn_t *serverSocketOpen3(int port, int nports, const char *cmd);
ssize_t Socket_available(supr_socket_conn_t *sc);
#else
extern void socketDestroy(supr_socket_conn_t *sc); 
extern supr_socket_conn_t *socketOpen(supr_socket_conn_t *serverConn);
extern supr_socket_conn_t *socketOpen2(const char *host, int port);
extern int socket_client(const char *str, int port);
extern supr_socket_conn_t *socketOpen1(const char *address);
extern int tryPingSocketServer2(const char *hostname, int port);
extern int tryPingSocketServer1(const char *address);
extern supr_socket_conn_t* trySocketOpen2(const char *hostname, int port);
extern supr_socket_conn_t* trySocketOpen1(const char *addr);
extern supr_thread_t *startDebugThread(int port, const char * info_addr); 
extern supr_socket_conn_t *serverSocketOpen3(int, int, const char *cmd);
extern ssize_t Socket_available(supr_socket_conn_t *sc);
#endif

// thread

#define THREAD_STATE_NEW 0
#define THREAD_STATE_RUNNABLE 1
#define THREAD_STATE_BLOCKED 2
#define THREAD_STATE_WAITING 3
#define THREAD_STATE_TIMED_WAITING 4
#define THREAD_STATE_TERMINATED 5
//#define THREAD_STATE_CANCELLED 6

#define SUPR_CURRENT_THREAD() ((supr_thread_t*)pthread_getspecific(currentThreadKey))




// DRIVER-USER COMMANDS
#define DU_SUCCESS 0 // return code
#define DU_ERROR 2 
#define DU_JOB_SUBMIT 1
#define DU_JOB_GET 3 // get result
#define DU_JOB_CANCEL 4
#define DU_JOB_ISDONE 5
#define DU_DRIVER_EVAL 6
#define DU_DISCONNECT 7

// user_cntxt
/*
typedef struct supr_context_struct {
  class_t *class;
  int ref_count;
  int padding;

  char *sys_home;
  char *usr_home;
  char *dfs_home;

  shm_io_info_t *driver_shm_io;
  mmap_io_t     *driver_mmap_io;
  supr_socket_conn_t   *driver_sc;

  supr_socket_conn_t   *dnn_sc;  // DSF_namenode connection

  supr_socket_conn_t   *msg_ss;  // server socket

} supr_context_t;
*/

/*
typedef struct iterator_struct {
  int (*hasNext)(void *data);
  void *(*next)(void *data);
  void *data;
} iterator_t;

typedef struct job_struct {
  char *name; // for driver user interface
  int job_id;
  int count;
  iterator_t *tasks; // implemented as subsets
  void *expr; // (serialized R expression for taskrunners
  void *result;
  void *environment; // for driver and workers?
} job_t;
*/

#ifdef __RJNI_MAIN__
#define lib_extern 
#else
#define lib_extern extern
#endif

typedef void *(*malloc_t)(size_t, const void *);

//lib_extern char *dupstr(const char *str);

lib_extern void *rjni_shm_create(const char *shm_name, size_t size);
lib_extern void *rjni_shm_open(const char *shm_name, size_t *size);
lib_extern void *supr_shm_open(const char *shm_name, size_t *size);
lib_extern shm_io_info_t *shm_io_create(const char *shm_name, size_t block_size);
lib_extern int shm_io_reset(shm_io_info_t *io, int isCreator);
lib_extern void show_shm_io_info(shm_io_info_t *io);
lib_extern int shm_destory(shm_io_info_t *);
lib_extern shm_io_info_t *shm_io_open(const char *shm_name);
lib_extern int shm_io_close(shm_io_info_t *io);
//lib_extern void *shm_io_read(shm_io_block_t *in, size_t *size, char **tmp_shm_name);
//lib_extern void *shm_io_read(shm_io_info_t *io_info, shm_io_block_t *in, size_t *size, char **tmp_shm_name);
lib_extern void *shm_io_read(shm_io_info_t *io_info, shm_io_block_t *in,
	       	size_t *size, malloc_t malloc);
lib_extern size_t shm_io_write(shm_io_info_t *io_info, shm_io_block_t *out,
	       	void *src, size_t size);

lib_extern int tr_shm_init(int job_id, int tr_id);

lib_extern void SocketConn_attach(supr_socket_conn_t *sc, void *object);
lib_extern void Thread_cancel(void *data);
lib_extern run_t *newRunnable(void (*run)(void *), void *data);

#endif
