
#define __DD_MAIN__

#include "dd.h"

#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)

// FIXME
#ifndef _
#define _(x) (x)
#endif



static const char *__src_file = NULL;
static const char *__src_func = NULL;
static int __src_line = -1;

static void __src_info(const char *func, const char *file, int line)
{
//  if(stdlog) fprintf(stdlog, "%s (%s:%d) ", func, file, line); else
//    fprintf(stdout, "%s (%s:%d) ", func, file, line);
  __src_file = file;
  __src_func = func;
  __src_line = line;
}
//
static void dd_info(const char *format, ...)
{
    if(!Supr_verbose) return;

    fprintf(stdout, "%s:%s:%d ", __src_func, __src_file, __src_line);
    va_list ap;
    supr_thread_t *cth = currentThread();
    if(cth) fprintf(stdout, "%d %d. ", cth->pid, cth->tid);
    va_start(ap, format);
    vprintf(format, ap);

    fflush(stdout);
}


#define printf __src_info(__func__, __FILE__, __LINE__); dd_info

extern char *localhost;

extern char *Exec_timestamp(char *buf, size_t buf_size);


extern int SuprErr_set(const char *format, ...);
extern void *SuprErr_get();

extern SEXP R_FalseValue;
extern SEXP R_TrueValue;

extern supr_socket_conn_t *DFS_namenode; // for drivers
extern int SocketConn_reuseAddr;
extern int Config_getPort(const char* name);

extern SEXP DFS_DDEnv(SEXP name, SEXP addr);


static shm_io_info_t *DFS_shm_io = NULL; // local DFS shm_io 
static shm_io_info_t *get_DFS_shm_io();

extern int shm_io_destroy (shm_io_info_t *io);

// testing
void DD_fini()
{
  //Supr_decref(DFS_shm_io);
  if(DFS_shm_io) shm_io_destroy(DFS_shm_io);
  DFS_shm_io = NULL;
}

int suffix2type(const char *suffix){
  
  //basic_info("\033[0;35msubset_name: %s\033[0m\n", suffix);

  if(suffix == NULL) return FILE_SUFFIX_UNKNOWN_TYPE;

  const char *str = suffix + strlen(suffix);
  for(; str != suffix; str--)
    if(*str == '.') {
      str++;
      break;
    }
  suffix = str;

  //basic_info("\033[0;35msuffix: %s\033[0m\n", suffix);

  if(strcmp(suffix, "sro")==0){
    return FILE_SUFFIX_SUPR_OBJECT;
  } else if(strcmp(suffix, "rda")==0 || strcmp(suffix, "rdata")==0){
    return FILE_SUFFIX_R_DATA;
  } else if(strcmp(suffix, "txt")==0 || strcmp(suffix, "text")==0){
    return FILE_SUFFIX_TEXT;
  } else if(strcmp(suffix, "csv")==0){
    return FILE_SUFFIX_TEXT_CSV;
  } else if(strcmp(suffix, "tab")==0){
    return FILE_SUFFIX_TEXT_TAB;
  } else if(strcmp(suffix, "robj")==0){
    return FILE_SUFFIX_R_OBJECT;
  } else {
    return FILE_SUFFIX_UNKNOWN_TYPE;
  }
}

SEXP DD_getDefaultRFuncBySuffix(const char *suffix)
{
  switch(suffix2type(suffix)){
    case FILE_SUFFIX_R_DATA: return install("loadRData");
    case FILE_SUFFIX_TEXT:   return install("readLines");
    case FILE_SUFFIX_TEXT_CSV:   return install("read.csv");
    case FILE_SUFFIX_TEXT_TAB:   return install("read.table");
    case FILE_SUFFIX_R_OBJECT:   return install("readRDS");
    default: break;
  }
  return R_NilValue;
}

class_t *DD = NULL;

// FIXME, no thread safe
const char *DD_toString(class_t * class, void *object)
{
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(1024);

  dd_t *dd = (dd_t *) object;

  sb->size = 0;
  sb->buf[0] = 0;

  strbufPutStr(sb, "(");
  strbufPutStr(sb, class->name);
  strbufPutStr(sb, ") {name: ");
  strbufPutStr(sb, dd->name);
  strbufPutStr(sb, " ...}");
  

  return sb->buf;

}

static void DD_finalize(class_t *class, void *object)
{
  dd_t *dd = (dd_t*) object;
  printf("[%s] TODO\n", __func__);
}

static class_t *DD_class(){
  static class_t *DD = NULL;
  if(!DD) DD = newClass("DD", DD_toString, DD_finalize);
  return DD;
}

void DD_init(){

  DD_class();

  srandom((unsigned int) 1024);
}

dd_t *newDD(const char *name){
  dd_t * dd = (dd_t*) malloc(sizeof(dd_t));
  dd->class = DD_class();
  dd->ref_count = REF_COUNT_INITIALIZER;
  dd->dir_fd = -1;

  dd->name = strdup(name);
  dd->values = newHashtable(TRUE);
  dd->att = NULL;
}

void DD_destroy(dd_t *dd){

  if(dd->dir_fd != -1)
	  close(dd->dir_fd);
  free(dd->name);
  //if(dd->values->mutex)
    pthread_mutex_destroy(dd->values->mutex);
  hashtable_destroy(dd->values);
  free(dd);
//  basic_info("FIXME");
  // dd->values : destroy...
  // dd->att: free?
}


class_t *NamenodeValue_class = NULL;
const char *namenodeValueToChar(class_t *class, void *object)
{
  nn_value_t *val = (nn_value_t *) object;
  return val->class->name; // FIXME
}
void namenodeValueFinalize(class_t *class, void *object)
{
  nn_value_t *val = (nn_value_t *) object;
  // FIXME ?
  val->addr->class->finalize(val->addr->class, val->addr);
  free(val);
}

nn_value_t *newNamenodeValue()
{
  nn_value_t *val = (nn_value_t *) malloc(sizeof(nn_value_t));
  if(!NamenodeValue_class){
    NamenodeValue_class = newClass("NamenodeValue", namenodeValueToChar,
		    namenodeValueFinalize);
  }

  val->class = NamenodeValue_class;
  val->ref_count = REF_COUNT_INITIALIZER;

  val->addr = newVector(FALSE);
  return val;
}

int __mkdir__(const char *name){
  char CWD_PATH[PATH_MAX];
  size_t len;
  char *p;

  if(*name != '/'){
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(CWD_PATH + strlen(CWD_PATH), "/data/");

    len  = strlen(CWD_PATH);
    p = CWD_PATH + len;
    sprintf(CWD_PATH + len, "%s", name);
  } else {
    sprintf(CWD_PATH, "%s", name);
    p = CWD_PATH + 1;
  }

  printf("%s\n", CWD_PATH);


  len = strlen(CWD_PATH);
  if(CWD_PATH[len-1] == '/') CWD_PATH[len-1] = 0;

  struct stat sb;

  for(; *p; p++){
          //printf("%c\n", *p);
    if(*p == '/'){

      *p = 0;

      //printf("OPEN: %s\n", CWD_PATH);

      DIR *dir = opendir(CWD_PATH);

      if(!dir){
        printf("WHOOPS: %s\n", CWD_PATH);
        if(errno == ENOENT){ // create
          printf("%s\n", CWD_PATH);
          int rc =  mkdir(CWD_PATH, 0700);
          if(rc == -1){
            return -1;
          }
        } else {
            return -1;
        }
      } else {
        //printf("CLOSE: %s\n", CWD_PATH);
        closedir(dir);
      }

      *p = '/';
    }
    //printf("tmp: %s\n\n", CWD_PATH);
  }

  printf("%s\n", CWD_PATH);
  //return mkdir(CWD_PATH, 0700); //S_IRWXU
  int rc = mkdir(CWD_PATH, 0700); //S_IRWXU
  if(rc == -1)
    fprintf(stderr, "mkdir(%s), %s\n", CWD_PATH, strerror(errno));

  return rc;
}


DIR *__opendir__(const char *name)
{
  char pathname[PATH_MAX];
  getcwd(pathname, PATH_MAX);
  sprintf(pathname + strlen(pathname), "/data/%s", name);
  return opendir(pathname);
}

// rm? int remove(const char *pathname): deletes  a  name from the filesystem.  It calls unlink(2) for files, and rmdir(2) for directories.

int __rm_recursive__(const char *pathname)
{
  struct stat sb;
  int rc = stat(pathname, &sb);
  if(rc == -1) return -1;

  if(S_ISDIR(sb.st_mode)) {
    DIR *dir = opendir(pathname);
    if(!dir) return -1;

    struct dirent *dp;
    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0)
              continue;
      printf("\t[%s] d_type: %d, d_name: %s\n", __func__,
		      dp->d_type, dp->d_name);
      char buf[strlen(pathname)+strlen(dp->d_name)+2];
      sprintf(buf, "%s/%s", pathname, dp->d_name);

      switch(dp->d_type){
        case DT_DIR:
	     rc = __rm_recursive__(buf);
	     if(rc == -1) return -1;
	     break;
        case DT_REG:
	default:
	       rc = unlink(buf);
	       if(rc == -1) return -1;
	     break;
      }
    }
    closedir(dir);
    return rmdir(pathname);
  } else {
    return unlink(pathname);
  }
}

int __rmdir__(const char *name, int recursive)
{
  char pathname[PATH_MAX];
  getcwd(pathname, PATH_MAX);
  sprintf(pathname + strlen(pathname), "/data/%s", name);

  struct stat sb;
  int rc = stat(pathname, &sb);
  if(rc == -1) return -1;

  if(recursive) {
    return __rm_recursive__(pathname);
  } else if(S_ISDIR(sb.st_mode)) {
    return rmdir(pathname);
  } else {
    return unlink(pathname);
  }
}

extern size_t __socket_read__(int fd, void *buf, size_t size);

void statPrint(struct stat *sb)
{
  //printf("[%s] st_uid: %d, st_size: %ld, st_mtim: %ld\n",
  char buf[128];
  struct tm result;
  localtime_r(&sb->st_mtim.tv_sec, &result);
  asctime_r(&result, buf);
  char *s = strstr(buf, "\n");
  if(s) *s = 0;
//                asctime(localtime(&sb->st_mtim.tv_sec))
  printf("[%s] %d \t %ld \t%s", S_ISDIR(sb->st_mode)? "*": " ",
                  sb->st_uid, sb->st_size, buf
                 // asctime(localtime(&sb->st_mtim.tv_sec))
                  );
}


#define read(fd, buf, size) __socket_read__((fd), (buf), (size))

SEXP DD_create(SEXP r_name)
{
  int fd = DFS_namenode->fd;
  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_CREATE;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
  }

  return ScalarInteger(rc);
}

SEXP DD_open4(SEXP connection, SEXP r_name, SEXP r_create, SEXP dfsNamePtr);

SEXP DD_open(SEXP r_name, SEXP r_create)
{
//fprintf(stderr, "FILE: %s, LINE: %d\n", __FILE__, __LINE__); fflush(stderr);

   if(!DFS_namenode) error(_("No DFS namenode is available"));
   return DD_open4(R_NilValue, r_name, r_create,
   	R_MakeExternalPtr(&DFS_namenode, R_NilValue, R_NilValue));
}

// connection: DFSNameNode
SEXP DD_open4(SEXP connection, SEXP r_name, SEXP r_create, SEXP dfsNamePtr)
{
  int fd;
  if(TYPEOF(connection) != NILSXP){
    dfsNamePtr = getAttrib(connection, install("conn"));
    if(TYPEOF(dfsNamePtr) == NILSXP)
	    error(_("invalid DFS nodename connection"));
  } 
  supr_socket_conn_t *sc = *((supr_socket_conn_t **)
    		R_ExternalPtrAddr(dfsNamePtr));
  if(!sc) error(_("invalid DFS nodename connection"));

  fd = sc->fd;
   
  const char *name = NULL;
  if(TYPEOF(r_name) == NILSXP && TYPEOF(connection) != NILSXP){
      r_name = getAttrib(connection, install("name"));
  }
 
  if(TYPEOF(r_name) == NILSXP)
    error(_("cannot find 'name'"));
  else 
    name = CHAR(asChar(r_name));

  int cmd = DFS_DD_OPEN;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  int create = asLogical(r_create);
  write(fd, &create, INT_SIZE);

  int rc;
  ssize_t n = read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    n = read(fd, &len, SIZE_SIZE);
    char err[len];
    n = read(fd, err, len);
    error_info(err);
    errorcall(R_NilValue, "%s", err);
    
	  /*
    int nerr;
    ssize_t n = read(fd, &nerr, INT_SIZE);
    if(n == -1) error(_("%s"), strerror(errno));
    char *errors[n];
    len = 0;
    for(int i=0; i<nerr; i++){
      errors[i] = SocketConn_readString(sc, NULL, 0);
      error_info(errors[i]);
      len += strlen(errors[i]) + 1;
    }
    char strerr[len];
    strcpy(strerr, errors[0]);
    for(int i=1; i<nerr; i++)
      sprintf(strerr + strlen(strerr), "%s%s", errors[i], i==nerr-1?"":"\n");

    error_info(strerr);
    error(_("%s"), strerr);
    */
  } /* else {
   
    int nDatanodes = rc;
    SEXP levels = PROTECT(allocVector(STRSXP, nDatanodes));
    for(int i=0; i<nDatanodes; i++){
      char *s = SocketConn_readString(DFS_namenode, NULL, 0);
      SET_STRING_ELT(levels, i, mkChar(s));
      free(s);
    }

    int n;
    read(fd, &n, INT_SIZE);

    SEXP df = PROTECT(allocVector(VECSXP, 2+nDatanodes));
    setAttrib(df, install("data.nodes"), levels);

    SEXP row_names = PROTECT(allocVector(INTSXP, n));
    SEXP subsets = PROTECT(allocVector(STRSXP, n));
    SEXP   sizes = PROTECT(allocVector(INTSXP, n));

    SET_VECTOR_ELT(df, 0, subsets);
    SET_VECTOR_ELT(df, 1, sizes);
    setAttrib(df, install("row.names"), row_names);

    SEXP locations[nDatanodes];
    for(int i=0; i<nDatanodes; i++) {
      locations[i] = PROTECT(allocVector(LGLSXP, n));
      SET_VECTOR_ELT(df, 2+i, locations[i]);
    }

    for(int i=0; i<n; i++){
      char *s_name = SocketConn_readString(DFS_namenode, NULL, 0);
      SET_STRING_ELT(subsets, i, mkChar(s_name));
      free(s_name);

      dd_stat_t stat;
      read(fd, &stat, sizeof(dd_stat_t));
      INTEGER(sizes)[i] = (int) stat.st_size;

      unsigned char which[nDatanodes];
      read(fd, which, sizeof(which));
      for(int j=0; j<nDatanodes; j++) {
        LOGICAL(locations[j])[i] = which[j];
      }

      INTEGER(row_names)[i] = i+1;
    }

    SEXP names = PROTECT(allocVector(STRSXP, 2+nDatanodes));
    int k=0;
    SET_STRING_ELT(names, k, mkChar("subset"));
    SET_VECTOR_ELT(df, k++, subsets);

    SET_STRING_ELT(names, k, mkChar("size"));
    SET_VECTOR_ELT(df, k++, sizes);

    for(int j=0; j<nDatanodes; j++){
      char buf[32];
      sprintf(buf, "data.node_%d", j+1);
      SET_STRING_ELT(names, k, mkChar(buf));
      SET_VECTOR_ELT(df, k++, locations[j]);
    }
    setAttrib(df, R_ClassSymbol, mkString("data.frame"));
    setAttrib(df, R_NamesSymbol, names);
    UNPROTECT(6 + nDatanodes);
    return df;
  }
  */
  
  // return ScalarInteger(rc);
  SEXP retval;
  if(TYPEOF(connection) != NILSXP){
    r_name = PROTECT(mkString(name));
    retval = DFS_DDEnv(r_name, connection);
    UNPROTECT(1);
  } else {
    retval = PROTECT(mkString(name));
    setAttrib(retval, R_ClassSymbol, mkString("DD"));
    setAttrib(retval, install("conn"), dfsNamePtr);
    UNPROTECT(1);
  }
  return retval;
}

extern so_t *SO_valueOf(SEXP r_object, size_t *length);

extern supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);
extern supr_socket_conn_t *serverSocketAccept(supr_socket_conn_t *serverConn);

void ftp_handleCommand(supr_socket_conn_t *conn, vector_t *socket_connections)
{
  size_t len = 0;
  int cmd;
  ssize_t n = recv(conn->fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
  if(n <= 0 ){
//        printf("\033[0;31m%d::recv [%s] conn(fd: %d) is disconnected " "(len=%ld)\033[0m\n\n", getpid(), __func__, conn->fd, len);
        int type = conn->type;
        //close(conn->fd);

        vectorRemoveElement(socket_connections, conn);
	SocketConn_destroy(conn);

        return;
  }
 
  read(conn->fd, &cmd, INT_SIZE);
  switch(cmd){
    case DFS_DD_GET:
	 {
           char *query = SocketConn_readString(conn, NULL, 0);
           //printf("[%s] GET: query = %s\n", __func__, query);
	   {
             int fd = open(query, O_RDONLY);
	     if(fd==-1){
	       //write(conn->fd, &fd, INT_SIZE);
	       //SocketConn_writeString(conn, strerror(errno));
	       char *err =  strerror(errno);
	       so_t so = { 0, 0, 0, SUPR_ERROR, strlen(err)+1};
	       write(conn->fd, &so, sizeof(so_t));
	       write(conn->fd, err, strlen(err)+1);
	     } else {
	       struct stat sb;
	       int rc = fstat(fd, &sb); //write(conn->fd, &rc, INT_SIZE);
	       if(rc==-1){
	         char *err =  strerror(errno);
	         so_t so = { 0, 0, 0, SUPR_ERROR, strlen(err)+1};
	         write(conn->fd, &so, sizeof(so_t));
	         write(conn->fd, err, strlen(err)+1);
	         //SocketConn_writeString(conn, strerror(errno));
	       } else {
	         void *ptr = malloc(sb.st_size);
		 read(fd, ptr, sb.st_size);
		 so_t so = {0, SUPR_MEMTYPE_FILE, 0, SUPR_FILE, sb.st_size};
		 write(conn->fd, &so, sizeof(so_t));
		 write(conn->fd, ptr, sb.st_size);
		 free(ptr);
	       }
	     }
	   }
	   free(query);
	 }
	 break;
    default: printf("[%s] Unknown command %d\n", __func__, cmd);
	     break;
  }
}

void ftp_cleanup(void *arg)
{
  printf("\033[0;31m\n[%s] arg: %p\n", __func__, arg);
  vector_t *socket_connections = (vector_t *) arg;
  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorRemove(socket_connections, i);
    SocketConn_destroy(sc);
  }
  vectorDestroy(socket_connections);
}

// TODO: Use nTaskrunners...
void ftp_run(int nTaskrunners)
{
  supr_thread_t *cth = currentThread();
  supr_socket_conn_t *serverConn = (supr_socket_conn_t *) cth->data;
  vector_t *socket_connections = newVector(FALSE);
  vectorAdd(socket_connections, serverConn);

  //printf("\033[0;32m[%s] serverConn: //%s:%d\033[0m\n",  __func__, serverConn->host, serverConn->port);

  pthread_cleanup_push(ftp_cleanup, socket_connections);

  while(TRUE){
      struct timeval tv;
      tv.tv_sec=5000;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      int max_fd = 0; //printf("\n");
      for(int i=0; i<vectorSize(socket_connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i);
        //conn->print(conn);
        int fd = conn->fd;
        FD_SET(fd, &readfds);
        if(fd > max_fd) max_fd = fd;
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      } 

      int rc = pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);

      for(int i = vectorSize(socket_connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i);
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
                continue;

	if(conn == serverConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(serverConn);
          printf("\033[0;33m[INFO] ftp client connection: %s\033[0m\n",
			  clientConn->host);

          if(clientConn && clientConn->fd != -1){
            vectorAdd(socket_connections, clientConn);
          }
        } else {
          ftp_handleCommand(conn, socket_connections);
        }
      }

      rc = pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
  }
 
  pthread_cleanup_pop(TRUE);
}

void *ftp_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  supr_socket_conn_t *nn_conn = (supr_socket_conn_t *) ((void **)arg)[3];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  int nTaskrunners = ((int*) data)[0];

  int port = 0;
  int nports = 1;

#define FTP_FIXME
#ifdef  FTP_FIXME
  char *addr = Config_getAddr("Filetransfer");
  basic_info("Filetransfer: %s", addr);
  if(!addr) addr = "";
  if(strstr(addr, "+")) nports = 0;
  char *s = strstr(addr, ":");
  if(!s) {
    port = 1024;
    nports = 0;
  } else {
    port = atoi(s+1);
  }
  free(addr);
#else
  {
    port = Config_getPort("Filetransfer");
  }
#endif

#ifdef  FTP_FIXME
  int reuse_addr = SocketConn_reuseAddr;
  if(port == 0 && nn_conn) {
    port = nn_conn->port + 1;
    reuse_addr = FALSE;
  }
#else
  if(port == 0 && nn_conn) 
	  port = nn_conn->port;


  int reuse_addr = SocketConn_reuseAddr;
#endif


#ifdef  FTP_FIXME
  supr_socket_conn_t *serverConn = serverSocketOpen3(port, nports, proc_cmd);
#else

  printf("\033[0;31m[%s] port: %d, reuse_addr: %d\033[0m\n", __func__,
	 port, reuse_addr);

  supr_socket_conn_t *serverConn = serverSocketOpen(port, reuse_addr);
#endif

  basic_info("Filetransfer: //%s:%d\n", serverConn->host, serverConn->port);
  th->data = serverConn;

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  ftp_run(nTaskrunners);

  pthread_exit(th); // FIXME
  return NULL;
}

// use nn_conn->port as a hint?
supr_thread_t *startFTPServer(int nTaskrunners, supr_socket_conn_t *nn_conn)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&nTaskrunners, &sem, &sth, nn_conn};
  int rc = pthread_create(&thread, NULL, ftp_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  //printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

SEXP DD_put(SEXP r_name, SEXP subsets, SEXP subset_names)
{
  if(TYPEOF(subset_names)!=NILSXP && TYPEOF(subset_names)!=STRSXP)
    error(_("argument 'subset.names' must be NULL or a character object"));

  if(TYPEOF(subsets) == STRSXP){ // files
    if(TYPEOF(subset_names)!=NILSXP && LENGTH(subset_names)!=LENGTH(subsets))
      error(_("'subsets' and 'subset.names' have different lengths"));
  } else if(TYPEOF(subsets) == VECSXP){// R objects
    if(TYPEOF(subset_names)!=NILSXP && LENGTH(subset_names)!=LENGTH(subsets))
      error(_("'subsets' and 'subset.names' have different lengths"));
  } else {
    errorcall(R_NilValue, "not implemented for %s objects",
		    type2char(TYPEOF(subsets)));
  }

  int fd = DFS_namenode->fd;
  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_PUT;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  //{
    int nDatanodes;
    read(fd, &nDatanodes, INT_SIZE);
    if(nDatanodes == -1){
      char err[256];
      SocketConn_readString(DFS_namenode, err, sizeof(err));
      errorcall(R_NilValue, "%s", err);
    }
    if(!nDatanodes)
      errorcall(R_NilValue, "No datanodes available");
  //}

  supr_socket_conn_t *ftp_conn = NULL;
  supr_thread_t *ftp_th = NULL;

  if(TYPEOF(subsets) == STRSXP){ // interpreted as URIs
    int n = LENGTH(subsets);
    //printf("[%s] LENGTH: %d XLENGTH: %ld\n", __func__, n, XLENGTH(subsets)); 

    for(int i=0; i<n; i++){
      size_t size;
      const char *uri = CHAR(STRING_ELT(subsets, i));
      so_t *s;
      if(strstr(uri, "//")) { // interpreted as a local file name
	size = sizeof(so_t)+ strlen(uri)+1;
        s = (so_t *)malloc(size);
	so_t so = {0, 0, 0, SUPR_URI, strlen(uri)+1};
	memcpy(s, &so, sizeof(so));
	memcpy(s+1, uri, so.size);
      } else { // start a ftp server...

	if(!ftp_conn){
          int nThreads = 4;
          ftp_th = startFTPServer(nThreads, DFS_namenode);
          ftp_conn = (supr_socket_conn_t *)ftp_th->data;
	  if(!ftp_conn)
		  errorcall(R_NilValue, "%s", strerror(errno));
	}

        char buf[256]; // FIXME
	//sprintf(buf, "ftp://%s:%d#", ftp_conn->host, ftp_conn->port);
	sprintf(buf, "//%s:%d#", ftp_conn->host, ftp_conn->port);
	char pathname[PATH_MAX];
	if(*uri == '/'){
	  memcpy(pathname, uri, strlen(uri)+1);
	} else if(*uri == '~'){
	  sprintf(pathname, "%s/%s", getenv("HOME"), uri+1);
	} else {
	  getcwd(pathname, PATH_MAX);
	  sprintf(pathname + strlen(pathname), "/%s", uri);
	}

	printf("\033[0;33m[INFO] DD.put: %s%s\033[0m\n", buf, pathname);

	size = sizeof(so_t) + strlen(buf)+strlen(pathname)+1;
        s = (so_t *)malloc(size);
	so_t so = {0, 0, 0, SUPR_URI, strlen(buf)+strlen(pathname)+1};
	memcpy(s, &so, sizeof(so));
	sprintf((char*)(s+1), "%s%s",buf, pathname);

      }

      char *s_name;
      char buf[256];
      if(TYPEOF(subset_names) == NILSXP){
        s_name = buf;
        const char *suffix = uri+strlen(uri);
	for(; suffix != uri; suffix--)
           if(*suffix == '.') break;
	
	if(suffix == uri) suffix = "";

	sprintf(buf, "part_%06d%s", i, suffix);
      } else {
        s_name = (char*) CHAR(STRING_ELT(subset_names, i));
      }
      len = strlen(s_name)+1;
      write(fd, &len, SIZE_SIZE);
      write(fd, s_name,  len);
      write(fd, s,  size);

      ////
      { // prevent SIGPIPE...
	int rc;
        read(fd, &rc, INT_SIZE); // printf("[%s] rc: %d\n", __func__, rc);
      }
      ////
      free(s);
    }
    len = 0;
    write(fd, &len, SIZE_SIZE);

  } else if(TYPEOF(subsets) == VECSXP){
    int n = LENGTH(subsets);

    //printf("[%s] LENGTH: %d XLENGTH: %ld\n", __func__, n, XLENGTH(subsets)); 
    for(int i=0; i<n; i++){
      size_t size;
      so_t *s = SO_valueOf(VECTOR_ELT(subsets, i), &size);

      //basic_info("s->obj_type: %d, s->size: %ld", s->obj_type, s->size);

      char *s_name;
      char buf[256];
      if(TYPEOF(subset_names) == NILSXP){
	//sprintf(buf, "part_%06d.sro", i); // use the format for .sro as the default
	sprintf(buf, "part_%06d.sro", i);
        s_name = buf;
      } else {
        s_name = (char*) CHAR(STRING_ELT(subset_names, i));
	int n = strlen(s_name)>sizeof(buf)? sizeof(buf) : strlen(s_name)+1;
	strncpy(buf, s_name, n);
	buf[sizeof(buf)-1-strlen(".sro")] = '\0';
	strcpy(buf+strlen(buf), ".sro");
        s_name = buf;
      }
      len = strlen(s_name)+1;
      write(fd, &len, SIZE_SIZE);
      write(fd, s_name,  len);
      write(fd, s,  size);
     
      ////
      { // prevent SIGPIPE...
	int rc;
        read(fd, &rc, INT_SIZE); // printf("[%s] rc: %d\n", __func__, rc);
      }
      ////
      free(s);
    }
    len = 0;
    write(fd, &len, SIZE_SIZE);

  } else {
    errorcall(R_NilValue, "not implemented for %s objects",
		    type2char(TYPEOF(subsets)));
  }

  int rc;
  read(fd, &rc, INT_SIZE);

  if(ftp_th){
    pthread_cancel(ftp_th->ptid); // testing?
    void *retval;
    pthread_join(ftp_th->ptid, &retval);
    if(retval == PTHREAD_CANCELED){
      printf("\033[0;32m[%s] PTHREAD_CANCELED\033[0m\n\n", __func__);
    } else 
      printf("\033[0;31m[%s] retval: %p\033[0m\n\n", __func__, retval);
    Thread_destroy(ftp_th);
  }

  if(rc == -1) {
	  /*
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    */
    int n;
    read(fd, &n, INT_SIZE);

    strbuf_t *sb = newStrbuf(1024);
    for(int i=0; i<n; i++){
      read(fd, &len, SIZE_SIZE);
      char err[len];
      read(fd, err, len);
      //printf("[%s] Error: %s\n", __func__, err);
      strbufPutStr(sb, err);
      strbufPutStr(sb, "\n");
    }

    //printf("[%s] Error: \n%s\n", __func__, sb->buf);

    //char buf[sb->size+1];
    //memcpy(buf, sb->buf, sb->size+1);

    SEXP r_err = mkString(sb->buf);
    sb->class->finalize(sb->class, sb);

    //errorcall(R_NilValue, "%s", buf);
    errorcall(R_NilValue, "%s", CHAR(STRING_ELT(r_err,0)));
  }

  return ScalarInteger(rc);
}


/*
SEXP DD_update(SEXP r_name)
{
  int fd = DFS_namenode->fd;
  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_UPDATE;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
  }

  return ScalarInteger(rc);
}
*/

size_t SocketConn_writeString(supr_socket_conn_t* sc, const char *str)
{
  size_t len = strlen(str)+1;
  write(sc->fd, &len, SIZE_SIZE);
  write(sc->fd, str, len);
  /*
  {
    int rc;
    read(sc->fd, &rc, sizeof(int));
  }
  */
  return len;
}

char *SocketConn_readString(supr_socket_conn_t* sc, char *buf, size_t buf_size)
{
  size_t len;
  ssize_t size = read(sc->fd, &len, SIZE_SIZE);
  if(size == -1) {
    SuprErr_set("%s, %s", __func__, strerror(errno));
    return NULL;
  }

  if(len > buf_size) buf = (char*) malloc(len);
  size = read(sc->fd, buf, len);
  if(size == -1) {
    SuprErr_set("%s, %s", __func__, strerror(errno));
    return NULL;
  }

  /*
  {
    int rc = 0;
    write(sc->fd, &rc, sizeof(int));
  }
  */

  return buf;
}

size_t SocketConn_writeInt(supr_socket_conn_t* sc, int val)
{
  write(sc->fd, &val, INT_SIZE);
  return INT_SIZE;
}



size_t SocketConn_writeSO(supr_socket_conn_t *sc, so_t *so)
{
  size_t size = sizeof(so_t) + so->size; 
  write(sc->fd, &size, SIZE_SIZE);
  write(sc->fd, so, size);
  return size;
}

so_t *SocketConn_readSO(supr_socket_conn_t *sc)
{
  size_t size;
  read(sc->fd, &size, SIZE_SIZE);
  so_t *so = (so_t *) malloc(size);
  read(sc->fd, so, size);
  return so;
}

// FIXME
SEXP SocketConn_readRObject(supr_socket_conn_t *sc)
{
  size_t size;
  read(sc->fd, &size, SIZE_SIZE);
  so_t *so = (so_t *) malloc(size);
  read(sc->fd, so, size);
  SEXP val = SO_toRObject(so, size);
  free(so);
  return val;
}

/*
SEXP DD_readDDInfo(int fd)
{
  size_t len;

#define DD_LIST_DD_INFO  1
  //
  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
  } else if(rc == DD_LIST_DD_INFO) {
#define LIST_DATANODE_INFO
#ifdef  LIST_DATANODE_INFO
    int nDatanodes;
    read(fd, &nDatanodes, INT_SIZE);
    SEXP levels = PROTECT(allocVector(STRSXP, nDatanodes));
    for(int i=0; i<nDatanodes; i++){
      char *s = SocketConn_readString(DFS_namenode, NULL, 0);
      SET_STRING_ELT(levels, i, mkChar(s));
      free(s);
    }

    printf("[%s] rc: %d, nDatanodes: %d\n", __func__, rc, nDatanodes);

    int n;
    read(fd, &n, INT_SIZE);

    SEXP names = PROTECT(allocVector(STRSXP, n));
    SEXP times = PROTECT(allocVector(STRSXP, n));
    SEXP sizes = PROTECT(allocVector(INTSXP, n)); // SIZE_SIZE??/ FIXME

    SEXP is_dir = PROTECT(allocVector(INTSXP, n));
    SEXP replicates = PROTECT(allocVector(INTSXP, n));

    SEXP locations[nDatanodes];
    for(int i=0; i<nDatanodes; i++) {
      locations[i] = PROTECT(allocVector(INTSXP, n));
      //SET_VECTOR_ELT(df, 2+i, locations[i]);
    }

    for(int i=0; i<n; i++){
      char *s_name = SocketConn_readString(DFS_namenode, NULL, 0);
      SET_STRING_ELT(names, i, mkChar(s_name));
      free(s_name);

      dd_stat_t sb;
      read(fd, &sb, sizeof(dd_stat_t));
      {
        char buf[128];
        struct tm result;
        localtime_r(&sb.st_mtim.tv_sec, &result);
        asctime_r(&result, buf);
        char *s = strstr(buf, "\n");
        if(s) *s = 0;
        SET_STRING_ELT(times, i, mkChar(buf));
      }
      INTEGER(is_dir)[i] = S_ISDIR(sb.st_mode);
      //statPrint(&sb); printf(" \t%s\n", s_name);

      INTEGER(sizes)[i] = (int) sb.st_size;

      unsigned char which[nDatanodes];
      read(fd, which, sizeof(which));
      int nrep = 0;
      for(int j=0; j<nDatanodes; j++) {
        INTEGER(locations[j])[i] = which[j];
	nrep +=  which[j];
      }
      INTEGER(replicates)[i] = nrep;

    }
    SEXP val = PROTECT(allocVector(VECSXP, 3 + nDatanodes + 2));
    int k = 0;
    SET_VECTOR_ELT(val, k++, names);
    SET_VECTOR_ELT(val, k++, is_dir);
    SET_VECTOR_ELT(val, k++, sizes);
    SET_VECTOR_ELT(val, k++, times);
    for(int i=0; i<nDatanodes; i++)
      SET_VECTOR_ELT(val, k++, locations[i]);
    SET_VECTOR_ELT(val, k++, replicates);

    names = PROTECT(allocVector(STRSXP, 3+nDatanodes + 2));
    k = 0;
    SET_STRING_ELT(names, k++, mkChar("subset"));
    SET_STRING_ELT(names, k++, mkChar("dir"));
    SET_STRING_ELT(names, k++, mkChar("size"));
    SET_STRING_ELT(names, k++, mkChar("time"));
    for(int i=0; i<nDatanodes; i++) {
      char buf[64];
      sprintf(buf, "dn.%d", i+1);
      SET_STRING_ELT(names, k++, mkChar(buf));
    }
    SET_STRING_ELT(names, k++, mkChar("nrep"));

    setAttrib(val, R_NamesSymbol, names);
    setAttrib(val, R_ClassSymbol, mkString("data.frame"));
    names = PROTECT(allocVector(INTSXP, n));
    for(int i=0; i<n; i++) INTEGER(names)[i] = i + 1;
    setAttrib(val, install("row.names"), names);
    setAttrib(val, install("data.nodes"), levels);
    UNPROTECT(9+nDatanodes);
    return val;
#else
    int n;
    read(fd, &n, INT_SIZE);
    SEXP names = PROTECT(allocVector(STRSXP, n));
    SEXP times = PROTECT(allocVector(STRSXP, n));
    SEXP sizes = PROTECT(allocVector(INTSXP, n)); // SIZE_SIZE??/ FIXME
    for(int i=0; i<n; i++){
      char *s_name = SocketConn_readString(DFS_namenode, NULL, 0);
      SET_STRING_ELT(names, i, mkChar(s_name));
      dd_stat_t sb;
      read(fd, &sb, sizeof(dd_stat_t));
      {
        char buf[128];
        struct tm result;
        localtime_r(&sb.st_mtim.tv_sec, &result);
        asctime_r(&result, buf);
        char *s = strstr(buf, "\n");
        if(s) *s = 0;
        SET_STRING_ELT(times, i, mkChar(buf));
      }
      //statPrint(&sb); printf(" \t%s\n", s_name);
      free(s_name);

      INTEGER(sizes)[i] = (int) sb.st_size;
    }
    SEXP val = PROTECT(allocVector(VECSXP, 3));
    SET_VECTOR_ELT(val, 0, names);
    SET_VECTOR_ELT(val, 1, sizes);
    SET_VECTOR_ELT(val, 2, times);
    names = PROTECT(allocVector(STRSXP, 3));
    SET_STRING_ELT(names, 0, mkChar("subset"));
    SET_STRING_ELT(names, 1, mkChar("size"));
    SET_STRING_ELT(names, 2, mkChar("time"));
    setAttrib(val, R_NamesSymbol, names);
    setAttrib(val, R_ClassSymbol, mkString("data.frame"));
    names = PROTECT(allocVector(INTSXP, n));
    for(int i=0; i<n; i++) INTEGER(names)[i] = i + 1;
    setAttrib(val, install("row.names"), names);
    UNPROTECT(6);
    return val;
#endif
#undef LIST_DATANODE_INFO
  }

  struct stat sb;
  read(fd, &sb.st_mode, sizeof(mode_t));


  if(S_ISDIR(sb.st_mode)){

    read(fd, &rc, INT_SIZE);

    if(rc == -1){
      read(fd, &len, SIZE_SIZE);
      char err[len];
      read(fd, err, len);
      errorcall(R_NilValue, "%s", err);
    }

    //struct dirent *dp;
    while(TRUE){

      read(fd, &len, SIZE_SIZE);
      if(len == 0) break;

      char d_name[len];
      read(fd, d_name, len);

      read(fd, &rc, INT_SIZE);

      if(rc == -1){
        read(fd, &len, SIZE_SIZE);
        char err[len];
        read(fd, err, len);
        //errorcall(R_NilValue, "%s: %s", d_name, err);
        printf("%s: %s\n", d_name, err);
      } else {
        read(fd, &sb, sizeof(struct stat));
        statPrint(&sb);
      }
      printf(" \t%s\n", d_name);
    }

  } else {
    read(fd, &sb, sizeof(struct stat));
    statPrint(&sb);
  }


  return R_NilValue;

#undef DD_LIST_DD_INFO 
}
*/



// for debugging ...
static struct sigaction R_oldIntAct;
static pthread_t interrupt_thread = 0;
static void (*interrupt_run)(void *) = NULL;
static void *interrupt_data = NULL;

void  DD_interrupt_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  if(!pthread_equal(pthread_self(), interrupt_thread)) {
	  pthread_kill(interrupt_thread, SIGINT);
	  return;
  }

  if(interrupt_run){
    interrupt_run(interrupt_data);
  }
  printf("[%s] MORE TO DO?\n", __func__);

  sigaction(SIGINT, &R_oldIntAct, NULL);
}

static void DD_interrupt_enable(pthread_t thread)
{
  printf("\n\033[0;32m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);
    struct sigaction sa;
    sa.sa_sigaction = DD_interrupt_SigactionSIGINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldIntAct);

    interrupt_thread = thread;
}

static void DD_interrupt_disable(pthread_t thread)
{
  printf("\n\033[0;32m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);
  sigaction(SIGINT, &R_oldIntAct, NULL);
}

static void DD_interrupt_cend(void *data)
{
  printf("\033[0;34m[%s] is called\033[0m\n", __func__);
  DD_interrupt_disable(pthread_self());
}

static void interrupt_socketConn(void *data)
{
  supr_socket_conn_t *sc = (supr_socket_conn_t *) data;
  printf("[%s] connecting: //%s:%d ...\n", __func__, sc->host, sc->port);
  int fd = socket_client(sc->host, sc->port);
  printf("[%s] connected to: //%s:%d, fd: %d\n", __func__, sc->host,
		  sc->port, fd);
  int cmd = SUPR_INTERRUPT;
  write(fd, &cmd, INT_SIZE);

  int rc;
  read(fd, &rc, INT_SIZE);
  printf("[%s] rc: %d\n", __func__, rc);
  close(fd);
}

static shm_io_info_t *get_DFS_shm_io()
{
  int fd = DFS_namenode->fd;
  int cmd = DFS_DD_GET_LOCAL_DATANODE_PID;
  write(fd, &cmd, INT_SIZE);
  int pid;
  read(fd, &pid, INT_SIZE);
  if(pid == -1) return NULL;

  printf("[%s] pid: %d\n", __func__, pid);

  char shm_name[256];
  sprintf(shm_name, "sdfs.%d.%d", geteuid(), pid);
  DFS_shm_io = shm_io_open(shm_name);
  return DFS_shm_io;
}

// for simple operations...
SEXP DD_operation(SEXP r_op, SEXP r_name, SEXP args)
{
  ////
  DD_interrupt_enable(pthread_self());
  interrupt_run = interrupt_socketConn;
  interrupt_data = DFS_namenode;

  RCNTXT cntxt;
  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);
  cntxt.cend = DD_interrupt_cend;
  cntxt.cenddata = NULL;
  ////

  if(!DFS_namenode)
    error("DFS namenode is not available");

//  basic_info("DFS_namenode: %s:%d:%d", DFS_namenode->host, DFS_namenode->port, DFS_namenode->fd);


  int fd = DFS_namenode->fd;
  const char *name = CHAR(asChar(r_name));

  const char *op = CHAR(asChar(r_op));
  verbose_info("%s(op=%s,...)", __func__, op);
  int cmd = DFS_DD_LIST;
  if(strcmp(op, "persist")==0){
    cmd = DFS_DD_PERSIST;
  } else if(strcmp(op, "info")==0){
    cmd = DFS_DD_INFO;
  } else if(strcmp(op, "exists")==0){
    cmd = DFS_DD_EXISTS;
  } else if(strcmp(op, "move")==0){
    cmd = DFS_DD_MOVE;
  } else if(strcmp(op, "rm")==0){
    cmd = DFS_DD_REMOVE;
  } else if(strcmp(op, "options")==0){
    cmd = DFS_DD_OPTION;
  } else if(strcmp(op, "start.workers")==0){
    cmd = DFS_START_WORKERS; // todo
  //} else if(strcmp(op, "update")==0){ cmd = DFS_DD_UPDATE;
  } else {
    errorcall(R_NilValue, "Unknown DD operation '%s'", op);
  } // TODO

  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);
  
  //printf("[%s] name: %s\n", __func__, name);

  if(cmd == DFS_DD_OPTION || cmd == DFS_DD_INFO){
    size_t size; //printf("[%s] writeSO\n", __func__);
    SocketConn_writeSO(DFS_namenode, SO_valueOf(args, &size));
    //printf("[%s] wroteSO\n", __func__);
  } else if (cmd == DFS_DD_REMOVE){
    int recursive = asLogical(CAR(args));
    //printf("[%s] recursive: %d\n", __func__, recursive);
    write(fd, &recursive, INT_SIZE);
  } else if (cmd == DFS_DD_MOVE){
    char *src = NULL;
    char *dest = NULL;
    while(TYPEOF(args) != NILSXP){
      if(TYPEOF(TAG(args)) == SYMSXP){
        const char *tag = CHAR(PRINTNAME(TAG(args)));
        if(strcmp(tag, "src")==0){
          src = strdup(CHAR(STRING_ELT(CAR(args),0)));
        } else if(strcmp(tag, "dest")==0) {
          dest = strdup(CHAR(STRING_ELT(CAR(args),0)));
        }
      }
      args = CDR(args);
    }
    //printf("[%s] src: %s\n", __func__, src);
    //printf("[%s] dest: %s\n", __func__, dest);
    size_t size = SocketConn_writeString(DFS_namenode, src);
    //printf("[%s] size: %ld\n", __func__, size);
    size = SocketConn_writeString(DFS_namenode, dest);
    //printf("[%s] size: %ld\n", __func__, size);

  } else if(cmd == DFS_DD_PERSIST){
    while(TYPEOF(args) != NILSXP){ // required for persist operation
      const char *tag = CHAR(PRINTNAME(TAG(args)));
      //printf("[%s] rag: %s\n", __func__, tag);
      SEXP val = CAR(args);

      if(TYPEOF(val) == INTSXP && LENGTH(val)){ // TODO...
        write(fd, INTEGER(val), INT_SIZE);
      }

      args = CDR(args);
    }
  } else {
  }

//  if(cmd == DFS_DD_UPDATE) return DD_readDDInfo(fd);
  

  SEXP ret = R_NilValue;
  int rc;
  //read(fd, &rc, INT_SIZE);
  ssize_t size = timed_read(fd, &rc, INT_SIZE);
  if(size == -1){
    error(_("%s"), strerror(errno));
  }

  //printf("[%s] rc = %d\n", __func__, rc);
  if(rc == -1) {
    if(cmd == DFS_DD_REMOVE || cmd == DFS_DD_MOVE ||
		    cmd == DFS_DD_PERSIST){
      int n;
      read(fd, &n, INT_SIZE);
      if(n>1){
        for(int i=0; i<n; i++){
          char *err = SocketConn_readString(DFS_namenode, NULL, 0); 
	  fprintf(stderr, "[%s] Error: %s\n", __func__, err);
	  free(err);
        }
        errorcall(R_NilValue, "%d errors", n);
      } else {
        char *err = SocketConn_readString(DFS_namenode, NULL, 0); 
	char buf[strlen(err)+1];
	memcpy(buf, err, strlen(err)+1);
	free(err);
        errorcall(R_NilValue, "%s", buf);
      }
    } else {
      read(fd, &len, SIZE_SIZE);
      //printf("[%s] len = %ld\n", __func__, len);
      char err[len];
      read(fd, err, len);
      errorcall(R_NilValue, "%s", err);
    }
  } else if (cmd == DFS_DD_OPTION || cmd == DFS_DD_INFO) {
	  printf("[%s] Return\n", __func__);
    ret = SocketConn_readRObject(DFS_namenode);
  } else if (cmd == DFS_DD_EXISTS) {
    ret = rc ? R_TrueValue : R_FalseValue;
  } else {
    ret = ScalarInteger(rc);
  }

  ////
  endcontext(&cntxt);
  DD_interrupt_disable(pthread_self());
  ////


  return ret;
}

SEXP DD_replicate(SEXP r_name)
{
  int fd = DFS_namenode->fd;
  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_REPLICATE;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    int nerr;
    read(fd, &nerr, INT_SIZE);
    if(nerr == 1){
      read(fd, &len, SIZE_SIZE);
      char err[len];
      read(fd, err, len);
      errorcall(R_NilValue, "%s", err);
    } else {
      for(int i=0; i<nerr; i++){
        read(fd, &len, SIZE_SIZE);
        char err[len];
        read(fd, err, len);
	printf("Error: %s\n", err);
      }
      errorcall(R_NilValue, "%d errors", nerr);
    }
  }

  return ScalarInteger(rc);
}

// move it to DD_operation(...)??
SEXP DD_close3(SEXP connection, SEXP r_name, SEXP dfsNamePtr);

SEXP DD_close(SEXP r_name){
  if(!DFS_namenode)
    error(_("no DFS namenode is available"));
  return DD_close3(R_NilValue, r_name,
  	R_MakeExternalPtr(&DFS_namenode, R_NilValue, R_NilValue));
}
SEXP DD_close3(SEXP connection, SEXP r_name, SEXP dfsNamePtr)
{
  int fd;
  if(TYPEOF(connection) != NILSXP){
    dfsNamePtr = getAttrib(connection, install("conn"));
    if(TYPEOF(dfsNamePtr) == NILSXP)
	    error(_("invalid DFS nodename connection"));
  }
  supr_socket_conn_t *sc = *((supr_socket_conn_t **)
   	 R_ExternalPtrAddr(dfsNamePtr));
  if(!sc) error(_("invalid DFS nodename connection"));

  fd = sc->fd;

  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_CLOSE;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

//  int _save = asLogical(save); write(fd, &_save, INT_SIZE);

  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
	  /*
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
    */
      int n;
      read(fd, &n, INT_SIZE);
      if(n>1){
        for(int i=0; i<n; i++){
          char *err = SocketConn_readString(DFS_namenode, NULL, 0);
          printf("[%s] Error: %s\n", __func__, err);
          free(err);
        }
        errorcall(R_NilValue, "%d errors", n);
      } else {
        char *err = SocketConn_readString(DFS_namenode, NULL, 0);
        char buf[strlen(err)+1];
        memcpy(buf, err, strlen(err)+1);
        free(err);
        errorcall(R_NilValue, "%s", buf);
      }

  }

  return ScalarInteger(rc);
}

void  DD_stat_print(dd_stat_t *stat)
{ // TODO
  char buf[128];
  static char stdstr[256]; // FIXME
  struct tm result;
  localtime_r(&stat->st_mtim.tv_sec, &result);
  asctime_r(&result, buf);
  char *s = strstr(buf, "\n");
  if(s) *s = 0;
  printf("st_dev: %ld st_size: %ld time: %s\n",
		  stat->st_dev, stat->st_size, buf
		  );
  sprintf(stdstr, "st_dev: %ld st_size: %ld time: %s\n",
		  stat->st_dev, stat->st_size, buf);
}

int supr_errno = 0;
char *supr_strerrors[] = {
	"Success",
	"Invalid URI",
};

#define INVALID_URI 1

const char *supr_strerror(int err_no)
{
  return supr_strerrors[err_no];
}

// FIXME
#define SocketConn_read(fd, buf, size) __dd_read__(fd, buf, size)
size_t __dd_read__(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }
    }

    ssize_t n = read(fd, buf + len,  size - len);

    if(n <= 0){
            printf("[%s] read, n = %ld, %s\n", __func__, n, strerror(errno));
            return -1;
    } /* else if (n < size - len){
            printf("[%s] Warning: read, n = %d, %s\n", __func__, n, strerror(errno));
    }
    */

    /*  n = -1: If no messages are available at the socket, the receive calls wait  for
       a  message  to arrive, unless the socket is nonblocking (see fcntl(2)),
       in which case the value -1 is returned and the external variable  errno
       is set to EAGAIN or EWOULDBLOCK.  The receive calls normally return any
       data available, up to the requested amount,  rather  than  waiting  for
       receipt of the full amount requested.
       */

    len += n;
  }
}

void SO_print(so_t* s)
{
  printf("ref_count: %d, mem_type: %d, sys_type: %d, obj_type: %d, size: %ld\n",
	  s->ref_count, s->mem_type, s->sys_type, s->obj_type, s->size);
  // TODO...
}

so_t *SO_getLocalDDSubset(const char *dd_name, const char *subset_name,
		const char *query, SEXP func, SEXP env)
{

  verbose_info(subset_name);

  shm_io_info_t *io = DFS_shm_io ? DFS_shm_io : get_DFS_shm_io();
  if(!io) return NULL;

//  printf("(local) DFS_shm_io: %p\n", DFS_shm_io);

  const char *q = query ? query : "";
  if(query){
  } else {
    char buf[INT_SIZE+strlen(dd_name)+strlen(subset_name)+2];
    sprintf(buf+INT_SIZE, "%s/%s", dd_name, subset_name);
    *((int*)buf) = DFS_DD_GET;
    shm_io_write(io, io->out, buf, sizeof(buf));
    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);

    if(*((int*)ptr)==-1) {//errorcall(R_NilValue, "%s", (char*)(ptr+INT_SIZE));
//	printf("\033[0;32m[Warning] %s: %s\033[0m\n", __func__, (char*)(ptr+INT_SIZE));
	return NULL;
    }

    so_t* so = (so_t*) ptr;
    so->ref_count = 1;

    //fprintf(stderr, "[%s] %s {%d, mem: %d (SUPR_MEMTYPE_FILE=%d), %d, %d, sz: %ld}\n", __func__, subset_name, so->ref_count, so->mem_type, SUPR_MEMTYPE_FILE, so->sys_type, so->obj_type, so->size);

    int tmp_fd = -1;

    if(so->mem_type == SUPR_MEMTYPE_MEM){
       if(so->obj_type != SUPR_FILE)
	       return so;

       char template[256];
       const char *suffix = subset_name + strlen(subset_name);
       for(; suffix != subset_name; suffix--)
	       if(*suffix == '.') {
		       suffix++;
		       break;
	       }
       sprintf(template, "/tmp/sdfs-XXXXXX.%s", suffix);
       tmp_fd = mkstemps(template, strlen(suffix)+1);
       if(tmp_fd == -1) {
         errorcall(R_NilValue, "%s", strerror(errno));
       }
       write(tmp_fd, so->val, so->size);
       so_t *s = so;
       so = (so_t*) malloc(sizeof(so_t)+strlen(template)+1);
       memcpy(so, s, sizeof(so_t));
       free(s);
       so->size = strlen(template)+1;
       memcpy(so->val, template, so->size);
       so->mem_type = SUPR_MEMTYPE_TMP;
    }

    switch(so->mem_type){
      
	    /*
      case SUPR_MEMTYPE_MEM: //so->ref_count = INT_MAX;
	   if(so->obj_type == SUPR_FILE){
	   } else return so;
	   */
      case SUPR_MEMTYPE_SHM:
	   {
             so_t *s = so;
	     char *shm_name = (char*) s->val;
	     so = (so_t*) malloc(sizeof(so_t)+ strlen(shm_name)
			     + strlen("/dev/shm/")+1);
	     memcpy(so, s, sizeof(so_t));
	     so->size = strlen(shm_name) + strlen("/dev/shm/")+1;
	     sprintf((char*)so->val, "/dev/shm/%s", shm_name);
	     free(s);
	   }
      case SUPR_MEMTYPE_FILE:
      case SUPR_MEMTYPE_TMP:
           verbose_info("FILE or TMP");
           verbose_info((char*)(so+1));
	   if(access((char*)(so+1), F_OK)!=0){
             verbose_info(strerror(errno));
	   }
	   
           //SO_print((so_t*) ptr);
	   if(TYPEOF(func) != NILSXP) {
	     //SEXP call = PROTECT(LCONS(func, CONS(mkString((char*)(so+1)), CONS(env, R_NilValue))));
	     SEXP call = PROTECT(LCONS(func, CONS(mkString((char*)(so+1)),
				     R_NilValue)));
	     //SEXP val = PROTECT(eval(call, env));
	     //printf("[%s] %s/%s:\n", __func__, dd_name, subset_name);
	     //PrintValue(val);
	     //UNPROTECT(2);
	     SEXP val = eval(call, env);
	     UNPROTECT(1);
	     if(so->size < sizeof(SEXP*)){
	       so = (so_t *) realloc(so, sizeof(so_t)+ sizeof(SEXP*));
	     }
	     so->ref_count = REF_COUNT_INITIALIZER;
	     so->mem_type = 0;
	     so->sys_type = 0;
	     so->obj_type = SUPR_R_OBJECT;
	     so->size     = sizeof(SEXP);
	     *((SEXP *) so->val) = val; //*((SEXP *) (so+1)) = val;
	     if(tmp_fd != -1) close(tmp_fd);
	     return so;

	   } else if(suffix2type((char*)(so+1)) == FILE_SUFFIX_SUPR_OBJECT) {
		  
	     int fd = open((char*)(so+1), O_RDONLY);
	     struct stat sb;
	     if(fd == -1 || fstat(fd, &sb) == -1)
	       errorcall(R_NilValue, "%s, %s", (char*)(so+1), strerror(errno));

	     so_t *so = (so_t*) malloc(sb.st_size);
	     read(fd, so, sb.st_size);
	     close(fd);
	     so->ref_count = REF_COUNT_INITIALIZER;
	     if(tmp_fd != -1) close(tmp_fd);
	     return so;

	   } else {
	     SEXP val = R_NilValue;
	     if(suffix2type((char*)(so+1)) == FILE_SUFFIX_R_DATA) {
	       SEXP envir =  PROTECT(allocSExp(ENVSXP));
	       if(TYPEOF(env) != ENVSXP) env = R_GlobalEnv;
      	       SET_ENCLOS(envir, env);
	       SEXP call = PROTECT(LCONS(install("load"),
		     CONS(mkString((char*)(so+1)), CONS(envir, R_NilValue))));
	       eval(call, env);
	       call = PROTECT(LCONS(install("as.list"), CONS(envir, R_NilValue)));
	       val = eval(call, env);
	       UNPROTECT(3);

	     } else if(suffix2type((char*)(so+1)) == FILE_SUFFIX_TEXT) {
	       SEXP call = PROTECT(LCONS(install("readLines"),
		     CONS(mkString((char*)(so+1)), R_NilValue)));
	       val = eval(call, env);
	       UNPROTECT(1);

	     } else if(suffix2type((char*)(so+1)) == FILE_SUFFIX_TEXT_CSV) {
	       SEXP call = PROTECT(LCONS(install("read.csv"),
		     CONS(mkString((char*)(so+1)), R_NilValue)));
	       val = eval(call, env);
	       UNPROTECT(1);

	     } else if(suffix2type((char*)(so+1)) == FILE_SUFFIX_TEXT_TAB) {
	       SEXP call = PROTECT(LCONS(install("read.table"),
		     CONS(mkString((char*)(so+1)), R_NilValue)));
	       val = eval(call, env);
	       UNPROTECT(1);

	     } else if(suffix2type((char*)(so+1)) == FILE_SUFFIX_R_OBJECT) {
	       // assume data are saved by saveRDS
	       SEXP call = PROTECT(LCONS(install("readRDS"),
		     CONS(mkString((char*)(so+1)), R_NilValue)));
	       val = eval(call, env);
	       UNPROTECT(1);

	     } else { // create a RAWSXP object ?
	       //errorcall(R_NilValue, "%s, unknown file type", (char*) (so->val));
               val = PROTECT(mkString((char*)(so->val)));
	       setAttrib(val, R_ClassSymbol, mkString("file"));
	       UNPROTECT(1);
	     }


	     if(so->size < sizeof(SEXP*)){
	       so = (so_t *) realloc(so, sizeof(so_t)+ sizeof(SEXP*));
	     }
	     so->ref_count = REF_COUNT_INITIALIZER;
	     so->mem_type = 0;
	     so->sys_type = 0;
	     so->obj_type = SUPR_R_OBJECT;
	     so->size     = sizeof(SEXP);
	     *((SEXP *) so->val) = val; //*((SEXP *) (so+1)) = val;
	     if(tmp_fd != -1) close(tmp_fd);
	     return so;
	   }

      default: errorcall(R_NilValue, "%s, %s", (char*)(so+1), strerror(38));
	       break;
    }
  }

  return NULL;
}

so_t *SO_getDDSubset(const char *dd_name, const char *subset_name,
		const char *addr, SEXP func, SEXP env){

	char msg[256];
	if(Supr_options.debug) {
	  sprintf(msg, "%s[%s]@%s", dd_name, subset_name, addr);
	  basic_info(msg);
	}
	//verbose_info(subset_name);
	//verbose_info(addr);

        char buf[strlen(addr)+1];
        sprintf(buf, "%s", addr);

	char *scheme = NULL;
	char *str;
	if(str = strstr(buf, "://")){
          scheme = buf;
	  *str = 0; str++;
	} else {
	  str = buf;
	}

	char *host = strstr(str, "//");
	if(!host) {
	  supr_errno = INVALID_URI;
	  {
	    sprintf(msg, "%s[%s]@%s, invalid URI", dd_name, subset_name, addr);
	    error_info(msg);
	  }
	  return NULL;
	} else {
          host += 2;
	}
//        printf("\t[%s] %s://%s\n", __func__, scheme, host);


        char *str_port = strstr(str, ":");
	if(!str_port) {
	  supr_errno = INVALID_URI;
	  {
	    sprintf(msg, "%s[%s]@%s, invalid URI", dd_name, subset_name, addr);
	    error_info(msg);
	  }
	  return NULL;
	}
        *str_port  = 0; str_port++;
        int port = atoi(str_port);

	char *query = strstr(str_port, "#");
	if(query) query++;


        printf("\t[%s] %s://%s:%d#%s\n", __func__, scheme, host, port, query);

  if(scheme){ // TODO
	  errno = 38; //Function not implemented;
	  perror(__func__);
	  {
	    sprintf(msg, "%s[%s]@%s, function not implemented", dd_name, subset_name, addr);
	    error_info(msg);
	  }
	  return NULL;
  } else {

    so_t *s = NULL;

#ifdef __USE_LOCAL_GET__

    // DFS_namenode for non datanodes
    if(DFS_namenode && strcmp(host, localhost) == 0 &&
      (s = SO_getLocalDDSubset(dd_name, subset_name, query, func, env)))
      return s;
    
    
#endif
    
//    printf("\t[%s] connecting: %s:%d \n", __func__, host, port);


    int ft_fd =  socket_client(host, port);

    if(ft_fd == -1) { // printf("\t[%s] connection: failure\n", __func__);
	{
	  sprintf(msg, "%s[%s]@%s, %s", dd_name, subset_name, addr, strerror(errno));
	  error_info(msg);
	}
	error(_("connect '%s:%d', %s"), host, port, strerror(errno));
     	return NULL;
    }
    /*
    {
      sprintf(msg, "%s[%s]@%s, fd: %d", dd_name, subset_name, addr, ft_fd); 
      basic_info(msg);
    }
    */

//    printf("\t[%s] ft_fd: %d\n", __func__, ft_fd);

    if(query){
        int cmd = DFS_DD_GET;
        write(ft_fd, &cmd, INT_SIZE);
        size_t len = strlen(query)+1;
        write(ft_fd, &len, SIZE_SIZE);
        write(ft_fd, query,  len);

        so_t so;
        read(ft_fd, &so, sizeof(so_t));
        s = (so_t *) malloc(sizeof(so_t) + so.size);
	if(!s){
	  {
	    sprintf(msg, "%s[%s]@%s, %s", dd_name, subset_name, addr, strerror(errno));
	    error_info(msg);
	  }
	  close(ft_fd);
	  error(_("malloc, %s"),  strerror(errno));
          return s;
	}
        read(ft_fd, s + 1, so.size);
        memcpy(s, &so, sizeof(so_t));
	s->ref_count = 1;
	close(ft_fd);
	return s;

    } else {

        int cmd = DFS_DD_GET;
        write(ft_fd, &cmd, INT_SIZE);
        size_t len = strlen(dd_name)+1;
        write(ft_fd, &len, SIZE_SIZE);
        write(ft_fd, dd_name,  len);

        len = strlen(subset_name)+1;
        write(ft_fd, &len, SIZE_SIZE);
        write(ft_fd, subset_name,  len);

        int mem_type;
//char buf[256];
//printf("%s, %s\n", subset_name, Exec_timestamp(buf, 256));
	ssize_t n = SocketConn_read(ft_fd, &mem_type, INT_SIZE);
//printf("%s, %s\n", subset_name, Exec_timestamp(buf, 256));
	if(n == -1){ // error
           printf("\t\033[0;35m[%s] Error: disconnected? (%s/%s)\033[0m\n",
			  __func__, dd_name, subset_name);
	  {
	    sprintf(msg, "%s[%s]@%s, %s", dd_name, subset_name, addr, strerror(errno));
	    error_info(msg);
	  }
          close(ft_fd);
          return NULL;
	}
//        printf("\t[%s] mem_type: %d\n", __func__, mem_type);

        if(mem_type != -1){

	  //basic_info("mem_type: %d\n", mem_type);

          so_t so;
          ssize_t n = SocketConn_read(ft_fd, &so, sizeof(so_t));
	  if(n == -1){ // error
             printf("\t\033[0;35m[%s] Error: disconnected? (%s/%s)\033[0m\n",
			  __func__, dd_name, subset_name);
          //shutdown(ft_fd, SHUT_RDWR);
	    {
	      sprintf(msg, "%s[%s]@%s, %s", dd_name, subset_name, addr, strerror(errno));
	      error_info(msg);
	    }
            close(ft_fd);
            return NULL;
	  }
	  //basic_info("so.size: %ld\n", so.size);

          s = (so_t *) malloc(sizeof(so_t) + so.size);
          n = SocketConn_read(ft_fd, s + 1, so.size);
	  if(n == -1){ // error
            printf("\t\033[0;35m[%s] Error: disconnected? (%s/%s)\033[0m\n",
			  __func__, dd_name, subset_name);
          //shutdown(ft_fd, SHUT_RDWR);
	    {
	      sprintf(msg, "%s[%s]@%s, %s", dd_name, subset_name, addr, strerror(errno));
	      error_info(msg);
	    }
            close(ft_fd);
            return NULL;
	  }
          memcpy(s, &so, sizeof(so_t));
	  s->ref_count = REF_COUNT_INITIALIZER;
        }

	//{
        //  shutdown(ft_fd, SHUT_RDWR);
	//}
	/*{
	  cmd = 0;
	  write(ft_fd, &cmd, sizeof(int));
	} */
        close(ft_fd);

//Thread_callStack_dl();

        if(func) { // Datauser

          if(s->mem_type == SUPR_MEMTYPE_MEM && s->obj_type == SUPR_FILE)
             mem_type = s->mem_type = SUPR_MEMTYPE_TMP;
    
	  SEXP _func = NULL;
	  if(TYPEOF(func)==NILSXP && mem_type!=SUPR_MEMTYPE_MEM){
            _func = PROTECT(DD_getDefaultRFuncBySuffix(subset_name));
//		  printf("_func: "); PrintValue(_func);
	    func = _func;
	  }

	  switch(mem_type){
	    case SUPR_MEMTYPE_FILE:
	    case SUPR_MEMTYPE_TMP:
	    case SUPR_MEMTYPE_SHM:
	         if(TYPEOF(func) != NILSXP) { // FIXME
		   char template[64];
		   sprintf(template, "/tmp/sdfs_XXXXXX");
		   int fd = mkstemp(template);
		   write(fd, s->val, s->size);
		   close(fd);
		   char *file_name = template;
		   //printf("[%s] template: %s\n", __func__, file_name);
	           SEXP file = PROTECT(mkString(file_name));
	           SEXP call = PROTECT(LCONS(func, CONS(file, R_NilValue)));
		   SEXP val  = eval(call, env);

		   unlink(file_name);

	           if(s->size < sizeof(SEXP*)){
	             s = (so_t *) realloc(s, sizeof(so_t)+ sizeof(SEXP*));
	           }
	           s->ref_count = REF_COUNT_INITIALIZER;
	           s->mem_type = SUPR_MEMTYPE_MEM;
	           s->sys_type = 0; // TODO
	           s->obj_type = SUPR_R_OBJECT;
	           s->size     = sizeof(SEXP);
	           *((SEXP *) s->val) = val; //*((SEXP *) (so+1)) = val;
		   UNPROTECT(2);
	         } 
	         break;
	      default: break;
	  }
	  if(_func) UNPROTECT(1);
	}

	
	return s;
    }
  }
}

const char *type2suffix(int type){
 switch(type){
   case FILE_SUFFIX_SUPR_OBJECT: return "s2o";
   case FILE_SUFFIX_R_DATA:      return "rda";
   case FILE_SUFFIX_TEXT:        return "txt";
   case FILE_SUFFIX_TEXT_CSV:    return "csv";
   case FILE_SUFFIX_TEXT_TAB:    return "tab";
   case FILE_SUFFIX_UNKNOWN_TYPE: return "na";
 }
}

//static hashtable_t *ddCache = NULL;


static int ia2cmp(const void *a, const void *b)
{
  return ((int*)a)[0] - ((int*)b)[0];
}

void DD_setGetPreference(const char **datanodeNames, int *pref,
	       	int len, const char *preferred)
{
  if(!localhost){
    char name[256];
    if(gethostname(name, 256) == -1)
      errorcall(R_NilValue, "gethostname, %s", strerror(errno));
    localhost = strdup(name);
  }

  if(!preferred) preferred = localhost;
  int diff[len][2]; // int array {diff[0][2], diff[1][2], ...}
  for(int i=0; i<len; i++){
    diff[i][0] = strncmp(preferred, datanodeNames[i]+2, strlen(preferred));
    diff[i][1] = i;
  }
  qsort(diff, len, 2*sizeof(int), ia2cmp);
  for(int i=0; i<len; i++) pref[i] = diff[i][1];
}


// Use a proxy thread?
SEXP DD_get(SEXP r_name, SEXP subset_name, SEXP env, SEXP args)
{
  /*
  { // FIXME
    if(!DFS_namenode || fcntl(DFS_namenode->fd, F_GETFD)==-1)
	    error("DFS_namenode is not available");
  }

  printf("DFS_namenode: //%s:%d\n", DFS_namenode->host, DFS_namenode->port);
  */

  int fd;
  if(!DFS_namenode) {
    SEXP dfsConnPtr = getAttrib(r_name, install("dfs.name"));
    if(TYPEOF(dfsConnPtr)==NILSXP)
	    error("DFS_namenode is not available");
    DFS_namenode = (supr_socket_conn_t*) R_ExternalPtrAddr(dfsConnPtr);
    if(!DFS_namenode) 
	    error("DFS_namenode is not available");
  }
  fd = DFS_namenode->fd;

  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_GET;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  // FIXME
  if(TYPEOF(subset_name)==NILSXP) {
    int n = 0;
    write(fd, &n, INT_SIZE);
  } else {
    int n = LENGTH(subset_name);
    write(fd, &n, INT_SIZE);
    for(int i=0; i<n; i++){
      const char *s_name = CHAR(STRING_ELT(subset_name, i));
      len = strlen(s_name)+1;
      write(fd, &len, SIZE_SIZE);
      write(fd, s_name,  len);
    } 
  }
  
  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
  }

  //basic_info("%s: rc=%d", __func__, rc);

  int nDatanodes = rc;
  char *datanodeNames[nDatanodes];
  for(int i=0; i<nDatanodes; i++)
  {
    datanodeNames[i] = SocketConn_readString(DFS_namenode, NULL, 0);
    //SuprErr_check();
    if(SuprErr_get())
	    error("cannot read DFS_namenode");
  }

  int n;
  read(fd, &n, INT_SIZE);
  SEXP names = PROTECT(allocVector(STRSXP, n));

  unsigned char datanodes[n][nDatanodes]; // indicators

  for(int i=0; i<n; i++){
    read(fd, &len, SIZE_SIZE);
    char s_name[len];
    read(fd, s_name, len);
    SET_STRING_ELT(names, i, mkChar(s_name));
    read(fd, datanodes[i], nDatanodes);
  }

  SEXP val = PROTECT(allocVector(VECSXP, n));
  setAttrib(val, R_NamesSymbol, names);

  // set preferrence
  int pref[nDatanodes];
  DD_setGetPreference((const char**)datanodeNames, pref, nDatanodes, NULL);

  for(int i=0; i<n; i++){
    const char *s_name = CHAR(STRING_ELT(names, i));
    SET_VECTOR_ELT(val, i, R_UnboundValue);
    for(int k=0; k<nDatanodes; k++){
      int j = pref[k];
      if(datanodes[i][j]){
	const char *addr = datanodeNames[j];

	printf("[%s] %d/%d. addr: %s\n", __func__, i, n, addr);

	const char *suffix = s_name + strlen(s_name);
	for(; suffix != s_name; suffix--)
          if(*suffix == '.'){
		  suffix++;
		  break;
	  }

	SEXP func = R_NilValue;
	if(suffix == s_name){
	 suffix = "";
	} else {
	  // ...
	}
	/*
	while(TYPEOF(args) != NILSXP){
          SEXP tag = TAG(args);
	  if(TYPEOF(tag) == SYMSXP && strcmp(CHAR(PRINTNAME(tag)), suffix)==0){
	    func = CAR(args);
	    break;
	  }
	}
	*/
	printf("\033[0;32m[%d:%s] TYPE(args): %s, suffix: %s\033[0m\n", __LINE__, __func__,
		type2char(TYPEOF(args)), suffix);
	if(TYPEOF(args)==VECSXP){
	  printf("[%s] VECSXP\n", __func__);
	} else if(TYPEOF(args)==LISTSXP){
	  printf("[%s] LISTSXP\n", __func__);
	}
	
	char buf[256];
        so_t *s = SO_getDDSubset(name, s_name, addr, func, env);

        if(s){
		
	  if(s->mem_type == SUPR_MEMTYPE_FILE){ // FIXME

	    //{
              SEXP raw = PROTECT(allocVector(RAWSXP, s->size));
	      memcpy(DATAPTR(raw), s+1, s->size);
              SET_VECTOR_ELT(val, i, raw);
	      UNPROTECT(1);
	      setAttrib(raw, install("file.suffix"),
		     mkString(type2suffix(s->obj_type)));
	    //}
	  } else if(s->obj_type == SUPR_R_OBJECT){
            SET_VECTOR_ELT(val, i, *((SEXP*) s->val));
	    //printf("[%s] (%s:%d):\n", __func__, __FILE__, __LINE__);
	    //PrintValue(*((SEXP *) s->val));
	  } else {
            SET_VECTOR_ELT(val, i, SO_toRObject(s, sizeof(so_t) + s->size));
	  }
          free(s);
	  break;
        }
      }
    }
  }


  UNPROTECT(2);

  return n==1 ? VECTOR_ELT(val, 0) : val;
}

void Socket_check(supr_socket_conn_t **sc_addr)
{
  supr_socket_conn_t *sc = *sc_addr;
  if(!sc) 
     error(_("connection is not available"));
  
  int fd = sc->fd;
  int flags = fcntl(fd, F_GETFL);

  if(flags == -1){ // FIXME, use PING
    error_info("Error in fcntl, addr: %s:%d", sc->host, sc->port);
    //free(sc);
    sc = socketOpen2(sc->host, sc->port);
    *sc_addr = sc;
    return;
  }

  if(Supr_options.debug){
    if(flags & O_NONBLOCK){ //fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
      debug_info("NON-BLOCKING ...");
    } else {
      debug_info("BLOCKING ...");
    }
  }

}

SEXP DD_list(SEXP r_name)
{
  Socket_check(&DFS_namenode);
  if(!DFS_namenode)
    error("DFS_namenode is not available");


  int fd = DFS_namenode->fd;

  ssize_t size;

  const char *name = CHAR(asChar(r_name));

  verbose_info(name);

  int cmd = DFS_DD_LIST;
  size = write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  size += write(fd, &len, SIZE_SIZE);
  size += write(fd, name,  len);

  if(size != INT_SIZE + SIZE_SIZE + len) {
    Socket_check(&DFS_namenode);
    error("[%d] %s: write(fd=%d, ...): %s", __LINE__, __func__, fd,
		    strerror(errno));
  }

#define DD_LIST_DD_INFO  1
  //
  int rc;
  size = read(fd, &rc, INT_SIZE);
  if(size != INT_SIZE)
	  error("[%d] %s: write(fd=%d, ...): %s", __LINE__, __func__, fd, strerror(errno));
    //error("write(fd=%d, ...): %s", fd, strerror(errno));

  //printf("DFS_namenode, rc: %d (%s)\n", rc, rc == DD_LIST_DD_INFO ?  "DD_LIST_DD_INFO" : "" );

  /*
  char msg[1024];
      {
        sprintf(msg, "rc: %d (DD_LIST_DD_INFO=%d)", rc, DD_LIST_DD_INFO);
        basic_info(msg);
      }
      */

  if(rc == -1) {
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
  } else if(rc == DD_LIST_DD_INFO) {
#define LIST_DATANODE_INFO
#ifdef  LIST_DATANODE_INFO
    int nDatanodes;
    ssize_t size = read(fd, &nDatanodes, INT_SIZE);
    /*
      {
        sprintf(msg, "size: %ld, nDatanodes: %d", size, nDatanodes);
        basic_info(msg);
      }
      */
      if(size != INT_SIZE)
	      error(_("%s"), strerror(errno));
      
    SEXP levels = PROTECT(allocVector(STRSXP, nDatanodes));
    for(int i=0; i<nDatanodes; i++){
	    /*
      {
        sprintf(msg, "%d. node: -----", i+1);
        basic_info(msg);
      }
      */
      char *s = SocketConn_readString(DFS_namenode, NULL, 0);
      /*
      {
        sprintf(msg, "%d. node: %s", i+1, s);
        basic_info(msg);
      }
      */
      SET_STRING_ELT(levels, i, mkChar(s));
      free(s);
    }

    //printf("[%s] rc: %d, nDatanodes: %d\n", __func__, rc, nDatanodes);

    int n;
    read(fd, &n, INT_SIZE);

    SEXP names = PROTECT(allocVector(STRSXP, n));
    SEXP times = PROTECT(allocVector(STRSXP, n));
    SEXP sizes = PROTECT(allocVector(INTSXP, n)); // SIZE_SIZE??/ FIXME

    SEXP is_dir = PROTECT(allocVector(INTSXP, n));
    SEXP replicates = PROTECT(allocVector(INTSXP, n));

    SEXP locations[nDatanodes];
    for(int i=0; i<nDatanodes; i++) {
      locations[i] = PROTECT(allocVector(INTSXP, n));
      //SET_VECTOR_ELT(df, 2+i, locations[i]);
    }

    for(int i=0; i<n; i++){
      char *s_name = SocketConn_readString(DFS_namenode, NULL, 0);
      SET_STRING_ELT(names, i, mkChar(s_name));

      /*
      {
        sprintf(msg, "%d. subset: %s", i+1, s_name);
        basic_info(msg);

	int rc = 0;
	write(fd, &rc, sizeof(int));
      }
      */

      free(s_name);

      dd_stat_t sb;
      read(fd, &sb, sizeof(dd_stat_t));
      {
        char buf[128];
        struct tm result;
        localtime_r(&sb.st_mtim.tv_sec, &result);
        asctime_r(&result, buf);
        char *s = strstr(buf, "\n");
        if(s) *s = 0;
        SET_STRING_ELT(times, i, mkChar(buf));
      }
      INTEGER(is_dir)[i] = S_ISDIR(sb.st_mode);
      //statPrint(&sb); printf(" \t%s\n", s_name);

      INTEGER(sizes)[i] = (int) sb.st_size;

      unsigned char which[nDatanodes];
      read(fd, which, sizeof(which));
      int nrep = 0;
      for(int j=0; j<nDatanodes; j++) {
        INTEGER(locations[j])[i] = which[j];
	nrep +=  which[j];
      }
      INTEGER(replicates)[i] = nrep;

    }
    SEXP val = PROTECT(allocVector(VECSXP, 3 + nDatanodes + 2));
    int k = 0;
    SET_VECTOR_ELT(val, k++, names);
    SET_VECTOR_ELT(val, k++, is_dir);
    SET_VECTOR_ELT(val, k++, sizes);
    SET_VECTOR_ELT(val, k++, times);
    for(int i=0; i<nDatanodes; i++)
      SET_VECTOR_ELT(val, k++, locations[i]);
    SET_VECTOR_ELT(val, k++, replicates);

    names = PROTECT(allocVector(STRSXP, 3+nDatanodes + 2));
    k = 0;
    SET_STRING_ELT(names, k++, mkChar("subset"));
    SET_STRING_ELT(names, k++, mkChar("dir"));
    SET_STRING_ELT(names, k++, mkChar("size"));
    SET_STRING_ELT(names, k++, mkChar("time"));
    for(int i=0; i<nDatanodes; i++) {
      char buf[64];
      sprintf(buf, "D.%d", i+1);
      SET_STRING_ELT(names, k++, mkChar(buf));
    }
    SET_STRING_ELT(names, k++, mkChar("nrep"));

    setAttrib(val, R_NamesSymbol, names);
    setAttrib(val, R_ClassSymbol, mkString("data.frame"));
    names = PROTECT(allocVector(INTSXP, n));
    for(int i=0; i<n; i++) INTEGER(names)[i] = i + 1;
    setAttrib(val, install("row.names"), names);
    setAttrib(val, install("data.nodes"), levels);
    UNPROTECT(9+nDatanodes);
    return val;
#else
    int n;
    read(fd, &n, INT_SIZE);
    SEXP names = PROTECT(allocVector(STRSXP, n));
    SEXP times = PROTECT(allocVector(STRSXP, n));
    SEXP sizes = PROTECT(allocVector(INTSXP, n)); // SIZE_SIZE??/ FIXME
    for(int i=0; i<n; i++){
      char *s_name = SocketConn_readString(DFS_namenode, NULL, 0);
      SET_STRING_ELT(names, i, mkChar(s_name));
      dd_stat_t sb;
      read(fd, &sb, sizeof(dd_stat_t));
      {
        char buf[128];
        struct tm result;
        localtime_r(&sb.st_mtim.tv_sec, &result);
        asctime_r(&result, buf);
        char *s = strstr(buf, "\n");
        if(s) *s = 0;
        SET_STRING_ELT(times, i, mkChar(buf));
      }
      //statPrint(&sb); printf(" \t%s\n", s_name);
      free(s_name);

      INTEGER(sizes)[i] = (int) sb.st_size;
    }
    SEXP val = PROTECT(allocVector(VECSXP, 3));
    SET_VECTOR_ELT(val, 0, names);
    SET_VECTOR_ELT(val, 1, sizes);
    SET_VECTOR_ELT(val, 2, times);
    names = PROTECT(allocVector(STRSXP, 3));
    SET_STRING_ELT(names, 0, mkChar("subset"));
    SET_STRING_ELT(names, 1, mkChar("size"));
    SET_STRING_ELT(names, 2, mkChar("time"));
    setAttrib(val, R_NamesSymbol, names);
    setAttrib(val, R_ClassSymbol, mkString("data.frame"));
    names = PROTECT(allocVector(INTSXP, n));
    for(int i=0; i<n; i++) INTEGER(names)[i] = i + 1;
    setAttrib(val, install("row.names"), names);
    UNPROTECT(6);
    return val;
#endif
  }

  struct stat sb;
  read(fd, &sb.st_mode, sizeof(mode_t));


  if(S_ISDIR(sb.st_mode)){

    read(fd, &rc, INT_SIZE);

    if(rc == -1){
      read(fd, &len, SIZE_SIZE);
      char err[len];
      read(fd, err, len);
      errorcall(R_NilValue, "%s", err);
    }

    //struct dirent *dp;
    while(TRUE){

      ssize_t size = read(fd, &len, SIZE_SIZE);
      if(size == -1)
	      error("read(fd=%d, ...)", fd, strerror(errno));
      if(len == 0) break;

      char d_name[len];
      read(fd, d_name, len);

      read(fd, &rc, INT_SIZE);

      if(rc == -1){
        read(fd, &len, SIZE_SIZE);
        char err[len];
        read(fd, err, len);
        //errorcall(R_NilValue, "%s: %s", d_name, err);
        printf("%s: %s\n", d_name, err);
      } else {
        read(fd, &sb, sizeof(struct stat));
        statPrint(&sb);
      }
      printf(" \t%s\n", d_name);
    }

  } else {
    read(fd, &sb, sizeof(struct stat));
    statPrint(&sb);
  }


  return R_NilValue;

}

//extern SEXP Rf_mkPROMISE(SEXP, SEXP);
//extern SEXP mkPROMISE(SEXP, SEXP);
/*linux> nm -D libR.so
0000000000196a46 T R_mkEVPROMISE
0000000000196a8c T R_mkEVPROMISE_NR
*/

SEXP DDT_call(SEXP ddt_call){
  int fd;
  /*
  if(!DFS_namenode) {
    SEXP dfsConnPtr = getAttrib(r_name, install("dfs.name"));
    if(TYPEOF(dfsConnPtr)==NILSXP)
	    error("DFS_namenode is not available");
    DFS_namenode = (supr_socket_conn_t*) R_ExternalPtrAddr(dfsConnPtr);
    if(!DFS_namenode) 
	    error("DFS_namenode is not available");
  }
  */

  //
  if(TYPEOF(ddt_call) != LANGSXP){
    if(TYPEOF(ddt_call) == ENVSXP){

      char val[256];
      SEXP name = getAttrib(ddt_call, install("name"));
      SEXP localEnv=getAttrib(ddt_call, install("localEnv"));
      SEXP conn=getAttrib(ddt_call, install("conn"));
      SEXP addr=getAttrib(ddt_call, install("address"));
      if(name == R_NilValue){
        sprintf(val, "<DDEnv: addr=%s, conn=%p>",
          CHAR(STRING_ELT(addr, 0)), R_ExternalPtrAddr(conn));
      } else {
        sprintf(val, "<DDEnv: addr=%s, conn=%p, name=%s>",
          CHAR(STRING_ELT(addr, 0)), R_ExternalPtrAddr(conn),
       	  CHAR(STRING_ELT(name, 0)));
      }
      SEXP ret_val = PROTECT(mkString(val));
      setAttrib(ret_val, R_ClassSymbol, mkString(".__DDEnvPrint__."));
      UNPROTECT(1);
      return ret_val; // TODO
    }
    fprintf(stderr, "\033[0;33m\ntypeof(ddt_call): %s\n", type2char(TYPEOF(ddt_call)));
    PrintValue(ddt_call);
    fprintf(stderr, "`%s`(... )\033[0m\n\n", CHAR(PRINTNAME(CAR(ddt_call))));
    return R_NilValue; // TODO
  }
  //

  SEXP x = PROTECT(LCONS(install("quote"), CONS(ddt_call, R_NilValue)));
  Rboolean success = R_ToplevelExec(Supr_serialize1, &x);
  //basic_info("success = %d", success);
  if(!success)
	  error(_("[%s] %s"), __func__, R_curErrorBuf());

  PROTECT(x);

  fd = DFS_namenode->fd;

  int cmd = DFS_DDT_CALL;
  write(fd, &cmd, INT_SIZE);

  int len = LENGTH(x);
  write(fd, &len, INT_SIZE);
  write(fd, RAW(x), len);
  UNPROTECT(2);

  int rc;
  read(fd, &rc, INT_SIZE);

  if(rc == -1){
    int len;
    read(fd, &len, INT_SIZE);
    unsigned char err[len];
    read(fd, err, len);
    error(_("%s"), err);
  }

  SEXP val = PROTECT(allocVector(RAWSXP, rc));
  read(fd, RAW(val), rc);

  success = R_ToplevelExec(Supr_unserialize1, &val);
  if(!success)
	  error(_("[%s] %s"), __func__, R_curErrorBuf());
  UNPROTECT(1);

  return val;
}


#undef read

