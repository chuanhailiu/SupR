

//#define __RYTHON_MAIN__

#include "supr.h"
#include "util.h"


#include <sys/types.h>
#include <sys/wait.h>

#define USE_PYTHON
#ifdef  USE_PYTHON
//#include <python3.6m/Python.h>
#define PY_SSIZE_T_CLEAN

#define PYTHON_3_8

#ifdef PYTHON_3_8

#define TESTING
#ifdef  TESTING

#include <Python.h>
#include <node.h>
#include <marshal.h>
#include <descrobject.h>
//#include <python3.6m/compile.h>
//#include <python3.6m/pyconfig.h>
#include <sysmodule.h>
#include <pythonrun.h>

#else

#include <python3.8/Python.h>
#include <python3.8/node.h>
#include <python3.8/marshal.h>
#include <python3.8/descrobject.h>
//#include <python3.6m/compile.h>
//#include <python3.6m/pyconfig.h>
#include <python3.8/sysmodule.h>
#include <python3.8/pythonrun.h>

#endif

#else

//// FIXME
//#include <python3.6m/Python.h>
#include <python3.6m/node.h>
#include <python3.6m/marshal.h>
#include <python3.6m/descrobject.h>
//#include <python3.6m/compile.h>
//#include <python3.6m/pyconfig.h>
#include <python3.6m/sysmodule.h>
#include <python3.6m/pythonrun.h>

#endif


#include <locale.h>
#endif

_Py_IDENTIFIER(ps1);
_Py_IDENTIFIER(ps2);

//_Py_IDENTIFIER(__dir__);
//_Py_IDENTIFIER(__getattr__);
//_Py_IDENTIFIER(__dict__);

// python -m pip install -U pip
// python -m pip install -U matplotlib

#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)

#define strdup(ptr) __supr_strdup__((ptr), __func__, __FILE__, __LINE__)

// FIXME
#ifndef _
#define _(x) (x)
#endif

#define null R_NilValue

SEXP R_RythonEnv = NULL;
pthread_key_t rythonThreadKey;
pthread_key_t rythonInterruptKey;

extern char *(*ptr_readline)(const char *prompt);
SEXP RObject_wrapper(PyObject *p);
static int Rython_isPyObjectWrapper(SEXP where);
static PyObject *SEXP_toPyObject(SEXP s);

SEXP PyObject_toROject(PyObject *obj);

static wchar_t *wchar_progname;
/*
int shm_io_destroy (shm_io_info_t *io);
void Supr_interrupt_enable();
void Supr_interrupt_disable();
void Supr_onClusterEvalIntr(void *data);

SEXP Sync_lock(SEXP x);
SEXP Sync_unlock(SEXP x);
SEXP Sync_wait(SEXP x, SEXP r_timeout);
SEXP Sync_notify(SEXP x, SEXP r_all);
*/


#ifdef USE_PYTHON

static PyObject *RError;
static PyObject *SuprError;
static int Py_initialized = FALSE;

static PyObject *Rython_capsulate(SEXP r_val);

static PyObject *__promise_getattr(PyObject *self, char *attr);
static int __promise_setattr(PyObject *self, char *attr, PyObject *value);
static PyObject *__promise_dir(PyObject *self, PyObject *args);

void Py_Print(PyObject *p, const char *prefix);

#define __Py_Print(obj, str) do { \
        fprintf(stdout, "[%s:%d] %s :: ", __FILE__, __LINE__, (str));    \
        PyObject_Print((obj), stdout, Py_PRINT_RAW);    \
        fprintf(stdout, "\n");   \
} while(0)

#define USE_LAZY_EVAL // in some sense lazy conversion
#ifdef  USE_LAZY_EVAL

// used as a reference (and promise object as well?) to R objects?
typedef struct {
    //PyObject_HEAD
    PyObject_VAR_HEAD
    //const void *r_expr;
    SEXP r_expr;
    //const void *r_envir;
    SEXP r_envir;
    PyObject   *p_object;
    char *name;
    void *context; // so a kind of extension to PyCapsule
    PyMethodDef *m_ml;
} RyPromiseObject;

//typedef struct SEXP_Object_struct RyPromiseObject;

PyObject *__myobj_new(PyTypeObject *subtype, PyObject *args,
	       	PyObject *kwds);

void __myobj_dealloc(PyObject *self)
{
  fprintf(stdout, "\033[0;35m %s is called: TODO, self: %p\033[0m\n",
		  __func__, self);
  //free(obj);

  PyObject *error_type, *error_value, *error_traceback;
  PyErr_Fetch(&error_type, &error_value, &error_traceback);
  {
    RyPromiseObject *my_obj = (RyPromiseObject *) self;
    fprintf(stdout, "\t\033[0;35m name: %s, m_ml: %p\033[0m\n",
		    my_obj->m_ml->ml_name, my_obj->m_ml);
    free((char*)my_obj->m_ml->ml_name);
    free(my_obj->m_ml);
  }
  PyErr_Restore(error_type, error_value, error_traceback);
}

PyObject *__promise_repr(PyObject *obj);

/*
PyObject *__myobj_repr(PyObject *obj)
{
  fprintf(stdout, "\033[0;35m %s is called\033[0m\n", __func__);
  //return NULL;
  SEXP s = ((RyPromiseObject*) obj)->r_expr;
  char buf[256];
  sprintf(buf, "<%s object at %p>", type2char(TYPEOF(s)), s);
  fprintf(stdout, "\033[0;35m[%s] %s\033[0m\n", __func__, buf);
  
  PyObject *ret = Py_BuildValue("s", buf);
  return ret;
 
}
*/

static void __myobj_finalize(PyObject *self)
{
  fprintf(stdout, "\033[0;36m %s is called. self: %p\033[0m\n", __func__,
		  self);
  PyObject *error_type, *error_value, *error_traceback;
  PyErr_Fetch(&error_type, &error_value, &error_traceback);
  {
//    XP_Object *my_obj = (SEXP_Object *) self;
//    free(my_obj->m_ml->ml_name);
//    free(my_obj->m_ml);
  }
  PyErr_Restore(error_type, error_value, error_traceback);
}

static PyObject *__promise_as_num(PyObject *self, PyObject *args);
static PyObject *__promise_as_int(PyObject *self, PyObject *args);
//static PyObject *__promise_as_int(PyObject *self, PyObject *args, PyObject *kwds);

/*
 * #define METH_VARARGS  0x0001
#define METH_KEYWORDS 0x0002
// METH_NOARGS and METH_O must not be combined with the flags above.
#define METH_NOARGS   0x0004
#define METH_O        0x0008
*/

static PyMethodDef __promise_methods[] = {
  {"__dir__",  __promise_dir, METH_VARARGS, "dir(object)"},
//  {"as_int",   __promise_as_int, METH_NOARGS, "as_int()"},
  {"as_int",   (PyCFunction)__promise_as_int, METH_VARARGS | METH_KEYWORDS, "as_int()"},
  {"as_num",   __promise_as_num, METH_NOARGS, "as_num()"},
  {NULL, NULL, 0, NULL}   
};

// reference to R objects ?
static PyTypeObject RyPromiseObject_Type = {
    PyVarObject_HEAD_INIT(NULL, 0)
    .tp_name = "RyPromiseObject",
    .tp_basicsize = sizeof(RyPromiseObject),
    .tp_doc = "ptr to R objects",
    .tp_new = __myobj_new,
    .tp_dealloc = (destructor)__myobj_dealloc,
    .tp_repr = (reprfunc)__promise_repr,
    .tp_str = NULL,
    .tp_finalize = (destructor) __myobj_finalize,
    .tp_getattr = __promise_getattr,
    .tp_setattr = __promise_setattr,
    .tp_methods = __promise_methods,
};

PyObject *__myobj_new(PyTypeObject *subtype, PyObject *args,
	       	PyObject *kwds)
{
  RyPromiseObject *obj =(RyPromiseObject *)_PyObject_New(
		  &RyPromiseObject_Type);

  obj->r_expr = NULL;
  obj->r_envir = NULL;
  obj->p_object = NULL;
  obj->name = NULL;
  obj->context = NULL;
  obj->m_ml = NULL;

  return (PyObject *) obj;
}

void RyPromise_setMethod(PyObject *prom, PyMethodDef *m_ml)
{
  RyPromiseObject *obj = (RyPromiseObject *) prom;
  obj->m_ml = m_ml;
}

PyObject *RyPromise_New(SEXP expr, SEXP env);

PyObject *__promise_new(PyTypeObject *subtype, PyObject *args, PyObject *kwds);

void __promise_dealloc(PyObject *obj)
{
  fprintf(stderr, "%s is called\n", __func__);
  //free(obj);
}

PyObject *__promise_repr(PyObject *obj)
{

  RyPromiseObject* prom = (RyPromiseObject*) obj;

  if(prom->p_object)
	  return PyObject_Repr(prom->p_object);

  SEXP s = (SEXP) prom->r_expr;

  /*
  fprintf(stderr, "%s is called \033[0;34m\n---------------\n", __func__);
  PrintValue(s);
  SEXP call = PROTECT(LCONS(install("str"), CONS(s, R_NilValue)));
  eval(call, R_GlobalEnv);
  UNPROTECT(1);
  fprintf(stderr, "----------------\n\033[0m");
  */

  char buf[256];
  sprintf(buf, "<%s object at %p>", type2char(TYPEOF(s)), s);
//  fprintf(stdout, "\033[0;35m[%s] prom->name: %s, prom->m_ml: %p\033[0m\n", __func__, prom->name, prom->m_ml);
  
  PyObject *ret = Py_BuildValue("s", buf);
  return ret;
 
}

/*
PyObject *RyRef_capsulate(SEXP r_val, SEXP env)
{
}
*/
/* 
 * Include/methodobject.h
 *
 * struct PyMethodDef {
    const char  *ml_name;   // The name of the built-in function/method 
    PyCFunction ml_meth;    // The C function that implements it 
    int         ml_flags;   // Combination of METH_xxx flags, which mostly
                               describe the args expected by the C func
    const char  *ml_doc;    // The __doc__ attribute, or NULL
};

typedef struct PyMethodDef PyMethodDef;

typedef struct {
    PyObject_HEAD
    PyMethodDef *m_ml; // Description of the C function to call 
    PyObject    *m_self; // Passed as 'self' arg to the C func, can be NULL
    PyObject    *m_module; // The __module__ attribute, can be anything
    PyObject    *m_weakreflist; // List of weak references
} PyCFunctionObject;

#define PyCFunction_New(ML, SELF) PyCFunction_NewEx((ML), (SELF), NULL)

PyAPI_FUNC(PyObject *) PyCFunction_NewEx(PyMethodDef *, PyObject *,
                                         PyObject *);


*/

/*A weak reference to an object is not enough to keep the object alive: when the only remaining references to a referent are weak references, garbage collection is free to destroy the referent and reuse its memory for something else. However, until the object is actually destroyed the weak reference may return the object even if there are no strong references to it.
 * */

/*A primary use for weak references is to implement caches or mappings holding large objects, where it’s desired that a large object not be kept alive solely because it appears in a cache or mapping.
 * */


// void tp_finalize(PyObject *self);

//#define RyPromise_CheckExact(f) Py_TYPE(f) == &RyPromiseObject_Type
#define RyPromise_CheckExact(o) Py_TYPE(o) == &RyPromiseObject_Type
//static PyObject * py_call(PyObject *self, PyObject *args);

PyObject *Sexp2Py(SEXP r_val, const char* attr);

static PyObject *__promise_call(PyObject *self, PyObject *args)
{
	/*
	fprintf(stdout, "%s is called\n", __func__);
	Py_Print(self, "SELF");
	Py_Print(args, "ARGS");
	*/
	//return Py_None;

  PyObject * fun = self;
  if(RyPromise_CheckExact(self)) 
  {
    //const char *name = PyCapsule_GetName(fun);
    //SEXP s = (SEXP) PyCapsule_GetPointer(fun, name);
    RyPromiseObject *prom = (RyPromiseObject *) self;
    SEXP s = (SEXP) prom->r_expr;

    SEXP call = PROTECT(LCONS(s, R_NilValue));
    Py_ssize_t n = PyTuple_Size(args);
    s = call;
    for(int i=0; i<n; i++){
       PyObject *a = PyTuple_GetItem(args, i);
       SETCDR(s, CONS(PyObject_toROject(a), R_NilValue));
       s = CDR(s);
    }
    SEXP val = eval(call, R_GlobalEnv);
    UNPROTECT(1);

    return Sexp2Py(val, NULL);
    //return RyPromise_New(val, R_GlobalEnv);

  } else {
    PyErr_SetString(PyExc_SystemError, __func__);
    return NULL;
  }
}

#define TREAT_R_WITH_ATTR_AS_CLASS

static PyObject *__promise_getattr(PyObject *self, char *attr)
{
  //fprintf(stdout, "[%s] attr: %s\n", __func__, attr);
  SEXP expr;
  if(RyPromise_CheckExact(self)){

    {
      PyMethodDef *m = Py_TYPE(self)->tp_methods;
      for(int i=0; m[i].ml_name && m[i].ml_doc; i++){
        //fprintf(stdout, "[%s] ml_name: %s\n", __func__, m[i].ml_name);
	if(strcmp(m[i].ml_name, attr)==0)
          return PyCFunction_NewEx(&m[i], self, NULL);
      }
    }

    RyPromiseObject *obj = (RyPromiseObject *)self;
    expr= obj->r_expr;
  } else {
    PyErr_SetString(PyExc_SystemError, "FIXME");
    return NULL;
  }

  SEXP r_val;

  if(strcmp(attr, "__class__")==0)
    attr = "class";

  if(TYPEOF(expr) == ENVSXP) {
    r_val = findVar(install(attr), expr); // _Shared??
    if(r_val == R_UnboundValue){
      //PyErr_SetString(PyExc_ValueError, "cannot find the named object");
      PyErr_SetString(PyExc_NameError, attr);
      return NULL;
    }
  } else {
    r_val = getAttrib(expr, install(attr));
  }
  
  return Sexp2Py(r_val, attr);

}

PyObject *Sexp2Py(SEXP r_val, const char *attr)
{
  int R_TYPE = TYPEOF(r_val);

  if(R_TYPE ==  PROMSXP) {
    r_val = eval(r_val, R_GlobalEnv); // protect???
    R_TYPE = TYPEOF(r_val);
  }

  if(R_TYPE == CLOSXP || R_TYPE==BUILTINSXP || R_TYPE==SPECIALSXP) {
    // for R "callable"  objects
    PyMethodDef *ml = (PyMethodDef *) malloc(sizeof(PyMethodDef)); // free?
    ml->ml_name = strdup(attr);
    ml->ml_meth = __promise_call;
    ml->ml_flags= METH_VARARGS;
    ml->ml_doc = "R callable object ...";

    PyObject *self = RyPromise_New(r_val, R_GlobalEnv);
    Py_Print(self, "Allocated RyPromise");
    RyPromise_setMethod(self, ml);

    //PyObject *my_func = PyCFunction_NewEx(ml, Rython_capsulate(r_val), NULL);
    // ml is referred to by PyCFunction_NexEx
    // PyCFunction_Type.tp_dealloc -> (destructor)meth_dealloc
    PyObject *my_func = PyCFunction_NewEx(ml, self, NULL);
    {
      PyCFunctionObject *f = (PyCFunctionObject *)my_func;
      fprintf(stderr, "f->m_ml: %p, ml: %p (FIXME, PyTypeObject.tp_dealloc?)\n", f->m_ml, ml);

      // testing
      //Py_TYPE(my_func)->tp_dealloc(my_func);
//      Py_DECREF(my_func);
//      return Py_None;
    }
    return my_func;
  }

  if(Rython_isPyObjectWrapper(r_val))
      return (PyObject *) R_ExternalPtrAddr(r_val);
  else if (ATTRIB(r_val) != R_NilValue && (TYPEOF(r_val) != CHARSXP ||
			  TYPEOF(ATTRIB(r_val)) != CHARSXP))
	  // has genuine attributes
      return RyPromise_New(r_val, R_GlobalEnv);
  else //      return Rython_capsulate(r_val);
    return SEXP_toPyObject(r_val);
}

static int __promise_setattr(PyObject *self, char *attr, PyObject *value)
{
  defineVar(install(attr), RObject_wrapper(value), R_GlobalEnv);
  return 0;
}

// deprecated...
/*
static PyObject *__promise___dir__(PyObject *self, PyObject *obj)
{
	fprintf(stdout, "%s is called\n", __func__);
	return Py_None;
}
*/

/*
PyObject *__promise_descr_get(PyObject *self, PyObject *obj, PyObject *type)
{
	fprintf(stdout, "%s is called\n", __func__);
	Py_Print(self, "self");
	Py_Print(obj, "obj");
	Py_Print(type, "type");
	return Py_None;
}
*/

//static int __promise_setattr(PyObject *self, char *attr, PyObject *value);
static PyObject *__promise_dir(PyObject *self, PyObject *args)
{
	/*
	fprintf(stdout, "%s is called, self: %p\n", __func__, self);
	Py_Print(self, "self");
	*/
  Py_ssize_t n = PyTuple_Size(args); // must be 0
	/*
	fprintf(stdout, "n: %ld\n", n);
	for(int i=0; i<n; i++){
	  PyObject *obj = PyTuple_GetItem(args,i);
	  Py_Print(obj, "args");
	}
	*/
  if(RyPromise_CheckExact(self)){
    RyPromiseObject *obj = (RyPromiseObject *)self;
    SEXP expr= obj->r_expr;

    if(TYPEOF(expr) == ENVSXP){
	SEXP keys = PROTECT(R_lsInternal(expr, TRUE));
	n = LENGTH(keys);
	PyObject *list = PyTuple_New(n);
	for(int i=0; i<n; i++)
          PyTuple_SetItem(list, i,
			  Py_BuildValue("s", CHAR(STRING_ELT(keys,i))));
	return  list;
    } else { // See R: attrib.c # do_attributes
      SEXP attrs = ATTRIB(expr);
      //int nvalues = LENGTH(attrs);
      int n = length(attrs);
      SEXP namesattr = R_NilValue;
      if (isList(expr)) {
        namesattr = getAttrib(expr, R_NamesSymbol);
	if (namesattr != R_NilValue) n++;
      } 
      if(n <= 0) {// return Py_None;
        char buf[256];
        sprintf(buf, "r_type: %s, FIXME: %s:%d", type2char(TYPEOF(expr)),
		      __FILE__, __LINE__);
        PyErr_SetString(PyExc_NotImplementedError, buf);
        return NULL;
      }

      PyObject *list = PyTuple_New(n);
      n = 0;
      if (namesattr != R_NilValue) {
        PyTuple_SetItem(list, n,
		  Py_BuildValue("s", CHAR(PRINTNAME(R_NamesSymbol))));
        n++;
      }
      while (attrs != R_NilValue) {
        if (TAG(attrs) == R_RowNamesSymbol)
          PyTuple_SetItem(list, n,
		  Py_BuildValue("s", CHAR(PRINTNAME(R_RowNamesSymbol))));
	else if (TAG(attrs) == R_NilValue)
          PyTuple_SetItem(list, n,
		  Py_BuildValue("s", CHAR(R_BlankString)));
        else
          PyTuple_SetItem(list, n,
		  Py_BuildValue("s", CHAR(PRINTNAME(TAG(attrs)))));
        attrs = CDR(attrs);
        n++;
      }

      return  list;
    }
  } else {
    PyErr_SetString(PyExc_SystemError, "FIXME");
    return NULL;
  }
}

//static PyObject *__promise_as_int(PyObject *self, PyObject *args, PyObject *kwds)
static PyObject *__promise_as_int(PyObject *self, PyObject *args)
{
  //Py_ssize_t n = PyTuple_Size(args); // must be 0
	/*
  Py_Print(self, "self"); // must be 0
  Py_Print(args, "args"); tuple of positional arguments
  Py_Print(kwds, "kwds"); dict of keyword arguments
  fprintf(stdout, "\033[0;35m %s is called\033[0m\n", __func__);
  */

  if(RyPromise_CheckExact(self)){
    RyPromiseObject *obj = (RyPromiseObject *)self;
    if(obj->p_object)
	    return obj->p_object;

    SEXP expr = obj->r_expr;
    SEXP call = PROTECT(LCONS(install("as.integer"), CONS(expr, R_NilValue)));
    SEXP r_val = PROTECT(eval(call, R_GlobalEnv));
    obj->p_object = SEXP_toPyObject(r_val);
    UNPROTECT(2);
    return obj->p_object;

  } else {
    PyErr_SetString(PyExc_SystemError, "FIXME");
    return NULL;
  }
  return Py_None;
}

static PyObject *__promise_as_num(PyObject *self, PyObject *args)
{
  Py_ssize_t n = PyTuple_Size(args); // must be 0
  fprintf(stdout, "\033[0;35m %s is called, argc: %ld\033[0m\n", __func__, n);
  return Py_None;
}

/*
    //.tp_methods = __promise_methods,
static PyMethodDef __promise_methods[] = {
  {"__dir__",  __promise_dir, METH_VARARGS, "dir(object)"},
  {NULL, NULL, 0, NULL}   
};
*/

// Change its name...
static PyTypeObject Deprecated_RyPromiseObject_Type = {
    PyVarObject_HEAD_INIT(NULL, 0)
    .tp_name = "DeprecatedRyPromiseObject",
    .tp_basicsize = sizeof(RyPromiseObject),
    .tp_doc = "Promise objects",
    .tp_new = __promise_new,
    .tp_dealloc = (destructor)__promise_dealloc,
    .tp_repr = (reprfunc)__promise_repr,
    //.tp_str = NULL,
    //.tp_str = (reprfunc)__promise_repr,
    //.tp_getattr = __promise_getattr,
    //.tp_setattr = __promise_setattr,
    //.tp_descr_get = __promise_descr_get,
    //.tp_methods = __promise_methods,
};

// not called by _PyObject_New
PyObject *__promise_new(PyTypeObject *subtype, PyObject *args,
	       	PyObject *kwds)
{
  RyPromiseObject *obj =(RyPromiseObject *)
	  _PyObject_New(&RyPromiseObject_Type);

  obj->r_expr = NULL;
  obj->r_envir = NULL;
  obj->p_object = NULL;
  obj->name = NULL;
  obj->context = NULL;
  obj->m_ml = NULL;

  return (PyObject *) obj;
}

void RyPromise_setContext(PyObject *c, void *context)
{
  RyPromiseObject *obj =(RyPromiseObject *) c;
  obj->context = context;
}

static void RyPromise_finalizer(SEXP s)
{
  PyObject *p = (PyObject *) R_ExternalPtrAddr(s);
  Py_DECREF(p);
  // FIXME
}


PyObject *RyPromise_New(SEXP expr, SEXP env)
{
  PyObject *args = NULL;
  PyObject *c =  RyPromiseObject_Type.tp_new(&RyPromiseObject_Type,
		  args, NULL);
//  Py_Print(prom, "promise object");
  RyPromiseObject *obj =(RyPromiseObject *) c;
  obj->r_expr = expr;
  obj->r_envir = env;
  obj->p_object = NULL;

  obj->name = strdup(type2char(TYPEOF(expr)));
  //obj->name = "R_EXTPTRSXP";
//       PyObject *c =  PyCapsule_New(r_val, "R_EXTPTRSXP", NULL); // FIXME
//      Py_INCREF(c); // check: refcnt
//  fprintf(stderr, "return: %p, refcnt: %ld\n", c, Py_REFCNT(c));

  SEXP p = PROTECT(R_MakeExternalPtr(c, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(p, RyPromise_finalizer, TRUE);
  setAttrib(expr, install("RyPromise"), p);
  UNPROTECT(1);
  RyPromise_setContext(c, SEXP_toPyObject);
  return c;
}

#define RyPromise_Check(op) PyObject_TypeCheck(op, &RyPromiseObject_Type)

#endif


///            PyDoc_STRVAR

// list of PyObject
// deprecated. delete me
typedef struct py_node_struct {
  char *name;
  PyObject *object;
  struct py_node_struct *next;
} py_node_t;

typedef struct _struct_py {
  char *progname;
  py_node_t *module_list;
  py_node_t *dict_list; // lock...
} py_runtime_t; // experimental... namespace list?

py_runtime_t __Rython_runtime = {"Rython", NULL, NULL};
py_runtime_t *Rython_runtime = &__Rython_runtime;


void Rython_printError(PyObject *err);
void __Rython_error(PyObject *err, const char* func, int line);
#define Rython_error(err) __Rython_error((err), __func__, __LINE__)

void Py_Print(PyObject *p, const char *prefix)
{
  if(!p) {
	       	fprintf(stdout, "%s:\n(null)\n", prefix);
		return;
  }

//  { if(PyType_Check(p)) { fprintf(stdout, "Type Object\n"); } }

  /*
  if(PyErr_Occurred()){
	       	fprintf(stdout, "PyErr_Occurred\n");
		return;
  }
  */
  PyTypeObject *t = Py_TYPE(p);
  fprintf(stdout, "\033[0;33m(prefix: %s, type: ", prefix);
//  fprintf(stdout, "\033[0;33m(prefix: %s, type (->str <%p>): ", prefix, t->tp_str);
  /*
  {
    fprintf(stdout, "\033[0;33m Py_TYPE(t): %p\n", Py_TYPE(t)); // NULL?
    fprintf(stdout, "\033[0;33m Py_TYPE(t)->tp_repr: %p\n",Py_TYPE(t)->tp_repr);
    fprintf(stdout, "\033[0;33m t->ob_type: %p\n",((PyObject*)t)->ob_type);
    fprintf(stdout, "\033[0;33m t->ob_type->tp_repr: %p\n", 
		    ((PyObject*)t)->ob_type->tp_repr);

	  PyObject_Repr((PyObject*)t);
	  PyObject_Str( (PyObject*)t);
  }
  */
  PyObject_Print((PyObject *)t, stdout, Py_PRINT_RAW);
  fprintf(stdout, ", refcnt: %ld)\033[0m\n", Py_REFCNT(p));
  PyObject_Print(p, stdout, Py_PRINT_RAW);
  fprintf(stdout, "\n");
}

// FIXME
py_node_t *Runtime_getModulelist()
{
  return Rython_runtime->module_list;
}
py_node_t *Runtime_getDictlist()
{
  return Rython_runtime->dict_list;
}

static PyObject *Rython_addModule(PyObject *module, const char *name)
{
  py_node_t *node = (py_node_t *) malloc(sizeof(py_node_t));
  node->name = strdup(name);
  node->object = module;
  node->next   = Rython_runtime->module_list;
  Rython_runtime->module_list = node;
  Py_INCREF(module);
  return module;
}
static PyObject *Rython_addDict(PyObject *dict, const char *name)
{
  py_node_t *node = (py_node_t *) malloc(sizeof(py_node_t));
  node->name = strdup(name);
  node->object = dict;
  node->next   = Rython_runtime->dict_list;
  Rython_runtime->dict_list = node;
  Py_INCREF(dict);
  return dict;
}


static int dumper_iterm = TRUE;

static void Rython_dumper()
{

	return;
	/*
  supr_thread_t *cth = currentThread();
  fprintf(stdout, "[%d %d] module_list:\n", cth->pid, cth->tid);

  int i=0;
  for(py_node_t *ml=Rython_runtime->module_list; ml; ml=ml->next) {
    fprintf(stdout, "%d. <%p> name: %s, file name: %s\n", ++i, ml->object,
		    PyModule_GetName(ml->object),
		    PyModule_GetFilename(ml->object)
		    );
    PyObject_Print(ml->object, stdout, Py_PRINT_RAW);

    if(dumper_iterm){
       PyObject *dict   = PyModule_GetDict(ml->object);
       SEXP r_obj = PROTECT(PyObject_toROject(dict));
       fprintf(stdout, "\n\033[0;32m");
       PrintValue(r_obj);
       fprintf(stdout, "\033[0m");
       UNPROTECT(1);
    }
  }
  fprintf(stdout, "\n");

  fprintf(stdout, "[%d %d] dict_list:\n", cth->pid, cth->tid);
  i=0;
  for(py_node_t *ml=Rython_runtime->dict_list; ml; ml=ml->next) {
    fprintf(stdout, "%d. <%p> name: %s\n", ++i, ml->object,
		    PyModule_GetName(ml->object));
     //fprintf(stdout, "\n%4d: %s ", ++i, PyDict_GetName(ml->object));
    PyObject_Print(ml->object, stdout, Py_PRINT_RAW);

    if(dumper_iterm){
       PyObject *dict   = ml->object;
       if(PyDict_Check(dict)){
         SEXP r_obj = PROTECT(PyObject_toROject(dict));
         fprintf(stdout, "\n\033[0;32m");
         PrintValue(r_obj);
         fprintf(stdout, "\033[0m");
         UNPROTECT(1);
       } else {
         fprintf(stdout, "FIXME (%s:%d)\n\033[0m", __FILE__, __LINE__);
       }
    }
  }
  fprintf(stdout, "\n");
  */

}


//Check PyRun_* and PyEval_* ???

SEXP PyObject_toROject(PyObject *obj)
{
  if(!obj || obj == Py_None)
    return R_NilValue;

  static SEXP PythonSEXP = NULL;
  if(!PythonSEXP) PythonSEXP = install("PyObject");

  SEXP ret = R_NilValue;
  if(PyUnicode_Check(obj)) {
    char *cstr;
//    PyArg_Parse(obj, "s", &cstr); // free???
    PyArg_ParseTuple(obj, "s", &cstr); // free???
    return mkString(cstr);
  } else if(PySequence_Check(obj)){

    size_t n = PySequence_Size(obj);
//    fprintf(stdout, "PySequence ... size: %ld\n", n);
    if(n==0) return allocVector(VECSXP,0);

    PyObject *elem = PySequence_GetItem(obj, 0);
    if(PyUnicode_Check(elem)) {
      ret = PROTECT(allocVector(STRSXP, n));
      for(size_t i=0; i<n; i++) {
        PyObject *elem = PySequence_GetItem(obj, i);
        char *cstr;
        PyArg_Parse(elem, "s", &cstr);
        SET_STRING_ELT(ret, i, mkChar(cstr));
      }
      UNPROTECT(1);
      return ret;
    } else  if(PyFloat_Check(elem)){ //printf("PyFloat\n");
      ret = PROTECT(allocVector(REALSXP, n));
      for(size_t i=0; i<n; i++)
         PyArg_Parse(PySequence_GetItem(obj, i), "d", REAL(ret)+i);
      UNPROTECT(1);
      return ret;
    } else if(PyNumber_Check(elem)){
      ret = PROTECT(allocVector(INTSXP, n));
      for(size_t i=0; i<n; i++)
         PyArg_Parse(PySequence_GetItem(obj, i), "i", INTEGER(ret)+i);
      UNPROTECT(1);
      return ret;
    } else {

    fprintf(stdout, "TODO (%s:%d) ...\n", __FILE__, __LINE__);
	    
//__Py_Print(Py_TYPE(elem), "\033[0;31melem TYPE\033[0m");
//__Py_Print(obj, "obj: Sequence");

    }


  } else if(PyList_Check(obj)){
    size_t n = PyList_Size(obj);
    fprintf(stdout, "PyList ... size: %ld\n", n);
    ret = PROTECT(allocVector(VECSXP, n));
    for(size_t i=0; i<n; i++) 
       SET_VECTOR_ELT(ret, i, PyObject_toROject(PyList_GetItem(obj, i)));
    UNPROTECT(1);
    return ret;

  } else if(PyNumber_Check(obj)){
    //fprintf(stdout, "PyNumber ...\n");
    if(PyFloat_Check(obj)){ printf("PyFloat\n");
      double val;
      PyArg_Parse(obj, "d", &val);
      return ScalarReal(val);

    } else if(PySequence_Check(obj)) {
          fprintf(stderr, "FIXME : Py... Sequence to SEXP\n");
      size_t n = PySequence_Size(obj);
      if(n ==0) return null;
      //PyObject *item = PySequence_GetItem(obj, 0);
      ret = PROTECT(allocVector(REALSXP, n));
      for(size_t i=0; i<n; i++)
         PyArg_Parse(PySequence_GetItem(obj, i), "d", REAL(ret)+i);
      UNPROTECT(1);
      return ret;

    } else if(PyTuple_Check(obj)) {
            printf("Py... Tuple\n");
    } else { // printf("Py... int\n");
      int val;
      PyArg_Parse(obj, "i", &val);
      return ScalarInteger(val);
    }

  } else if(PyDict_Check(obj)){
    size_t size = PyDict_Size(obj); //PyObject *keys = PyObject_Dir(obj);
    fprintf(stdout, "PyDict ... size: %ld\n", size);
    if(size == 0)
      return allocVector(VECSXP, 0);
    
    PyObject *keys = PyDict_Keys(obj);
    if(PyList_Check(keys)) PyList_Sort(keys);
    //printf("PySequence_Check(keys) = %d\n", PySequence_Check(keys));
    ret = PROTECT(allocVector(VECSXP, size));
    SEXP names = PROTECT(allocVector(STRSXP, size));
    char *key_str;
    const char *value_str;
    for(int i=0; i<size; i++){ // FIXME
       PyObject *key = PySequence_GetItem(keys, i);
       PyArg_Parse(key, "s", &key_str);
       PyObject *value = PyDict_GetItem(obj, key);
       fprintf(stdout, "[%d] key: %p, key_str: %s", i, key, key_str);
       /*
       {
       PyObject *repr = PyObject_Repr(value);
       PyArg_Parse(repr, "s", &value_str);

       //value_str = PyString_AsString(repr); // ???

       fprintf(stderr, " %s", value_str);
       }
       */
       //{
         PyTypeObject *type = Py_TYPE(value);
	 fprintf(stdout, "PyTypeObject. tp_name: %s\n", type->tp_name);
	 fprintf(stdout, "\t\033[0;33m]tp_doc: %s\n", type->tp_doc);
       //}
       fprintf(stdout, "\033[0m\n");
       SET_STRING_ELT(names, i, mkChar(key_str));
       SEXP rv = PROTECT(R_MakeExternalPtr(value, R_NilValue, R_NilValue));
       //setAttrib(rv, R_ClassSymbol, mkString("PythonObject")); // FIXME
       setAttrib(rv, R_ClassSymbol, mkString(type->tp_name)); // FIXME


       SET_VECTOR_ELT(ret, i, rv);
       UNPROTECT(1);
    }
    setAttrib(ret, R_NamesSymbol, names);
    fprintf(stdout, "PyDict ... Return\n");
    UNPROTECT(2);
    return ret;

  } else if(PyModule_Check(obj)){
    fprintf(stdout, "PyModule ...\t -> PyObject_Dir(obj):\n");
    return PyObject_toROject(PyObject_Dir(obj));
  } else if(PyCallable_Check(obj)){

	  /*
    SEXP func_body = PROTECT(LCONS(install(".Call"),
         CONS(mkString("Rython_doCall"), //R_NilValue
		 CONS(install("what"),
		      CONS(
		      LCONS(install("list"), CONS(install("..."), R_NilValue)),
			      R_NilValue)))));
    SEXP formals = PROTECT(CONS(R_MissingArg, CONS(py_func, R_NilValue)));
    SET_TAG(formals, install("..."));
    SET_TAG(CDR(formals), install("what"));
    */
    SEXP py_func = PROTECT(R_MakeExternalPtr(obj, R_NilValue, R_NilValue));
    setAttrib(py_func, R_ClassSymbol, mkString("PyObject"));
    // add finalizer ...

    SEXP formals = PROTECT(CONS(R_MissingArg, R_NilValue));
    SET_TAG(formals, install("..."));
    SEXP func_body = PROTECT(LCONS(install(".Call"),
         CONS(mkString("Rython_doCall"), //R_NilValue
		 CONS(py_func, //install("what"),
		      CONS(
		      LCONS(install("list"), CONS(install("..."), R_NilValue)),
			      R_NilValue)))));
    SEXP do_call = PROTECT(allocSExp(CLOSXP));
    SET_FORMALS(do_call, formals);
    SET_BODY(do_call, func_body);
    SET_CLOENV(do_call, R_GlobalEnv);
    UNPROTECT(4);
    return do_call;
  }

  Py_INCREF(obj);
  Py_INCREF(obj); // why?

  // why
  ret = PROTECT(R_MakeExternalPtr(obj, PythonSEXP, null));
  PyObject *repr = PyObject_Repr(obj);
  const char *value_str;
  PyArg_Parse(repr, "s", &value_str);
  setAttrib(ret, install(">>>"), PROTECT(mkString(value_str)));

  UNPROTECT(2);
  return ret;


}

static PyObject *Rython_findObject(const char *obj_name)
{
  //const char *obj_name = CHAR(asChar(r_name));
  PyObject *sys_module = PyImport_AddModule("sys");
  PyObject *sys_dict   = PyModule_GetDict(sys_module);

  PyObject *local_dict  = PyDict_GetItemString(sys_dict, "supr_local_dict");
  PyObject *global_dict = PyDict_GetItemString(sys_dict, "supr_global_dict");

  PyObject *main_module = PyImport_AddModule("__main__");
  PyObject *main_dict = PyModule_GetDict(main_module);

  PyObject *sm_dict = PyDict_GetItemString(sys_dict, "modules");
  PyObject *obj = NULL;

  int len = strlen(obj_name);
  char buffer[len+1];

  PyObject *dicts[] = {local_dict, global_dict, main_module,
          PyImport_AddModule("builtins"),
          PyImport_AddModule("sys"),
          NULL};

  int d = 0;
  PyObject *dict = dicts[0];
  for(; dict; dict = dicts[++d]) {
    if(PyModule_Check(dict)) dict = PyModule_GetDict(dict);
    sprintf(buffer, "%s", obj_name);
    char obj_buffer[len+1];

    char *s = buffer;
    while(s){
//        printf("[%d] %s\n", d, s);
      if(obj = PyDict_GetItemString(dict, s)) break;
      int i = strlen(s) - 1;
//        printf("[%d] <%p>\n", i, obj);
      for(; i>=0; i--) {
        if(buffer[i] == '.'){
          memcpy(obj_buffer, buffer, strlen(obj_name)+1);
          obj_buffer[i] = 0;
          s = obj_buffer;
          if(strlen(s)==0) s = NULL;
          break;
        }
      }
      if(i<0) break;
    }

    if(!obj) continue;

    if(strlen(s) < len){
      sprintf(buffer, "%s", obj_name+strlen(s)+1);
      sprintf(buffer, "%s", obj_name+strlen(s)+1);
//    printf("\n\033[0;33mbuffer = %s, ", buffer);
      char *t = buffer;
      while(strstr(t, ".")){
        for(int i=0; i<strlen(t); i++){
          if(t[i]=='.'){
              t[i] = 0;
              obj = PyObject_GetAttrString(obj, t);
              if(!obj) return NULL;
              /*
    printf("\n\033[0;34mobject, ");
              printf("t = %s\n", t);
    PyObject_Print(obj, stdout, Py_PRINT_RAW);
    printf("\033[0m\n\n");
    */
              t += i+1;
              break;
          }
        }
      }
      obj = PyObject_GetAttrString(obj, t);
    }
    break;
  }

  return obj;

//  return R_NilValue;
}

//SEXP Rython_findObject(SEXP r_name)
SEXP Rython_findVar(SEXP r_name)
{
  PyObject *py_obj = Rython_findObject(CHAR(asChar(r_name)));
  return PyObject_toROject(py_obj);
}

//SEXP 
// PyErr_Clear();
// PyUnicode_FromString((const char)key);
SEXP Rython_help(SEXP wrapped)
{
  if(wrapped == R_NilValue) return R_NilValue;

  if(!Rython_isPyObjectWrapper(wrapped))
    error(_("invalid argument, not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(wrapped);

  Py_Print(obj, "obj"); // Py_Show??
  if(!obj) return R_NilValue;

  PyObject *doc = PyObject_GetAttrString(obj, "__doc__");
  if(doc){
    fprintf(stdout, "__doc__: \033[0;32m\n");
    Py_Print(doc, "__doc__");
    fprintf(stdout, "\033[0m\n");
  }

  if(PyMethod_Check(obj)){
    fprintf(stdout, "Method\n");
    Py_Print(PyFunction_GetModule(obj), "Method");
  }

  if(PyFunction_Check(obj)){
    //PyObject* PyFunction_GetGlobals(PyObject *op);
    //PyObject* PyFunction_GetModule(PyObject *op);
    fprintf(stdout, "In module:");
    Py_Print(PyFunction_GetModule(obj), "In module");
    error(_("not implemented"));
  } else if(PyCFunction_Check(obj)){
    fprintf(stdout, "\033[0;32mPyCFunction\n");
    fprintf(stderr, "\t\t\033[0;33mname: %s",PyEval_GetFuncName(obj));
    fprintf(stderr, "PyEval_GetFuncDesc: (%s)\n\033[0m",
		    PyEval_GetFuncDesc(obj));
    fprintf(stderr, "\t\t\033[0;33m%s%s\n\033[0m",PyEval_GetFuncName(obj),
		    PyEval_GetFuncDesc(obj));
    //PyEval_GetBuiltins()
    // PyEval_GetGlobals()
    // PyEval_GetFrame()
    // PyEval_GetGlobals()
    //PyObject *func = PyCFunction_GET_FUNCTION(globals_func);
    //PyObject *val = PyObject_CallFunctionObjArgs(globals_func, NULL);
    //PyObject_Print(val, stdout, Py_PRINT_RAW); fprintf(stdout, "\n ^ PyObject_CallFunctionObjArgs\n");

    PyObject *self = PyCFunction_GET_SELF(obj);
    Py_Print(self, "function->self");
    //PyObject *func = PyCFunction_GET_FUNCTION(obj);
    PyCFunction func = PyCFunction_GET_FUNCTION(obj);
    // typedef PyObject *(*PyCFunction)(PyObject *, PyObject *);
    //Py_Print((PyObject *)func, "function->ml_meth");

    //obj: ptr to PyCFunctionObject
    {
      PyCFunctionObject *cfunc = (PyCFunctionObject *) obj;
      Py_Print((PyObject *)cfunc->m_module, "cfunc->m_module");
      PyMethodDef *m_ml = cfunc->m_ml;
      fprintf(stdout, "cfunc->m_ml->ml_name: %s", cfunc->m_ml->ml_name);

    }
  }

  return R_NilValue;
}

static const char *Rython_getDoc(PyObject *obj)
{
    PyFunctionObject *func = NULL;

  if (PyMethod_Check(obj)){ // PyMethodObject
    __Py_Print(obj, "PyMethod:\n");
        PyMethodObject *meth = (PyMethodObject *) obj;
        return Rython_getDoc(meth->im_func);
  } else if (PyFunction_Check(obj)) { // PyFunctionObject
    __Py_Print(obj, "PyFunction:\n");
// see funcobject.h
        func = (PyFunctionObject*) obj;

//      return func->func_doc;
        PyObject *repr = PyObject_Repr(func->func_doc);
        const char *doc_str;
        PyArg_Parse(repr, "s", &doc_str);
        return doc_str; // free??? double check ...
  } else if (PyCFunction_Check(obj)) { // PyCFunctionObject
//    Py_Print(obj, "PyCFunction:\n");
//PyObject_HEAD
//PyMethodDef *m_ml; Description of the C function to call
//PyObject    *m_self;Passed as 'self' arg to the C func, can be NULL
//PyObject    *m_module; /* The __module__ attribute, can be anything */
//PyObject    *m_weakreflist; /* List of weak references */
    PyMethodDef *m_ml = ((PyCFunctionObject*)obj)->m_ml;
// onst char  *ml_name;
// PyCFunction ml_meth;
// int         ml_flags;
// const char  *ml_doc;
    return m_ml->ml_doc;
  } else {

        PyObject *repr = PyObject_Repr(obj);
        const char *doc_str;
        PyArg_Parse(repr, "s", &doc_str);
        return doc_str;
  }
}

SEXP Rython_dir(SEXP r_name)
{
  //return PyObject_toROject(pDic);

  { // list PySys_ objects???
    PyObject *my_global = PySys_GetObject("supr_global_dict");
    printf("my_global: %p\n", my_global);
    PyObject *obj = PySys_GetObject("jnk---jnk");
    printf("jnk---jnk: %p\n", obj);
  }
  return R_NilValue;
}

// FIXME
PyObject *Rython_globals()
{
  PyObject *dict = (PyObject*) pthread_getspecific(rythonThreadKey);
  return dict;
}

// FIXME
void Rython_locals_cend(void *data)
{
   PyObject *dict = (PyObject *) data;
   Py_XDECREF(dict);
}
PyObject *Rython_locals()
{
	return NULL;

//     SEXP currentEnv = R_GlobalContext->sysparent;
     fprintf(stdout, "\n\033[0;33m==== %s ====\033[0m\n", __func__);
     PyObject *dict = NULL;
     RCNTXT *cntxt = R_GlobalContext;
     if(cntxt->sysparent == R_GlobalEnv) return NULL;

     int skip = TRUE;
     for(; cntxt; cntxt = cntxt->nextcontext){

       fprintf(stdout, "callfun: the function, if this was a closure\n");
       PrintValue(cntxt->callfun);
       fprintf(stdout, "cloenv: for closures, the env of the closure\n");
       PrintValue(cntxt->cloenv);
       fprintf(stdout, "sysparent: the env the closure was called from\n");
       PrintValue(cntxt->sysparent);
       fprintf(stdout, "[%s] cend: %p\n", cntxt->cend ? " " :
		       "\033[0;31m*\033[0m", cntxt->cend);
       fprintf(stdout, "cenddata: %p\n", cntxt->cenddata);
       fprintf(stdout, "\n");

       if(cntxt->callfun == R_NilValue)  // called from R_BaseEnv
	       continue;
       else if(skip){ // skip the R wrapper closure of the Rython function
	       skip = FALSE;
	       continue;
       }

       if(!cntxt->cend){
         dict = PyDict_New();
	 Py_XINCREF(dict);
         cntxt->cenddata = dict;
         cntxt->cend = Rython_locals_cend;
	 break;
       } else if(cntxt->cend == Rython_locals_cend){
         dict = (PyObject *) cntxt->cenddata;
	 break;
       }
     }
     fprintf(stdout, "\033[0;33m==== %s: RETURN %p ====\033[0m\n\n",
		     __func__, dict);
     return dict;
}

// no ...
void Rython_removeLocals()
{
//     SEXP currentEnv = R_GlobalContext->sysparent;
     fprintf(stdout, "\n\033[0;33m==== %s ====\033[0m\n", __func__);
     PyObject *dict = NULL;
     RCNTXT *cntxt = R_GlobalContext;
     if(cntxt->sysparent == R_GlobalEnv) return;

     int skip = TRUE;
     for(; cntxt; cntxt = cntxt->nextcontext){

       fprintf(stdout, "callfun: the function, if this was a closure\n");
       PrintValue(cntxt->callfun);
       fprintf(stdout, "cloenv: for closures, the env of the closure\n");
       PrintValue(cntxt->cloenv);
       fprintf(stdout, "sysparent: the env the closure was called from\n");
       PrintValue(cntxt->sysparent);
       fprintf(stdout, "[%s] cend: %p\n", cntxt->cend ? " " :
		       "\033[0;31m*\033[0m", cntxt->cend);
       fprintf(stdout, "cenddata: %p\n", cntxt->cenddata);
       fprintf(stdout, "\n");

       if(cntxt->callfun == R_NilValue)  // called from R_BaseEnv
	       continue;
       else if(skip){ // skip the R wrapper closure of the Rython function
	       skip = FALSE;
	       continue;
       }

       if(cntxt->cend == Rython_locals_cend){
         dict = (PyObject *) cntxt->cenddata;
         Rython_locals_cend(dict);
	 break;
       }
     }
     fprintf(stdout, "\033[0;33m==== %s: REMOVED %p ====\033[0m\n\n",
		     __func__, dict);
}

// raise: 1 error, 0, warning
// FIXME
void Rython_checkError(int raise)
{
  PyObject *err = PyErr_Occurred();
  if(!err)
	  return;
  if(raise)
    Rython_error(err);
  else {
    Rython_printError(err);
    PyErr_Clear();
  }
}

void Rython_checkInit()
{
  if( ! Py_IsInitialized() )
	  error(_("python is not initialized"));
  {
     SEXP currentEnv = R_GlobalContext->sysparent;
     PrintValue(currentEnv);
     PrintValue(R_GlobalEnv);

     RCNTXT *cntxt = R_GlobalContext;
     for(; cntxt; cntxt = cntxt->nextcontext){
       fprintf(stdout, "callfun: the function, if this was a closure\n\t");
       PrintValue(cntxt->callfun);
       fprintf(stdout, "cloenv: for closures, the env of the closure\n\t");
       PrintValue(cntxt->cloenv);
       fprintf(stdout, "sysparent: the env the closure was called from\n\t");
       PrintValue(cntxt->sysparent);
       fprintf(stdout, "cend: %p\n", cntxt->cend);
       fprintf(stdout, "cenddata: %p\n", cntxt->cenddata);
       fprintf(stdout, "\n");
     }
  }
}

/**
 * PyObject* PyImport_ImportModuleEx(const char *name, PyObject *globals, PyObject *locals, PyObject *fromlist)
 *
 * Return value: New reference.
 * 
 * Import a module. This is best described by referring to the built-in Python function __import__().  
 * 
 * The return value is a new reference to the imported module or top-level package, or NULL with an exception set on failure. Like for __import__(), the return value when a submodule of a package was requested is normally the top-level package, unless a non-empty fromlist was given.
 *
**/

/*import_stmt:    "import" module ["as" name] ("," module ["as" name] )* 
              | "from" module "import" identifier ["as" name]
                ("," identifier ["as" name] )*
              | "from" module "import" "*" 
module:         (identifier ".")* identifier
*/

/* R: import <- function(what = "*", as = NULL, from = NULL)
   R: import <- function(what = NULL, as = NULL, from = NULL)
 */

//SEXP Rython_import(SEXP r_name, SEXP as, SEXP r_from)
SEXP Rython_import(SEXP r_what, SEXP r_as, SEXP r_from)
{
  Rython_checkInit();

//            PyErr_SetNone(SuprError);

  PyObject *globals = Rython_globals();
  PyObject *locals = Rython_locals();

  PyObject *dest = locals ? locals : ( globals ? globals :
		  PyModule_GetDict(PyImport_AddModule("__main__")));
  PyErr_Clear();

  PyObject *from_module = NULL;
  PyObject *from_dict = NULL;
  if(r_from != R_NilValue){
    if(Rython_isPyObjectWrapper(r_from)){
      from_module = (PyObject *) R_ExternalPtrAddr(r_from);
    } else {
      const char * from = CHAR(asChar(r_from));
      from_module = PyImport_Import(Py_BuildValue("s", from));
      Rython_checkError(TRUE);
    }
    from_dict = PyModule_GetDict(from_module);
  }

  if(r_what == R_NilValue) { // the what = "*" case
    if(r_from == R_NilValue) error(_("nothing to import"));
    if(r_as != R_NilValue) warning(_("'as' is ignored"));

    /*
    PyObject *module = from_module;
    PyObject *module = NULL;
    if(Rython_isPyObjectWrapper(r_from)){
      module = (PyObject *) R_ExternalPtrAddr(r_from);
    } else {
      const char * from = CHAR(asChar(r_from));
      module = PyImport_Import(Py_BuildValue("s", from));
      Rython_checkError(TRUE);
    }
    */

    //PyObject *dict = PyModule_GetDict(module);
    PyObject *keys = PyDict_Keys(from_dict);
    Rython_checkError(TRUE);

    Py_ssize_t n = PyList_Size(keys);
    for(int i=0; i < n; i++){
      PyObject *key = PyList_GetItem(keys, i); //Py_Print(key, "key");
      PyObject *val = PyDict_GetItem(from_dict, key); //Py_Print(val, "val");
      PyDict_SetItem(dest, key, val);
    }
    return RObject_wrapper(dest);
  }

  if(r_as == R_NilValue) r_as = r_what;

  if(TYPEOF(r_what) != STRSXP || TYPEOF(r_as) != STRSXP)
	  error(_("invalid arguments"));

  int n = LENGTH(r_what);
  PyObject *val = NULL;

  for(int i=0; i<n; i++){
    const char *name = CHAR(STRING_ELT(r_what, i));
    const char *as = CHAR(STRING_ELT(r_as, i));

    if(r_from == R_NilValue){ //module = PyImport_ImportModule(name);
      val = PyImport_Import(Py_BuildValue("s", name));
    } else {
      val = PyDict_GetItemString(from_dict, name);
    }
    PyDict_SetItemString(dest, as, val);
  }

  Rython_checkError(TRUE);

  return RObject_wrapper( n==1 ? val : dest );

	/*
  //if( !Py_initialized)
  if( ! Py_IsInitialized() )
  { // testing
    Py_Initialize();
//    Py_initialized = TRUE;
    fprintf(stderr, "Py_IsInitialized: %d\n", Py_IsInitialized());

    PyObject *pName, *pModule;

    //pName = PyUnicode_DecodeFSDefault("numpy");
    pName = PyUnicode_DecodeFSDefault("sys");
    fprintf(stdout, "pName: %p, PyObject_Print:\033[0;35m\n", pName);

    if(PyErr_Occurred()){
      PyErr_Print();
      PyErr_Clear();
    } else {
      PyObject_Print(pName, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\033[0m\n");
    }
    
    pModule = PyImport_Import(pName);
    if(PyErr_Occurred()){
      PyErr_Print();
    }
    Py_DECREF(pName);

    fprintf(stdout, "pModule: %p, PyObject_Print:\033[0;35m\n", pModule);
   
    PyObject_Print(pModule, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\033[0m\n");

  }


  PyObject *pModule = NULL;
  const char *name = CHAR(asChar(r_name));
  const char *from = CHAR(asChar(r_from));
  if(name){
    PyObject *globals = NULL; // PyDict_New();
    PyObject *locals = NULL;  //PyDict_New();
    PyObject *fromlist = NULL; // for now
    pModule = PyImport_ImportModuleEx(name, globals, locals, fromlist);
    __Py_Print(pModule, "import from");
    if(PyErr_Occurred()) {
      PyErr_Print(); // for now
      PyErr_Clear();
//      Py_XDECREF(pName);
      error(_("Python Error Occurred"));
      //Py_XDECREF(pModule);
    }

    {
       SEXP val = PyObject_toROject(pModule);
       PrintValue(val);
    }

    py_node_t *ml = (py_node_t *)malloc(sizeof(py_node_t));
    ml->object = pModule;
    ml->next = Rython_runtime->module_list;
    Rython_runtime->module_list = ml;

  }

  int i=0;
  for(py_node_t *ml=Rython_runtime->module_list; ml; ml=ml->next) {
     fprintf(stdout, "\n%4d: %s ", ++i, PyModule_GetName(ml->object));
     PyObject_Print(ml->object, stdout, Py_PRINT_RAW);
  }
  fprintf(stdout, "\n");

  SEXP retval = PROTECT(R_MakeExternalPtr(pModule, R_NilValue, R_NilValue));
  setAttrib(retval, R_ClassSymbol, mkString("PythonModule"));
  UNPROTECT(1);

  return retval;
  */
}

static PyObject *SEXP_toPyObject(SEXP s)
{
  static SEXP PythonSEXP = NULL;
  if(!PythonSEXP) PythonSEXP = install("PyObject");


  PyObject *obj;
  if(s == R_NilValue)
    return Py_None; // return NULL;
  else if(TYPEOF(s) == LISTSXP){
    int n=0;
    for(SEXP t = s; t != R_NilValue; t = CDR(t)) n++;
    obj = PyTuple_New(n);
    n = 0;
    for(SEXP t = s; t != R_NilValue; t = CDR(t)) {
      PyTuple_SetItem(obj, n++, SEXP_toPyObject(CAR(t)));
    }
    return obj;
  } else if (TYPEOF(s) == REALSXP){
    if (LENGTH(s)==1){
      obj = PyFloat_FromDouble(REAL(s)[0]);
      return obj;
    } else { // ???

      PyObject *list = PyList_New(LENGTH(s));
      for (size_t i = 0; i < LENGTH(s); i++) {
        PyList_SET_ITEM(list, i, PyFloat_FromDouble(REAL(s)[i]));
      }
      return list;
    }
  } else if (TYPEOF(s) == INTSXP){
    if (LENGTH(s)==1){ //fprintf(stderr, "INTSXP, LENGTH(s)==1\n");
      obj =  Py_BuildValue("i", INTEGER(s)[0]);
      //PyObject_Print(obj, stdout, Py_PRINT_RAW); fprintf(stdout, "\n%s\n", __func__); fprintf(stderr, "INTSXP, LENGTH(s)==1\n");
      return obj;
    } else {
      PyObject *list = PyList_New(LENGTH(s));
      for (size_t i = 0; i < LENGTH(s); i++)
        PyList_SET_ITEM(list, i, Py_BuildValue("i", INTEGER(s)[i]));
      return list;
    }
  } else if (TYPEOF(s) == SYMSXP){
    PyObject *obj =  Rython_findObject(CHAR(PRINTNAME(s)));
    if(!obj) error(_("Python cannot find object '%s'"), CHAR(PRINTNAME(s)));
    return obj;
  } else if (TYPEOF(s) == EXTPTRSXP && R_ExternalPtrTag(s) == PythonSEXP){
    PyObject *obj = R_ExternalPtrAddr(s);
    //CHECK_REFCNT(obj);
    //_Py_CHECK_REFCNT(obj);
    Py_INCREF(obj); // for now CHECK REFCNT?
    return obj;
  } else if (TYPEOF(s) == STRSXP){
    size_t n = LENGTH(s);
    if(n==0) return PyList_New(0);
    if(n==1){
      return PyUnicode_DecodeFSDefault(CHAR(STRING_ELT(s,0)));
    } else {
      PyObject *list = PyList_New(n);
      for (size_t i = 0; i < n; i++)
              PyList_SET_ITEM(list, i, Py_BuildValue("s",
                                     CHAR(STRING_ELT(s, i))));
      return list;
    }
  } else if(TYPEOF(s) == PROMSXP){
    SEXP v = PROTECT(eval(s, R_GlobalEnv)); // FXIME: env
    PyObject *p = SEXP_toPyObject(v);
    UNPROTECT(1);
    return p;
  } else if(TYPEOF(s) == CLOSXP){ // capsulate and SetName ...
    PyObject *p = PyCapsule_New(s, "R_CLOSXP", NULL); // FIXME: protect
    return p;
  } else if(TYPEOF(s) == BUILTINSXP){
    PyObject *p = PyCapsule_New(s, "R_BUILTINSXP", NULL);
    return p;
  } else if(TYPEOF(s) == SPECIALSXP){
    PyObject *p = PyCapsule_New(s, "R_SPECIALSXP", NULL);
    return p;
  } else if(TYPEOF(s) == EXPRSXP){
    PyObject *p = PyCapsule_New(s, "R_EXPRSXP", NULL);
    return p;
  } else if(TYPEOF(s) == LANGSXP){
    PyObject *p = PyCapsule_New(s, "R_LANGSXP", NULL);
    return p;
  }

  error(_("SEXP_toPyObject (%s): not fully implemented"),
                  type2char(TYPEOF(s)));
  return NULL;
}

static void RObject_wrapper_finalizer(SEXP s)
{
  PyObject *p = (PyObject *) R_ExternalPtrAddr(s);
  Py_DECREF(p);
}

SEXP RObject_wrapper(PyObject *p)
{
  SEXP retval = PROTECT(R_MakeExternalPtr(p, R_NilValue, R_NilValue));
  Py_INCREF(p);
  R_RegisterCFinalizerEx(retval, RObject_wrapper_finalizer, TRUE);

  SEXP klass = PROTECT(allocVector(STRSXP, 2));
      SET_STRING_ELT(klass, 0, mkChar("PyObject"));
      PyTypeObject *type = Py_TYPE(p);
  SET_STRING_ELT(klass, 1, mkChar(type->tp_name));
  setAttrib(retval, R_ClassSymbol, klass);
  UNPROTECT(2);
  return retval;
}

// FIXME
static int Rython_isPyObjectWrapper(SEXP where)
{
  if(TYPEOF(where) != EXTPTRSXP) return 0;

  SEXP klass = getAttrib(where, R_ClassSymbol);
  if(klass == R_UnboundValue) return 0;

  int i=0;
  for(; i < LENGTH(klass); i++)
	  if(strcmp(CHAR(STRING_ELT(klass, i)), "PyObject")==0)
		  break;
  if(i >= LENGTH(klass)) return 0;
  return 1;
}

static int __PyFunction_Check(PyObject *obj)
{
    return PyFunction_Check(obj);
}
static int __PyCFunction_Check(PyObject *obj)
{
    return PyCFunction_Check(obj);
}
static int __PyMethod_Check(PyObject *obj)
{
    return PyMethod_Check(obj);
}
static int __PyCallable_Check(PyObject *obj)
{
    return PyCallable_Check(obj);
}

SEXP Rython_getAttrNames(SEXP object, SEXP r_mode)
{
  if(!Rython_isPyObjectWrapper(object))
    error(_("invalid argument, not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(object);

  /*
  fprintf(stdout, "%s\n", __func__);
  PyObject_Print(obj, stdout, Py_PRINT_RAW);
  fprintf(stdout, "\n%s\n", __func__);
  */

  PyObject *attrs = PyObject_Dir(obj);
  const char *mode = CHAR(asChar(r_mode));
  Py_Print(attrs, "attrs");
  if(!attrs) return R_NilValue;

  int (*check)(PyObject *) = NULL;

  if(strcmp(mode, "func")==0)
    check = __PyFunction_Check;
  else if(strcmp(mode, "cfunc")==0)
    check = __PyCFunction_Check;
  else if(strcmp(mode, "method")==0)
    check = __PyMethod_Check;
  else if(strcmp(mode, "callable")==0)
    check = __PyCallable_Check;

  PyObject *s = NULL;

  if(check) {
    if(!PyList_Check(attrs)) error(_("FIXME @ %s:%d"), __FILE__, __LINE__);
    Py_ssize_t len = PyList_Size(attrs);
    Py_ssize_t n = 0;
    for(int i=0; i<len; i++) {
      PyObject *a = PyObject_GetAttr(obj, PyList_GetItem(attrs,i)); 
      //if(PyFunction_Check(a)) n++;
      if(check(a)) n++;
    }

    fprintf(stdout, "n: %ld\n", n);

    PyObject *s = PyList_New(n);
    n = 0;
    for(int i=0; i<len; i++) {
      PyObject *a = PyObject_GetAttr(obj, PyList_GetItem(attrs,i)); 
      //if(PyFunction_Check(a))
      if(check(a)) PyList_SetItem(s, n++, PyList_GetItem(attrs,i));
    }

    attrs = s;
  } 

  SEXP ret =  PyObject_toROject(attrs);
  if(s) Py_DECREF(s);
  return ret;
}

SEXP Rython_getAttr(SEXP object, SEXP name)
{
  if(!Rython_isPyObjectWrapper(object))
    error(_("invalid argument, not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(object);

  if(!PyObject_HasAttrString(obj, CHAR(asChar(name))))
    error(_("object doesn't have the '%s' attribute"), CHAR(asChar(name)));

  obj =  PyObject_GetAttrString(obj, CHAR(asChar(name)));
  return RObject_wrapper(obj);
}

SEXP Rython_setAttr(SEXP object, SEXP name, SEXP value)
{
  if(!Rython_isPyObjectWrapper(object))
    error(_("invalid argument, not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(object);

//  if(!PyObject_HasAttrString(obj, CHAR(asChar(name))))
//    error(_("object doesn't have the '%s' attribute"), CHAR(asChar(name)));

  int rc;
  if(Rython_isPyObjectWrapper(value)){
    rc =  PyObject_SetAttrString(obj, CHAR(asChar(name)), 
		    (PyObject *) R_ExternalPtrAddr(value));
  } else {
    rc =  PyObject_SetAttrString(obj, CHAR(asChar(name)),
		    SEXP_toPyObject(value)); // as RObject???
  }
  return ScalarInteger(rc);
}

static PyObject *Rython_mkArgs(SEXP args)
{
   PyObject *py_args = NULL;
   if(args == R_NilValue) return NULL;
   if(TYPEOF(args) == VECSXP){
      int n = LENGTH(args);
      if(n==0) return NULL;
      py_args = PyTuple_New(n);
      for(int i=0; i<n; i++) {
        SEXP val = VECTOR_ELT(args, i);
        if(Rython_isPyObjectWrapper(val))
          PyTuple_SetItem(py_args, i, (PyObject *) R_ExternalPtrAddr(val));
        else
          PyTuple_SetItem(py_args, i, SEXP_toPyObject(val));
      }
    } else {
      error(_("not implemented (%s:%d)"), __FILE__, __LINE__);
    }

   return py_args;

}

// FIXME???
SEXP Rython_invokeMethod(SEXP method, SEXP object, SEXP args)
{
  if(!Rython_isPyObjectWrapper(method))
    error(_("invalid argument, 'method' is not a PyObject"));
  if(!Rython_isPyObjectWrapper(object))
    error(_("invalid argument, 'object' is not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(object);
  PyObject *meth = (PyObject *) R_ExternalPtrAddr(method);

  //if(args == R_NilValue || LENGTH(args)==0 ) {
// PyObject* PyObject_CallMethod(PyObject *obj, const char *name,
// 	 const char *format, ...)
//
// 	 PyObject* PyMethod_Function(PyObject *meth)
//
    Py_Print(meth, "method");

    /*
     * PyAPI_DATA(PyTypeObject) PyClassMethodDescr_Type;
PyAPI_DATA(PyTypeObject) PyGetSetDescr_Type;
PyAPI_DATA(PyTypeObject) PyMemberDescr_Type;
PyAPI_DATA(PyTypeObject) PyMethodDescr_Type;
PyAPI_DATA(PyTypeObject) PyWrapperDescr_Type;
PyAPI_DATA(PyTypeObject) PyDictProxy_Type;
*/
    PyObject *method_name = NULL;
    PyObject *cfunc = NULL;

    int flags = -1;

    if(Py_TYPE(meth) == &PyWrapperDescr_Type){
      Py_Print(meth, "Wrapped");
      PyTypeObject *d_type =  PyDescr_TYPE(meth);
      Py_Print((PyObject *)d_type, "descr_type");
      PyObject *d_name = PyDescr_NAME(meth);
      Py_Print(d_name, "descr_name");
//      PyWrapperDescrObject *wrapper = (PyWrapperDescrObject *) meth;
      method_name = d_name;
      cfunc = PyObject_GetAttr(obj, d_name);
      Py_Print(cfunc, "obj->cfunc");
      PyObject *self = PyCFunction_GET_SELF(cfunc);
      Py_Print(self, "obj->cfunc->self");
      fprintf(stdout, "%p == %p\n", self, obj);
    } else if(Py_TYPE(meth) == &PyMethodDescr_Type){
      Py_Print(meth, "Wrapped");
      PyTypeObject *d_type =  PyDescr_TYPE(meth);
      Py_Print((PyObject *)d_type, "descr_type");
      PyObject *d_name = PyDescr_NAME(meth);
      Py_Print(d_name, "descr_name");

      method_name = d_name;
      cfunc = PyObject_GetAttr(obj, d_name);

      Py_Print(cfunc, "obj->cfunc");
      PyObject *self = PyCFunction_GET_SELF(cfunc);
      Py_Print(self, "obj->cfunc->self");
      fprintf(stdout, "%p == %p\n", self, obj);

//      flags = method->ml_flags & ~(METH_CLASS | METH_STATIC | METH_COEXIST);
      flags = PyCFunction_GET_FLAGS(cfunc)
	      & ~(METH_CLASS | METH_STATIC | METH_COEXIST);
      fprintf(stdout, "flags: %d, METH_O: %d\n", flags, METH_O);
    }

    if(cfunc && PyCallable_Check(cfunc)){
      PyObject *py_args = Rython_mkArgs(args);
      PyObject *val = PyObject_CallObject(cfunc, py_args);
      Py_Print(val, "val");

      PyObject *err = PyErr_Occurred();
      if(err) Rython_error(err);
      
      return RObject_wrapper(val);
    }

    if(FALSE){
      PyObject *func = PyMethod_Function(meth);
      Py_Print(func, "func");
      const char *meth_name = PyEval_GetFuncName(func);
      PyObject *val = PyObject_CallMethod(obj, meth_name, NULL);
      Py_Print(val, "val");
      return RObject_wrapper(val);
    } else {
    }
  //}


  return R_NilValue;
}


// invoke to do ...
// obj, m_name, args ... to do ...
SEXP Rython_callFunction(SEXP func, SEXP args)
{
  if(!Rython_isPyObjectWrapper(func))
    error(_("invalid argument, not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(func);

  if(!PyCallable_Check(obj))
    error(_("invalid argument, not callable"));

//  PyObject* _PyObject_Vectorcall(PyObject *callable, PyObject *const *args, size_t nargsf, PyObject *kwnames);
  // PyObject* PyObject_CallObject(PyObject *callable, PyObject *args)

  if(args == R_NilValue)
  {
    PyObject *val = PyObject_CallObject(obj, NULL);
    PyObject *err = PyErr_Occurred();
    if(err) Rython_error(err);
    return RObject_wrapper(val);
  } else if (TYPEOF(args) == VECSXP) { // not tested yet
    int n = LENGTH(args);
    PyObject *py_args = PyTuple_New(n);
    for(int i=0; i<n; i++)
      PyTuple_SetItem(py_args, i, SEXP_toPyObject( VECTOR_ELT(args, i)));
    
    PyObject *val = PyObject_CallObject(obj, py_args);
    PyObject *err = PyErr_Occurred();
    if(err) Rython_error(err);
    return RObject_wrapper(val);
  } else {
    error(_("not implemented"));

  }
    
  return R_NilValue;
}





SEXP Rython_doCall(SEXP what, SEXP args, SEXP quote, SEXP envir)
{
  int _quote = asLogical(quote); // do later ...
  if(TYPEOF(what) == STRSXP){ // get the method... strsplit
    error(_("not implemented"));
  } else if(Rython_isPyObjectWrapper(what)){
    PyObject *obj = (PyObject *) R_ExternalPtrAddr(what);

    if(!PyCallable_Check(obj))
      error(_("invalid argument, not callable"));


    PyObject *py_args = NULL;

    if(TYPEOF(args) == VECSXP){
      int n = LENGTH(args);
      py_args = PyTuple_New(n);
      for(int i=0; i<n; i++) {
	SEXP val = VECTOR_ELT(args, i);
	if(Rython_isPyObjectWrapper(val))
          PyTuple_SetItem(py_args, i, (PyObject *) R_ExternalPtrAddr(val));
	else
          PyTuple_SetItem(py_args, i, SEXP_toPyObject(val));
      }
    } else {
      error(_("not implemented (%s:%d)"), __FILE__, __LINE__);
    }

    PyObject *val = PyObject_CallObject(obj, py_args);//works for PyCFunction

    PyObject *err = PyErr_Occurred();
    if(err) Rython_error(err);
    return RObject_wrapper(val);

  } else {
    error(_("invalid 'what' argument"));
  }
  return R_NilValue;
}

SEXP Rython_getClass(SEXP object)
{
  if(!Rython_isPyObjectWrapper(object))
    error(_("invalid argument, not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(object);

  return RObject_wrapper(PyObject_Type(obj));
}


/*
SEXP Rython_getModuleDict(SEXP object)
{
  if(!Rython_isPyObjectWrapper(object))
    error(_("invalid argument, not a PyObject"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(object);

  if(!PyModule_Check(obj))
    error(_("invalid argument, not a module object"));

  return RObject_wrapper(PyModule_GetDict(obj));
}
*/

PyObject *__PyImport_GetModule(const char *name)
{
  PyObject *modules = PyImport_GetModuleDict();
  return PyDict_GetItemString(modules, name);
}

PyObject *Rython_getEx(const char *name, PyObject *dict)
{
  char buf[strlen(name)+1];
  memcpy(buf, name, strlen(name)+1);
  char *tok = strtok(buf, ".");
  fprintf(stdout, "token: %s\n", tok);
  if(!tok) return NULL;

  PyObject *val = PyDict_GetItemString(dict, tok);
  if(!val) return NULL;

  for(tok = strtok(NULL, "."); tok; tok = strtok(NULL, ".")){
    fprintf(stdout, "token: %s\n", tok);
    val = PyObject_GetAttrString(val, tok);
    if(!val) return NULL;
  }

  return val;
}

// where must be a dict or NULL (NULL->locals, to do)
SEXP Rython_get(SEXP r_name, SEXP wrapped_dict)
{ 
  PyObject *dict = NULL;
  if(wrapped_dict == R_NilValue)
    dict = Rython_globals();
  else if(!Rython_isPyObjectWrapper(wrapped_dict))
    error(_("expected a wrapped python dict object"));
  else
    dict = (PyObject *) R_ExternalPtrAddr(wrapped_dict);

  if(PyModule_Check(dict))
    dict = PyModule_GetDict(dict);

  if(!PyDict_Check(dict))
    error(_("expected a wrapped python dict object"));

  PyObject *obj = PyDict_GetItemString(dict, CHAR(asChar(r_name)));
  return RObject_wrapper(obj);



  /*
  error(_("deprecated"));
  ///

  if(r_name == R_NilValue){
    PyObject *sys_module = PyImport_AddModule("sys");
    return RObject_wrapper(sys_module);
    // or return RObject_wrapper(PySys_getObject("modules"));
  }

  const char *name = CHAR(asChar(r_name));


  if(where == R_NilValue){
    // testing
    py_node_t *node = Runtime_getModulelist();
    for(; node; node = node->next){
      PyObject *dict = PyModule_GetDict(node->object);
      PyObject *err = PyErr_Occurred();
      if(err){
        Rython_printError(err);
        continue;
      }
      // Use PyDict_contains ...
      PyObject *val = PyDict_GetItemString(dict, name);
      err = PyErr_Occurred();
      if(err){
        Rython_printError(err);
        continue;
      }

      if(val) {
	fprintf(stdout, "Found in (%s)\n", node->name);
        return RObject_wrapper(val);
      }

    }

    node = Runtime_getDictlist();
    for(; node; node = node->next){

      PyObject *dict = node->object;
      PyObject *err = PyErr_Occurred();
      if(err){
        Rython_printError(err);
        continue;
      }
      // Use PyDict_contains ...
      PyObject *val = PyDict_GetItemString(dict, name);
      err = PyErr_Occurred();
      if(err){
        Rython_printError(err);
        continue;
      }

      if(val) {
	fprintf(stdout, "Found in (%s)\n", node->name);
        return RObject_wrapper(val);
      }

    }

  } else if(Rython_isPyObjectWrapper(where)) {
    PyObject *obj = (PyObject *) R_ExternalPtrAddr(where);
    if(PyModule_Check(obj)) obj = PyModule_GetDict(obj);

    if(PyDict_Check(obj)) {
      obj = PyDict_GetItemString(obj, name);
      PyObject *err = PyErr_Occurred();
      if(err) Rython_error(err);

      return RObject_wrapper(obj);
      
    }
  } else {
    error(_("not implemented"));
  }
  if(ret == R_UnboundValue)
	  error(_("cannot find '%s'"), CHAR(asChar(r_name)));
  return ret;
  */
}

SEXP Rython_toR(SEXP wrapped_obj)
{ // consider the current eval frame

  if(wrapped_obj == R_NilValue) return R_NilValue;

  if(!Rython_isPyObjectWrapper(wrapped_obj))
          error(_("expected a wrapped python dict object"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(wrapped_obj);
  return PyObject_toROject(obj);
}



SEXP Rython_print(SEXP wrapped_obj)
{
  if(!Rython_isPyObjectWrapper(wrapped_obj))
      error(_("expected a wrapped python object"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(wrapped_obj);

  PyObject_Print(obj, stdout, Py_PRINT_RAW);
  fprintf(stdout, "\n");

  return wrapped_obj;

	/*
  SEXP klass;
  if( TYPEOF(object) == EXTPTRSXP &&
      (klass = getAttrib(object, R_ClassSymbol)) != R_UnboundValue){
    int i = 0;
    for(; i<LENGTH(klass); i++)
      if(strcmp(CHAR(STRING_ELT(klass,i)), "PyObject")==0)
		    break;
    if(i>=LENGTH(klass))
	    error(_("invalid argument"));
    PyObject *obj = R_ExternalPtrAddr(object);
    PyObject_Print(obj, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\n");

    {
         PyObject *my_obj =  RythonObject_Type.tp_new(&RythonObject_Type,
			 (PyObject *)object, NULL);
	 fprintf(stdout, "my_obj: %p\n", my_obj);
         PyObject_Print(my_obj, stdout, Py_PRINT_RAW);

         fprintf(stdout, "\n");
    }

  } else {
    error(_("invalid argument"));
  }
  return R_NilValue; 
  */
}

// _put
SEXP Rython_assign(SEXP r_name, SEXP r_value, SEXP r_dict)
{// testing .. supr_global_dict, if r_dict = null

  SEXP ret = R_NilValue;
  if(r_dict == R_NilValue){
	  /*
    PyObject *sys_module = PyImport_AddModule("sys");
    PyObject *sys_dict   = PyModule_GetDict(sys_module);
    PyObject *global_dict = PyDict_GetItemString(sys_dict,
		    "supr_global_dict");
		    */
    PyObject *module = PyImport_AddModule("__main__");
    PyObject *global_dict   = PyModule_GetDict(module);

    fprintf(stdout, "[%s] global_dict: %p\n", __func__, global_dict);

    const char *var_name = CHAR(asChar(r_name));
    PyObject *val = SEXP_toPyObject(r_value);

    if(val) {
      PyDict_SetItemString(global_dict, var_name, val);
      ret = PROTECT(R_MakeExternalPtr(val, R_NilValue, R_NilValue)); 
      SEXP klass = PROTECT(allocVector(STRSXP, 2));
      SET_STRING_ELT(klass, 0, mkChar("PyObject"));
        PyTypeObject *type = Py_TYPE(val);
      SET_STRING_ELT(klass, 1, mkChar(type->tp_name));
      setAttrib(ret, R_ClassSymbol, klass);
      UNPROTECT(2);
    } else {
      error(_("(%s:%d)"), __FILE__, __LINE__);
    }
  } else {
      error(_("not implemented (%s:%d)"), __FILE__, __LINE__);
  }

  Rython_dumper();

  return ret;
}

void Rython_printError(PyObject *err)
{
  PyObject *type, *value, *traceback;
  PyErr_Fetch(&type, &value, &traceback);

  PyObject *repr = PyObject_Repr(value);
  const char *value_str;
  PyArg_Parse(repr, "s", &value_str);

  const char *bt_str = "...";
  repr = PyObject_Repr(traceback);
  PyArg_Parse(repr, "s", &bt_str);

  const char *bt_header = "\nTraceback: ";
  char buf[strlen(value_str)+strlen(bt_str)+strlen(bt_header)+1];
  sprintf(buf, "%s%s%s", value_str, bt_header, bt_str);
   //PyErr_Restore(type, value, traceback);
  fprintf(stderr, "\n\033[0;31m%s\033[0m\n", buf);
}

void __Rython_error(PyObject *err, const char *func, int line)
{
  PyObject *type, *value, *traceback;
  PyErr_Fetch(&type, &value, &traceback);

  PyObject *repr = PyObject_Repr(value);
  const char *value_str;
  PyArg_Parse(repr, "s", &value_str);

  const char *bt_str = "...";
  repr = PyObject_Repr(traceback);
  //PyArg_Parse(repr, "s", &bt_str);
  PyArg_ParseTuple(repr, "s", &bt_str);

  const char *bt_header = "\nTraceback: ";
  char buf[strlen(value_str)+strlen(bt_str)+strlen(bt_header)+1];
  sprintf(buf, "\033[0;31m%s%s%s (%s. %s:%d)\033[0m", value_str,
		  bt_header, bt_str, func, __FILE__, line);
   //PyErr_Restore(type, value, traceback);
  PyErr_Clear();
  error(_("%s"), buf);
}


// PyObject* PyObject_Dir(PyObject *o);
// returning a (possibly empty) list of strings appropriate for the object argument,

// _ls: 
// make it simple
// dict or module
SEXP Rython_ls(SEXP wrapped_dict)
{
  SEXP ret = R_NilValue;
  if(wrapped_dict == R_NilValue) {
    PyObject *dict = Rython_globals();
    PyObject *keys = PyDict_Keys(dict);
    return PyObject_toROject(keys);
  }

  if(!Rython_isPyObjectWrapper(wrapped_dict))
	  error(_("expected a wrapped python dict object"));

  PyObject *dict = (PyObject *) R_ExternalPtrAddr(wrapped_dict);

  if(PyModule_Check(dict))
	  dict  = PyModule_GetDict(dict);

  if(!PyDict_Check(dict))
    error(_("expected a wrapped python dict or module object"));
  
  PyObject *keys = PyDict_Keys(dict);
  return PyObject_toROject(keys);
}

SEXP __Rython_ls(SEXP name)
{
  SEXP ret = R_NilValue;

  error(_("deprecated"));
  
  if(name == R_NilValue) {
    // Call PyObject_Dir(NULL)
    // returning the names of the current locals; in this case, if no execution frame is active then NULL is returned but PyErr_Occurred() will return false
    PyObject *py_val = PyObject_Dir(NULL);
    PyObject *err = PyErr_Occurred();
    if(!err)
      return PyObject_toROject(py_val);
      //Rython_error(err);

    // try globals : __main__ module's dict
    PyErr_Clear();

    PyObject *module = PyImport_AddModule("__main__");
    PyObject_Print(module, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\n\033[0;33m(%s:%d)\033[0m\n\n", __FILE__, __LINE__);

    PyObject *dict = PyModule_GetDict(module);
    PyObject_Print(dict, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\n\033[0;33m(%s:%d)\033[0m\n\n", __FILE__, __LINE__);

    err = PyErr_Occurred();
    if(!err)
      Rython_printError(err); //???

    if(dict && PyDict_Check(dict))
    {
      PyObject *keys = PyDict_Keys(dict);
      return PyObject_toROject(keys);
    } else {
      return R_NilValue;
    }

  } else if(TYPEOF(name) == SYMSXP){




  } else if(TYPEOF(name) == STRSXP) {
    const char *c_name = CHAR(asChar(name));

    // testing
    py_node_t *node = Runtime_getModulelist();
    for(; node; node = node->next){
      PyObject *py_val = PyObject_Dir(node->object);
      fprintf(stderr, "\n<%p> module name: %s (%s)\n", node->object,
		      PyModule_GetName(node->object), node->name);

      PyObject *err = PyErr_Occurred();
      if(err){
              Rython_printError(err);
	      continue;
      }

      if(py_val){
        SEXP val = PyObject_toROject(py_val);
	PrintValue(val);
      } else {
	      //fprintf(stderr, "Error: ...\n");
      }
    }

    node = Runtime_getDictlist();
    for(; node; node = node->next){
      PyObject *py_val = PyObject_Dir(node->object);
      fprintf(stderr, "\n<%p> dict name: %s (%s)\n", node->object,
		      PyModule_GetName(node->object), node->name);

      if(py_val){
        SEXP val = PyObject_toROject(py_val);
	PrintValue(val);
      } else {
	      fprintf(stderr, "Error: ...\n");
      }
    }


  } else if(TYPEOF(name) == EXTPTRSXP) {
	      fprintf(stderr, "EXTPTRSXP ... OKAY 1\n");
    SEXP klass = getAttrib(name, R_ClassSymbol); 
    int i=0;
    for(; i<LENGTH(klass); i++)
	    if(strcmp(CHAR(STRING_ELT(klass, i)), "PyObject")==0)
		    break;
	      fprintf(stderr, "EXTPTRSXP ... OKAY 2, i: %d\n", i);
    if(i >= LENGTH(klass))
      error(_("invalid argument"));

	      fprintf(stderr, "EXTPTRSXP ... OKAY 3, i: %d\n", i);

    PyObject *obj = (PyObject *) R_ExternalPtrAddr(name);

    if(PyModule_Check(obj)) obj = PyModule_GetDict(obj);

    if(PyDict_Check(obj))
    {
      //PyObject *obj = (PyObject *) R_ExternalPtrAddr(name);
      PyObject_Print(obj, stdout, Py_PRINT_RAW);
      size_t size = PyDict_Size(obj);
      fprintf(stdout, "PyDict ... size: %ld\n", size);
      if(size == 0) return allocVector(VECSXP, 0);

      PyObject *keys = PyDict_Keys(obj);
      if(PyList_Check(keys)) PyList_Sort(keys);
      ret = PROTECT(allocVector(STRSXP, size));
      for(int i=0; i<size; i++){
        char *key_str;
	PyObject *key = PySequence_GetItem(keys, i);
	PyArg_Parse(key, "s", &key_str);
	fprintf(stdout, "[%d] key_str: %s\n", i, key_str);
	SET_STRING_ELT(ret, i, mkChar(key_str));
      }

      UNPROTECT(1);
      //ret = PyObject_toROject(obj);
      //PrintValue(ret);
      return ret;
    } else {
	      fprintf(stderr, "EXTPTRSXP ... OKAY 4, <%p>\n", obj);

      PyObject *py_val = PyObject_Dir(obj);

	      fprintf(stderr, "EXTPTRSXP ... OKAY 5, i: %d\n", i);
      PyObject *err = PyErr_Occurred();
      if(err) Rython_error(err);  // CheckError ...
    
      if(py_val){
        ret = PyObject_toROject(py_val);
	PrintValue(ret);
      }
    }

  } else {
    error(_("invalid argument"));
  }
  return ret;
}


SEXP Rython_serialize(SEXP wrapped_obj)
{
  if(wrapped_obj == R_NilValue) return R_NilValue;

  if(!Rython_isPyObjectWrapper(wrapped_obj))
	  error(_("expected a wrapped python object"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(wrapped_obj);

  PyObject *val = PyMarshal_WriteObjectToString(obj, 2);

  PyObject_Print(val, stdout, Py_PRINT_RAW);
  fprintf(stdout, "\n");
  PyObject_Print((PyObject*)Py_TYPE(val), stdout, Py_PRINT_RAW);
  fprintf(stdout, "\nPyBytes_Size(val): %ld\n", PyBytes_Size(val));

  return RObject_wrapper(val);
}

SEXP Rython_unserialize(SEXP wrapped_obj)
{
  if(wrapped_obj == R_NilValue) return R_NilValue;

  if(!Rython_isPyObjectWrapper(wrapped_obj))
	  error(_("expected a wrapped python object"));

  PyObject *obj = (PyObject *) R_ExternalPtrAddr(wrapped_obj);

  const char *data = PyBytes_AsString(obj);
  Py_ssize_t len = PyBytes_Size(obj);

  PyObject *val = PyMarshal_ReadObjectFromString(data, len);

  return RObject_wrapper(val);
}

void Rython_checkConfig()
{
//  PyConfig config;
//  PyConfig_InitPythonConfig(&config);
//  fprintf(stdout, "buffered_stdio: %d\n", config.buffered_stdio);
}

/*
SEXP Rython_ls_str(SEXP name)
{
}
*/
// interface to
// int
// PyRun_SimpleStringFlags(const char *command, PyCompilerFlags *flags)
// Executes the Python source code from command in the __main__ module according to the flags argument.
SEXP Rython_runCommand(SEXP r_command)
{

  Rython_checkConfig(); // tetsing

  fprintf(stdout, "Py_GetProgramName():  %p\n", Py_GetProgramName());
  fprintf(stdout, "                   :  %p\n", wchar_progname);
  const char *command = CHAR(asChar(r_command));
  PyCompilerFlags *flags = NULL;
  int rc = PyRun_SimpleStringFlags(command, flags);
  return ScalarInteger(rc);
}

//ncludeInclude/node.h
/*
typedef struct _node {
    short               n_type;
    char                *n_str;
    int                 n_lineno;
    int                 n_col_offset;
    int                 n_nchildren;
    struct _node        *n_child;
} node;
*/

//#define CHILD(n, i)     (&(n)->n_child[i])

static void _node_print(struct _node *node, const char *prefix)
{
   if(!node) {
	   fprintf(stdout, "%s (null)\n", prefix);
	   return;
   }
   fprintf(stdout, "%s{ n_type: %d\n", prefix,node->n_type); 
   fprintf(stdout, "%s  n_str:  %s\n", prefix,node->n_str); 
   fprintf(stdout, "%s  n_lineno:  %d\n", prefix,node->n_lineno); 
   fprintf(stdout, "%s  n_col_offset:  %d\n", prefix,node->n_col_offset); 
   fprintf(stdout, "%s  n_nchildren:  %d\n", prefix,node->n_nchildren); 
   fprintf(stdout, "%s  n_child:  %p\n", prefix,node->n_child); 
   fprintf(stdout, "%s}\n", prefix);
   char buf[strlen(prefix)+strlen("  ")+1];
   sprintf(buf, "%s  ", prefix);
   for(int i=0; i<node->n_nchildren; i++){
     _node_print(CHILD(node, i), buf);
   }
}

//#undef CHILD

// change the name
SEXP Rython_parseString(SEXP r_str)
{
  const char *str = CHAR(asChar(r_str));
  int start = Py_file_input;

  /*  // Works
  PyObject *code =  Py_CompileString(str, "stdin", start); //Bytecode object
  if(code){ // code object
      fprintf(stdout, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      PyObject_Print(code, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      PyObject_Print( (PyObject *)Py_TYPE(code), stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      // PyObject* PyEval_EvalCode(PyObject *co, PyObject *globals, PyObject *locals)
      //PyObject *globals = PyDict_New();
      PyObject *globals = PyModule_GetDict(PyImport_AddModule("__main__"));
      PyObject *locals = PyDict_New();
      PyObject *val = PyEval_EvalCode(code, globals, locals);
      PyObject *err = PyErr_Occurred();
      Rython_printError(err);

      fprintf(stdout, "~~~~~~~~~~~~~~~~~~~~~locals~~~~~~~~~~~~~~~~~~~~\n");
      PyObject_Print(locals, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      fprintf(stdout, "~~~~~~~~~~~~~~~~~~~~~~~~~~globals~~~~~~~~~~~~~~~~\n");
      PyObject_Print(globals, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      fprintf(stdout, "~~~~~~~~~~~~val~~~~~~~~~~~~~~~~\n");
      PyObject_Print(val, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

      return RObject_wrapper(locals);
  }
  */
  
  struct _node *node = PyParser_SimpleParseString(str, start);

  PyObject *err = PyErr_Occurred();
  Rython_printError(err);

  fprintf(stdout, "==============================================\n");
  _node_print(node, "");
  fprintf(stdout, "==============================================\n");
  PyNode_ListTree(node);
  fprintf(stdout, "----------------------------------------------\n");
  struct _node *compiled_node = node;
  if(compiled_node){
    PyCodeObject *compiled_code = PyNode_Compile (compiled_node, "temp.py");
    if (compiled_code)
    {
      fprintf(stdout, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      PyObject_Print((PyObject*)compiled_code, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      fprintf(stdout, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
//      return_value.Reset(PyEval_EvalCode (compiled_code, globals.get(), locals.get()));
      PyObject *globals = PyModule_GetDict(PyImport_AddModule("__main__"));
      PyObject *locals = PyDict_New();
      PyObject *val = PyEval_EvalCode((PyObject*)compiled_code, globals, locals);
      PyObject *err = PyErr_Occurred();
      Rython_printError(err);

      //return RObject_wrapper((PyObject*)compiled_code);
      return RObject_wrapper(locals);
    }
  }

  SEXP ret = PROTECT(R_MakeExternalPtr(node, R_NilValue, R_NilValue)); 
  setAttrib(ret, R_ClassSymbol, mkString("PyObject_struct__node"));
  UNPROTECT(1);
  return ret;
 
  return R_NilValue;
}

// run scr in file
SEXP Rython_source(SEXP r_filename)
{
  const char *filename = CHAR(asChar(r_filename));
  int closeit = TRUE;
  PyCompilerFlags *flags = NULL;
  FILE *fp = fopen(filename, "r");
  if(!fp)
	  error(_("cannot open '%s'"), filename);
  int rc = PyRun_SimpleFileExFlags(fp, filename, closeit, flags);
 
  return ScalarInteger(rc);
}

// Include/dictobject.h: typedef struct { ... 
//   PyDictKeysObject *ma_keys;
// } PyDictObject
//
// Objects/dict-common.h
// ....h: _dictkeysobject {
//  dict_lookup_func dk_lookup;
//} 



// Deprecated... delete me
// FIXME ...
#include "PyObject-dict-common.h" // copied from Objects/dict-common.h
//#include <python3.6m/object.h>
//#include <python3.6m/dictobject.h>
#include <object.h>
#include <dictobject.h>

typedef Py_ssize_t (*dict_lookup_func) (PyDictObject *mp, PyObject *key, Py_hash_t hash, PyObject **value_addr);

extern void c_backtrace();
// testing
static dict_lookup_func save_py_dk_lookup = NULL; // save
Py_ssize_t my_dk_lookup(PyDictObject *mp, PyObject *key, Py_hash_t hash,
	       	PyObject **value_addr)
{
  fprintf(stdout, "\033[0;31m%s(<%p>, %s, ...) is called (mp->ma_values: %p, key-value split if null)\033[0m\n",
		  __func__, mp, PyUnicode_AsUTF8(key),
		  mp->ma_values);
        fprintf(stdout, "hash: %ld\n", hash);

  Py_ssize_t ix = save_py_dk_lookup(mp, key, hash, value_addr);
  if(ix>=0)
        fprintf(stdout, "*value_addr: %p\n", *value_addr);
  /*
  if (ix < 0) {
     PyErr_Clear();
     return NULL;
  }
  */


  //if(!look_R_namespaces) c_backtrace();

  if( ix < 0 ){
    // try a different way ...
    {
      fprintf(stdout, "\033[0;31m\t Try (R).GlobalEnv$%s\033[0m\n",
		    PyUnicode_AsUTF8(key));
      const char *name = PyUnicode_AsUTF8(key);
      SEXP r_val = findVar(install(name), R_GlobalEnv);
      if(r_val != R_UnboundValue){
        PyDictObject *tmp_dict = (PyDictObject*) PyDict_New();
        PyObject *value = SEXP_toPyObject(r_val);
        PyDict_SetItemString((PyObject*)tmp_dict, name, value);
        ix = tmp_dict->ma_keys->dk_lookup(mp, key, hash, value_addr);
      }
      return ix;
    }


    //
    //
    //
    //
    //
    //
    //
    //
    //if (!PyUnicode_CheckExact(key)) { // checked already by PyDict_GetItem
    //}
    fprintf(stdout, "\033[0;31m\t Try (R).GlobalEnv$%s\033[0m\n",
		    PyUnicode_AsUTF8(key));
    const char *name = PyUnicode_AsUTF8(key);
    SEXP r_val = findVar(install(name), R_GlobalEnv);
    if(r_val != R_UnboundValue && strcmp(name, "xx")==0) { // regist_names?

      fprintf(stdout, "\n____________________________________________\n");
      // c_backtrace();
      //sleep(120);
      fprintf(stdout, " IN R (%s:%d):\n", __FILE__, __LINE__);
	    PrintValue(r_val);

      PyObject *value = SEXP_toPyObject(r_val);

      /*
      {
        *value_addr = value;
	return 1;
      }
      */

      
      PyObject *err = PyErr_Occurred();
      if(err){
            Rython_printError(err);
      fprintf(stdout, " PyErr_Clear()... (%s:%d):\n", __FILE__, __LINE__);
            PyErr_Clear();
      }
     

      PyObject_Print(value, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\nSET_ITEM (%s:%d), value: %p\n\n", __FILE__, __LINE__,
		      value);

      //PyDict_SetItemString(global_dict, var_name, val);
      //PyDict_SetItem((PyObject*)mp, key, *value_addr);
      mp->ma_keys->dk_lookup = save_py_dk_lookup;
      int rc = PyDict_SetItem((PyObject*)mp, key, value);
      fprintf(stdout, "\033[0;34mRIGHT LOOK AFTER SET rc: %d (%s:%d)\033[0m\n",
		      rc, __FILE__, __LINE__);

      mp->ma_keys->dk_lookup = my_dk_lookup;
      //fprintf(stdout, "\033[0;34mRIGHT LOOK AFTER SET ix: %ld (%s:%d)\033[0m\n", ix, __FILE__, __LINE__);

      // wass set okay?
      {
//        mp->ma_keys->dk_lookup = save_py_dk_lookup;
	PyObject *new_value_2 = PyDict_GetItem((PyObject*)mp, key);
//        mp->ma_keys->dk_lookup = my_dk_lookup;
        fprintf(stdout, "\033[0;36m[Double Checking] value: %p, new_value_2: %p  (%s:%d)\033[0m\n",
		      value, new_value_2, __func__, __LINE__);
	if(new_value_2 == value)
          fprintf(stdout, "\033[0;32mOKAY\033[0m\n\n");
	else 
          fprintf(stdout, "\033[0;31mWhoops\033[0m\n\n");
      }

      PyObject *new_value;

//      ix = save_py_dk_lookup(mp, key, hash, &new_value);
      ix = my_dk_lookup(mp, key, hash, value_addr);
      fprintf(stdout, "\033[0;36mLOOKUP AFTER SET ix: %ld (%s:%d)\033[0m\n", ix, __FILE__, __LINE__);
//      fprintf(stdout, "\033[0;36mLOOKUP AFTER SET mp->ma_values[ix=%ld]: %p (%s:%d)\033[0m\n", ix, mp->ma_values[ix], __FILE__, __LINE__);
      fprintf(stdout, "\033[0;36mvalue: %p, new_value: %p\033[0m\n",
		      value, *value_addr);
      PyObject *new_value_2 = NULL;
      if( ix >= 0 )
      {
        fprintf(stdout, "\nVALUE: (%s:%d)\n", __FILE__, __LINE__);
        PyObject_Print(*value_addr, stdout, Py_PRINT_RAW);
        fprintf(stdout, " (%s:%d)\n", __FILE__, __LINE__);
      }
      fprintf(stdout, "\nETURN ix: %ld (%s:%d)\n\n", ix, __FILE__, __LINE__);
      return ix;


      if((hash = ((PyASCIIObject *) key)->hash) == -1)
      {
        fprintf(stdout, "hash: %ld\n", hash);
        hash = PyObject_Hash(key);
        if (hash == -1) {
            PyErr_Clear();
            //return NULL;
            return ix;
        }
        fprintf(stdout, "hash: %ld\n", hash);
      }



      PyObject_Print(*value_addr, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n\033[0;31m\t (R).GlobalEnv$%s : %s\033[0m\n",
		    PyUnicode_AsUTF8(key), type2char(TYPEOF(r_val)));
      ix = 0;
      ix = 7; // ????
    }
    
  }

  fprintf(stdout, "RETURN ix: %ld, *value_addr: %p (%s:%d)\n", ix,
		 *value_addr, __FILE__, __LINE__);
  {
    const char *name = PyUnicode_AsUTF8(key);
    if(strcmp(name, "xx")==0)
      PyObject_Print(*value_addr, stdout, Py_PRINT_RAW);
  }

  return ix;
}


//SEXP Rython_buitinsDict()
SEXP Rython_globalDict()
{
	error(_("deprecated func '%s'"),__func__);

  PyObject *module = PyImport_AddModule("__main__");
  PyObject *dict = PyModule_GetDict(module);
  PyObject_Print(dict, stdout, Py_PRINT_RAW);
  fprintf(stdout, "\n");

  {
    if(!PyDict_Check(dict)) error(_("shouldn't happen")); //

    PyDictObject *mp = (PyDictObject *) dict;

    fprintf(stdout, "mp->ma_keys->dk_lookup: %p\n", mp->ma_keys->dk_lookup);

    if(!save_py_dk_lookup) save_py_dk_lookup = mp->ma_keys->dk_lookup;
    mp->ma_keys->dk_lookup = my_dk_lookup;
  }

  return RObject_wrapper(dict);

	/*
  PyObject *builtins_module = PyImport_AddModule("builtins");
  PyObject *builtins_dict = PyModule_GetDict(builtins_module);
  PyObject *globals_func = PyDict_GetItemString(builtins_dict, "globals");

  PyObject_Print(globals_func, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\n");

  if(PyFunction_Check(globals_func))
    fprintf(stdout, "PyFunction\n");
  if(PyCFunction_Check(globals_func))
  {
    fprintf(stdout, "\033[0;32mPyCFunction\n");
    fprintf(stderr, "\t\t\033[0;33mname: %s",PyEval_GetFuncName(globals_func));
    fprintf(stderr, "PyEval_GetFuncDesc: (%s)\n\033[0m",PyEval_GetFuncDesc(globals_func));
    //PyEval_GetBuiltins()
    // PyEval_GetGlobals()
    // PyEval_GetFrame()
    // PyEval_GetGlobals()
    //PyObject *func = PyCFunction_GET_FUNCTION(globals_func);
    PyObject *val = PyObject_CallFunctionObjArgs(globals_func, NULL);
    PyObject_Print(val, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\n ^ PyObject_CallFunctionObjArgs\n");
  } else
    fprintf(stdout, "type: ?\n");

  PyObject *val = PyObject_CallObject(globals_func, NULL);

      PyObject *err = PyErr_Occurred();
      if(err) Rython_error(err);  // CheckError ...

  PyObject_Print(val, stdout, Py_PRINT_RAW);

  return PyObject_toROject(val);
  */
}

// This is a starting point
//SEXP do_python(SEXP call, SEXP op, SEXP args, SEXP env)
// __main__	The environment where the top-level script is run.


// Example (3.8.1)
//////////////////////////////////////////////

//// Rmodule: as a sub-module of suprmodule

static void RyCapsule_finalizer(SEXP s)
{
  PyObject *p = (PyObject *) R_ExternalPtrAddr(s);
  Py_DECREF(p);
  // FIXME
}

static PyObject *Rython_capsulate(SEXP r_val)
{
      PyObject *c = PyCapsule_New(r_val, "R_EXTPTRSXP", NULL); // FIXME
      Py_INCREF(c); // check: refcnt
      fprintf(stderr, "return: %p, refcnt: %ld\n", c, Py_REFCNT(c));

      SEXP p = PROTECT(R_MakeExternalPtr(c, R_NilValue, R_NilValue));
      R_RegisterCFinalizerEx(p, RyCapsule_finalizer, TRUE);
      setAttrib(r_val, install("PyCapsule"), p);
      UNPROTECT(1);
      PyCapsule_SetContext(c, SEXP_toPyObject);
      return c;
}

extern int Supr_setSignal(int sig);


static PyObject * supr_get(PyObject *self, PyObject *args);

//static PyObject * supr_put(PyObject *self, PyObject *name, PyObject *value)
static PyObject * supr_put(PyObject *self, PyObject *args)
{

  Py_ssize_t n = PyTuple_Size(args); //fprintf(stdout, "n: %ld\n", n);
  if(n != 2) {
    PyErr_SetString(PyExc_TypeError, "put(name, value)");
    return NULL;
  }

	   /*
  for(Py_ssize_t i=0; i < n; i++){
    PyObject *p = PyTuple_GetItem(args, i);
    Py_Print(p, "args");
  }
  */

  const char *key;
  PyObject *val;
  //PyArg_ParseTuple(args, "(sO)", &key, &val);
  PyArg_ParseTuple(args, "sO", &key, &val);
  //fprintf(stdout, "key: %s ", key);
  //Py_Print(val, "value");
  SEXP s = RObject_wrapper(val);
  defineVar(install(key), s, R_GlobalEnv); // Lock???
  return Py_None;

	/*
  const char *key;
  PyArg_ParseTuple(args, "s", &key);
  SEXP s = RObject_wrapper(value);
  defineVar(install(key), s, R_GlobalEnv); // Lock???
  return Py_None;
  */
}

static PyObject * supr_ls(PyObject *self, PyObject *args)
{
  Py_ssize_t n = PyTuple_Size(args); //fprintf(stdout, "n: %ld\n", n);
  if(n != 0) {
    PyErr_SetString(PyExc_TypeError, "ls()");
    return NULL;
  }

  SEXP call = PROTECT(LCONS(install("ls"), R_NilValue));
  SEXP val = eval(call, R_GlobalEnv);
  PyObject *p = SEXP_toPyObject(val);
  UNPROTECT(1);
  return p;
}

static PyObject * supr_r2py(PyObject *self, PyObject *args)
{
  Py_ssize_t n = PyTuple_Size(args); //fprintf(stdout, "n: %ld\n", n);
  if(n != 1) {
    PyErr_SetString(PyExc_TypeError, "r2py(x)");
    return NULL;
  }

  PyObject *val;
  //PyArg_ParseTuple(args, "(sO)", &key, &val);
  PyArg_ParseTuple(args, "O", &val);

  //Py_Print(val, "val");
  if(PyCapsule_CheckExact(val)){
    PyObject *(*converter)(SEXP) = (PyObject *(*)(SEXP))
	    PyCapsule_GetContext(val);
    const char *name = PyCapsule_GetName(val);
    fprintf(stderr, "name: %s\n", name);
    if(strcmp(name, "R_EXTPTRSXP")==0) {
      SEXP s = (SEXP) PyCapsule_GetPointer(val, "R_EXTPTRSXP");
      return converter(s);
    } else {
      return val; // SetWarn???
    }
  }

  PyErr_SetString(PyExc_TypeError, "require PyObject *");
  return NULL;
}

static PyObject * py_quit(PyObject *self, PyObject *args)
{
  fprintf(stderr, "Quit ... CleanUp ... ?\n");
  Supr_setSignal(0);
  void **onintr_addr = pthread_getspecific(rythonInterruptKey);
  *onintr_addr = PyExc_EOFError; // not really E_EOF

  //PyErr_SetString(RError, "quit repl");
  //PyErr_SetString(PyExc_KeyboardInterrupt, "quit repl?");
  PyErr_SetString(PyExc_StopIteration, "Quit repl");
  return NULL;
}

static PyObject * py_call(PyObject *self, PyObject *args)
{
  Py_ssize_t n = PyTuple_Size(args); //fprintf(stdout, "n: %ld\n", n);
  if(n == 0) {
    PyErr_SetString(PyExc_TypeError, "call(x, ...)");
    return NULL;
  }

  PyObject *fun = PyTuple_GetItem(args, 0);

  SEXP call;
  if(PyUnicode_Check(fun)){
    const char *name;
    PyArg_Parse(fun, "s", &name);
    call = PROTECT(LCONS(install(name), R_NilValue));
  } else if (PyCapsule_CheckExact(fun)){
    const char *name = PyCapsule_GetName(fun);
    SEXP s = (SEXP) PyCapsule_GetPointer(fun, name);
    call = PROTECT(LCONS(s, R_NilValue));
  } else {
    PyErr_SetString(PyExc_TypeError, "func must be a R object");
    return NULL;
  }

  SEXP s = call;
  for(int i=1; i<n; i++){
       PyObject *a = PyTuple_GetItem(args, i);
       SETCDR(s, CONS(PyObject_toROject(a), R_NilValue));
       s = CDR(s);
  }
  SEXP val = eval(call, R_GlobalEnv);
  UNPROTECT(1); 
  return Rython_capsulate(val);
}

static PyObject * py_eval(PyObject *self, PyObject *args)
{
  Py_ssize_t n = PyTuple_Size(args); //fprintf(stdout, "n: %ld\n", n);
  if(n==0) return Py_None;

  Py_Print(args, "eval_args");

  SEXP val = R_NilValue;
  for(Py_ssize_t i = 0; i<n; i++){
    PyObject *p = PyTuple_GetItem(args, i);
    if(PyUnicode_Check(p)){
      const char *text;
      PyArg_Parse(p, "s", &text);
      fprintf(stderr, "text: %s\n", text);
      SEXP call = PROTECT(LCONS(install("parse"), CONS(mkString(text),
				      R_NilValue)));
      SET_TAG(CDR(call), install("text"));
      PrintValue(call);
      SEXP expr = PROTECT(eval(call, R_GlobalEnv));
      if(TYPEOF(expr) == EXPRSXP){
	int len = LENGTH(expr);
	for(int j=0; j<len; j++)
          val = eval(VECTOR_ELT(expr,j), R_GlobalEnv);
      } else {
        PyErr_SetString(PyExc_ValueError, "py_eval: FIXME");
      }
      UNPROTECT(2);
    } else if (PyCapsule_CheckExact(p)){
      const char *name = PyCapsule_GetName(p);
      SEXP s = (SEXP) PyCapsule_GetPointer(p, name);
      val = eval(s, R_GlobalEnv);
    } else {
      PyErr_SetString(PyExc_TypeError, "func must be a R object");
      return NULL;
    }
  }
  return Rython_capsulate(val);
}

static PyObject * py_inspect(PyObject *self, PyObject *args)
{
  Py_ssize_t n = PyTuple_Size(args); //fprintf(stdout, "n: %ld\n", n);
  if(n==0) return Py_None;

  Py_Print(args, "inspect_args");

  PyObject *obj = PyTuple_GetItem(args,0);

  Py_Print(obj, "inspect_args[0]");

  if(PyFunction_Check(obj)){ // PyObject_CallObject for PyFunction
    fprintf(stdout, "This is a PyFunction object\n");
    PyObject *call_args = PyTuple_GetSlice(args, 1, n);
    Py_Print(call_args, "call_args");
    PyObject *val = PyObject_CallObject(obj, call_args);
    Py_Print(val, "call_val");
    return val;
  } else if(PyMethod_Check(obj)){ // PyObject_CallObject for PyMethod
    fprintf(stdout, "This is a PyMethod object\n");
    PyObject *call_args = PyTuple_GetSlice(args, 1, n);
    Py_Print(call_args, "call_args");
    PyObject *val = PyObject_CallObject(obj, call_args);
    Py_Print(val, "call_val");
    return val;
  } else if(PyCFunction_Check(obj)){ // PyObject_CallObject for PyCFunction
    fprintf(stdout, "This is a PyCFunction object\n");
    PyObject *call_args = PyTuple_GetSlice(args, 1, n);
    Py_Print(call_args, "call_args");
    PyObject *val = PyObject_CallObject(obj, call_args);
    Py_Print(val, "call_val");
    return val;
  } else if(PyCallable_Check(obj)){ // PyObject_CallObject for PyCallable
    fprintf(stdout, "This is a PyCallable object\n");
    PyObject *call_args = PyTuple_GetSlice(args, 1, n);
    Py_Print(call_args, "call_args");
    PyObject *val = PyObject_CallObject(obj, call_args);
    Py_Print(val, "call_val");
    return val;
  } else if(Py_TYPE(obj) == &PyWrapperDescr_Type){ 
    fprintf(stdout, "This is a PyWrapperDescr\n");
    PyObject *call_args = PyTuple_GetSlice(args, 1, n);
    Py_Print(call_args, "call_args");
    PyObject *val = PyObject_CallObject(obj, call_args);
    Py_Print(val, "call_val");
    return val;
  } else if(Py_TYPE(obj) == &PyMethodDescr_Type){ 
    fprintf(stdout, "This is a PyMethodDescr\n");
    PyObject *call_args = PyTuple_GetSlice(args, 1, n);
    Py_Print(call_args, "call_args");
    PyObject *val = PyObject_CallObject(obj, call_args);
    Py_Print(val, "call_val");
    return val;
  } else {
    PyErr_WarnEx(NULL, "Todo?", 1);
  }

  return Py_None;
}

/*
static PyObject * py_force_promise(PyObject *self, PyObject *args)
{
  PyErr_SetString(SuprError, "eval: TODO");
  return NULL;
}
*/


static PyMethodDef RMethods[] = {
    {"ls",  supr_ls, METH_VARARGS,
	    "ls(): list objects in [.GlobalEnv]"},
    {"get",  supr_get, METH_VARARGS,
	    "get(name): Get a R object from [.GlobalEnv]"},
    {"put",  supr_put, METH_VARARGS,
	    "put(name, value): Put a R object in [.GlobalEnv]"},
    {"r2py",  supr_r2py, METH_VARARGS,
	    "r2p(): Convert R objects to Python Objects"},
    {"q",    py_quit, METH_VARARGS,
	    "q(): quit py.repl"},
    {"quit", py_quit, METH_VARARGS,
	    "quit() or C^D: to quit py.repl"},
    {"call", py_call, METH_VARARGS,
	    "call(): a R function"},
    {"eval", py_eval, METH_VARARGS,
	    "eval(): a simple R expression"},
    {"inspect", py_inspect, METH_VARARGS,
	    "inspect(): in"},
//   {"fp",   py_force_promise, METH_VARARGS, "force promise"},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

#define R_doc  "R_module: provide functions to get and put R objects"

static struct PyModuleDef Rmodule = {
    PyModuleDef_HEAD_INIT,
    "RInterface",   /* name of module */
    R_doc, /* module documentation, may be NULL */
    -1,       /* size of per-interpreter state of the module,
                 or -1 if the module keeps state in global variables. */
    RMethods
};

PyMODINIT_FUNC
PyInit_R(void)
{
      PyObject *m;

      m = PyModule_Create(&Rmodule);
      if (m == NULL) return NULL;

      RError = PyErr_NewException("R.error", NULL, NULL);
      Py_XINCREF(RError);
      if (PyModule_AddObject(m, "error", RError) < 0) {
        Py_XDECREF(RError);
        Py_CLEAR(RError);
        Py_DECREF(m);
        return NULL;
      }

      /*
      { // change its Dict's get func
        PyObject *dict = PyModule_GetDict(m);
	Py_Print(dict, "Rmodule_GetDict");
	PyDictObject *mp = (PyDictObject *) dict;
	// ((PyModuleObject *)m) -> md_dict
	// ix = (mp->ma_keys->dk_lookup)(mp, key, hash, &value);
	// __promise_dk_lookup: force_promise 
	// the problem is that you cannot change mp->ma_keys->dk_lookup
	// do it at the higher level?

	//PyModuleObject *mod = (PyModuleObject *)m;
	//fprintf(stderr, "mod->\n");
      }
      */

      return m;
}

#define supr_doc  "supr_module: provide functions to get and put R objects"

// Python example:
static PyObject *
supr_system(PyObject *self, PyObject *args)
{
//	c_backtrace(); sleep(30);
    const char *command;
    int sts;

    if (!PyArg_ParseTuple(args, "s", &command))
        return NULL;
    sts = system(command);
    if (sts < 0) {
        PyErr_SetString(SuprError, "System command failed");
        return NULL;
    }
    return PyLong_FromLong(sts);
}


static PyObject *
supr_get(PyObject *self, PyObject *args)
{
//  __Py_Print(self, __func__);

  const char *name;
  if (!PyArg_ParseTuple(args, "s", &name))
        return NULL;

  SEXP r_val = findVar(install(name), R_GlobalEnv); // _Shared??
  if(r_val != R_UnboundValue){
    if(Rython_isPyObjectWrapper(r_val))
      return (PyObject *) R_ExternalPtrAddr(r_val);
    else {
      return Rython_capsulate(r_val);
    }
  }
  PyErr_SetString(PyExc_ValueError, "cannot find the named object");
  return NULL;
}



static PyMethodDef SuprMethods[] = {
    //...
    {"get",  supr_get, METH_VARARGS,
     "Get a R object from .GlobalEnv"},
    {"system",  supr_system, METH_VARARGS,
     "Execute a shell command."},
 //   ...
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

static struct PyModuleDef suprmodule = {
    PyModuleDef_HEAD_INIT,
    "supr",   /* name of module */
    supr_doc, /* module documentation, may be NULL */
    -1,       /* size of per-interpreter state of the module,
                 or -1 if the module keeps state in global variables. */
    SuprMethods
};

PyMODINIT_FUNC
PyInit_supr(void)
{
    PyObject *m;

    m = PyModule_Create(&suprmodule);
    if (m == NULL) return NULL;

    SuprError = PyErr_NewException("supr.error", NULL, NULL);
    Py_XINCREF(SuprError);
    if (PyModule_AddObject(m, "error", SuprError) < 0) {
        Py_XDECREF(SuprError);
        Py_CLEAR(SuprError);
        Py_DECREF(m);
        return NULL;
    }

    //fprintf(stderr, "OKA 1 (%s:%d)\n", __FILE__, __LINE__);

    // include Rmodule
    PyObject *r = PyInit_R();
    if(r) {
      //fprintf(stderr, "OKA 2 (%s:%d)\n", __FILE__, __LINE__);
      if (PyModule_AddObject(m, "R", r) < 0) {
        Py_XDECREF(r);
        Py_DECREF(r);
      }
    }

    return m;
}

////////////////////////////////////

#define __USE_GNU
#include <dlfcn.h>

//#define _GNU_SOURCE         /* See feature_test_macros(7) */
#include <link.h>

//int dl_iterate_phdr( int (*callback) (struct dl_phdr_info *info, size_t size, void *data), void *data);
int dl_iter_callback (struct dl_phdr_info *info, size_t size, void *data)
{
  char *target = (char*) data;
  fprintf(stdout, "[%s] %s\n", strstr(info->dlpi_name, target) ? "*": " ",
  	                  info->dlpi_name);
  if(strstr(info->dlpi_name, target)){
	 char *type;
	 int p_type, j;
         for (j = 0; j < info->dlpi_phnum; j++) {
               p_type = info->dlpi_phdr[j].p_type;
               type =  (p_type == PT_LOAD) ? "PT_LOAD" :
                       (p_type == PT_DYNAMIC) ? "PT_DYNAMIC" :
                       (p_type == PT_INTERP) ? "PT_INTERP" :
                       (p_type == PT_NOTE) ? "PT_NOTE" :
                       (p_type == PT_INTERP) ? "PT_INTERP" :
                       (p_type == PT_PHDR) ? "PT_PHDR" :
                       (p_type == PT_TLS) ? "PT_TLS" :
                       (p_type == PT_GNU_EH_FRAME) ? "PT_GNU_EH_FRAME" :
                       (p_type == PT_GNU_STACK) ? "PT_GNU_STACK" :
                       (p_type == PT_GNU_RELRO) ? "PT_GNU_RELRO" : NULL;

               printf("    %2d: [%14p; memsz:%7lx] flags: 0x%x; ", j,
                       (void *) (info->dlpi_addr + info->dlpi_phdr[j].p_vaddr),
                       info->dlpi_phdr[j].p_memsz,
                       info->dlpi_phdr[j].p_flags);
               if (type != NULL)
                   printf("%s\n", type);
               else
                   printf("[other (0x%x)]\n", p_type);
           }

  }
  return 0;
}

/*
SEXP Rython_Repl()
{
  wchar_t *argv[1]; // = {"python3.6m"};

  {
    if (setlocale(LC_ALL, "") == NULL) {
               perror("setlocale");
               exit(EXIT_FAILURE);
    }
    
    size_t mbslen = mbstowcs(NULL, "python3.6m", 0);
    if (mbslen == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
    }
    
    argv[0] = calloc(mbslen + 1, sizeof(wchar_t));
    if (argv[0] == NULL) {
               perror("calloc");
               exit(EXIT_FAILURE);
    }

    if (mbstowcs(argv[0], "python3.6m", mbslen + 1) == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
           }

  }

  printf("sizeof(wchar_t): %ld\n", sizeof(wchar_t));
  int argc = sizeof(argv)/sizeof(wchar_t*);

    //BEGIN_R_FREE();
  rl_callback_handler_remove();
  Py_Main(argc, argv);
    //END_R_FREE();
}
*/

/*
void Rython_initialize_readline ()
{
  rl_readline_name = "Python";
  rl_ding();
  rl_initialize();
}
*/

int my_PyOS_InputHook()
{
	c_backtrace();
	size_t buf_size = 100;
	char buf[buf_size];
	fprintf(stderr, "%s: fgets\n", __func__);
	char *s = fgets(buf, buf_size, stdin);
	fprintf(stderr, "%s: %s\n", __func__, s);
	return 0;
}

// char* (*PyOS_ReadlineFunctionPointer)(FILE *, FILE *, const char *)

int Supr_getSignal();

char* my_PyOS_ReadlineFunction(FILE *stdin, FILE *stdout, const char *prompt)
{
	/*
	fprintf(stderr, "%s: %s\n", __func__, prompt);
	c_backtrace();
	char *buf = (char*) PyMem_RawMalloc(100);
	sprintf(buf, "1+2\n");
	sleep(5);
	return buf;
	*/
	   //fprintf(stderr, "[%s] next \n", __func__);
	//char *line = readline(prompt); // signals???
        char *line = ptr_readline(prompt);

	   if(Supr_getSignal()){
              printf("\t[%s] Supr_getSignal(): %d\n", __func__,
			      Supr_getSignal());
              //if(__thread_rl.sig == SIGINT) LONGJMP(Console_read_jmpbuf,1);

	   /*
              if(__thread_rl.sig == SIGUSR2)
                Thread_SigactionSIGUSR2(__thread_rl.sig, __thread_rl.info,
                                __thread_rl.ucontext); // NORET
              else if(__thread_rl.sig == SIGINT && cth->data == PTHREAD_ERROR)
                Thread_SigactionSIGUSR2(__thread_rl.sig, __thread_rl.info,
                                __thread_rl.ucontext); // NORET
              //else printf("\t[%s] ignored ...\n", __func__);
	      */

              //continue;
            }


	int rc;
	if(rc = PyErr_CheckSignals())
	   fprintf(stderr, "[%s] PyErr_CheckSignals(): %d\n", __func__, rc);

	if(PyErr_Occurred()){
	   fprintf(stderr, "[%s] PyErr_Occurred()\n", __func__);
	}

	if(!line) {
	   fprintf(stderr, "[%s] line: \"%s\"\n", __func__, line);
	   //line = (char*)malloc(1);
	   //line[0] = 0;
	   // jump...
//		PyExc_MemoryError
		/*
	    fprintf(stderr, "[%s] Py_TYPE(PyExc_KeyboardInterrupt): %p\n",
			    __func__, Py_TYPE(PyExc_KeyboardInterrupt));
	    Py_Print(PyExc_KeyboardInterrupt, "PyExc_KeyboardInterrupt");
            PyErr_SetNone(PyExc_KeyboardInterrupt);
	    */
            //PyErr_SetNone(PyExc_SyntaxError);
//		currentThread()->data = PyExc_KeyboardInterrupt;
	   for(;;) {
	     // fprintf(stdout, "quit? [y/n/c]");
	     // fflush(stdout);
             char *buf = ptr_readline("quit? [y/n/c] ");
	     if(!buf){
	       void **intr_addr = pthread_getspecific(rythonInterruptKey);
	       *intr_addr = PyExc_EOFError;
	       free(buf); // CleanUp ...
	       return NULL;
	     } else if(buf && *buf=='y'){
	       buf = (char*) PyMem_RawMalloc(strlen("supr.R.q()\n"+1));
	       sprintf(buf, "supr.R.q()\n");
	       return buf;
	     } else if(buf && *buf=='n'){
	       buf = (char*) PyMem_RawMalloc(2);
	       buf[0] = '\n'; buf[1] = 0;
	       return buf;
	     } 
	   }
	   return NULL;
	}
	size_t len = strlen(line);
	char *buf = (char*) PyMem_RawMalloc(len+2);
	memcpy(buf, line, len+1);
	if(buf[len-1] != '\n')
	{
	  buf[len]  = '\n';
	  buf[len+1]  = 0;
	}
	//free(line); ???

	if(line && strlen(line))
	  add_history(line);

//            PyErr_SetNone(SuprError);
	return buf;

}

/*
static int __Ctr_D_command_func(int count, int key)
{
 // fprintf(stderr, "%s is called\n", __func__);
  fprintf(stderr, "\n\n[%s] Ctr_D: jump?\n\n\n", __func__);
  // KeyboardInterrupt
  //PyErr_SetString(PyExc_KeyboardInterrupt, "\\Ctr-D");
  //PyErr_SetNone(PyExc_KeyboardInterrupt);
  //RCNTXT *cntxt = R_GlobalContext;
  //longjmp(cntxt->cjmpbuf, 0);

  //c_backtrace();
  //PyErr_SetNone(PyExc_KeyboardInterrupt);
}
*/

#define DEBUG_SET_ERROR	\
  {	\
      PyErr_SetNone(PyExc_SystemError);	\
      Rython_checkError(TRUE);	\
  }

SEXP Rython_init();

SEXP Rython_repl()
{

  // FIXME
  if(! strstr(LIB_PYTHON, "3.6m"))
	  error(_("Unimplemented for Python:%s"), LIB_PYTHON);

  if ( ! Py_IsInitialized() ) Rython_init();

//DEBUG_SET_ERROR

	//{
		//PyObject *prom = RyPromise_New(R_GlobalEnv, R_GlobalEnv);
		//Py_Print(prom, __func__);
		/*
		prom = _PyObject_New(&RyPromiseObject_Type);
		prom = PyObject_Init(prom, &RyPromiseObject_Type);
		Py_Print(prom, "GOOD: RyPromiseObject_Type");
		*/
	//}

  RCNTXT *cntxt = R_GlobalContext;

  void *py_onintr = NULL;
  pthread_setspecific(rythonInterruptKey, &py_onintr);
  /*
  if(setjmp(cntxt->cjmpbuf))
  {
	  fprintf(stderr, "FIXME: CleanUp\n");
	  return R_NilValue;
  }
  */

  //  rl_callback_handler_remove();
   // Rython_initialize_readline ();
  { // move this to supr.c
//		rl_bind_keyseq("\\C-d", __Ctr_D_command_func);


    PyObject *dict = PyModule_GetDict(PyImport_AddModule("builtins"));
    PyObject *quit = PyDict_GetItemString(dict, "quit");
    Py_Print(quit, "quit");
    if(PyCallable_Check(quit)) {
      fprintf(stderr, "[%s] quit is callable\n", __func__);
    }

    // not any of the following
    if(PyCFunction_Check(quit)) {
      fprintf(stderr, "[%s] quit is CFunction\n", __func__);
    }
    if(PyFunction_Check(quit)) {
      fprintf(stderr, "[%s] quit is Function\n", __func__);
    }
    if(PyMethod_Check(quit)) {
      fprintf(stderr, "[%s] quit is Method\n", __func__);
    }

    PyDict_SetItemString(dict, "Quit", quit);
    PyDict_SetItemString(dict, "quit", Py_None);



    PyObject *cfunc = NULL;
    int flags = -1;

    PyObject *meth = quit;
    PyObject *method_name = NULL;


    if(Py_TYPE(meth) == &PyWrapperDescr_Type){
      Py_Print(meth, "Wrapped");
      PyTypeObject *d_type =  PyDescr_TYPE(meth);
      Py_Print((PyObject *)d_type, "descr_type");
      PyObject *d_name = PyDescr_NAME(meth);
      Py_Print(d_name, "descr_name");
//      PyWrapperDescrObject *wrapper = (PyWrapperDescrObject *) meth;
      method_name = d_name;
      /*
      cfunc = PyObject_GetAttr(obj, d_name);
      Py_Print(cfunc, "obj->cfunc");
      PyObject *self = PyCFunction_GET_SELF(cfunc);
      Py_Print(self, "obj->cfunc->self");
      fprintf(stdout, "%p == %p\n", self, obj);
      */
    } else if(Py_TYPE(meth) == &PyMethodDescr_Type){
      Py_Print(meth, "Wrapped");
      PyTypeObject *d_type =  PyDescr_TYPE(meth);
      Py_Print((PyObject *)d_type, "descr_type");
      PyObject *d_name = PyDescr_NAME(meth);
      Py_Print(d_name, "descr_name");

      method_name = d_name;
      /*
      cfunc = PyObject_GetAttr(obj, d_name);

      Py_Print(cfunc, "obj->cfunc");
      PyObject *self = PyCFunction_GET_SELF(cfunc);
      Py_Print(self, "obj->cfunc->self");
      fprintf(stdout, "%p == %p\n", self, obj);
      */

//      flags = method->ml_flags & ~(METH_CLASS | METH_STATIC | METH_COEXIST);
      flags = PyCFunction_GET_FLAGS(cfunc)
              & ~(METH_CLASS | METH_STATIC | METH_COEXIST);
      fprintf(stdout, "flags: %d, METH_O: %d\n", flags, METH_O);
    }


    
  }



//DEBUG_SET_ERROR

   PyObject *mod = PyImport_AddModule("supr");
   PyObject *main = PyImport_AddModule("__main__"); // add to ...
   PyDict_SetItemString(PyModule_GetDict(main), "supr", mod);
   {
     PyObject *prom = RyPromise_New(R_GlobalEnv, R_GlobalEnv);
     //Py_Print(prom, __func__);
     // test getattr and setter
     PyDict_SetItemString(PyModule_GetDict(main), "to", prom);
     prom = RyPromise_New(R_GlobalEnv, R_GlobalEnv);
     //Py_Print(prom, __func__);
     PyDict_SetItemString(PyModule_GetDict(main), "R_GlobalEnv", prom);

     /*
     PyMethodDef *ml = (PyMethodDef *) malloc(sizeof(PyMethodDef));
     ml->ml_name = "__dir__";
     ml->ml_meth = __promise___dir__;
     ml->ml_flags = METH_O;
     ml->ml_doc  = "dir(R_ENVSXP)";
     PyObject *R_Env___dir__ = PyCFunction_New(ml, prom); 
     //_PySys_SetObjectId(&PyId___dir__, R_Env___dir__);

     PyObject *v = _PySys_GetObjectId(&PyId___dir__);
     Py_Print(v, "PyId___dir__");
     v = _PySys_GetObjectId(&PyId___getattr__);
     Py_Print(v, "PyId___getattr__");
     v = _PySys_GetObjectId(&PyId___dict__);
     Py_Print(v, "PyId___dict__");
     */

   }
	PyOS_InputHook = my_PyOS_InputHook;
   PyOS_ReadlineFunctionPointer = &my_PyOS_ReadlineFunction;

    FILE *fp = stdin;
    const char *filename = "<stdin>";
    //PyCompilerFlags *flags;
    /*
    PyCompilerFlags _PyCompilerFlags_INIT = {0};
    PyCompilerFlags *cf = &_PyCompilerFlags_INIT;
    */
    PyCompilerFlags *cf = NULL;
    //int err = PyRun_InteractiveLoopFlags(fp, filename, cf);
// int PyRun_InteractiveOneFlags(FILE *fp, const char *filename, PyCompilerFlags *flags)
    int err;
//    ps1 = ">>> ";
//    ps2 = "... ";
    PyObject *v;
    _PySys_SetObjectId(&PyId_ps1, v = PyUnicode_FromString(">>> "));
    Py_XDECREF(v);
    _PySys_SetObjectId(&PyId_ps2, v = PyUnicode_FromString("... "));
    Py_XDECREF(v);

//DEBUG_SET_ERROR
    do {
      err = PyRun_InteractiveOneFlags(fp, filename, cf);
      //fprintf(stderr, "onintr: %p\n", py_onintr);
      //PyObject *onintr = (PyObject *) py_onintr;
      //Py_Print(onintr, "onintr");
      PyObject *e;
      if(err == -1 && (e= PyErr_Occurred())){
	Rython_printError(e);
        PyErr_Print();
	fflush(stdout);
      }

      //if(currentThread()->data == PyExc_KeyboardInterrupt) break;
      //if(onintr == PyExc_KeyboardInterrupt) break;
//DEBUG_SET_ERROR
    } while (py_onintr != PyExc_EOFError); // (err != -1);
    //fprintf(stderr, "exit err: %d\n", err);

    pthread_setspecific(rythonInterruptKey, NULL);

    return ScalarInteger(err);
}

SEXP Rython_init()
{

#ifdef USE_PYTHON

//Rython_Repl();



  if( Py_IsInitialized() )
	  error(_("Rython is already initialized"));


  // Set by the -v option and the PYTHONVERBOSE environment variable.
  //Py_VerboseFlag = 2;
  //Py_VerboseFlag = 1;

  //
  const char *argv_0 = "python3.6m";
  wchar_t *program = Py_DecodeLocale(argv_0, NULL);
    if (program == NULL) {
        fprintf(stderr, "Fatal error: cannot decode \"%s\"\n", argv_0);
        exit(1);
    }
    //

   /* Add a built-in module, before Py_Initialize */
    /////
    PyImport_AppendInittab("supr", PyInit_supr);

    wchar_progname = program;
    Py_SetProgramName(wchar_progname);  // optional but recommended
//  Py_DebugFlag  =1;

//  const char *progname = "Embeded Python"; // _01 ???


    /*
  {
//    wchar_t *wchar_progname;
    if (setlocale(LC_ALL, "") == NULL) {
               perror("setlocale");
               exit(EXIT_FAILURE);
    }

    size_t mbslen = mbstowcs(NULL, argv_0, 0);
    if (mbslen == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
    }

    wchar_progname = calloc(mbslen + 1, sizeof(wchar_t));
    if ( wchar_progname== NULL) {
               perror("calloc");
               exit(EXIT_FAILURE);
    }

    if (mbstowcs(wchar_progname, argv_0, mbslen + 1) == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
           }

    Py_SetProgramName(wchar_progname);  // optional but recommended

  }
  */

  // The basic initialization function is Py_Initialize(). This initializes the table of loaded modules, and creates the fundamental modules builtins, __main__, and sys. It also initializes the module search path (sys.path).

  // Py_Initialize() does not set the “script argument list” (sys.argv). If this variable is needed by Python code that will be executed later, it must be set explicitly with a call to PySys_SetArgvEx(argc, argv, updatepath) after the call to Py_Initialize().

  //void PySys_SetArgvEx(int argc, wchar_t **argv, int updatepath);
  //wchar_t *argv[1];
  wchar_t *argv[] = {program};
  size_t size;

  //argv[0] = Py_DecodeLocale("python3.6m", &size);
  /*
  {
    if (setlocale(LC_ALL, "") == NULL) {
               perror("setlocale");
               exit(EXIT_FAILURE);
    }

    size_t mbslen = mbstowcs(NULL, "python3.6m", 0);
    if (mbslen == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
    }

    argv[0] = calloc(mbslen + 1, sizeof(wchar_t));
    if (argv[0] == NULL) {
               perror("calloc");
               exit(EXIT_FAILURE);
    }

    if (mbstowcs(argv[0], "python3.6m", mbslen + 1) == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
           }
  }
  */

  int updatepath = 0;

  int libpython3_6m_loaded = 0;

  /*
  {
    int rc = dl_iterate_phdr( dl_iter_callback, "libpython3.6m.so");
  }
  fprintf(stderr, "Before Py_Initialize\n");
  sleep(10);
  */
  
  //
  if( ! libpython3_6m_loaded ) { // reload
  // Check /proc/pid/maps???
  // ltrace is a program that simply runs the specified command until it exits
  // ...
  //
  
// setenv LD_LIBRARY_PATH /usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH

    //const char *dl_filename = "libpython3.6m.so";
    const char *dl_filename = LIB_PYTHON;
    void *dl_handle = dlopen(dl_filename, RTLD_NOW | RTLD_GLOBAL); 
    if(!dl_handle) error(_("dlopen: %s\ndlerror: %s"), dl_filename,
		    dlerror());
    void *func = dlsym(dl_handle, "PyExc_SystemError");
    if(!func) error(_("dlsym, PyExc_SystemError: %s"), strerror(errno));
  }
  //

  Py_Initialize();

  /*
  {
    int rc = dl_iterate_phdr( dl_iter_callback, "libpython3.6m.so");
  }
  fprintf(stderr, "After Py_Initialize\n");
  sleep(10);
  */


  PySys_SetArgvEx(sizeof(argv)/sizeof(wchar_t *), argv, updatepath);

  /*
  {
    int rc = dl_iterate_phdr( dl_iter_callback, "libpython3.6m.so");
  }
  fprintf(stderr, "After PySys_SetArgvEx\n");
  sleep(60);
  */

//  PySys_SetArgvEx(sizeof(argv)/sizeof(wchar_t *), argv, updatepath);

  //////////
  // /usr/lib/x86_64-linux-gnu/libpython3.6m.so
 
  /*
  PyObject *npy = PyImport_ImportModule("numpy");

  PyObject *err = PyErr_Occurred();
  if(err) Rython_printError(err);

  if(npy)
    Py_INCREF(npy);
    */


  PyImport_ImportModule("supr");

  { // Create 
    
#define DEFAULT_HASH_SIZE 29
    R_RythonEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
               ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install(".PythonEnv"), R_RythonEnv, R_GlobalEnv);
    setAttrib(R_RythonEnv, R_ClassSymbol, mkString("PythonEnv"));
    UNPROTECT(1);
#undef DEFAULT_HASH_SIZE
    defineVar(install("sys"), RObject_wrapper(PyImport_AddModule("sys")),
		    R_RythonEnv);
    defineVar(install("main"),
	    RObject_wrapper(PyImport_AddModule("__main__")), R_RythonEnv);
    defineVar(install("builtins"),
	    RObject_wrapper(PyImport_AddModule("builtins")), R_RythonEnv);
  }
	
  pthread_key_create(&rythonThreadKey, NULL);
  PyObject *globals = PyDict_New();
  pthread_setspecific(rythonThreadKey, globals);

  pthread_key_create(&rythonInterruptKey, NULL);

	{
	  int rc = PyType_Ready(&RyPromiseObject_Type);
	  if(rc == -1) error(_("initialize RyPromiseObject_Type"));
	  rc = PyType_Ready(&Deprecated_RyPromiseObject_Type);
	  if(rc == -1) error(_("initialize RythonObject_Type"));
//static PyTypeObject RythonObject_Type = {
	}



  return R_RythonEnv;

  //{ // checking
    //PyObject *modules = PySys_getObject("modules");
    //assert(PyDict_Check(modules));
  /*
    PyObject *sys_module = PyImport_AddModule("sys");
    PyObject *sys_dict = PyModule_GetDict(sys_module);
    PyObject *sys_path = PyDict_GetItemString(sys_dict, "path");
    PyObject_Print(sys_path, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\n");
    fprintf(stdout, "Python %s\n", Py_GetVersion());
    */

// [       '/usr/lib/python36.zip', '/usr/lib/python3.6', '/usr/lib/python3.6/lib-dynload', '/usr/local/lib/python3.6/dist-packages', '/usr/lib/python3/dist-packages']
// == ? ==
//    ['', '/usr/lib/python36.zip', '/usr/lib/python3.6', '/usr/lib/python3.6/lib-dynload', '/usr/local/lib/python3.6/dist-packages', '/usr/lib/python3/dist-packages']

    /*
    wchar_t *w_home = Py_GetPythonHome();
    // wchar_t* Py_DecodeLocale(const char* arg, size_t *size)
    // char* Py_EncodeLocale(const wchar_t *text, size_t *error_pos)
    size_t error_pos;
    char *c_home = Py_EncodeLocale(w_home, &error_pos);
    fprintf(stdout, "PythonHome: %s\n", c_home);
    */

    /*
    {
      PyObject *builtins_module = PyImport_AddModule("builtins");
      PyObject *builtins_dict = PyModule_GetDict(builtins_module);
      return PyObject_toROject(builtins_dict);
      PyObject *globals_func = PyDict_GetItemString(sys_dict, "globals");
      PyObject *val = PyObject_CallObject(globals_func, NULL);
      return PyObject_toROject(val);
    }
    */

    //return PyObject_toROject(sys_path);
  //}

  // for now ...
  /*
  py_runtime_t *py_runtime = malloc(sizeof(py_runtime_t));
  py_runtime->progname = strdup(progname);
  py_runtime->module_list = NULL; // deprecated ...
  */
  /*
  __py_AddModule(call, "__main__", py_runtime);
  __py_AddModule(call, "sys", py_runtime);
  __py_AddModule(call, "builtins", py_runtime);
  __py_AddModule(call, "numpy", py_runtime);
  */
  {
    PyObject *sys_module = PyImport_AddModule("sys");

    Rython_addModule(sys_module, "sys");

    PyObject *global_dict = PyDict_New();
    PyObject *local_dict = PyDict_New();

    Rython_addDict(global_dict, "supr_global_dict");
    Rython_addDict(local_dict, "supr_local_dict");

    PySys_SetObject("supr_global_dict", global_dict);
    PySys_SetObject("supr_lolcal_dict", local_dict);

//    PySys_SetObject("supr_local_dict", PyDict_New());

    //PySys_SetObject("supr_local_dict", global_dict);
    //PySys_SetObject("supr_global_dict", PyDict_New());

    PyDict_SetItemString(global_dict, "__main__",
                    PyImport_AddModule("__main__"));

  }

  Rython_dumper();

  SEXP py_ptr = PROTECT(R_MakeExternalPtr(Rython_runtime, null, null));

  // FIXME...
  /*
  SEXP klass = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                          //findVar(install("Object"), R_ClassEnv),
                  ScalarInteger(29)));
  //setAttrib(py_ptr, R_ClassEnvSymbol, klass);
  setAttrib(py_ptr, R_ClassSymbol, klass);
  setAttrib(klass, R_NameSymbol, mkString("Python"));
  setAttrib(klass, R_ClassSymbol, mkString(".Class"));
  //setAttrib(klass, R_ClassEnvSymbol, findVar(install("Class"), R_ClassEnv));
  //setAttrib(klass, R_ClassSymbol, findVar(install("Class"), R_ClassEnv));
  //defineVar(install("Python"), klass, R_ClassEnv);

  SEXP callClassFun =  findFun(install(".callClassFun"), R_BaseEnv);

  // construct these from the above python_funs ???
  */
  /*
  defineVar(install("SimpleString"),    callClassFun, klass);
  defineVar(install("SimpleFile"),    callClassFun, klass);
  defineVar(install("CallObject"),    callClassFun, klass);
  */

  /*
  T_class_fun_t *pfun = python_funs;
  for(int i=0; pfun[i].name; i++)
          defineVar(install(pfun[i].name),    callClassFun, klass);
	  */

  /*
  for(int i=0; pfun[i].name; i++){
    defineVar(install(pfun[i].name),    callClassFun, klass);
    SEXP fun = PROTECT(allocSExp(CLOSXP));
    CLOSENV(fun) = R_BaseEnv;
  }
  */


//  SEXP R_DocSymbol = install("doc");

  //R_RegisterCFinalizer(py_ptr, python_finalizer);

  /*
  printf("Examples:\n\nSimpleString(\"from time import time, ctime\\n"
      "print('Today is', ctime(time()))\\n\")\n");
  printf("\nSimpleFile(\"script.py\")\n\n");
  */

  //T_PROTECT(py_ptr);
  //UNPROTECT(2);
  UNPROTECT(1);

  return py_ptr;
#else
  error(_("not implemented"));
#endif
}

#endif

