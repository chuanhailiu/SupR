# Writing R Extensions ($1.1.5): It is run as part of the installation in
# src build directory install of copying the shared objects

#change its suffix to .R

print("src/install.libs.R is called")

print(SHLIB_EXT)
files <- Sys.glob(paste0("*", SHLIB_EXT))
print(files)
print(R_PACKAGE_DIR)
print(R_ARCH)
dest <- file.path(R_PACKAGE_DIR, paste0('libs', R_ARCH))
print(dest)
if(!dir.exists(dest))
  dir.create(dest, recursive = TRUE, showWarnings = TRUE)
file.copy(files, dest, overwrite = TRUE)
if(file.exists("symbols.rds"))
 file.copy("symbol.rds", dest, overwrite = TRUE)

#execs <- c("driver", "master", "worker", "taskrunner", "dfs_name", "dfs_data")
execs <- c("driver", "master", "worker", "taskrunner", "dfs_name", "dfs_data", "threadserver")
if( any(file.exists(execs)) ) {
  dest <- file.path(R_PACKAGE_DIR, paste0('bin', R_ARCH))
  if(!dir.exists(dest))
    dir.create(dest, recursive = TRUE, showWarnings = TRUE)
  file.copy(execs, dest, overwrite = TRUE)
}

#to <- file.path(R_PACKAGE_DIR, paste0('bin/libsupr.so', R_ARCH))
#from <- file.path(R_PACKAGE_DIR, paste0('libs/libsupr.so', R_ARCH))
#file.symlink(from, to)

