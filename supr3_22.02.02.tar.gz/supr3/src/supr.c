
#define SUPR3

#define __SUPR_MAIN__

// to use USE_RINTERNALS section in Internals.h
#define USE_RINTERNALS

#define __USE_XOPEN2KXSI
#define __USE_XOPEN

#include "supr.h"
#include "util.h"


#include <sys/types.h>
#include <sys/wait.h>

//#include <sys/types.h>
//#include <sys/wait.h>

/*
#define HAVE_CONFIG_H 1

#if HAVE_CONFIG_H
//#include<config.h>
#include "config.h"

#if HAVE_PYTHON3_6M_PYTHON_H
#define USE_PYTHON
//#ifdef  USE_PYTHON
//#include <python3.6m/Python.h>
#include <python3.6m/Python.h>
#include <locale.h>
//#endif
#endif

#endif
*/

#ifdef USE_PYTHON
#include <Python.h>
#endif

#include <locale.h>
#include <pwd.h>

// FIXME
#ifndef _
#define _(x) (x)
#endif

#define THREAD_START 1

// from Defn.h
#define DEFAULTDEPARSE          1089

#ifdef SUPR3

// Use the variadic macro in the C preprocessor ?
/*
void realdbgprintf (const char *SourceFilename,
                    int SourceLineno,
                    const char *CFormatString,
                    ...)
{
}
#define dbgprintf(...) realdbgprintf (__FILE__, __LINE__, __VA_ARGS__)
*/

// from R/envir.c
#define IS_USER_DATABASE(rho)  (OBJECT((rho)) && inherits((rho), "UserDefinedDatabase"))

  int localEnvPort = 0;
  const char *localEnvHost = NULL;
  int clusterEnvPort = 0;
  const char *clusterEnvHost = NULL;

  int localThreadServerPort = -1;
  const char *localThreadServerHost = NULL;

  char *proc_cmd = NULL;
  char *cmd = NULL;

unsigned long save_cstackstart; // = R_CStackStart;

#define THREAD_PROC_EXISTS 3001
#define THREAD_PROC_REMOVE 3002
#define THREAD_PROC_LIST   3003
//#define THREAD_PROC_EVAL   3004
#define THREAD_PROC_NEW    3005
#define THREAD_PROC_START  3006
#define THREAD_PROC_JOIN   3007
#define THREAD_PROC_STOP   3008

#define THREAD_PROC_STATE  3009
#define THREAD_PROC_SIGSTATE SIGUSR2

#define THREAD_PROC_CHILD_START 3010
#define THREAD_PROC_INTERRUPT   3011
#define SUPR_INFO   3012
#define THREAD_SERVER_SHUTDOWN 3013

SEXP SuprContextEnv = NULL;
SEXP SuprJobEnv = NULL;
SEXP SuprBroadcastedEnv = NULL;
char *shm_prefix = NULL;

SEXP SuprContext = NULL; // delete me

static int threadState = -1;
static supr_socket_conn_t *ForkedChild_sc = NULL;

SEXP SuprEnv = NULL; // R_GlobalEnv$.SuprEnv
SEXP SuprThreads = NULL; // SuprEnv$.SuprThreads

struct sigaction R_SIGINT_sigaction;
/*
  sa.sa_sigaction = Supr_SigactionSIGINT_enabled;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
  sigaction(SIGINT, &sa, &R_oldactInt);
  */


/*
int __pthread_sigmask__(int how, const sigset_t *set, sigset_t *oldset,
		const char *file, int line, const char *fun)
{
	supr_thread_t *cth = SUPR_CURRENT_THREAD();
  char *_h = how == SIG_BLOCK?"BLOCK":"UNBLOCK";	
  char *_s = sigismember(set, SIGINT)?"SIGINT":"*";
  fprintf(stderr, "[%s] %s:%d:%s: pthread_sigmask(%s, \033[0;31m%s\033[0m, ...)\n",
		  cth?  cth->name : "(null)",
		  file, line, fun, _h, _s);
  return pthread_sigmask(how, set, oldset);
}

#define pthread_sigmask(h, s, o) __pthread_sigmask__(h, s, o, __FILE__, __LINE__, __func__) 

*/


/*
int DFLT_SO_RCVBUF = 0;
int DFLT_SO_SNDBUF = 0;
int DFLT_NONBLOCK = 0;
*/

#define gettid() ((int)syscall(SYS_gettid))

#define SUPR_GDB_DEBUG() 	do{	\
  char *buf = NULL;	\
  Supr_debug2(getpid(), &buf);	\
  if(buf) error_info(buf);	\
  free(buf);	\
} while(0)

SEXP Sys_gettid(){
  return ScalarInteger((int)syscall(SYS_gettid));
}
SEXP Sys_getppid(){
  return ScalarInteger(getppid());
}

const char *__doc__ = "\n"
"? supr\n"
"grep(\"[Tt]hread\", ls(\"package:supr3\"), value=TRUE)\n"
"grep(\"DD\", ls(\"package:supr3\"), value=TRUE)\n"
"grep(\"[Cc]luster\", ls(\"package:supr3\"), value=TRUE)\n"
;

typedef struct sync_info_struct {
  pid_t R_owner;
  pid_t padding; // TODO
} sync_info_t;

sync_info_t Sync_info = {0, 0};

pthread_mutex_t Supr_syncMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  Supr_syncCond  = PTHREAD_COND_INITIALIZER;
void *Supr_syncObject = NULL;

supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);
SEXP ThreadServer_connect(SEXP server);

SEXP Cluster_createObjectTableEnv(SEXP rho);
static void Cluster_connection_finalizer(SEXP s);
SEXP startRemoteThreadServer(SEXP s);

extern int shm_io_destroy (shm_io_info_t *io);
void Shm_io_info_finalizer (SEXP s){
  //fprintf(stderr, "%s... (FIXME)\n", __func__);
  fprintf(stderr, "%s... \n", __func__);
  shm_io_info_t *ii = (shm_io_info_t *)R_ExternalPtrAddr(s);
  int args[] = {DU_DISCONNECT};
  //shm_io_write(ii, ii->out, args, sizeof(args));
  shm_io_destroy(ii);
}

#ifdef SUPR3

static pthread_mutex_t supr3_R_Busy_mutex = PTHREAD_MUTEX_INITIALIZER;

#endif

void Supr_do_xterm(int use_xterm, int interactive);
int  (*Cluster_handleCommand)(supr_socket_conn_t *conn) = NULL;
char *X11_str = "_"; // NULL;

vector_t *threads = NULL;
vector_t *sys_threads = NULL;
vector_t *dcl_threads = NULL;

supr_socket_conn_t *debug_sc = NULL;
supr_socket_conn_t *info_sc = NULL;
supr_socket_conn_t *msg_sc = NULL;
supr_socket_conn_t *parent_sc = NULL;
char *info_addr = NULL;
char *msg_color = "\033[0;33m";

SEXP Cluster_startDriver(SEXP S_addr, SEXP S_port, SEXP S_master, SEXP S_dfs,
		SEXP S_verbose, SEXP S_debug, SEXP S_info);

#endif

//FIXME double supr_floor(double x) { return floor(x); }

//int Supr_lockQueueShow = FALSE; // TRUE

static supr_thread_t *eventHandlerThread = NULL;
SEXP DD_enableInfo(SEXP r_level);
static SEXP Supr_infoServer = NULL;
//static
SEXP Supr_namespace = NULL;
supr_socket_conn_t *DFS_namenode = NULL; // FIXME
//supr_socket_conn_t *Cluster_driver = NULL; // FIXME
supr_socket_conn_t *driver_sc = NULL; // FIXME
shm_io_info_t *driver_shm_io = NULL;

int nTrustedHosts = 0;
char **TrustedHosts = NULL;

static pthread_mutex_t MSG_syncMutex = PTHREAD_MUTEX_INITIALIZER;
supr_thread_t *main_thread = NULL; // change it to Thread_main?
vector_t *socket_connections = NULL;
vector_t *special_socket_connections = NULL;
vector_t *messages = NULL;
pthread_cond_t *messages_cond = NULL;

char *Supr_curStrError = NULL;

SEXP Cluster_messages();
pid_t main_pid=0;
void doCleanups();

tr_cntxt_t tr_cntxt = {NULL, -1, -1, 0, 0, NULL, NULL, NULL, 0};

char *Supr_curErrorBuf = NULL;
ssize_t Supr_curErrorBuf_size = 0;

/*
ssize_t socket_read(int fildes, const void *buf, size_t nbyte){
  
  ssize_t size = 0;
  unsigned char *buffer = (unsigned char *)buf;
  while(size < nbyte){
    ssize_t n = read(fildes,  buffer + size, nbyte - size);
    if(n==-1){
	  fprintf(stderr, "Error in %s, %s\n", __func__, strerror(errno));
	  return n;
    } 
    size += n;
  }
  return size;
}
*/

#define INFO_SERVER_SHUTDOWN -1
// FIXME
ssize_t real_read(int fd, void *buf, size_t size //,supr_socket_conn_t *sc
		)
{
//  if(!sc) return read(fd, buf,  size);

  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec = (int) Supr_options.timeout;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
//            if(ns==0) continue; else return -1;
              if(ns == 0) {
                //      errno = EWOULDBLOCK;
                error_info(strerror(errno));
                error_info("gdb -p %d; gdb -p %d", getpid(), gettid());
                /*
                {
                      char buf[256];
                      sprintf(buf, "gdb -p %d", getpid());
                      error_info(buf);
                }
                // sleep(60); return -1;
                */
		if(strcmp(proc_cmd, "R")==0)
		  error(_("%s"), strerror(errno));
                
              } else {
                error_info(strerror(errno));
                return -1;
              }
      }
    }

    ssize_t n = read(fd, buf + len,  size - len);

    if(n <= 0){
      char err[256];
      sprintf(err, "read, n = %ld, %s\n", n, strerror(errno));
      error_info(err);
      return -1;
    }


    len += n;
  }
  return size;
}

#define read(fd, buf, size) real_read((fd), (buf), (size))

//extern SEXP R_CurrentExpr;

SEXP (*__cluster_jobs_ptr__)() = NULL;
SEXP R_cluster_jobs(){
  if(__cluster_jobs_ptr__)
    return __cluster_jobs_ptr__();
  else
    return R_NilValue;
}
SEXP (*__cluster_job_ptr__)(SEXP) = NULL;
SEXP R_cluster_job(SEXP job_id){
  if(__cluster_job_ptr__)
    return __cluster_job_ptr__(job_id);
  else
    return R_NilValue;
}

char *color = "\033[0;33m";
static SEXP Supr_quit();

char *Supr_signal_shm_open(pid_t pid, int sig, void **mem_addr, ssize_t *size_addr){
  char shm_name[256];
  sprintf(shm_name, "%s-%d-signal-%d", shm_prefix, pid, sig);
  void *mem_ptr = Supr_shm_open(shm_name, size_addr);
  if(!mem_ptr) return NULL;
  *mem_addr = mem_ptr; 
  return strdup(shm_name);
}

char *Supr_signal_shm_create(pid_t pid, int sig, int cmd, void *msg, ssize_t len){
  char shm_name[256];
  sprintf(shm_name, "%s-%d-signal-%d", shm_prefix, pid, sig);
  {
     char path[strlen(shm_name)+strlen("/dev/shm/")+1];
     sprintf(path, "/dev/shm/%s", shm_name);
     if(access(path, F_OK) !=0 ) shm_unlink(shm_name);
  }
  ssize_t size = sizeof(pid_t) + sizeof(int) + len;
  void *ptr = Supr_shm_create(shm_name, size);
  if(!ptr) return NULL;
  pid_t this_pid = getpid();
  memcpy(ptr, &this_pid, sizeof(pid_t));
  memcpy(ptr + sizeof(pid_t), &cmd, sizeof(int));
  memcpy(ptr + sizeof(pid_t) + sizeof(int), msg, len);
  munmap(ptr, size);
  int rc = kill(pid, sig);
  if(rc == -1) {
    shm_unlink(shm_name);
    return NULL;
  }
  else
    return strdup(shm_name);
}

//#define  is_nall(x) (TYPEOF(x) == NILSXP)

void (*__start_master_fun__)(void *) = NULL;
void (*__start_dfsname_fun__)(void *) = NULL;
// driver
SEXP Supr_master(SEXP S_addr){
  basic_info(__func__);

//  PrintValue(R_CurrentExpr);

  const char *addr = TYPEOF(S_addr) == NILSXP ? NULL : CHAR(asChar(S_addr));

  if(!addr){
    supr_socket_conn_t *master = NULL;
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = vectorElementAt(socket_connections,i);
      if(sc->type == MASTER_CONN){
	      master = sc;
	      break;
      }
    }
    if(master){
      char buf[strlen(master->host)+32];
      sprintf(buf, "%s:%d", master->host, master->port);
      return mkString(buf);
    } 
  }

  if(!addr){
    SEXP S_addr = findVar(install("master"), SuprContextEnv);
    if(S_addr == R_UnboundValue) 
      return R_NilValue;
    addr = CHAR(asChar(S_addr));
  }

  pthread_mutex_lock(&main_thread->mutex);
    main_thread->data = strdup(addr);
    main_thread->fun  = __start_master_fun__;
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);

  return R_NilValue; // promise ...
}

SEXP Supr_dfsname(SEXP S_addr){
  basic_info(__func__);

  const char *addr = TYPEOF(S_addr) == NILSXP ? NULL : CHAR(asChar(S_addr));

  if(!addr){
    supr_socket_conn_t *dfs = NULL;
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = vectorElementAt(socket_connections,i);
      if(sc->type == DFS_NAMENODE_CONN){
              dfs = sc;
              break;
      }
    }
    if(dfs){
      char buf[strlen(dfs->host)+32];
      sprintf(buf, "%s:%d", dfs->host, dfs->port);
      return mkString(buf);
    }
  }

  if(!addr){
    SEXP S_addr = findVar(install("dfs"), SuprContextEnv);
    if(S_addr == R_UnboundValue)
      return R_NilValue;
    addr = CHAR(asChar(S_addr));
  }

  pthread_mutex_lock(&main_thread->mutex);
    main_thread->data = strdup(addr);
    main_thread->fun  = __start_dfsname_fun__;
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);

  return R_NilValue; // promise ...
}





SEXP Supr_signal(SEXP S_pid, SEXP S_sig, SEXP S_cmd, SEXP S_msg)
{
  pid_t pid = asInteger(S_pid);
  int sig = 0;
  if(TYPEOF(S_sig)==SYMSXP || TYPEOF(S_sig)==STRSXP) {
    const char *str_sig = CHAR(asChar(S_sig));
    if(strcmp(str_sig, "INT")==0) sig = SIGINT;
    else if(strcmp(str_sig, "USR1")==0) sig = SIGUSR1;
    else if(strcmp(str_sig, "USR2")==0) sig = SIGUSR2;
    else if(strcmp(str_sig, "KILL")==0) sig = SIGKILL;
    else if(strcmp(str_sig, "ABRT")==0) sig = SIGABRT;
    else if(strcmp(str_sig, "PIPE")==0) sig = SIGPIPE;
    else if(strcmp(str_sig, "WINCH")==0) sig = SIGWINCH;
    else if(strcmp(str_sig, "STOP")==0) sig = SIGSTOP;
    else if(strcmp(str_sig, "CONT")==0) sig = SIGCONT;
    else if(strcmp(str_sig, "CHLD")==0) sig = SIGCHLD;
  }
  int cmd = asInteger(S_cmd);
  ssize_t len = 0; // TODO: send S_msg object ...
  void *msg = NULL;
  char *shm_name = Supr_signal_shm_create(pid, sig, cmd, msg, len);
  if(shm_name)
    return mkString(shm_name);
  else
    error(_("%s"), strerror(errno));
}

/*
typedef struct supr_options_struct {
  int verbose;
  int debug;
  int info;
  int padding;
  double timeout;
// ...
} supr_options_t;
*/
//supr_options_t Supr_options = {FALSE, FALSE, FALSE, 0, 60.0};

/*
int __kill(pid_t pid, int sig){
  fprintf(stderr, "%s: %d KILLs(%d, %d) \n", cmd, getpid(), pid, sig);
  if(sig != 0)
    sleep(30);
  return kill(pid, sig);
}

#define kill(p, s) __kill((p), (s))
*/

/*
static const char *Supr_StrErrors[] =
{
  "Success",  //0
  "evaluating timeout expr", // 1
  "failed to evaluate timeout expr of wait", // 2
}

const char *Supr_strerror(int errno){
  if(errno < 0) return "unknown error";
}
*/

/*
void __basic_info__(const char *s, const char *file, int line, const char* func){
  char msg[strlen(s)+256];
  sprintf(msg, "%s:%d:%s, %s", file, line, func, s);
  Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
}
*/


void argv_info(int argc, char **argv){
  if(argc<=0) return;

  int len = 0;
  for(int i=0; i<argc; i++) len +=  strlen(argv[i]) + 2;

  char buf[len];
  sprintf(buf, "%s", argv[0]);
  for(int i=1; i<argc; i++)
    sprintf(buf+strlen(buf), "\n\t%s",  argv[i]);
  verbose_info(buf);
  //basic_info(buf);
}



void __debug_info__(const char *s, const char *file, int line, const char* func){
  char msg[strlen(s)+256];
  sprintf(msg, "%s:%d:%s, %s", file, line, func, s);
  Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
}

void __verbose_info__(const char *s, const char *file, int line, const char* func){
  char msg[strlen(s)+256];
  sprintf(msg, "%s:%d:%s, %s", file, line, func, s);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
}


//#define basic_info(s) __basic_info__((s), __FILE__, __LINE__, __func__)

void __sys_warning__(const char *s, const char *file, int line, const char *func){
  char msg[strlen(s)+256];
  sprintf(msg, "%s:%d:%s [WARNING] %s", file, line, func, s);
  Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0); // FIXME
}

extern char *connTypeToStr(int type);

SEXP RList_findVar(const char *name, SEXP list);

int Supr_verbose = FALSE;
int Supr_debug = FALSE;
int Supr_infov = FALSE;
void (*Supr_do_ncpu_ptr)(int ncpu) = NULL;
void (*Supr_do_xterm_ptr)(int xterm, int interactive) = NULL;


static int X_term_exit = FALSE;

SEXP Supr_X_terminal(SEXP inter, SEXP args){

  //if(!Supr_do_xterm_ptr) Supr_do_xterm_ptr = Supr_do_xterm;
  int interactive = asInteger(inter);
  if(!interactive) {
    X_term_exit = TRUE;
    return R_NilValue; // FIXME
  }

  if(Supr_do_xterm_ptr) {
    int interactive = asInteger(inter);
    //SEXP s = RList_findVar("interactive", args);
    //if(s != R_UnboundValue)
    basic_info("interactive : %d", interactive );
   
    X_term_exit = FALSE;
    Supr_do_xterm_ptr(TRUE, interactive);
  }
  return R_NilValue; // TODO
}

/*
SEXP Supr_X_terminal_exit(){
  Supr_do_xterm_ptr(FALSE, FALSE);
  //error_info("[%s] rl-version: %o\n", __func__, rl_readline_version);
  X_term_exit = TRUE;
  return R_NilValue;
}
*/

SEXP Supr_setOptions(SEXP options){

  if(TYPEOF(options) == NILSXP || LENGTH(options)==0){
    SEXP ret_val = PROTECT(allocVector(VECSXP, 8));
    SET_VECTOR_ELT(ret_val, 0, ScalarLogical(Supr_options.verbose));
    SET_VECTOR_ELT(ret_val, 1, ScalarLogical(Supr_options.debug));
    SET_VECTOR_ELT(ret_val, 2, ScalarLogical(Supr_options.info));
    SET_VECTOR_ELT(ret_val, 3, ScalarReal(Supr_options.timeout));
    SET_VECTOR_ELT(ret_val, 4, ScalarInteger(Supr_options.port));
    SET_VECTOR_ELT(ret_val, 5, ScalarInteger(Supr_options.level));
    SET_VECTOR_ELT(ret_val, 6, ScalarInteger(Supr_options.ncpu));
    SET_VECTOR_ELT(ret_val, 7, ScalarInteger(Supr_options.xterm));
    SEXP names = PROTECT(allocVector(STRSXP, 8));
    SET_STRING_ELT(names, 0, mkChar("verbose"));
    SET_STRING_ELT(names, 1, mkChar("debug"));
    SET_STRING_ELT(names, 2, mkChar("info"));
    SET_STRING_ELT(names, 3, mkChar("timeout"));
    SET_STRING_ELT(names, 4, mkChar("port"));
    SET_STRING_ELT(names, 5, mkChar("level"));
    SET_STRING_ELT(names, 6, mkChar("ncpu"));
    SET_STRING_ELT(names, 7, mkChar("xterm"));
    setAttrib(ret_val, R_NamesSymbol, names);
    UNPROTECT(2);
    return ret_val;
  }

  // FIXME
  int len = LENGTH(options);
  int rc = 0;
  SEXP names = getAttrib(options, R_NamesSymbol);
  for(int i=0; i<len; i++){
    const char *name = CHAR(STRING_ELT(names, i));
    if(strncmp(name, "verbose", strlen(name))==0){
      Supr_options.verbose = asInteger(VECTOR_ELT(options,i));
      Supr_verbose = Supr_options.verbose;
      if(Supr_options.verbose) Supr_options.level = 1;
    } else if(strncmp(name, "debug", strlen(name))==0){
      Supr_options.debug = asInteger(VECTOR_ELT(options,i));
      Supr_debug = Supr_options.debug;
      if(Supr_options.debug) Supr_options.level = 1;
    } else if(strncmp(name, "info", strlen(name))==0){
      Supr_options.info = asInteger(VECTOR_ELT(options,i));
      Supr_infov = Supr_options.info;
      Supr_options.level = 0; // FIXME 
    } else if(strncmp(name, "timeout", strlen(name))==0){
      Supr_options.timeout = asReal(VECTOR_ELT(options,i));
    } else if(strncmp(name, "port", strlen(name))==0){
      Supr_options.level = asInteger(VECTOR_ELT(options,i));
    } else if(strncmp(name, "level", strlen(name))==0){
      Supr_options.level = asInteger(VECTOR_ELT(options,i));
    } else if(strncmp(name, "ncpu", strlen(name))==0){
      Supr_options.ncpu = asInteger(VECTOR_ELT(options,i));
      if(Supr_do_ncpu_ptr)
        Supr_do_ncpu_ptr(Supr_options.ncpu);
    } else if(strncmp(name, "xterm", strlen(name))==0){
      Supr_options.xterm = asInteger(VECTOR_ELT(options,i));
      if(Supr_do_xterm_ptr)
        Supr_do_xterm_ptr(Supr_options.xterm, FALSE);
    }

    //basic_info("proc_cmd: %s", proc_cmd);

/*
    if(strcmp(proc_cmd, "R")==0){
      SEXP driver = findVar(install("driver"), SuprContextEnv);
      if(driver != R_UnboundValue){
        if(TYPEOF(driver)==ENVSXP){
          int cmd = CLUSTER_SET_OPTIONS;
	  SEXP scPtr = getAttrib(driver, install("conn"));
	  supr_socket_conn_t * sc = (supr_socket_conn_t *)
		R_ExternalPtrAddr(scPtr);
	  if(sc){
            write(sc->fd, &cmd, sizeof(int));
	    write(sc->fd, &Supr_options, sizeof(supr_options_t));
	    int rc = read(sc->fd, &rc, sizeof(int));
	  }
	} // else dfs ...
      }
    }
*/



  }

  return ScalarInteger(rc);
}


/*
#define USE_PYTHON
#ifdef  USE_PYTHON
//#include <python3.6m/Python.h>
#include <python3.6m/Python.h>
#include <locale.h>
#endif
*/

#define USE_X11
#ifdef  USE_X11
#include <X11/Xlib.h>
//#include <X11/X.h>
//#include <X11/Xlib.h>
#include <X11/Xatom.h>
//#include <X11/Xutil.h>
//#include <X11/cursorfont.h>
//#include <X11/Intrinsic.h>
//#include <X11/Xutil.h>
//#include <X11/Xos.h>
#endif

#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)

#define strdup(ptr) __supr_strdup__((ptr), __func__, __FILE__, __LINE__)

#define __FIXME__(s) fprintf(stderr, "[FIXME] %s (%s:%d)\n", (s), __FILE__, __LINE__)

#define rjni_shm_open(s, t) supr_shm_open((s), (t))

#define DEFAULT_HASH_SIZE 29

#ifdef R_CHECK_THREAD

#ifndef VALUE_TO_STRING
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)
#endif

//#pragma message "R_CHECK_THREAD = " VALUE(R_CHECK_THREAD)
char *R_check_thread_expr = VALUE(R_CHECK_THREAD);

#ifdef THREADED_CODE
//#pragma message "THREADED_CODE = " VALUE(THREADED_CODE)
#endif

#ifdef R_BCNODESTACKSIZE
//#pragma message "R_BCNODESTACKSIZE = " VALUE(R_BCNODESTACKSIZE)
#endif

#endif


#define READLINE_VERSION_6
#ifdef  READLINE_VERSION_6
// FIXME??
#define rl_pending_signal()	0
#define rl_callback_sigcleanup()
#endif

// FIXME
#define NOT_USE_LOCALHOST

#define CANNOT_FIND_JOB 2
#define JOB_WAS_CANCELLED 3

extern void R_Busy(int);

//#define DRIVER_MALLOC_DEBUG 1
#ifdef DRIVER_MALLOC_DEBUG
extern SEXP Malloc_print();
#define MALLOC_PRINT   Malloc_print()
void *__MALLOC_DEBUG_MARK__(size_t s)
{
        return malloc(s);
}
#define MALLOC_MARK(s) __MALLOC_DEBUG_MARK__(s)
#else
#define MALLOC_PRINT
#define MALLOC_MARK(s)
#endif



// system("lsof +D supr3/bin");

extern SEXP R_TrueValue;
extern SEXP R_FalseValue;
int Thread_main_run_Rmainloop(void);

void __R_Busy(int busy); // FIXME by changing its name to ...

static int Supr_threadType = 0;

pthread_key_t sigusr2HandlerKey;
pthread_key_t interruptThreadKey;
pthread_key_t stacktraceKey;
pthread_key_t taskrunnerThreadKey;
void *PTHREAD_INTERRUPTED = NULL;
void *PTHREAD_ERROR       = NULL;
//void *PTHREAD_CANCELED    = NULL;

extern void c_backtrace();
char *sexp2char(SEXP x);
char *__myR_simpleTraceback(const char *func, const char *file, int line);
#define myR_simpleTraceback() __myR_simpleTraceback(__func__, __FILE__, __LINE__)

// busy: FALSE - unlock, TRUE: lock
int R_SetSyncEvalLock(int busy);

// delete me?
static pthread_mutex_t SuprSignal_mutex = PTHREAD_MUTEX_INITIALIZER;
static int SuprSignal_value = 0;


#ifdef DONT_BIND_UNBOUNDVALUE
static void __defineVar(SEXP symbol, SEXP value, SEXP rho, int line)
{
  if(value == R_UnboundValue){
//	  fprintf(stderr, "\033[0;35m[%s] FIXME (%s:%d)\033[0m\n", __func__, __FILE__, line);
//	  value = R_NilValue;
    // remove it
//    SEXP list = PROTECT(CONS(symbol, R_NilValue));
    SEXP list = PROTECT(allocVector(STRSXP, 1));
    SET_STRING_ELT(list, 0, PRINTNAME(symbol));
    SEXP call = PROTECT(LCONS(install(".Internal"),
        CONS(LCONS(install("remove"),
	    CONS(list, CONS(rho, CONS(R_FalseValue, R_NilValue)))),
		R_NilValue)));
    //PrintValue(call);
    eval(call, R_GlobalEnv);
    UNPROTECT(2);
    return;
  }
  defineVar(symbol, value, rho);
}

#define defineVar(s, v, r) __defineVar((s), (v), (r), (__LINE__)) 

#endif

/*
#define SUPR_RUNNER_THREAD 0
#define SUPR_RUNNER_PROC 1
#define SUPR_RUNNER_PROC 2
#define SUPR_RUNNER_TASKRUNNER 3

static int Supr_runner = 0;
*/

//#define _GNU_SOURCE         /* See feature_test_macros(7) */
/*
#define _USE_GNU
#include <unistd.h>
#include <sys/syscall.h>
*/

static RCNTXT *__R_ToplevelContext = NULL;

static int __SuprSignal_set(int value)
{
  pthread_mutex_lock(&SuprSignal_mutex);
    int last_value = SuprSignal_value;
    SuprSignal_value = value;
  pthread_mutex_unlock(&SuprSignal_mutex);
  return last_value;
}

static int Supr_gettid()
{
  return (int) syscall(SYS_gettid);
}

#define SuprSignal_set(s) fprintf(stderr,	\
  "\033[0;35m%d Call SuprSignal_set from %s (%s:%d), sig: %d\033[0m\n",	\
  Supr_gettid(), __func__, __FILE__, __LINE__, (s));	\
  __SuprSignal_set(s);

static int SuprSignal_get()
{
  pthread_mutex_lock(&SuprSignal_mutex);
    int value = SuprSignal_value;
  pthread_mutex_unlock(&SuprSignal_mutex);
  return value;
}
    
static int Supr_state = 0;
SEXP R_ErrorValue = NULL;

static int SuprError_check()
{
  if(!R_ErrorValue){
    R_ErrorValue = PROTECT(ScalarInteger(0)); // error code
    defineVar(install(".SuprError"), R_ErrorValue, R_GlobalEnv);
    setAttrib(R_ErrorValue, R_ClassSymbol, mkString("SuprError"));
    setAttrib(R_ErrorValue, install("message"), R_NilValue);
    UNPROTECT(1);
  }

  SEXP err = findVar(install(".SuprError"),  R_GlobalEnv);
  if(err != R_ErrorValue)
    defineVar(install(".SuprError"), R_ErrorValue, R_GlobalEnv);

  return INTEGER(R_ErrorValue)[0];
}

SEXP SuprError_setCMessage(const char *message)
{
  SuprError_check();
  INTEGER(R_ErrorValue)[0] = -1;
  setAttrib(R_ErrorValue, install("message"), mkString(message));
  return R_ErrorValue;
}

// strsrror messages?
SEXP SuprError_setCMessageInt(int code)
{
  SuprError_check();
  INTEGER(R_ErrorValue)[0] = code;
  const char *message = strerror(code);
  setAttrib(R_ErrorValue, install("message"), mkString(message));
  return R_ErrorValue;
}

//
SEXP SuprError_setRMessage(SEXP message)
{
  SuprError_check();
  const char *msg = CHAR(asChar(message));
  return SuprError_setCMessage(msg);
}

SEXP SuprError_clearMessage()
{
  SuprError_check();
  INTEGER(R_ErrorValue)[0] = 0;
  setAttrib(R_ErrorValue, install("message"), R_NilValue);
  defineVar(install(".SuprError"), R_ErrorValue, R_GlobalEnv);
  return R_ErrorValue;
}
//

// FIXME
int SuprError_setDevice(const char *filename)
{
  static int save_fd = -1; 
  if(save_fd < 0) save_fd = dup(STDERR_FILENO);

  int fd = open(filename, O_WRONLY);
  if(fd == -1){
    fprintf(stderr, "Error: %s, %s\n", __func__, strerror(errno));
    return -1;
  }

  int rc = dup2(fd, STDERR_FILENO);
  if(rc == -1){
    fprintf(stderr, "Error: %s, %s\n", __func__, strerror(errno));
    return -1;
  }

  return save_fd;
}

int Supr_who4(const char *hostname, int port, int *pid_addr,
	       	supr_socket_conn_t **sc_addr)
{
  char buf[1024];

  if(strstr(hostname, "//")) hostname = strstr(hostname, "//") + 2;
  supr_socket_conn_t *sc = socketOpen2(hostname, port);

  if(!sc) return -1;

  debug_info(buf, "Connected to '%s:%d'", sc->host, sc->port);

  int fd = sc->fd;
  struct timeval tv;
  fd_set readfds, writefds;


  { // writable?
      fd_set readfds, writefds;

      tv.tv_sec=Supr_options.timeout;
      tv.tv_usec=50000;

      FD_ZERO(&writefds);
      FD_SET(fd, &writefds);

      int ns = select(fd+1, NULL, &writefds, NULL, &tv);
      if(ns <= 0) {
	if(ns == -1){
          sprintf(buf, "Error: %s", strerror(errno));
          basic_info(buf);
        } else {
          basic_info("Error: ETIMEDOUT");
	  // FIXME
	  int cmd = 0; // shutdown
	  write(fd, &cmd, sizeof(int));
	  errno = ETIMEDOUT;
	}
        socketDestroy(sc);
        return -2;
      }

      int cmd = CLUSTER_WHO;
      ssize_t size = write(fd, &cmd, sizeof(int));
      if(size == -1){
	  sprintf(buf, "Error: %s", strerror(errno));
          basic_info(buf);
          close(fd);
          free(sc); // FIXME
	  return -2;
      }
  }

  size_t n = 0;
  int msg[3];
  while (n<sizeof(msg)) { // readable? use socket_read ...
      tv.tv_sec=Supr_options.timeout;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0) {
	if(ns == -1){
          sprintf(buf, "Error: %s", strerror(errno));
          basic_info(buf);
        } else {
          sprintf(buf, "Error: ETIMEDOUT");
          basic_info(buf);
	  errno = ETIMEDOUT;
	}
        socketDestroy(sc);
        return -3;
      }

      size_t m = read(fd, ((char*)msg) + n, sizeof(msg)-n);
      if(m <= 0) {
          sprintf(buf, "Error: %s", strerror(errno));
          basic_info(buf);
        socketDestroy(sc);
        return -5;
      }
      n += m;
      if(n < sizeof(msg)) fprintf(stderr, "%s: n=%ld\n", __func__, n);
  }

  if(n == sizeof(msg) && msg[2] == geteuid()){

        if(sc_addr)
          *sc_addr = sc;
        else
          socketDestroy(sc);

        if(pid_addr) *pid_addr = msg[1];

        return msg[0];
  } else {
    sprintf(buf, "n=%ld, sizeof(msg): %ld, msg: [%d, %d, %d], euid: %d\n",
        n, sizeof(msg), msg[0], msg[1], msg[2], geteuid()); socketDestroy(sc);
    return -6;
  }
}

int Supr_who3(const char *addr, int *pid_addr, supr_socket_conn_t **sc_addr)
{
  char *host = strdup(addr);
  char *s = strstr(host, ":");
  if(!s) {
          free(host); return -4;
  }
  *s = 0; s++;
  char *h = strstr(host, "//")? strstr(host, "//")+2 :  host;

  int rc = Supr_who4(host, atoi(s), pid_addr, sc_addr);
  free(host);
  return rc;
}

void Supr_notify(const char *dest, const char* src, int cmd){
          supr_socket_conn_t *sc = socketOpen1(dest);
	  verbose_info("%s(%s, %s, %d): %p\n", __func__, dest, src, cmd, sc);
          if(sc){
            write(sc->fd, &cmd, sizeof(int));
            int len = strlen(src)+1;
            write(sc->fd, &len, sizeof(int));
            write(sc->fd, src, len);
            int rc;
            read(sc->fd, &rc, sizeof(int));
	    verbose_info("Send %s to %s", src, dest);
            //close(sc->fd);
            //free(sc);
            Supr_decref(sc);
          } else {
            verbose_info("cannot connect to %s", dest);
          }

	//  basic_info("%s-exit", __func__);
}

#define SUPR_LOADING  1
#define SUPR_QUITTING 4

#define LD_INIT_DO_THREAD_INIT

//extern  R_bcstack_t *R_BCNodeStackTop, *R_BCNodeStackEnd;

#define CONSOLE_BUFFER_SIZE 4096
typedef struct {
  ParseStatus    status;
  int            prompt_type;
  int            browselevel;
  unsigned char  buf[CONSOLE_BUFFER_SIZE+1];
  unsigned char *bufp;
} R_ReplState;

extern int Rf_ReplIteration(SEXP rho, int savestack, int browselevel, R_ReplState *state);


SEXP R_thread_fini();
//SEXP Supr_checkJMP(const char *msg);

struct sigaction R_oldSigSegvAct;

// See xdg-open:
// xdg-open http://liu1.stat.purdue.edu:7202
// do this at R level?

extern int R_wait_usec;

static void (*save_R_Busy)(int which) = NULL;

static void (*save_R_ResetConsole)(void) = NULL;
static void (*save_R_FlushConsole)(void) = NULL;
static void (*save_R_ClearerrConsole)(void) = NULL;
//R_ParseError
//R_ParseErrorMsg

extern void __supr_malloc_init__(); // uitl.c init
extern void __supr_malloc_fini__(); // uitl.c init

char *Supr_message = NULL; // delete me ...?

char *Supr_sysHome = NULL;
char *Supr_usrHome = NULL;
char *Supr_dfsHome = NULL;   // new, Sat May  9 10:57:27 EDT 2020
char *Supr_threadDir = NULL; // new, Tue Nov 16 09:51:38 EST 2021
char *Supr_defaultInfonode = NULL;

char *SUPR_HOMESYS = NULL; // delete me ...
char *SUPR_HOMEUSR = NULL;

char *SUPR_DFS_HOMEUSR = NULL;
char *SUPR_DFS_HOMESYS = NULL;;
void suprDFSHomeInit();


//static int Supr_isatty = FALSE; // for interactive

extern int R_Interactive;

typedef struct supr_conf_struct {
  char *name;
  char *value;
  struct supr_conf_struct *next;
} supr_conf_t;

supr_conf_t *Supr_conf = NULL;

int SuprConf_readFile(FILE *file, supr_conf_t **conf_addr);

R_bcstack_t *__R_BCNodeStackBase = NULL;


typedef struct save_bcstack_struct {
  size_t size;
  R_bcstack_t bcstack[0];
} save_bcstack_t;

#define R_BCNodeStackPos (R_BCNodeStackTop - __R_BCNodeStackBase)

void Supr_saveBCNodeStack();
void Supr_restorBCNodeStack();

SEXP R_thread_init();
SEXP R_thread_fini();

static RCNTXT Save_R_ToplevelContext;

//FILE *stdlog = NULL;
//int Supr_stdlog_fileno = -1;
//char *Supr_stdlog_filename = NULL;

extern int __supr_debug_munmap(void *addr, size_t length, const char *func,
                const char *file, int line);

//#define munmap(a, l) __supr_debug_munmap((a), (l), __func__,    \ __FILE__, __LINE__)

// TODO; See MySupR/... ?
void *__Supr_malloc(size_t size)
{
  return __supr_malloc__(size, __func__, __FILE__, __LINE__);
}

void *__Supr_realloc(void *ptr, size_t size)
{
  return __supr_realloc__(ptr, size, __func__, __FILE__, __LINE__);
}

void __Supr_free(void *ptr)
{
  __supr_free__((ptr), __func__, __FILE__, __LINE__);
}


void (*Supr_free)(void *ptr) = __Supr_free;
void *(*Supr_malloc)(size_t size) = __Supr_malloc;
void *(*Supr_realloc)(void *ptr, size_t size) = __Supr_realloc;


// debug ...
ssize_t socket_write(int fildes, const void *buf, size_t nbyte){
  
  ssize_t size = 0;
  unsigned char *buffer = (unsigned char *)buf;
  while(size < nbyte){
    ssize_t n = write(fildes, buffer + size, nbyte - size);
    if(n==-1){
	  fprintf(stderr, "Error in %s, %s\n", __func__, strerror(errno));
	  return n;
    } 
    size += n;
  }
  return size;
}

//
ssize_t socket_read(int fildes, const void *buf, size_t nbyte){
  
  ssize_t size = 0;
  unsigned char *buffer = (unsigned char *)buf;
  while(size < nbyte){
    ssize_t n = read(fildes,  buffer + size, nbyte - size);
    if(n==-1){
	  fprintf(stderr, "Error in %s, %s\n", __func__, strerror(errno));
	  return n;
    } 
    size += n;
  }
  return size;
}
//

// FIXME...
int __Supr_sendSimpleMessage(const char *msg, const char *color, int type,
	       	int level)
{

  sigset_t sig_set;
  sigset_t old_sig_set;
  sigemptyset(&sig_set);
  sigaddset(&sig_set, SIGINT);
  pthread_sigmask(SIG_BLOCK, &sig_set, &old_sig_set);
  
  int oldcancelstate;
  pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);
  pthread_mutex_lock(info_sc->mutex);

    int fd = info_sc->fd;
    int cmd = CLUSTER_INFO;

             ssize_t size = socket_write(fd, &cmd, sizeof(int));

             unsigned char buf[8];
             snprintf(buf, 8, "%s", color);
             size += socket_write(fd, buf, sizeof(buf));
             size += socket_write(fd, &type, sizeof(int));
             size += socket_write(fd, &level, sizeof(int));
             ssize_t len = strlen(msg)+1;
             size += socket_write(fd, &len, sizeof(ssize_t));
             size += socket_write(fd, msg, len);
	     
             int rc;
             ssize_t n = socket_read(fd, &rc, sizeof(int));

	     if(size != 7*sizeof(int) + len){ // FIXME
       fprintf(stderr, "%d: %ld unlocked, wrote: %ld (?=%ld), read: %ld\n\n", __LINE__, syscall(SYS_gettid), size,
		       7*sizeof(int) + len,
		       n); 
	     }
  pthread_mutex_unlock(info_sc->mutex);
  pthread_setcancelstate(oldcancelstate, &oldcancelstate);

  rc = sigismember(&old_sig_set, SIGINT);
//  fprintf(stderr, "sigismember(&old_sig_set, SIGINT): %d\n", rc);
  if(rc == 0){
    sigemptyset(&sig_set);
    sigaddset(&sig_set, SIGINT);
    pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
  }
  return rc;
}


int __real_Supr_sendSimpleMessage__(const char *msg, const char *color, int type,
	       	int level){
  
  if(info_sc && info_sc->mutex){
    return __Supr_sendSimpleMessage(msg, color, type, level);
  }

  int rc;

  sigset_t sig_set;
  sigset_t old_sig_set;
  sigemptyset(&sig_set);
  sigaddset(&sig_set, SIGINT);
  pthread_sigmask(SIG_BLOCK, &sig_set, &old_sig_set);
//  rc = sigismember(&old_sig_set, SIGINT);
//  fprintf(stderr, "\033[0;32msigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);

  int oldcancelstate;
  pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);

  supr_socket_conn_t *sc = NULL;
  int cmd = CLUSTER_INFO;

  pthread_mutex_lock(&Supr_syncMutex);

  if(info_sc) {
//    Supr_incref(info_sc);
    sc = info_sc;
  } 
  else {
    if(parent_sc){
//      Supr_incref(parent_sc);
      sc = parent_sc;
    } else {
      fprintf(stderr, "%s[INFO] \033[0m: %s\n", color, msg);
      pthread_mutex_unlock(&Supr_syncMutex);

      pthread_setcancelstate(oldcancelstate, &oldcancelstate);

      rc = sigismember(&old_sig_set, SIGINT);
//      fprintf(stderr, "\033[0;34msigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);
       if(rc == 0){
         sigemptyset(&sig_set);
         sigaddset(&sig_set, SIGINT);
         pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
       }
       return -1;
    }
  }



  int fd = sc->fd;
  //

             ssize_t size = socket_write(fd, &cmd, sizeof(int));

             unsigned char buf[8];
             snprintf(buf, 8, "%s", color);
             size += socket_write(fd, buf, sizeof(buf));
             size += socket_write(fd, &type, sizeof(int));
             size += socket_write(fd, &level, sizeof(int));
             ssize_t len = strlen(msg)+1;
             size += socket_write(fd, &len, sizeof(ssize_t));
             size += socket_write(fd, msg, len);
	     
             ssize_t n = socket_read(fd, &rc, sizeof(int));

	     if(size != 7*sizeof(int) + len){ // FIXME
       fprintf(stderr, "%d: %ld unlocked, wrote: %ld (?=%ld), read: %ld\n\n", __LINE__, syscall(SYS_gettid), size,
		       7*sizeof(int) + len,
		       n); 
	     }
  pthread_mutex_unlock(&Supr_syncMutex);

  //int rc =
  pthread_setcancelstate(oldcancelstate, &oldcancelstate);

  rc = sigismember(&old_sig_set, SIGINT);
//  fprintf(stderr, "\033[0;34msigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);
  if(rc == 0){
    sigemptyset(&sig_set);
    sigaddset(&sig_set, SIGINT);
    pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
  }

  return rc;
}

int (*Supr_sendSimpleMessage)(const char *msg, const char *color, int type, int level)
  = __real_Supr_sendSimpleMessage__;
   
int Supr_sendVerboseMessage(const char *msg, const char *color, int type,
	       	int level)
{
//return -1;
  if(info_addr){
    supr_socket_conn_t *sc = socketOpen1(info_addr);
    if(sc){
      char buf[strlen(msg)+1+strlen(proc_cmd)+strlen(Supr_hostname)+32];
      char host[strlen(Supr_hostname)+1];
      memcpy(host, Supr_hostname, strlen(Supr_hostname)+1);
      char *s = strchr(host, '.'); if(s) *s = 0;
      sprintf(buf, "[INFO@%s.%s]", proc_cmd, host);
      sprintf(buf+strlen(buf), " %s", msg);
      msg = buf;
      //fprintf(stderr, "\033[0;31m%s\033[0\n", msg);
      int cmd = SUPR_INFO;
      write(sc->fd, &cmd, sizeof(int)); 
      int len = strlen(msg)+1;
      write(sc->fd, &len, sizeof(int)); 
      write(sc->fd, msg, len);
      int rc;
      read(sc->fd, &rc, sizeof(int));
      Supr_decref(sc);
      return 0;
    }
  } else {
    fprintf(stderr, "%s\n", msg);
    return 1;
  }
  return -1;
}

static supr_socket_conn_t *Supr_findConnectionEx(int fd, vector_t *connections)
{
  //message:
  //fprintf(stderr, "[%s] connections: %p, size: %d\n",__func__, connections, vectorSize(connections));

  if(connections == NULL) return NULL;

  for(int i = vectorSize(connections) - 1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(connections, i);
    if(sc->fd == fd)
            return sc;
    //fprintf(stderr, "[%s]\t%d. fd: %d (!=%d)\n",__func__, i+1, sc->fd, fd);
  }

  return NULL;
}

supr_socket_conn_t *Supr_findConnection(int fd)
{
  supr_socket_conn_t *sc = Supr_findConnectionEx(fd, socket_connections);
  if(sc) return sc;

  return Supr_findConnectionEx(fd, special_socket_connections);
}


//int shm_io_destroy (shm_io_info_t *io);
void Supr_interrupt_enable();
void Supr_interrupt_disable();
void Supr_onClusterEvalIntr(void *data);
char *Supr_hostname = NULL;
char *Supr_login = NULL; // used for security
char *Supr_username = NULL; // 
supr_thread_t *Supr_threadServer = NULL;
char **Supr_argv = NULL;

SEXP Sync_lock(SEXP x);
SEXP Sync_unlock(SEXP x);
SEXP Sync_wait(SEXP x, SEXP r_timeout, SEXP env);
SEXP Sync_notify(SEXP x, SEXP r_all, SEXP env);

void Thread_SigactionSegv(int sig, siginfo_t *ip, void *context);

typedef struct pts_device_struct {
  char *name;
  pid_t pid;
  int   padding;
  struct pts_device_struct *next;
} pts_device_t;

static pts_device_t *pts_device_root = NULL;

SEXP Supr_addDevice(SEXP device)
{
   pts_device_t *dev = malloc(sizeof(pts_device_t));
   const char *name = CHAR(asChar(device));
   pid_t pid = INTEGER(getAttrib(device, install("pid")))[0];
   //fprintf(stderr, "dev: %s, pid: %d\n", name, pid);
   dev->name = strdup(name);
   dev->pid = pid;
   dev->next = pts_device_root;
   pts_device_root = dev;
   return R_NilValue;
}

static SEXP Supr_removeDevice(SEXP device)
{
  if(device == NULL || device == R_NilValue){
    pts_device_t *dev = pts_device_root;
    while(dev){
      kill(dev->pid, SIGKILL);
      pts_device_t *dev_ntex = dev->next;
      free(dev);
      dev = dev_ntex;
    }
    pts_device_root = NULL;
  }
}

SEXP Supr_version()
{
  return mkString(SUPR_VERSION_STRING);
}

SEXP Supr_setVerboseEnabled(SEXP state)
{
  if(!Supr_verbose){
    __FIXME__("display some helpful info");
  }
  Supr_verbose = asLogical(state);
  return R_NilValue;
}

/*
SEXP Supr_setLockQueueShowEnabled(SEXP state)
{
  if(!Supr_verbose){
    __FIXME__("display some helpful info");
  }
  Supr_lockQueueShow = asLogical(state);
  return R_NilValue;
}
*/


char *Exec_timestamp(char *buf, size_t buf_size)
{
  time_t ltime;
  time(&ltime);
  struct tm result;
  localtime_r(&ltime, &result);
  asctime_r(&result, buf);
  char *s = strstr(buf, "\n");
  if(s) *s = 0;
  return buf;
}

static int *worker_windows = NULL; // delete me ...

extern void SocketConn_closeAll(vector_t *conns, int do_shutdown);
extern supr_xterm_t *supr_xterm3(const char *window_name, char **argv,
                int window);

int X11_check();
int X11_windows(Window win);



void runAsDaemon2(char *dir, char *sub_dir)
{
   //int X11_rc =  X11_check();
   /*
   fprintf(stderr, "%s:%d, pid:%d\n",__func__, __LINE__, getpid());
   fflush(stderr);
   fprintf(stderr, "%s@\033[0;32m%s\033[0m. X11_str=\"%s\"\n", __func__, proc_cmd, X11_str);
   fflush(stderr);
   */

   pid_t pid = fork();
   if(pid < 0) {
           perror("fork");
           //exit(EXIT_FAILURE);
           exit(EXIT_FAILURE);
   }

   if (pid > 0) {
     Supr_message = "Daemon exit 1";
     //fprintf(stderr, "%s-%d: exit 1\n", proc_cmd, getpid());
     exit(EXIT_SUCCESS); // wait?
   }

   // first generation
   // X11_rc =  X11_check();

   if(setsid() < 0) {
           perror("fork");
           exit(EXIT_FAILURE);
   }

   pid = fork();
   if(pid < 0) {
           perror("fork");
           exit(EXIT_FAILURE);
   }

   if (pid > 0) {
     Supr_message = "Daemon exit 2";
     exit(EXIT_SUCCESS); // wait?
   }

   // second generation
   //X11_rc =  X11_check();

   // Set new file permissions
   umask(0);

   char path[PATH_MAX];

   char new_dir[PATH_MAX];
   if(sub_dir){
     if(strlen(sub_dir))
       sprintf(new_dir, "%s/%s", dir, sub_dir);
     else
       sprintf(new_dir, "%s/%d", dir, getpid());
     if(mkdir(new_dir, 0700) == -1){
	   Supr_sendSimpleMessage(new_dir, msg_color, ERROR_INFO_TYPE,0);
           exit(EXIT_FAILURE);
     } 
     dir = new_dir;
   }

   chdir(dir);

   //for(int fd = sysconf(_SC_OPEN_MAX); fd >= 0; fd --) close(fd);
   //basic_info("sysconf(_SC_OPEN_MAX): %ld", sysconf(_SC_OPEN_MAX));
//
   // X11 forwarding trouble ...
   /*
   {
     int save_out_fd = dup(STDOUT_FILENO);
     int save_err_fd = dup(STDERR_FILENO);
   }
   */

//
   //fprintf(stderr, "%s-%d: redirect std-io\n", proc_cmd, getpid());
//#define TEST_KEEP_SSH_X11FORWARDING_ALIVE
//#ifdef TEST_KEEP_SSH_X11FORWARDING_ALIVE
   //fprintf(stderr, "%s:%d\n",__func__, __LINE__);
   //fprintf(stderr, "%s@%s. X11_str=\"%s\"\n", __func__, proc_cmd, X11_str);

   //basic_info("%s@%s. X11_str=\"%s\"", __func__, proc_cmd, X11_str);
   if( //strcmp(proc_cmd, "worker")==0 &&
      X11_str && (strcmp(X11_str, "-Y")==0
   	|| strcmp(X11_str,"-X")==0)){
	//basic_info("Keep X11Forwarding alive (?)");
     int  save_in_fd = dup(STDIN_FILENO);
     int save_out_fd = dup(STDOUT_FILENO);
     int save_err_fd = dup(STDERR_FILENO);
     //fprintf(stdout, "dup(fd=%d): %d\n", STDIN_FILENO, save_in_fd);
     //fprintf(stdout, "dup(fd=%d): %d\n", STDOUT_FILENO, save_out_fd);
     //fprintf(stderr, "dup(fd=%d): %d\n", STDERR_FILENO, save_err_fd);
//#else
   } else {
     //basic_info("Ignore X11Forwarding (?)");
     
     //fprintf(stdout, "close(fd=%d)\n", STDOUT_FILENO);
     //fprintf(stderr, "close(fd=%d)\n", STDERR_FILENO);
     //fflush(stdout);
     //fflush(stderr);

     for(int fd = sysconf(_SC_OPEN_MAX); fd >= 0; fd --) {
	   if(debug_sc && fd == debug_sc->fd)
		   continue;
	   else if(info_sc && fd == info_sc->fd)
		   continue;
	   close(fd);
     }
   }
//#endif
//
//

   sprintf(path, "%s/stdout.txt", dir);
   unlink(path);

/*
   if(!R_Interactive) {
     basic_info("6. call Supr_do_xterm, R_Interactive: %d", R_Interactive);
     Supr_do_xterm(TRUE);
   }
*/

   FILE *out = fopen(path, "w");
   if(out)
     dup2(fileno(out), STDOUT_FILENO);

/*
   if(!R_Interactive) {
     basic_info("7. call Supr_do_xterm, R_Interactive: %d", R_Interactive);
     Supr_do_xterm(TRUE);
   }
*/


   
   sprintf(path, "%s/stderr.txt", dir);
   unlink(path);
   FILE *err = fopen(path, "w");
   if(err)
     dup2(fileno(err), STDERR_FILENO);

/*
   if(!R_Interactive) {
     basic_info("8. call Supr_do_xterm, R_Interactive: %d", R_Interactive);
     Supr_do_xterm(TRUE);
   }
*/

}
void runAsDaemon(char *dir)
{
  runAsDaemon2(dir, NULL);
}

int Supr_waitpid(const char *tmp_out, const char *tmp_err,
        const char *sock_addr, pid_t pid, int *status_addr, const char *X11_str)
{
  basic_info("X11Forwarding: %s", X11_str);
  if(X11_str && (strcmp(X11_str, "-Y")==0 || strcmp(X11_str, "-Y")==0))
    return  0;

  {
    errno = 0;
    int rc = waitpid(pid, status_addr, 0);
    supr_socket_conn_t *server_sc = NULL;
    if(sock_addr && (server_sc = socketOpen1(sock_addr))){
      // TODO
      Supr_decref(server_sc);
    }
    return rc;
  }

  supr_socket_conn_t *server_sc = NULL;
  if(sock_addr && (server_sc = socketOpen1(sock_addr))){
    int args[] = {SET_CONN_PID, getpid(), -1};
    write(server_sc->fd, args, sizeof(args));

    while(TRUE){
      struct timeval tv;
      tv.tv_sec=Supr_options.timeout;
      tv.tv_usec=0;

      fd_set readfds;
      FD_ZERO(&readfds);

      int max_fd = server_sc->fd;
      FD_SET(server_sc->fd, &readfds);

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0) {
        basic_info("%s:%d. \033[0;35m%s-select: %d\033[0m", __FILE__, __LINE__,  __func__, ns);
        break;
      } else if(FD_ISSET(server_sc->fd, &readfds)) {
        int len;
	read(server_sc->fd, &len, sizeof(int));
	char buf[len];
	read(server_sc->fd, buf, len);
        basic_info("%s:%d. \033[0;35m%s-select: %s\033[0m", __FILE__, __LINE__,  __func__, buf);
      } else {
        error_info("%s:%d. \033[0;35m%s-select: FIXME\033[0m", __FILE__, __LINE__,  __func__);
      }
    }
    return 0;
  }

  FILE *out_f = fopen(tmp_out, "r");
  FILE *err_f = fopen(tmp_err, "r");
  int out_fd = fileno(out_f); // open(tmp_out, O_RDONLY);
  int err_fd = fileno(err_f); // open(tmp_err, O_RDONLY);

//
  int kill_proc = FALSE; 
  basic_info("tmp_out: %s, fd: %d, pid: %d", tmp_out?tmp_out:"(null)",
  	out_fd, pid); 
  basic_info("tmp_err: %s, fd: %d, pid: %d", tmp_err?tmp_err:"(null)",
  	err_fd, pid); 

  //if(out_fd != -1 && err_fd != -1)
  //{
    //basic_info("\033[0;31mfopen(slavename, \"r+\"): %p\033[0m", f_slave);


    while(TRUE){
      struct timeval tv;
      tv.tv_sec=Supr_options.timeout;
      tv.tv_usec=0;

      fd_set readfds;
      FD_ZERO(&readfds);

      kill_proc = TRUE; 
      int max_fd = -1;
      if(out_fd!=-1){
        FD_SET(out_fd, &readfds);
        max_fd = out_fd;
        kill_proc = FALSE;
      }
      if(err_fd!=-1){
        FD_SET(err_fd, &readfds);
        max_fd = err_fd > max_fd ? err_fd : max_fd;
        kill_proc = FALSE;
      }

      if(kill_proc) break;

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0) {
        basic_info("%s:%d. \033[0;35m%s-select: %d\033[0m", __FILE__, __LINE__,  __func__, ns);
        kill_proc = FALSE;
        break;
      } else {
	char buf[4096];
        if(FD_ISSET(out_fd, &readfds)) {
	  char *s = fgets(buf, sizeof buf, out_f);
	  if(s){
	    if(s[strlen(s)-1]=='\n') s[strlen(s)-1]=0;
            basic_info("%s:\033[0;34m%s\033[0m", tmp_out, s);
	  } else {
            basic_info("%s:\033[0;34m(EOF)\033[0m", tmp_out);
	    fclose(out_f);
	    out_f = NULL;
	    out_fd = -1;
	  }
	}
        if(FD_ISSET(err_fd, &readfds)) {
	  char *s = fgets(buf, sizeof buf, err_f);
	  if(s){
	    if(s[strlen(s)-1]=='\n') s[strlen(s)-1]=0;
            basic_info("%s:\033[0;31m%s\033[0m", tmp_err, s);
	  } else {
            basic_info("%s:\033[0;31m(EOF)\033[0m", tmp_err);
	    fclose(err_f);
	    err_f = NULL;
	    err_fd = -1;
	  }
	}
      }
    }
  //}
//

  int rc = -1;
  //if(kill_proc)
  {
    //rc = kill(pid, 0);
    //rc = kill(pid, SIGKILL);
    //if(rc != 0) basic_info("%s:%d. \033[0;31m%s-kill: %s\033[0m", __FILE__, __LINE__,  __func__, strerror(errno));

    errno = 0;
    rc = waitpid(pid, status_addr, 0);
    int status = *status_addr;
    basic_info("%s. (%s:%d) waitpid(%d, ...), rc: %d, err: %s",
                        __func__, __FILE__, __LINE__,
                 pid, rc, strerror(errno));
    if(rc == -1){
      error_info("error: %s", strerror(errno));
    } else if(WIFEXITED(status)){
      int exit_status = WIFEXITED(status);
      if(exit_status){
	const char *tmp = tmp_err;
	FILE * f_tmp = fopen(tmp, "r");
        basic_info("\033[0;31m===== ssh/execl exit status: %d (file: %s) =====\033[0m", exit_status, tmp);
	if(f_tmp){
	  char buf[4096];
	  while(fgets(buf, sizeof buf, f_tmp)) {
	    char *s = strrchr(buf, '\n');
	    if(s) *s = 0;
	    basic_info("\033[0;34m%s\033[0m", buf);
	  }
	  basic_info("\033[0;31m==== (file: %s) =====\n\033[0m", tmp);
	  fclose(f_tmp);
	}

	//if(driver_addr) {
	//  Supr_notify(driver_addr, Supr_hostname, CLUSTER_CONNECT_MASTER);
	//}
      } else{
        basic_info("\033[0;32mssh/execl exit status: %d\033[0m", exit_status);
      }

    } else {
      error_info("\033[0;31mterminated abnormally\033[0m");
      if(WIFSIGNALED(status)){
        int sig = WTERMSIG(status);
	error_info("\033[0;31m\tsignal: %d\033[0m", sig);
      } else {
      }
      
    }

    return rc;
  }
  errno = 0;
  return rc; // TODO
}


SEXP DD_enableInfo(SEXP r_level);

/*
 * Cluster: driver, master, and workers
*/

static void DFS_connection_finalizer(SEXP s); // clean finalizers ...

// remote and local
supr_socket_conn_t *Supr_startRemoteMaster(const char *addr, int info,
		int verbose, int debug, double timeout){

  char msg[1024];
  sprintf(msg, "[VERBOSE] %s(%s)", __func__, addr);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  if(strstr(addr, "//")) addr = strstr(addr, "//") + 2;


  char *host = strdup(addr);
  char *s = strstr(host, ":");
  if(!s) return NULL;
  *s = 0; s++;
  int port = atoi(s);

  sprintf(msg, "\033[0;32mStart master %s:%d ...\033[0m", host, port);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  char path[strlen(Supr_sysHome) + strlen("/bin/master")+2];
  sprintf(path, "%s/bin/master",  Supr_sysHome);
  char port_str[32];
  sprintf(port_str, "%d", port);

  SEXP infoServer = findVar(install("info"), SuprContextEnv);
  if(infoServer == R_UnboundValue)
	  error(_("cannot find (SocketServer) 'info'"));
  //SEXP klass = getAttrib(infoServer, R_ClassSymbol); // TODO... 

  supr_socket_conn_t *is_sc = (supr_socket_conn_t *) 
	  			R_ExternalPtrAddr(infoServer);

  char notify_addr[strlen(Supr_hostname)+32];
  sprintf(notify_addr, "%s:%d", Supr_hostname, is_sc->port);

  const char *format = "bash -c 'source .suprrc;" //" env;"
         " $SUPR_SYS_HOME/bin/master -port %s" //%d
         " %s %s %s -timeout %g -info %s -notify %s'";

  char ssh_arg[strlen(format) + strlen(notify_addr) + 256 + 8*PATH_MAX];
  int ntrs_int = 0;

  sprintf(ssh_arg, format, // port,
		  strstr(addr,":") ?  (strstr(addr,":") + 1):"0",
		  info ? "--info" : "",
                verbose ? "--verbose" : "", debug ? "--debug" : "", timeout,
	       	notify_addr, notify_addr); // FIXME

  Cluster_sendSimpleMessage(ssh_arg, msg_color, VERBOSE_INFO_TYPE, 0);

  char shm_name[256];
  sprintf(shm_name, "SUPR_USER_%d_%d", geteuid(), getpid());
  sem_t *sem = (sem_t*) Supr_shm_create(shm_name, sizeof(sem_t));
  if(!sem)
    error(_("[%s:%d] Supr_shm_create(%s), %s"), __FILE__,__LINE__,
		   shm_name, strerror(errno));
  shm_unlink(shm_name);

  sem_init(sem, 1, 0);

  supr_socket_conn_t *ret_conn = NULL;

  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {

      //sprintf(msg, "\033[0;31m[%d] parent proc: %d\033[0m\n", __LINE__, getpid());
      Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

      //supr_socket_conn_t *conn = NULL;

      double time_elapsed = 0.0;

      pthread_mutex_lock(&Supr_syncMutex); // fixme ...

        sem_post(sem);

        Supr_syncObject = &Supr_syncCond;
        double timeout = Supr_options.timeout;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

        pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);

      pthread_mutex_unlock(&Supr_syncMutex);

      {
        clock_gettime(CLOCK_REALTIME, &wait);
        save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
        time_elapsed = -save_time;

        sprintf(msg, "\033[0;32m%s master %s:%d (in %g sec.)\n\033[0m",
                        time_elapsed >= Supr_options.timeout ?
                        "\033[0;31mFailed to start\033[0m":"Started",
                        host, port, time_elapsed);
        Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

        if(Supr_syncObject == &Supr_syncCond) {

          sprintf(msg, "\033[0;31mcannot start %s\033[0m", host);
          Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

        } else if(Supr_syncObject) {

          Cluster_sendSimpleMessage((char*) Supr_syncObject, msg_color,
			  VERBOSE_INFO_TYPE, 0);

	  ret_conn = socketOpen1((char*) Supr_syncObject);
      fprintf(stderr, "\033[0;33mret_conn: %p\033[0m\n", ret_conn);
	  if(!ret_conn) {
	      char msg[strlen((char*)Supr_syncObject)+1];
	      memcpy(msg, Supr_syncObject, sizeof(msg));
              free(Supr_syncObject);
              Supr_syncObject = NULL;
	      error(_("cannot connect to master %s"),
				  (char*) Supr_syncObject);
	  }

          free(Supr_syncObject);
        } else {
      fprintf(stderr, "\033[0;33mError in %s ret_conn: %p\033[0m\n",
		      __func__, ret_conn);
	}
        Supr_syncObject = NULL;
      }

      int status;
      int rc = waitpid(pid, &status, 0);
//      fprintf(stderr, "P [%s] waitpid(pid=%d, &status, 0): %d, status: %d (%s:%d)\n", __func__, pid, rc, status, __FILE__, __LINE__ );

      munmap(sem, sizeof(sem_t));
      return ret_conn;
  }

  sem_wait(sem);
  munmap(sem, sizeof(sem_t));

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid) {
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    exit(EXIT_SUCCESS);
  }

  if(strcmp(host,Supr_hostname)==0){

    char path[PATH_MAX];
    sprintf(path, "%s/bin/master",  Supr_sysHome);
    char port_str[32];
    sprintf(port_str, "%d", port);

		fprintf(stderr, "%d:%s\n", __LINE__, __func__);

    int rc = execl(path, path, "-port", 
		    strstr(addr, ":")?  (strstr(addr, ":")+1):"0",
             //    "-usr", Supr_usrHome, "-sys", Supr_sysHome, // FIXME
                 "-info",   notify_addr,
                 "-notify", notify_addr,
                 Supr_verbose ? "--verbose" : "",
                 Supr_debug ?  "--debug" : "",
                 Supr_infov ?  "--info" : "",
                 (char *) NULL);
  } else {

    int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
  }
  exit(EXIT_SUCCESS);

  return NULL; // not reached
}

// both local and remote...
supr_socket_conn_t *Supr_startRemoteDFSNamenode(const char *addr, int info,
		int verbose, int debug, double timeout){

  char msg[1024];
  sprintf(msg, "[VERBOSE] %s(%s)", __func__, addr);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  if(strstr(addr, "//")) addr = strstr(addr, "//") + 2;


  char *host = strdup(addr);
  char *s = strstr(host, ":");
  if(!s) return NULL;
  *s = 0; s++;
  int port = atoi(s);

  basic_info("Start DFSNamenode. addr: %s, port: %d%s", host, port,
		  strstr(s, "+")?"+":"");

  sprintf(msg, "\033[0;32mStart dfs_namenode %s:%d ...\033[0m", host, port);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  char path[strlen(Supr_sysHome) + strlen("/bin/dfs_name")+2];
  sprintf(path, "%s/bin/dfs_name",  Supr_sysHome);
  char port_str[32];
  sprintf(port_str, "%d", port);

  SEXP infoServer = findVar(install("info"), SuprContextEnv);
  if(infoServer == R_UnboundValue)
	  error(_("cannot find (SocketServer) 'info'"));
  //SEXP klass = getAttrib(infoServer, R_ClassSymbol); // TODO... 

  supr_socket_conn_t *is_sc = (supr_socket_conn_t *) 
	  			R_ExternalPtrAddr(infoServer);

  char notify_addr[strlen(Supr_hostname)+32];
  sprintf(notify_addr, "%s:%d", Supr_hostname, is_sc->port);

  const char *format = "bash -c 'source .suprrc;" //" env;"
         " $SUPR_SYS_HOME/bin/dfs_name -port %s" // %d
         " %s %s %s -timeout %g -info %s -notify %s -timeout %g'";

  char ssh_arg[strlen(format) + strlen(notify_addr) + 256 + 8*PATH_MAX];
  int ntrs_int = 0;

  // missing port: 1024+
  sprintf(ssh_arg, format, strstr(addr, ":")?(strstr(addr, ":")+1):"0", //port,
		info ? "--info" : "",
                verbose ? "--verbose" : "", debug ? "--debug" : "", timeout,
	       	notify_addr, notify_addr, Supr_options.timeout); // FIXME

  Cluster_sendSimpleMessage(ssh_arg, msg_color, VERBOSE_INFO_TYPE, 0);

  char shm_name[256];
  sprintf(shm_name, "SUPR_USER_%d_%d", geteuid(), getpid());
  sem_t *sem = (sem_t*) Supr_shm_create(shm_name, sizeof(sem_t));
  if(!sem)
    error(_("[%s:%d] Supr_shm_create(%s), %s"), __FILE__,__LINE__,
		   shm_name, strerror(errno));
  shm_unlink(shm_name);

  sem_init(sem, 1, 0);

  supr_socket_conn_t *namenode = NULL;

  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {

      //sprintf(msg, "\033[0;31m[%d] parent proc: %d\033[0m\n", __LINE__, getpid());
      Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

      //supr_socket_conn_t *conn = NULL;

      double time_elapsed = 0.0;

      pthread_mutex_lock(&Supr_syncMutex); // fixme ...

        sem_post(sem);

        Supr_syncObject = &Supr_syncCond;
        double timeout = Supr_options.timeout;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

        pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);

      pthread_mutex_unlock(&Supr_syncMutex);

      {
        clock_gettime(CLOCK_REALTIME, &wait);
        save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
        time_elapsed = -save_time;

        sprintf(msg, "\033[0;32m%s dfs_name %s:%d (in %g sec.)\n\033[0m",
                        time_elapsed >= Supr_options.timeout ?
                        "\033[0;31mFailed to start\033[0m":"Started",
                        host, port, time_elapsed);
        Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

        if(Supr_syncObject == &Supr_syncCond) {

          sprintf(msg, "\033[0;31mcannot start %s\033[0m", host);
          Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

        } else if(Supr_syncObject) {

          Cluster_sendSimpleMessage((char*) Supr_syncObject, msg_color,
			  VERBOSE_INFO_TYPE, 0);

	  namenode = socketOpen1((char*) Supr_syncObject);

	  if(!namenode) {
	      char msg[strlen((char*)Supr_syncObject)+1];
	      memcpy(msg, Supr_syncObject, sizeof(msg));
              free(Supr_syncObject);
              Supr_syncObject = NULL;
	      error(_("cannot connect to dfs namenode %s"),
				  (char*) Supr_syncObject);
	  } else {
	    basic_info("connected to dfs namenode://%s:%d\n",
			    namenode->host, namenode->port);
	  }

          free(Supr_syncObject);
        }
	
        Supr_syncObject = NULL;
      }

      int status;
      int rc = waitpid(pid, &status, 0);
//      fprintf(stderr, "P [%s] waitpid(pid=%d, &status, 0): %d, status: %d (%s:%d)\n", __func__, pid, rc, status, __FILE__, __LINE__ );

      munmap(sem, sizeof(sem_t));
      return namenode;
  }

  sem_wait(sem);
  munmap(sem, sizeof(sem_t));

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid) {
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
//    fprintf(stderr, "C (%s:%d) waitpid(%d, ...), rc: %d, err: %s\n", __FILE__, __LINE__, pid, rc, strerror(errno));
    exit(EXIT_SUCCESS);
  }

  if(strcmp(host, Supr_hostname)==0){
    
     char path[PATH_MAX];
     sprintf(path, "%s/bin/dfs_name",  Supr_sysHome);

     char port_str[16];
     sprintf(port_str, "%d", port);
     char min_port_str[16];
     sprintf(min_port_str, "%d", Supr_options.port);
     char timeout_str[256];
     sprintf(timeout_str, "%g", Supr_options.timeout);

     execl(path, path, "-port", 
		     strstr(addr, ":")?  (strstr(addr, ":") + 1):"1024+",
		     Supr_verbose ? "--verbose" : "",
                 Supr_debug ?  "--debug" : "", Supr_infov ?  "--info" : "",
                 "-info", notify_addr, "-notify", notify_addr,
		 "-timeout", timeout_str,
		 (char *) NULL);
  } else {
    execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
  }

  //exit(EXIT_SUCCESS);

  return NULL; // not reached
}


shm_io_info_t *Supr_createShmConnection(SEXP server, const char *from)
{

  const char *host = CHAR(asChar(getAttrib(server, install("address"))));
  if(!host) return NULL;
  if(strstr(host, "//")) host = strstr(host, "//") + 2;
  char buf[strlen(host)+1];
  strcpy(buf, host);
  char *s = strstr(buf, ":");
  if(s)  *s=0; else return NULL;
  if(strcmp(buf, Supr_hostname)) return NULL;

  char _shm_io_name[128];
  sprintf(_shm_io_name, "%s-%d-%s-%d", shm_prefix, getpid(), from, __LINE__);
  const char *shm_io_name = _shm_io_name;
  
  size_t block_size = 8*sysconf(_SC_PAGE_SIZE); // FIXME
  shm_io_info_t *shm_io = shm_io_create(shm_io_name, block_size);

  supr_socket_conn_t *sc;
  SEXP conn = getAttrib(server, install("conn"));
  if(TYPEOF(conn) != NILSXP)
    sc = (supr_socket_conn_t*) R_ExternalPtrAddr(conn);
  else 
    sc = socketOpen1(host);

  if(!sc) return NULL;
  int fd = sc->fd;
  int cmd = CLUSTER_SHM_CONN;
  write(fd, &cmd, sizeof(int));
  int len = strlen(shm_io_name)+1;
  ssize_t size = write(fd, &len, sizeof(int));
  size = write(fd, shm_io_name, len);
  int rc;
  size = read(fd, &rc, sizeof(int));
  if(size == -1){
	  return NULL; // FIXME: destroy...
  }

  {
        int rc; // = sem_wait(&shm_io->in->sem_wait);
        struct timespec ts;
        if (clock_gettime(CLOCK_REALTIME, &ts) == -1)
        {
          printf("[%s] Error: clock_gettime, %s", __func__, strerror(errno));
        }
        ts.tv_sec += (long) Supr_options.timeout;

        rc = sem_timedwait(&shm_io->in->sem_wait, &ts);
        if(rc && Supr_verbose){
          fprintf(stderr, "rc: %d, err: %s\n", rc, strerror(errno));
        }

	if(rc == -1) {
          fprintf(stderr, "rc: %d, err: %s\n", rc, strerror(errno));
	  return NULL; // FIXME: destroy...
	}
  }

  pid_t *driver_pid  = (pid_t *) shm_io_read(shm_io, shm_io->in,
                        &size, NULL);
  fprintf(stderr, "\033[0;32mdriver_pid: %d\n", *driver_pid);

  return shm_io;
}

// a R_options-like interface to SuprContextEnv
static void  Cluster_setDefaults();
//extern SEXP deparse1(SEXP call, Rboolean abbrev, int opts);
extern SEXP Rf_deparse1m(SEXP call, Rboolean abbrev, int);

SEXP DFS_createObjectTableEnv(supr_socket_conn_t **sc_addr, const char *path);

typedef struct dfs_env_data_struct {
  SEXP rho;
  supr_socket_conn_t **sc_addr;
  char *path; // file
  SEXP local; // attr(rho, "localEnv") localEnv
  // ...
} dfs_env_data_t;

extern SEXP DD_list(SEXP r_name); 

void ThreadServer_connect_finalizer(SEXP s);
SEXP ThreadServer_createObjectTableEnv();
SEXP Cluster_setLocalEnvToObjectTable(SEXP rho, SEXP localEnv);

// localEnv can be found through the attributes of server
// and its ObjectTable
void Supr_addLocalFunctions(SEXP server, const char *localfuns_symbol,
		const char *server_name)
{
    SEXP localEnv = getAttrib(server, install(".LocalEnv"));
    if(TYPEOF(localEnv) == NILSXP){
      localEnv = Cluster_setLocalEnvToObjectTable(server, R_NilValue);
      defineVar(install(".LocalEnv"), localEnv, localEnv);
    }
    SEXP ths_localfuns = findVar(install(localfuns_symbol), Supr_namespace);
    if(ths_localfuns != R_UnboundValue){
      if(TYPEOF(ths_localfuns) == PROMSXP){
        ths_localfuns = PROTECT(eval(ths_localfuns, R_GlobalEnv));
      }
      else PROTECT(ths_localfuns);
      if(TYPEOF(ths_localfuns) == LISTSXP){// defined in supr3
        SEXP s = ths_localfuns;
        while(TYPEOF(s) != NILSXP){
          if(TYPEOF(CAR(s)) == CLOSXP){

            SEXP f = CAR(s);
            SEXP formals = FORMALS(f);
            SEXP func = PROTECT(allocSExp(CLOSXP));
            SET_BODY(func, BODY(f));
            SET_CLOENV(func, CLOENV(f));
            SEXP func_formals=PROTECT(CONS(R_NilValue, R_NilValue));
            SEXP args=func_formals;

            while(TYPEOF(formals) != NILSXP){
              if(strcmp(CHAR(PRINTNAME(TAG(formals))), server_name)==0){
                      SETCDR(args, CONS(server, R_NilValue));
              } else {
                      SETCDR(args, CONS(CAR(formals), R_NilValue));
              }
              args = CDR(args);
              SET_TAG(args, TAG(formals));
              formals = CDR(formals);
            }
            SET_FORMALS(func, CDR(func_formals));
            defineVar(TAG(s), func, localEnv);

	    //fprintf(stderr, "define localfunc: %s\n", CHAR(PRINTNAME(TAG(s))));
            UNPROTECT(2);

          } else
            defineVar(TAG(s), CAR(s), localEnv);
          s = CDR(s);
        }
      }
      UNPROTECT(1);
    }

}

SEXP Cluster_stopDriver(SEXP all);
SEXP Supr_master_address();
SEXP Supr_namenode_address();

static SEXP Supr_stopDFS(){
  const char *addr = NULL;

  /*
  SEXP dfs = findVar(install("dfs"), SuprContextEnv);
  if(TYPEOF(dfs)==STRSXP) {
    addr = CHAR(asChar(dfs));
  } 
  
  if(TYPEOF(dfs)==ENVSXP){
    SEXP address = getAttrib(dfs, install("address"));
    if(TYPEOF(address)==STRSXP)
      addr = CHAR(asChar(address));
  }
  */

  SEXP dfs_addr = Supr_namenode_address();
  if(TYPEOF(dfs_addr)==STRSXP)
	  addr = CHAR(asChar(dfs_addr));

  //fprintf(stderr, "addr: %s\n", addr);
  if(addr){
	  if(strstr(addr, "//")) addr = strstr(addr, "//")+2;
	  supr_socket_conn_t *sc = socketOpen1(addr);
          //fprintf(stderr, "sc: %p\n", sc);
	  if(sc){
		  int cmd = CLUSTER_SHUTDOWN ;
		  write(sc->fd, &cmd, sizeof(int));
		  int all = FALSE;
		  write(sc->fd, &all, sizeof(int));
		  int rc;
		  ssize_t size = timed_read(sc->fd, &rc, sizeof(int));
		  if(size == -1){
	            basic_info("timed_read: %s", strerror(errno));
		  } else {
	            basic_info("\033[0;32mstop DFS namenode rc: %d\033[0m", rc);
		  }
		  close(sc->fd);
		  free(sc); // FIXME
                  defineVar(install("dfs"), mkString(addr), SuprContextEnv);
		  char *a = Config_getAddr("Namenode");
		  if(a && strstr(a, "//")){
		    if(strstr(a, "?")) {
		      char *s = strstr(a, "?"); 
		      *s = 0;
		    }
                    defineVar(install("dfs"), mkString(strstr(a,"//")),
				    SuprContextEnv);
		    free(a);
		  }
		  if(DFS_namenode){
		    close(DFS_namenode->fd);
		    free(DFS_namenode); // FIXME
		    DFS_namenode = NULL;
		  }
	  } else {
	    basic_info("cannot connect to DFS namenode");
	  }
  } else {
	  basic_info("cannot find DFS namenode address");
  }
  return R_NilValue;
}


static SEXP Supr_stopMaster(){
  const char *addr = NULL;
  SEXP master = findVar(install("master"), SuprContextEnv);
  if(TYPEOF(master)==ENVSXP){
    SEXP address = getAttrib(master, install("address"));
    if(TYPEOF(address)==STRSXP)
      addr = CHAR(asChar(address));
  } else {
    SEXP master_addr = Supr_master_address();
    if(TYPEOF(master_addr)==STRSXP){
      addr = CHAR(asChar(master_addr));
    }
  }

  //fprintf(stderr, "addr: %s\n", addr);
  if(addr){
	  if(strstr(addr, "//")) addr = strstr(addr, "//")+2;
	  supr_socket_conn_t *sc = socketOpen1(addr);
          //fprintf(stderr, "sc: %p\n", sc);
	  if(sc){
		  int cmd = CLUSTER_SHUTDOWN ;
		  write(sc->fd, &cmd, sizeof(int));
		  int all = TRUE;
		  write(sc->fd, &all, sizeof(int));
		  int rc;
		  ssize_t size = timed_read(sc->fd, &rc, sizeof(int));
		  if(size == -1){
	            basic_info("timed_read: %s", strerror(errno));
		  } else {
	            basic_info("\033[0;32mstop master rc: %d\033[0m", rc);
		  }
		  close(sc->fd);
		  free(sc); // FIXME

                  defineVar(install("master"), mkString(addr), SuprContextEnv);
		  char *a = Config_getAddr("Master");
		  if(a && strstr(a, "//")){
                    defineVar(install("master"), mkString(strstr(a,"//")),
				    SuprContextEnv);
		    free(a);
		  }
	  } else {
	    basic_info("cannot connect to master");
	  }
  } else {
	  basic_info("cannot find master address");
  }
  return R_NilValue;
}

static SEXP Supr_stopDriver(){
  const char *addr = NULL;
  SEXP driver = findVar(install("driver"), SuprContextEnv);
  if(TYPEOF(driver)==STRSXP) {
    addr = CHAR(asChar(driver));
  } else if(TYPEOF(driver)==ENVSXP){
    SEXP address = getAttrib(driver, install("address"));
    if(TYPEOF(address)==STRSXP)
      addr = CHAR(asChar(address));
    //SEXP shmio = getAttrib(driver, install("shmio"));
    // let the finalizer to take care of ...
    //shm_io_info_t *io = __supr_context->driver_shm_io;
    driver_shm_io = NULL; //
  }
  //fprintf(stderr, "addr: %s\n", addr);
  if(addr && !strstr(addr, "+")){
	  if(strstr(addr, "//")) addr = strstr(addr, "//")+2;
	  supr_socket_conn_t *sc = socketOpen1(addr);
         // fprintf(stderr, "sc: %p\n", sc);
	  if(sc){
		  int cmd = CLUSTER_SHUTDOWN ;
		  write(sc->fd, &cmd, sizeof(int));
		  int all = FALSE;
		  write(sc->fd, &all, sizeof(int));
		  int rc;
		  ssize_t size = timed_read(sc->fd, &rc, sizeof(int));
		  if(size == -1){
	            basic_info("timed_read: %s", strerror(errno));
		  } else {
	            basic_info("\033[0;32mstop driver rc: %d\033[0m", rc);
		  }
		  close(sc->fd);
		  free(sc); // FIXME
                  defineVar(install("driver"), mkString(addr), SuprContextEnv);
		  char *a = Config_getAddr("Driver");
		  if(a && strstr(a, "//")){
                    defineVar(install("driver"), mkString(strstr(a,"//")),
				    SuprContextEnv);
		    free(a);
		  }
	  } else {
	    basic_info("cannot connect to driver");
	  }
	  //driver_sc = NULL;
  } else {
	  basic_info("cannot find driver address");
  }
  return R_NilValue;
}

SEXP Supr_cntxt(SEXP args, SEXP env);

SEXP Supr_shutdown(){
  {
    SEXP args = PROTECT(CONS(R_NilValue, CONS(R_NilValue, R_NilValue)));
    SET_TAG(CDR(args), install("ths"));
    Supr_cntxt(args, R_GlobalEnv);
    UNPROTECT(1);
  }
  Supr_stopDFS();
  Supr_stopMaster();
  Supr_stopDriver();
  return R_NilValue;
}

// for user only?

SEXP RVec_findVar(const char *name, SEXP vec){
  int n = LENGTH(vec);
  if(TYPEOF(vec) != VECSXP) return R_UnboundValue;
  SEXP names = getAttrib(vec, install("names"));
  for(int i=0; i<n; i++){
    if(strcmp(CHAR(STRING_ELT(names, i)), name)==0)
      return VECTOR_ELT(vec, i);
  }
  return R_UnboundValue;
}

// on.exit(close(conn), add = TRUE)
SEXP Supr_add_onExit(SEXP args, SEXP env)
{
  //args = PROTECT(eval(args, env));
  //basic_info("typeof(args): %s", type2char(TYPEOF(args)));
  //PrintValue(args);

  SEXP call = PROTECT(LCONS(install("on.exit"),
                            CONS(args, CONS(R_TrueValue, R_NilValue))));
  //SET_TAG(CDDR(call), install("all.names"));
  SEXP r = PROTECT(eval(call, R_GlobalEnv));

  UNPROTECT(1);
  return r;
}
//static void Cluster_setDefaults();

SEXP Supr_config(SEXP args, SEXP env){
  
  args = PROTECT(eval(args, env));

  //basic_info("typeof(args): %s", type2char(TYPEOF(args)));
  //PrintValue(args);
  SEXP s_nodes = R_UnboundValue;


  if(TYPEOF(args) == VECSXP) {
    s_nodes = RVec_findVar("nodes", args);
  } else if(TYPEOF(args) == LISTSXP) {
    s_nodes = RList_findVar("nodes", args);
  } else {
    error(_("invalid arguments for 'config'"));
  }

  int force = FALSE;
  SEXP s_force = R_UnboundValue;
  if(TYPEOF(args) == VECSXP) {
    s_force = RVec_findVar("force", args);
  } else if(TYPEOF(args) == LISTSXP) {
    s_force = RList_findVar("force", args);
  } 
  if(s_force != R_UnboundValue)
    force = asInteger(s_force);
  //basic_info("force: %d", force);

  int port = 1024;
  SEXP s_port = R_UnboundValue;
  if(TYPEOF(args) == VECSXP) {
    s_port = RVec_findVar("port", args);
  } else if(TYPEOF(args) == LISTSXP) {
    s_port = RList_findVar("port", args);
  } 
  if(s_port != R_UnboundValue)
    port = asInteger(s_port);

  int ncpu = 0;
  SEXP s_ncpu = R_UnboundValue;
  if(TYPEOF(args) == VECSXP) {
    s_ncpu = RVec_findVar("ncpu", args);
  } else if(TYPEOF(args) == LISTSXP) {
    s_ncpu = RList_findVar("ncpu", args);
  } 
  if(s_ncpu != R_UnboundValue)
    ncpu = asInteger(s_ncpu);

  basic_info("ncpu: %d", ncpu);

  //
  //basic_info("port: %d", port);

  //basic_info("typeof(evs): %s", type2char(TYPEOF(evs)));

  SEXP nodes = PROTECT(CONS(mkString(Supr_hostname), R_NilValue));

  if(s_nodes == R_UnboundValue || s_nodes == R_NilValue)
    error(_("argument 'nodes' not found"));
    
  //{
  s_nodes = PROTECT(eval(s_nodes, env));
  if(TYPEOF(s_nodes) != STRSXP)  {
      //PrintValue(args);
      error("invalid argument 'env' in config=list(...) or 'envir'");
  } else  {
      //PrintValue(args);
      SEXP t = nodes;
      for(int i=0; i < LENGTH(s_nodes);  i++){
        //basic_info("env name: %s", CHAR(STRING_ELT(evs, i)));
        const char *value = CHAR(STRING_ELT(s_nodes, i));
        //if(!value) continue;
        //basic_info("%d: %s", i+1, value);
	if(strstr(value, "[")){
	  char buf[strlen(value)+1];
	  memcpy(buf, value, strlen(value)+1);
	  // remove white spaces if any?
	  char *prefix = buf;
	  char *s = strstr(prefix, "[");
	  *s = 0; s++;
	  char *val = s;
	  s = strstr(val, "]");
	  if(s) *s = 0;
          //basic_info("prefix: \"%s\", suffix: \"%s\"", prefix, val);
	  for(; val; val = s){
	    s = strstr(val, ",");
	    if(s) { *s = 0; s++;}
            //basic_info("block: %s", val);

	    char *a = strtok(val, " \t-");
	    if(!a) continue;
	    char *b = strtok(NULL, " \t-");
	    if(!b) b = a;
            //basic_info("block: %s-%s", a, b);
	    if(strlen(a) != strlen(b))
	      error(_("invalid value in $%s: \"%s\""),
			      CHAR(STRING_ELT(s_nodes, i)), value);
	    char format[strlen(prefix)+32];
	    sprintf(format, "%s%%0%ldd%%s", prefix, strlen(a));
            //basic_info("format: %s", format);

	    int ai = atoi(a), bi = atoi(b);
	    for(int j=ai; j<=bi; j++){
              char host[strlen(prefix)+strlen(Supr_hostname)+1+strlen(a)];
	      if(strstr(Supr_hostname, ".")){
	        sprintf(host, format, j, strstr(Supr_hostname, "."));
	      } else {
	        sprintf(host, format, j, "");
	      }
              //basic_info("%s: %s", val, host);
	      SETCDR(t, CONS(mkString(host), R_NilValue));
	      t = CDR(t);
	    }


	  }

	} else {
          //char *val = value; 
	  char buf[strlen(value)+1];
	  memcpy(buf, value, strlen(value)+1);
	  char *val = strtok(buf, " \t,;");
          for(; val; val=strtok(NULL, " \t,;")){
            //basic_info("val: %s", val);
            char host[strlen(val)+strlen(Supr_hostname)+1];
	    if(strstr(val, ".")){
	        sprintf(host, "%s", val);
	    } else if(strstr(Supr_hostname, ".")){
	        sprintf(host, "%s%s", val, strstr(Supr_hostname, "."));
	    } else {
	        sprintf(host, "%s", val);
	    }
            //basic_info("%s: %s", CHAR(STRING_ELT(s_nodes, i)), host);
	    SETCDR(t, CONS(mkString(host), R_NilValue));
	    t = CDR(t);
	  }
	}
      }
  }

  //}
  //PrintValue(nodes);

  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  //basic_info("%s: ", path);

  struct stat statbuf;
  int rc;

  /*
  rc = stat(path, &statbuf);
  if (S_ISLNK(statbuf.st_mode)) basic_info (" stat says link\n");
  if (S_ISREG(statbuf.st_mode)) basic_info (" stat says file\n");
  */

  rc = lstat (path, &statbuf);
  //if(rc != 0) error(_("%s: %s"), path, strerror(errno));
  if (rc == 0 && S_ISREG(statbuf.st_mode) && !force) {
    //basic_info ("lstat says file\n");
    error(_("%s exists and is not a link"), path);
  }

  if (rc == 0 && S_ISLNK(statbuf.st_mode)) {
	//  basic_info ("lstat says link\n");
    unlink(path);
  }

  char *ncpu_str = "";
  char ncpu_buf[256];

  if(ncpu>0){
    sprintf(ncpu_buf, "&ncpu=%d", ncpu);
    ncpu_str = ncpu_buf;
  }

  FILE *file = fopen(path, "w");
  fprintf(file, "Namenode //%s:%d+?data={\n}\n", Supr_hostname, port);
  SEXP t = CDR(nodes);
  while(t != R_NilValue){
    fprintf(file, "Datanode //%s:%d+?data={\n}%s\n",
		    CHAR(STRING_ELT(CAR(t), 0)), port, ncpu_str);
    t = CDR(t);
  }

  if(ncpu>0){
    ncpu_str = ncpu_buf;
    sprintf(ncpu_buf, "?ncpu=%d", ncpu);
  }

  fprintf(file, "\nDriver //%s:%d+\n", Supr_hostname, port);
  fprintf(file, "Master //%s:%d+\n", Supr_hostname, port);
  t = CDR(nodes);
  int nhosts = 1;
  while(t != R_NilValue){
    fprintf(file, "Worker //%s:%d+%s\n", CHAR(STRING_ELT(CAR(t), 0)),
    	port, ncpu_str);
    t = CDR(t);
    nhosts++;
  }

  fprintf(file, "\nInfonode //%s:%d+\n", Supr_hostname, port);
  fprintf(file, "Filetransfer //%s:%d+\n", Supr_hostname, port);

  //use unique hosts: FIXME for efficiency?
  const char *hosts[nhosts];
  nhosts = 0; 
  hosts[nhosts++] = Supr_hostname; 
  t = nodes;
  while(t != R_NilValue){
    SEXP s = nodes;
    const char *host = CHAR(STRING_ELT(CAR(t), 0));
    int i=0;
    for(;i<nhosts; i++){
      if(strcmp(host, hosts[i])==0)
        break;
    }
    if(i >= nhosts)
      hosts[nhosts++] = host;

    t = CDR(t);
  }


  fprintf(file, "\nThreadServers {\n");

  /*
  int n =0;
  t = nodes;
  while(t != R_NilValue){
    fprintf(file, "   %s:%d+\n", CHAR(STRING_ELT(CAR(t), 0)), port);
    t = CDR(t);
    n++;
  }
  */
  for(int i=0; i<nhosts; i++){
    fprintf(file, "   %s:%d+\n", hosts[i], port);
  }

  fprintf(file, "}\n");

  fprintf(file, "\nTrustedHosts {\n");
  t = nodes;

  /*
  SEXP ret_val = PROTECT(allocVector(STRSXP, n));
  n = 0;
  while(t != R_NilValue){
    fprintf(file, "   %s\n", CHAR(STRING_ELT(CAR(t), 0)));
    SET_STRING_ELT(ret_val, n++, STRING_ELT(CAR(t), 0));
    t = CDR(t);
  }
  */
  SEXP ret_val = PROTECT(allocVector(STRSXP, nhosts));
  for(int i=0; i<nhosts; i++){
    fprintf(file, "   %s\n", hosts[i]);
    SET_STRING_ELT(ret_val, i, mkChar(hosts[i]));
  }
  fprintf(file, "}\n");
  fclose(file);

  Cluster_setDefaults();

  UNPROTECT(4);
  return ret_val;
}

SEXP Config_getHosts(){
//  if(!Supr_usrHome) suprHomeInit();

  char cn_file[PATH_MAX];

  sprintf(cn_file, "%s/supr.conf", Supr_usrHome);
  //int rc = access(cn_file, R_OK);
  //int fd = open(cn_file, O_RDWR, 0600);
  struct stat sb;
  SEXP hosts = PROTECT(CONS(mkString(Supr_hostname), R_NilValue));

  int fd, rc;
  if((fd = open(cn_file, O_RDWR, 0600))!=-1 && (rc = fstat(fd, &sb))==0) {
        char buf[sb.st_size+2];
        read(fd, buf+1, sb.st_size);
        close(fd);
        buf[0] = '\n';
        buf[sb.st_size+1] = 0;

	// namenode
	SEXP t = hosts;

	char *servers[] ={"Namenode", "Datanode", "Driver", "Master", "Worker"};
	int n = sizeof(servers)/sizeof(char*);
	for(int i=0; i<n; i++){
	  char *server = servers[i];
	  char x[sizeof(buf)];
	  memcpy(x, buf, sizeof(buf));

          char *block = strstr(x, server);
	  char *next = NULL;
	  for(;block; block = next){
	    next = strstr(block, server);
	    if(next) { *next = 0; next++; }
            //basic_info("%s block: %s", server, block);
	    if(strstr(block,"//")){
              char *s = strstr(block,":");
	      if(s) {
	        *s = 0;
		char *h = strstr(block,"//")+2;
                //basic_info("[x] %s block: %s", server, h);
		SEXP v = hosts;
		while(v != R_NilValue){
                  if(strcmp(CHAR(STRING_ELT(CAR(v),0)), h)==0)
			  break;
		  v = CDR(v);
		}
		if(v == R_NilValue){
	          SETCDR(t, CONS(mkString(h), R_NilValue));
	          t = CDR(t);
		}
	        *s = ':';
	      } 
	    }
	  }
	}

	char *block = strstr(buf, "ThreadServers");
	if(block){
          block = strstr(block, "{");
	  if(block) {
	    char *s = strstr(block, "}");
	    if(!s) error(_("invalid ThreadServers block in %s"), cn_file); 
	    *s = 0;
	    block++;
	    char *h = strtok(block, " \t\n");
	    for(;h; h = strtok(NULL, " \t\n")){
		s = strstr(h, ":"); 
		if(s) *s = 0;
                //basic_info("[x] ThreadServers block: %s", h);
		SEXP v = hosts;
		while(v != R_NilValue){
                  if(strcmp(CHAR(STRING_ELT(CAR(v),0)), h)==0)
			  break;
		  v = CDR(v);
		}
		if(v == R_NilValue){
	          SETCDR(t, CONS(mkString(h), R_NilValue));
	          t = CDR(t);
		}
	    }
	  }

	}


  } else {
    fprintf(stdout, "Error in open supr.conf '%s', %s\n", cn_file,
		    strerror(errno));
  }
  UNPROTECT(1);
  return hosts;
}
  

//run supr-proc: TODO
SEXP Supr_supr_proc(){
  SEXP hosts = PROTECT(Config_getHosts());
  SEXP ret_val = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP u = ret_val;
  SEXP t = hosts;
  const char *format = "bash -c \"ps -U $USER |grep -E 'master|driver|worker|taskrunner|dfs_name|dfs_data|threadserver'\"";

  while(t != R_NilValue){
    const char *host = CHAR(STRING_ELT(CAR(t), 0));
    //int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    //char *ssh_arg = format;

    char cmd[strlen(format)+strlen(host)+64];
    sprintf(cmd, "/usr/bin/ssh %s %s", host, format);
    FILE *file = popen(cmd, "r");
    char buf[4096];
    fprintf(stdout, "\033[0;33mhost: %s\033[0m\n", host);
    /*
    for(char *s = fgets(buf, sizeof(buf), file); s; s = fgets(buf, sizeof(buf), file)){
      fprintf(stdout, "%s", s);
      SETCDR(u, CONS(mkString(s), R_NilValue));
      u = CDR(u);
      SET_TAG(u, install(host));
    }
    */
    for(char *s = fgets(buf, sizeof(buf), file);
		    s; s = fgets(buf, sizeof(buf), file)){
      char *new_line = strstr(buf, "\n");
      if(new_line) *new_line = 0;
      fprintf(stdout, "%s\n", s);
      SETCDR(u, CONS(mkString(s), R_NilValue));
      u = CDR(u);
      SET_TAG(u, install(host));
    }
    fprintf(stdout, "\n");
    pclose(file);

    t = CDR(t);
  }
  UNPROTECT(2);
  return CDR(ret_val);
}

/* from Doug Crabill
 * #!/usr/bin/env bash
 *
 *  hosts="vega adhara1 adhara2 adhara3 adhara4 adhara5 adhara6"
 *   
 *
 *   for str in $hosts; do
 *     echo -e "\n##### $str"
 *       ssh $str "killall -9 master dfs_name dfs_data driver worker taskrunner"
 *       done
 *        
 */

SEXP Supr_supr_killall(){
  SEXP hosts = PROTECT(Config_getHosts());
  SEXP ret_val = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP u = ret_val;
  SEXP t = hosts;
  //const char *format = "bash -c \"ps -U $USER |grep -E 'master|driver|worker|taskrunner|dfs_name|dfs_data'\"";
  //const char *format = "bash -c \"killall -9 master; killall -9 dfs_name; killall -9 dfs_data; killall -9 driver; killall -9 worker; killall -9 taskrunner\"";
  //const char *format = "bash -c \"hostname; killall -KILL master; killall -KILL dfs_name; killall -KILL dfs_data; killall -KILL driver; killall -KILL worker; killall -KILL taskrunner\"";
  const char *format = "bash -c \"hostname; killall -KILL master dfs_name dfs_data driver worker taskrunner threadserver\"";

  while(t != R_NilValue){
    const char *host = CHAR(STRING_ELT(CAR(t), 0));
    //int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    //char *ssh_arg = format;

    char cmd[strlen(format)+strlen(host)+64];
    sprintf(cmd, "/usr/bin/ssh %s %s", host, format);
    FILE *file = popen(cmd, "r");
    char buf[4096];
    fprintf(stdout, "\033[0;33mhost: %s\033[0m\n", host);


    for(char *s = fgets(buf, sizeof(buf), file);
		    s; s = fgets(buf, sizeof(buf), file)){
      char *new_line = strstr(buf, "\n");
      if(new_line) *new_line = 0;
      fprintf(stdout, "%s\n", s);
      SETCDR(u, CONS(mkString(s), R_NilValue));
      u = CDR(u);
      SET_TAG(u, install(host));
    }
    pclose(file);

    t = CDR(t);
  }
  UNPROTECT(2);
  return CDR(ret_val);
}

SEXP Supr_supr_shm(SEXP args, SEXP env)
{
  SEXP hosts = PROTECT(Config_getHosts());
  SEXP ret_val = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP u = ret_val;
  SEXP t = hosts;

  int do_rm = FALSE; 
  char *format = "/usr/bin/ssh %s bash -c \"hostname; ls -l /dev/shm/*%d*\"";

  PrintValue(args);

  if(args != R_NilValue){
    args = PROTECT(eval(args, env));
    SEXP rm = RList_findVar("rm", args);

    do_rm = asInteger(rm);
    if(do_rm)
      format = "/usr/bin/ssh %s bash -c \"hostname; rm /dev/shm/*%d*\"";
    UNPROTECT(1);
  }

  basic_info("cmd format: %s", format);

  uid_t uid =  geteuid();

  while(t != R_NilValue){
    const char *host = CHAR(STRING_ELT(CAR(t), 0));

    char cmd[strlen(format)+strlen(host)+64];
    sprintf(cmd, format, host, uid);

    basic_info("cmd: %s", cmd);

    FILE *file = popen(cmd, "r");
    char buf[4096];
    fprintf(stdout, "\033[0;33m\nhost: %s\033[0m\n", host);


    for(char *s = fgets(buf, sizeof(buf), file);
		    s; s = fgets(buf, sizeof(buf), file)){
      char *new_line = strstr(buf, "\n");
      if(new_line) *new_line = 0;
      fprintf(stdout, "%s\n", s);
      SETCDR(u, CONS(mkString(s), R_NilValue));
      u = CDR(u);
      SET_TAG(u, install(host));
    }
    pclose(file);

    t = CDR(t);
  }
  UNPROTECT(2);
  return CDR(ret_val);
}

SEXP Supr_supr_tmp(SEXP args, SEXP env)
{
  SEXP hosts = PROTECT(Config_getHosts());
  SEXP ret_val = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP u = ret_val;
  SEXP t = hosts;

  int do_rm = FALSE; 
  char *format = "/usr/bin/ssh %s bash -c \"hostname; ls -lR /tmp/supr-%s\"";

  PrintValue(args);

  if(args != R_NilValue){
    args = PROTECT(eval(args, env));
    SEXP rm = RList_findVar("rm", args);

    do_rm = asInteger(rm);
    if(do_rm)
      format = "/usr/bin/ssh %s bash -c \"hostname; rm -R /tmp/supr-%s\"";
    UNPROTECT(1);
  }

  basic_info("cmd format: %s", format);

  while(t != R_NilValue){
    const char *host = CHAR(STRING_ELT(CAR(t), 0));

    char cmd[strlen(format)+strlen(host)+64];
    sprintf(cmd, format, host, Supr_username);

    basic_info("cmd: %s", cmd);

    FILE *file = popen(cmd, "r");
    char buf[4096];
    fprintf(stdout, "\033[0;33m\nhost: %s\033[0m\n", host);


    for(char *s = fgets(buf, sizeof(buf), file);
		    s; s = fgets(buf, sizeof(buf), file)){
      char *new_line = strstr(buf, "\n");
      if(new_line) *new_line = 0;
      fprintf(stdout, "%s\n", s);
      SETCDR(u, CONS(mkString(s), R_NilValue));
      u = CDR(u);
      SET_TAG(u, install(host));
    }
    pclose(file);

    t = CDR(t);
  }
  UNPROTECT(2);
  return CDR(ret_val);
}

extern int Rf_ReplIteration(SEXP rho, int savestack, int browselevel, R_ReplState *state);

#ifdef __Copy__R_ReplConsole 
static void R_ReplConsole(SEXP rho, int savestack, int browselevel)
{
    int status;
    R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};

    R_IoBufferWriteReset(&R_ConsoleIob);
    state.buf[0] = '\0';
    state.buf[CONSOLE_BUFFER_SIZE] = '\0';
    /* stopgap measure if line > CONSOLE_BUFFER_SIZE chars */
    state.bufp = state.buf;
    if(R_Verbose)
	        REprintf(" >R_ReplConsole(): before \"for(;;)\" {main.c}\n");

    for(;;) {
       status = Rf_ReplIteration(rho, savestack, browselevel, &state);
       if(status < 0) {
         if (state.status == PARSE_INCOMPLETE)
                error(_("unexpected end of input"));
	            return;
       }
    }
										}

#endif

/*
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#ifndef _FILE_OFFSET_BITS
#define _FILE_OFFSET_BITS 64
#endif
*/
#include <sys/time.h>
#include <sys/resource.h>
//       int getrlimit(int resource, struct rlimit *rlp);
//       int setrlimit(int resource, const struct rlimit *rlp);
//       struct rlimit {
//              rlim_t rlim_cur;  /* Soft limit */
//              rlim_t rlim_max;  /* Hard limit (ceiling for rlim_cur) */
//       };
SEXP Supr_info_extended()
{
  // TODO
  struct rlimit dfs_rlimit;
  int rc = getrlimit(RLIMIT_NOFILE, &dfs_rlimit);  
  if(rc == -1)
    error(_("getrlimit(RLIMIT_NOFILE, ...): %s"), strerror(errno));

  SEXP dfs_max = PROTECT(allocVector(REALSXP, 2));
  SEXP names = PROTECT(allocVector(STRSXP, 2));
  SET_STRING_ELT(names, 0, mkChar("Soft_limit"));
  SET_STRING_ELT(names, 1, mkChar("Hard_limit"));
  setAttrib(dfs_max, R_NamesSymbol, names);
  REAL(dfs_max)[0] = dfs_rlimit.rlim_cur;
  REAL(dfs_max)[1] = dfs_rlimit.rlim_max;

  SEXP ret_val = PROTECT(CONS(dfs_max, R_NilValue));
  SET_TAG(ret_val, install("RLIMIT_NOFILE"));

  SEXP t = ret_val;
  SEXP ncpu = PROTECT(ScalarInteger((int)sysconf(_SC_NPROCESSORS_ONLN)));
  SETCDR(t, CONS(ncpu, R_NilValue));
  t = CDR(t);
  SET_TAG(t, install("ncpu"));

  UNPROTECT(3);
  return ret_val;
}

void *Supr_R_interactive(void *arg)
{
  sem_t *sem = (sem_t *) ((void **)arg)[0];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[1];
  char *slavename = (char *) ((void **)arg)[2];
  int xterm_pid  = *((int*) ((void **)arg)[3]);

  //basic_info("posix_openpt. slavename: %s", slavename);
  FILE *slave = fopen(slavename, "r+");
  //fprintf(slave, "\033[0;32m%s~ $\033[0m %s [%d]\n", Supr_hostname, proc_cmd, getpid());

  supr_thread_t *th = newThread(pthread_self(), getpid(),
              syscall(SYS_gettid), THREAD_STATE_NEW,
              (unsigned long) &sem);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  /*
  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);
  */

  {
    /*
    char buf[256], window[256];
    snprintf(buf, sizeof(buf), "-S%s/%d", strrchr(slavename,'/')+1, master);
    if(!fork()) {
      execlp("xterm", "xterm", buf, (char *)0);
      _exit(1);
    }

    FILE *slave = fopen(slavename, "r+");

    fgets(window, sizeof window, slave);
    basic_info("window: %s\n", window);
    */



    //for(int i=0; i< 5; i++){
    //  fputs("\033[0;34m> say something: \033[0m", slave);
    //  fgets(buf, sizeof buf, slave);
    //  fprintf(slave, "[1] you said %s\n", buf);
    //}
//    sleep(3);
//			        return 0;
// REPL (Read-Eval-Print Loop)
//  int my_ReplConsole(SEXP rho, int savestack, int browselevel)
    //

    //fprintf(slave, "\033[0;32m%s~ $\033[0m %s [%d]\n", Supr_hostname, proc_cmd, getpid());

    //FILE *slave = fdopen(xterm_out_fd, "w+");
    //fprintf(slave, "\033[0;32m%s~ $\033[0m %s [%d]\n", Supr_hostname, proc_cmd, getpid());

    int xterm_in_fd = open(slavename, O_RDONLY);
    int xterm_out_fd = open(slavename, O_WRONLY);
    int xterm_err_fd = open(slavename, O_WRONLY);

    int save_in  = dup(STDIN_FILENO);
    int save_out = dup(STDOUT_FILENO);
    int save_err = dup(STDERR_FILENO);
    dup2(xterm_in_fd, STDIN_FILENO);
    dup2(xterm_out_fd, STDOUT_FILENO);
    dup2(xterm_err_fd, STDERR_FILENO);

    //fprintf(stderr, "1. \033[0;32m%s~ $\033[0m %s \n", Supr_hostname, "waiting ...");
    //fprintf(stdout, "1. \033[0;32m%s~ $\033[0m %s \n", Supr_hostname, "waiting ...");

//
    pthread_mutex_lock(&th->mutex);
      sem_post(sem);
//      fprintf(stderr, "(wait)1. \033[0;32m%s~ $\033[0m %s \n", Supr_hostname, "waiting ...");
      pthread_cond_wait(&th->cond, &th->mutex);
    pthread_mutex_unlock(&th->mutex);
//

//    fprintf(stderr, "2. \033[0;32m%s~ $\033[0m %s \n", Supr_hostname, "waiting ..."); //    fprintf(stderr, "2. \033[0;32m%s~ $\033[0m pid: %d, tid: %d\n", Supr_hostname, getpid(), th->tid);

/*
    pthread_mutex_lock(&th->mutex);
      pthread_cond_wait(&th->cond, &th->mutex);
    pthread_mutex_unlock(&th->mutex);
*/

 //   fprintf(stderr, "2. \033[0;35m%s~ $\033[0m %s \n", Supr_hostname, "waiting ...");

    SEXP rho = R_GlobalEnv;
    int savestack = R_PPStackTop;
    int browselevel = 0;

    int status = -1;
    R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};
    state.buf[0] = '\0';
    state.buf[CONSOLE_BUFFER_SIZE] = '\0';
    state.bufp = state.buf;
    //char *prompt[] = {">> ", "+  "};
    //char prompt_buf[256];

    basic_info("R_Interactive: %d", R_Interactive);

    if(R_Interactive)
    {
      basic_info("%d do Rf_ReplIteration", gettid());
      fprintf(stderr, "%d do Rf_ReplIteration\n"
      "Type Ctr+D to stop REPL\n\n", gettid());
    
      { // TODO...
        int rc = pthread_mutex_trylock(&supr3_R_Busy_mutex);
	if(rc != 0){
	  error_info("locked by proc: %d", 
	  	supr3_R_Busy_mutex.__data.__owner);
	} else {
	  verbose_info("locked! unlock ...");
          rc = pthread_mutex_unlock(&supr3_R_Busy_mutex);
	}
      }

      BEGIN_R_EVAL();
      //status = Rf_ReplIteration(rho, savestack, browselevel, &state);
        //basic_info("Rf_ReplIteration: %d", status);
        for(;;) {
          status = Rf_ReplIteration(rho, savestack, browselevel, &state);
          if(status < 0) {
            if (state.status == PARSE_INCOMPLETE)
                error(_("unexpected end of input"));
		    break;
	            //return;
          }
	  //basic_info("X_term_exit: %d", X_term_exit);
	  if(X_term_exit) // xterm_repl_iter = FALSE
	    break;
        }
      END_R_EVAL();

      //basic_info("%d done Rf_ReplIteration", gettid());
      fprintf(stderr, "\n%d done Rf_ReplIteration\n\n", gettid());
    } 
    

    dup2(save_in, STDIN_FILENO);
    dup2(save_out, STDOUT_FILENO);
    dup2(save_err, STDERR_FILENO);
  }
  pthread_mutex_lock(&th->mutex);
    free(th->name);
    th->name = NULL;
    kill(xterm_pid, SIGKILL);
  pthread_mutex_unlock(&th->mutex);
  pthread_exit(th); // do pthread_join ...
  return NULL;
}

//#define _XOPEN_SOURCE 600 
//#include <fcntl.h>
//       int posix_openpt(int flags);

//extern int posix_openpt (int __oflag);

int Supr_gdb_C(int proc, int interactive, supr_thread_t **thread_addr,
	char **xterm_name_addr){

  int xterm_fd;
  char *slavename = *xterm_name_addr;
  FILE *f_slave = NULL;

  pid_t cpid;
  unsigned long int window_id;

  if(!slavename) { 
    char *pSptyName = NULL;
    if((xterm_fd = posix_openpt(O_RDWR | O_NONBLOCK | O_NOCTTY))==-1
        || grantpt(xterm_fd) == -1
        || unlockpt(xterm_fd) == -1
        || !(pSptyName = ptsname(xterm_fd))
        ) {
      error_info("posix_openpt | grantpt | unlockpt | ptsname, %s",
    	strerror(errno));
      return -1;
    }

    int master = xterm_fd;
    //int slave = open(pSptyName, O_RDWR);
    slavename = pSptyName;
    *xterm_name_addr = slavename;

    //basic_info("xterm_fd: %d, ptsname: %s", xterm_fd, pSptyName);
    basic_info("\033[0;33mgetpid(): %d\033[0m", getpid());

    char buf[256], window[256];
    //snprintf(buf, sizeof(buf), "-S%s/%d", strrchr(slavename,'/')+1, master);
    snprintf(buf, sizeof(buf), "-S%s/%d", strrchr(slavename,'/')+1, master);

    char tmp[256];
    sprintf(tmp, "xterm-%d.out", getpid());

    int out_fd = open(tmp, O_WRONLY|  O_CREAT | O_TRUNC, 0600);
    int err_fd = open(tmp, O_WRONLY| O_CREAT | O_TRUNC, 0600);
    int in_fd = open(tmp, O_RDONLY);


    cpid = fork();
    if(!cpid) {
//      int in_fd = open(tmp, O_RDONLY);
      dup2(in_fd, STDIN_FILENO);
      dup2(out_fd, STDOUT_FILENO);
      dup2(err_fd, STDERR_FILENO);

      int rc = execlp("xterm", "xterm", buf, (char *)0);
      //int rc = execl("/usr/bin/xterm", "xterm", buf, (char *)0);
      //int rc = execlp("xterm", "xterm", buf, "&", (char *)0);
      // FIXME...
      if(info_addr){
	info_sc = NULL;
	if(info_addr) info_sc = socketOpen1(info_addr);
        basic_info("execlp(\"xterm\", ...): %d", rc);
	error_info("%s, %s", __func__, strerror(errno));
	Supr_decref(info_sc);
	// TODO...
      }
      //_exit(1);
      exit(EXIT_FAILURE);
    }

    close(out_fd);
    close(err_fd);
    close(in_fd);

    /*
    {
	int rc = kill(cpid, 0);
        basic_info("kill child proc %d ... rc: %d, err: %s\n",
		cpid, rc, strerror(errno));
    }
    */

    f_slave = fopen(slavename, "r+");

    int kill_xterm = FALSE;
    {
      //basic_info("\033[0;31mfopen(slavename, \"r+\"): %p\033[0m", f_slave);

      int f_fd = fileno(f_slave);
      int max_fd = f_fd;

      struct timeval tv;
      tv.tv_sec=15;
      tv.tv_usec=0;

      fd_set readfds;
      FD_ZERO(&readfds);

      FD_SET(f_fd, &readfds);

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0) {
        basic_info("%s:%d. \033[0;35m%s-select: %d\033[0m", __FILE__, __LINE__,  __func__, ns);
        kill_xterm = TRUE;
      }
    }

    /*
    {
	int rc = kill(cpid, 0);
        basic_info("kill child proc %d ... rc: %d, err: %s\n",
		cpid, rc, strerror(errno));
    }
    */
    //pid_t mpid = fork();

    //if(!mpid)
    if(kill_xterm)
    {
      // Check error messages ...
      FILE *f_tmp = fopen(tmp, "r");
      if(f_tmp){
	    char buf[4096];
	    while(fgets(buf, sizeof buf, f_tmp)) {
	      basic_info("\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	      fprintf(stderr, "\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	    }
	    fclose(f_tmp);
      }

      int status;
      errno = 0;
      int rc = waitpid(cpid, &status, 0);
      basic_info("%s:%d. %s: waitpid(%d, ...), rc: %d, status: %d, %s %s\n",
             __FILE__, __LINE__, __func__, cpid, rc, status,
	     errno?"err: ":"", strerror(errno));

      unlink(tmp);
      return -1;


      /*
      int status;
      basic_info("calls waitpid ... testing only");
      // kill
      {
        //sleep(30);
	int rc = kill(cpid, 0);
        basic_info("kill child proc %d ... rc: %d, err: %s\n",
		cpid, rc, strerror(errno));
	
	rc = kill(cpid, SIGKILL); // no need to kill?
        basic_info("kill child proc %d ... rc: %d, err: %s\n",
		cpid, rc, strerror(errno));
      }

      errno = 0;
      int rc = waitpid(cpid, &status, 0);
      basic_info("%s:%d. %s: waitpid(%d, ...), rc: %d, status: %d, %s %s\n",
             __FILE__, __LINE__, __func__, cpid, rc, status,
	     errno?"err: ":"", strerror(errno));

      if(rc == -1){
        error_info("err: %s", strerror(errno));

	{
	  FILE *f_tmp = fopen(tmp, "r");
	  if(f_tmp){
	    char buf[4096];
	    while(fgets(buf, sizeof buf, f_tmp)) {
	      basic_info("\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	      fprintf(stderr, "\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	    }
	    fclose(f_tmp);
	  }
	}

	return -1;
      } else if(WIFEXITED(status)){
      
        basic_info("terminated normally, that is, by calling exit(3) or _exit(2), or by returning from main()");
        int exit_status = WIFEXITED(status);
        basic_info("exit  status  of xterm: %d", exit_status);
	if(exit_status){
          //sprintf(tmp, "xterm-%d.out", getpid());
	  FILE *f_tmp = fopen(tmp, "r");
	  if(f_tmp){
	    char buf[4096];
	    while(fgets(buf, sizeof buf, f_tmp)) {
	      basic_info("\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	      fprintf(stderr, "\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	    }
	    fclose(f_tmp);
	  }
          *xterm_name_addr = NULL;
	  return -1;
	}
      
      } else {
        error_info("\033[0;31mterminated abnormally\033[0m");
	if(WIFSIGNALED(status)){
	  int sig = WTERMSIG(status);
          error_info("\033[0;31m\tsignal: %d\033[0m", sig);
	} else { // 
	}
	{
	  FILE *f_tmp = fopen(tmp, "r");
	  if(f_tmp){
	    char buf[4096];
	    while(fgets(buf, sizeof buf, f_tmp)) {
	      basic_info("\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	      fprintf(stderr, "\033[0;31m%s: \033[0;31m%s\033[0m", tmp, buf);
	    }
	    fclose(f_tmp);
	  }
	}

	return -1;
      }
      //exit(EXIT_SUCCESS);
      */
    } // else { basic_info("parent proc proc continue...\n"); }
    unlink(tmp);

    //f_slave = fopen(slavename, "r+");
    //basic_info("\033[0;31mfopen(slavename, \"r+\"): %p\033[0m", f_slave);
    //fprintf(f_slave, "\033[0;31mfopen(slavename, \"r+\"): %p\033[0m\n",f_slave);

    fgets(window, sizeof window, f_slave);
    if(strchr(window, '\n')) *strchr(window, '\n') = 0;
    //basic_info("window (id?): %s", window);
    //fprintf(f_slave, "window (id?): %s", window);

    //fprintf(f_slave, "\033[0;32mxterm args: \"%s\"\033[0m\n", buf);
    //fprintf(f_slave, "\033[0;34mhost: %s \033[0m\n", Supr_hostname);
    //fprintf(f_slave, "\033[0;34mpid: %d \033[0m\n", getpid());


    // Window
    //
    char *endptr;
    if(strchr(window, '\n')) *strchr(window, '\n') = 0;
    window_id = strtoul(window, &endptr, 16);
    //basic_info("pid: %d, window id: 0x%x", cpid, window_id);
    fprintf(f_slave, "xterm pid: %d, window id: 0x%lx\n", cpid, window_id);
    X11_windows(window_id);
    //
    fclose(f_slave);
  }

  f_slave = fopen(slavename, "r+");
  //basic_info("\033[0;31mfopen(slavename, \"r+\"): %p\033[0m", f_slave);
  //fprintf(f_slave, "\033[0;31m%d. fopen(slavename, \"r+\"): %p\033[0m", __LINE__, f_slave);


  if(!*thread_addr){

    //basic_info("\033[0;31mpthread_create...\033[0m");
    //fprintf(f_slave, "\033[0;31mpthread_create...\n\033[0m");
    //fflush(f_slave);

    pthread_t thread;
    supr_thread_t *R_interactive = NULL;
    sem_t sem;
    sem_init(&sem, 1, 0);
    void *arg[] = {&sem, &R_interactive, slavename, &cpid, NULL};
    int rc = pthread_create(&thread, NULL, Supr_R_interactive, arg);

    sem_wait(&sem);
    sem_destroy(&sem);
    //basic_info("pid %d started an interactive R interface", getpid());

    pthread_mutex_lock(&R_interactive->mutex);
      free(R_interactive->name);
      //R_interactive->name = strdup("R_interactive");
      R_interactive->name = strdup(slavename);
      //vectorAdd(threads, R_interactive);
      pthread_cond_signal(&R_interactive->cond);
    pthread_mutex_unlock(&R_interactive->mutex);

    if(thread_addr)
      *thread_addr = R_interactive;
    //basic_info("\033[0;31mpthread_created\033[0m");

    /*
    X11_windows(window_id);
    pthread_mutex_lock(&R_interactive->mutex);
      pthread_cond_signal(&R_interactive->cond);
    pthread_mutex_unlock(&R_interactive->mutex);
    */
  }

  //pid_t proc = getpid();
  //if(S_proc != R_NilValue) proc = asInteger(S_proc);

  //if(interactive)

  //sleep(60);
  return 0;

//
/*
  pid_t pid = fork();
  if(pid == -1) {
    error_info("fork, %s", strerror(errno));
    return -1;
  }

  if(pid) {
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    basic_info("C (%s:%d) waitpid(%d, ...), rc: %d, status: %d, err: %s\n",
	   __FILE__, __LINE__, pid, rc, status, strerror(errno));
  } else { // FIXME? "/usr/bin/xterm"
    char proc_str[64];
    sprintf(proc_str, "%d", proc);
//    char gdb_cmd[256];
//    sprintf(gbd_cmd, "gdb -p %d", proc);

    fprintf(stderr, "gdb -p %s\n", proc_str);
//    fprintf(stderr, "gdb_cmd: %s\n", gdb_cmd);
    errno = 0;
    int rc = execl("/usr/bin/xterm", "xterm", 
    	"+ah", 
    	"-aw", 
//	gdb_cmd,
    	"-e", "gdb", "-p", proc_str, 
    	(char *) NULL);
    fprintf(stderr, "Error in execl, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  return 0;
*/
}

void Supr_do_xterm(int use_xterm, int interactive){

  static supr_thread_t *gdb_thread = NULL;
  static char *xterm_name = NULL;
  static pid_t xterm_pid = -1;

  if(use_xterm){
    if(gdb_thread){
      /*
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        rc = pthread_cond_signal(&gdb_thread->cond);
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
      */
//
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        if(gdb_thread->name) {
	  //
          rc = pthread_cond_signal(&gdb_thread->cond);
	} else {
          void *ret_val;
          rc = pthread_join(gdb_thread->ptid, &ret_val);
	  // destroy...
	  xterm_name = NULL;
          Supr_options.xterm = 0;
	}
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
      if(!xterm_name)
          gdb_thread = NULL; // FIXME... destroy 
//
    }

    if(!gdb_thread){ // if(!xterm_name || !gdb_thread)
      int rc = Supr_gdb_C(0, interactive, &gdb_thread, &xterm_name);
      if(rc == -1) {
        basic_info("Supr_gdb_C: %d", rc);
        Supr_options.xterm = 0;
	xterm_name = NULL;
	gdb_thread = NULL;
	return;
      }
      Supr_options.xterm = 1;
      //fprintf(stderr, "%s:%d. tid: %d\n\n", __FILE__,__LINE__, gdb_thread->tid);
      //sleep(1);
    
// testing
/*
      rc = pthread_mutex_lock(&gdb_thread->mutex);
        rc = pthread_cond_signal(&gdb_thread->cond);
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
*/
    }

    //fprintf(stderr, "tid: %d, rc: %d\n", gdb_thread->tid, rc);

  } else {
    /*
    basic_info("%s(%s): TODO...", __func__, use_xterm? "TRUE":"FALSE");
    xterm_name = NULL;
    if(gdb_thread){
      int rc = pthread_cancel(gdb_thread->ptid); // FIXME
      fprintf(stderr, "pthread_cancel, rc: %d\n", rc);
      void *ret_val;
      rc = pthread_join(gdb_thread->ptid, &ret_val);
      fprintf(stderr, "pthread_join, rc: %d\n", rc);
      for(int i=0; i<10; i++) fprintf(stderr, "\n");
      gdb_thread = NULL;
    }
    Supr_options.xterm = 0;
    */
  }
}



SEXP Supr_gdb(SEXP S_proc, SEXP S_interactive){

  error(_("TODO"));

  pid_t proc = getpid();
  int interactive = FALSE;
  if(S_proc != R_NilValue) proc = asInteger(S_proc);
  if(S_interactive != R_NilValue) interactive = asInteger(S_interactive);

  char *xterm_name;
  int rc = Supr_gdb_C(proc, interactive, NULL, &xterm_name); // return supr_thread?
  return R_NilValue;
}

SEXP Supr_cntxt(SEXP args, SEXP env)
{
  //
  // start services, if any, in the following order: 
  // 	info, dfs, master, workers, and driver
  //

  SEXP s = args;

  {
    SEXP t = args;
    while(TYPEOF(t) != NILSXP){
      if(TYPEOF(TAG(t)) != NILSXP){
        if(strcmp(CHAR(PRINTNAME(TAG(t))),"shutdown")==0){
	  return Supr_shutdown();
	} else if(strcmp(CHAR(PRINTNAME(TAG(t))),"quit")==0){
	  return Supr_quit();
	} else if(strcmp(CHAR(PRINTNAME(TAG(t))),"config")==0){
	  return Supr_config(CAR(t), env);
	} else if(strcmp(CHAR(PRINTNAME(TAG(t))),"shm")==0){
	  return Supr_supr_shm(CAR(t), env);
	} else if(strcmp(CHAR(PRINTNAME(TAG(t))),"tmp")==0){
	  return Supr_supr_tmp(CAR(t), env);
        }
      } else if(TYPEOF(CAR(t)) == SYMSXP) {
        if(strcmp(CHAR(PRINTNAME(CAR(t))),"shutdown")==0){
	  return Supr_shutdown();
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"quit")==0){
	  return Supr_quit();
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"proc")==0){
	  return Supr_supr_proc();
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"killall")==0){
	  return Supr_supr_killall();
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"config")==0){
	  return Supr_config(CDR(t), env);
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"shm")==0){
	  //basic_info("typeof(CAR(t)): %s", type2char(TYPEOF(CAR(t))));
	  return Supr_supr_shm(CDR(t), env);
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"tmp")==0){
	  //basic_info("typeof(CAR(t)): %s", type2char(TYPEOF(CAR(t))));
	  return Supr_supr_tmp(CDR(t), env);
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"on.exit")==0){
	  return Supr_add_onExit(CDR(t), env);
	} else if(strcmp(CHAR(PRINTNAME(CAR(t))),"default")==0){
          Cluster_setDefaults();
	  return R_NilValue;
        }
      } else if(TYPEOF(CAR(t)) == STRSXP) {
        if(strcmp(CHAR(asChar(CAR(t))),"shutdown")==0){
	  return Supr_shutdown();
	} else if(strcmp(CHAR(asChar(CAR(t))),"quit")==0){
	  return Supr_quit();
        }
      }
      t = CDR(t);
    }
  }

  int has_info_arg = FALSE;
  { // sort ...
    char *names[] = {"info", "dfs", "master", "workers", "driver", NULL};
    for(int i=0; names[i]; i++){
      char *name = names[i];
      SEXP p = s; 
      SEXP t = CDR(p);
      while(TYPEOF(t) != NILSXP){

        if(TYPEOF(TAG(t)) == SYMSXP &&
		       	strcmp(name, CHAR(PRINTNAME(TAG(t))))==0){
	    SEXP node = PROTECT(t);
	    SETCDR(p, CDR(t));

	    SETCDR(node, CDR(s));
	    SETCDR(s, node);
	    s = CDR(s);
	    UNPROTECT(1);
	    if(i==0) has_info_arg = TRUE;
	    break;
        }

	p = t;
	t = CDR(t);
      }
    }
  }

  s = CDR(args);

  if(!has_info_arg){
    SEXP dflt = findVar(install("info"), SuprContextEnv);
    if(dflt == R_UnboundValue)
	    error(_("no info server is available"));

    if(TYPEOF(dflt) == STRSXP) {
      SEXP info = PROTECT(CONS(dflt, s)); //SETCDR(info, s);
      SET_TAG(info, install("info"));
      SETCDR(args, info);
      s = CDR(args);
      UNPROTECT(1);
    } else {
	  supr_socket_conn_t *sc = (supr_socket_conn_t *)
		  R_ExternalPtrAddr(dflt);
	  if(sc){
	    int pong = tryPingSocketServer2(sc->host, sc->port);
	    if(pong == CLUSTER_PONG) {
	      //warning(_("info server %s:%d is still running"), sc->host, sc->port);
	      //fprintf(stderr, "info server %s:%d is still running", sc->host, sc->port);
	      verbose_info("info server %s:%d is still running", sc->host,
			      sc->port);
	      //defineVar(install("info"), Supr_infoServer, SuprContextEnv);
	    } else {
	      error(_("info server (%d): %s"), pong, strerror(errno));
	    }
	  }
    }
  }

  while(TYPEOF(s) != NILSXP){

    SEXP tag = TAG(s);

    if(TYPEOF(tag) != SYMSXP) {
      SEXP expr = Rf_deparse1m(CAR(s), 0, DEFAULTDEPARSE);
      //error(_("invalid argument: %s"), deparse1(CAR(s), TRUE, 0));
      error(_("invalid argument: %s"), CHAR(asChar(expr)));
    }
    
    const char *name = CHAR(PRINTNAME(tag));

    //fprintf(stderr, "name: %s\n", name);
      
    SEXP val = PROTECT(eval(CAR(s), env));
    //int nUNPROTECT = 1;


    if( strcmp(name, "info") == 0 ){

      if(TYPEOF(val) == NILSXP){
	  if(Supr_verbose)
            fprintf(stderr, "stop info server ... ?");
	  //
	  
      } else {
      
        if(Supr_verbose)
          fprintf(stderr, "start info server %s ...\n", CHAR(asChar(val)));

	SEXP infoServer = findVar(install("info"), SuprContextEnv);
	if(TYPEOF(infoServer) == EXTPTRSXP){
	  supr_socket_conn_t *sc = (supr_socket_conn_t *)
		  R_ExternalPtrAddr(infoServer);
	  if(sc){
	    int pong = tryPingSocketServer2(sc->host, sc->port);
	    if(pong == CLUSTER_PONG) {
	      warning(_("info server %s:%d is still running"), sc->host,
			      sc->port);
	      s = CDR(s);
	      continue;
	    }
	  }
	}

	if(Supr_infoServer && TYPEOF(Supr_infoServer)==EXTPTRSXP){
	  supr_socket_conn_t *sc = (supr_socket_conn_t *)
		  R_ExternalPtrAddr(Supr_infoServer);
	  if(sc){
	    int pong = tryPingSocketServer2(sc->host, sc->port);
	    if(pong == CLUSTER_PONG) {
	      warning(_("info server %s:%d is still running"), sc->host,
			      sc->port);
	      basic_info("info server %s:%d is still running", sc->host,
			      sc->port);
	      defineVar(install("info"), Supr_infoServer, SuprContextEnv);
	      s = CDR(s);
	      continue;
	    }
	  }
	}

	defineVar(install("info"), val, SuprContextEnv);
	infoServer = DD_enableInfo(0);
	defineVar(install("info"), infoServer, SuprContextEnv);
	Supr_infoServer = infoServer; // FIXME
      }

    } else if( strcmp(name, "driver") == 0 ){
      //int savestack = R_PPStackTop;
      int nUNPROTECT = 0;
      if(TYPEOF(val) == NILSXP){
	  if(Supr_verbose)
            fprintf(stderr, "stop driver ... ?");
	  SEXP driver = findVar(tag, SuprContextEnv);
	  SEXP address= PROTECT(getAttrib(driver, install("address")));

	  //SEXP all = R_FalseValue; // R_TrueValue;
	  //Cluster_stopDriver(all);
          Supr_stopDriver();

	  defineVar(tag, address, SuprContextEnv);
	  UNPROTECT(1);
      } else {
	if(Supr_verbose)
            fprintf(stderr, "start driver ...\n");

	SEXP port = val;
	if(TYPEOF(val)==STRSXP && LENGTH(val)>0){
	    const char *port_str = CHAR(STRING_ELT(val,0));

	    //int pong = tryPingSocketServer1(port_str);
	    int who_pid;
	    supr_socket_conn_t *sc = NULL;
	    int who = -1;
	    if(!strstr(port_str, "+"))
	      who = Supr_who3(port_str, &who_pid, &sc);

	    //if(pong == CLUSTER_PONG)
	    if(who == DRIVER_CONN)
	    {
	      //supr_socket_conn_t *sc = socketOpen1(port_str);
	      if(sc){
	        SEXP ret_val = PROTECT(Cluster_createObjectTableEnv(R_NilValue));
	        char addr[strlen(sc->host)+16];
	        sprintf(addr, "%s:%d", sc->host, sc->port);
	        setAttrib(ret_val, install("address"), mkString(addr)); 
	        SEXP scPtr=PROTECT(R_MakeExternalPtr(sc,R_NilValue,R_NilValue));
	        R_RegisterCFinalizerEx(scPtr,Cluster_connection_finalizer,TRUE);
	        setAttrib(ret_val, install("conn"), scPtr); 
	        UNPROTECT(2); 

	        defineVar(install("driver"), ret_val, SuprContextEnv);
	        defineVar(install("cluster"), ret_val, SuprEnv);// FIXME

                Supr_addLocalFunctions(ret_val, "driver.localfuns", "driver");

	        SEXP infoServer = findVar(install("info"), SuprContextEnv);
		int info_port = -1;
	       	if(TYPEOF(infoServer) == EXTPTRSXP){
		       	supr_socket_conn_t *info = (supr_socket_conn_t *)
			       	R_ExternalPtrAddr(infoServer);
		       	info_port = info->port;
	       	}

		
		int msg[] = {USER_REGISTER, getpid(), info_port};
		write(sc->fd, msg, sizeof(msg));

		// shm_io?
		//{
		shm_io_info_t *shm_io_info = Supr_createShmConnection(ret_val,
				"user");
		if(shm_io_info){
		  driver_shm_io = shm_io_info;
                  SEXP shmPtr = PROTECT(R_MakeExternalPtr(shm_io_info,
				       	R_NilValue, R_NilValue));
	       	  R_RegisterCFinalizerEx(shmPtr, Shm_io_info_finalizer, TRUE);
	       	  setAttrib(ret_val, install("shmio"), shmPtr);
		  UNPROTECT(1);
		} else {
			warning(_("cannot establish shm connection, %s"),
					strerror(errno));
		}


		//}

		// uid was checked by Supr_who3
		// verify with user name?
		{
		  int rc = Supr_checkLogin(sc->fd, sc, "driver");
		  if(rc != 0){
		    error_info("%s:%d. FIXME: Supr_checkLogin(sc-fd, sc)",
				    __func__, __LINE__);
		  }
		}
	
	        //return ret_val;
		char buf[256];
		sprintf(buf, "connected to driver '%s:%d'", sc->host, sc->port);
		Supr_sendSimpleMessage(buf, msg_color, DEFAULT_INFO_TYPE, 0);
                s = CDR(s);
	        continue;
	      }

	    } else if(who > 0){
	      error(_("'%s:pid=%d', is not an accessible driver server"),
			      port_str, who_pid);
	      close(sc->fd);
	      free(sc); // TODO
	    }

	    int port_int = -1;
	    if(strstr(port_str, ":")){
	      port_int = atoi(strstr(port_str, ":")+1);
	    } else {
	      port_int = atoi(port_str);
	    }
	    port = PROTECT(ScalarInteger(port_int));
            nUNPROTECT++;
	} else {
	}


	SEXP master = findVar(install("master"), SuprContextEnv);
	if(master == R_UnboundValue){
	    master = R_NilValue;
	} 
	

	SEXP namenode = R_NilValue;
	if(DFS_namenode){
	    char buf[strlen(DFS_namenode->host)+16];
	    sprintf(buf, "%s:%d", DFS_namenode->host, DFS_namenode->port);
	    namenode = PROTECT(mkString(buf));
            nUNPROTECT++;
	} else {
	    namenode = findVar(install("dfs"), SuprContextEnv);
	    if(namenode == R_UnboundValue){
	      namenode = R_NilValue;
	    } 
	}

	SEXP driver =  PROTECT(Cluster_startDriver(
				val,
			port,
		       	master,
			namenode,
			Supr_verbose ? R_TrueValue : R_FalseValue,
			Supr_debug ? R_TrueValue : R_FalseValue,
			Supr_infov ? R_TrueValue : R_FalseValue));
        nUNPROTECT++;
	defineVar(install("driver"), driver, SuprContextEnv); 
	//UNPROTECT(nUNPROTECT); nUNPROTECT = 0;
#define DONOT_CONNECT_MASTER
#ifndef DONOT_CONNECT_MASTER
	//Check master
	//
	{
	pthread_mutex_lock(&Supr_syncMutex); // fixme ...

          double timeout = Supr_options.timeout;
          struct timespec wait;
          clock_gettime(CLOCK_REALTIME, &wait);
          double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
          timeout += save_time;

          wait.tv_sec = (long) floor(timeout);
          wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

	  Supr_syncObject = pthread_getspecific(currentThreadKey);
          pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);
	  Supr_syncObject = NULL;

        pthread_mutex_unlock(&Supr_syncMutex);

	//}
	//for(int j=0; j < Supr_options.timeout; j++)  {
	
	  SEXP master = findVar(install("master"), SuprContextEnv);
	  if(master == R_UnboundValue || TYPEOF(master)==STRSXP){
            SEXP tbPtr = HASHTAB(driver);
	    R_ObjectTable *tb = (R_ObjectTable *)R_ExternalPtrAddr(tbPtr);
	    SEXP objects = PROTECT(tb->objects(tb));
	    int len = LENGTH(objects);
	    int i=0;
	    for(; i<len; i++){
              if(strncmp("master", CHAR(STRING_ELT(objects, i)),
				      strlen("master"))==0) {
	        defineVar(install("master"),
		      mkString(strstr(CHAR(STRING_ELT(objects, i)), "//")+2),
		      SuprContextEnv);
		break;
	      }
	    }
	    //PrintValue(objects);
	    UNPROTECT(1);
	  }
	}
#endif //DONOT_CONNECT_MASTER

#define DONOT_CONNECT_DFS
#ifndef DONOT_CONNECT_DFS

	//Check dfs 
	{
	pthread_mutex_lock(&Supr_syncMutex); // fixme ...

          double timeout = Supr_options.timeout;
          struct timespec wait;
          clock_gettime(CLOCK_REALTIME, &wait);
          double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
          timeout += save_time;

          wait.tv_sec = (long) floor(timeout);
          wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

	  Supr_syncObject = pthread_getspecific(currentThreadKey);
          pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);
	  Supr_syncObject = NULL;

        pthread_mutex_unlock(&Supr_syncMutex);

	  SEXP dfs = findVar(install("dfs"), SuprContextEnv);
	  if(dfs == R_UnboundValue || TYPEOF(dfs)==STRSXP){
            SEXP tbPtr = HASHTAB(driver);
	    R_ObjectTable *tb = (R_ObjectTable *)R_ExternalPtrAddr(tbPtr);
	    SEXP objects = PROTECT(tb->objects(tb));
	    int len = LENGTH(objects);
	    int i=0;
	    for(; i<len; i++){
              if(strncmp("dfsname", CHAR(STRING_ELT(objects, i)),
				      strlen("dfsname"))==0) {
	        defineVar(install("dfs"),
		      mkString(strstr(CHAR(STRING_ELT(objects, i)), "//")+2),
		      SuprContextEnv);
		break;
	      }
	    }
	    //PrintValue(objects);
	    UNPROTECT(1); // if(i<len) break; sleep(1);
	  }
	}
#endif // DONOT_CONNECT_DFS

      }
      UNPROTECT(nUNPROTECT);
      //basic_info("[driver] savestack: %d ?= R_PPStackTop: %d", savestack, R_PPStackTop);
    } else if( strcmp(name, "dfs") == 0 ){

      int savestack = R_PPStackTop;

      if(TYPEOF(val) == NILSXP){
	if(Supr_verbose) fprintf(stderr, "[INFO] stop dfs server ...");
          Supr_stopDFS();
      } else {

	if(TYPEOF(val) == ENVSXP){
	  SEXP address = getAttrib(val, install("address"));
          int pong = tryPingSocketServer1(CHAR(asChar(address)));
	  if(pong != CLUSTER_PONG) {
	    supr_socket_conn_t *sc = Supr_startRemoteDFSNamenode(
			  CHAR(asChar(address)),
			  Supr_options.info,
			  Supr_options.verbose,
			  Supr_options.debug,
			  Supr_options.timeout
			  );
		// verify with user name?
		{
		  int rc = Supr_checkLogin(sc->fd, sc, "DFS");
		  if(rc != 0){
		    error_info("%s:%d. FIXME: Supr_checkLogin(sc-fd, sc)",
				    __func__, __LINE__);
		  }
		}
            if(DFS_namenode){ // disconnect
	      close(DFS_namenode->fd);
	      free(DFS_namenode); // FIXME: destroy
	      DFS_namenode = NULL;
            }
	    DFS_namenode = sc;
	    SEXP ret_val = PROTECT(DFS_createObjectTableEnv(&DFS_namenode,"."));

	    defineVar(install("dfs"), ret_val, SuprContextEnv);
	    UNPROTECT(1);
	    
	  } else {
	    warning(_("dfs %s exists"), CHAR(asChar(address)));
	  }
	  s = CDR(s);
	  continue;
	}

        if(DFS_namenode){ // disconnect
	      close(DFS_namenode->fd);
	      free(DFS_namenode); // FIXME: destroy
	      DFS_namenode = NULL;
        }


	supr_socket_conn_t *sc = NULL;
	const char *__addr = NULL;

	if(TYPEOF(val) == STRSXP && LENGTH(val)>0){

          
	  int who_pid;
	  __addr = CHAR(STRING_ELT(val, 0));

	  verbose_info("Connect to DFS: %s ...", __addr);

	  int who = -1;
	  if(!strstr(__addr, "+"))
	    who = Supr_who3(__addr, &who_pid, &sc);

//	  fprintf(stderr, "\033[0;31m[%s:%d:%s] val: %s, who: %d/%s, pid: %d, sc: %p\033[0m\n", __FILE__, __LINE__, __func__, __addr, who, connTypeToStr(who),  who_pid, sc);

	  if(who == DFS_NAMENODE_CONN){
	        SEXP infoServer = findVar(install("info"), SuprContextEnv);
		int info_port = -1;
	       	if(TYPEOF(infoServer) == EXTPTRSXP){
		       	supr_socket_conn_t *info = (supr_socket_conn_t *)
			       	R_ExternalPtrAddr(infoServer);
		       	info_port = info->port;
//	  fprintf(stderr, "\033[0;31m[%s:%d:%s] val: %s, who: %d/%s, pid: %d, sc: %p, info_port: %d\033[0m\n", __FILE__, __LINE__, __func__, __addr, who, connTypeToStr(who),  who_pid, sc, info_port);
	       	}

		
		int msg[] = {USER_REGISTER, getpid(), info_port};
		write(sc->fd, msg, sizeof(msg));

	  } else {

	
	    sc = Supr_startRemoteDFSNamenode(
			  __addr,
			  Supr_options.info,
			  Supr_options.verbose,
			  Supr_options.debug,
			  Supr_options.timeout
			  );
	  }
	  DFS_namenode = sc;
	  //fprintf(stderr, "\033[031mDFS_namenode: %p\033[0m\n",DFS_namenode);

	  SEXP ret_val = PROTECT(DFS_createObjectTableEnv(&DFS_namenode, ".")); // or "/"


          int nUNPROTECT = 1;
	  UNPROTECT(nUNPROTECT);
	  defineVar(install("dfs"), ret_val, SuprContextEnv);

	} else if(TYPEOF(val) == EXTPTRSXP){ // Check class?
          DFS_namenode = (supr_socket_conn_t*) R_ExternalPtrAddr(val);
	 
	
          int pong = tryPingSocketServer2(DFS_namenode->host,
			    DFS_namenode->port);
	  if(pong != CLUSTER_PONG) {
	    SEXP expr = Rf_deparse1m(CAR(s), 0, DEFAULTDEPARSE);
	    error(_("invalid 'dfs' argument, %s"), CHAR(asChar(expr)));
	  }
	} else {

	  SEXP expr = Rf_deparse1m(CAR(s), 0, DEFAULTDEPARSE);
	  error(_("invalid 'dfs' argument, %s"), CHAR(asChar(expr)));
	}
      }

      if(savestack != R_PPStackTop)
        basic_info("Warning in %s: savestack=%d ?= R_PPStackTop=%d", __func__,
		      savestack, R_PPStackTop);

    } else if( strcmp(name, "master") == 0 ){
      SEXP master = findVar(install("master"), SuprContextEnv);
      supr_socket_conn_t *sc = NULL;
      if(master != R_UnboundValue && TYPEOF(master) == EXTPTRSXP)
	      sc = (supr_socket_conn_t *) R_ExternalPtrAddr(master);

      if(TYPEOF(val) == NILSXP){
	if(Supr_verbose) fprintf(stderr, "[INFO] stop master server ...");
          Supr_stopMaster();
      } else {

        if(sc){ // disconnect
	      close(sc->fd);
	      free(sc); // FIXME: destroy
	      sc = NULL;
        }

	const char *__addr = NULL;

	if(TYPEOF(val) == STRSXP && LENGTH(val)>0){

	  int who_pid;
	  __addr = CHAR(STRING_ELT(val, 0));
	  int who = Supr_who3(__addr, &who_pid, &sc);

	  fprintf(stderr, "\033[0;31m[%s:%d:%s] val: %s, who: %d/%s, pid: %d, sc: %p\033[0m\n",
		    __FILE__, __LINE__, __func__, __addr, who,
		   connTypeToStr(who),  who_pid, sc);

	  if(who == MASTER_CONN){ // && sc

	        SEXP infoServer = findVar(install("info"), SuprContextEnv);
		int info_port = -1;
	       	if(TYPEOF(infoServer) == EXTPTRSXP){
		       	supr_socket_conn_t *info = (supr_socket_conn_t *)
			       	R_ExternalPtrAddr(infoServer);
		       	info_port = info->port;
	  fprintf(stderr, "\033[0;31m[%s:%d:%s] val: %s, who: %d/%s, pid: %d, sc: %p, info_port: %d\033[0m\n",
		    __FILE__, __LINE__, __func__, __addr, who,
		   connTypeToStr(who),  who_pid, sc, info_port);
	       	}

		
		int msg[] = {USER_REGISTER, getpid(), info_port};
		write(sc->fd, msg, sizeof(msg));
	
	  fprintf(stderr, "\033[0;31m[%s:%d:%s] val: %s, who: %d/%s, pid: %d, sc: %p\033[0m\n",
		    __FILE__, __LINE__, __func__, __addr, who,
		   connTypeToStr(who),  who_pid, sc);

	  } else {

            sc = Supr_startRemoteMaster(
			  __addr,
			  Supr_options.info,
			  Supr_options.verbose,
			  Supr_options.debug,
			  Supr_options.timeout
			  );
		// verify with user name?
		if(sc){
		  int rc = Supr_checkLogin(sc->fd, sc, "master");
		  if(rc != 0){
		    error_info("%s:%d. FIXME: Supr_checkLogin(sc-fd, sc)",
				    __func__, __LINE__);
		  }
		} else {
		  error(_("cannot connect to master: %s"), __addr);
		}
	  }

	  // FIXME
	  SEXP ret_val = PROTECT(Cluster_createObjectTableEnv(R_NilValue));
          int nUNPROTECT = 1;
          char addr[strlen(sc->host)+16];
          sprintf(addr, "%s:%d", sc->host, sc->port);
	  setAttrib(ret_val, install("address"), mkString(addr));

          SEXP scPtr = PROTECT(R_MakeExternalPtr(sc, R_NilValue, R_NilValue));
          nUNPROTECT ++;
          R_RegisterCFinalizerEx(scPtr, Cluster_connection_finalizer, TRUE);
          setAttrib(ret_val, install("conn"), scPtr);

          UNPROTECT(nUNPROTECT);

	  defineVar(install("master"), ret_val, SuprContextEnv);

	  /*
	  SEXP scPtr = PROTECT(R_MakeExternalPtr(sc, R_NilValue,
				  R_NilValue));
	  defineVar(install("master"), scPtr, SuprContextEnv);
	  setAttrib(scPtr, R_ClassSymbol, mkString("SocketConnection"));
	  R_RegisterCFinalizerEx(scPtr, DFS_connection_finalizer, TRUE);
	  UNPROTECT(1);
	  */

	} else if(TYPEOF(val) == EXTPTRSXP){ // Check class?
          sc = (supr_socket_conn_t*) R_ExternalPtrAddr(val);
          int pong = tryPingSocketServer2(sc->host, sc->port);
	  if(pong != CLUSTER_PONG) {
	    SEXP expr = Rf_deparse1m(CAR(s), 0, DEFAULTDEPARSE);
	    error(_("invalid 'master' argument, %s"), CHAR(asChar(expr)));
	  }
	} else {
	  SEXP expr = Rf_deparse1m(CAR(s), 0, DEFAULTDEPARSE);
	  error(_("invalid 'master' argument, %s"), CHAR(asChar(expr)));
	}
      }

    } else if( strcmp(name, "ths") == 0 ){

      //fprintf(stderr, "thread... typeof: %s\n", type2char(TYPEOF(val)));

      if(TYPEOF(val) == NILSXP){
        SEXP __servers = findVar(install("ths"), SuprContextEnv);
	SEXP servers = PROTECT(CONS(R_NilValue, R_NilValue));

        //fprintf(stderr, "thread... typeof: %s\n", type2char(TYPEOF(__servers)));

	if(TYPEOF(__servers) == LISTSXP){
	  SETCDR(servers, __servers);
	} else if(TYPEOF(__servers) == VECSXP){
	  SEXP t = servers;
	  int len = LENGTH(__servers);
	  SEXP names = getAttrib(__servers, R_NamesSymbol);
	  for(int i=0; i<len; i++){
	    SEXP server = VECTOR_ELT(__servers,i);
	    SETCDR(t, CONS(server, R_NilValue));
	    t = CDR(t);
	    if(names != R_NilValue)
	      SET_TAG(t, install(CHAR(STRING_ELT(names, i))));
	  }
        }

	//PrintValue(__servers);

	if(TYPEOF(servers) == LISTSXP){
	  
	  SEXP t = CDR(servers);
	  while(TYPEOF(t) != NILSXP){
	    SEXP server = CAR(t);
	    if(TYPEOF(server)==ENVSXP){
	      SEXP addr = getAttrib(server, install("address"));
	      //basic_info("shutdown %s", CHAR(asChar(addr)));
	      if(TYPEOF(addr)!=NILSXP){
                supr_socket_conn_t *sc = socketOpen1(CHAR(asChar(addr)));
		if(sc){
		  int cmd = THREAD_SERVER_SHUTDOWN;
		  write(sc->fd, &cmd, sizeof(int)); 
		  close(sc->fd);
		  free(sc); // FIXME
		  //SET_VECTOR_ELT(servers,i, R_NilValue);
		  SETCAR(t, addr);
		}
	      }
	    }
	    t = CDR(t);
	  }
	  defineVar(install("ths"), CDR(servers), SuprContextEnv);
	} else {
	  error(_("not implemented"));
	}
	UNPROTECT(1);

        //defineVar(install("ths"), R_NilValue, SuprContextEnv);
        s = CDR(s);
        continue; 
      } else if (TYPEOF(val)==VECSXP && LENGTH(val)==0){

        // find all existing thread servers

        char path[PATH_MAX];
	sprintf(path, "%s/threadserver", Supr_usrHome);
	DIR *dir = opendir(path);
        if(!dir) {
          warning(_("opendir('%s'), %s"), path, strerror(errno));
          s = CDR(s);
          continue; 
        }

	SEXP server_list = PROTECT(CONS(R_NilValue, R_NilValue));
	SEXP server_elt = server_list;
	int nservers = 0;
	struct dirent *dp;
        while((dp = readdir(dir))){ // hostnames
	  if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0)
              continue;
	  char host_path[PATH_MAX];
	  sprintf(host_path, "%s/%s", path, dp->d_name);
	  DIR *host_dir = opendir(host_path);
          if(!host_dir) {
            warning(_("opendir('%s'), %s"), host_path, strerror(errno));
	    continue;
          }
	  struct dirent *host_dp;
          while((host_dp = readdir(host_dir))){ // hostnames
	    if(strcmp(host_dp->d_name, ".")==0 ||
			    strcmp(host_dp->d_name, "..")==0)
              continue;
	    char log_file[PATH_MAX];
	    sprintf(log_file, "%s/%s/threadserver.log", host_path,
			    host_dp->d_name);
	    FILE *file = fopen(log_file, "r");
	    if(file){
	      char buf[1024];
	      char *addr = fgets(buf, sizeof(buf), file);
	      char *pid_str = fgets(buf+strlen(addr)+1,
			      sizeof(buf)-strlen(addr), file);
	      pid_t pid = atoi(strstr(pid_str, ":")+1);
	      if(strstr(addr, "//")) addr = strstr(addr, "//")+2;
	      //fprintf(stderr, "addr: %s, pid: %d\n", addr, pid);
	      fclose(file);

	      if(strstr(addr,"\n")) *strstr(addr,"\n") = 0;
	      supr_socket_conn_t *sc = socketOpen1(addr);
	      int port = atoi(strstr(addr, ":")+1);
	      if(sc){
		SEXP ret_val = PROTECT(ThreadServer_createObjectTableEnv());
                //char addr[strlen(sc->host)+16];
	       	sc->port = port;
	       	//sprintf(addr, "%s:%d", sc->host, sc->port);
		setAttrib(ret_val, install("address"), mkString(addr)); 
		
		SEXP scPtr = PROTECT(R_MakeExternalPtr(sc, R_NilValue,
				       	R_NilValue));
	       	R_RegisterCFinalizerEx(scPtr, ThreadServer_connect_finalizer,
			       	TRUE); 
		//
		setAttrib(ret_val, install("type"), mkString("client"));
	       	setAttrib(ret_val, install("host"), mkString(sc->host));
	       	setAttrib(ret_val, install("port"), ScalarInteger(sc->port));
		//
	       	setAttrib(ret_val, install("conn"), scPtr); 

  if(Supr_namespace){
    SEXP server = ret_val;
    SEXP localEnv = Cluster_setLocalEnvToObjectTable(server, R_NilValue);
    defineVar(install(".LocalEnv"), localEnv, localEnv);

    SEXP thread_new = findVar(install("Thread.new"), Supr_namespace);

    if(TYPEOF(thread_new) == PROMSXP){
      thread_new = PROTECT(eval(thread_new, R_GlobalEnv));
    }
    else PROTECT(thread_new);

    SEXP formals = FORMALS(thread_new);
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SET_BODY(func, BODY(thread_new));
    SET_CLOENV(func, CLOENV(thread_new));
    SEXP func_formals=PROTECT(CONS(R_NilValue, R_NilValue));
    SEXP args=func_formals;

    while(TYPEOF(formals) != NILSXP){
      if(//TYPEOF(TAG(formals)) == SYMSXP &&
		      strcmp(CHAR(PRINTNAME(TAG(formals))),"server")==0){
        SETCDR(args, CONS(server, R_NilValue));
      } else {
        SETCDR(args, CONS(CAR(formals), R_NilValue));
      }
      args = CDR(args);
      SET_TAG(args, TAG(formals));

      formals = CDR(formals);
    }
    SET_FORMALS(func, CDR(func_formals));
    defineVar(install("new"), func, localEnv);
    UNPROTECT(3);
  }


	        SETCDR(server_elt, CONS(ret_val, R_NilValue));
		SET_TAG(CDR(server_elt), install(addr));
	        server_elt = CDR(server_elt);
	        nservers++;

		UNPROTECT(2);
	      } else {
	        warning(_("cannot connect to '%s'"), addr);
	      }
	    } else {
	      warning(_("cannot open '%s', %s"), log_file, strerror(errno));
	    }
	  }
        }
	//defineVar(install("ths"), CDR(server_list), SuprContextEnv);
	{
	  SEXP ths = PROTECT(allocVector(VECSXP, nservers));
	  SEXP nms = PROTECT(allocVector(STRSXP, nservers));
	  SEXP t = CDR(server_list);
	  nservers = 0;
	  while(t != R_NilValue){
	    SET_VECTOR_ELT(ths, nservers, CAR(t));
	    SET_STRING_ELT(nms, nservers, mkChar(CHAR(PRINTNAME(TAG(t)))));
	    nservers++;
	    t = CDR(t);
	  }
	  setAttrib(ths, R_NamesSymbol, nms);
	  defineVar(install("ths"), ths, SuprContextEnv);
	  UNPROTECT(2);
	}

	UNPROTECT(1);


        s = CDR(s);
        continue; 

	// TODO ...
      }

      int len = LENGTH(val);

      //basic_info("LENGTH(val): %d", len);
      //PrintValue(val);

      SEXP vec_val = PROTECT(allocVector(VECSXP, len));

      if(TYPEOF(val) == STRSXP){
        for(int i=0; i<len; i++)
	  SET_VECTOR_ELT(vec_val, i, mkString(CHAR(STRING_ELT(val, i))));
	SEXP names = getAttrib(val, R_NamesSymbol);
	if(TYPEOF(names)==STRSXP)
	  setAttrib(vec_val, R_NamesSymbol, names);
	else
	  setAttrib(vec_val, R_NamesSymbol, val);
	val = vec_val;
      }

      if(TYPEOF(val) == VECSXP){
	//SEXP names = getAttrib(val, R_NamesSymbol);
        for(int i=0; i<len; i++) {
	  SEXP addr = VECTOR_ELT(val, i);
	  SEXP server = addr;
	  if(TYPEOF(addr)==STRSXP){
	    server = PROTECT(startRemoteThreadServer(addr));
	    SET_VECTOR_ELT(val, i, server);
	    if(TYPEOF(server) == ENVSXP){
	      basic_info("[%d] %s", i+1, CHAR(asChar(getAttrib(server, install("address")))));
	    }

	    UNPROTECT(1);
	  }

	  /*
  if(Supr_namespace){
    SEXP localEnv = Cluster_setLocalEnvToObjectTable(server, R_NilValue);
    defineVar(install(".LocalEnv"), localEnv, localEnv);

    SEXP thread_new = findVar(install("Thread.new"), Supr_namespace);

    if(TYPEOF(thread_new) == PROMSXP){
      thread_new = PROTECT(eval(thread_new, R_GlobalEnv));
    }
    else PROTECT(thread_new);

    SEXP formals = FORMALS(thread_new);
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SET_BODY(func, BODY(thread_new));
    SET_CLOENV(func, CLOENV(thread_new));
    SEXP func_formals=PROTECT(CONS(R_NilValue, R_NilValue));
    SEXP args=func_formals;

    while(TYPEOF(formals) != NILSXP){
      if(//TYPEOF(TAG(formals)) == SYMSXP &&
		      strcmp(CHAR(PRINTNAME(TAG(formals))),"server")==0){
        SETCDR(args, CONS(server, R_NilValue));
      } else {
        SETCDR(args, CONS(CAR(formals), R_NilValue));
      }
      args = CDR(args);
      SET_TAG(args, TAG(formals));

      formals = CDR(formals);
    }
    SET_FORMALS(func, CDR(func_formals));
    defineVar(install("new"), func, localEnv);
    UNPROTECT(2);
  }
  */




	}
	defineVar(install("ths"), val, SuprContextEnv);
      } else {
        warning(_("invalid argument for `%s`"), name);
      }
      /*
      if(TYPEOF(val) == STRSXP){
      } else if(TYPEOF(val) == VECSXP){
	SEXP s = list_val;
	SEXP names = getAttrib(val, R_NamesSymbol);
	for(int i=0; i<LENGTH(val); i++){
          SETCDR(s, CONS(VECTOR_ELT(val, i), R_NilValue));
	  s = CDR(s);
	  if(names != R_NilValue)
	    SET_TAG(s, install(CHAR(STRING_ELT(names, i))));
	}
      }


      if(TYPEOF(val) == VECSXP){ // pairlist
      //} else if(TYPEOF(val) == STRSXP){
      //} else if(TYPEOF(val) == VECSXP){
      } else if(TYPEOF(val) == LISTSXP){ // pairlist
        val = CDR(list_val);
        SEXP s = val;
        while(TYPEOF(s) != NILSXP){
          SEXP tag = TAG(s);
	  if(TYPEOF(tag) == NILSXP){
            fprintf(stderr, "thread... typeof: %s\n", type2char(TYPEOF(s)));
	    // start and connect to ...
	    SEXP server = PROTECT(startRemoteThreadServer(CAR(s)));
	    SET_TAG(s, install(CHAR(asChar(CAR(s)))));
	    SETCAR(s, server);
	    UNPROTECT(1);
	  }
	  s = CDR(s);
	}
	defineVar(install(name), val, SuprContextEnv);
      } else {
        warning(_("invalid argument for `%s`"), name);
      }
      */
      UNPROTECT(1);
    }


    s = CDR(s);
    UNPROTECT(1);
  }

  return R_NilValue;
}

SEXP Socket_setBlockingStatus(SEXP block, SEXP connection)
{
  SEXP conn = getAttrib(connection, install("conn"));
  if(TYPEOF(conn) == NILSXP)
	  error(_("'connection' not found"));

  supr_socket_conn_t *sc = (supr_socket_conn_t *)
	  R_ExternalPtrAddr(conn);
  // Check sc->class ...
  if(!sc)
    error(_("'connection' not found, FIXME --- %s:%d"), __FILE__, __LINE__);

  int fd = sc->fd;

  int flags = fcntl(fd, F_GETFL);
  if(flags == -1) error(_("%s"), strerror(errno));
  if(TYPEOF(block) == NILSXP)
    return flags & O_NONBLOCK ? R_FalseValue : R_TrueValue;

  int bl  = asLogical(block);
  int rc;
  if(bl) {
    rc = fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
  } else {
    rc = fcntl(fd, F_SETFL, flags | O_NONBLOCK);
  }
  if(rc == -1) error(_("%s"), strerror(errno));
  flags = fcntl(fd, F_GETFL);
  if(flags == -1) error(_("%s"), strerror(errno));

  // testing
  if(flags & O_NONBLOCK){
    int test;
    //ssize_t size = read(fd, &test, sizeof(int));
    ssize_t size = recv(fd, &test, sizeof(int), MSG_PEEK);
    if(size==-1){
      fprintf(stderr, "recv: %ld, errno: %d, error: %s\n",
		     size,  errno, strerror(errno));
      if(errno == EAGAIN  || errno == EWOULDBLOCK){
        fprintf(stderr, "\tEAGAIN: %d, EWOULDBLOCK: %d\n",
			EAGAIN,  EWOULDBLOCK);
        fprintf(stderr,
"The socket is marked nonblocking and the receive operation would block ...\n"
"See man recv\n"
"\tEBADF  The argument sockfd is an invalid file descriptor.\n"
"\tEINTR  The receive was interrupted by delivery of a signal  before  any\n"
"\t\tdata were available\n"
"\tENOTSOCK The file descriptor sockfd does not refer to a socket.\n"
"\tENOTCONN The socket is associated with a connection-oriented protocol and\n"
"\t\t has not been connected\n"
"\t...\n"
);
      }
    }
  }
  return flags & O_NONBLOCK ? R_FalseValue : R_TrueValue;
}


SEXP Supr_getConnections(){

  SEXP r;
  BEGIN_R_EVAL();

    r = PROTECT(allocVector(STRSXP, vectorSize(socket_connections)));

    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
                vectorElementAt(socket_connections, i);
        char *name = "";
        if(sc->type == DFS_NAMENODE_CONN){
                name = "dfsname";
	} else if(sc->type == DFS_DATANODE_CONN){
                name = "dfsdata";
        } else if(sc->type == MASTER_CONN){
                name = "master";
        } else if(sc->type == WORKER_CONN){
                name = "worker";
        } else if(sc->type == DRIVER_CONN){
                name = "driver";
        } else if(sc->type == USER_CONN){
                name = "user";
        } else if(sc->type == TASKRUNNER_CONN){
                name = "taskrunner";
        } else if(sc->type == EXECUTOR_CONN){
                name = "executor";
        } else if(sc->type == TR_PRINT_STDOUT){
                name = "taskrunner";
        } else if(sc->type == TR_PRINT_STDERR){
                name = "taskrunner";
        } else if(sc->type == INFO_CONN){
                name = "info";
        } else {
                name = "other"; // TODO
        }


        char buf[strlen(sc->host)+64];
	if(sc->cmd){
          sprintf(buf, "%s%s://%s:%d:%d:%s", "", //conn == sc ? "*":"",
		       	name, sc->host, sc->port, sc->pid, sc->cmd);
	} else {
          sprintf(buf, "%s%s://%s:%d:%d", "", //conn == sc ? "*":"",
		       	name, sc->host, sc->port, sc->pid);
	}
        SET_STRING_ELT(r, i, mkChar(buf));

    }
    
    UNPROTECT(1);
  END_R_EVAL();

  return r;
}

SEXP (*Supr_interrupt_ptr)(SEXP what) = NULL;
SEXP Supr_interrupt(SEXP what)
{
   basic_info(__func__); // debug 
   return Supr_interrupt_ptr ?  Supr_interrupt_ptr(what) : ScalarInteger(0);
}

SEXP (*Supr_getPthreads_ptr)() = NULL;

SEXP Supr_getPthreads()
{
  SEXP r;
  BEGIN_R_EVAL();

  // return as a data.frame
    int nrow = vectorSize(threads);
    int ncol = 2; // for now
    r = PROTECT(allocVector(VECSXP, ncol));
    SEXP names = PROTECT(allocVector(STRSXP, ncol));
    SEXP row_names = PROTECT(allocVector(STRSXP, nrow));

    ncol = 0;

    SEXP tid = PROTECT(allocVector(INTSXP, nrow));
    SET_STRING_ELT(names, ncol, mkChar("tid"));
    SET_VECTOR_ELT(r, ncol++, tid);

    SEXP state = PROTECT(allocVector(STRSXP, nrow));
    SET_STRING_ELT(names, ncol, mkChar("state"));
    SET_VECTOR_ELT(r, ncol++, state);

    setAttrib(r, R_ClassSymbol, mkString("data.frame"));
    setAttrib(r, R_NamesSymbol, names);
    setAttrib(r, install("row.names"), row_names);

    for(int i=vectorSize(threads)-1; i>=0; i--){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
        const char *name = th->name;
	char tid_str[32];
	if(!name) {
	  name = tid_str;
	  sprintf(tid_str, "%d", th->tid);
	}
        SET_STRING_ELT(row_names, i, mkChar(name));
	pthread_mutex_lock(&th->mutex);
          SET_STRING_ELT(state, i, mkChar(state2char(th->state)));
	pthread_mutex_unlock(&th->mutex);
        INTEGER(tid)[i] = th->tid;
    }

    UNPROTECT(2+ncol);
  END_R_EVAL();

  //char msg[1024];
  //sprintf(msg, "Supr_getPthreads_ptr: %p", Supr_getPthreads_ptr);
  //Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);

  if(Supr_getPthreads_ptr){
    SEXP att = PROTECT(Supr_getPthreads_ptr());
    if(TYPEOF(att) == LISTSXP) {
      //setAttrib(r, TAG(att), CAR(att));
      r = PROTECT(CONS(r, R_NilValue));
      char *sys_cmd = cmd;
      while(strstr(sys_cmd, "/")) sys_cmd = strstr(sys_cmd, "/") + 1;
      SET_TAG(r, install(sys_cmd));
      SETCDR(r, att);
      UNPROTECT(1);
    }
    UNPROTECT(1);
  }

  UNPROTECT(1);
  return r;
    
}


//void handleClusterContextList(void *data, vector_t *socket_connections)
void handleClusterList(void *data, vector_t *socket_connections)
{
  int cmd;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) data;
  int fd = conn->fd;
  read(fd, &cmd, sizeof(int));

  int len;
  read(fd, &len, sizeof(int));
  char sym[len];
  read(fd, sym, len);

  //Supr_sendSimpleMessage(__func__, msg_color, 0, 0);
  //Supr_sendSimpleMessage(sym, msg_color, 0, 0);

  BEGIN_R_EVAL();

    SEXP call = PROTECT(LCONS(install("ls"),
			    CONS(SuprEnv, CONS(R_TrueValue, R_NilValue))));
    SET_TAG(CDDR(call), install("all.names"));
    SEXP r = PROTECT(eval(call, R_GlobalEnv));

    call = PROTECT(LCONS(install("serialize"),
                              CONS(r, CONS(R_NilValue, R_NilValue))));
    SEXP raw = PROTECT(eval(call, R_GlobalEnv));

    int len = LENGTH(raw);
    write(fd, &len, sizeof(int));
    write(fd, RAW(raw), len);
    UNPROTECT(4);
  END_R_EVAL();
}

void __handleClusterContextDoCall(void *data)
{
  verbose_info(__func__);
  supr_socket_conn_t *conn = (supr_socket_conn_t *) data;
  int fd = conn->fd;

      int len;
      read(fd, &len, sizeof(int));

      SEXP raw = PROTECT(allocVector(RAWSXP, len));
      read(fd, RAW(raw), len);
      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
      call = PROTECT(eval(call, R_GlobalEnv));


      SEXP r = PROTECT(eval(CAR(call), SuprEnv)); // FIXME

      call = PROTECT(LCONS(install("serialize"),
                              CONS(r, CONS(R_NilValue, R_NilValue))));
      raw = eval(call, R_GlobalEnv);

      len = LENGTH(raw);
      write(fd, &len, sizeof(int));
      write(fd, RAW(raw), len);
      UNPROTECT(5);

  //END_R_EVAL();
}
SEXP Supr_mkError(const char *str)
{
  SEXP err = PROTECT(mkString(str));
  setAttrib(err, R_ClassSymbol, mkString("SuprError"));
  UNPROTECT(1);
  return err;
}

void handleClusterContextDoCall(void *data, SEXP env)
{
  verbose_info(__func__);
  int cmd;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) data;
  int fd = conn->fd;
  read(fd, &cmd, sizeof(int));

  BEGIN_R_EVAL();
  Rboolean success = R_ToplevelExec(__handleClusterContextDoCall, data);
  if(!success){
      SEXP err = Supr_mkError(R_curErrorBuf());
      SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(err, CONS(R_NilValue, R_NilValue))));
      SEXP raw = eval(call, R_GlobalEnv);
      int len = LENGTH(raw);
      write(fd, &len, sizeof(int));
      write(fd, RAW(raw), len);
      UNPROTECT(1);
  }
  END_R_EVAL();
}

void handleClusterContextGet(void *data, vector_t *socket_connections)
{
  int cmd;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) data;
  int fd = conn->fd;
  read(fd, &cmd, sizeof(int));

  int len;
  read(fd, &len, sizeof(int));
  char sym[len];
  read(fd, sym, len);

  //Supr_sendSimpleMessage(__func__, msg_color, 0, 0);
  //Supr_sendSimpleMessage(sym, msg_color, 0, 0);

  BEGIN_R_EVAL();

      SEXP r = PROTECT(findVar(install(sym), SuprEnv));
      if(r == R_UnboundValue) r = R_NilValue;

      int nUNPROTECT = 1;

      if(TYPEOF(r) == ENVSXP){
        basic_info("tyepof(r): %s", type2char(TYPEOF(r)));
	char str_r[256];
	sprintf(str_r, "<environment: %p>", r);
	r = PROTECT(mkString(str_r));
        nUNPROTECT ++;
      } 


      SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(r, CONS(R_NilValue, R_NilValue))));
      nUNPROTECT ++;
      SEXP raw = eval(call, R_GlobalEnv);

      len = LENGTH(raw);
      write(fd, &len, sizeof(int));
      write(fd, RAW(raw), len);
      UNPROTECT(nUNPROTECT);

  END_R_EVAL();
}



void handleClusterExists(void *data, vector_t *socket_connections)
{
  int cmd;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) data;
  int fd = conn->fd;
  read(fd, &cmd, sizeof(int));

  int len;
  read(fd, &len, sizeof(int));
  char sym[len];
  read(fd, sym, len);

  //Supr_sendSimpleMessage(__func__, msg_color, 0, 0);
  //Supr_sendSimpleMessage(sym, msg_color, 0, 0);

  BEGIN_R_EVAL();
   
    SEXP v =  findVar(install(sym), SuprEnv);
    int rc = v != R_UnboundValue;
    write(fd, &rc, sizeof(int));

  END_R_EVAL();
}

void handleClusterAssign(void *data, vector_t *socket_connections)
{
  int cmd;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) data;
  int fd = conn->fd;
  read(fd, &cmd, sizeof(int));

  int len;
  read(fd, &len, sizeof(int));
  char sym[len];
  read(fd, sym, len);

  //Supr_sendSimpleMessage(__func__, msg_color, 0, 0);
  //Supr_sendSimpleMessage(sym, msg_color, 0, 0);

  BEGIN_R_EVAL();

    read(fd, &len, sizeof(int));
  
    SEXP raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);
 
    SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
    SEXP val = PROTECT(eval(call, R_GlobalEnv));

    defineVar(install(sym), val, SuprEnv);

    /*
    val = PROTECT(findVar(install(sym), SuprEnv));
    call = PROTECT(LCONS(install("serialize"), CONS(val, CONS(R_NilValue,
                        R_NilValue))));
    raw = eval(call, R_GlobalEnv);

    len = LENGTH(raw);
    write(fd, &len, sizeof(int));
    write(fd, RAW(raw), len);
    */

    UNPROTECT(3);
  END_R_EVAL();

  int rc=0;
  //read(fd, &rc, sizeof(int));
  write(fd, &rc, sizeof(int));
}



SEXP Cluster_createObjectTableEnv(SEXP rho);

// cleanup
static void Cluster_connection_finalizer(SEXP s)
{
  supr_socket_conn_t *sc = (supr_socket_conn_t *) R_ExternalPtrAddr(s);
  if(Supr_verbose)
    fprintf(stderr, "[%s:%d:%s]\n", __FILE__, __LINE__, __func__);
  close(sc->fd);
  free(sc);
}

static void Cluster_table_finalizer(SEXP s)
{
  if(Supr_verbose)
    fprintf(stderr, "[%s:%d:%s] TODO\n", __FILE__, __LINE__, __func__);
}

/*
typedef struct supr_env_data_struct {
  supr_socket_conn_t * sc;
  char *address;
} supr_env_data_t;
*/

Rboolean Cluster_exists(const char * const name, Rboolean *canCache, R_ObjectTable *tb){
  //SEXP rho = ((SEXP*) (tb + 1))[0];
  SEXP rho = (SEXP) tb->privateData;

  // use sc for efficiency later ...
  SEXP address = getAttrib(rho, install("address"));
  if(TYPEOF(address) == NILSXP) return FALSE;

  char *addr = (char*) CHAR(asChar(address));
  int pong = tryPingSocketServer1(addr);
  if(pong != CLUSTER_PONG) 
	  error(_("%s, cannot connect to %s"), __func__, addr);
	  //error(_("cannot connect to %s"), addr);

  //SEXP scPtr = getAttrib(rho, install("conn"));
  //supr_socket_conn_t *sc = (supr_socket_conn_t *)R_ExternalPtrAddr(scPtr);
  supr_socket_conn_t *sc = socketOpen1(addr);
  if(!sc) error(_("cannot connect to %s"), addr);//FIXME to improve efficiency

  int fd = sc->fd;
  int cmd = CLUSTER_CONTEXT_EXISTS;

    write(fd, &cmd, sizeof(int));

    int len;
    len=strlen(name)+1;
    write(fd, &len, sizeof(int));
    write(fd, name, len);

    int rc;
    read(fd, &rc, sizeof(int));

    close(sc->fd);
    free(sc); // destroy...
    return rc;
}
SEXP Cluster_get(const char * const name, Rboolean *canCache, R_ObjectTable *tb){

  // check local env
  SEXP local = ((SEXP*)(tb+1))[0];
  if(TYPEOF(local) == ENVSXP){
    SEXP val = findVar(install(name), local);
    if(val != R_UnboundValue)
      return val;
  }

  SEXP rho = (SEXP) tb->privateData;

  // use sc for efficiency later ...
  //if(!sc)
  //{ //return R_EmptyEnv;
    //SEXP rho = (SEXP) tb->privateData;
    // use sc for efficiency later ...
    SEXP address = getAttrib(rho, install("address"));
    if(TYPEOF(address) == NILSXP) return R_NilValue;
    

    char *addr = (char*) CHAR(asChar(address));
    int pong = tryPingSocketServer1(addr);
    if(pong != CLUSTER_PONG) 
	  //error(_("%s, cannot connect to %s"), __func__, addr);
	  error(_("cannot connect to %s"), addr);

    //SEXP scPtr = getAttrib(rho, install("conn"));
    //supr_socket_conn_t *sc = (supr_socket_conn_t *)R_ExternalPtrAddr(scPtr);
    supr_socket_conn_t *sc = socketOpen1(addr);
    if(!sc) error(_("cannot connect to %s"), addr);//FIXME to improve efficiency

    int fd = sc->fd;
    int cmd = CLUSTER_CONTEXT_GET;

    write(fd, &cmd, sizeof(int));

    int len;
    len=strlen(name)+1;
    write(fd, &len, sizeof(int));
    write(fd, name, len);

    
    read(fd, &len, sizeof(int));
    SEXP raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);

    SEXP val;
    BEGIN_R_EVAL();
      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
      val = PROTECT(eval(call, R_GlobalEnv));

        //basic_info("typeof(val): %s", type2char(TYPEOF(val)));

      if(TYPEOF(val) == CLOSXP
         || TYPEOF(val) == BUILTINSXP
         || TYPEOF(val) == SPECIALSXP
      ){ // to do...

        //basic_info("typeof(val): %s", type2char(TYPEOF(val)));

	      SEXP __val = val;
	      //PrintValue(val);
        val = findVar(install("supr.call"), Supr_namespace); 
        //basic_info("typeof(val): %s", type2char(TYPEOF(val)));
	UNPROTECT(1);
	if(TYPEOF(val) == PROMSXP)
          val = PROTECT(eval(val, R_GlobalEnv));
        else PROTECT(val);

        SEXP formals = FORMALS(val);
        SEXP func = PROTECT(allocSExp(CLOSXP));
        SET_BODY(func, BODY(val));
        SET_CLOENV(func, CLOENV(val));
        SEXP func_formals=PROTECT(CONS(R_NilValue, R_NilValue));
        SEXP args=func_formals;

        while(TYPEOF(formals) != NILSXP){
		/*
          if(strcmp(CHAR(PRINTNAME(TAG(formals))),".server")==0){
            SETCDR(args, CONS(rho, R_NilValue));
          } else { }
	  */
          SETCDR(args, CONS(CAR(formals), R_NilValue));
          args = CDR(args);
          SET_TAG(args, TAG(formals));

          formals = CDR(formals);
        }

	SETCDR(args, CONS(mkString(name), R_NilValue));
        args = CDR(args);
        SET_TAG(args, install(".name"));
        SET_FORMALS(func, CDR(func_formals));

	SETCDR(args, CONS(rho, R_NilValue));
        args = CDR(args);
        SET_TAG(args, install(".server"));
        SET_FORMALS(func, CDR(func_formals));

	{
		setAttrib(func, install("func"), __val);
	}

	UNPROTECT(2);
	val = func;

      } 
      else if (TYPEOF(val) == BUILTINSXP) { // to do
        val = findVar(install("supr.call"), Supr_namespace); 
      }
      else if (TYPEOF(val) == SPECIALSXP) { // do
        val = findVar(install("supr.call"), Supr_namespace); 
      }
      UNPROTECT(3); 
    END_R_EVAL();
    close(sc->fd);
    free(sc); // destroy...
    return val;
  //}


}

SEXP Supr_doRemoteCall(SEXP fun_name, SEXP rho, SEXP S_call)
{
  //SETCAR(S_call, install(CHAR(asChar(fun_name))));

  //fprintf(stderr, "S_call:\n"); PrintValue(S_call); fprintf(stderr, "// S_call\n");

  SETCAR(S_call, install(CHAR(asChar(fun_name))));

//  fprintf(stderr, "S_call:\n"); PrintValue(S_call); fprintf(stderr, "// S_call\n");

  SEXP address = getAttrib(rho, install("address"));
  if(TYPEOF(address) == NILSXP) return allocVector(STRSXP,0);

  char *addr = (char*) CHAR(asChar(address));
  int pong = tryPingSocketServer1(addr);
  if(pong != CLUSTER_PONG)
     error(_("cannot connect to %s"), addr);
  supr_socket_conn_t *sc = socketOpen1(addr);
  if(!sc) error(_("cannot connect to %s"), addr);

  int fd = sc->fd;
  int cmd = CLUSTER_CONTEXT_DOCALL;
  write(fd, &cmd, sizeof(int));

  SEXP val = R_NilValue;
  const char *err_str = NULL;
  BEGIN_R_EVAL();

    SEXP expr = PROTECT(CONS(S_call, R_NilValue));
  
    SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(expr, CONS(R_NilValue, R_NilValue))));
    SEXP raw = PROTECT(eval(call, R_GlobalEnv));

    int len = LENGTH(raw);
    write(fd, &len, sizeof(int));
    write(fd, RAW(raw), len);

    read(fd, &len, sizeof(int));
    raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);
    call = PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
    val = PROTECT(eval(call, R_GlobalEnv));

    SEXP err = getAttrib(val, R_ClassSymbol);
    if(TYPEOF(err) != NILSXP && strcmp(CHAR(asChar(err)), "SuprError")==0)
	    err_str = CHAR(asChar(val));

    UNPROTECT(6);

  END_R_EVAL();

  close(sc->fd);
  free(sc); // destroy...
  
  if(err_str) error(_("%s"), err_str);
  return val;
}

int Cluster_remove(const char * const name, R_ObjectTable *tb){
  // int cmd = CLUSTER_CONTEXT_REMOVE  
	error(_("not implemented"));
	return -1; // not reached
}
SEXP Cluster_objects(R_ObjectTable *tb){
  //SEXP rho = ((SEXP*) (tb + 1))[0];
  SEXP rho = (SEXP) tb->privateData;

  // use sc for efficiency later ...
  SEXP address = getAttrib(rho, install("address"));
  if(TYPEOF(address) == NILSXP) return allocVector(STRSXP,0);

  char *addr = (char*) CHAR(asChar(address));

  basic_info("addr: %s", addr);

  int pong = tryPingSocketServer1(addr);
  if(pong != CLUSTER_PONG) 
	  //error(_("%s, cannot connect to %s"), __func__, addr);
	  error(_("cannot connect to %s"), addr);

  //SEXP scPtr = getAttrib(rho, install("conn"));
  //supr_socket_conn_t *sc = (supr_socket_conn_t *)R_ExternalPtrAddr(scPtr);
  supr_socket_conn_t *sc = socketOpen1(addr);
  if(!sc) error(_("cannot connect to %s"), addr);//FIXME to improve efficiency
  // int cmd = CLUSTER_CONTEXT_PUT;
  //  int cmd = CLUSTER_STATE;
  int fd = sc->fd;
  int cmd = CLUSTER_CONTEXT_OBJECTS;

    write(fd, &cmd, sizeof(int));

    int len;
    char *name = "testing"; // delete me...
    len=strlen(name)+1;
    write(fd, &len, sizeof(int));
    write(fd, name, len);

    read(fd, &len, sizeof(int));
    SEXP raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);
    SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
    SEXP val = PROTECT(eval(call, R_GlobalEnv));

    UNPROTECT(3); 
    //close(sc->fd);
    //free(sc); // destroy...
    Supr_decref(sc);

    /*
    SEXP local = ((SEXP*)(tb+1))[0];

    if(TYPEOF(local) == ENVSXP){
	    setAttrib(val, install(".LocalEnv"), local);
    }
    */

    return val;
}
 
SEXP Cluster_assign(const char * const name, SEXP value, R_ObjectTable *tb)
{
  SEXP rho = (SEXP) tb->privateData;
  // use sc for efficiency later ...
  SEXP address = getAttrib(rho, install("address"));
  if(TYPEOF(address) == NILSXP) 
    error(_("cannot find the 'address' attribute"));

  char *addr = (char*) CHAR(asChar(address));
  int pong = tryPingSocketServer1(addr);
  if(pong != CLUSTER_PONG) 
	  error(_("cannot connect to %s"), addr);

  //SEXP scPtr = getAttrib(rho, install("conn"));
  //supr_socket_conn_t *sc = (supr_socket_conn_t *)R_ExternalPtrAddr(scPtr);
  supr_socket_conn_t *sc = socketOpen1(addr);
  if(!sc) error(_("cannot connect to %s"), addr);//FIXME to improve efficiency
  // int cmd = CLUSTER_CONTEXT_PUT;
  //  int cmd = CLUSTER_STATE;
  int fd = sc->fd;
  int cmd = CLUSTER_CONTEXT_PUT;

    write(fd, &cmd, sizeof(int));

    int len;
    len=strlen(name)+1;
    write(fd, &len, sizeof(int));
    write(fd, name, len);

  BEGIN_R_EVAL();
    
    // use shm instead?

    SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(value, CONS(R_NilValue, R_NilValue))));
    SEXP raw = PROTECT(eval(call, R_GlobalEnv));
    int len = LENGTH(raw);
    write(fd, &len, sizeof(int));
    write(fd, RAW(raw), len);

    /*
    read(fd, &len, sizeof(int));
    raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);
    call = PROTECT(LCONS(install("unserialize"), CONS(raw, R_NilValue)));
    value = eval(call, R_GlobalEnv);
    */

    int rc = 0;
    //write(fd, &rc, sizeof(int));
    read(fd, &rc, sizeof(int));
    UNPROTECT(2);
   
  END_R_EVAL();
    close(sc->fd);
    free(sc); // destroy...
  
  return value; // FIXME for active bindings ...
}
Rboolean Cluster_canCache(const char * const name, R_ObjectTable *tb){
  fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__,
        name);
  return FALSE;
}
void  Cluster_onDetach(R_ObjectTable *tb) {
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}
void Cluster_onAttach(R_ObjectTable *tb) {
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}

/*
typedef Supr_ObjectTable_struct {
	R_ObjectTable *table;
	SEXP local; // local env; or more general SEXP * vars ... ?
} Supr_ObjectTable;
*/

SEXP Cluster_setLocalEnvToObjectTable(SEXP rho, SEXP localEnv){
  if(TYPEOF(localEnv) == ENVSXP){
    PROTECT(localEnv);
  } else if(TYPEOF(localEnv) == NILSXP){
    localEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
			    ScalarInteger(DEFAULT_HASH_SIZE)));
  } else {
    error(_("invalid argument type 'localEnv'"));
  }

  SEXP tbPtr = HASHTAB(rho);
  R_ObjectTable *table = (R_ObjectTable *) R_ExternalPtrAddr(tbPtr);
  ((SEXP*)(table + 1))[0] = localEnv;
  // to protect
  setAttrib(rho, install("localEnv"), localEnv); 
  UNPROTECT(1);
  return localEnv;
}

SEXP Cluster_createObjectTableEnv(SEXP rho)
{
  R_ObjectTable *table = malloc(sizeof(R_ObjectTable) + sizeof(SEXP));
  table->type = NA_INTEGER; // TODO
  table->cachedNames = NULL;
  table->active = TRUE;

  table->exists = Cluster_exists;
  table->get    = Cluster_get;
  table->remove = Cluster_remove;
  table->assign = Cluster_assign;
  table->objects= Cluster_objects;
  table->canCache = Cluster_canCache;

  table->onDetach = Cluster_onDetach;
  table->onAttach = Cluster_onAttach;


  //SEXP udb = PROTECT(R_MakeExternalPtr(table, R_NilValue, R_NilValue));

  if(TYPEOF(rho) != ENVSXP){
    rho = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(rho, R_EmptyEnv);
  } else {
    PROTECT(rho);
  }
  SEXP tbPtr = PROTECT(R_MakeExternalPtr(table, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(tbPtr, Cluster_table_finalizer, TRUE);
  SET_HASHTAB(rho, tbPtr);

  OBJECT(rho) = TRUE;

  //setAttrib(rho, R_ClassSymbol, mkString("UserDefinedDatabase"));
  SEXP klass = PROTECT(allocVector(STRSXP, 2));
  SET_STRING_ELT(klass, 0, mkChar("UserDefinedDatabase"));
  SET_STRING_ELT(klass, 1, mkChar("ClusterContext"));
  setAttrib(rho, R_ClassSymbol, klass);

  UNPROTECT(3);

  //((SEXP*)(table + 1))[0] = rho; // delete me?
  ((SEXP*)(table + 1))[0] = R_NilValue;
  
  //table->privateData = NULL;
  table->privateData = rho;

  return rho;
}

#define CHECK_AVAILABLE() do 	{\
} while(0)

// don't do connection
SEXP Supr_master_address()
{
  SEXP master = findVar(install("master"), SuprContextEnv);
//  if(master == R_UnboundValue)
//	  error(_("'master' not found"));
  if(TYPEOF(master) == ENVSXP){
    SEXP addr = getAttrib(master, install("address"));
    if(TYPEOF(addr) == STRSXP) return addr;
  }

  SEXP driver = findVar(install("driver"), SuprContextEnv);
  if(TYPEOF(driver) == ENVSXP) {
    SEXP connPtr = getAttrib(driver, install("conn"));
    if(connPtr!=NULL){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
              R_ExternalPtrAddr(connPtr);
      int cmd = DFS_MASTER_ADDR;
      write(sc->fd, &cmd, sizeof(int));
      int len;
      ssize_t size = timed_read(sc->fd, &len, sizeof(int));
      if(size == -1) error(_("timed_read: %s"), strerror(errno));
      if(len>0){
        char addr[len];
        ssize_t size = timed_read(sc->fd, addr, len);
        if(size == -1) error(_("timed_read: %s"), strerror(errno));
        verbose_info("Found master addr (from driver): %s", addr);
        return mkString(addr);
      }
    }
  }

  SEXP name = findVar(install("master"), SuprContextEnv);
  if(TYPEOF(name) == STRSXP){
    const char *addr = CHAR(STRING_ELT(name, 0));
    if(!strstr(addr, "+"))
       return mkString(strstr(addr, "//")?  strstr(addr, "//") + 2 : addr);
  }

  error(_("cannot find master address"));
  return R_NilValue; // not reached
}



// from master
SEXP Supr_worker_address(SEXP S_which)
{
  supr_socket_conn_t *sc = NULL;

  SEXP master = findVar(install("master"), SuprContextEnv);
  //if(master == R_UnboundValue) error(_("'master' not found"));

  if(TYPEOF(master) == ENVSXP){
    SEXP connPtr = getAttrib(master, install("conn"));
    if(connPtr!=NULL){
      sc = (supr_socket_conn_t *) R_ExternalPtrAddr(connPtr);
      Supr_incref(sc);
    }
  }
 
  if(!sc) {
    SEXP master_addr =  Supr_master_address();
    if(TYPEOF(master_addr) == STRSXP){
      const char *addr = CHAR(asChar(master_addr));
      sc = socketOpen1(addr);
    }
  }

  if(!sc) error(_("cannot connect to master"));


	/*
  if(TYPEOF(master) == EXTPTRSXP) {
    sc = (supr_socket_conn_t *) R_ExternalPtrAddr(master);
    Supr_incref(sc);
  } else if(TYPEOF(master) == STRSXP){ // update if necessary ?
    const char *addr = CHAR(asChar(master));
    sc = socketOpen1(addr);
    if(!sc)
      error(_("cannot connect to '%s' not found"), addr);
  }
  */

  int cmd_args[] = {CLUSTER_GET_WORKER_ADDR, asInteger(S_which)};
  int fd = sc->fd;
  write(fd, cmd_args, sizeof(cmd_args));
  int rc;
  read(fd, &rc, sizeof(int)); 
  if(rc==-1) {
    size_t len;
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    error_info(err);
    Supr_decref(sc);
    errorcall(R_NilValue, "%s", err);
  }

  int len = rc; //read(fd, &len, sizeof(int)); 
  char addr[len];
  read(fd, addr, len);
  Supr_decref(sc);

  char *s = strstr(addr, ";\n");
  if(s){
    len = 0;
    while(s){
      len++;
      s = strstr(s+2, ";\n");
    }
    SEXP ret_val =PROTECT(allocVector(STRSXP, len));
    len = 0;
    char *t = addr;
    s = strstr(t, ";\n");
    while(s){
      *s = '\0';
      SET_STRING_ELT(ret_val, len++, mkChar(t));
      t = s+2;
      s = strstr(t, ";\n");
    }
    UNPROTECT(1);
    return ret_val;
  } else
    return mkString(addr);
}

// don't do connection
SEXP Supr_namenode_address()
{
  if(DFS_namenode) {
    char addr[strlen(DFS_namenode->host)+64];
    sprintf(addr, "%s:%d", DFS_namenode->host, DFS_namenode->port);
    return mkString(addr);
  }

  SEXP driver = findVar(install("driver"), SuprContextEnv);
  if(TYPEOF(driver) == ENVSXP) {
    SEXP connPtr = getAttrib(driver, install("conn"));
    if(connPtr!=NULL){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	      R_ExternalPtrAddr(connPtr);
      int cmd = DFS_NAMENODE_ADDR;
      write(sc->fd, &cmd, sizeof(int));
      int len;
      ssize_t size = timed_read(sc->fd, &len, sizeof(int));
      if(size == -1) error(_("timed_read: %s"), strerror(errno));
      if(len>0){
        char addr[len];
        ssize_t size = timed_read(sc->fd, addr, len);
        if(size == -1) error(_("timed_read: %s"), strerror(errno));
	verbose_info("Found namenade addr (from driver): %s", addr);
        return mkString(addr);
      }
    }
  }

  SEXP dfsname = findVar(install("dfs"), SuprContextEnv);
  if(TYPEOF(dfsname) == STRSXP){
    const char *addr = CHAR(STRING_ELT(dfsname, 0));
    if(!strstr(addr, "+")) 
       return mkString(strstr(addr, "//")?  strstr(addr, "//") + 2 : addr);
  }

  error(_("cannot find DFS namenode address"));
  return R_NilValue; // not reached
}

// do connection
SEXP Supr_datanode_address(SEXP S_which)
{
  if(!DFS_namenode) {

    //SEXP dfsname = findVar(install("dfs"), SuprContextEnv);
    //if(dfsname == R_UnboundValue) error(_("(namenode) 'dfs' not found"));
    SEXP dfsname = Supr_namenode_address();
    if(dfsname == R_NilValue)
	  error(_("(namenode) 'dfs' not found"));

    if(TYPEOF(dfsname) == STRSXP){
      SEXP args = PROTECT(LCONS(install("list"), CONS(dfsname, R_NilValue)));
      SET_TAG(CDR(args), install("dfs"));
      Supr_cntxt(args, SuprEnv);
      UNPROTECT(1);

      if(!DFS_namenode) {
	const char *addr = CHAR(asChar(dfsname));
	char _addr[strlen(addr)+1];
	strcpy(_addr, addr);
	error(_("cannot connect to '%s'"), _addr);
      }
    } else {
      return dfsname;
    }
  }

  int cmd_args[] = {CLUSTER_GET_DATANODE_ADDR, asInteger(S_which)};
  int fd = DFS_namenode->fd;
  write(fd, cmd_args, sizeof(cmd_args));
  int rc;
  read(fd, &rc, sizeof(int)); 
  if(rc==-1) {
    size_t len;
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    error_info(err);
    errorcall(R_NilValue, "%s", err);
  }

  int len = rc; //read(fd, &len, sizeof(int)); 
  char addr[len];
  read(fd, addr, len);
  //Supr_decref(sc);

  char *s = strstr(addr, ";\n");
  if(s){
    len = 0;
    while(s){
      len++;
      s = strstr(s+2, ";\n");
    }
    SEXP ret_val =PROTECT(allocVector(STRSXP, len));
    len = 0;
    char *t = addr;
    s = strstr(t, ";\n");
    while(s){
      *s = '\0';
      SET_STRING_ELT(ret_val, len++, mkChar(t));
      t = s+2;
      s = strstr(t, ";\n");
    }
    UNPROTECT(1);
    return ret_val;
  } else
    return mkString(addr);
}

SEXP Supr_connectionAsEnv(SEXP conn){

  const char *addr = NULL;
  if(TYPEOF(conn) == STRSXP && LENGTH(conn) > 0){
    addr = CHAR(STRING_ELT(conn,0));
  } else if(TYPEOF(conn) == ENVSXP){
    conn = getAttrib(conn, install("address"));
    if(TYPEOF(conn) == STRSXP && LENGTH(conn) > 0)
      addr = CHAR(STRING_ELT(conn,0));
  }

  SEXP rho;
  if(addr) {
    rho = PROTECT(Cluster_createObjectTableEnv(R_NilValue));
    setAttrib(rho, install("address"), mkString(addr));
    SEXP klass = PROTECT(allocVector(STRSXP, 2));
    SET_STRING_ELT(klass, 0, mkChar("UserDefinedDatabase"));
    SET_STRING_ELT(klass, 1, mkChar("ConnectionEnv"));
    setAttrib(rho, R_ClassSymbol, klass);
    UNPROTECT(1); // klass
  } else {
    error(_("invalid argument"));
  }
  UNPROTECT(1); // rho
  return rho;
}

// Call("DFS_DDEnv", as.character(name), addr, "DDEnv")
SEXP DFS_DDEnv(SEXP name, SEXP addr){

  if(!DFS_namenode){
    supr_socket_conn_t *sc;
    if(TYPEOF(addr) == STRSXP)
      sc = socketOpen1(CHAR(asChar(addr)));
    else if (TYPEOF(addr) == ENVSXP){
      sc = NULL;
      SEXP cl = getAttrib(addr, R_ClassSymbol);
      if(TYPEOF(cl)!=NILSXP && strcmp(CHAR(STRING_ELT(cl,0)), "DDEnv")==0) {
        R_ObjectTable *tb = (R_ObjectTable *) R_ExternalPtrAddr(HASHTAB(addr));
        dfs_env_data_t *data = (dfs_env_data_t *) tb->privateData;
        sc =  *data->sc_addr;
      }
    }

    DFS_namenode = sc;
  }
  SEXP rho = PROTECT(DFS_createObjectTableEnv(&DFS_namenode,
			  CHAR(asChar(name))));
  //SEXP klass = PROTECT(allocVector(STRSXP, 3));
  //SET_STRING_ELT(klass, 0, STRING_ELT(cl,0));
  //SET_STRING_ELT(klass, 1, mkChar("UserDefinedDatabase"));
  //SET_STRING_ELT(klass, 2, mkChar("ConnectionEnv"));
  //setAttrib(rho, R_ClassSymbol, klass);
  setAttrib(rho, install("name"), name);
  UNPROTECT(1);
  return rho;
}



//// JobEnv, used by taskrunners...
//SEXP SuprShared_put(SEXP x, SEXP name, SEXP value);
//SEXP SuprShared_get(SEXP x, SEXP name);
typedef struct task_info_struct {
  SEXP LocalEnv;
  int job; // job_id;
  int task; // task_id;
  char *address;
  // more ...
} task_info_t;

SEXP TR_get_par(SEXP name, SEXP rjob_id);
SEXP TR_put_par(SEXP name, SEXP value, SEXP rjob_id);
Rboolean TR_exist_par(SEXP name, SEXP rjob_id);
int TR_remove_par(SEXP name, SEXP rjob_id);
SEXP TR_objects_par(SEXP rjob_id);

Rboolean JobEnv_exists(const char * const name, Rboolean *canCache, R_ObjectTable *tb)
{ //SEXP rho = (SEXP) tb->privateData;
  task_info_t *task_info = (task_info_t *) (tb+1);
  if(strcmp(name,"job")==0)
    return TRUE;
  else if(strcmp(name,"task")==0)
    return TRUE;
  else if(strcmp(name,"address")==0)
    return task_info->address != NULL;
  else if(strcmp(name,"firstSubset")==0){
    SEXP val = findVar(install("firstSubset"), task_info->LocalEnv);
    return val != R_UnboundValue;
  }
  else if(strcmp(name, ".__NAMESPACE__.")==0){
     return FALSE;
  }

  return TR_exist_par(mkString(name), ScalarInteger(task_info->job));
}

SEXP JobEnv_get(const char * const name, Rboolean *canCache, R_ObjectTable *tb)
{
  task_info_t *task_info = (task_info_t *) (tb+1);
  if(strcmp(name,"job")==0)
    return ScalarInteger(task_info->job);
  else if(strcmp(name,"task")==0)
    return ScalarInteger(task_info->task);
  else if(strcmp(name,"address")==0)
    return task_info->address ? mkString(task_info->address) : R_NilValue;
  else if(strcmp(name,"firstSubset")==0){
    SEXP val = findVar(install("firstSubset"), task_info->LocalEnv);
    if(val == R_UnboundValue) 
	    error(_("object '%s' not found"), name);
    return val;
  }
  else if(strcmp(name, ".__NAMESPACE__.")==0){
	  return R_UnboundValue;
  } else if(strcmp(name, ".")==0){
	  return R_UnboundValue;
  }

  return TR_get_par(mkString(name), ScalarInteger(task_info->job));
}

extern void removeVar(SEXP symbol, SEXP rho);

int JobEnv_remove(const char * const name, R_ObjectTable *tb){
  //SEXP rho = (SEXP) tb->privateData;
  task_info_t *task_info = (task_info_t *) (tb+1);
  
  if(strcmp(name,"job")==0)
    return 0;
  else if(strcmp(name,"task")==0)
    return 0;
  else if(strcmp(name,"address")==0)
    return 0;
  else if(strcmp(name,"firstSubset")==0){
    removeVar(install("firstSubset"), task_info->LocalEnv);
    return 1;
  }
  else if(strcmp(name, ".__NAMESPACE__.")==0){
	  return 0;
  } else if(strcmp(name, ".")==0){
	  return 0;
  } // FIXME

  return TR_remove_par(mkString(name), ScalarInteger(task_info->job));

}

SEXP JobEnv_objects(R_ObjectTable *tb)
{
  //SEXP rho = (SEXP) tb->privateData;
  task_info_t *task_info = (task_info_t *) (tb+1);
  //error(_("not implemented"));

  //if(task_info->job < 0){ // for now...
  //  return TR_get_par(mkString("."), ScalarInteger(task_info->job));
  //}

  //warning(_("Not implemented"));
  return TR_objects_par(ScalarInteger(task_info->job));
  //return allocVector(STRSXP, 0); //R_NilValue; // not reached
}

SEXP JobEnv_assign(const char * const name, SEXP value, R_ObjectTable *tb)
{
  //SEXP rho = (SEXP) tb->privateData;
  task_info_t *task_info = (task_info_t *) (tb+1);
  if(strcmp(name,"job")==0){
    task_info->job = asInteger(value);
    return value;
  } else if(strcmp(name,"task")==0){
    task_info->task = asInteger(value);
    return value;
  } else if(strcmp(name,"address")==0){
    if(task_info->address)
	    free(task_info->address);
    task_info->address = strdup(CHAR(asChar(value)));
    return value;
  } else if(strcmp(name,"firstSubset")==0){
    defineVar(install("firstSubset"), value, task_info->LocalEnv);
    return value;
  //} else if(strcmp(name,".")==0){ error(_("symbol '.' is reserved")); // remove the restriction later...
  }

  return TR_put_par(mkString(name), value, ScalarInteger(task_info->job));
}

Rboolean JobEnv_canCache(const char * const name, R_ObjectTable *tb){
  fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__,
        name);
  return FALSE;
}
void  JobEnv_onDetach(R_ObjectTable *tb) {
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}
void JobEnv_onAttach(R_ObjectTable *tb) {
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}


SEXP JobEnv_createObjectTableEnv(SEXP rho)
{
  R_ObjectTable *table = malloc(sizeof(R_ObjectTable) + sizeof(task_info_t));
  table->type = NA_INTEGER; // TODO // JOB_ENV_TYPE ?
  table->cachedNames = NULL;
  table->active = TRUE;

  table->exists = JobEnv_exists;
  table->get    = JobEnv_get;
  table->remove = JobEnv_remove;
  table->assign = JobEnv_assign;
  table->objects= JobEnv_objects;

  table->canCache = JobEnv_canCache;
  table->onDetach = JobEnv_onDetach;
  table->onAttach = JobEnv_onAttach;

  if(TYPEOF(rho) != ENVSXP){
    rho = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(rho, R_EmptyEnv);
  } else {
    PROTECT(rho);
  }
  SEXP tbPtr = PROTECT(R_MakeExternalPtr(table, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(tbPtr, Cluster_table_finalizer, TRUE);
  SET_HASHTAB(rho, tbPtr);

  OBJECT(rho) = TRUE;

  //setAttrib(rho, R_ClassSymbol, mkString("UserDefinedDatabase"));
  SEXP klass = PROTECT(allocVector(STRSXP, 2));
  SET_STRING_ELT(klass, 0, mkChar("UserDefinedDatabase"));
  SET_STRING_ELT(klass, 1, mkChar("JobEnv"));
  setAttrib(rho, R_ClassSymbol, klass);

  UNPROTECT(3);

  //((SEXP*)(table + 1))[0] = R_NilValue; // reserved for .LocalEnv 
  task_info_t *task_info = (task_info_t *) (table+1);
  task_info->LocalEnv = R_NilValue;
  task_info->job  = NA_INTEGER;
  task_info->task = NA_INTEGER;
  task_info->address = NULL;

  //table->privateData = NULL;
  table->privateData = rho;

  //{
    SEXP localEnv = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(localEnv, R_EmptyEnv);
    setAttrib(rho, install("localEnv"), localEnv);
    UNPROTECT(1);
    task_info->LocalEnv = localEnv;
  //}

  return rho;
}


//// JobEnv

int Config_getPort(const char *name);

SEXP Cluster_debug(SEXP address){

  int pong = tryPingSocketServer1(CHAR(asChar(address)));
  fprintf(stderr, "pong: %d\n", pong);
  if(pong != CLUSTER_PONG)
	  error(_("cannot connect to %s"), CHAR(asChar(address)));

  supr_socket_conn_t *sc = socketOpen1(CHAR(asChar(address)));
  if(!sc) error(_("cannot connect to %s"), CHAR(asChar(address)));
  // finalizer ...

  int cmd = 0; // TODO
  int fd = sc->fd;
  write(fd, &cmd, sizeof(int));
  int rc;
  read(fd, &rc, sizeof(int));
  sleep(2);
  // TODO...
  close(fd);
  free(sc);
  return ScalarInteger(rc); 
}

supr_socket_conn_t *Cluster_startDriverBackend(const char *addr, int port,
		SEXP S_master, SEXP S_dfs,
		SEXP S_verbose, SEXP S_debug, SEXP S_info,
	       	supr_socket_conn_t *info_sc,
		shm_io_info_t **shm_io_info);

// Use infoConn
// Use the current session for the driver!
SEXP Cluster_startDriver(SEXP S_addr, SEXP S_port, SEXP S_master, SEXP S_dfs,
		SEXP S_verbose, SEXP S_debug, SEXP S_info)
{

  if(!Supr_infoServer){
      Supr_infoServer = PROTECT(DD_enableInfo(0));
      defineVar(install("infoServer"), Supr_infoServer, SuprEnv);
      UNPROTECT(1);
  }

  int driver_port;
  if(TYPEOF(S_port) == NILSXP) {
    driver_port = Config_getPort("Driver");
  } else {
    driver_port = INTEGER(S_port)[0];
  }

  shm_io_info_t *shm_io_info;
  supr_socket_conn_t *sc = Cluster_startDriverBackend(
		  CHAR(asChar(S_addr)),
		  driver_port,
		  S_master, S_dfs,
		  S_verbose, S_debug, S_info,
	      (supr_socket_conn_t *) R_ExternalPtrAddr(Supr_infoServer),
	      &shm_io_info);

                if(sc)
		{ // testing: login
		  int rc = Supr_checkLogin(sc->fd, sc, "driver");
		  if(rc != 0){
		    error_info("%s:%d. FIXME: Supr_checkLogin(sc-fd, sc)",
				    __func__, __LINE__);
		  }
		} else {
		  error(_("cannot start driver: %s"), CHAR(asChar(S_addr)));
		}
	
  SEXP ret_val = PROTECT(Cluster_createObjectTableEnv(R_NilValue));
  int nUNPROTECT = 1;
  char addr[strlen(sc->host)+16];//sprintf(addr, "%s:%d", sc->host, sc->port);
    //sc->port = port;
  sprintf(addr, "%s:%d", sc->host, sc->port);
  setAttrib(ret_val, install("address"), mkString(addr));

  SEXP scPtr = PROTECT(R_MakeExternalPtr(sc, R_NilValue, R_NilValue));
  nUNPROTECT ++;
  R_RegisterCFinalizerEx(scPtr, Cluster_connection_finalizer, TRUE);
  setAttrib(ret_val, install("conn"), scPtr);

  driver_shm_io = shm_io_info;
  SEXP shmPtr = PROTECT(R_MakeExternalPtr(shm_io_info, R_NilValue, R_NilValue));
  nUNPROTECT ++;
  R_RegisterCFinalizerEx(shmPtr, Shm_io_info_finalizer, TRUE);
  setAttrib(ret_val, install("shmio"), shmPtr);


	  /*
  if(Supr_namespace){ 
    SEXP localEnv = Cluster_setLocalEnvToObjectTable(ret_val, R_NilValue);
    defineVar(install(".LocalEnv"), localEnv, localEnv);

    SEXP cluster_eval = findVar(install("cluster.eval"), Supr_namespace);
    defineVar(install("eval"), cluster_eval, localEnv);

    SEXP cluster_get = findVar(install("cluster.get"), Supr_namespace);
    defineVar(install("get"), cluster_get, localEnv);

  }
*/
  Supr_addLocalFunctions(ret_val, "driver.localfuns", "driver");

  UNPROTECT(nUNPROTECT);

  defineVar(install("cluster"), ret_val, SuprEnv);
  return ret_val;
}

supr_socket_conn_t *Cluster_startDriverBackend(
		const char *addr, int port, SEXP S_master,
	       	SEXP S_dfs, SEXP S_verbose, SEXP S_debug, SEXP S_info,
	       	supr_socket_conn_t *info_sc, shm_io_info_t **shm_io_info)
{
   char _shm_io_name[128];
   //sprintf(_shm_io_name, "supr-driver.%d.%d", geteuid(), getpid()); // FIXME
   sprintf(_shm_io_name, "%s-%d-user-%d", shm_prefix, getpid(), __LINE__);

   const char *shm_io_name = _shm_io_name;
  //{
    size_t block_size = 8*sysconf(_SC_PAGE_SIZE); // FIXME
    shm_io_info_t *shm_io = shm_io_create(shm_io_name, block_size);
    *shm_io_info = shm_io;

    /*
    {
      sem_t *sem = &shm_io->in->sem_wait; 
      int val;
      sem_getvalue(sem, &val);
      fprintf(stderr, "shm_io->in->sem_wait: val=%d\n", val);
    }
    */
  //}

  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));


  if(pid) {

      supr_socket_conn_t *conn = NULL;
      pthread_mutex_lock(&Supr_syncMutex); // fixme ... 

        double timeout = Supr_options.timeout * 2; // FIXME, max(TIME_WAIT)=?
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

        Supr_syncObject = &Supr_syncCond; // FIXME
	int rc = pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);
	if(rc != 0) {
          if(rc == ETIMEDOUT)
	    fprintf(stderr, "%s: rc=%d, ETIMEDOUT=%d\n",__func__,rc,ETIMEDOUT);
	}

      pthread_mutex_unlock(&Supr_syncMutex);

      if(rc == ETIMEDOUT){
        error_info("timeout (%s sec.)", Supr_options.timeout * 2);
      } 
      else {

        {
          clock_gettime(CLOCK_REALTIME, &wait);
          save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
          basic_info("\033[0;32m%s driver (in %g sec.)\n\033[0m",
                -save_time >= Supr_options.timeout ?
		"\033[0;31mFailed to start\033[0m":"Started", -save_time);
        }

      
        if(Supr_syncObject && Supr_syncObject != &Supr_syncCond){
	  char *host = (char*) Supr_syncObject;
          //fprintf(stderr, "Drive->server: %s\n", host);
	  char *s = strstr(host, ":");
	  if(s){
	    *s = 0; s++;
	    int port = atoi(s);
	    conn = socketOpen2(host, port); // USER_REGISTER
	    if(conn) conn->port = port;
	    driver_sc = conn;

	    SEXP infoServer = findVar(install("info"), SuprContextEnv);
	    // info port
	    port = -1;
	    if(TYPEOF(infoServer) == EXTPTRSXP){
	      supr_socket_conn_t *sc = (supr_socket_conn_t *)
		  R_ExternalPtrAddr(infoServer);
	      port = sc->port;
	    }
	    //int msg[] = {USER_REGISTER, getpid(), conn->port};
	    if(conn){
	      int msg[] = {USER_REGISTER, getpid(), port};
	      write(conn->fd, msg, sizeof(msg));
	    }
	  } 
        }


        {
          int rc; // = sem_wait(&shm_io->in->sem_wait);
	  struct timespec ts;
          if (clock_gettime(CLOCK_REALTIME, &ts) == -1)
          {
            printf("[%s] Error: clock_gettime, %s", __func__, strerror(errno));
          }
          ts.tv_sec += (long) Supr_options.timeout;

          rc = sem_timedwait(&shm_io->in->sem_wait, &ts);
          if(rc && Supr_verbose){
            fprintf(stderr, "rc: %d, err: %s\n", rc, strerror(errno));
          }
        }

        //conn->att = shm_io;
        {
          size_t size;
          //void *ptr = shm_io_read(shm_io, shm_io->in, &size, NULL);
          pid_t *driver_pid  = (pid_t *) shm_io_read(shm_io, shm_io->in,
		       	&size, NULL);
          if(Supr_verbose)
            fprintf(stderr, "\033[0;32mdriver_pid: %d\n", *driver_pid);
        }
      }

      int status;
      rc = waitpid(pid, &status, 0);

      if(!conn) error(_("cannot connect to the driver"));
      
      return conn;
  }

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid) {
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    //fprintf(stderr, "\033[0;31mC: %d, (%s:%d) waitpid(%d, ...), rc: %d, err: %s\033[0m\n", getpid(), __FILE__, __LINE__, pid, rc, strerror(errno));
    exit(EXIT_SUCCESS);
  }

  const char *master   = "";
  const char *dfs_name = "";
  if(TYPEOF(S_master) == STRSXP && LENGTH(S_master)>0)
	  master = CHAR(STRING_ELT(S_master,0));
  else if(TYPEOF(S_master) == ENVSXP){
    SEXP a = getAttrib(S_master, install("address"));
    if(TYPEOF(a) == STRSXP && LENGTH(a)>0)
      master = CHAR(STRING_ELT(a,0));
  }

  if(TYPEOF(S_dfs) == STRSXP && LENGTH(S_dfs)>0)
	  dfs_name = CHAR(STRING_ELT(S_dfs,0));
  else if(TYPEOF(S_dfs) == ENVSXP){
    SEXP a = getAttrib(S_dfs, install("address"));
    if(TYPEOF(a) == STRSXP && LENGTH(a)>0)
	    dfs_name = CHAR(STRING_ELT(a,0));
  }

  char path[strlen(Supr_sysHome) + strlen("/bin/driver")+2];
  sprintf(path, "%s/bin/driver",  Supr_sysHome);
  char port_str[32];
  sprintf(port_str, "%d", port);
  char info_addr[strlen(info_sc->host) + 32];
  sprintf(info_addr, "%s:%d", info_sc->host, info_sc->port);

  int verbose = Supr_verbose;
  int debug = Supr_debug;
  int infov = Supr_infov;
  if(TYPEOF(S_verbose) != NILSXP) verbose = LOGICAL(S_verbose)[0];
  if(TYPEOF(S_debug) != NILSXP)   debug = LOGICAL(S_debug)[0];
  if(TYPEOF(S_info) != NILSXP)   infov = LOGICAL(S_info)[0];

  char strlevel[64];
  sprintf(strlevel, "%d", Supr_options.level);
//  char X11_str[64];
//  sprintf(X11_str, "%s", Supr_options.xterm? "-Y":"");

  int rc = execl(path, path, "-port", // port_str,
		  strstr(addr, ":") ?  (strstr(addr, ":") +1):"0",
                 //"-usr", Supr_usrHome, "-sys", Supr_sysHome, // FIXME
                 //"-dfs", Supr_dfsHome,
		 "-shm", shm_io_name,
		 "-info",   info_addr,
		 "-notify", info_addr, 
		 "-master", master, "-dfs", dfs_name,
		 verbose ?  "--verbose" : "",
		 debug ?  "--debug" : "",
		 infov ?  "--info" : "",
		 "-level", strlevel,
		 "-X11", Supr_options.xterm? "-Y":"_",
                 (char *) NULL);


  return NULL; // not reached
}

SEXP Cluster_stopDriver(SEXP S_all)
{
  if(!driver_sc){
    SEXP cluster = findVar(install("cluster"), SuprEnv);
    if(cluster == R_UnboundValue){ // more checking?
      error(_("cannot find cluster"));
    }
    SEXP scPtr = getAttrib(cluster, install("conn"));
    driver_sc = R_ExternalPtrAddr(scPtr);
  }
  if(!driver_sc) error(_("cannot find cluster"));

  int cmd = CLUSTER_SHUTDOWN;
  write(driver_sc->fd, &cmd, sizeof(int));
  int all = asLogical(S_all);
  write(driver_sc->fd, &all, sizeof(int));

  int rc;
  read(driver_sc->fd, &rc, sizeof(int));

  defineVar(install("cluster"), R_UnboundValue,  SuprEnv);
  close(driver_sc->fd);
  //free(Cluster_driver); 
  driver_sc = NULL;
  return ScalarInteger(rc);
}

SEXP Cluster_state(SEXP which)
{
  if(!driver_sc){
    SEXP cluster = findVar(install("cluster"), SuprEnv);
    if(cluster == R_UnboundValue){ // more checking?
      error(_("cannot find cluster"));
    }
    SEXP scPtr = getAttrib(cluster, install("conn"));
    driver_sc = R_ExternalPtrAddr(scPtr);
  }
  if(!driver_sc) error(_("cannot find cluster"));

  int fd = driver_sc->fd;

  SEXP ret_val = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP s = ret_val;
  which = CDR(which);
  while(TYPEOF(which) != NILSXP){
    //const char *name = CHAR(PRINTNAME(TAG(which)));
    const char *name = CHAR(PRINTNAME(CAR(which)));
    fprintf(stderr, "name: %s, typeof(which): %s\n", name, type2char(TYPEOF(which)));
    {
      struct timeval tv;
      fd_set readfds, writefds;

      tv.tv_sec=5;
      tv.tv_usec=50000;

      FD_ZERO(&writefds);
      FD_SET(fd, &writefds);

      int ns = select(fd+1, NULL, &writefds, NULL, &tv);
      if(ns <= 0) error(_("cannot write cluster"));
    }
    int cmd = CLUSTER_STATE;
    write(fd, &cmd, sizeof(int));

    int len;
    len=strlen(name)+1;
    write(fd, &len, sizeof(int));
    write(fd, name, len);

    read(fd, &len, sizeof(int));
    SEXP raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);
    SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
    SEXP val = PROTECT(eval(call, R_GlobalEnv));
    //PrintValue(val);

    SETCDR(s, CONS(val, R_NilValue));
    s = CDR(s);
    SET_TAG(s, install(name));

    UNPROTECT(3);

    which = CDR(which);
  }

  UNPROTECT(1);
  return CDR(ret_val);
}


SEXP startRemoteThreadServer(SEXP S_addr){
  char msg[1024];

  const char *addr = TYPEOF(S_addr) == NILSXP ? NULL:CHAR(asChar(S_addr));
  char *host = NULL;
  char *port_str = NULL;
  int port = -1;
  if(!addr || !strstr(addr,":")){ // FIXME
    host = strdup(Supr_hostname);
    port = Config_getPort("ThreadServers");
  } else {

    if(strstr(addr, "//")) addr = strstr(addr, "//")+2;
    host = strdup(addr);
    char *s = strstr(host, ":");
    if(!s) return NULL;
    *s = 0; s++;
    port = atoi(s);
    port_str = s;
  }

  SEXP infoServer = findVar(install("info"), SuprContextEnv);
  if(infoServer == R_UnboundValue || TYPEOF(infoServer) != EXTPTRSXP)
  {
	  free(host);
	  error(_("no info server is available"));
  }
  supr_socket_conn_t *info=(supr_socket_conn_t *)R_ExternalPtrAddr(infoServer);
  char info_addr[strlen(info->host)+32];
  sprintf(info_addr, "%s:%d", info->host, info->port);

  sprintf(msg, "Start thread -port %s:%d ...", host, port);
  Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);

  char shm_name[256];
  sprintf(shm_name, "SUPR_THREAD_%d", getpid());
  sem_t *sem = (sem_t*) Supr_shm_create(shm_name, sizeof(sem_t));
  if(!sem)
    error(_("[%s:%d] Supr_shm_create, %s"), __FILE__,__LINE__, strerror(errno));
  shm_unlink(shm_name);

  sem_init(sem, 1, 0);

  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {

//      fprintf(stderr, "\033[0;31m[%d] parent proc: %d\033[0m\n", __LINE__, getpid());

	  //
      char msg[1024];
      pthread_mutex_lock(&Supr_syncMutex); // fixme ...

        sem_post(sem);

        sprintf(msg, "connot connect to threadserver '%s'", addr);
        Supr_syncObject = msg;
        double timeout = Supr_options.timeout;
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;

        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

        pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);



      pthread_mutex_unlock(&Supr_syncMutex);

      char *__addr = (char*) Supr_syncObject;
      //sprintf(msg, "connected to threadserver '%s'", __addr);
      //Cluster_sendSimpleMessage(msg, "\033[0;33m", BASIC_INFO_TYPE, 0);
      verbose_info("connected to threadserver '%s'", __addr);

      Supr_syncObject = NULL;
      SEXP ret_val = R_NilValue;
      if(__addr && strstr(__addr, ":"))
        ret_val = ThreadServer_connect(mkString(__addr));
      
      {
        clock_gettime(CLOCK_REALTIME, &wait);
        save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
        sprintf(msg, "\033[0;32mpid: %d, cpid: %d. Time elapsed: %g\n\033[0m",
                getpid(), pid, -save_time);
        Cluster_sendSimpleMessage(msg, "\033[0;32m", VERBOSE_INFO_TYPE, 0);
      }



      if(!Supr_options.xterm){
        int status;
        int rc = waitpid(pid, &status, 0);
      }
      //fprintf(stderr, "P [%s] waitpid(pid=%d, &status, 0): %d, status: %d (%s:%d)\n", __func__, pid, rc, status, __FILE__, __LINE__ );

      free(host);

      munmap(sem, sizeof(sem_t));
      //return master_conn;
      //
      return ret_val;
  }

  sem_wait(sem);
  munmap(sem, sizeof(sem_t));

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid) {
    int status;
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    //fprintf(stderr, "C (%s:%d) waitpid(%d, ...), rc: %d, err: %s\n", __FILE__, __LINE__, pid, rc, strerror(errno));
    exit(EXIT_SUCCESS);
  }

  char path[strlen(Supr_sysHome) + strlen("/bin/threadserver")+2];
  sprintf(path, "%s/bin/threadserver",  Supr_sysHome);
  //char port_str[32];
  //sprintf(port_str, "%d", port);

  //char driver_addr[strlen(driverServerConn->host)+32];
  //sprintf(driver_addr, "%s:%d", driverServerConn->host,driverServerConn->port);

  if(strstr(host, "//")) host = strstr(host, "//")+2;
  //fprintf(stderr, "path: %s, host: %s, port_str: %s\n", path, host, port_str);

  char *notify_addr = info_addr;
  int rc;
  if(strcmp(host, Supr_hostname)==0){
    //fprintf(stderr, "local: notify_addr=info_addr=%s\n", info_addr);
    rc = execl(path, path,
		 "-port", port_str,
                 "-info", info_addr,
                 "-notify", info_addr,
                 Supr_verbose ? "--verbose" : "",
                 Supr_debug ?  "--debug" : "",
                 Supr_infov ?  "--info" : "",
                 (char *) NULL);
  } else {
    //fprintf(stderr, "remote: notify_addr=info_addr=%s\n", info_addr);
    char ssh_arg[1024];
    //
    const char *format  = "bash -c 'source .suprrc;"
         " $SUPR_SYS_HOME/bin/threadserver -port %s -X11 %s"
         " %s %s %s -info %s -notify %s'";
	 //
    /*
    const char *format  = "bash 'source .suprrc;"
         " $SUPR_SYS_HOME/bin/threadserver -port %s"
         " %s %s %s -info %s -notify %s'";
	 */

    sprintf(ssh_arg, format,
	 port_str,
         Supr_options.xterm ? "-Y":"_",
	 Supr_verbose ? "--verbose":"",
	 Supr_debug ? "--debug":"",
	 Supr_infov ? "--info":"",
	 info_addr, info_addr);

    verbose_info("ssh -Y %s ssh_arg: %s\n", host, ssh_arg);

    //rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
    rc = execl("/usr/bin/ssh", "ssh", "-Y", host, ssh_arg, (char*) NULL);
    /*
    char buf[strlen("/usr/bin/ssh")+strlen(host)+strlen(ssh_arg)+3];
    sprintf(buf, "/usr/bin/ssh %s %s", host, ssh_arg);
    fprintf(stderr, "cmd buf: %s\n", buf);
    FILE *out = popen(buf, "r");
    char *line = buf;

   // fprintf(stderr, "out: %s\n", line);
    char __buf[1024];
    while(line=fgets(__buf, sizeof(__buf), out)){
      fprintf(stderr, "\033[0;31mout: %s\033[0m\n", line);
    }
    rc = pclose(out);
    */
  }

  fprintf(stderr, "Error with rc=%d in execl, %s\n", rc, strerror(errno));
  
  info_sc = socketOpen1(notify_addr);
  Supr_notify(notify_addr, host, CLUSTER_CONNECT_MASTER);
  exit(EXIT_FAILURE);
  


  return NULL; // not reached
}


#define USE_DOT_SUPRRC

#ifdef  USE_DOT_SUPRRC

supr_socket_conn_t *Supr_startDFSNamenode();

static void DFS_connection_finalizer(SEXP s)
{
  supr_socket_conn_t *sc = *((supr_socket_conn_t **) R_ExternalPtrAddr(s));
  if(Supr_verbose)
    fprintf(stderr, "[%s:%d:%s] TODO ...\n", __FILE__, __LINE__, __func__);
//  if(sc){ close(sc->fd); free(sc); }
}

static void DFS_table_finalizer(SEXP s)
{
  R_ObjectTable *tb = (R_ObjectTable *)R_ExternalPtrAddr(s);
  dfs_env_data_t *data = (dfs_env_data_t *) tb->privateData;
  if(Supr_verbose) {
    fprintf(stderr, "[%s:%d:%s] data->path: %s\n", __FILE__, __LINE__,
		    __func__, data->path);
  }
  free(data->path);
  free(tb);
}

// op: "exists", "persist", "rm", "mv"
extern SEXP DD_operation(SEXP op, SEXP name, SEXP args);
extern SEXP DD_put(SEXP r_name, SEXP subsets, SEXP subset_names);
extern SEXP DD_get(SEXP r_name, SEXP subset_name, SEXP env, SEXP args);

// not for subsets? ... FXIME...
Rboolean DFS_exists(const char * const name, Rboolean *canCache, R_ObjectTable *tb){
  dfs_env_data_t *dfs_env_data = (dfs_env_data_t *) tb->privateData;
  SEXP server = dfs_env_data->rho; 
  SEXP x = PROTECT(mkString(name));
  SEXP op= PROTECT(mkString("exists"));
  SEXP v = DD_operation(op, x, NULL);
  UNPROTECT(2);
  return LOGICAL(v)[0];
}

SEXP DFS_get(const char * const name, Rboolean *canCache, R_ObjectTable *tb){


  dfs_env_data_t *dfs_env_data = (dfs_env_data_t *) tb->privateData;
  //basic_info("dfs_env_data: %p", dfs_env_data);

  SEXP local = dfs_env_data->local;
  if(TYPEOF(local) == ENVSXP){
    SEXP val = findVar(install(name), local);
    if(val != R_UnboundValue)
      return val;
  }

  const char *dd_name = dfs_env_data->path;

  //basic_info("dd_name: %s, name: %s", dd_name, name);
	  
  if(!dd_name){
	  basic_info(__func__);
	  basic_info(name);
	  warning(_("Not implemented yet"));
	  return R_UnboundValue;
  }

  if(strcmp(name, ".__NAMESPACE__.")==0){
    //basic_info("dd_name: %s, name: %s", dd_name, name);
    return R_UnboundValue;
  }
  
  SEXP subset_name = PROTECT(mkString(name));
  SEXP r_name = PROTECT(mkString(dd_name));
  SEXP args = PROTECT(allocVector(VECSXP, 0));

  SEXP ret_val = DD_get(r_name, subset_name, R_GlobalEnv, args);
  UNPROTECT(3);

  return ret_val; 
}

int DFS_remove(const char * const name, R_ObjectTable *tb){

  dfs_env_data_t *dfs_env_data = (dfs_env_data_t *) tb->privateData;
  const char *dd_name = dfs_env_data->path;

  if(!dd_name){
	  basic_info(__func__);
	  error(_("Not implemented yet"));
  }

  SEXP x = PROTECT(mkString(name));
  SEXP op= PROTECT(mkString("rm"));
  SEXP args = PROTECT(CONS(R_FalseValue, R_NilValue));
  SET_TAG(args, install("recursive"));
  SEXP v = PROTECT(DD_operation(op, x, args));
  int rc = asInteger(v);
  UNPROTECT(4);
  return rc;
}

SEXP DFS_assign(const char * const name, SEXP value, R_ObjectTable *tb)
{
  dfs_env_data_t *dfs_env_data = (dfs_env_data_t *) tb->privateData;
  const char *dd_name = dfs_env_data->path;

  if(!dd_name){
	  basic_info(__func__);
	  error(_("Not implemented yet"));
  }

  SEXP subset_names = PROTECT(mkString(name));
  SEXP r_name = PROTECT(mkString(dd_name));
  SEXP subsets = PROTECT(allocVector(VECSXP, 1));
  SET_VECTOR_ELT(subsets, 0, value);

  SEXP ret_val = DD_put(r_name, subsets, subset_names);
  UNPROTECT(3);

  return ret_val;
}

SEXP DFS_objects(R_ObjectTable *tb){
//  error(_("Not implemented")); // TODO? 

  dfs_env_data_t *data = (dfs_env_data_t *) tb->privateData;
  //SEXP server = data->rho; 
  //supr_socket_conn_t *sc = *data->sc_addr;

  if(data->path)
    return DD_list(mkString(data->path));
  else {
	  basic_info(__func__);
	  error(_("Not implemented yet"));
  }
}

Rboolean DFS_canCache(const char * const name, R_ObjectTable *tb){
  fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__,
        name);
  return FALSE;
}
void  DFS_onDetach(R_ObjectTable *tb)
{
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}
void DFS_onAttach(R_ObjectTable *tb)
{
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}


// FIXME...
SEXP DD_print(SEXP x, SEXP dots){
   fprintf(stdout, "(DD) %s\n", CHAR(asChar(x)));
   return x;
}
SEXP DDEnv_print(SEXP x, SEXP dots){
  R_ObjectTable *tb = (R_ObjectTable *) R_ExternalPtrAddr(HASHTAB(x));
  dfs_env_data_t *data =  (dfs_env_data_t *)tb->privateData;
  supr_socket_conn_t *sc = *data->sc_addr;
  if(sc)
    fprintf(stderr, "dfs://%s:%d/%s\n", sc->host, sc->port, data->path);
  return mkString(data->path);
}


// DFS or DFSNameNode
SEXP DFS_createObjectTableEnv(supr_socket_conn_t **sc_addr, const char *path)
{
  //R_ObjectTable *table = malloc(sizeof(R_ObjectTable) + sizeof(SEXP));
  R_ObjectTable *table = malloc(sizeof(R_ObjectTable) + sizeof(dfs_env_data_t));
  table->type = NA_INTEGER; // TODO
  table->cachedNames = NULL;
  table->active = TRUE;

  table->exists = DFS_exists;
  table->get = DFS_get;
  table->remove = DFS_remove;
  table->assign = DFS_assign;
  table->objects= DFS_objects;
  table->canCache = DFS_canCache;

  table->onDetach = DFS_onDetach;
  table->onAttach = DFS_onAttach;

  //table->privateData = NULL;
  table->privateData = table + 1;

  //SEXP udb = PROTECT(R_MakeExternalPtr(table, R_NilValue, R_NilValue));

  SEXP rho = PROTECT(allocSExp(ENVSXP));
  SET_ENCLOS(rho, R_EmptyEnv);
  SEXP tbPtr = PROTECT(R_MakeExternalPtr(table, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(tbPtr, DFS_table_finalizer, TRUE);
  SET_HASHTAB(rho, tbPtr);

  OBJECT(rho) = TRUE;

  //setAttrib(rho, R_ClassSymbol, mkString("UserDefinedDatabase"));
  SEXP klass = PROTECT(allocVector(STRSXP, 2));
  SET_STRING_ELT(klass, 0, mkChar("DDEnv")); // DDEnv: distributed data 
  SET_STRING_ELT(klass, 1, mkChar("UserDefinedDatabase"));
  setAttrib(rho, R_ClassSymbol, klass);
  supr_socket_conn_t *sc = *sc_addr;
  if(sc){
    char addr[strlen(sc->host)+32];
    sprintf(addr, "%s:%d", sc->host, sc->port);
    setAttrib(rho, install("address"), mkString(addr));
    SEXP scPtr = PROTECT(R_MakeExternalPtr(sc_addr, R_NilValue, R_NilValue));
    R_RegisterCFinalizerEx(scPtr, DFS_connection_finalizer, TRUE);
    setAttrib(rho, install("conn"), scPtr);
    UNPROTECT(1);
  }

  dfs_env_data_t *dfs_env_data = table->privateData;
  dfs_env_data->rho = rho;
  dfs_env_data->sc_addr = sc_addr;
  dfs_env_data->path = path ? strdup(path) : NULL;

  // names of objects, such as open and close,
  // in local can be considered as reserved key words???
  // basic_info(path);
  //if(strcmp(path, ".")==0){
    Supr_addLocalFunctions(rho, "dfs.localfuns", "dfs");
    SEXP local = getAttrib(rho, install("localEnv"));
    dfs_env_data->local= local;
    if(findVar(install(".LocalEnv"), local)==R_UnboundValue)
      defineVar(install(".LocalEnv"), local, local);
//    setAttrib(rho, install("name"), mkString("."));
    SET_ENCLOS(rho, local);
  //}

  UNPROTECT(3);
  return rho;
}

// DDT: Distributed Data Table
#define DDT_TMP_SKIP
#ifndef DDT_TMP_SKIP
SEXP DDT_tmp(SEXP call, SEXP x, SEXP i, SEXP j, SEXP group, SEXP env)
{
  SEXP ddt_call = PROTECT(LCONS(install("[.DDEnv"), R_NilValue));
  //SETCDR(ddt_call, R_NilValue);
  SEXP args;
  SEXP dd_name_attr = getAttrib(x, install("name")); 
  if(TYPEOF(dd_name_attr) == STRSXP)
    args = PROTECT(CONS(install(CHAR(asChar(dd_name_attr))), R_NilValue));
  else {
    x = findVar(install("call"), ENCLOS(x));
    if(x == R_UnboundValue) {
	    basic_info("FIXME");
	    error(_("FIXME"));
    }
    args = PROTECT(CONS(x, R_NilValue));
  }

  SEXP s = args;
  SET_TAG(s, install("x"));

  SETCDR(s, CONS(i, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("i"));

  SETCDR(s, CONS(j, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("j"));
   
  SETCDR(s, CONS(group, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("group"));
   
  SETCDR(s, CONS(env, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("env"));

  SETCDR(ddt_call, args);
  
 
  SEXP rho = PROTECT(DFS_createObjectTableEnv(&DFS_namenode, NULL));
  defineVar(install("call"), ddt_call, ENCLOS(rho));
  
  UNPROTECT(3);
  return rho;
}

#else

SEXP DDT_tmp(SEXP call, SEXP x, SEXP i, SEXP j, SEXP group, SEXP env)
{
  SEXP ddt_call = PROTECT(LCONS(install("[.DDEnv"), R_NilValue));
  SEXP args;
  SEXP dd_name_attr = getAttrib(x, install("name")); 
  if(TYPEOF(dd_name_attr) == STRSXP) {
    args = PROTECT(CONS(install(CHAR(asChar(dd_name_attr))), R_NilValue));
    //args = PROTECT(CONS(dd_name_attr, R_NilValue));
  } else if(TYPEOF(x) == PROMSXP) {
    SEXP quote  = CAR(CDDR(PRCODE(x)));
//    fprintf(stderr, "quote: ?\n");
//    PrintValue(quote);
    args = PROTECT(CONS(CAR(CDR(quote)), R_NilValue));
  } else {
    basic_info("FIXME");
    error(_("FIXME"));
  }

  SEXP s = args;
  SET_TAG(s, install("x"));

  SETCDR(s, CONS(i, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("i"));

  SETCDR(s, CONS(j, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("j"));
   
  SETCDR(s, CONS(group, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("group"));
   
  SETCDR(s, CONS(env, R_NilValue));
  s = CDR(s);
  SET_TAG(s, install("env"));

  SETCDR(ddt_call, args);
  
 
  SEXP rho = PROTECT(allocSExp(PROMSXP));
  /*
  PRCODE(s) = CHK(expr); INCREMENT_REFCNT(expr);
    PRENV(s) = CHK(rho); INCREMENT_REFCNT(rho);
    PRVALUE(s) = R_UnboundValue;
    PRSEEN(s) = 0;
    */

  s = rho;
  SEXP expr = PROTECT(LCONS(install(".Call"), CONS(mkString("DDT_call"), CONS(
	  LCONS(install("quote"), CONS(ddt_call, R_NilValue)), R_NilValue))));

  //basic_info("expr:");
  //PrintValue(CDDR(expr));

  SET_PRCODE(s, expr);
  SET_PRENV(s, R_GlobalEnv);
  SET_PRVALUE(s, R_UnboundValue);
  SET_PRSEEN(s, 0);
  SETCDR(ddt_call, args);
  setAttrib(s, R_ClassSymbol, mkString("DDEnv"));

  UNPROTECT(4);
  return rho;
}

#endif



//SEXP DD_print(SEXP x, SEXP args){ }


// start an info connection to DFS_name if info = TRUE?
// See supr.c: SEXP DD_enableInfo(SEXP r_level)
//     supr.c: hread_startInputHandler()

//SEXP DD_enableInfo(SEXP r_level);

// fix _enableInfo first ...

SEXP DFS_startNamenode(SEXP S_verbose, SEXP S_debug, SEXP S_infoConn){

    const char *infoConn;
    if(TYPEOF(S_infoConn) == NILSXP) {
      infoConn = NULL;
    } else {
      infoConn = CHAR(asChar(S_infoConn));
    }
    char info_str[infoConn ? (strlen(infoConn)+1) : 1];
    if(infoConn){
      strcpy(info_str, infoConn);
      infoConn = info_str;
    }

    supr_socket_conn_t *sc = Supr_startDFSNamenode(LOGICAL(S_verbose)[0],
    	LOGICAL(S_debug), infoConn);

    DFS_namenode = sc;

    SEXP ret_val = PROTECT(DFS_createObjectTableEnv(&DFS_namenode, "."));
    int nUNPROTECT = 1;

    if(!Supr_infoServer){
      Supr_infoServer = PROTECT(DD_enableInfo(0));
      defineVar(install("infoServer"), Supr_infoServer, SuprEnv);
      UNPROTECT(1);
    }

    if(Supr_infoServer){
      supr_socket_conn_t *conn = (supr_socket_conn_t *)
		    R_ExternalPtrAddr(Supr_infoServer);
      fprintf(stderr, "[%s] Supr_infoServer: %s:%d\n",
		      __func__, conn->host, conn->port);
      int cmd = INFO_REGISTER;
      write(sc->fd, &cmd, sizeof(int));
      int level = 0; // ?
      write(sc->fd, &level, sizeof(int));
      write(sc->fd, &conn->port, sizeof(int));
      int rc;
      read(sc->fd, &rc, sizeof(int));
      printf("[%s] Sent INFO_REGISTER to %s:%d\n",
		      __func__, sc->host, sc->port);
    }

    UNPROTECT(nUNPROTECT);
    return ret_val;

}

supr_socket_conn_t *Supr_startDFSNamenode(int verbose, int debug,
	const char *infoConn)
{
  printf("[%s:%d] Supr_usrHome: %s\n", __FILE__, __LINE__, Supr_usrHome);

  // find the host
  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  struct stat sb;
  int fd = open(path, O_RDONLY); 
  if(fd == -1 || fstat(fd, &sb) == -1)
    error(_("%s, %s"), path, strerror(errno));

  char buf[sb.st_size+1];
  read(fd, buf, sb.st_size);
  buf[sb.st_size] = 0;
#ifdef SUPR3
  close(fd);
#endif

  char *hostname = strstr(buf, "Namenode");
  if(hostname) { //error(_("%s"), strerror(errno));
    hostname = strstr(hostname, "//")+2;
  }

  int port = -1;

  if(hostname){
    char *s = strstr(hostname, ":");
    *s = 0; s++;
    port = atoi(s);
  } else { 
    // hostname = Supr_hostname;
    return NULL;
  }

  if(!Supr_dfsHome){ // FIXME
    char path[PATH_MAX];

    sprintf(path, "%s/dfs", Supr_usrHome);
    DIR *dir = opendir(path);
    if(!dir){
      if(mkdir(path, 0700)==-1){
         error(_("%s, %s"), path, strerror(errno));
      }
    } else {
      closedir(dir);
    }

    sprintf(path, "%s/dfs/%s", Supr_usrHome, hostname);
    dir = opendir(path);
    if(!dir){
      if(mkdir(path, 0700)==-1){
         error(_("%s, %s"), path, strerror(errno));
      }
    } else {
      closedir(dir);
    }


    Supr_dfsHome = malloc(strlen(path)+1);
    strcpy(Supr_dfsHome, path);
  }

  {
    sprintf(path, "%s/%s", Supr_usrHome, "dfs_name.log");
    unlink(path);
  }

// FIXME
//  printf("hostname: %s\n", hostname);
#ifdef USE_LOCALHOST
  hostname = Supr_hostname;
  fprintf(stderr, "[%d] hostname: %s\n", __LINE__, hostname);
#else
  if(strcmp(hostname,"localhost")==0) {
    hostname = Supr_hostname;
  }
#endif
//  printf("hostname: %s\n", hostname);


  //Start a socket server ??? ....



  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  int rc;
  if(pid) {

  fprintf(stderr, "\033[0;31m[%d] parent proc: %d\033[0m\n", __LINE__, getpid());

      int status;
      rc = waitpid(pid, &status, 0);
      fprintf(stderr,
        "P [%s] waitpid(pid=%d, &status, 0): %d, status: %d (%s:%d)\n", 
           __func__, pid, rc, status, __FILE__, __LINE__ );

#define WAIT_SDFS_NAMENODE
#ifdef  WAIT_SDFS_NAMENODE

//        printf("\033[0;31mport: %d\033[0m\n", port);

      // Start and use a socket server ?
      int _port = port;
      supr_socket_conn_t *conn;
      for(int count = 0; count < 100; count++)
      {
	if(_port==0){
          //sprintf(path, "%s/%s", Supr_usrHome, "dfs_name.log");
          sprintf(path, "%s/%s", Supr_dfsHome, "dfs_name.log");
          printf("\033[0;31mlog: %s\033[0m\n", path);
	  if(access(path, F_OK)==0){ // FIXME by locking file access?
	    struct stat sb;
            int fd = open(path, O_RDONLY);
	    if(fd != -1 && fstat(fd, &sb) != -1){
              char buf[sb.st_size+1];
              buf[sb.st_size] = 0;
	      read(fd, buf, sb.st_size);
	      close(fd);
              printf("\033[0;31mbuf: %s\033[0m\n", buf);
	      if(strstr(buf, "\n"))
                port = atoi(strstr(buf,":")+1);
	      
	    }
	  }
	}

	if((count+1)%5 == 0)
          printf("\033[0;38mConnecting DFS namenode: //%s:%d ...\033[0m\n",
		       	hostname, port);

        conn = socketOpen2(hostname, port);
	if(conn) {
	  conn->type = DFS_NAMENODE_CONN;
	  conn->port = port;
          printf("\033[0;38m Connected to //%s:%d\033[0m\n",
			  conn->host, conn->port);
	  return conn;
	}

	// check dfs_name.log ... FIXME ...
    
	//sleep(1);
      }
      //
      return NULL;

#else

      supr_socket_conn_t * conn = socketOpen2(hostname, port);
      printf("\033[0;31mconn: %p\033[0m\n", conn);
      return conn;

#endif
  }

  fprintf(stderr, "\033[0;32m[%d] Child proc: %d\033[0m\n", __LINE__,
	getpid());

  rc = setsid();
  printf("setsid(): %d, error: %s\n", rc, rc==-1? strerror(errno) : "");
  fflush(stdout);

 
      //const char *format = "source .suprrc;"
      //	" $SUPR_SYS_HOME/bin/dfs_name -port %d -usr %s -sys %s -dfs %s";

      const char *format = "bash -c 'source .suprrc;"
      	" $SUPR_SYS_HOME/bin/dfs_name -port %d -usr %s -sys %s -dfs %s'";

      size_t len = strlen(format) + 128+ 3*PATH_MAX; //+strlen(R_home);
      char ssh_exec_arg[len];
      //sprintf(ssh_exec_arg, format, port);
      //sprintf(ssh_exec_arg, format, port, Supr_usrHome, Supr_sysHome, Supr_dfsHome);
      // FIXME, don't use Supr_usrHome
      sprintf(ssh_exec_arg, format, port, Supr_dfsHome, Supr_sysHome,
      		Supr_dfsHome);


  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid) {
      Supr_message = (char*) malloc(256);
      sprintf(Supr_message, "C [%s] Child proc %d of this proc %d is running ssh",
                    __func__, pid, getpid());
      int status;
      fprintf(stdout, "C [%s (%s:%d)] waitpid: Wait %d\n", __func__, __FILE__,
                      __LINE__, pid);
      errno = 0;
      rc = waitpid(pid, &status, 0);
      fprintf(stdout, "C (%s:%d) waitpid(%d, ...), rc: %d, err: %s\n",
                      __FILE__, __LINE__,
                      pid, rc, strerror(errno));
      fprintf(stdout, "status: %d\n", status);

      if(status == 0) {
        fprintf(stdout, "EXIT_SUCCESS (dfs_name started)\n");
        exit(EXIT_SUCCESS);
      }
      if(status && WIFEXITED(status)) {
        fprintf(stdout, "WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
        fprintf(stderr, "WEXITSTATUS(status): %d, ssh host: %s %s\n",
                        WEXITSTATUS(status), hostname, ssh_exec_arg);
        fprintf(stdout, "Check stderr.txt for the error message\n");
        exit(EXIT_FAILURE);
      }
      fprintf(stdout, "[line: %d] EXIT_SUCCESS (dfs_name started)\n", __LINE__);
      fflush(stdout);
      exit(EXIT_SUCCESS);
  } else { // FIXME... path to ssh

      //rc = execl("/usr/bin/ssh", "ssh", hostname, ssh_exec_arg, (char *) NULL);
      fprintf(stderr, "CC [INFO] localhost: %s\n", Supr_hostname);

      if(   strcmp(hostname, Supr_hostname) == 0
         || strcmp(hostname, "localhost") == 0) {
        fprintf(stderr, "CC [INFO] %s/bin/dfs_name -port %d -usr %s -sys %s -dfs %s\n",
	Supr_sysHome, port, Supr_dfsHome, Supr_sysHome, Supr_dfsHome); // FIXME
	char path[strlen(Supr_sysHome) + strlen("/bin/dfs_name")+2];
	sprintf(path, "%s/bin/dfs_name",  Supr_sysHome);
	char port_str[32];
	sprintf(port_str, "%d", port);
	if(verbose && debug){
          rc = execl(path, path, "-port", port_str,
                 "-usr", Supr_dfsHome, "-sys", Supr_sysHome, // FIXME
                 "-dfs", Supr_dfsHome, "--verbose", "--debug",
		 (char *) NULL);
	} else if(verbose){
          rc = execl(path, path, "-port", port_str,
                 "-usr", Supr_dfsHome, "-sys", Supr_sysHome, // FIXME
                 "-dfs", Supr_dfsHome, "--verbose",
		 (char *) NULL);
	} else if (debug){
          rc = execl(path, path, "-port", port_str,
                 "-usr", Supr_dfsHome, "-sys", Supr_sysHome, // FIXME
                 "-dfs", Supr_dfsHome, "--debug",
		 (char *) NULL);
	} else {
          rc = execl(path, path, "-port", port_str,
                 "-usr", Supr_dfsHome, "-sys", Supr_sysHome, // FIXME
                 "-dfs", Supr_dfsHome,
		 (char *) NULL);
	}
      } else { // TO DO
        fprintf(stderr, "CC [INFO] ssh %s %s\n", hostname, ssh_exec_arg);

        rc = execl("/usr/bin/ssh", "ssh", hostname, ssh_exec_arg, (char *) NULL);
      }

      fprintf(stderr, "[[CC]] rc: %d, error: %s\n", rc,  strerror(errno));
  }

  return NULL; // not reached
}

#else

supr_socket_conn_t *Supr_startDFSNamenode()
{
  printf("Supr_usrHome: %s\n", Supr_usrHome);

  // find the host
  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  struct stat sb;
  int fd = open(path, O_RDONLY); 
  if(fd == -1 || fstat(fd, &sb) == -1)
	  error(_("%s"), strerror(errno));

  char buf[sb.st_size+1];
  read(fd, buf, sb.st_size);
  buf[sb.st_size] = 0;

  char *hostname = strstr(buf, "Namenode");
  if(hostname) { //error(_("%s"), strerror(errno));
    hostname = strstr(hostname, "//")+2;
  }

  int port = -1;

  if(hostname){
    char *s = strstr(hostname, ":");
    *s = 0; s++;
    port = atoi(s);
  } else { 
    // hostname = Supr_hostname;
    return NULL;
  }

  {
    sprintf(path, "%s/%s", Supr_usrHome, "dfs_name.log");
    unlink(path);
  }

// FIXME
//  printf("hostname: %s\n", hostname);
#ifdef USE_LOCALHOST
  hostname = Supr_hostname;
  fprintf(stderr, "hostname: %s\n", hostname);
#else
  if(strcmp(hostname,"localhost")==0) {
    hostname = Supr_hostname;
  }
#endif
//  printf("hostname: %s\n", hostname);





  pid_t pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));

  int rc;
  if(pid) {

      int status;
      rc = waitpid(pid, &status, 0);

#define WAIT_SDFS_NAMENODE
#ifdef  WAIT_SDFS_NAMENODE

//        printf("\033[0;31mport: %d\033[0m\n", port);

int _port = port;
      supr_socket_conn_t *conn;
      for(int count = 0; count < 100; count++)
      {
	if(_port==0){
          sprintf(path, "%s/%s", Supr_usrHome, "dfs_name.log");
          printf("\033[0;31mlog: %s\033[0m\n", path);
	  if(access(path, F_OK)==0){ // FIXME by locking file access?
	    struct stat sb;
            int fd = open(path, O_RDONLY);
	    if(fd != -1 && fstat(fd, &sb) != -1){
              char buf[sb.st_size+1];
              buf[sb.st_size] = 0;
	      read(fd, buf, sb.st_size);
	      close(fd);
              printf("\033[0;31mbuf: %s\033[0m\n", buf);
	      if(strstr(buf, "\n"))
                port = atoi(strstr(buf,":")+1);
	      
	    }
	  }
	}

        printf("\033[0;31mhost: //%s:%d\033[0m\n", hostname, port);

        conn = socketOpen2(hostname, port);
        printf("\033[0;31mconn: %p\033[0m\n", conn);
	if(conn) {
	  conn->type = DFS_NAMENODE_CONN;
	  conn->port = port;
	  return conn;
	}

	// check dfs_name.log ... FIXME ...
    
	//sleep(2);

      }
      return NULL;

#else

      supr_socket_conn_t * conn = socketOpen2(hostname, port);
      printf("\033[0;31mconn: %p\033[0m\n", conn);
      return conn;

#endif
  }

  rc = setsid();
  printf("setsid(): %d, error: %s\n", rc, rc==-1? strerror(errno) : "");
  fflush(stdout);

 
  const char *format = "%s/bin/R --vanilla -e \"{library(supr2);"
                    "supr2:::runAsDFSNamenode(port=%d)}\"";
  char *R_home = getenv("R_HOME");
  printf("\033[0;32mR_home: %s\n", R_home);

  size_t len = strlen(format) + 128+strlen(R_home);
  char ssh_exec_arg[len];
  sprintf(ssh_exec_arg, format, R_home,  port); // FIXME???


/*
  const char *format = "$R_HOME'/bin/R --vanilla -e \"{library(supr2);"
                    "supr2:::runAsDFSNamenode(port=%d)}\"'";

  size_t len = strlen(format) + 128;
  char ssh_exec_arg[len];
  sprintf(ssh_exec_arg, format, port); // FIXME???
*/

  pid = fork();
  if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid) {
      Supr_message = (char*) malloc(256);
      sprintf(Supr_message, "[%s] Child proc %d of this proc %d is running ssh",
                    __func__, pid, getpid());
      int status;
      fprintf(stdout, "[%s (%s:%d)] waitpid: Wait %d\n", __func__, __FILE__,
                      __LINE__, pid);
      errno = 0;
      rc = waitpid(pid, &status, 0);
      fprintf(stdout, "(%s:%d) waitpid(%d, ...), rc: %d, err: %s\n",
                      __FILE__, __LINE__,
                      pid, rc, strerror(errno));
      fprintf(stdout, "status: %d\n", status);
      if(status && WIFEXITED(status)) {
        fprintf(stdout, "WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
        fprintf(stderr, "WEXITSTATUS(status): %d, ssh host: %s %s\n",
                        WEXITSTATUS(status), hostname, ssh_exec_arg);
        fprintf(stdout, "Check stderr.txt for the error message\n");
      }
      fflush(stdout);
      exit(EXIT_SUCCESS);
  } else {

      // FIXME... path to ssh
      rc = execl("/usr/bin/ssh", "ssh", hostname, ssh_exec_arg, (char *) NULL);
      fprintf(stderr, "rc: %d, error: %s\n", rc,  strerror(errno));
  }

  return NULL; // not reached
}

#endif // USE_DOT_SUPRRC


/* A simple gdb interface
 *
 * gdb -p proc
 * bt
 * thread n
 * bt
 */
//void Supr_debug2(pid_t which, supr_socket_conn_t *socket_in);

SEXP Supr_debug_R(SEXP which, SEXP conn_in){
  char *buf = NULL;
  Supr_debug2(INTEGER(which)[0], &buf);// TODO
  if(buf) Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);
  free(buf);
  return R_NilValue;
}

extern supr_socket_conn_t *serverSocketAccept(supr_conn_t *serverConn);

//
/*
char *Supr_gdb_insert(){
	//fflush(stdin);
	//fprintf(stdout, "stdout: %s\n", str);
	//fprintf(stderr, "stderr: %s\n", str);
//	fflush(stdout);
	static int i=0;
	switch(i++){
		case 0: return "\033[0;32m";
		case 1: return "\033[0;33m";
		case 2: return "\033[0;34m";
		case 3: return "\033[0;35m";
		case 4: return "\033[0;36m";
		default: return "\033[0m";
	}
	return NULL;
}
*/
//

// libthread_db: 
void Supr_debug2(pid_t which, char **out){

	Supr_debug = TRUE;
	Supr_verbose = TRUE;
	Supr_infov = TRUE;

  char msg[1024];
  if(which <=0) which = getpid();
  sprintf(msg, "Start gdb -p %d on %s", which, Supr_hostname);
  Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

  //
  char shm_name[256];
  sprintf(shm_name, "SUPR_DEBUG_%d", getpid());
  ssize_t segment_size = sizeof(sem_t)+sizeof(int);
  sem_t *sem = (sem_t*) Supr_shm_create(shm_name, segment_size);
  if(!sem){
    sprintf(msg, "[%s:%d] Supr_shm_create, %s", __FILE__,__LINE__,
		    strerror(errno));
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
    return;
  }
  shm_unlink(shm_name);

  sem_init(sem, 1, 0);

  errno = 0;
  ((int*)sem)[0] = 0;

  /*
  int fd_in = STDIN_FILENO;
  if(socket_in) {
    fd_in = socket_in->fd;
  }
  dup2(fd_in, STDIN_FILENO);
  */

  // gdb stdout and stderr file:
  char template[128];
  sprintf(template, "/tmp/supr_XXXXXX");

  int fd_tmp = mkstemp(template);
  if(fd_tmp == -1){
    sprintf(msg, "Error in mkstemp(%s), %s", template, strerror(errno));
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
    return;
  } 

  sprintf(msg, "mkstemp(%s), %s", template, strerror(errno));
  Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
  
  int pipefd_err[2];
  int rc = pipe(pipefd_err);
  if(rc==-1) printf("[c] pipe, %s\n", strerror(errno));

  // gdb stdin file:
  int pipefd_in[2];
  rc = pipe(pipefd_in);
  if(rc==-1) printf("[c] pipe, %s\n", strerror(errno));

  pid_t pid = fork(); if(pid == -1) error(_("fork, %s"), strerror(errno));

  if(pid) {
    
    //FILE *cmd_output = fdopen(pipefd_out[0], "r");
    FILE *cmd_input = fdopen(pipefd_in[1], "w");
    FILE *cmd_error = fdopen(pipefd_err[0], "r");

    //close(pipefd_out[1]); // Close writing end of pipe
    close(pipefd_in[0]);
    close(pipefd_err[1]); // Close writing end of pipe

   fprintf(cmd_input, "bt\n"
	   "thread apply all bt\n"
	   "q\n"
	   "n\n");

   fflush(cmd_input);

   sem_wait(sem);

   int fd = open(template, O_RDONLY);
   if(fd == -1){
          sprintf(msg, "Error in open(%s), %s", template, strerror(errno));
          Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
          return;
    } 
    struct stat sb;
    if(fstat(fd, &sb)!=-1){
	  char *buf = malloc(sb.st_size+1);
	  buf[sb.st_size] = 0;
	  read(fd, buf, sb.st_size);
	  close(fd);
          //Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);
	  //fprintf(stderr, "\033[0;33mcmd_out: %s\033[0m", strstr(buf, "(gdb)"));
	  //free(buf);
	  *out = buf;
    }

    char line[1024];
    while(fgets(line, sizeof(line), cmd_error)){
	  fprintf(stderr, "\033[0;31mcmd_error: %s\033[0m", line);
    }
    
    int status;
    sprintf(msg, "Wait with waitpid(%d, ...)", pid);
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
    int rc = waitpid(pid, &status, 0);
    sprintf(msg, "P [%s] waitpid(pid=%d, &status, 0): %d, status: %d (%s:%d)",
           __func__, pid, rc, status, __FILE__, __LINE__ );
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    munmap(sem, segment_size);

    close(fd_tmp);
    unlink(template);
    return;
  } else {

    int save_stderr_fd = STDERR_FILENO;

    dup2(pipefd_err[1], STDERR_FILENO); // Duplicate writing end to stdout
    close(pipefd_err[0]);
    close(pipefd_err[1]); 
    
    dup2(pipefd_in[0], STDIN_FILENO);
    close(pipefd_in[0]);
    close(pipefd_in[1]);

    dup2(fd_tmp, STDOUT_FILENO);
    //dup2(fd_tmp, STDERR_FILENO);

    char cmd[256];

    sprintf(cmd, "gdb -p %d", which);
    int rc= system(cmd);
    ((int*)sem)[0] = rc;

    dup2(save_stderr_fd, STDERR_FILENO);
    sem_post(sem);

    munmap(sem, sizeof(sem_t)+segment_size);
    exit(rc);
  }
}


// addr: //host:port?ntrs=k
//
void Supr_startWorker(char *addr, const char *master, int argc, char** argv,
		int use_window)
{
  int Worker_useWindow = use_window;
  int Taskrunner_useWindow = FALSE;

  char *verbose = NULL;
  char *nTaskrunners = NULL;

  char *_window = NULL;
  for(int i=0; i<argc; i++){
    //printf("\033[0;34margv[%d]: %s\033[0m\n", i, argv[i]);
    if(i < argc -1){
      if(strcmp(argv[i], "-verbose")==0){
        verbose = argv[++i];
        //printf("\033[0;34margv[%d]: %s\033[0m\n", i, argv[i]);
      } else if(strncmp(argv[i], "-nt", 3)==0){
        nTaskrunners = argv[++i];
        //printf("\033[0;34margv[%d]: %s\033[0m\n", i, argv[i]);
      } else if( (
          strcmp(argv[i], "-stdout")==0 ||
          strcmp(argv[i], "-taskrunner.stdout")==0
          ) && strcmp(argv[i+1], "--window")==0) {
         _window = "-taskrunner.stdout --window";
         Taskrunner_useWindow = TRUE;
	 i++;
         //printf("\033[0;34margv[%d]: %s\033[0m\n", i, argv[i]);
         //Worker_useWindow = TRUE;
      }
    }
  }

//  char *ttys[] = {"/dev/pts/4", "/dev/pts/11", "/dev/pts/12"};
//  static int tty_idx = 0;

//  char *__tty = ttys[tty_idx++];

  /*
  int pipe_fd[2];
  pipe(pipe_fd);
  */



  pid_t pid = fork();
  if(pid) {
    //sleep(5); printf("\n\n\n\n\n\n");
    if(worker_windows == NULL){
      worker_windows = (int*) malloc(sizeof(int)*2);
      worker_windows[0] = pid;
      worker_windows[1] = 0;
    } else {
      int *p = worker_windows;
      int n = 0;
      while(p[n]) n++;
      n++;
      worker_windows = (int*) malloc(sizeof(int)*(n+1));
      memcpy(worker_windows+1, p, n*sizeof(int));
      worker_windows[0] = pid;
      free(p);

      //n = 0; while(worker_windows[n]) { n++; }
    }

    /*
    close(pipe_fd[1]);

    int c;
    for(int i=0; i<100; i++){
       ssize_t size = read(pipe_fd[0], &c, 1);
       if(size == 1){
	       putchar(c);
       }
    }
    */


    int status;
    //int rc = waitpid(pid, &status, WNOHANG);
    int rc = waitpid(pid, &status, 0);
    printf("waitpid: %d, status: %d\n", rc, status);

    return;
  }

  /*
  close(pipe_fd[0]);
  {
     char *to_parent = "Hello!\n";
     write(pipe_fd[1], to_parent, strlen(to_parent));
  }
  */

 
	  /*
  pid = fork();
  if(pid){
    int status;
    int rc = waitpid(pid, &status, WNOHANG);
    printf("waitpid: %d, status: %d\n", rc, status);
	  exit(0);
  }
    */

  setsid();

  pid = getpid();

  supr_thread_t *cth = currentThread();
  cth->pid = pid;
  cth->tid = (int) syscall(SYS_gettid);
  cth->ptid = pthread_self();

  SocketConn_closeAll(socket_connections, 0);

  {
          int rc = setpgrp();
  }

  char CMD_PATH[PATH_MAX];
  sprintf(CMD_PATH, "/usr/bin/ssh");

  char *hostname = strstr(addr, "//")+2;
  char *str = strstr(hostname, ":");
  *str = 0; str++;


  if(!nTaskrunners || atoi(nTaskrunners)<=0){
    char *ntrs = strstr(str, "?");
    if(ntrs && (ntrs = strstr(ntrs, "ntrs")) && (ntrs = strstr(ntrs, "="))){
      nTaskrunners = ntrs+1;
      int k = atoi(nTaskrunners);
      printf("nTaskrunners: %s, k: %d\n", nTaskrunners, k);
    }
  }

  {
    char *s = str;
    while(*s && isdigit(*s)) s++;
    *s = 0;
  }

  size_t len = 0;
  //const char *format = "'cd supr/src; gnome-terminal --hide-menubar --title"
  const char *format = "'cd $SUPR_SYS_HOME/bin; gnome-terminal --hide-menubar --title"
         " \"Worker@%s\" --window"
         " -- sh -c \"worker -port %s -master %s %s\"; exec bash'";

  len += strlen(format);
  len += strlen(addr) + strlen(master) + (_window ? strlen(_window) : 0)+3;

  if(nTaskrunners)
    len += strlen("-ntaskrunners") + strlen(nTaskrunners)+2;

  if(verbose)
    len += strlen("-verbose") + strlen(verbose)+2;

  char ssh_arg[len+256]; // FIXME


  //if(_window && strcmp(_window, "--window")==0)
  if(FALSE && Taskrunner_useWindow)
  {
    sprintf(ssh_arg, format, hostname, str, master,
                    "-taskrunner.stdout --window");
  } else {
    //sprintf(ssh_arg, "'cd supr/src; worker -port %s -master %s %s'", str, master,
    //sprintf(ssh_arg, "'cd $SUPR_SYS_HOME/bin; worker -port %s -master %s %s'", str, master,
    //sprintf(ssh_arg, "'$SUPR_SYS_HOME/bin/worker -port %s -master %s %s'", str, master,
//    sprintf(ssh_arg, "'R -e \"{library(supr2); supr2:::runAsWorker()}\" -port %s -master %s %s'", str, master,
//    sprintf(ssh_arg, "'R -e \"{library(supr2);supr2:::runAsWorker(port=%sL,master=\'%s\')}\" -port %s -master %s %s'", str, master, str, master,

	  /*
    char *R_home = getenv("R_HOME");
    if(!R_home){
      printf("Error: cannot find R_HOME\n");
      exit(EXIT_FAILURE);
    }
    
    sprintf(ssh_arg, "'%s/bin/R -e \"{library(supr2);supr2:::runAsWorker()}\" -port %s -master %s %s'", R_home, str, master,
                    _window ? _window : "");
		    */
//    sprintf(ssh_arg, "source .suprrc; env; $R_HOME/bin/R -e \'{library(supr2);supr2:::runAsWorker()}\' -port %s -master %s %s", str, master,
//                    _window ? _window : "");
    sprintf(ssh_arg, "$R_HOME/bin/R -e \'{library(supr2);supr2:::runAsWorker()}\' -port %s -master %s %s", str, master,
                    _window ? _window : "");
  }

  if(nTaskrunners)
    sprintf(ssh_arg + strlen(ssh_arg)-1, " -ntaskrunners %s'", nTaskrunners);
  if(verbose)
    sprintf(ssh_arg + strlen(ssh_arg)-1, " -verbose %s'", verbose);

  /*
  {
    printf("\033[0;32mcmd_path: %s\033[0m\n", CMD_PATH); 
    printf("\033[0;32mhostname: %s\033[0m\n", hostname);
    printf("\033[0;32mssh_arg: %s\033[0m\n", ssh_arg);
  }
  */

  if(FALSE && Taskrunner_useWindow)
  {
    char *X11 = "-Y";
    char cmd[strlen("ssh %s %s %s &")+strlen(X11)+strlen(hostname)+strlen(ssh_arg)+3];
    //sprintf(cmd, "ssh %s %s %s&", X11, hostname, ssh_arg);
    //sprintf(cmd, "ssh %s %s %s &", X11, hostname, ssh_arg);
    sprintf(cmd, "ssh %s %s %s", X11, hostname, ssh_arg);
    //printf("\n\033[0;32mcmd: %s\033[0m\n\n", cmd);
    int rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
    exit(0);
 } else if(FALSE && Worker_useWindow) {

    char *X11 = "-Y";
    char *argv[] = {
          CMD_PATH, X11, hostname, ssh_arg,
          (char*) NULL
      };

    char window_name[256];
    sprintf(window_name, "Worker@%s", hostname);
    //supr_xterm_t *xterm = supr_xterm3(window_name, argv, TRUE);
    supr_xterm_t *xterm = supr_xterm3(window_name, argv, FALSE);
    //supr_xterm_t *xterm = supr_xterm3(window_name, argv, Taskrunner_useWindow);


    if(xterm) {
      printf("[%s] run worker: xterm =  %p\n", __func__, xterm);
    } else {
      printf("[%s] run worker: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
    }

    exit(0);

  } else {
    char *X11 = "-Y"; // ""; // "-Y";
    //printf("\033[0;34mhostname: %s\033[0m\n", hostname);
    //printf("\033[0;34mssh_arg: %s\033[0m\n", ssh_arg);
    //printf("\033[0;34mX11: %s\033[0m\n", X11);
#define USE_EXECL
#ifdef  USE_EXECL

    char cmd[strlen("ssh %s %s %s &")+strlen(X11)+strlen(hostname)+strlen(ssh_arg)+3];
    //sprintf(cmd, "ssh %s %s %s&", X11, hostname, ssh_arg);
    sprintf(cmd, "ssh %s %s %s &", X11, hostname, ssh_arg);
    //printf("\n\033[0;32mcmd: %s\033[0m\n\n", cmd);

    {
            /*
            for(int i=0; i<5; i++) {
                    printf("\033[0;32m..\033[0m\n");
                    sleep(1);
            }
            */
                    //sleep(1);
    //printf("\n\033[0;32mcmd: %s\033[0m\n\n", cmd);
      char *display_env = getenv("DISPLAY");
      int rc = X11_check();
      printf("display_env: %s, X11_check(): %d\n", display_env, rc);

      errno = 0;
      rc = isatty(STDOUT_FILENO);
      if(errno) {
          printf("[%s] Error: %s STDOUT_FILENO: %d (%s:%d)\n", __func__,
                          strerror(errno), STDOUT_FILENO,
                          __FILE__, __LINE__);
          rc = 0;
      }
      if(rc){
        char buf[PATH_MAX];
        int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
        if(rc) {
          printf("[%s] Error: %s (%s:%d)\n", __func__, strerror(errno),
                          __FILE__, __LINE__);
        } else {
          printf("ttyname: %s\n", buf);
        }
      }
    }
    //int rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
    sprintf(CMD_PATH, "/usr/bin/ssh");
    X11 = "-Y";
    /*
    sprintf(ssh_arg, "R -e '{library(supr2);supr2:::runAsWorker(port=%s,"
		    "master=\"%s\")}' -port %s -master %s %s",
		    str, master,
		    str, master,
                    _window ? _window : "");
		    */
    //char *ntrs = "2L";
    if(!nTaskrunners) //nTaskrunners = "2L";
	    nTaskrunners = "0L";

/*
ssh scholar-fe02.rcac.purdue.edu $R_HOME/bin/R '--vanilla -e "{library(supr2);supr2:::runAsWorker(port=7204,master=\"//scholar-fe02.rcac.purdue.edu:7202\",window=NULL,nTaskrunners=2L)}"'

or

ssh scholar-fe02.rcac.purdue.edu $R_HOME'/bin/R --vanilla -e "{library(supr2);supr2:::runAsWorker(port=7204,master=\"//scholar-fe02.rcac.purdue.edu:7202\",window=NULL,nTaskrunners=2L)}"'
 */
    /*
    char *R_home = getenv("R_HOME");
    if(!R_home){
      printf("Error: cannot find R_HOME\n");
      exit(EXIT_FAILURE);
    }
    */
    
	    /*
    sprintf(ssh_arg, "$R_HOME/bin/R --vanilla -e \'{library(supr2);supr2:::runAsWorker"
		    "(port=%s,master=\"%s\",window=%s,nTaskrunners=%s)}\'",
		    str, master, _window ? _window : "NULL", nTaskrunners);
    */
    sprintf(ssh_arg, "source .suprrc; env; $R_HOME/bin/R --vanilla -e \'{library(supr2);supr2:::runAsWorker"
		    "(port=%s,master=\"%s\",window=%s,nTaskrunners=%s)}\'",
		    str, master, _window ? _window : "NULL", nTaskrunners);

    /*
    {
      FILE *out = fopen(__tty, "w");
      dup2(fileno(out), STDOUT_FILENO);
      dup2(fileno(out), STDERR_FILENO);
    }
    */
    /*
    {
       //write(pipe_fd[1], to_parent, strlen(to_parent));
      dup2(pipe_fd[1], STDOUT_FILENO);
      dup2(pipe_fd[1], STDERR_FILENO);
    }
    */

// FIXME
    Rprintf("\033[0;34mFrom host: %s\033[0m\n\n\n", hostname);
#ifdef USE_LOCALHOST
  hostname = Supr_hostname;
  fprintf(stderr, "hostname: %s\n", hostname);
#else
  if(strcmp(hostname, "localhost")==0)
    hostname = Supr_hostname;
#endif
    Rprintf("\033[0;34mFrom host: %s\033[0m\n\n\n", hostname);

    
    Rprintf("\033[0;34mFrom host: %s\033[0m\n\n\n", Supr_hostname);
    Rprintf("\033[0;34mX11: %s\033[0m\n", X11);
    Rprintf("\033[0;34mhostname: %s\033[0m\n", hostname);
    Rprintf("\033[0;34mssh_arg: %s\033[0m\n\n", ssh_arg);

    int rc;

    /*
    pid_t p = fork();
    if(p<0) {
	    REprintf("Error: %s\n", strerror(errno));
	    rc = -1;
    } else if (p){
      int status;
      errno = 0;
      rc = waitpid(p, &status, 0);
      Rprintf("rc: %d, err: %s\n", rc, strerror(errno));
      if(status){
        Rprintf("WIFEXITED(status): terminated normally: %s\n",
			WIFEXITED(status)?"TRUE":"FALSE");
        Rprintf("WEXITSTATUS(status): exit status: %d\n",
			WEXITSTATUS(status));
#define SSH_ERROR 255
	if(WEXITSTATUS(status) ==  SSH_ERROR){
	  char *ssh_err = "an error occurred"; //See man ssh
	  supr_socket_conn_t *server = NULL;
	  if(vectorSize(socket_connections)>0){
	    server = (supr_socket_conn_t *)
		  vectorElementAt(socket_connections, 0);
	  }
	  if(server){
            int sc_fd = socket_client(server->host, server->port);
	  //int cmd = CLUSTER_ERROR;
	    Rprintf("close: %d\n", sc_fd);
	    close(sc_fd); // to do
	  }
	  exit(SSH_ERROR);
	}
#undef SSH_ERROR
      }

    } else {
      rc = execl(CMD_PATH, "ssh", X11,
                  hostname, ssh_arg,
                  (char*) NULL);
    }
    */
    //rc = execl(CMD_PATH, "ssh", X11, hostname, ssh_arg, (char*) NULL);
    if(Supr_verbose){
      printf("%s ssh %s %s\n", CMD_PATH, hostname, ssh_arg);
    }

#define USE_STDIN_REDIRECTION
#ifdef  USE_STDIN_REDIRECTION
    char template[128];
    sprintf(template, "/tmp/supr_XXXXXX");
    int fd = mkstemp(template);
    write(fd, ssh_arg, strlen(ssh_arg)+1);
    lseek(fd, 0, SEEK_SET);
    dup2(fd, STDIN_FILENO);
    rc = execl(CMD_PATH, "ssh", hostname, (char*) NULL);
#else
    rc = execl(CMD_PATH, "ssh", hostname, ssh_arg, (char*) NULL);
#endif
   
#else
    char cmd[1024];
    sprintf(cmd, "ssh %s %s", hostname, ssh_arg);
    printf("\033[0;32mcmd: %s\033[0m\n", cmd);
    int rc = system(cmd);
#endif

    Rprintf("\033[0;31m[%s] run worker: rc =  %d, %s\033[0m\n", __func__,
		    rc, strerror(errno));
    //sleep(120);
    exit(0);
  }

}

SEXP Supr_runAsWorker(SEXP args)
{
	//
  pid_t pid = fork();
  if(pid < 0) error(_("fork: %s"), strerror(errno));

  if(pid){
    Supr_message = (char*) malloc(256);
    sprintf(Supr_message, "[%s] Child proc %d of this proc %d is running worker",
		    __func__, pid, getpid());
    int status;
    Rprintf("waitpid: Wait\n");
    errno = 0;
    int rc = waitpid(pid, &status, 0);

    Rprintf("(%s:%d) waitpid(%d, ...), rc: %d, err: %s\n", 
		    __FILE__, __LINE__,
		    pid, rc, strerror(errno));
    Rprintf("status: %d\n", status);
    if(status && WIFEXITED(status))
      Rprintf("WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
    //exit(0);
    return R_NilValue;
  } else {
  //
    fprintf(stderr, "[%d@%s] Supr_sysHome: %s\n", getpid(),
		    __func__, Supr_sysHome);
    //setpgrp();
    //setsid();
    int argc = 0;
    for(int i=0; Supr_argv[i]; i++){
      fprintf(stderr, "%d. %s\n", i, Supr_argv[i]);
      argc ++;
    }
    //char *const argv[argc];
    char path[strlen(Supr_sysHome)+strlen("bin")+strlen(SYS_COMMAND_WORKER)+3];
    sprintf(path, "%s/bin/%s", Supr_sysHome, SYS_COMMAND_WORKER);
#define USE_ARGS
#ifdef  USE_ARGS

	Rprintf("\"worker_init\": %s\n", __func__);
	PrintValue(args);

    argc = 7+1;
    //char *argv[argc];
    char *argv[argc];
    argc = 0;
    argv[argc++] = SYS_COMMAND_WORKER;
    argv[argc++] = "-port";
    /*
    SEXP r = RList_findVar("port", args);
    if(r == R_UnboundValue){
	    error(_("FIXME: %s:%d, args: %s"), __FILE__, __LINE__,
			    type2char(TYPEOF(args)));
    }
    */
    //const char *_port_ = CHAR(asChar(RList_findVar("port", args)));
    //printf("_port_: %s\n", _port_);
    //argv[argc++] =  strdup(_port_);
    argv[argc++] =  (char*) CHAR(asChar(RList_findVar("port", args)));
    argv[argc++] = "-master";
    /*
    r = RList_findVar("master", args);
    if(r == R_UnboundValue){
	    error(_("FIXME: %s:%d, args: %s"), __FILE__, __LINE__,
			    type2char(TYPEOF(args)));
    }
    */
    //const char *_master_ = CHAR(asChar(RList_findVar("master", args)));
    //printf("_master_: %s\n", _master_);
    //argv[argc++] = strdup(_master_);
    argv[argc++] = (char*) CHAR(asChar(RList_findVar("master", args)));

    argv[argc++] = "-nTaskrunners";
    argv[argc++] = (char*) CHAR(asChar(RList_findVar("nTaskrunners", args)));

    argv[argc++] = NULL;
#else
    char *argv[argc];
    argc = 0;
    //args[argc++] = path;
    argv[argc++] = SYS_COMMAND_WORKER;
    for(int i=3; Supr_argv[i]; i++){
      fprintf(stderr, "%d. %s\n", i, Supr_argv[i]);
      argv[argc++] = Supr_argv[i];
    }
    argv[argc++] = NULL;
#endif

    for(int i=0; argv[i]; i++){
      fprintf(stderr, "argv[%d] %s\n", i, argv[i]);
    }

    int rc = execv(path, argv);
    fprintf(stderr, "path: %s, rc: %d, err/msg: %s\n", path,
		    rc, strerror(errno));
  }
}

SEXP Supr_runAsDFSDatanode(SEXP args)
{
  const char *port = CHAR(asChar(RList_findVar("port", args)));
  fprintf(stderr, "\033[0;31m[pid: %d] %s@%s, port: %s\033[0m\n",
		 getpid(), Supr_hostname,
		 __func__, port); 

  c_backtrace();

  fflush(stderr);

  //
  pid_t pid = fork();
  if(pid < 0) error(_("fork: %s"), strerror(errno));

  if(pid){
    Supr_message = (char*) malloc(256);
    sprintf(Supr_message, "[%s] Child proc %d of this proc %d is running dfs_data",
		    __func__, pid, getpid());

    int status;
    Rprintf("waitpid: Wait %d\n", pid);
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    Rprintf("(%s:%d) waitpid(%d, ...), rc: %d, err: %s\n", 
		    __FILE__, __LINE__,
		    pid, rc, strerror(errno));
    Rprintf("status: %d\n", status);
    if(status && WIFEXITED(status))
      Rprintf("WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
    //exit(0);
    fflush(stdout);
    return R_NilValue;
  } else {
  //
    int argc = 3+1;
    char *argv[argc];
    argc = 0;
    argv[argc++] = SYS_COMMAND_DFS_DATANODE;
    argv[argc++] = "-port";
    argv[argc++] = (char *) port;
    argv[argc++] = NULL;

    char path[strlen(Supr_sysHome)+strlen("bin")+strlen(SYS_COMMAND_DFS_DATANODE)+3];
    sprintf(path, "%s/bin/%s", Supr_sysHome, SYS_COMMAND_DFS_DATANODE);

    fprintf(stderr, "path: %s\n", path);
    for(int i=0; argv[i]; i++){
      fprintf(stderr, "argv[%d] %s\n", i, argv[i]);
    }

    int rc = execv(path, argv);
    fprintf(stderr, "path: %s, rc: %d, err/msg: %s\n", path,
		    rc, strerror(errno));
  }
  //return R_NilValue;
    exit(0);
}


SEXP Supr_runAsDFSNamenode(SEXP args)
{
  const char *port = CHAR(asChar(RList_findVar("port", args)));
  fprintf(stderr, "\033[0;31m[pid: %d] %s@%s, port: %s\033[0m\n",
		 getpid(), Supr_hostname,
		 __func__, port); 

//  c_backtrace();

//  fflush(stderr);

  //
  pid_t pid = fork();
  if(pid < 0) error(_("fork: %s"), strerror(errno));

  if(pid){
    Supr_message = (char*) malloc(256);
    sprintf(Supr_message, "[%s] Child proc %d of this proc %d is running dfs_name",
		    __func__, pid, getpid());

    int status;
    Rprintf("waitpid: Wait %d\n", pid);
    errno = 0;
    int rc = waitpid(pid, &status, 0);
    Rprintf("(%s:%d) waitpid(%d, ...), rc: %d, err: %s\n", 
		    __FILE__, __LINE__,
		    pid, rc, strerror(errno));
    Rprintf("status: %d\n", status);
    if(status && WIFEXITED(status))
      Rprintf("WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
    //exit(0);
    fflush(stdout);
    return R_NilValue;
  } else {
  //
    int argc = 3+1;
    char *argv[argc];
    argc = 0;
    argv[argc++] = SYS_COMMAND_DFS_NAMENODE;
    argv[argc++] = "-port";
    argv[argc++] = (char *) port;
    argv[argc++] = NULL;

    char path[strlen(Supr_sysHome)+strlen("bin")+strlen(SYS_COMMAND_DFS_NAMENODE)+3];
    sprintf(path, "%s/bin/%s", Supr_sysHome, SYS_COMMAND_DFS_NAMENODE);

    fprintf(stderr, "path: %s\n", path);
    for(int i=0; argv[i]; i++){
      fprintf(stderr, "argv[%d] %s\n", i, argv[i]);
    }

    int rc = execv(path, argv);
    fprintf(stderr, "path: %s, rc: %d, err/msg: %s\n", path,
		    rc, strerror(errno));
  }
  //return R_NilValue;
    exit(0);
}





#define PASSCODE 1001
#define ADD_HOST 1011
#define RUN_CMD  1021

SEXP Supr_suprd(SEXP what, SEXP argv, SEXP suprd_host, SEXP suprd_port)
{
  int sc_fd = socket_client(CHAR(asChar(suprd_host)),
		  asInteger(suprd_port));
  if(sc_fd == -1)
    error(_("socket_client, %s"), strerror(errno));

  int rc;
  int cmd = PASSCODE;
  char *home = getenv("HOME");
  char path[PATH_MAX];
    sprintf(path, "%s/.supr/.passcode", home);
  rc = access(path, F_OK);
  if(rc == -1){
    warning(_("the passcode file '%s' doesn't exist"), path);
  } else {
    int fd = open(path, O_RDONLY);
    if(fd == -1)
      error(_("cannot open the passcode file, %s"), strerror(errno));
    
    struct stat sb;
    rc = fstat(fd, &sb);
    if(rc == -1)
      error(_("stat, %s"), strerror(errno));

    char buf[sb.st_size+1];
    ssize_t size = read(fd, buf, sb.st_size);
    if(size != sb.st_size)
      error(_("read, %s"), strerror(errno));
    buf[sb.st_size] = 0;
    close(fd);
    //printf("passcode: %s\n", buf);
    write(sc_fd, &cmd, INT_SIZE);
    int len = strlen(buf)+1;
    write(sc_fd, &len, INT_SIZE);
    write(sc_fd, buf, len);
    read(sc_fd, &rc, len);
    //printf("rc: %d\n", rc);
  }

  const char *what_str = CHAR(asChar(what));
  if(strcmp(what_str, "run")==0){
    cmd = RUN_CMD;
    write(sc_fd, &cmd, INT_SIZE);

    int n = LENGTH(argv);
    write(sc_fd, &n, INT_SIZE);
    //printf("write: n: %d\n", n);
    for(int i=0; i<n; i++){
      const char *arg = CHAR(STRING_ELT(argv, i));
      int len = strlen(arg)+1;
      write(sc_fd, &len, INT_SIZE);
      write(sc_fd, arg, len);
      //printf("write: %d, %s\n", len, arg);
    }
    read(sc_fd, &rc, INT_SIZE);

  } else if(strcmp(what_str, "add")==0){
    cmd = ADD_HOST;
    int n = LENGTH(argv);
    for(int i=0; i<n; i++){
      write(sc_fd, &cmd, INT_SIZE);
      const char *arg = CHAR(STRING_ELT(argv, i));
      int len = strlen(arg)+1;
      write(sc_fd, &len, INT_SIZE);
      write(sc_fd, arg, len);
      //printf("write: %d, %s\n", len, arg);
      read(sc_fd, &rc, INT_SIZE);
    }
  } 


  close(sc_fd);

  return ScalarInteger(rc);
}

#undef PASSCODE
#undef ADD_HOST
#undef RUN_CMD


int Exec_setStdout(const char *cmd, const char *_stdout)
{
  printf("cmd: %s, out: %s\n", cmd, _stdout);

  if(_stdout == NULL || strlen(_stdout) == 0 ) {
    char buf[256];
    sprintf(buf, "%s.out", cmd);
    int fd = open(buf, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if(fd == -1){
      printf("Error: open(%s), %s\n", buf, strerror(errno));
      return -1;
    }
    close(STDOUT_FILENO);
    int dup_fd = dup2(fd, STDOUT_FILENO);
    if(dup_fd==-1) {
      printf("Error: %s\n", strerror(errno));
      return -1;
    }

    sprintf(buf, "%s.err", cmd);
    fd = open(buf, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if(fd == -1){
      printf("Error: open(%s), %s\n", buf, strerror(errno));
      return -1;
    }
    close(STDERR_FILENO);
    dup_fd = dup2(fd, STDERR_FILENO);
    if(dup_fd==-1) {
      printf("Error: %s\n", strerror(errno));
      return -1;
    }

    return 0;
  }

  if(strcmp(_stdout, "--window")){
    int fd = open(_stdout, O_WRONLY);
    if(fd == -1){
      printf("Error: open(%s), %s\n", _stdout, strerror(errno));
      return -1;
    }
    close(STDOUT_FILENO);
    int dup_fd = dup2(fd, STDOUT_FILENO);
    if(dup_fd==-1) {
      printf("Error: %s\n", strerror(errno));
      return -1;
    }
    close(STDERR_FILENO);
    dup_fd = dup2(fd, STDERR_FILENO);
    if(dup_fd==-1) {
      printf("Error: %s\n", strerror(errno));
      return -1;
    }
  }

  return 0;
}

// test port 0
extern int __socket_server(int _port, int *port, int reuse_addr);
SEXP SocketConn_startServer(SEXP port)
{
  int _port;
  int fd = __socket_server(asInteger(port), &_port, 0); 
  SEXP val = PROTECT(allocVector(INTSXP, 2));
  INTEGER(val)[0] = fd;
  INTEGER(val)[1] = _port;
  UNPROTECT(1);
  return val;
}

int X11_check()
{
  //return 0;

  // deprecated ...


  Display *display;
  int screen;
  Window win;
  //GC gc;

  display = XOpenDisplay((char *)0);
  printf("display: %p\n", display);
  if(display){
    screen = DefaultScreen(display);
    printf("screen: %d\n", screen);
    int close_mode = RetainPermanent;
    XSetCloseDownMode(display, close_mode);
    XCloseDisplay(display);
  }

  if(!display)
    basic_info("%s: %s", __func__, strerror(errno));

  return display? 0 : errno;
}

//return visible?
int X11_windows(Window window)
{
  Display *display;
  int screen;
  Window win, root;

  display = XOpenDisplay((char *)0);
  basic_info("display: %p", display);
  if(display){
    screen = DefaultScreen(display);
    basic_info("screen: %d", screen);

    root = DefaultRootWindow(display);


//    int status = XQueryTree(display, w, root_return, parent_return, children_return, nchildren_return);
    XWindowAttributes xwa;
    int status;
    /*
    status = XGetWindowAttributes(display, root, &xwa);
    basic_info("status: %d, [,]: (%d:%d, %d:%d)", status,
		    xwa.x, xwa.width, xwa.y, xwa.height);
    */

    status = XGetWindowAttributes(display, window, &xwa);
    basic_info("status: %d, [,]: (%d:%d, %d:%d)", status,
		    xwa.x, xwa.width, xwa.y, xwa.height);

    /*
    Window new_root, parent, *children;
    unsigned int nchildren;
    status = XQueryTree(display, root, &new_root, &parent, &children,
		    &nchildren);

    basic_info("status: %d, nchildren: %d", status, nchildren);
    for(unsigned int i=0; i<nchildren; i++){
      win = children[i];
    }
    */

    
    int close_mode = RetainPermanent;
    XSetCloseDownMode(display, close_mode);
    XCloseDisplay(display);
  }

  if(!display)
    basic_info("%s: %s", __func__, strerror(errno));

  return display? 0 : errno;
}

#ifndef SUPR3
int X11_stdout()
{

  //return 0;

  int use_gnome_terminal = TRUE;

  { // testing...
    //size_t size = 1024;
    //char buf[size];
    //FILE *f = fmemopen(buf, size, "w+"); 
    char template[128];
    sprintf(template, "/tmp/supr_XXXXXX");
    int fd = mkstemp(template);
    int save_stdout_fd = dup(STDOUT_FILENO);
    int save_stderr_fd = dup(STDERR_FILENO);
    if(fd != -1 ){
      dup2(fd, STDOUT_FILENO);
      dup2(fd, STDERR_FILENO);
    } else {
      printf("Error: memopen, %s\n", strerror(errno));
    }

    int rc = system("dbus-update-activation-environment --systemd --all");
    //int rc = system("dbus-update-activation-environment --systemd" " DBUS_SESSION_BUS_ADDRESS DISPLAY XAUTHORITY");
    //int rc = system("./term");

//    return rc;
    printf("dbus-update-activation-environment --systemd --all: %d\n", rc);
    if(fd != -1) {
      dup2(save_stdout_fd, STDOUT_FILENO);
      dup2(save_stderr_fd, STDERR_FILENO);
      //sleep(5);
      struct stat sb;
      fstat(fd, &sb);
      char buf[sb.st_size+1];
      buf[sb.st_size] = 0;
      lseek(fd, 0, SEEK_SET);
      read(fd, buf, sb.st_size);
      printf("Stdout/Stderr: %s\n", buf);
      close(fd);
      unlink(template);

      if(strstr(buf, "Error") || strstr(buf, "error"))
      {
        printf("\033[0;31mStdout/Stderr: %s\033[0m\n", buf);
        use_gnome_terminal = FALSE;
      }
    }
    printf("dbus-update-activation-environment --systemd --all: %d\n", rc);
  }


  int pipe_fd[2];
  pipe(pipe_fd);
  //
  pid_t pid = fork();
  if(pid == -1){
    perror(__func__);
    return -1;
  }
  if(pid) {
    close(pipe_fd[0]);
    return pipe_fd[1];
		 // pid;
  }

  close(pipe_fd[1]);
  //

  /*
  {
    R_segvAct.sa_sigaction = Worker_SigactionSegv;
    sigemptyset(&R_segvAct.sa_mask);
    R_segvAct.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &R_segvAct, &R_oldSegvAct);
  }
  */

  Display *display;
  int screen;
  Window win;
  XEvent e;

  //const char *msg = "Hello, World";
  const char *msg = Supr_hostname;

  display = XOpenDisplay((char *)0);

  fprintf(stderr, "display: %p\n", display);

  if(!display) return -1;

  //int fd = ConnectionNumber(display);

  Atom _XA_WM_PROTOCOLS = XInternAtom(display, "WM_PROTOCOLS", 0);

  //int close_mode = RetainPermanent;
  //XSetCloseDownMode(display, close_mode);

  screen = DefaultScreen(display);

  win = XCreateSimpleWindow(display, RootWindow(display, screen),
		  10, 10, 100, 80, 1,
              BlackPixel(display, screen), WhitePixel(display, screen));
   //XSelectInput(display, win, ExposureMask | KeyPressMask);
   XSelectInput(display, win, ExposureMask | KeyPressMask | StructureNotifyMask);
   XMapWindow(display, win);

   //sleep(500); return 0;

   //sleep(5);
   int done = FALSE;
   while (1) {
      fprintf(stderr, "next event: ...\n");
      XNextEvent(display, &e);
      fprintf(stderr, "next event.type: %d\n", e.type);
      if (e.type == Expose) {
         XFillRectangle(display, win, DefaultGC(display, screen),
			 20, 20, 10, 10);
         XDrawString(display, win, DefaultGC(display, screen), 10, 50, msg, strlen(msg));
         fprintf(stderr, "event.type: %d\n", e.type);
         //sleep(2); break;
//	 done = TRUE;
      }
      if(e.type == DestroyNotify){
         break;
      }
      if((e.type == ClientMessage) &&
             (e.xclient.message_type == _XA_WM_PROTOCOLS)){
        XFillRectangle(display, win, DefaultGC(display, screen),
			 20, 100, 20, 20);
	printf("event.type: %d, e.xclient.message_type: %ld\n", e.type,
			e.xclient.message_type);
	//break;
      }
      if(e.type == ClientMessage){
        XFillRectangle(display, win, DefaultGC(display, screen),
			 20, 100, 20, 20);
	printf("event.type: %d\n", e.type);
	//break;
      }

      fprintf(stderr, "event.type: %d\n", e.type);

      //sleep(100); break;

      //break;
      //
      /*
      while(done) {
        int cmd;
	fprintf(stderr,"read: ...\n");
	size_t size = read(pipe_fd[0], &cmd, INT_SIZE);

        XFillRectangle(display, win, DefaultGC(display, screen),
			 20, 100, 10, 10);
	fprintf(stderr, "cmd: %d, size: %ld\n", cmd, size);
	if(size == -1)
	  fprintf(stderr, "Error: %s\n", strerror(errno));
	if(size == INT_SIZE && cmd == 0)
	  break;
	sleep(5);
      }

      if(done) break;
      */
      //
      /*
      if (e.type == KeyPress)
         break;
	 */
   //   break;
   }

   // XCloseDisplay(display);
   //XFreeGC(display, gc);
	XDestroyWindow(display,win);
	XCloseDisplay(display);
	exit(1);

   return 0;
}
#endif

void Exec_freeArgs(char **argv)
{
  for(int i=0; argv[i]; i++) free(argv[i]);
  free(argv);
}

char **Exec_createArgs(const char **argv_b, SEXP args)
{
  int n=1; // terminating NULL
  for(int i=0; argv_b[i]; i++) n++; 

  SEXP s = args;
  while(s != R_NilValue){
    SEXP tag = TAG(s);
    if(tag != R_NilValue) 
	    n++;
    n++; 
    s = CDR(s);
  }

  char **argv = (char**) malloc(sizeof(char*)*n);
  n=0;
  for(int i=0; argv_b[i]; i++) argv[n++] = strdup(argv_b[i]); 

  s = args;
  while(s != R_NilValue){
    SEXP tag = TAG(s);
    char buf[256];
    if(tag != R_NilValue) {
      sprintf(buf, "-%s", CHAR(PRINTNAME(tag)));
      argv[n++] = strdup(buf);
    }
    argv[n++] = strdup(CHAR(asChar(CAR(s))));
    s = CDR(s);
  }

  argv[n++] = NULL;

  return argv;
}


// for Thread_dumpStack?
/*
#define _GNU_SOURCE
#define __USE_GNU
#include <dlfcn.h>
*/


/*
#define print_caller_info(which)        \
do {    \
   Dl_info __info__;    \
   int __rc__ = dladdr(__builtin_return_address(which), &__info__);     \
   printf("[%d] fun: %s\n", getpid(), __info__.dli_sname);      \
} while (0)
*/

//void print_callerInfo(int BT_SIZE);
/*
void print_callerInfo(int BT_SIZE) 
{
  void    *array[BT_SIZE];
  int   size, i;
  char   **strings;
  size = backtrace(array, BT_SIZE);
  strings = backtrace_symbols(array, size);
  for (i = 1; i < size; i++) {
    fprintf("\t%2d. %s\n", strings[i]);
  }
}
*/

// R_ToplevelExec is "public"
// static SEXP sOptions = NULL;
//    if(!sOptions) sOptions = install(".Options");
//    return sOptions;

//supr_context_t *__supr_context = NULL;

/*
vector_t *threads = NULL;
vector_t *sys_threads = NULL;
vector_t *dcl_threads = NULL;
*/


hashtable_t *Thread_C_SharedObjects = NULL;
SEXP Thread_R_SharedEnv = NULL;

supr_socket_conn_t *msg_serverSocketConn = NULL;

static SEXP _ThreadEnv = NULL;

extern SEXP *R_PPStack;

static void *(*Sys_switch)(void *data) = NULL;

static pthread_mutex_t OS_system_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  OS_system_cond = PTHREAD_COND_INITIALIZER;

static int Supr_display_message = TRUE;

static int Supr_initialized();
int supr_init();
//static int supr_finalize();
extern void __supr_malloc_finalize();

void (*__supr_cleanup)(void) = NULL;

//#define _GNU_SOURCE
#define __USE_GNU
#include <dlfcn.h>



static int Supr_nCallsFromConsoleToBusy = -1;

static void tmp_R_Busy(int which){
  //fprintf(stderr, "which: %d\n", which); which should be 1
  Dl_info __info__;
  int __rc__;
  void *addr;

  addr = __builtin_return_address(0);
  if(!addr) return;
  __rc__ = dladdr(addr, &__info__);
  /*
  fprintf(stderr, "\033[0;32maddr: %p, fun: %s (%s:%d)\033[0m\n",
     addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n",
                  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);
		  */

  if(Rf_ReplIteration == __info__.dli_saddr) {
    Supr_nCallsFromConsoleToBusy = 0;
    return;
  }


  addr = __builtin_return_address(1);
  if(!addr) return;
  __rc__ = dladdr(addr, &__info__);
  /*
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n",
                  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);
		  */

  if(Rf_ReplIteration == __info__.dli_saddr) {
    Supr_nCallsFromConsoleToBusy = 1;
    return;
  }

  addr = __builtin_return_address(2);
  if(!addr) return;
  __rc__ = dladdr(addr, &__info__);
  /*
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n",
                  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);
		  */

  if(Rf_ReplIteration == __info__.dli_saddr) {
    Supr_nCallsFromConsoleToBusy = 2;
    return;
  }

  addr = __builtin_return_address(3);
  if(!addr) return;
  __rc__ = dladdr(addr, &__info__);
  /*
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n",
                  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);
		  */

  if(Rf_ReplIteration == __info__.dli_saddr) {
    Supr_nCallsFromConsoleToBusy = 3;
    return;
  }

  addr = __builtin_return_address(4);
  if(!addr) return;
  __rc__ = dladdr(addr, &__info__);
  /*
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n",
                  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);
		  */

  if(Rf_ReplIteration == __info__.dli_saddr) {
    Supr_nCallsFromConsoleToBusy = 4;
    return;
  }

  /*
  addr = __builtin_return_address(5);
  if(!addr) return;
  __rc__ = dladdr(addr, &__info__);
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n",
                  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);
		  */



}


int R_ReadConsole(const char *prompt, unsigned char *buf, int len, int addtohistory);
extern int (*ptr_R_ReadConsole)(const char *prompt, unsigned char *buf, int len, int addtohistory);
static int (*save_ptr_R_ReadConsole)(const char *prompt, unsigned char *buf, int len, int addtohistory);

extern void (*ptr_R_ResetConsole)(void);
extern void (*ptr_R_FlushConsole)(void);
extern void (*ptr_R_ClearerrConsole)(void);
// FIXME
//void Supr_run(int busy);

static int Supr_running = FALSE;

static int SupR_ReadConsole(const char *prompt, unsigned char *buf, int len,
	       	int addtohistory)
{
  //fprintf(stderr, "SupR_ReadConsole: %p\n", ptr_R_ReadConsole);
  //if(main_thread) { R_SetSyncEvalLock(FALSE); } else { __FIXME__("mutex_unlock"); }
  // See myReplConsole
  {
	
      SEXP sleepVar = findVar(install("sleepVar"), R_GlobalEnv);
      if(sleepVar == R_UnboundValue){
         fprintf(stderr, "\033[0;31mSupR_ReadConsole: sleepVar == R_UnboundValue\n");
      } else sleep(300);

  }


  if(Supr_verbose) {
    fprintf(stderr, "\033[0;31mSupR_ReadConsole: %p\n", ptr_R_ReadConsole);
    fprintf(stderr, "\033[0;31mSupR_ReadConsole: BUSY\033[0m\n");
  }

  if(!Supr_running){
      Supr_running = TRUE;
      ptr_R_Busy = __R_Busy;
      if(Supr_verbose)
        fprintf(stderr, "\n[INFO] run Thread_main_run_Rmainloop...\n");

      // FIXME-FIXME
      int rc = Thread_main_run_Rmainloop();

      if(Supr_verbose)
        fprintf(stderr, "\033[0;31m[%s] [INFO] return to R (%s:%d)\033[0m\n",
		       	__func__, __FILE__, __LINE__);
      if(R_Interactive)
      {
        //int retval = 1;
//	snprintf(buf, len, "library.dynam.unload(\"libsupr\", \"%s\")\n", Supr_sysHome);
	snprintf(buf, len, "message(\"----\n\")\n");
        return 1; //retval;
      }
      Supr_running = FALSE;
  }

  if(Supr_verbose)
    fprintf(stderr, "[%s] [INFO] return to R (%s:%d)\n", __func__, __FILE__, __LINE__);


  int retval = save_ptr_R_ReadConsole(prompt, buf, len, addtohistory);

  //if(main_thread) { R_SetSyncEvalLock(TRUE); } 

  return retval;
}

static void SupR_ResetConsole(void)
{
  //fprintf(stderr, "%s call: %p\n", __func__, save_R_ResetConsole);
  save_R_ResetConsole();
}

static void SupR_FlushConsole(void)
{
  //fprintf(stderr, "%s call: %p\n", __func__, save_R_FlushConsole);
  save_R_FlushConsole();
}

/*
 See R:src/main/errors.c and context.c
 in stop -> errorcall -> verrorcall_dflt 
 -> jump_to_top_ex(traceback=TRUE, tryUserHandler=TRUE, processWarnings=TRUE,
                   resetConsole=TRUE, FALSE) 
 -> (R_ClearerrConsole, R_jumpctxt(R_ToplevelContext, 0, NULL))
 -> R_jumpctxt -> (R_restore_globals, LONGJMP(cptr->cjmpbuf, mask))
*/

static void SupR_ClearerrConsole(void)
{
  if(Supr_verbose) {// FIXME?
    fprintf(stderr, "\n%s is called before R_restore_globals\n", __func__);
    fprintf(stderr, "%s call: %p\n", __func__, save_R_ClearerrConsole);
    // check if it is called after restore ...
    //c_backtrace();
    printf("\033[0;31mRe-restore R_BCNodeStackTop etc ...\n");
    fprintf(stderr, "R_GlobalContext: %p\n", R_GlobalContext);

    supr_thread_t *cth = currentThread();
    fprintf(stderr, "save_R_BCNodeStackTop (pos): %ld\n",
		    cth->save_R_BCNodeStackTop-__R_BCNodeStackBase);
    fprintf(stderr, "     R_BCNodeStackTop (pos): %ld\n",
	 	    R_BCNodeStackTop - __R_BCNodeStackBase);
    R_BCNodeStackTop =  cth->save_R_BCNodeStackTop;

    fprintf(stderr, "R_ToplevelContext->nodestack (pos): %ld\n",
	 	    __R_ToplevelContext->nodestack - __R_BCNodeStackBase);


    // checking/testing cth->R_ToplevelContext
 
    for(RCNTXT *cntxt_ptr = R_GlobalContext; cntxt_ptr; 
		    cntxt_ptr = cntxt_ptr->nextcontext){
      
      fprintf(stderr, "\tcntxt: %p\n", cntxt_ptr);

      if(cntxt_ptr == cth->R_ToplevelContext)
	      break;
    }

    myR_simpleTraceback();

    fprintf(stderr, "cth->R_ToplevelContext->nodestack (pos): %ld\n",
	 	    cth->R_ToplevelContext->nodestack - __R_BCNodeStackBase);
    fprintf(stderr, "\n\033[0m");
  }

  //fprintf(stderr, "%d sleep(120)\n", getpid());
  //sleep(120);


  save_R_ClearerrConsole();
}

static RCNTXT __SupR_ToplevelContext;
static void Supr_save_R_ToplevelContext()
{
  RCNTXT *top_ptr = R_GlobalContext;
  while(top_ptr->nextcontext)
    top_ptr = top_ptr->nextcontext; 

  RCNTXT *save = &__SupR_ToplevelContext;

  // Serr R_restore_globals(RCNTXT *cptr) @ R:src/main/context.c
  save->cstacktop = top_ptr->cstacktop;
  save->gcenabled = top_ptr->gcenabled;
  save->bcintactive = top_ptr->bcintactive;
  save->bcpc = top_ptr->bcpc;
  save->bcbody = top_ptr->bcbody;
  save->evaldepth = top_ptr->evaldepth;
  save->vmax = top_ptr->vmax;
  save->intsusp = top_ptr->intsusp;
  save->handlerstack = top_ptr->handlerstack;
  save->restartstack = top_ptr->restartstack;
  save->prstack = top_ptr->prstack;
  save->nodestack = top_ptr->nodestack;
  save->srcref = top_ptr->srcref;
}

/*
static void Supr_setUsrHome(){

  if(!Supr_usrHome){
    Supr_usrHome = getenv("SUPR_USE_HOME");
    if(!Supr_usrHome) {
      SEXP usrHome = findVar(install(".SuprContext"), R_GlobalEnv);
      if(usrHome != R_UnboundValue){
        if(TYPEOF(usrHome) != LISTSXP){
		PrintValue(usrHome);
          defineVar(install(".SuprContext"), R_UnboundValue, R_GlobalEnv);
	  warning(_("removed object '.SuprContext', unexpected type"));
          usrHome = R_NilValue;
	}
        while(usrHome != R_NilValue){
          if(TAG(usrHome) != R_NilValue){
            if(strcmp(CHAR(PRINTNAME(TAG(usrHome))),"usr.home")==0){
              Supr_usrHome = strdup(CHAR(asChar(CAR(usrHome))));
	      break;
	    }
	  }
	  usrHome = CDR(usrHome);
	}
      }

      if(!Supr_usrHome) {
	const char *home = getenv("HOME"); // define USER_HOME "HOME"
        Supr_usrHome = (char*) malloc(strlen(home) + strlen(".supr")+2);
	sprintf(Supr_usrHome, "%s/%s", home, ".supr");
	DIR *dir = opendir(Supr_usrHome);
        if(!dir){
          if(mkdir(Supr_usrHome, 0700)==-1){
            error(_("%s, %s"), Supr_usrHome, strerror(errno));
	  }
	} else {
	  closedir(dir);
	}	
      }

    }
  }

}
*/

static void Supr_setR_BCNodeStackBase()
{
      RCNTXT *top_ptr = R_GlobalContext;

      while(top_ptr->nextcontext)
	      top_ptr  = top_ptr->nextcontext;

      __R_BCNodeStackBase = top_ptr->nodestack;
}

static int R_isInitialized()
{
  if(Supr_verbose) {
    fprintf(stderr, "Using this value to detect R_Initialized?) R_TrueValue: %p\n",
		    R_TrueValue);
  }

  //return R_TrueValue != NULL;
  return R_TrueValue != R_FalseValue;
}

static void Supr_sysHomeInit()
{
  char *shell = getenv("SHELL");
  //fprintf(stderr, "SHELL=%s\n", shell);
  char *home = getenv("HOME");
  //fprintf(stderr, "HOME=%s\n", home);
  char path[PATH_MAX];
  sprintf(path, "%s/.suprrc", home);
  int fd = open(path, O_RDONLY);
  struct stat sb;
  int rc;
  if(fd == -1 || (rc = fstat(fd, &sb))==-1) {
    fprintf(stderr, "Error: %s\n", strerror(errno));
    return;
  }
  char buf[sb.st_size+1];
  ssize_t n = read(fd, buf, sb.st_size);
  if(n != sb.st_size){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    return;
  }
  close(fd);
  buf[sb.st_size] = 0;
  //fprintf(stderr, "%s:\n", path);
  //fprintf(stderr, "%s", buf);
  char *sys = strstr(buf, "SUPR_SYS_HOME=");
  if(!sys){
    fprintf(stderr, "Error: damaged .suprrc file\n");
    return;
  }

  sys += strlen("SUPR_SYS_HOME=");
  char *s = sys;
  char *t = sys;
  while(*s && !isspace(*s)){
    if(*s != '"'){
      *t = *s;
      t++;
    }
    s++;
  }
  *t = 0;
  Supr_sysHome = strdup(sys);
  //fprintf(stderr, "[%s] Supr_sysHome: %s\n", __func__, Supr_sysHome);
  //fprintf(stderr, "[INFO] version: supr2_%s\n", SUPR_VERSION_STRING);
  //fprintf(stderr, "[INFO] libPath: %s\n", Supr_sysHome);
}


extern int nextFreePort(int port);

//Socket_timed_read
ssize_t timed_read(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec = (int) Supr_options.timeout;
      tv.tv_usec=0;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
              if(ns == 0) {
                //      errno = EWOULDBLOCK;
                // error_info(strerror(errno));
                error_info("[timeout] gdb -p %d; gdb -p %d", getpid(), gettid());
		errno = ETIMEDOUT;
                return -1;
              } else {
                error_info(strerror(errno));
                return -1;
              }
      }
    }

    ssize_t n = read(fd, buf + len,  size - len);

    if(n <= 0){
      char err[256];
      sprintf(err, "read, n = %ld, %s\n", n, strerror(errno));
      error_info(err);
      return -1;
    }


    len += n;
  }
  return size;
}


// if(conn) fd = conn->fd
int Supr_checkLogin(int sockfd, supr_socket_conn_t *conn, char *server)
{
  //int Conn_confirm_send(int sockfd, char *buf, int len)
  if(Supr_login){
	  int len = strlen(Supr_login)+1;
	  int msg[2] = {CLUSTER_LOGIN, len};
          write(sockfd, msg, sizeof(msg));
          write(sockfd, Supr_login, len);
          int rc;
          ssize_t size = timed_read(sockfd, &rc, sizeof(int));
          if(size == sizeof(int) && rc == 0) {
            basic_info("[%s %s: %s%d] \033[0;32mSUCCESS\033[0m\n",
	      __func__, server, conn? conn->host:"", conn? conn->port : -1);
            return 0;
	  } else {
                  basic_info("size: %ld, rc: %d", size, rc);
                  //close(sockfd);
                  //return -1;
          }

  } else {
	  error_info("login: %s", Supr_login);
  }

  basic_info("[%s %s: %s%d]\n"
	      "\tcmd: %s, pid: %d, verify: \033[0;31mFAILURE\033[0m",
	      __func__, server, conn? conn->host:"", conn? conn->port : -1,
	      proc_cmd, getpid()//, Supr_login
	      );
  return -1;
}

int Supr_handleCommand(int cmd, supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  switch(cmd){
    case CLUSTER_LOGIN:
         {
           int msg[2]; // {cmd, len}
           ssize_t size = read(fd, msg, sizeof(msg));
	   int len = msg[1];
	   char login[len];
           size = read(fd, login, len);
	   int rc = 0;
	   if(Supr_login){
	     if(strcmp(Supr_login, login)==0){
               size = write(fd, &rc, sizeof(int));
	     } else {
               error_info("%s: wrong login/username %s", __func__, login);
	       rc = -1;
               size = write(fd, &rc, sizeof(int));
	       return -1;
	     }
	   } else {
             size = write(fd, &rc, sizeof(int));
	   }
	 }
	 return 0;
    default: break;
  }
  return cmd;
}

void String_class_init();
void suprHomeInit();

void Supr_createConfigTemplate()
{
// fprintf(stderr, "\t\033[0;32m* %s\033[0m\n", __func__);
// fprintf(stderr, "\t\033[0;32m* useHome: %s\033[0m\n", Supr_usrHome);

 char path[PATH_MAX];
 sprintf(path, "%s/supr.conf", Supr_usrHome);
 if(access(path, F_OK)==0) {
//   fprintf(stderr, "[INFO] found configuration file: %s\033[0m\n", path);
	 return;
 } else {
    fprintf(stderr, "\033[0;31m[WARNING] cannot find Supr_usrHome: %s\033[0m\n", Supr_usrHome);
    if(access(Supr_usrHome, F_OK)) {
      DIR *dir = opendir(Supr_usrHome);
      if(!dir){
        warning(_("opendir('%s'), %s"), Supr_usrHome, strerror(errno));
	if(mkdir(Supr_usrHome, 0700)==-1){
           error(_("%s, %s"), Supr_usrHome, strerror(errno));
        }
      }
      closedir(dir);
    }
 }

 FILE *fs = fopen(path, "w");
 if(!fs){
   fprintf(stderr, "Error in fopen(%s), %s\n", path, strerror(errno));
 }
 
 fprintf(stderr, "[INFO] create config tempplate: %s\033[0m\n", path);

 int port = nextFreePort(1023);
 fprintf(fs, "Namenode //%s:%d?data={\n", Supr_hostname, port);
 fprintf(fs, "\t%s/dfs_name/%s\n", Supr_usrHome, Supr_hostname);
 fprintf(fs, "}\n\n");

 port = nextFreePort(port);
 fprintf(fs, "Datanode //%s:%d?data={\n", Supr_hostname, port);
 fprintf(fs, "\t%s/dfs_data/%s\n", Supr_usrHome, Supr_hostname);
 fprintf(fs, "}\n\n");

 port = nextFreePort(port);
 fprintf(fs, "Master //%s:%d\n", Supr_hostname, port);
 port = nextFreePort(port);
 fprintf(fs, "Driver //%s:%d\n\n", Supr_hostname, port);

 port = nextFreePort(port);
 fprintf(fs, "Worker //%s:%d\n\n", Supr_hostname, port);
 port = nextFreePort(port);
 fprintf(fs, "Infonode //%s:%d\n\n", Supr_hostname, port);
 port = nextFreePort(port);
 fprintf(fs, "Filetransfer //%s:%d\n\n", Supr_hostname, port);

 fprintf(fs, "ThreadServers {\n");
 port = nextFreePort(port);
 fprintf(fs, "\t%s:%d\n", Supr_hostname, port);
 fprintf(fs, "}\n\n");

 fprintf(fs, "TrustedHosts {\n");
 fprintf(fs, "\t%s\n", Supr_hostname);
 fprintf(fs, "}\n\n");

 fclose(fs);
}
// note: R-4.0.0 introduced R_BCProtTop, initilaized to be R_BCNodeStackTop (?)

#define USE_USERNAME_FOR_SECURITY

// initialized in dl_init
vector_t *cleanups = NULL;

// take a look at /proc/self/maps ?
// use argv[0]
void __attribute__ ((constructor)) __dl_init(void)
{
  // main_pid = getpid();
  //atexit(doCleanups);

  __supr_malloc_init__();

  if(cleanups)
    error_info("FIXME");
  else
    cleanups = newVector(TRUE);

  if(Supr_hostname == NULL){
    char hostname[256];
    int rc = gethostname(hostname, sizeof(hostname));
    if(rc == -1) perror(__func__);
    else  {
      Supr_hostname = (char*) malloc(strlen(hostname)+1);
      memcpy(Supr_hostname, hostname, strlen(hostname)+1);
    }
  }

  Supr_options.ncpu = sysconf(_SC_NPROCESSORS_ONLN);

  Supr_options.timeout = 60.0;

  Supr_sysHomeInit(); // testing...
  suprHomeInit();

  Supr_createConfigTemplate();

  // find the default info server from the supr.conf
  char path[PATH_MAX];

  sprintf(path, "%s/supr.conf", Supr_usrHome);
  int fd = open(path, O_RDONLY);

  if(fd == -1)
    error(_("%s, %s"), path, strerror(errno));

  struct stat sb;
  if(fstat(fd, &sb) == 0){
    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    close(fd);
    char *in_ptr = strstr(buf, "Infonode");
    if(in_ptr) {
       in_ptr+=2;
       Supr_defaultInfonode = in_ptr+2;
       while(*in_ptr != '\n' && *in_ptr != '\t' && *in_ptr != ' ')
         in_ptr++;
       *in_ptr = 0;
       Supr_defaultInfonode = strdup(Supr_defaultInfonode);
    }

  }

  //if(!Supr_username)
  {

        uid_t uid = getuid();
        //fprintf(stderr, "getuid: %d\n", uid);
        errno = 0;
        struct passwd *pw_ptr = getpwuid(uid);

        if(pw_ptr){
          //fprintf(stderr, "username: %s\n", pw_ptr->pw_name);
          //fprintf(stderr, "user password: %s\n", pw_ptr->pw_passwd);
          //fprintf(stderr, "home directory: %s\n", pw_ptr->pw_dir);
          //fprintf(stderr, "shell program: %s\n", pw_ptr->pw_shell);
          //fprintf(stderr, "...\n");

          char *login = pw_ptr->pw_name;
          Supr_username = (char*) malloc(strlen(login)+1);
          memcpy(Supr_username, login, strlen(login)+1);
          basic_info("username: %s", Supr_username);
        }

  }



  if(!Supr_username) {
    char login_r[256];
    int rc = getlogin_r(login_r, sizeof(login_r));
    char *login = login_r;
    if(rc != 0) {
            /*
      fprintf(stderr, "Error: getlogin_r, %s\n", strerror(rc));
      fprintf(stderr, "Error: getlogin_r, %s\n", strerror(errno));
      login = NULL;
      */
      //fprintf(stderr, "Error: getlogin_r, %s\n", strerror(rc));
      fprintf(stderr, "Error: getlogin_r, %s\n", strerror(errno));
      //login = NULL;
      login = getlogin();
      fprintf(stderr, "getlogin(): %s\n", login);
      if(!login) {
         login =getenv("USER");
         fprintf(stderr, "getenv(\"USER\"): %s\n", login);
      }

      if(login){
        Supr_username = (char*) malloc(strlen(login_r)+1);
        memcpy(Supr_username, login_r, strlen(login_r)+1);
        basic_info("username: %s", Supr_username);
      }

    } else {
      Supr_username = (char*) malloc(strlen(login_r)+1);
      memcpy(Supr_username, login_r, strlen(login_r)+1);
      basic_info("username: %s", Supr_username);
    }
  }

  if(!Supr_username) {
      error_info("'username' not found");
  }

#ifdef USE_USERNAME_FOR_SECURITY
  { // use Supr_usrHome/passphrase if exists
    char path[PATH_MAX];
    sprintf(path, "%s/passphrase", Supr_usrHome);
    int fd = open(path, O_RDONLY);
    if(fd > 0){
      // basic_info("found the passphrase file: %s", path);
      struct stat sb;
      if(fstat(fd, &sb) == 0){
        char buf[sb.st_size+1];
        read(fd, buf, sb.st_size);
        close(fd);
	char *s = strstr(buf, "\n");
	if(s) *s = 0;
        Supr_login = (char*) malloc(strlen(buf)+1);
        memcpy(Supr_login, buf, strlen(buf)+1);
        //basic_info("login/passphrase: %s", Supr_login);
      } else {
        error_info("%s: %s", path, strerror(errno));
      }
    }
  }

  if(!Supr_login) 
    Supr_login = Supr_username;
#endif // USE_USERNAME_FOR_SECURITY

//	{ SuprError_setDevice("/dev/pts/5"); }
  //supr_init();
/*
  if(R_VERSION_MAJOR_NUM >= 4){
    fprintf(stderr, "Warning: no sufficient testing was done on R-%s\n",
		    R_VERSION_STRING);
  }
*/
  //__supr_malloc_init__();

  String_class_init();

  Supr_curErrorBuf_size = 1024;
  Supr_curErrorBuf = malloc(Supr_curErrorBuf_size);

  char buf[64];
  sprintf(buf, "supr-%d", geteuid());
  shm_prefix = strdup(buf);

  //fprintf(stdout, "\033[0m\n");

  pthread_key_create(&sigusr2HandlerKey, NULL);
 
  if(Supr_argv == NULL) {
    FILE *cmdline = fopen("/proc/self/cmdline", "r");
    if(cmdline){
      int c;
      size_t size = 0;
      for(;;){
        c = fgetc(cmdline);
        size++; // printf(" %d", c);
        if(c==-1) break;// putchar(c);

      }
      //printf("\n");

      rewind(cmdline);
      char *cmd = (char*) malloc(size);
      size = 0;
      int argc = 0;
      for(;;){
        c = fgetc(cmdline);
        if(c==-1) {
          cmd[size++] = 0;
          break;
        } else if(c==0) {
          argc++;
        }
        cmd[size++] = c;
      }
      fclose(cmdline);

      //char *argv[argc];
      Supr_argv = (char**) malloc((argc+1) * sizeof(char *));
      char *arg = cmd;
      int i=0;
      for(; *arg; i++){
        Supr_argv[i] = strdup(arg);
	if(Supr_verbose)
          fprintf(stderr, "\033[033m[%d] __dl_init: %d. %s, R_Interactive: %d\033[0m\n",
		       	getpid(), i, Supr_argv[i], R_Interactive);
        arg += strlen(arg)+1; 
      }
      Supr_argv[i] = NULL;
      free(cmd);
    }
  }

#ifdef LD_INIT_DO_THREAD_INIT

  if(Supr_verbose)
     fprintf(stderr, "\033[032m[%s] cmd: %s (==\"R\"?)\033[0m\n", __func__,
		  Supr_argv[0] + strlen(Supr_argv[0])-1);

  //if(Supr_verbose) { fprintf(stderr, "Using this value to detect R_Initialized?) R_TrueValue: %p\n", R_TrueValue); }
  //if(R_GlobalContext)
  //if(strcmp(Supr_argv[0] + strlen(Supr_argv[0])-1,"R")==0)
  
  R_bcstack_t *tmp_R_BCNodeStackBase = NULL;
  
  if(R_isInitialized())
  {
    save_R_Busy = ptr_R_Busy;

    if(Supr_verbose) {
       fprintf(stderr, "R_VERSION_STRING: %s\n", R_VERSION_STRING);
       fprintf(stderr, "R is initialized\n");
       fprintf(stderr, "__R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);
    }
    //{

#ifndef SUPR3
      RCNTXT *top_ptr = R_GlobalContext;

      while(top_ptr->nextcontext)
	      top_ptr  = top_ptr->nextcontext;

      __R_BCNodeStackBase = top_ptr->nodestack;

      tmp_R_BCNodeStackBase = __R_BCNodeStackBase;
//      __R_BCNodeStackBase -= 15;
#endif
          
    //}

    if(Supr_verbose) 
       fprintf(stderr, "__R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);

    {
      if(Supr_verbose)
        fprintf(stderr, "ptr_R_ReadConsole: %p\n", ptr_R_ReadConsole);

#ifdef SUPR3
      save_ptr_R_ReadConsole = ptr_R_ReadConsole;

      save_R_ResetConsole = ptr_R_ResetConsole;
      save_R_FlushConsole = ptr_R_FlushConsole;
      save_R_ClearerrConsole = ptr_R_ClearerrConsole;
#else
      save_ptr_R_ReadConsole = ptr_R_ReadConsole;
      ptr_R_ReadConsole = SupR_ReadConsole;

      save_R_ResetConsole = ptr_R_ResetConsole;
      save_R_FlushConsole = ptr_R_FlushConsole;
      save_R_ClearerrConsole = ptr_R_ClearerrConsole;

      ptr_R_ResetConsole = SupR_ResetConsole;
      ptr_R_FlushConsole = SupR_FlushConsole;
      ptr_R_ClearerrConsole = SupR_ClearerrConsole;
#endif


    }

    if(Supr_verbose) {
      fprintf(stderr, "\033[0;32mR_BCNodeStackEnd: %p\n", R_BCNodeStackEnd);
      fprintf(stderr, "SIZE (? == 200000): %ld\n", R_BCNodeStackEnd - __R_BCNodeStackBase);
      fprintf(stderr, "R_BCNodeStackTop: %p\n", R_BCNodeStackTop);
      fprintf(stderr, "StackTop/Position: %ld\033[0m\n",
		      R_BCNodeStackTop - __R_BCNodeStackBase);
    }

    R_thread_init();
  }
//  else { printf("R_GlobalContext: %p\n", R_GlobalContext); }
#endif
 
/*
  if(Supr_verbose) {
//      __R_BCNodeStackBase -= 15;
//      R_BCNodeStackTop -= 15;
    fprintf(stderr, "tmp_R_BCNodeStackBase: %p\n", tmp_R_BCNodeStackBase);
    fprintf(stderr, "diff: %ld\n", tmp_R_BCNodeStackBase - __R_BCNodeStackBase);
    fprintf(stderr, "__R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);
    fprintf(stderr, "R_BCNodeStackEnd: %p\n", R_BCNodeStackEnd);
    fprintf(stderr, "R_BCNodeStackTop: %p\n", R_BCNodeStackTop);
    fprintf(stderr, "SIZE (? == 200000): %ld\n", R_BCNodeStackEnd - __R_BCNodeStackBase);
    fprintf(stderr, "SIZE (? == 200000 tmp): %ld\n", R_BCNodeStackEnd - tmp_R_BCNodeStackBase);
  }
*/

  if(Supr_usrHome)
    Supr_dfsHome = strdup(Supr_usrHome);

  for(int i=0; Supr_argv[i]; i++){
    if(strcmp(Supr_argv[i], "-usr")==0 && Supr_argv[++i]){
      Supr_usrHome = Supr_argv[i];
    } else if(strcmp(Supr_argv[i], "-sys")==0 && Supr_argv[++i]){
      Supr_sysHome = Supr_argv[i];
    } else if(strcmp(Supr_argv[i], "-dfs")==0 && Supr_argv[++i]){
      Supr_dfsHome = Supr_argv[i];
    } else if(strcmp(Supr_argv[i], "-verbose")==0 && Supr_argv[++i]){
      Supr_verbose = *Supr_argv[i] == 'T';
    } else if(strcmp(Supr_argv[i], "--verbose")==0){
      Supr_verbose = TRUE;
    }
  }

  if(Supr_argv && Supr_argv[0]) {
    cmd = Supr_argv[0];
    proc_cmd = cmd;
    while(strstr(proc_cmd, "/"))
      proc_cmd = strstr(proc_cmd, "/") + 1;
    //fprintf(stderr, "proc_cmd: %s\n", proc_cmd);
  }

  if(Supr_verbose) {
    printf("[%s] Supr_sysHome: %s\n", __func__, Supr_sysHome);
    printf("[%s] SUPR_HOMESYS: %s\n", __func__, SUPR_HOMESYS);
  }
 // printf("save_R_Busy: %p\n", save_R_Busy);
  if(Supr_verbose) {
    printf("[INFO] libsupr.so is initialized\n");
//    printf("[INFO] R_BCNodeStackPos: %ld\n", R_BCNodeStackPos);
    fflush(stdout);
  }

  sys_threads = newVector(TRUE);
  messages = newVector(TRUE);

}

// Experiment:
// keep R in the SupR mode, as long as libsupr.so is loaded
// 


SEXP Supr_last();

void __attribute__ ((destructor)) __dl_fini(void)
{
  //fprintf(stdout, "\033[0m\n");

  Supr_last();
  //supr_finalize();
  //
	/*
  __supr_malloc_finalize();
  if(__supr_cleanup) __supr_cleanup();
  for(int i=0; Supr_argv[i]; i++){
    printf("[%d-%ld] %d. %s\n", getpid(), syscall(SYS_gettid), i, Supr_argv[i]);
  }
  */

  pthread_key_delete(sigusr2HandlerKey);

  ptr_R_ReadConsole = save_ptr_R_ReadConsole;
  ptr_R_ResetConsole = save_R_ResetConsole;
  ptr_R_FlushConsole = save_R_FlushConsole;
  ptr_R_ClearerrConsole = save_R_ClearerrConsole;

  if(Supr_verbose) {
    printf("[cmd: %s, pid: %d] last_message: %s\n",
		  cmd,  getpid(), Supr_message);
  }
  ptr_R_Busy = save_R_Busy;
 
  // replace SIGSEGV
  //{
    sigaction(SIGSEGV, &R_oldSigSegvAct, NULL); 
  //}

  __supr_malloc_fini__();
//#ifdef LD_INIT_DO_THREAD_INIT
  //R_thread_fini();
  //R_thread_fini();
//#endif
  //printf("save_R_Busy: %p\n", save_R_Busy);
  //printf("ptr_R_Busy: %p\n", ptr_R_Busy);
  if(Supr_verbose) {
    printf("[%d] libsupr.so - fini\n\n", getpid());
  }

  Supr_removeDevice(NULL);
}

static const char *__conf_template__ = "Namenode //localhost:0\n"
	"Datanode //localhost:0\n\n"
	"Master //localhost:0\n"
	"Driver //localhost:0\n\n"
	"Worker //localhost:0\n\n"
	"Infonode //localhost:0\n"
	"Filetransfer //localhost:0\n";

static void SuprConf_check(const char *usrHome)
{
  if(!usrHome) return; // FIXME?

  char path[PATH_MAX];
  int n = snprintf(path, PATH_MAX, "%s/%s", usrHome, "supr.conf");
  if(n >= PATH_MAX) error(_("path is too long"));

  if(access(path, F_OK)==-1){ // create the default/template supr.conf
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if(fd == -1) error(_("%s"), strerror(errno));

    //write(fd, __conf_template__, strlen(__conf_template__)+1);
    write(fd, __conf_template__, strlen(__conf_template__));
    close(fd);
  }

  // do checking...
  
}

//SEXP SuprContext(SEXP what, SEXP args, SEXP env);

//
SEXP Supr_last()
{
  //REprintf("\033[0;31m__supr_context: %p\033[0m\n", __supr_context);
  //if(__supr_context){
    //REprintf("\033[0;31m shutdown?\033[0m\n");
    // disconnect driver for now
    //REprintf("\033[0;31mdisconnect... \033[0m\n");
    //SEXP args = PROTECT(CONS(mkString("disconnect"), R_NilValue)); 
    //SuprContext(install("driver"), args, R_GlobalEnv);
//    SuprContext(install("shutdown"), R_NilValue, R_GlobalEnv);//FIXME...
   // __supr_context = NULL;
    //UNPROTECT(1);
  //}
  return R_NilValue;
}
//


// libname: fullpath to the lib
// paste0(libname, pkgname): the directory

#ifdef SUPR3


SEXP Supr_onLoad(SEXP libname,  SEXP pkgname)
{
  char msg[1024];


  // options
  /*
  {
    SEXP call = PROTECT(LCONS(install("options"), R_NilValue));
    SEXP R_options = PROTECT(eval(call, R_GlobalEnv));
    int len = LENGTH(R_options);
    SEXP names = getAttrib(R_options, R_NamesSymbol);
    for(int i=0; i<len; i++){
      if(strcmp("verbose", CHAR(STRING_ELT(names,i)))==0)
      {
        Supr_verbose = LOGICAL(VECTOR_ELT(R_options, i))[0];
	Supr_options.verbose = Supr_verbose;
      } else if(strcmp("timeout", CHAR(STRING_ELT(names,i)))==0) {
	Supr_options.timeout = INTEGER(VECTOR_ELT(R_options, i))[0];
      } else if(strcmp("info", CHAR(STRING_ELT(names,i)))==0) {
        Supr_infov = LOGICAL(VECTOR_ELT(R_options, i))[0];
	Supr_options.info = Supr_infov;
      } else if(strcmp("debug", CHAR(STRING_ELT(names,i)))==0) {
        Supr_debug = LOGICAL(VECTOR_ELT(R_options, i))[0];
	Supr_options.debug = Supr_debug;
      } else if(strcmp("port", CHAR(STRING_ELT(names,i)))==0) {
	Supr_options.port = asInteger(VECTOR_ELT(R_options, i));
      }
    }
  }
  */

  if(Supr_verbose) {
    sprintf(msg, "[%s:%d] %d.\033[0;32m%s\033[0m(%s, %s)\033[0m",
		   __FILE__, __LINE__, getpid(), __func__,
		   CHAR(asChar(libname)), CHAR(asChar(pkgname)));
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }

  // Check SUPR_HOME, default: ~/.supr
  if(!Supr_usrHome){
    int env = TRUE;
    Supr_usrHome = getenv("SUPR_USE_HOME");
    if(!Supr_usrHome){
      env = FALSE;
      const char *home = getenv("HOME");
      if(!home)
        error(_("cannot find the 'HOME' environment variable"));
	char path[PATH_MAX];
	sprintf(path, "%s/.supr", home);
	Supr_usrHome = malloc(strlen(path)+1);
	strcpy(Supr_usrHome, path);
    } 
    int rc = access(Supr_usrHome, R_OK);
    if(rc==0){
      DIR *dir = opendir(Supr_usrHome);
      if(!dir) 
	  error(_("opendir(%s): %s"), Supr_usrHome, strerror(errno));
      closedir(dir);
      //fprintf(stderr, "\033[0;33m[INFO] Found (%s) SUPR_USE_HOME: %s\033[0m\n", env ? "from the environment variable":"the default", Supr_usrHome);
    } else {
      int rc = mkdir(Supr_usrHome, 0700);
      if(rc == -1)
	  error(_("mkdir(%s): %s"), Supr_usrHome, strerror(errno));
//      fprintf(stderr, "\033[0;33m[INFO] Created SUPR_USE_HOME: %s\033[0m\n", Supr_usrHome);
    }
  }


  if(!Supr_sysHome){ // it should have been set by __dl_init
    Supr_sysHome = malloc(strlen(CHAR(asChar(libname)))
		    +strlen(CHAR(asChar(pkgname)))+2);
    sprintf("%s/%s", CHAR(asChar(libname)), CHAR(asChar(pkgname)));
  }

  // Check Supr_hostname
  if(!Supr_hostname){
    char hostname[256];
    int rc = gethostname(hostname, sizeof(hostname));
    if(rc == -1) perror(__func__);
    else  {
      Supr_hostname = (char*) malloc(strlen(hostname)+1);
      memcpy(Supr_hostname, hostname, strlen(hostname)+1);
    }
  }

  if(!SuprContextEnv){ // for context interval R objects
    SEXP call = PROTECT(LCONS(install("getNamespace"),
			    CONS(pkgname, R_NilValue)));
    SEXP ns = eval(call, R_BaseEnv);
    Supr_namespace = ns;
//    SuprContextEnv = findVar(install("ContextEnv"), ns);
    SuprContextEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install("ContextEnv"), SuprContextEnv, ns);
    setAttrib(SuprContextEnv, R_ClassSymbol, mkString("SuprContext"));
    defineVar(install("session"), mkString(cmd), SuprContextEnv);

    SuprBroadcastedEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install("broadcastedEnv"), SuprBroadcastedEnv, ns);

    Cluster_setDefaults();
    UNPROTECT(3);
  }

  char *sys_cmd = cmd;
  while(strstr(sys_cmd, "/")) sys_cmd = strstr(sys_cmd, "/") + 1;
  defineVar(install("Sys.cmd"), mkString(sys_cmd), Supr_namespace);
  if(strcmp(sys_cmd, "taskrunner")==0) // TASKRUNNER_SYS_CMD
  {
    SEXP task_info = PROTECT(CONS(R_NilValue, R_NilValue));
    SET_TAG(task_info, install("task"));
    defineVar(install("task.info"), task_info, Supr_namespace);
    UNPROTECT(1);
  }

  //if(strcmp(sys_cmd, "taskrunner")==0) // TASKRUNNER_SYS_CMD
  {
    //SEXP JobEnv = PROTECT(allocSExp(ENVSXP));
    //SET_ENCLOS(JobEnv, R_EmptyEnv);
    if(strcmp(proc_cmd, "driver")==0
       //||strcmp(proc_cmd, "worker")==0
       //||strcmp(proc_cmd, "master")==0
       ||strcmp(proc_cmd, "dfs_name")==0
       ||strcmp(proc_cmd, "dfs_data")==0
         ){
      SuprJobEnv = PROTECT(allocSExp(ENVSXP));
      SET_ENCLOS(SuprJobEnv, SuprEnv);
    } else {
      SuprJobEnv = PROTECT(JobEnv_createObjectTableEnv(R_NilValue));
    }
    defineVar(install("JobEnv"), SuprJobEnv, Supr_namespace);
    UNPROTECT(1);
  }
  
  return Supr_namespace; //R_NilValue;
}

static int rjni_strcmp(const void *a, const void *b);

static void Cluster_setDefaults(){
  // supr.conf
  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  struct stat sb;
  int fd = open(path, O_RDONLY);
  if(fd == -1 || fstat(fd, &sb) == -1)
    error(_("%s, %s"), path, strerror(errno));

  char buf[sb.st_size+1];
  read(fd, buf, sb.st_size);
  buf[sb.st_size] = 0;
  close(fd);

  // ncpu

  //fprintf(stderr, "%s, set ncpu, proc_cmd: %s\n", Supr_hostname, proc_cmd);

  if(strcmp(proc_cmd, "worker")==0 || strcmp(proc_cmd, "dfs_data")==0) {
   
    char *server = NULL;
    char *who = strcmp(proc_cmd, "worker")==0 ? "Worker" : "Datanode";
    
    server = strstr(buf, who);
    char *nl = server;
    int n=0;
    for(; server; server = strstr(nl, who)){
        nl = strstr(server, "\n");
	if(nl) *nl = 0;
        if(strstr(server, Supr_hostname)) {
	  if(nl) *nl = '\n';
	  break;
	}
        //fprintf(stderr, "continue...\n");
	
	if(nl) *nl = '\n'; else break;
    }

    //fprintf(stderr, "server: %s\n", server);

//    if(!server){ sleep(300); }

    if(server){

	  char *nl = strstr(server, "\n");
	  if(nl) *nl=0;

	  int ncpu = 0;

	  char *s = strstr(server, "ncpu=");
	  if(s){
	    ncpu = atoi(s+strlen("ncpu="));
	    //fprintf(stderr, "\033[0;31mproc_cmd: %s, ncpu: %d\033[0m\n", proc_cmd, ncpu);

	  } else if (strstr(server, "{")){
	    if(nl) *nl='\n';
	    char *t = strstr(nl, "}");
	    if(!t){
	      fprintf(stderr, "expected '}' in supr.conf for\n %s ", server);
	      //exit(EXIT_FAILURE); // FIXME...
	    } else {
	      t++;
	      nl = strstr(t, "\n");
	      if(nl) *nl=0;
	      s = strstr(t, "ncpu=");
	      if(s) {
	        ncpu = atoi(s+strlen("ncpu="));
	        //fprintf(stderr, "\033[0;31mproc_cmd: %s, ncpu: %d\033[0m\n", proc_cmd, ncpu);
	      }
	    }
	    
	  }

	  //fprintf(stderr, "\033[0;31mncpu: %d\033[0m, server: %s\n", ncpu, server);
	  if(ncpu > 0) Supr_options.ncpu = ncpu;


	  if(nl) *nl='\n';
    }
  }
        
  //fprintf(stderr, "\033[0;31mbuf:\n%s\n\033[0m", buf);
  //fprintf(stderr, "\033[0;31mncpu: %d\n\n\033[0m", Supr_options.ncpu);

  // driver, etc
  char *servers[] = {"driver", "master", "dfs", "info", "ths"};
  char *config_names[] = {"Driver", "Master", "Namenode", "Infonode",
  			"ThreadServers"};
  char *log_names[] = {"driver", "master", "dfs_name", "info", "ths"};

  for(int i=0; i < sizeof(servers)/sizeof(char*); i++){
    char *server = NULL;
    /*
    sprintf(path, "%s/%s.log", Supr_usrHome, log_names[i]);
    FILE *file = fopen(path, "r");
    if(file){
      char line[256];
      if(server = fgets(line, sizeof(line), file)){
        if(strstr(server, "\n")) *strstr(server, "\n") = 0;
        SEXP S_server = PROTECT(mkString(server));
        defineVar(install(servers[i]), S_server, SuprContextEnv);
        UNPROTECT(1);
      }
      fclose(file);
    }
    */

    if(!server && (server = strstr(buf, config_names[i]))){
      if(strcmp(servers[i], "ths")==0){
        server = strdup(server + strlen(config_names[i]));
	if(!strstr(server, "}")) error(_("expected \"}\" in %s"), server);
        *strstr(server, "}") = 0;
	char *token = strtok(server, "{}\n\t ");
	SEXP list = PROTECT(CONS(R_NilValue, R_NilValue));
	SEXP s = list;
	int len = 0;
	while(token){
	  SETCDR(s, CONS(mkString(token), R_NilValue));
	  len ++;
	  s = CDR(s);
          token = strtok(NULL, "{}\n\t ");
	}

	SEXP v = PROTECT(allocVector(VECSXP,len));
	SEXP n = PROTECT(allocVector(STRSXP,len));
	s = CDR(list);
	len = 0;
	while(s != R_NilValue){
	  SET_VECTOR_ELT(v, len, CAR(s));
	  SET_STRING_ELT(n, len, STRING_ELT(CAR(s),0));
	  len++;
	  s = CDR(s);
	}

	setAttrib(v, R_NamesSymbol, n);
        //defineVar(install(servers[i]), CDR(list), SuprContextEnv);
        defineVar(install(servers[i]), v, SuprContextEnv);
        UNPROTECT(3);
        free(server);
      } else {
        server = strdup(strstr(server, "//"));


	if(!strstr(server, "\n")) error(_("expected \"\\n\""));
	if(strstr(server, "?"))
          *strstr(server, "?") = 0;
	else 
          *strstr(server, "\n") = 0;
        SEXP S_server = PROTECT(mkString(server));
        defineVar(install(servers[i]), S_server, SuprContextEnv);
        UNPROTECT(1);
        free(server);
      }
    }
  }

  // (trusted) hosts
  char *hosts = strstr(buf, "TrustedHosts");
  if(hosts){
        hosts = strdup(hosts + strlen("TrustedHosts"));
	if(!strstr(hosts, "}")) error(_("expected \"}\" in %s"), hosts);
        *strstr(hosts, "}") = 0;
	char *token = strtok(hosts, "{}\n\t ");
	SEXP list = PROTECT(CONS(R_NilValue, R_NilValue));
	SEXP s = list;
	nTrustedHosts = 0;
	while(token){
	  SETCDR(s, CONS(mkString(token), R_NilValue));
	  s = CDR(s);
	  nTrustedHosts++;
          token = strtok(NULL, "{}\n\t ");
	}
        defineVar(install("TrustedHosts"), CDR(list), SuprContextEnv);
	free(hosts);

	TrustedHosts = malloc(sizeof(char*)*nTrustedHosts);
	nTrustedHosts = 0;
	s = CDR(list);
	while(TYPEOF(s) != NILSXP){
	  TrustedHosts[nTrustedHosts++] = strdup(CHAR(STRING_ELT(CAR(s),0)));
	  s = CDR(s);
	}

	qsort(TrustedHosts, nTrustedHosts, sizeof(char *), rjni_strcmp);
        UNPROTECT(1);
  }


}

#else 
/*
SEXP Supr_onLoad(SEXP libname,  SEXP pkgname)
{
  //fprintf(stderr, "\033[0;32m[%s] ==========\033[0m\n", __func__);
  //Supr_verbose = TRUE;
  {
    SEXP call = PROTECT(LCONS(install("getTaskCallbackNames"), R_NilValue));
    SEXP names = eval(call, R_BaseEnv);
    int n = LENGTH(names);
    for(int i=0; i<n; i++){
      if(strcmp(CHAR(STRING_ELT(names, i)), "unload.supr2")==0){
        call = PROTECT(LCONS(install("removeTaskCallback"),
			       CONS(mkString("unload.supr2"),R_NilValue)));
        eval(call, R_BaseEnv);
	if(Supr_verbose)
	  REprintf("[INFO] removeTaskCallback(\"unload.supr2\")\n");
	UNPROTECT(1);
	break;
      }
    }
    UNPROTECT(1);
  }
  if(!save_R_Busy) save_R_Busy = ptr_R_Busy; 
  //fprintf(stderr, "ptr_R_Busy: %p\n", ptr_R_Busy);

  const char *lib_path = CHAR(asChar(libname));
  const char *pkg_name = CHAR(asChar(pkgname));

//  printf("[%s] Supr_sysHome: %s\n", __func__, Supr_sysHome);
//  printf("[%s] SUPR_HOMESYS: %s\n", __func__, SUPR_HOMESYS);

  char *save_sysHome = Supr_sysHome;
  Supr_sysHome = (char*) malloc(strlen(lib_path) + strlen(pkg_name)+2);
  sprintf(Supr_sysHome, "%s/%s", lib_path, pkg_name);
  //printf("[%s] Supr_sysHome(lib_path/pkg_name): %s\n", __func__, Supr_sysHome);
  //SUPR_SYSHOME = Supr_sysHome;
  //printf("[%s] SUPR_SYSHOME: %s\n", __func__, SUPR_SYSHOME);
  //PrintValue(libname);
  //PrintValue(pkgname);
  if(save_sysHome){
    if(strcmp(save_sysHome, Supr_sysHome))
      fprintf(stderr, "Warning: Supr_sysHome is set to %s\n", Supr_sysHome);
    free(save_sysHome);
  }

  if(!Supr_usrHome){
    Supr_usrHome = getenv("SUPR_USE_HOME");
    if(!Supr_usrHome) {
      SEXP usrHome = findVar(install(".SuprContext"), R_GlobalEnv);
      if(usrHome != R_UnboundValue){
        if(TYPEOF(usrHome) != LISTSXP){
		PrintValue(usrHome);
          defineVar(install(".SuprContext"), R_UnboundValue, R_GlobalEnv);
	  warning(_("removed object '.SuprContext', unexpected type"));
          usrHome = R_NilValue;
	}
        while(usrHome != R_NilValue){
          if(TAG(usrHome) != R_NilValue){
            if(strcmp(CHAR(PRINTNAME(TAG(usrHome))),"usr.home")==0){
              Supr_usrHome = strdup(CHAR(asChar(CAR(usrHome))));
	      break;
	    }
	  }
	  usrHome = CDR(usrHome);
	}
      }

      if(!Supr_usrHome) {
	const char *home = getenv("HOME"); // define USER_HOME "HOME"
        Supr_usrHome = (char*) malloc(strlen(home) + strlen(".supr")+2);
	sprintf(Supr_usrHome, "%s/%s", home, ".supr");
	DIR *dir = opendir(Supr_usrHome);
        if(!dir){
          if(mkdir(Supr_usrHome, 0700)==-1){
            error(_("%s, %s"), Supr_usrHome, strerror(errno));
	  }
	} else {
	  closedir(dir);
	}	
      }

    }
  }

  // check supr.conf
  SuprConf_check(Supr_usrHome);
  

  //fprintf(stderr,"[%s] is called, Supr_usrHome: %s\n",__func__, Supr_usrHome);
  SEXP suprCntxt = findVar(install(".SuprContext"), R_GlobalEnv);
  if(suprCntxt == R_UnboundValue){
    suprCntxt = PROTECT(CONS(mkString(Supr_sysHome), R_NilValue));
    SET_TAG(suprCntxt, install("sys.home"));
    defineVar(install(".SuprContext"), suprCntxt, R_GlobalEnv);
    UNPROTECT(1);
  }

  SEXP s = suprCntxt;
  // FIXME: make a function List_defineVar...
  while(s != R_NilValue){
    if(TAG(s) != R_NilValue && strcmp(CHAR(PRINTNAME(TAG(s))),"sys.home")==0){
      SETCAR(s, mkString(Supr_sysHome));
      break;
    }
    s = CDR(s);
  }
  if(s == R_NilValue){
    s = PROTECT(CONS(mkString(Supr_sysHome), R_NilValue));
    SET_TAG(s, install("sys.home"));
    SETCDR(s, CDR(suprCntxt));
    SETCDR(suprCntxt, s);
    UNPROTECT(1);
  }

  s = suprCntxt;
  while(s != R_NilValue){
    if(TAG(s) != R_NilValue && strcmp(CHAR(PRINTNAME(TAG(s))),"usr.home")==0){
      SETCAR(s, mkString(Supr_usrHome));
      break;
    }
    s = CDR(s);
  }
  if(s == R_NilValue){
    s = PROTECT(CONS(mkString(Supr_usrHome), R_NilValue));
    SET_TAG(s, install("usr.home"));
    SETCDR(s, CDR(suprCntxt));
    SETCDR(suprCntxt, s);
    UNPROTECT(1);
  }

  if(Supr_sysHome) 
	  SUPR_HOMESYS = Supr_sysHome;
  if(Supr_usrHome) {
	  SUPR_HOMEUSR = Supr_usrHome;
    if(!Supr_dfsHome){
	  Supr_dfsHome = strdup(Supr_usrHome);
	  SUPR_DFS_HOMEUSR = Supr_dfsHome;
    }
  }

  if(!main_thread) {
    // this is the case when libsupr.so was not unloaded from a previous
    // library(supr2) call
    //warning(_("Error: FIXME (%s:%d)"), __FILE__, __LINE__);
    R_thread_init();
  }

  {

    RCNTXT *top_ptr = R_GlobalContext;
    while(top_ptr->nextcontext)
	    top_ptr = top_ptr->nextcontext;

    if(top_ptr->nodestack != __R_BCNodeStackBase){
      if(Supr_verbose){
        fprintf(stderr, "Warning: __R_BCNodeStackBase=%p\n",
		      __R_BCNodeStackBase); 
        fprintf(stderr, "Warning: top_ptr->nodestack= %p\n",
		      top_ptr->nodestack);
      }
      __R_BCNodeStackBase = top_ptr->nodestack;
    }

  }


//sleep(120);
  if(Supr_verbose){
    printf("[%s] Supr_sysHome: %s\n", __func__, Supr_sysHome);
  //SUPR_SYSHOME = Supr_sysHome;
    printf("[%s] SUPR_HOMESYS: %s\n", __func__, SUPR_HOMESYS);
  }
 

  return R_NilValue;
}
*/
#endif

#ifdef SUPR3

//static pthread_mutex_t supr3_R_Busy_mutex = PTHREAD_MUTEX_INITIALIZER;

void supr3_R_Busy(int which){

  static pthread_t pthread = 0;

  if(which==1 && !pthread_equal(pthread, pthread_self())){
    pthread_mutex_lock(&supr3_R_Busy_mutex);
    pthread =  pthread_self();
    Sync_info.R_owner = supr3_R_Busy_mutex.__data.__owner;
  } else if(which==0 && pthread != 0){
    pthread_mutex_unlock(&supr3_R_Busy_mutex);
    pthread = 0;
  }
}

SEXP R_lock(){
  R_Busy(1);
  return ScalarInteger(0); // FIXME?
}
SEXP R_unlock(){
  R_Busy(0);
  return ScalarInteger(0); // FIXME?
}

extern void (*ptr_R_ProcessEvents)();
void (*save_ptr_R_ProcessEvents)() = NULL;

typedef void (*sighandler_t)(int);
sighandler_t R_SIGINT_sighandler = NULL;

//#define basic_info(s) __basic_info__((s), __FILE__, __LINE__, __func__)

#define MSG_MAX 1024

void real_info(int type, const char *SourceFilename, int SourceLineno,
                const char *funName,  const char *format, ...){

  
  if(strlen(format)>=1024 && !strstr(format, "%")){
    Cluster_sendSimpleMessage(format, msg_color, type, 0);
    return;
  }

  va_list ap;
  int d;
  char c, *s;
  void *p;
  double x;
  ssize_t size;

  char msg[MSG_MAX];
  int len = 0;

  if(Supr_options.level) {
    sprintf(msg, "%s:%d:%s: ", SourceFilename, SourceLineno, funName);
    len += strlen(msg);
  }


  va_start(ap, format);
  const char *fmt = format;
  char buf[256];
  while (*fmt) {
    while(*fmt && *fmt != '%'){
      msg[len++] = *fmt; 
      fmt++;
    }
    if(*fmt) fmt++; else break;
    
    s = buf;
    if(*fmt == 0) break; // error in format...
    switch (*fmt) {
               case 's':    
		   fmt++;
                   s = va_arg(ap, char *);
                   break;
               case 'd':     
		   fmt++;
                   d = va_arg(ap, int);
                   sprintf(buf, "%d", d);
                   break;
               case 'x':     
		   fmt++;
                   d = va_arg(ap, int);
                   sprintf(buf, "%x", d);
                   break;
               case 'f':      
		   fmt++;
                   x = va_arg(ap, double);
                   sprintf(buf, "%f", x);
                   break;
               case 'g':      
		   fmt++;
                   x = va_arg(ap, double);
                   sprintf(buf, "%g", x);
                   break;
               case 'l':   
		   fmt++;
		   if(*fmt && *fmt == 'd'){
                     size = va_arg(ap, ssize_t);
                     sprintf(buf, "%ld", size);
		     fmt++;
		   } else {
		     fprintf(stderr, "%c: not implemented\n", *fmt);
		     s = "?";
		   }
                   break;
               case 'c':  
		   fmt++;
                   c = (char) va_arg(ap, int);
                   sprintf(buf, "%c", c);
                   break;
               case 'p': 
		   fmt++;
                   p = (void *) va_arg(ap, void *);
                   sprintf(buf, "%p", p);
                   break;
	       default: // error, FIXME
		   fmt++;
		   fprintf(stderr, "%c: not implemented\n", *fmt);
		   s = "?";
		   break;
    }
    int n = strlen(s);
    if(len+n >= MSG_MAX){
       snprintf(msg + len, MSG_MAX-len-1, "%s", s);
       len += MSG_MAX-len-1;
    } else {
       sprintf(msg + len, "%s", s);
       len += n;
    }
    msg[len] = 0;
  }
  msg[len] = '\0'; //fprintf(stderr, "\033[0;31m%s\033[0m", msg);

  va_end(ap);

  //error_info(msg);
  Cluster_sendSimpleMessage(msg, msg_color, type, 0);
  
}





/*

void real_error_info(const char *SourceFilename, int SourceLineno,
                const char *funName, const char *format, ...){

  if(strlen(format)>=1024 && !strstr(format, "%")){
    Cluster_sendSimpleMessage(msg, msg_color, ERROR_INFO_TYPE, 0);
    return;
  }

  va_list ap;
  int d;
  char c, *s;
  void *p;
  double x;
  ssize_t size;

  char msg[MSG_MAX];
  int len = 0;

  sprintf(msg, "%s:%d:%s: ", SourceFilename, SourceLineno, funName);
  len = strlen(msg);

  va_start(ap, format);
  const char *fmt = format;
  char buf[256];
  while (*fmt) {
    while(*fmt && *fmt != '%'){
      msg[len++] = *fmt; 
      fmt++;
    }
    if(*fmt) fmt++; else break;
    
    s = buf;
    if(*fmt == 0) break; // error in format...
    switch (*fmt) {
               case 's':
		   fmt++;
                   s = va_arg(ap, char *);
                   break;
               case 'd':
		   fmt++;
                   d = va_arg(ap, int);
                   sprintf(buf, "%d", d);
                   break;
               case 'f':
		   fmt++;
                   x = va_arg(ap, double);
                   sprintf(buf, "%f", x);
                   break;
               case 'l':
		   fmt++;
		   if(*fmt && *fmt == 'd'){
                     size = va_arg(ap, ssize_t);
                     sprintf(buf, "%ld", size);
		     fmt++;
		   } else {
		     fprintf(stderr, "%c: not implemented\n", *fmt);
		     s = "?";
		   }
                   break;
               case 'c':
		   fmt++;
                   c = (char) va_arg(ap, int);
                   sprintf(buf, "%c", c);
                   break;
               case 'p':
		   fmt++;
                   p = (void *) va_arg(ap, void *);
                   sprintf(buf, "%p", p);
                   break;
	       default: // error, FIXME
		   fmt++;
		   fprintf(stderr, "%c: not implemented\n", *fmt);
		   s = "?";
		   break;
    }
    int n = strlen(s);
    if(len+n >= MSG_MAX){
       snprintf(msg + len, MSG_MAX-len-1, "%s", s);
       len += MSG_MAX-len-1;
    } else {
       sprintf(msg + len, "%s", s);
       len += n;
    }
    msg[len] = 0;
  }
  msg[len] = '\0'; //fprintf(stderr, "\033[0;31m%s\033[0m", msg);

  va_end(ap);

  //error_info(msg);
  Cluster_sendSimpleMessage(msg, msg_color, ERROR_INFO_TYPE, 0);
}


void real_verbose_info(const char *SourceFilename, int SourceLineno,
                const char *funName, const char *format, ...){

  if(strlen(format)>=1024 && !strstr(format, "%")){
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
    return;
  }

  va_list ap;
  int d;
  char c, *s;
  void *p;
  double x;
  ssize_t size;

  char msg[MSG_MAX];
  int len = 0;

  sprintf(msg, "%s:%d:%s: ", SourceFilename, SourceLineno, funName);
  len = strlen(msg);

  va_start(ap, format);
  const char *fmt = format;
  char buf[256];
  while (*fmt) {
    while(*fmt && *fmt != '%'){
      msg[len++] = *fmt; 
      fmt++;
    }
    if(*fmt) fmt++; else break;
    
    s = buf;
    if(*fmt == 0) break; // error in format...
    switch (*fmt) {
               case 's':
		   fmt++;
                   s = va_arg(ap, char *);
                   break;
               case 'd':
		   fmt++;
                   d = va_arg(ap, int);
                   sprintf(buf, "%d", d);
                   break;
               case 'f':
		   fmt++;
                   x = va_arg(ap, double);
                   sprintf(buf, "%f", x);
                   break;
               case 'l':
		   fmt++;
		   if(*fmt && *fmt == 'd'){
                     size = va_arg(ap, ssize_t);
                     sprintf(buf, "%ld", size);
		     fmt++;
		   } else {
		     fprintf(stderr, "%c: not implemented\n", *fmt);
		     s = "?";
		   }
                   break;
               case 'c':
		   fmt++;
                   c = (char) va_arg(ap, int);
                   sprintf(buf, "%c", c);
                   break;
               case 'p':
		   fmt++;
                   p = (void *) va_arg(ap, void *);
                   sprintf(buf, "%p", p);
                   break;
	       default: // error, FIXME
		   fmt++;
		   fprintf(stderr, "%c: not implemented\n", *fmt);
		   s = "?";
		   break;
    }
    int n = strlen(s);
    if(len+n >= MSG_MAX){
       snprintf(msg + len, MSG_MAX-len-1, "%s", s);
       len += MSG_MAX-len-1;
    } else {
       sprintf(msg + len, "%s", s);
       len += n;
    }
    msg[len] = 0;
  }
  msg[len] = '\0'; //fprintf(stderr, "\033[0;31m%s\033[0m", msg);

  va_end(ap);

  //error_info(msg);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
}





void real_debug_info(const char *SourceFilename, int SourceLineno,
                const char *funName, const char *format, ...){

  if(strlen(format)>=1024 && !strstr(format, "%")){
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
    return;
  }

  va_list ap;
  int d;
  char c, *s;
  void *p;
  double x;
  ssize_t size;

  char msg[MSG_MAX];
  int len = 0;

  sprintf(msg, "%s:%d:%s: ", SourceFilename, SourceLineno, funName);
  len = strlen(msg);

  va_start(ap, format);
  const char *fmt = format;
  char buf[256];
  while (*fmt) {
    while(*fmt && *fmt != '%'){
      msg[len++] = *fmt; 
      fmt++;
    }
    if(*fmt) fmt++; else break;
    
    s = buf;
    if(*fmt == 0) break; // error in format...
    switch (*fmt) {
               case 's':
		   fmt++;
                   s = va_arg(ap, char *);
                   break;
               case 'd':
		   fmt++;
                   d = va_arg(ap, int);
                   sprintf(buf, "%d", d);
                   break;
               case 'f':
		   fmt++;
                   x = va_arg(ap, double);
                   sprintf(buf, "%f", x);
                   break;
               case 'l':
		   fmt++;
		   if(*fmt && *fmt == 'd'){
                     size = va_arg(ap, ssize_t);
                     sprintf(buf, "%ld", size);
		     fmt++;
		   } else {
		     fprintf(stderr, "%c: not implemented\n", *fmt);
		     s = "?";
		   }
                   break;
               case 'c':
		   fmt++;
                   c = (char) va_arg(ap, int);
                   sprintf(buf, "%c", c);
                   break;
               case 'p':
		   fmt++;
                   p = (void *) va_arg(ap, void *);
                   sprintf(buf, "%p", p);
                   break;
	       default: // error, FIXME
		   fmt++;
		   fprintf(stderr, "%c: not implemented\n", *fmt);
		   s = "?";
		   break;
    }
    int n = strlen(s);
    if(len+n >= MSG_MAX){
       snprintf(msg + len, MSG_MAX-len-1, "%s", s);
       len += MSG_MAX-len-1;
    } else {
       sprintf(msg + len, "%s", s);
       len += n;
    }
    msg[len] = 0;
  }
  msg[len] = '\0'; //fprintf(stderr, "\033[0;31m%s\033[0m", msg);

  va_end(ap);

  //error_info(msg);
  Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
}
*/


void Supr_SIGINT_sighandler(int sig)
{
  basic_info("R: handleInterrupt/%p\n", R_SIGINT_sighandler);
  R_SIGINT_sighandler(sig);
}

void Supr_SIGINT_sigaction(int sig, siginfo_t *ip, void *cntxt)
{
  basic_info("R: sigaction/%p\n", R_SIGINT_sigaction.sa_sigaction);
  R_SIGINT_sigaction.sa_sigaction(sig, ip, cntxt);
}

/*
SEXP __BASIC_INFO(SEXP x)
{
  switch(TYPEOF(x)){
    case NILSXP: BASIC_INFO("x: NULL\n");
	 break;
    case STRSXP: BASIC_INFO("x: %s\n", CHAR(asChar(x)));
	 break;
    case INTSXP: BASIC_INFO("x: %d\n", asInteger(x));
	 break;
    case REALSXP: BASIC_INFO("x: %f\n", asReal(x));
	 break;
    default: BASIC_INFO("x: %s\n", CHAR(asChar(x)));
	 break;
  }
  size_t size = 10;
  BASIC_INFO("x: size: %ld\n", size);
  return R_NilValue; 
}
*/

#define USE_R_SIGINT_HANDLER() signal(SIGINT, R_SIGINT_sighandler)

SEXP Supr3_last(SEXP libname,  SEXP pkgname)
{
  //fprintf(stderr, "TODO ... \n");
  SEXP ret_val = R_NilValue;
  if(Supr_infoServer && TYPEOF(Supr_infoServer)==EXTPTRSXP){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
             R_ExternalPtrAddr(Supr_infoServer);
    if(sc){
      //fprintf(stderr, "sc->fd: %d\n", sc->fd); 
      int pong = tryPingSocketServer2(sc->host, sc->port);
      if(pong == CLUSTER_PONG) {
        //warning(_("info server %s:%d is still running"), sc->host, sc->port);
        basic_info("info server %s:%d is still running", sc->host, sc->port);
	//defineVar(install("info"), Supr_infoServer, SuprContextEnv);
        supr_socket_conn_t *conn = socketOpen2(sc->host, sc->port);
        //fprintf(stderr, "conn: %p\n", conn);
	if(conn){
	  Supr_incref(conn);
          int cmd = INFO_SERVER_SHUTDOWN;
	  write(conn->fd, &cmd, sizeof(int));
	  int rc;
	  read(conn->fd, &rc, sizeof(int));
          //fprintf(stderr, "infoServer.shutdown(): %d\n", rc);
          fprintf(stderr, "disconnected %d socket connections\n", rc);
	  Supr_decref(conn);
	  ret_val = ScalarInteger(rc);
	}
	//close(sc->fd);
	//Supr_decref(sc);
        //conn = socketOpen2(sc->host, sc->port);
        //fprintf(stderr, "conn: %p\n", conn);
      }
   }
  }

  X_term_exit = TRUE;
  //error(_("TODO"));

  return ret_val;
}

SEXP Supr_onAttach(SEXP libname,  SEXP pkgname)
{
  {
    R_SIGINT_sighandler = signal(SIGINT, Supr_SIGINT_sighandler);

    struct sigaction sa;
    sa.sa_sigaction = Supr_SIGINT_sigaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_SIGINT_sigaction);
    signal(SIGINT, R_SIGINT_sighandler);
  }

  char msg[1024];
  if(Supr_verbose) {
    sprintf(msg, "[%s:%d] %d.\033[0;32m%s\033[0m(%s, %s)\033[0m",
		   __FILE__, __LINE__, getpid(), __func__,
		   CHAR(asChar(libname)), CHAR(asChar(pkgname)));
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }

  save_R_Busy = ptr_R_Busy;
  ptr_R_Busy = supr3_R_Busy;

  //
  save_ptr_R_ProcessEvents = ptr_R_ProcessEvents;
  /*
  ptr_R_ProcessEvents = supr3_R_ProcessEvents;

  ptr_R_ProcessEvents();
  */
  //

  //fprintf(stderr, "\033[0;32m[%s] <<<<<\033[0m\n", __func__);

  SuprEnv = findVar(install(".SuprEnv"), R_GlobalEnv);
  if(SuprEnv == R_UnboundValue || TYPEOF(SuprEnv) != ENVSXP){
    SuprEnv = PROTECT(R_NewHashedEnv(R_GlobalEnv, //R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install(".SuprEnv"), SuprEnv, R_GlobalEnv);

    // make sure it is protected in case .SuprEnv is removed from R_GlobalEnv
    UNPROTECT(1);
  }
  defineVar(install(".SuprEnv"), SuprEnv, SuprContextEnv);

  /*
  { // makeActiveBinding
    SEXP call = PROTECT(LCONS(install("makeActiveBinding"),
		    CONS(install("connections"), CONS(install("connections"),
		    CONS(SuprEnv, R_NilValue)))));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);

  }
  */


  SuprThreads = findVar(install(".SuprThreads"), SuprEnv);
  if(SuprThreads == R_UnboundValue || TYPEOF(SuprThreads) != ENVSXP){
    SuprThreads = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install(".SuprThreads"), SuprThreads, SuprEnv);
    UNPROTECT(1);
  }

  /*
  if(strcmp(proc_cmd, "R")==0){
    SEXP JobEnv = findVar(install("JobEnv"), Supr_namespace);
    //JobEnv_createObjectTableEnv(JobEnv);
    if(JobEnv != R_UnboundValue){
      defineVar(install("job"), ScalarInteger(-1), JobEnv);
    }
  }
  */

  // add .Last function
  SEXP supr_last = PROTECT(allocSExp(CLOSXP));
  SEXP expr = PROTECT(LCONS(install(".Call"),
  	CONS(mkString("Supr3_last"), R_NilValue)));
  SEXP body = PROTECT(LCONS(install("{"),
  	CONS(expr, R_NilValue)));

  SEXP last = findVar(install(".Last"), R_GlobalEnv);
  if(last != R_UnboundValue)
    SETCDR(CDR(body), last);

  SET_BODY(supr_last, body);
  SET_FORMALS(supr_last, R_NilValue);
  SET_CLOENV(supr_last, R_GlobalEnv);
  defineVar(install(".Last"), supr_last, R_GlobalEnv);
  UNPROTECT(3);

  return R_NilValue;
}

#else

/*
SEXP Supr_onAttach(SEXP libname,  SEXP pkgname)
{
  //fprintf(stderr, "\033[0;32m[%s] >>>>>\033[0m\n", __func__);

  //myR_simpleTraceback();


  //Supr_verbose = TRUE;
//  PrintValue(libname);
//  PrintValue(pkgname);
//  fprintf(stderr, "[%s] R_thread_init? TODO...\n", __func__);

//  if(R_Interactive) R_thread_init();
//  { R_thread_init(); }


  // do nothing
  //fprintf(stderr, "[%s] TODO...\n", __func__);
  //
#define NOT_FIND_NCALLS_FROM_BUSY
#ifdef FIND_NCALLS_FROM_BUSY
    //if(R_Interactive)
    { // find the number of func calls to supr_R_Busy

      R_ReplState state = {PARSE_NULL, 1, 0, "", NULL} ;
      state.buf[0] = '\0';
      state.buf[CONSOLE_BUFFER_SIZE] = '\0';
      state.bufp = state.buf;

      void (*__save_R_Busy)(int) = ptr_R_Busy;

      ptr_R_Busy = tmp_R_Busy;

      sprintf(state.buf, "assign(\"info\",\"OK\", envir=.GlobalEnv)\n");//??

      int status = Rf_ReplIteration(R_GlobalEnv, 0, 0, &state);
      if(status < 0) {
          if (state.status == PARSE_INCOMPLETE)
	  {
           // __FIXME__("unexpected end of input");
           printf("2? unexpected end of input");
	  }
      }
      if(Supr_verbose)
        fprintf(stderr, "Supr_nCallsFromConsoleToBusy: %d\n",
		       	Supr_nCallsFromConsoleToBusy);

      ptr_R_Busy = __save_R_Busy;
    }
#endif

  //fprintf(stderr, "\033[0;32m[%s] >>>>> DONE!\033[0m\n\n", __func__);
  return R_NilValue;
}
*/
#endif

// See also .Last.lib, which is exported from the namespace
#ifdef SUPR3
SEXP Supr_onDetach(SEXP fullPathToPkg)
{
//  { SuprError_setDevice("/dev/pts/5"); }
  fprintf(stderr, "\033[0;31m[%s] TODO...\033[0m\n", __func__);

  ptr_R_Busy = save_R_Busy;

  ptr_R_ProcessEvents = save_ptr_R_ProcessEvents;

  return R_NilValue;
}
#else 
/*
SEXP Supr_onDetach(SEXP fullPathToPkg)
{
//  { SuprError_setDevice("/dev/pts/5"); }
 // fprintf(stderr, "\033[0;31m[%s] TODO...\033[0m\n", __func__);
  ptr_R_Busy = save_R_Busy;
  return R_NilValue;
}
*/
#endif

#ifdef SUPR3
SEXP Supr_onUnload(SEXP fullPathToPkgDir)
{
  fprintf(stderr, "\033[0;31m[%s] TODO...\033[0m\n", __func__);
  PrintValue(fullPathToPkgDir);
  return R_NilValue;
}

#else

/*
SEXP Supr_onUnload(SEXP fullPathToPkgDir)
{ //PrintValue(fullPathToPkgDir);
  // do nothing as long as libsupr.so is loaded
  // fprintf(stderr, "[%s] do NOT dyn.unload(\"libsupr.so\"). More to do ?\n", __func__);

  //R_thread_fini();

  ptr_R_Busy = save_R_Busy;

  return R_NilValue;
}
*/

#endif

static int Supr_detach(int detach)
{
	printf("deprecated ...\n");
	return 0;

    SEXP call = PROTECT(LCONS(install("detach"), 
		    CONS(mkString("package:supr2"), 
		    CONS(R_TrueValue, R_NilValue))));
    SET_TAG(CDDR(call), install("unload"));

    /*
    int save_out = dup(STDOUT_FILENO);
    int save_err = dup(STDERR_FILENO);
    int fd = open("/dev/pts/11", O_WRONLY);
    dup2(fd, STDOUT_FILENO);
    dup2(fd, STDERR_FILENO);
    */
    PrintValue(call);
    //eval(call, R_GlobalEnv); // consider callback ... will not work?
    R_thread_fini();
    if(detach)
      eval(call, R_GlobalEnv);
    UNPROTECT(1);
    /*
    dup2(save_out, STDOUT_FILENO);
    dup2(save_err, STDERR_FILENO);
    */
    return 0;
}



// FIXME
void Supr_protect(SEXP s)
{
  static SEXP protectList = NULL;
  if(!protectList){
    protectList = PROTECT(CONS(s, R_NilValue));
    defineVar(install(".SuprProtected"), protectList, R_GlobalEnv);
  } else {
    SEXP list = PROTECT(CONS(s, CDR(protectList)));
    SETCDR(protectList, list);
  }
  UNPROTECT(1);
}

void SocketConn_attach(supr_socket_conn_t *sc, void *object)
{
  if(sc->att == NULL) sc->att = newVector(FALSE);
  vectorAdd((vector_t*)sc->att, object);
}

void Thread_cancel(void *data)
{
  supr_thread_t *th = (supr_thread_t *) data;
  printf("Cancel %s\n", th->name);
  int rc = pthread_cancel(th->ptid);
  if(rc == 0) {
    void *retval;
    rc = pthread_join(th->ptid, &retval);
  }
}

static pthread_mutex_t __REF_MUTEX__ = PTHREAD_MUTEX_INITIALIZER;

int Supr_refcnt(void *data)
{
  if(!data) return 0;

  int ref_count = -1;
  pthread_mutex_lock(&__REF_MUTEX__);
  object_t *obj = (object_t *) data;
  ref_count = obj->ref_count;
  pthread_mutex_unlock(&__REF_MUTEX__);
  return ref_count;
}

void Supr_incref(void *data)
{
  if(!data) return;

  object_t *obj = (object_t *) data;
  pthread_mutex_lock(&__REF_MUTEX__);
  obj->ref_count ++;
  pthread_mutex_unlock(&__REF_MUTEX__);
}

void Supr_decref(void *data)
{
  if(!data) return;
  object_t *obj = (object_t *) data;
  pthread_mutex_lock(&__REF_MUTEX__);
  obj->ref_count--;
  int count = obj->ref_count;
  pthread_mutex_unlock(&__REF_MUTEX__);
  if(count == 0)
    obj->class->finalize(obj->class, obj);
}

// special object so_t
void SO_incref(so_t *so)
{
  if(!so) return;
  so->ref_count ++;
  // message:
  //fprintf(stderr, "[%s] so->ref_count: %d\n",__func__, so->ref_count);
}

#ifndef VALUE_TO_STRING
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)
#define VAR_NAME_VALUE(var) #var "="  VALUE(var)
#endif



#ifdef malloc
//#pragma message("\033[0;31mmalloc is defined\033[0m\n")
//#pragma message "value of malloc(x) = " VALUE(malloc(x))
#endif

#ifdef free
//#pragma message("\033[0;31mfree is defined\033[0m\n")
//#pragma message "value of free(x) = " VALUE(free(x))
#endif

void SO_decref(so_t *so)
{
  if(!so) return;

  so->ref_count --;
  if(so->ref_count == 0) free(so);
}

static pthread_mutex_t SuprErr_mutex = PTHREAD_MUTEX_INITIALIZER;
static void *err = NULL; // a list/vector of errors


// FIXME
int SuprErr_set(const char *format, ...)
{
   pthread_mutex_lock(&SuprErr_mutex);

   va_list ap;
   va_start(ap, format);
   char buf[4098];
   vsnprintf(buf, sizeof(buf), format, ap);
   err = (char*) malloc(strlen(buf)+1);
   pthread_mutex_unlock(&SuprErr_mutex);
   return 0;
}

void *SuprErr_get()
{
   void *ret = NULL;
   pthread_mutex_lock(&SuprErr_mutex);
   ret = err;
   err = NULL;
   pthread_mutex_unlock(&SuprErr_mutex);
   return ret;
}

SEXP RList_findVar(const char *name, SEXP list)
{
  if(TYPEOF(list) != LISTSXP)
          return R_UnboundValue;

  while(list != R_NilValue){
    if(TAG(list) != R_NilValue
       && strcmp(CHAR(PRINTNAME(TAG(list))), name)==0)
            return CAR(list);
    list = CDR(list);
  }
  return R_UnboundValue;
}


#ifndef R_EXT_EVENTLOOP_H
typedef void (*InputHandlerProc)(void *userData);

typedef struct _InputHandler {

  int activity;
  int fileDescriptor;
  InputHandlerProc handler;

  struct _InputHandler *next;

    /* Whether we should be listening to this file descriptor or not. */
  int active;

    /* Data that can be passed to the routine as its only argument.
       This might be a user-level function or closure when we implement
       a callback to R mechanism.
     */
  void *userData;

} InputHandler;
#endif

#ifdef SUPR3
// FIXME?
#define SuprStdidActivity 100
//static InputHandler Supr_BasicInputHandler = {SuprStdidActivity, -1, NULL};
static InputHandler Supr_BasicInputHandler = {SuprStdidActivity, -1, NULL, NULL, 0, NULL};
InputHandler *Supr_R_InputHandlers = &Supr_BasicInputHandler;
// init?
#endif

InputHandler *__InputHandlers_selectInputHandler(int timeout);

typedef struct supr_monitor_struct {
  class_t *class;
  int ref_count;
  int tid;
  char *name;
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
} supr_monitor_t;

vector_t *monitors = NULL;

/*
typedef struct class_node_struct {
  class_t *class;
  struct class_node_struct *next;
} class_node_t;

static class_node_t *SuprClass_root = NULL; 
static pthread_mutex_t SuprClass_mutex = PTHREAD_MUTEX_INITIALIZER;

class_t *SuprClass_register(class_t *c)
{
  class_node_t *node = (class_node_t *) malloc(sizeof(class_node_t));
  node->class = c;
  pthread_mutex_lock(&SuprClass_mutex);
    node->next = SuprClass_root;
    SuprClass_root = node;
  pthread_mutex_unlock(&SuprClass_mutex);

  return c;
}

class_t *SuprClass_get(void *obj)
{
  class_t *c = ((object_t*)obj)->class, *retval = NULL;
  pthread_mutex_lock(&SuprClass_mutex);
    class_node_t *node = SuprClass_root;
    while(node){
	    node = node->next;
	    if(node->class == c) {
		    retval = c;
		    break;
	    }
    }
  pthread_mutex_unlock(&SuprClass_mutex);
  return retval;
}

const char *SuprClass_name(class_t *c)
{
  return c ? c->name : NULL;
}
*/



extern void (*ptr_R_ClearerrConsole)();
//static void (*__save_R_ClearerrConsole)() = NULL;
//static void __R_ClearerrConsole();

extern SEXP Rf_deparse1line(SEXP call, Rboolean abbrev);
extern SEXP Rf_deparse1m(SEXP call, Rboolean abbrev, int);

extern int R_interrupts_pending;
void Thread_SigactionSIGUSR2(int sig, siginfo_t *ip, void *context);


jmp_buf R_ToplevelContext_cjmpbuf; // a saved copy for the main_thread - FIXME
jmp_buf save_R_ToplevelContext_cjmpbuf; // a saved copy for the main_thread

char *Thread_readline(const char *prompt);
char *(*ptr_readline)(const char *prompt) = readline;

SEXP R_future(SEXP job, SEXP op, SEXP timeout);

// 12/17/2021: ...

static void UserJob_R_finalizer(SEXP s)
{
  user_job_t *job = (user_job_t *) R_ExternalPtrAddr(s);
  Supr_decref(job);
}

SEXP Job_combine(SEXP retval, SEXP combine, SEXP env){
 // if(TYPEOF(combine) == CLOSXP){
    SEXP call = PROTECT(LCONS(combine, CONS(retval, R_NilValue)));
    retval = eval(call, env);
    UNPROTECT(1);
 // }
  
  return retval;
}

SEXP Job_get(SEXP S_timeout, SEXP rho){
  SEXP value = findVar(install(".value"), rho);
  if(value != R_UnboundValue) {
    //return value;
    SEXP combine = findVar(install("combine"), rho);
    SEXP env = findVar(install("envir"), rho);
    return Job_combine(value, combine, env);
  }

  SEXP job = findVar(install("job.id"), rho);
  int id = asInteger(job);
  double timeout = asReal(S_timeout);

  shm_io_info_t *io = driver_shm_io;
  if(! io) error(_("driver_shm_io is not available"));

  supr_thread_t *cth = currentThread();

  Supr_interrupt_enable();

  int status = 0;

  RCNTXT cntxt;
  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);
    cntxt.cend = &Supr_onClusterEvalIntr;
    cntxt.cenddata = &status;

    int *to = (int*) &timeout;
    int args[] = {DU_JOB_GET, id, to[0], to[1]};
    shm_io_write(io, io->out, args, sizeof(args));

    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    int result_available = *((int*)ptr);
    free(ptr);

    if(result_available ==  CANNOT_FIND_JOB){
            error(_("cannot find the job"));
    } else if(result_available ==  JOB_WAS_CANCELLED){
            error(_("the job was cancelled"));
    }

    // get intr_ref
    if(!result_available){
      char *ref = (char *) shm_io_read(io, io->in, &size, NULL);
      printf("[%s] Read sync object reference: \"%s\"\n", __func__, ref);
      cth->properties = ref; // ??
    }

    SEXP retval;

    so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
    if(size==0){ // why???
      so = (so_t*) shm_io_read(io, io->in, &size, NULL);
    }

    if(cth->data == PTHREAD_INTERRUPTED){
      warning("interrupted cluster_get");
      retval = R_NilValue;
    } else {
      retval = SO_toRObject(so, size);
      defineVar(install(".value"), retval, rho);
    }
    free(so);

    SEXP combine = findVar(install("combine"), rho);
    SEXP env = findVar(install("envir"), rho);
    retval = Job_combine(retval, combine, env);
    //defineVar(install(".value"), retval, rho);

  endcontext(&cntxt);

  Supr_interrupt_disable();

  return retval;
}

SEXP Job_cancel(SEXP rho){

  SEXP isCancelled = findVar(install(".cancelled"), rho);
  if(isCancelled != R_UnboundValue){
    error(_("invalid operation"));
  }
  //SEXP job = PROTECT(ScalarInteger(id));
  SEXP job = findVar(install("job.id"), rho);
  SEXP cmd = PROTECT(mkString("cancel"));
  SEXP val = R_future(job, cmd, R_FalseValue); // PrintValue(val);
  UNPROTECT(1);

  defineVar(install(".cancelled"), R_TrueValue, rho);
  return val; //R_TrueValue;
}

SEXP Job_isCancelled(SEXP rho){
  SEXP isCancelled = findVar(install(".cancelled"), rho);
  if(isCancelled==R_UnboundValue) {
    return R_FalseValue;
  } else 
    return R_TrueValue;
}

SEXP Job_isDone(SEXP rho){
  SEXP isDone = findVar(install(".done"), rho);
  if(isDone==R_UnboundValue) {
  
    shm_io_info_t *io = driver_shm_io;
    if(! io) error(_("driver_shm_io is not available"));

    SEXP job = findVar(install("job.id"), rho);
    if(job == R_UnboundValue) error(_("'job.id' not found"));
    int id = asInteger(job);
    int args[] = {DU_JOB_ISDONE, id};
    shm_io_write(io, io->out, args, sizeof(args));
    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    int retval = ((int*)ptr)[0];
    free(ptr); //return retval;
    if(retval) {
      defineVar(install(".done"), R_TrueValue,  rho);
      return R_TrueValue;
    } else
      return R_FalseValue;
  }
  else 
    return R_TrueValue;
}

// job result as a future
SEXP newUserJob(int id, SEXP combine, SEXP envir)
{
  SEXP rho = PROTECT(allocSExp(ENVSXP));
  
  SET_ENCLOS(rho, SuprEnv);
  defineVar(install("job.id"), ScalarInteger(id), rho);
  defineVar(install("combine"), combine, rho);
  defineVar(install("envir"), envir, rho);

  {
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SEXP func_body = PROTECT(LCONS(install(".Call"),
           CONS(mkString("Job_cancel"), CONS(rho, R_NilValue))));
    SET_FORMALS(func, R_NilValue);
    SET_BODY(func, func_body);
    SET_CLOENV(func, rho);
    defineVar(install("cancel"), func, rho);
    UNPROTECT(2);
  }

  {
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SEXP func_body = PROTECT(LCONS(install(".Call"),
           CONS(mkString("Job_get"), CONS(install("timeout"),
		   CONS(rho, R_NilValue)))));
    SEXP formals = PROTECT(CONS(ScalarReal(0), R_NilValue));
    SET_TAG(formals, install("timeout"));
    SET_FORMALS(func, formals);
    SET_BODY(func, func_body);
    SET_CLOENV(func, rho);
    defineVar(install("get"), func, rho);
    UNPROTECT(3);
  }

  {
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SEXP func_body = PROTECT(LCONS(install(".Call"),
           	CONS(mkString("Job_isCancelled"), CONS(rho, R_NilValue))));
    SET_FORMALS(func, R_NilValue);
    SET_BODY(func, func_body);
    SET_CLOENV(func, rho);
    defineVar(install("is.cancelled"), func, rho);
    UNPROTECT(2);
  }

  {
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SEXP func_body = PROTECT(LCONS(install(".Call"),
           CONS(mkString("Job_isDone"), CONS(rho, R_NilValue))));
    SET_FORMALS(func, R_NilValue);
    SET_BODY(func, func_body);
    SET_CLOENV(func, rho);
    defineVar(install("is.done"), func, rho);
    UNPROTECT(2);
  }

  setAttrib(rho, R_ClassSymbol, mkString("Future")); // 

  UNPROTECT(1);

  return rho;
}


SEXP R_future(SEXP job, SEXP op, SEXP timeout);
SEXP Cluster_jobOperation(SEXP what, SEXP job_id);

class_t *Runnable_class = NULL;
const char *runnableToChar(class_t *class, void *data)
{
  return "Runnable"; // FIXME
}
void runnableFinalize(class_t *class, void *object)
{
  run_t *r = (run_t*) object;
  free(r); // FIXME
}


run_t *newRunnable(void (*run)(void *), void *data)
{
  run_t *r = (run_t *) malloc(sizeof(run_t));
  r->class = Runnable_class;
  r->ref_count = REF_COUNT_INITIALIZER;
  r->run = run;
  r->data=data;
  return r;
}

static pthread_mutex_t info_thread = PTHREAD_MUTEX_INITIALIZER;

static struct sigaction R_oldWinchAct;
static struct sigaction __R_oldUsr2Act;

char *info_color = "\033[0;33m";
static int __info_displayed = FALSE;

int info_setDisplayed(int val)
{
  pthread_mutex_lock(&info_thread);
  int retval = __info_displayed;
  if(val == TRUE || val == FALSE) __info_displayed = val;
  pthread_mutex_unlock(&info_thread);
  return retval;
}

static const char *__src_func = NULL;
static const char *__src_file = NULL;
static int __src_line = 0;
static void __src_info(const char *func, const char *file, int line)
{
  __src_func = func;
  __src_file = file;
  __src_line = line;
}

void supr_info(const char *format, ...)
{
  if(Supr_verbose == FALSE)
	  return;
  
  fprintf(stdout, "%s %s:%d", __src_func, __src_file, __src_line);

  va_list ap;
  supr_thread_t *cth = currentThread();
  if(cth) printf("%s %d.%d \033[0m", info_color, cth->pid, cth->tid);
  va_start(ap, format);
  vprintf(format, ap);
  info_setDisplayed(TRUE);
  //if(cth) pthread_kill(cth->pid, SIGWINCH);
  if(cth) raise(SIGWINCH);

  fflush(stdout);
}

//#define printf supr_info
#define printf __src_info(__func__, __FILE__, __LINE__); supr_info


void supr_warning(const char *format, ...)
{
  va_list ap;
  va_start(ap, format);
  vprintf(format, ap);
}

//jmp_buf __cjmpbuf;

static const char* ptrToString(void *ptr, char *buf, int buf_size)
{
  if(!ptr){
    snprintf(buf, buf_size, "(null)");
  } else if(ptr == __R_ToplevelContext){
    snprintf(buf, buf_size, "R_ToplevelContext");
  } else if(ptr == PTHREAD_INTERRUPTED){
    snprintf(buf, buf_size, "PTHREAD_INTERRUPTED");
  } else if(ptr == PTHREAD_ERROR){
    snprintf(buf, buf_size, "PTHREAD_ERROR");
  } else if(ptr == PTHREAD_CANCELED){
    snprintf(buf, buf_size, "PTHREAD_CANCELED");
  } else {
    snprintf(buf, buf_size, "%p", ptr);
  }
  return buf;
}

// debug
static RCNTXT *save_R_GlobalContext = NULL;
static int save_R_GlobalContext_called = 0; 
static void  Save_R_GlobalContext(RCNTXT *save)
{
  save_R_GlobalContext = save;
  save_R_GlobalContext_called = 1; 
//  printf("[%s] is called\n", __func__);
}

#define CheckThreadMain() __CheckThreadMain(__func__, __LINE__) 
void __CheckThreadMain(const char *func, int line)
{
  supr_thread_t *cth = currentThread();
  supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads,0);

//  fprintf(stderr, "[%s] [%p %p] cth - th: %ld (%s:%d)\n", __func__, cth, th, (unsigned long) cth - (unsigned long) th, func, line);
  if(cth!=th){
	  raise(SIGSEGV);
    error("[%s] cth %p != %p (%s:%d)\n", __func__, cth, th, func, line);
  }
}

int __Thread_CheckStack(RCNTXT *cntxt, unsigned long CStackStart,
	       	const char *func, const char *file, int line)
{
//  RCNTXT *cntxt = R_GlobalContext;
  RCNTXT *GlobalContext = cntxt? cntxt : R_GlobalContext;
  if(CStackStart == 0) CStackStart = R_CStackStart;

  if(GlobalContext != save_R_GlobalContext){
    supr_thread_t *cth = currentThread();
    printf("%d %d cth->R_GlobalContext: %p (%s:%d), save_R_GC_called: %d\n",
		    cth->pid, cth->tid,
        cth->R_GlobalContext, file, line, save_R_GlobalContext_called);
    save_R_GlobalContext_called = 0; 
    printf("\033[0;31mGlobalContext (%p) != save_R_GlobalContext (%p)\033[0m\n",
                GlobalContext, save_R_GlobalContext);
  }

return 0;

  int len  = 0;

  int hasError = FALSE;
  unsigned long TT = (unsigned long) &cntxt;

  unsigned long TC = (unsigned long) CStackStart;

  supr_thread_t *cth = (supr_thread_t *) currentThread();

  printf("\n%d %d [%s] %s %s %d\n", cth->pid, cth->tid,
		  __func__, func, file, line);
  printf("[%s] R_GlobalContext: %p, R_CStackStart: %lx\n", __func__,
		  R_GlobalContext, R_CStackStart);
  printf("[%s] __R_ToplevelContext: %p\n", __func__, __R_ToplevelContext);
  printf("[%s] TT - TC: %ld (stack growth direction)\n", __func__, TT- TC);
  printf("[%s] TC - TT: %ld\n", __func__, TC- TT);

  printf("Stack check:\n");

  int count = 0;
  for(cntxt = GlobalContext; cntxt; cntxt = cntxt->nextcontext){
    count ++;
    long d1 = (unsigned long) cntxt - TC;
    long d2 = (unsigned long) cntxt - TT;
    //printf("cntxt: %p\n", cntxt);
    if(!cntxt->nextcontext) break;
    if( d1*d2>0)
    {
      hasError = TRUE;
      printf("\n\033[0;31m%d: [ERROR] (cntxt-TC)*(cntxt-TT)>0\033[0m\n",count);
      printf("\tTT: %lx cntxt: %lx TC: %lx\n", TT, (unsigned long) cntxt, TC);
      printf("\tcntxt - TC: %ld\n", ((unsigned long) cntxt -  TC));
      printf("\tcntxt - TT: %ld\n", ((unsigned long) cntxt - TT));
    } else {
      printf("\t%d: TT: %lx cntxt: %lx TC: %lx\n", count, TT,
		      (unsigned long) cntxt, TC);
    }
    if(count>20) exit(1);
  }

  if(hasError) {
    printf("\033[0;31m[WARNING] FIXME ? (func: %s, %s:%d)\033[0m",
		    func, file, line);
    supr_thread_t *cth = currentThread();

	  pthread_kill(cth->ptid, SIGSEGV);

  } else {
    printf("OKAY  (count: %d) reached ToplevelContext: %s\n\n", count,
		    cntxt == __R_ToplevelContext? "TRUE":"FALSE");
  }

  return hasError;
}

#define CheckStack() __Thread_CheckStack(NULL, 0, __func__, __FILE__, __LINE__)

/*
#define CheckStack1(th) do {	\
  __Thread_CheckStack((th)->R_GlobalContext, (th)->R_CStackStart,	\
		  (__func__), (__FILE__), (__LINE__));	\
while(0)
*/


void ThreadError_print(const char *err)
{
  supr_thread_t *cth = currentThread();

//sleep(2);

  //printf("\033[0;31m[%s] %s\033[0m\n", cth->name, err);
  SEXP //tb = findVar(install(".Traceback"), R_BaseEnv);
  tb = SYMVALUE(install(".Traceback"));
  printf("%s/%s [%s] R_BaseEnv$.Traceback (%s):\n", Supr_hostname, Supr_argv[0],
			cth->name, type2char(TYPEOF(tb)));

  fprintf(stderr, "\n%s/%s [%s] R_BaseEnv$.Traceback (%s):\n", Supr_hostname,
		  Supr_argv[0], cth->name, type2char(TYPEOF(tb)));
  //PrintValue(tb);
  if(TYPEOF(tb) == LISTSXP){
	int i=0;
	while(TYPEOF(tb) != NILSXP){ //PrintValue(CAR(tb));
	    SEXP x = CAR(tb);
	    if(TYPEOF(x) == STRSXP){ // FIXME
	      fprintf(stderr, "%2d: ", i+1); 
  	      for(int i=0; i<LENGTH(x); i++){
  		fprintf(stderr, "%s%s\n", i==0 ?"":"\t", CHAR(STRING_ELT(x,i)));
  	      }
	    } else {
	      fprintf(stderr, "%2d: (%s) ...", i+1, type2char(TYPEOF(x)));
	    }
	    tb = CDR(tb);
	    i++;
	}
  }

  SEXP warnings = SYMVALUE(install("last.warning"));
  fprintf(stderr, "[%s] R_BaseEnv$last.warning (%s):\n", cth->name, type2char(TYPEOF(warnings)));
  if(warnings != R_UnboundValue){
    PrintValue(warnings);
  }

}
	
int Thread_setState(supr_thread_t *th, int state)
{
  supr_thread_t *cth = currentThread();
  if(th->mutex.__data.__owner == cth->tid)
  {
    th->state = state;
    return state;
  }
 
  pthread_mutex_lock(&th->mutex);
    th->state = state;
  pthread_mutex_unlock(&th->mutex);
  return state;
}

#ifndef Hashtable_put

#define Hashtable_put hashtable_set
#define Hashtable_get hashtable_find
#define Hashtable_delete hashtable_delete
#define Hashtable_keySet hashtable_keys
#define Hashtable_destroy hashtable_destroy
#define Hashtable_size hashtable_size

#endif


static hashtable_t *shmCache = NULL;

typedef struct shm_cache_struct {
  char  *name;
  size_t size;
  int    ref_count;
  int    att_len;
  void * att[0];
} shm_cache_t;

void shmCache_free_data(void *data)
{
  shm_cache_t *e = (shm_cache_t*) data;
  free(e->name);
  free(e);
}

//extern void (*ptr_R_Busy)(int);
void supr_R_Busy(int busy);
void save_ptr_R_Busy(int busy);

static int initialized = FALSE;

// R initialization
//SEXP supr_init()
// too many inits, FIXME...
int supr_init()
{
  //printf("%s:\n", __func__);
  //static int initialized = FALSE;
  if(initialized) return -1; // R_NilValue;
  initialized = TRUE;

//  if(ptr_R_Busy != supr_R_Busy) save_ptr_R_Busy = ptr_R_Busy;
  ptr_R_Busy = supr_R_Busy;

  //__supr_malloc_init__();

  shmCache = newHashtable(TRUE);
  shmCache->free_data = shmCache_free_data;

  // remove unused shms
  DIR *dir = opendir("/dev/shm");
  struct dirent *dp;
  while((dp = readdir(dir))){
    if(strncmp("supr", dp->d_name, 4)==0){
      char *str = strdup(dp->d_name);
      //printf("[%s] name: %s\n", __func__, dp->d_name);
      char *s = strtok(str,"-");
      s = strtok(NULL,"-");
      int uid = s ? atoi(s) : -1;
      s = strtok(NULL,"-");
      int pid = s ? atoi(s) : -1;
      if(pid != -1){
        int rc = kill(pid, 0);
        //printf("[%s] uid: %d, pid: %d, kill_rc: %d, name: %s", __func__, uid, pid, rc, dp->d_name);
        if(rc == -1) {
          //printf(" err: %s\n", strerror(errno));
	  rc = shm_unlink(dp->d_name);
          //printf("\tdelete_rc: %d\n", rc);
        } 
      }

      free(str);
    }
  }

  pthread_key_create(&currentThreadKey, NULL);
  pthread_key_create(&interruptThreadKey, NULL);
  pthread_key_create(&stacktraceKey, NULL);
  pthread_key_create(&taskrunnerThreadKey, NULL);

  PTHREAD_INTERRUPTED = malloc(sizeof(void *)); // FIXME ?
  PTHREAD_ERROR = malloc(sizeof(void *)); // FIXME ?
//  PTHREAD_CANCELED = malloc(sizeof(void *)); // FIXME ?

  Runnable_class = newClass("Runnable", runnableToChar, runnableFinalize);

  return 0; //R_NilValue;
}

int supr_fini()
{
  //shmCache = newHashtable(TRUE);
  //shmCache->free_data = shmCache_free_data;
  if(!initialized) return -1;

  pthread_key_delete(currentThreadKey);
  pthread_key_delete(interruptThreadKey);
  pthread_key_delete(stacktraceKey);
  pthread_key_delete(taskrunnerThreadKey);

  free(PTHREAD_INTERRUPTED); PTHREAD_INTERRUPTED = NULL;
  free(PTHREAD_ERROR); PTHREAD_ERROR = NULL;

  // Runnable_class = newClass("Runnable", runnableToChar, runnableFinalize);
  // FIXME
  Runnable_class = NULL;

  initialized = FALSE;
  return 0;
}

void Shm_print(){
  pthread_mutex_lock(shmCache->mutex);
    int n;
    char **keys = Hashtable_keySet(shmCache, &n);
//    printf("\033[0;32m");
    for(int i=0; i<n; i++){
      shm_cache_t *e = (shm_cache_t*) Hashtable_get(shmCache, keys[i]);
//      printf("%4d. %s, sz: %ld, ref: %d, att_len: %d\n", i+1, keys[i], e->size, e->ref_count, e->att_len);
    }
//    printf("\033[0m");
    free(keys);
  pthread_mutex_unlock(shmCache->mutex);
}

void ShmCache_check()
{
  pthread_mutex_lock(shmCache->mutex);
    int n;
    char **keys = Hashtable_keySet(shmCache, &n);
    for(int i=0; i<n; i++){
      shm_cache_t *e = (shm_cache_t*) Hashtable_get(shmCache, keys[i]);
      fprintf(stderr, "%4d. %s, sz: %ld, ref: %d, att_len: %d\n", i+1, keys[i], e->size, e->ref_count, e->att_len);
    }
    free(keys);
  pthread_mutex_unlock(shmCache->mutex);
}

void ShmCache_add(const char *name, size_t size, void *att){
  pthread_mutex_lock(shmCache->mutex);

    size_t sz = sizeof(shm_cache_t) + (att? sizeof(void*):0);
//MALLOC_MARK(__LINE__);
    shm_cache_t *e = (shm_cache_t*) malloc(sz); 
    e->name = strdup(name);
    e->size = size;
    e->ref_count = 1;
    e->att_len = 0;
    if(att){
      e->att_len = 1;
      e->att[0] = att;
    }
//MALLOC_MARK(__LINE__);
    Hashtable_put(shmCache, e->name, e);
//MALLOC_MARK(__LINE__);
  pthread_mutex_unlock(shmCache->mutex);
  //Shm_print();
  ShmCache_check();
}

int ShmCache_inc_ref(const char *name){
  int ref_count;
  pthread_mutex_lock(shmCache->mutex);
    shm_cache_t *e = (shm_cache_t*) Hashtable_get(shmCache, name);
    e->ref_count ++;
    ref_count = e->ref_count;
  pthread_mutex_unlock(shmCache->mutex);
  return ref_count;
}

int ShmCache_dec_ref(const char *name){
  int ref_count;
  pthread_mutex_lock(shmCache->mutex);
    shm_cache_t *e = (shm_cache_t*) Hashtable_get(shmCache, name);
    e->ref_count --;
    ref_count = e->ref_count;
    if(e->ref_count==0){
      shm_unlink(e->name);
      Hashtable_delete(shmCache, e->name);
      //free(e->name);
      //free(e); // removed by Hashtable_delete??
    }
  pthread_mutex_unlock(shmCache->mutex);
  return ref_count;
}

void ShmCache_clear()
{
  pthread_mutex_lock(shmCache->mutex);
    int nkeys;
    char **keys = hashtableKeySet(shmCache,  &nkeys);
    fprintf(stderr, "[%s] nkeys: %d\n", __func__, nkeys);
    for(int i=0; i<nkeys; i++){
       char *key = keys[i];
       if(*key == '/'){
         fprintf(stderr, "\tkey: %s, access: %d\n", key, access(key, F_OK));
       } else {
	 char pathname[strlen(key)+1 + strlen("/dev/shm/")];
	 sprintf(pathname, "/dev/shm/%s", key);
         fprintf(stderr, "\tkey: %s, access: %d\n",
			 key, access(pathname, F_OK));
	 if(access(pathname, F_OK) == -1){ // remove
	   Hashtable_delete(shmCache, key);
	 }
       }
    }
    free(keys);
  pthread_mutex_unlock(shmCache->mutex);
}

/*
// __builtin_frame_address
int Thread_callStack_dl()
{
  c_backtrace();
  Dl_info info; 
  void *r_addr; //, *f_addr;
  int rc;

  c_backtrace();

  for(int level=0; level < 5; level++){
    switch(level){
      case 0:  r_addr = __builtin_return_address(0);  break;
      case 1:  r_addr = __builtin_return_address(1);  break;
      case 2:  r_addr = __builtin_return_address(2);  break;
      case 3:  r_addr = __builtin_return_address(3);  break;
      case 4:  r_addr = __builtin_return_address(4);  break;

      default: break;
    }

    if( !r_addr ) break;

    rc = dladdr(r_addr, &info);
    if(rc) {
      printf("%2d : ", level);
      printf("%p fname: %s, sname:%s\n", r_addr, info.dli_fname, info.dli_sname);
    } else {
      //printf("error: %s\n", dlerror());
      printf("\n");
      break;
    }
  }
  return 0;
}
*/




vector_t *__classes__ = NULL;


const char *cmd2char(int cmd)
{
  static char buf[128];
  switch(cmd){
    case DCL_CONN: 	 return "DCL_CONN";
    case SUPR_INTERRUPT: return "SUPR_INTERRUPT";
    case USER_INTERRUPT: return "USER_INTERRUPT";

    case DFS_DD_NULL:    return "DFS_DD_NULL";
    case DFS_DD_LIST:    return "DFS_DD_LIST";
    case DFS_DD_CREATE:  return "DFS_DD_CREATE";
    case DFS_DD_CREATE_RETURN:  return "CREATE_RETURN";
    case DFS_DD_PUT:     return "DFS_DD_PUT";
    case DFS_DD_PUT_RETURN:     return "DFS_DD_PUT_RETURN";
    case DFS_DD_PERSIST: return "PERSIST";
    case DFS_DD_PERSIST_RETURN: return "PERSIST_RETURN";
    case DFS_DD_UPDATE:  return "DFS_DD_UPDATE";
    case DFS_DD_UPDATE_RETURN:  return "DFS_DD_UPDATE_RETURN";
    case DFS_DD_OPEN:    return "DFS_DD_OPEN";
    case DFS_DD_OPEN_RETURN:    return "DFS_DD_OPEN_RETURN";
    case DFS_DD_REMOVE:  return "DFS_DD_REMOVE";
    case DFS_DD_GET:     return "DFS_DD_GET";
    case DFS_DD_REPLICATE:     return "REPLICATE";
    case DFS_DD_REPLICATE_RETURN:     return "REPLICATE_RETURN";
    case DFS_DD_CLOSE:    return "DFS_DD_CLOSE";
    case DFS_DD_CLOSE_RETURN:    return "DFS_DD_CLOSE_RETURN";
    case DFS_DD_INFO:    return "DFS_DD_INFO";
    case DFS_DD_INFO_RETURN:    return "DFS_DD_INFO_RETURN";

    case DFS_DD_OPTION:    return "DFS_DD_OPTION";
    case DFS_DD_OPTION_RETURN:    return "DFS_DD_OPTION_RETURN";
    case DFS_DD_MOVE:    return "DFS_DD_MOVE";
    case DFS_DD_MOVE_RETURN:    return "DFS_DD_MOVE_RETURN";

    case TASK_RESULTS:   return "TASK_RESULTS";
    case TASK_EXIT:      return "TASK_EXIT";

    case DFS_DATANODE_REGISTER: return "DFS_DATANODE_REGISTER";
    case DRIVER_REGISTER: return "DRIVER_REGISTER";
    case WORKER_REGISTER: return "WORKER_REGISTER";
    case INFO_REGISTER: return "INFO_REGISTER";
    case INFO_CONN:     return "INFO_CONN";
    case DFS_DD_DATANODE_INFO:     return "DATANODE_INFO";
    case CLOSE_CONN:     return "CLOSE_CONN";
    case DFS_START_WORKERS:     return "DFS_START_WORKERS";
    case CLUSTER_JOB_SUBMIT:     return "CLUSTER_JOB_SUBMIT";
    case CLUSTER_MALLOC_PRINT:     return "CLUSTER_MALLOC_PRINT";
    case TR_PRINT_STDOUT:     return "TR_PRINT_STDOUT";
    case TR_PRINT_STDERR:     return "TR_PRINT_STDERR";
    case TR_COUNTDOWN_DECREASE:  return "TR_COUNTDOWN_DECREASE";
    case TR_COUNTDOWN_RELEASE:  return "TR_COUNTDOWN_RELEASE";
    case TASKRUNNER_MESSAGE:  return "TASKRUNNER_MESSAGE";
    case CLUSTER_BYTE_MSG:  return "CLUSTER_BYTE_MSG";
    case HTTP_GET:   return "HTTP_GET";
    case HTTP_POST:  return "HTTP_POST";
    case CLUSTER_PING:  return "PING";
    case CLUSTER_PONG:  return "PONG";
    case CLUSTER_INFO:  return "INFO";
    case CLUSTER_PROC_CMD:  return "PROC_CMD";
    case CLUSTER_INFO_DISCONNECT:  return "INFO_DISCONNECT";
    case TR_CLUSTER_GET:  return "TR_CLUSTER_GET";
    case TR_CLUSTER_SYNC:  return "TR_CLUSTER_SYNC";
    case TR_CLUSTER_SYNC_RETURN:  return "TR_CLUSTER_SYNC_RETURN";
    case TR_CLUSTER_WAIT:  return "TR_CLUSTER_WAIT";
    case TR_CLUSTER_WAIT_RETURN:  return "TR_CLUSTER_WAIT_RETURN";
    case TR_CLUSTER_WAIT_TIMEOUT:  return "TR_CLUSTER_WAIT_TIMEOUT";
    case TR_CLUSTER_NOTIFY:  return "TR_CLUSTER_NOTIFY";
    case TR_CLUSTER_NOTIFYALL:  return "TR_CLUSTER_NOTIFYALL";
    case TR_CLUSTER_INTERRUPT:  return "TR_CLUSTER_INTERRUPT";
    case TR_CLUSTER_UNSYNC:  return "TR_CLUSTER_UNSYNC";
    case CLUSTER_CONNECT_MASTER:  return "CLUSTER_CONNECT_MASTER";
    case CLUSTER_CONNECT_DFSNAME:  return "CLUSTER_CONNECT_DFSNAME";
    case CLUSTER_CONNECT_DRIVER:  return "CLUSTER_CONNECT_DRIVER";
    case CLUSTER_CONNECT_THREADSERVER:  return "CLUSTER_CONNECT_THREADSERVER";
    case CLUSTER_EXECUTOR_REGISTER:  return "CLUSTER_EXECUTOR_REGISTER";
    case DRIVER_INFO:  return "DRIVER_INFO";
    case THREADSERVER_STARTED:  return "THREADSERVER_STARTED";
    case CLUSTER_CONTEXT_GET:  return "CLUSTER_CONTEXT_GET";
    case CLUSTER_CONTEXT_PUT:  return "CLUSTER_CONTEXT_PUT";
    case CLUSTER_CONTEXT_OBJECTS:  return "CLUSTER_CONTEXT_OBJECTS";
    case CLUSTER_CONTEXT_EXISTS:  return "CLUSTER_CONTEXT_EXISTS";
    case CLUSTER_CONTEXT_REMOVE:  return "CLUSTER_CONTEXT_REMOVE";
    case CLUSTER_SHM_CONN:  return "CLUSTER_SHM_CONN";
    case USER_REGISTER:  return "USER_REGISTER";
    case SET_CONN_PID:  return "SET_CONN_PID";
    case DFS_DDT_CALL:  return "DFS_DDT_CALL";
    case CLUSTER_MSG_SEND:  return "CLUSTER_MSG_SEND";
    case CLUSTER_MSG_BROADCAST:  return "CLUSTER_MSG_BROADCAST";
    case TR_CLUSTER_WAIT_TIMEOUT_EXPR:  return "TR_CLUSTER_WAIT_TIMEOUT_EXPR";
    case CLUSTER_SHUTDOWN:  return "CLUSTER_SHUTDOWN";
    case THREAD_SERVER_SHUTDOWN:  return "THREAD_SERVER_SHUTDOWN";
    default: break;
  }
  sprintf(buf,"unknown command: %d", cmd);
  return buf;
}

const char *stringToChar(class_t *class, void *data)
{
  return ((string_t *) data)->str;
}

const char *__stringToChar(class_t *class, void *data)
{
  return ((String) data)->str;
}

void stringFinalize(class_t *class, void *object)
{
  String s = (String) object;
//  free(s->str);
  free(s);
}

/*
class_t *String_class() // FIXME...
{
  static class_t *class  = NULL;
  if(!class) class = newClass("String", __stringToChar, stringFinalize);
  return class;
}
*/

class_t *String_class = NULL;

void String_class_init()
{
  String_class = newClass("String", __stringToChar, stringFinalize);
}

String String_new(const char *format, ...)
{

  static strbuf_t *sb = NULL; // not thread-safe ... FIXME
  if(!sb) sb = newStrbuf(1024);

  va_list ap;
  va_start(ap, format);

  while(TRUE) {
    sb->size = 0;
    sb->buf[0] = 0;
    int n = vsnprintf(sb->buf, sb->buf_size, format, ap);
    if( n < sb->buf_size) break;

    sb = Strbuf_resize(sb, sb->buf_size + sb->buf_size/2);
  }

  size_t size = strlen(sb->buf)+1;
  String s = (String) malloc(sizeof(struct String_struct) + size);
  //s->class = String_class();
  s->class = String_class;
  s->ref_count = REF_COUNT_INITIALIZER;

  s->length= size;
  memcpy(s->str, sb->buf, s->length);
  //memcpy(s + 1, sb->buf, s->length);

  return s;
}

// deprecated
string_t *new_string(char *str, char *src_file, int src_line)
{
 // static class_t *class  = NULL;
  //if(!class) class = newClass("String", stringToChar);
  //printf("\033[0;33mWarning: depreciated %s (%s:%d)\033[0m\n", __func__, __FILE__, __LINE__);

  string_t *s = (string_t *) malloc(sizeof(string_t));
  //s->class = class;
  //s->class = String_class();
  s->class = String_class;
  s->ref_count = REF_COUNT_INITIALIZER;
  s->length = strlen(str) + 1; // USE THIS "plus 1"???
  s->str = str;
  //s->src_file=src_file;
  //s->src_line=src_line;
  //s->ref_count = 1;
  return s;
}


size_t stringLength(string_t *s)
{
  return s->length;
}

//#define INT_SIZE  4
//#define SIZE_SIZE 8

size_t writeString(int fd, string_t *s)
{
  //{
   // printf("[%s] (%s) \n", __func__, s->class->name);
    //printf("[%s] (size_t) length (strlen + 1): %ld\n", __func__, s->length);
    //printf("[%s] str: %s\n", __func__, s->str);
  //}

  size_t size =  write(fd, &s->length, SIZE_SIZE);
  if(size != SIZE_SIZE) return -1;
  size_t len =  write(fd, s->str, s->length);
  if(len != s->length ) return -1;
  return size + len;
}

/*
size_t readString(int fd, string_t *s)
{
  {
    printf("[%s] (%s) \n", __func__, s->class->name);
    printf("[%s] (size_t) length: %ld\n", __func__, s->length);
    printf("[%s] str: %s\n", __func__, s->str);
  }

  size_t len;
  size_t size =  read(fd, &len, SIZE_SIZE);
  if(size != SIZE_SIZE) return -1;
  size_t len =  write(fd, s->str, s->length + 1);
  if(len != s->length + 1 ) return -1;
  return size + len;
}
*/

/*
char *read_string(int fd, char *buf, size_t &buf_size)
{
  size_t len;
  size_t size =  read(fd, &len, SIZE_SIZE);
  if(size != INT_SIZE) return NULL;

  if(!buf || *buf_size < size) {
    buf = (char*) malloc(size);
    *buf_size = size;
  }

  size_t len =  read(fd, buf, size);
  if(len != size) return NULL;
  return buf;
}
*/






#define null R_NilValue
#define is_null(x) TYPEOF(x) == NILSXP


extern ssize_t Socket_send(int socket, const void *buffer, size_t length,
	       	int flags);

ssize_t socketWrite(int fd, void *buf, size_t nbyte) {
  return  Socket_send(fd, buf, nbyte, 0);
}


ssize_t socketRead(int fd, void *buf, size_t nbyte)
{
//	printf("[%s] Okay 01\n", __func__);
  size_t len = read(fd, buf, nbyte);
//	printf("[%s] Okay 02, len: %ld\n", __func__, len);
  if (len==nbyte) return len;

  for(; len < nbyte; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }
    }

//	printf("[%s] Okay 03\n", __func__);
    int n = read(fd, buf + len,   nbyte - len);
//	printf("[%s] Okay 04, len: %d\n", __func__, n);

    if(n <= 0){
//      printf("[%s] read, n = %d, %s\n", __func__, n, strerror(errno));
      return -1;
    }

    len += n;
  }

  return len;

}

static int javaDriver_PID = 0; // change variable name...
static int rDriver_PID = 0;


static  struct sigaction R_oldactInt;
static  struct sigaction Java_oldactInt;
static  struct sigaction Java_oldactUsr1;


pthread_t signalHandlerThread_ptid = 0;
unsigned int signalHandlerThread_tid = 0;

void  SUPR_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  if(pthread_equal(pthread_self(), signalHandlerThread_ptid)){
    printf("\033[0;33m[INFO][%s] handlerThread_ptid=%ld\033[0m\n\n", __func__,
                  signalHandlerThread_ptid);
    supr_thread_t *th = currentThread();
    pthread_mutex_lock(&th->mutex);
      printf("[%s] currentThread: %s\n", __func__, objectToString(th));
    pthread_mutex_unlock(&th->mutex);
  } else {
    printf("\033[0;37m[INFO][%s] pthread_self()=%ld -> %ld\033[0m\n",
                    __func__, pthread_self(), signalHandlerThread_ptid);
    pthread_kill(signalHandlerThread_ptid, sig);
  }
}


void  SUPR_SigactionSIGUSR1(int sig, siginfo_t *ip, void *context)
{

  if(pthread_equal(pthread_self(), signalHandlerThread_ptid)){
    printf("\033[0;33m[INFO][%s] handlerThread_ptid=%ld\033[0m\n\n", __func__,
                  signalHandlerThread_ptid);
    supr_thread_t *th = currentThread();
    pthread_mutex_lock(&th->mutex);
      printf("[%s] currentThread: %s\n", __func__, objectToString(th));
    pthread_mutex_unlock(&th->mutex);

    c_backtrace();
  } else {
    printf("\033[0;37m[INFO][%s] pthread_self()=%ld -> %ld\033[0m\n",
                    __func__, pthread_self(), signalHandlerThread_ptid);
    pthread_kill(signalHandlerThread_ptid, sig);
  }

}

void  SUPR_SigactionSIGUSR2(int sig, siginfo_t *ip, void *context)
{
    printf("\033[0;37m[INFO][%s] pthread_self()=%ld\033[0m\n", __func__,
		    pthread_self());
    c_backtrace();
}

supr_conn_t *connections[2*CONN_OPEN_MAX];

//vector_t *connVector = NULL;

//int isInterrupted = FALSE;


const char *threadToString(class_t *class, void *object);
void threadFinalize(class_t *class, void *object);

static class_t __thread_class = {"Thread", threadToString,
	threadFinalize};

//class_t *Thread_class = NULL;
class_t *Thread_class = &__thread_class;

char *threadStateToString[] = { "NEW", "RUNNABLE", "BLOCKED", "WAITING",
       	"TIMED_WAITING", "TERMINATED" };

const char *threadToString(class_t *class, void *object)
{
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(256);

  sb->size = 0; 

  supr_thread_t *th = (supr_thread_t *) object;
  strbufPutStr(sb, "(");
  strbufPutStr(sb, class->name);
  strbufPutStr(sb, ") ");
  char buf[256];
  sprintf(buf, "<%p> %lx:%d %s", object, th->ptid, th->tid,
		  threadStateToString[th->state]);
  strbufPutStr(sb, buf);
  return sb->buf;
}

void threadDestroy(supr_thread_t *th);
void threadFinalize(class_t *class, void *object)
{
	if(Supr_verbose){
	  printf("object: %p\n", object);
	}

  supr_thread_t *th = (supr_thread_t *) object;
  threadDestroy(th); // FIXME
}

supr_thread_t *newThread(pthread_t ptid, pid_t pid, pid_t tid, int state,
		unsigned long C_StackStart)
{
	/*
  if(!Thread_class){
    Thread_class = newClass("Thread", threadToString, threadFinalize);
  }
  */
  //printf("Thread_class: %p\n", Thread_class);
  //printf("pid: %d, tid: %ld\n", getpid(), syscall(SYS_gettid));
  //fflush(stdout);

  supr_thread_t *th = malloc(sizeof(supr_thread_t));
  th->class  = Thread_class;
  th->ref_count = REF_COUNT_INITIALIZER;
  th->ptid  = ptid;
  th->pid   = pid;
  th->tid   = tid;
  th->state = state;

  th->fun  = NULL;
  th->data = NULL;

  th->where = NULL;


  {
    th->conn = NULL;
    th->sharedEnv = R_EmptyEnv;
  }

  th->data = NULL; // ???
  th->properties = NULL;

  pthread_mutex_init(&th->mutex, NULL);
  pthread_cond_init(&th->cond, NULL);

  th->save_R_PPStackTop = 0;
  th->R_thread = R_NilValue;
  th->R_GlobalContext = __R_ToplevelContext; // NULL;
  th->R_CStackStart   = C_StackStart; // 
  
  char buf[256];
  sprintf(buf, "Thread.%d", th->tid);
  th->name = strdup(buf);

  th->runnable = NULL;

  th->R_eval_state = 0;
  th->R_ToplevelContext = __R_ToplevelContext;


  return th;
}

void threadDestroy(supr_thread_t *th)
{
	if(Supr_verbose){
	  printf("pid: %d, tid: %ld\n", getpid(), syscall(SYS_gettid));
	}
  int rc;
  if(!pthread_equal(pthread_self(), th->ptid))
  {
    rc = pthread_cancel(th->ptid);
    if(rc != ESRCH){
	    /*
      fprintf(stderr, "[%s] pthread_cancel(%ld, %d, %d): rc = %d"
		     "No thread with the ID %ld could be found\n",
		    __func__, th->ptid, th->pid, th->tid, rc,
		    th->ptid);
    } else {*/
      fprintf(stderr, "[%s] pthread_cancel(%ld, %d, %d): rc = %d %s\n",
		    __func__, th->ptid, th->pid, th->tid, rc,
		    rc? strerror(errno):"");
    }
    
  }

  if(Supr_verbose){
    printf("[0/2] pthread_cancel(th->ptid): %d (ESRCH=%d)\n", rc, ESRCH);
  }

  rc = pthread_mutex_destroy(&th->mutex);
  if(Supr_verbose){
    printf("[1/2] pthread_mutex_destroy(&th->mutex): %d\n", rc);
    if(rc){
      char *err = NULL;
      switch(rc){
        case EPERM: err = "no privilege";
		  break;
        case EBUSY: err = "mutex is busy";
		  break;
        default: err= "don't know";
		  break;
      }
      printf("error: %s\n", err);
    }
  }

  if(rc == 0){

    rc = pthread_cond_destroy(&th->cond);
    if(Supr_verbose){
      printf("[2/2] pthread_cond_destroy(&th->cond): %d\n", rc);
    }
  }
  free(th);
}

supr_thread_t *currentThread()
{
  return (supr_thread_t *) pthread_getspecific(currentThreadKey);
}

/*
typedef struct job_struct {
  int job_id;
  int count; // or simply for padding 
  void *expr; // (serialized R expression for taskrunners
  void *environment; // for driver and workers?

  iterator_t *tasks; // implemented as subsets
  char *name; // for driver user interface
  void *result;
} job_t;
*/



// libsupr.so init
void __init()
{
  printf("[%s] ????\n", __func__);
}



void addCleanups(void (*run)(void *), void *data)
{
//  if(!cleanups) cleanups = newVector(FALSE);

  run_t *cleanup = (run_t *)malloc(sizeof(run_t));
  cleanup->run = run;
  cleanup->data = data;
  if(cleanups->mutex){
    pthread_mutex_lock(cleanups->mutex);
      vectorAdd(cleanups, cleanup);
    pthread_mutex_unlock(cleanups->mutex);
  } else {
    error_info("%s:%d. %s FIXME ", __FILE__, __LINE__, __func__);
    vectorAdd(cleanups, cleanup);
  }
}



void doCleanups(){

  basic_info("pid: %d, main_pid: %d, cleanups: %p", getpid(), main_pid,
		  cleanups);

  if(getpid() != main_pid) return;

  if(cleanups){
    basic_info("vectorSize(cleanups): %d", vectorSize(cleanups));
    for(int i=vectorSize(cleanups)-1; i>=0; i--){
      run_t *cleanup = (run_t *) vectorElementAt(cleanups, i);
      basic_info("[%d %s] do_cleanup %p", getpid(),  __func__, cleanup);
      cleanup->run(cleanup->data);
      vectorRemove(cleanups, i);
    }
  }
}

char *cmd2str(int cmd){
  switch(cmd){
    case TR_EXIT: return "TR_EXIT"; // cmd
    case TR_NEW_JOB: return "TR_NEW_JOB"; // cmd array
    case TR_SEND_DRIVER: return "TR_SEND_DRIVER"; // cmd array
    case TR_JOB_RESULT: return "TR_JOB_RESULT"; // cmd array
    case TR_NEXT_SUBSET: return "TR_NEXT_SUBSET"; // cmd array
    default: break;
  }

  return "Unknown Command";
}

// R_serialize
// copied from R

extern void R_Serialize(SEXP s, R_outpstream_t stream);

extern void R_InitOutPStream(R_outpstream_t stream, R_pstream_data_t data,
                 R_pstream_format_t type, int version,
                 void (*outchar)(R_outpstream_t, int),
                 void (*outbytes)(R_outpstream_t, void *, int),
                 SEXP (*phook)(SEXP, SEXP), SEXP pdata);

extern void R_InitInPStream(R_inpstream_t stream, R_pstream_data_t data,
                R_pstream_format_t type,
                int (*inchar)(R_inpstream_t),
                void (*inbytes)(R_inpstream_t, void *, int),
                SEXP (*phook)(SEXP, SEXP), SEXP pdata);


typedef size_t R_size_t; // defined in Defn.h

typedef struct membuf_st {
    R_size_t size;
    R_size_t count;
    unsigned char *buf;
} *membuf_t;

//#define _(x) x

#define MAXELTSIZE 8192   // Defn.h
#define INCR MAXELTSIZE

void resize_buffer(membuf_t mb, R_size_t needed)
{


    if(needed > R_XLEN_T_MAX)
        error(_("serialization is too large to store in a raw vector"));
#ifdef LONG_VECTOR_SUPPORT
    if(needed < 10000000) /* ca 10MB */
        needed = (1+2*needed/INCR) * INCR;
    else
        needed = (R_size_t)((1+1.2*(double)needed/INCR) * INCR);
#else
    if(needed < 10000000) /* ca 10MB */
        needed = (1+2*needed/INCR) * INCR;
    else if(needed < 1700000000) /* close to 2GB/1.2 */
        needed = (R_size_t)((1+1.2*(double)needed/INCR) * INCR);
    else if(needed < INT_MAX - INCR)
        needed = (1+needed/INCR) * INCR;
#endif
//    unsigned char *tmp = realloc(mb->buf, needed); // can cause SIGSEGV
                   // through malloc (), _int_malloc (), malloc_consolidate()

#ifdef CHECKING_SERIALIZE_RESIZE_BUFFER
    int extra_size = strlen(BUFFER_EXTRA)+1;
if(mb->size > extra_size){
   //fprintf(stderr, "\033[0;31m%s\n\033[0m", (char*)(mb->buf+mb->size));
} else if(mb->size ==0){
   //fprintf(stderr, "\033[0;32mStarted with NULL\n\033[0m");
}
    unsigned char *tmp = realloc(mb->buf, needed+extra_size); // can cause SIGSEGV
    if(tmp) sprintf((char*)(tmp+needed), "%s", BUFFER_EXTRA);
#else
    unsigned char *tmp = realloc(mb->buf, needed); // can cause SIGSEGV
#endif

    if (tmp == NULL) {
        free(mb->buf); mb->buf = NULL;
        error(_("cannot allocate buffer"));
    } else
            mb->buf = tmp;
    mb->size = needed;

}


static void OutCharMem(R_outpstream_t stream, int c)
{
    membuf_t mb = stream->data;
    if (mb->count >= mb->size)
        resize_buffer(mb, mb->count + 1);
    mb->buf[mb->count++] = (char) c;
}

static void OutBytesMem(R_outpstream_t stream, void *buf, int length)
{
    membuf_t mb = stream->data;
    R_size_t needed = mb->count + (R_size_t) length;
////
//fprintf(stderr, "\033[0;35mmb->count = %lu\033[0m --> ",mb->count);
////
#ifndef LONG_VECTOR_SUPPORT
    /* There is a potential overflow here on 32-bit systems */
    if((double) mb->count + length > (double) INT_MAX)
        error(_("serialization is too large to store in a raw vector"));
#endif
    if (needed > mb->size) resize_buffer(mb, needed);
    memcpy(mb->buf + mb->count, buf, length);
    mb->count = needed;
}

static int InCharMem(R_inpstream_t stream)
{
    membuf_t mb = stream->data;
    if (mb->count >= mb->size) //error(_("read error"));
              error(_("read error (%s:%d)"), __FILE__, __LINE__);
    return mb->buf[mb->count++];
}

static void InBytesMem(R_inpstream_t stream, void *buf, int length)
{
    membuf_t mb = stream->data;
    if (mb->count + (R_size_t) length > mb->size) //error(_("read error"));
              error(_("read error (%s:%d)"), __FILE__, __LINE__);
    memcpy(buf, mb->buf + mb->count, length);
    mb->count += length;
}


static void InitMemInPStream(R_inpstream_t stream, membuf_t mb,
                             void *buf, R_size_t length,
                             SEXP (*phook)(SEXP, SEXP), SEXP pdata)
{
    mb->count = 0;
    mb->size = length;
    mb->buf = buf;
    R_InitInPStream(stream, (R_pstream_data_t) mb, R_pstream_any_format,
                    InCharMem, InBytesMem, phook, pdata);
}

// serialized bytes starts from offset
static void InitMemOutPStream7(R_outpstream_t stream, membuf_t mb,
                              R_pstream_format_t type, int version,
                              SEXP (*phook)(SEXP, SEXP), SEXP pdata,
			      size_t offset)
{
    if(offset>0){
      mb->count = offset;
      mb->size = offset;
      mb->buf = malloc(offset);
      memset(mb->buf, 0, offset);
    } else {
      mb->count = 0;
      mb->size = 0;
      mb->buf = NULL;
    }
    R_InitOutPStream(stream, (R_pstream_data_t) mb, type, version,
                     OutCharMem, OutBytesMem, phook, pdata);
}

static void InitMemOutPStream(R_outpstream_t stream, membuf_t mb,
                              R_pstream_format_t type, int version,
                              SEXP (*phook)(SEXP, SEXP), SEXP pdata)
{
    mb->count = 0;
    mb->size = 0;
    mb->buf = NULL;
    R_InitOutPStream(stream, (R_pstream_data_t) mb, type, version,
                     OutCharMem, OutBytesMem, phook, pdata);
}





static void free_mem_buffer(void *data)
{
    membuf_t mb = data;
    if (mb->buf != NULL) {
        unsigned char *buf = mb->buf;
        mb->buf = NULL;
        free(buf);
    }
}

static void *CloseMemOutPStreamAndReturnBytes(R_outpstream_t stream,
	       	size_t *size)
{
    void *val;
    membuf_t mb = stream->data;
#ifdef CHECKING_SERIALIZE_RESIZE_BUFFER
int extra_size = strlen(BUFFER_EXTRA);
if(mb->size > extra_size){
//  fprintf(stderr, "\033[0;35m%s\n\033[0m", mb->buf+mb->size);
  if(strcmp((char*)(mb->buf+mb->size), BUFFER_EXTRA)){
    fprintf(stderr, "\n\033[1;31m******* Whoops *******\n\n\033[0m");
    error(_("\033[1;31m******* Whoops *******\033[0m"));
  }
}
#endif
    /* duplicate check, for future proofing */
#ifndef LONG_VECTOR_SUPPORT
    if(mb->count > INT_MAX)
        error(_("serialization is too large to store in a raw vector"));
#endif
    *size = mb->count;
    val = mb->buf;
    mb->buf = NULL;

    //free_mem_buffer(mb);
	/*
    PROTECT(val = allocVector(RAWSXP, mb->count));
    memcpy(RAW(val), mb->buf, mb->count);
    free_mem_buffer(mb);
    UNPROTECT(1);
    */
    return val;
}

static SEXP CloseMemOutPStream(R_outpstream_t stream)
{
    SEXP val;
    membuf_t mb = stream->data;
#ifdef CHECKING_SERIALIZE_RESIZE_BUFFER
int extra_size = strlen(BUFFER_EXTRA);
if(mb->size > extra_size){
//  fprintf(stderr, "\033[0;35m%s\n\033[0m", mb->buf+mb->size);
  if(strcmp((char*)(mb->buf+mb->size), BUFFER_EXTRA)){
    fprintf(stderr, "\n\033[1;31m******* Whoops *******\n\n\033[0m");
    error(_("\033[1;31m******* Whoops *******\033[0m"));
  }
}
#endif
    /* duplicate check, for future proofing */
#ifndef LONG_VECTOR_SUPPORT
    if(mb->count > INT_MAX)
        error(_("serialization is too large to store in a raw vector"));
#endif
    PROTECT(val = allocVector(RAWSXP, mb->count));
    memcpy(RAW(val), mb->buf, mb->count);
    free_mem_buffer(mb);
    UNPROTECT(1);
    return val;
}

static const int R_DefaultSerializeVersion = 2;

void *R_objectToBytes3(SEXP object, size_t *size, size_t offset)
{

  struct R_outpstream_st out;
  R_pstream_format_t type;

  type = R_pstream_xdr_format; // R_pstream_ascii_format; R_pstream_binary_format;
  int version = R_DefaultSerializeVersion;
  SEXP (*hook)(SEXP, SEXP) = NULL;
  SEXP fun = R_NilValue;

        RCNTXT cntxt;
        struct membuf_st mbs; //?
        void *val = NULL; // SEXP val;

        /* set up a context which will free the buffer if there is an error */
        begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);
        cntxt.cend = &free_mem_buffer;
        cntxt.cenddata = &mbs;

        InitMemOutPStream7(&out, &mbs, type, version, hook, fun, offset);
        //InitMemOutPStream(&out, &mbs, type, version, hook, fun);
        R_Serialize(object, &out);

        //val =  CloseMemOutPStream(&out);
        val =  CloseMemOutPStreamAndReturnBytes(&out, size);

        /* end the context after anything that could raise an error but before
           calling OutTerm so it doesn't get called twice */
        endcontext(&cntxt);

        return val;
}

void *R_objectToBytes(SEXP object, size_t *size)
{
  return R_objectToBytes3(object, size, 0);
}

SEXP R_objectToRaw(SEXP object)
{

  struct R_outpstream_st out;
  R_pstream_format_t type;

  type = R_pstream_xdr_format; // R_pstream_ascii_format; R_pstream_binary_format;
  int version = R_DefaultSerializeVersion;
  SEXP (*hook)(SEXP, SEXP) = NULL;
  SEXP fun = R_NilValue;


        RCNTXT cntxt;
        struct membuf_st mbs; //?
        SEXP val;

        /* set up a context which will free the buffer if there is an error */
        begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);
        cntxt.cend = &free_mem_buffer;
        cntxt.cenddata = &mbs;

        InitMemOutPStream(&out, &mbs, type, version, hook, fun);
        R_Serialize(object, &out);

        val =  CloseMemOutPStream(&out);

        /* end the context after anything that could raise an error but before
           calling OutTerm so it doesn't get called twice */
        endcontext(&cntxt);

        return val;
}

extern SEXP R_Unserialize(R_inpstream_t stream);

SEXP R_bytesToObject(void *data, size_t length)
{
  struct R_inpstream_st in;
  struct membuf_st mbs;

  InitMemInPStream(&in, &mbs, data,  length, NULL, R_NilValue);
  return R_Unserialize(&in);
}

SEXP R_rawToObject(SEXP icon)
{
  SEXP fun = R_NilValue;

  struct R_inpstream_st in;
  SEXP (*hook)(SEXP, SEXP);

  //hook = fun != R_NilValue ? CallHook : NULL;
  hook = NULL;

  if(TYPEOF(icon) == RAWSXP){
    struct membuf_st mbs;
    void *data = RAW(icon);
    R_size_t length = XLENGTH(icon);
    InitMemInPStream(&in, &mbs, data,  length, hook, fun);
    return R_Unserialize(&in);
  }
}

// supr_object:
so_t *SO_error(const char *msg)
{
  so_t *so = malloc(sizeof(so_t)+strlen(msg)+1);
  so->ref_count = 1;
  so->mem_type = 0;
  so->sys_type = 0; // R
  so->obj_type = SUPR_ERROR;
  so->size = strlen(msg)+1;
  memcpy(so+1, msg, so->size);
  return so;
}

extern so_t *SO_getDDSubset(const char *dd_name, const char *subset_name,
                const char *addr, SEXP func, SEXP env);
extern const char *type2suffix(int type);

SEXP SO_toRObject(void *ptr, size_t size)
{
  so_t *so = (so_t *)ptr;

  /*
  if(so->mem_type == SUPR_MEMTYPE_FILE){ // file?
    char *file_name = (char*)(so + 1);
    printf("[%s] file_name: %s\n", __func__, file_name);
    return R_MakeExternalPtr(so, R_NilValue,  R_NilValue);
  }
  */
   

  switch(so->obj_type){
    case SUPR_SERIALIZED_ROBJ:
	 {
           SEXP val = PROTECT(R_bytesToObject(so+1, so->size));
      //     PrintValue(val);
           UNPROTECT(1);
	   return val;
	 }
	 break;

    case SUPR_PTHREAD_TIMEOUT:
	 {
           //return R_UnboundValue;
	   SO_decref(so);
           error(_("timeout"));
	 }
	 break;

    case SUPR_PTHREAD_INTERRUPTED:
	 {
           return R_UnboundValue;
	 }
	 break;

    case SUPR_UNBOUND_VALUE:
    case SUPR_NILSXP:
	 {
           return R_NilValue;
	 }
	 break;

    case SUPR_INT_ARRAY:
	 {
           int *x = (int*) (so+1);
	   int len = x[0]; x++;
	   SEXP val = allocVector(INTSXP, len);
	   memcpy(INTEGER(val), x, sizeof(int)*len);
	   return val;
	 }
	 break;

    case SUPR_LGLSXP:
	 {
           int *x = (int*) (so+1);
	   int len = x[0]; x++;
	   SEXP val = allocVector(LGLSXP, len);
	   memcpy(LOGICAL(val), x, sizeof(int)*len);
	   return val;
	 }
	 break;

    case SUPR_SO_ARRAY:
	 {
           size_t *offset = (size_t*) so->val;
	   int n = (int) offset[0]; offset ++;
	   SEXP val = PROTECT(allocVector(VECSXP, n));
	   for(int i=0; i<n; i++){
             so_t *s = (so_t *)(ptr + offset[i]);
	     SEXP e = SO_toRObject(s, sizeof(so_t) + s->size);
	     SET_VECTOR_ELT(val, i, e);
	   }
	   UNPROTECT(1);
	   return val;
	 }
	 break;

    case SUPR_STRING_ARRAY:
    case SUPR_DD_SUBSET_LOCATIONS:
	 {
           size_t *offset = (size_t*) so->val;
	   int n = (int) offset[0]; offset ++;
	   //printf("\033[0;31mn: %d\033[0m\n", n);
	   //sleep(2);
	   SEXP val = PROTECT(allocVector(STRSXP, n));
	   for(int i=0; i<n; i++){
             char *s = (char *)(ptr + offset[i]);
	     SET_STRING_ELT(val, i, mkChar(s));
	   }

	   if(so->obj_type == SUPR_DD_SUBSET_LOCATIONS){ // do this in nextSub?
//             so_t *s = SO_getDDSubset(name, s_name, addr, func, env);
             const char *name = CHAR(STRING_ELT(val, 0));
             const char *s_name = CHAR(STRING_ELT(val, 1));
	     SEXP func = R_NilValue;
	     for(int i=2; i<n; i++){
               const char *addr = CHAR(STRING_ELT(val, i)); 
	       //basic_info(addr);
               so_t *s = SO_getDDSubset(name, s_name, addr, func, R_GlobalEnv);

               if(s){

                 if(s->mem_type == SUPR_MEMTYPE_FILE){ // FIXME

                   SEXP raw = PROTECT(allocVector(RAWSXP, s->size));
                   memcpy(DATAPTR(raw), s+1, s->size);
                   //SET_VECTOR_ELT(val, i, raw);
	           val = raw;
                   UNPROTECT(1);
                   setAttrib(raw, install("file.suffix"),
                     mkString(type2suffix(s->obj_type)));
		 } else if(s->obj_type == SUPR_R_OBJECT){
                   //SET_VECTOR_ELT(val, i, *((SEXP*) s->val));
                   val = *((SEXP*) s->val);
		 } else {
			 val = SO_toRObject(s, sizeof(so_t) + s->size);
		 }
		 free(s);
		 break;
	       }
	     }
	   }


	   UNPROTECT(1); //   PrintValue(val);
	   return val;
	 }
	 break;


	 /* FIXME
    case SUPR_ERROR:
	 {
	   SEXP err = mkChar((char*)(so+1));
	   if(free_ptr) free(so);
	   error(_("%s"), CHAR(err));
	 }
	 break;
	 */


    default: break;
  }

  /*
  char *buf = NULL;
  Supr_debug2(getpid(), &buf);
  if(buf) error_info(buf);
  free(buf);
  */

  SUPR_GDB_DEBUG();

  errorcall(R_NilValue, "not implemented for [obj_type: %d] (%s, %d)",
		  so->obj_type, __FILE__, __LINE__);
}


SEXP SO_toRObj(void *ptr)
{
  so_t *so = (so_t *)ptr;

  /*
  if(so->mem_type == SUPR_MEMTYPE_FILE){ // file?
    char *file_name = (char*)(so + 1);
    printf("[%s] file_name: %s\n", __func__, file_name);
    return R_MakeExternalPtr(so, R_NilValue,  R_NilValue);
  }
  */
   
  SEXP val;

  switch(so->obj_type){
    case SUPR_SERIALIZED_ROBJ:
         val = R_bytesToObject(so+1, so->size);
	 break;

    case SUPR_PTHREAD_TIMEOUT:
	 SO_decref(so);
         error(_("timeout"));
	 break;

    case SUPR_PTHREAD_INTERRUPTED:
         val = R_UnboundValue;
	 break;

    case SUPR_UNBOUND_VALUE:
    case SUPR_NILSXP:
         val = R_NilValue;
	 break;

    case SUPR_INT_ARRAY:
	 {
           int *x = (int*) (so+1);
	   int len = x[0]; x++;
	   val = allocVector(INTSXP, len);
	   memcpy(INTEGER(val), x, sizeof(int)*len);
	 }
	 break;

    case SUPR_LGLSXP:
	 {
           int *x = (int*) (so+1);
	   int len = x[0]; x++;
	   val = allocVector(LGLSXP, len);
	   memcpy(LOGICAL(val), x, sizeof(int)*len);
	 }
	 break;

    case SUPR_SO_ARRAY:
	 {
           size_t *offset = (size_t*) so->val;
	   int n = (int) offset[0]; offset ++;
	   val = PROTECT(allocVector(VECSXP, n));
	   for(int i=0; i<n; i++){
             so_t *s = (so_t *)(ptr + offset[i]);
	     SEXP e = SO_toRObject(s, sizeof(so_t) + s->size);
	     SET_VECTOR_ELT(val, i, e);
	   }
	   UNPROTECT(1);
	 }
	 break;

    case SUPR_STRING_ARRAY:
    case SUPR_DD_SUBSET_LOCATIONS:
	 {
           size_t *offset = (size_t*) so->val;
	   int n = (int) offset[0]; offset ++;
	   //printf("\033[0;31mn: %d\033[0m\n", n);
	   //sleep(2);
	   val = PROTECT(allocVector(STRSXP, n));
	   for(int i=0; i<n; i++){
             char *s = (char *)(ptr + offset[i]);
	     SET_STRING_ELT(val, i, mkChar(s));
	   }

	   if(so->obj_type == SUPR_DD_SUBSET_LOCATIONS){ // do this in nextSub?
//             so_t *s = SO_getDDSubset(name, s_name, addr, func, env);
             const char *name = CHAR(STRING_ELT(val, 0));
             const char *s_name = CHAR(STRING_ELT(val, 1));
	     SEXP func = R_NilValue;
	     for(int i=2; i<n; i++){
               const char *addr = CHAR(STRING_ELT(val, i)); 
	       //basic_info(addr);
               so_t *s = SO_getDDSubset(name, s_name, addr, func, R_GlobalEnv);

               if(s){

                 if(s->mem_type == SUPR_MEMTYPE_FILE){ // FIXME

                   SEXP raw = PROTECT(allocVector(RAWSXP, s->size));
                   memcpy(DATAPTR(raw), s+1, s->size);
                   //SET_VECTOR_ELT(val, i, raw);
	           val = raw;
                   UNPROTECT(1);
                   setAttrib(raw, install("file.suffix"),
                     mkString(type2suffix(s->obj_type)));
		 } else if(s->obj_type == SUPR_R_OBJECT){
                   //SET_VECTOR_ELT(val, i, *((SEXP*) s->val));
                   val = *((SEXP*) s->val);
		 } else {
			 val = SO_toRObject(s, sizeof(so_t) + s->size);
		 }
		 free(s);
		 break;
	       }
	     }
	   }
	   UNPROTECT(1); //   PrintValue(val);
	 }
	 break;

    case SUPR_ERROR:
	 {
	   SEXP err = mkChar((char*)(so+1));
	   SO_decref(so);
	   error(_("%s"), CHAR(err));
	 }
	 break;

    case SUPR_REFERENCE:
	 {
	   //char *str = (char*)(so+1);
	   //char buf[strlen(str)+1+2];
	   //sprintf(buf, "<%s>", str);
	   //val = mkString(buf);
	   char buf[256];
	   sprintf(buf, "<local_ptr: %p>", ((void**)(so+1))[0]);
	   val = mkString(buf);
	 }
	 break;


    default:
         {
	   SUPR_GDB_DEBUG();
           errorcall(R_NilValue, "not implemented for [obj_type: %d] (%s, %d)",
		  so->obj_type, __FILE__, __LINE__);
	 }
	 break;
  }
  SO_decref(so);
  return val;
}


// #define dupstr(x) memcpy(malloc(strlen(x)+1), (x), strlen(x)+1)


class_t *newClass(char *name, const char *(*toString)(class_t *, void *),
                  void (*finalize)(class_t *, void *))
{

  class_t *c = (class_t *) malloc(sizeof(class_t));
  c->name = name;
  c->toString = toString;
  c->finalize = finalize;

  if(__classes__)
    vectorAdd(__classes__, c);
  /*else {
    __classes__ = newVector(TRUE);
    vectorAdd(__classes__, __classes__->class);
  }*/

  return c;
}

class_t *getClass(void *ptr)
{
  if(!__classes__){
    __classes__ = newVector(TRUE);
    vectorAdd(__classes__, __classes__->class);
  }

  class_t *ptr_class = ((object_t *) ptr)->class;

  for(int i=0; i<vectorSize(__classes__); i++){
     class_t *class = (class_t*) vectorElementAt(__classes__, i);
     if(ptr_class == class) return class;
  }

  return NULL;
}

const char *strbufToString(class_t *class, void *object){
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(1024);
  sb->size = 0;
  char buf[256];
  sprintf(buf, "(%s) size = %ld, buf_size = %ld", class->name,
		  sb->size, sb->buf_size);
  strbufPut(sb, buf, strlen(buf));
  //return _dupstr(sb->buf);
  return sb->buf;
}

void strbufFinalize(class_t *class, void *object)
{
  strbuf_t * sb = (strbuf_t *) object;
  free(sb->buf);
  free(sb);
}

strbuf_t *newStrbuf(size_t size)
{
  strbuf_t *sb = (strbuf_t *) malloc(sizeof(strbuf_t));
  static class_t *class = NULL;
  if(!class) class = newClass("strbuf", strbufToString, strbufFinalize);
  sb->class = class;
  sb->ref_count = REF_COUNT_INITIALIZER;
  sb->buf = malloc(size);
  sb->buf_size = size;

  sb->size = 0;
  sb->buf[0] = 0;

  return sb;
}

strbuf_t *Strbuf_resize(strbuf_t *sb, size_t size)
{
  sb->buf = realloc(sb->buf, size);
  sb->buf_size = size;
  return sb;
}


strbuf_t *strbufPut(strbuf_t *sb, const void *p, size_t size)
{
  if(sb->size + size >= sb->buf_size){
    /*
    unsigned char *buf = sb->buf;
    sb->buf_size += size+1;
    sb->buf = (unsigned char *)malloc(sb->buf_size);
    memcpy(sb->buf, buf, sb->size);
    free(buf);
    */
    sb->buf_size += size+1;
    sb->buf = (unsigned char *)realloc(sb->buf, sb->buf_size);
  } 

  memcpy(sb->buf + sb->size, p, size);
  sb->size += size;
  sb->buf[sb->size] = 0;
  return sb;
}

strbuf_t *strbufPutStr(strbuf_t *sb, const char *str)
{
  return strbufPut(sb, str, strlen(str));
}



off_t getFileSize(int fd)
{
  struct stat statbuf;
  int rc = fstat(fd, &statbuf);
  if(rc == -1)
    errorcall(null, "fstat(%d), %s\n", __func__, fd, strerror(errno));
  return statbuf.st_size;
}


char *fileRead(const char* file)
{
  int fd = open(file, O_RDONLY);
  if(fd == -1)
  {
    //errorcall(null, "open(%s), %s", file, strerror(errno));
    //printf("[%s] open(%s), %s", __func__, file, strerror(errno));
    return NULL;
  }

  off_t size  = getFileSize(fd);
//  printf("size = %ld\n", size);
  if(size == 0){
    close(fd);
    char *buf = malloc(256);
    sprintf(buf, "//localhost:0");
    return buf;
  }

  char *p = (char*) malloc(size+1);
  read(fd, p, size);
  p[size] = 0;
  //printf("[%s] %s\n", __func__, p);
  close(fd);
  return p;
}

size_t fileWrite(const char *file, char *buf, size_t buf_size)
{
//  fprintf(stderr, "[%s] write (%s, buf, %ld)\n", __func__, file, buf_size);
  //int fd = open(file, O_WRONLY | O_CREAT | O_TRUNC);
  int fd = open(file, O_RDWR |  O_CREAT | O_TRUNC, 0600);
  if(fd == -1)
  {
   // errorcall(null, "open(%s), %s", file, strerror(errno));
   fprintf(stderr, "[%s] Error: open(%s), %s\n", __func__, file,
		   strerror(errno));
   return -1;
  }
  size_t size = write(fd, buf, buf_size);
//  fprintf(stderr, "[%s] wrote: %ld\n", __func__, size);
  close(fd);
  return size;
}

void suprHomeInit();

char *Config_getAddr(char *name){
  if(!Supr_usrHome) suprHomeInit(); 

  char *addr = NULL;

  char cn_file[PATH_MAX];

      sprintf(cn_file, "%s/supr.conf", Supr_usrHome);
      int rc = access(cn_file, R_OK);
      int fd = open(cn_file, O_RDWR, 0600);
      struct stat sb;
      if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {
        char buf[sb.st_size+1];
        read(fd, buf, sb.st_size);
        close(fd);

        buf[sb.st_size] = 0;    
        char *line = strtok(buf, "\n");
        char *namenode_line = NULL;
        while(line){
          if(*line != '#' && strstr(line, name))
          {
            namenode_line = line;
	    char *s = strstr(line, "\n");
	    if(s) *s = 0;
	    addr = malloc(strlen(line)+1);
	    memcpy(addr, line, strlen(line)+1);
            break;
          }
          line = strtok(NULL, "\n");
        }

	
        //fprintf(stdout, "%s: %s\n", name, namenode_line);
	/*
        if(namenode_line){
          line = strstr(namenode_line, "//");
          if(line) line = strstr(line+2, ":");
          if(line) line += 1;
          if(line) port = atoi(line);
        }
	*/
        //fprintf(stdout, "%s: //*:%d\n", name, port);

      } else {
        fprintf(stdout, "Error: supr.conf, %s\n", strerror(errno));
      }
  return addr;
}

int Config_getPort(const char *name)
{
  if(!SUPR_HOMEUSR) suprHomeInit(); 

  int port = 0;

  char cn_file[PATH_MAX];

      sprintf(cn_file, "%s/supr.conf", SUPR_HOMEUSR);
      int rc = access(cn_file, R_OK);
      int fd = open(cn_file, O_RDWR, 0600);
      struct stat sb;
      if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {
        char buf[sb.st_size+1];
        read(fd, buf, sb.st_size);
        close(fd);

        buf[sb.st_size] = 0;    
        char *line = strtok(buf, "\n");
        char *namenode_line = NULL;
        while(line){
          if(*line != '#' && strstr(line, name))
          {
            namenode_line = line;
            break;
          }
          line = strtok(NULL, "\n");
        }

        //fprintf(stdout, "%s: %s\n", name, namenode_line);
        if(namenode_line){
          line = strstr(namenode_line, "//");
          if(line) line = strstr(line+2, ":");
          if(line) line += 1;
          if(line) port = atoi(line);
        }
        //fprintf(stdout, "%s: //*:%d\n", name, port);

      } else {
        fprintf(stdout, "Error: supr.conf, %s\n", strerror(errno));
      }
  return port;
}


static pthread_mutex_t __thread_mutex = PTHREAD_MUTEX_INITIALIZER;

int __supr_R_Busy(int busy)
{
  return R_SetSyncEvalLock(busy);
}

// busy: FALSE - unlock, TRUE - lock
int R_SetSyncEvalLock(int busy)
{
  if(main_thread){
    supr_thread_t *cth = currentThread();

    //printf("\033[0;35mthread: %s, busy: %d => to %s\033[0m\n", cth->name, busy, busy?"LOCK":"UNLOCK");

    int rc;

    if(busy) {
      rc = pthread_mutex_lock(&__thread_mutex);
      if(rc != 0) {
        __FIXME__(__func__);
	sleep(120);
	exit(1);
      }

      R_CStackStart   = cth->R_CStackStart;
      R_GlobalContext = cth->R_GlobalContext;

      //printf("LOCKED, rc: %d\n", rc);
      //print_callerInfo(5);

    } else if(__thread_mutex.__data.__owner == cth->tid) { 
      
      cth->R_GlobalContext = R_GlobalContext;

      rc = pthread_mutex_unlock(&__thread_mutex);
      if(rc != 0) {
        __FIXME__(__func__);
	sleep(120);
	exit(1);
      }

    } else {
      if(Supr_state != SUPR_QUITTING)
      {
        //printf("illegal call: pthread_mutex_unlock (%s:%d), Thread_CleanUp?\n\n", __FILE__, __LINE__);
      }
    }
  }

  return 0;
//  return R_PPStackTop;
}

#include <execinfo.h>

/*
void print_callerInfo(int BT_SIZE) 
{
  void    *array[BT_SIZE];
  int   size, i;
  char   **strings;
  size = backtrace(array, BT_SIZE);
  strings = backtrace_symbols(array, size);
  for (i = 1; i < size; i++) {
    fprintf(stdout, "\t%2d. %s\n", i, strings[i]);
  }
}
*/

static struct sigaction R_oldIntAct;
// for the main thread
static void Console_read_handleInteruption(pthread_mutex_t *mutex, int action);

static void Console_read_SigactionINT(int sig, siginfo_t *ip, void *context)
{
  printf("\033[0;33m[%s] pid: %d, tid:%ld\033[0m\n",
                  __func__, getpid(), syscall(SYS_gettid));

  if(currentThread()->data == PTHREAD_ERROR) {
    sigaction(SIGINT, &R_oldIntAct, NULL);
    Thread_SigactionSIGUSR2(sig, ip, context);
  }

#define BACKTRACE_SIZE 256
  void *array[BACKTRACE_SIZE];
  int  size = backtrace(array, BACKTRACE_SIZE);
#undef BACKTRACE_SIZE
  char **strings = backtrace_symbols(array, size);
  for(int i=0; i<size; i++){
    char *str = strings[i];
    if(strstr(str, "select") || strstr(str, "Busy") || 
       strstr(str, "ReplIteration"))
	    printf("\033[0;33m%2d : %s\033[0m\n", i, str);
  }
  free(strings);

  Console_read_handleInteruption(&__thread_mutex, 0); // testing the func

  if(!currentThread()->data)
    currentThread()->data = PTHREAD_INTERRUPTED;
}

static void Console_read_handleInteruption(pthread_mutex_t *mutex, int action)
{
  int owner_tid = mutex->__data.__owner;
  printf("\n[%s] mutex->owner's tid: %d\n", __func__, owner_tid);
  supr_thread_t *owner = NULL;
  int rc = pthread_mutex_trylock(threads->mutex); // FIXME
  for(int i = 0; i < vectorSize(threads); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
    // lock ... or call Thread_getState ...
    if(!th) continue; // FIXME
    if(action==0){
      printf("\tthread: %s, state: %d\n", th->name, th->state);
    }
    if(th->tid == owner_tid){
      owner = th;
      if(action != 0) break;
    }
  }
  pthread_mutex_unlock(threads->mutex);

  if(action == 0) return;

  // to do ...
}

//#include <termios.h>
//#include <unistd.h>

// R-version/src/main/main.c and Defn.h

/* PARSE_NULL will not be returned by R_ParseVector */
// R_ext/Parse.h
/*
typedef enum {
    PARSE_NULL,
    PARSE_OK,
    PARSE_INCOMPLETE,
    PARSE_ERROR,
    PARSE_EOF
} ParseStatus;
*/


static int (*__ReplIteration)(SEXP, int, int, R_ReplState *) = NULL;

/*
static void R_ReplConsole(SEXP rho, int savestack, int browselevel)
{
    int status;
    R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};

    R_IoBufferWriteReset(&R_ConsoleIob);
    state.buf[0] = '\0';
    state.buf[CONSOLE_BUFFER_SIZE] = '\0';
    // stopgap measure if line > CONSOLE_BUFFER_SIZE chars 
    state.bufp = state.buf;
    if(R_Verbose)
        REprintf(" >R_ReplConsole(): before \"for(;;)\" {main.c}\n");
    for(;;) {
        status = Rf_ReplIteration(rho, savestack, browselevel, &state);
        if(status < 0) {
          if (state.status == PARSE_INCOMPLETE)
            error(_("unexpected end of input"));
          return;
        }
    }
}
*/


static  R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};


/*
void __old_MY_ReplConsole(SEXP rho, int savestack, int browselevel)
{

  int status;
  //R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};
  state.status = PARSE_NULL;
  state.prompt_type = 1;
  state.browselevel = 0;
  state.buf[0] = 0;
  state.bufp = NULL;


  //  R_IoBufferWriteReset(&R_ConsoleIob);
  state.buf[0] = '\0';
  state.buf[CONSOLE_BUFFER_SIZE] = '\0';
    // stopgap measure if line > CONSOLE_BUFFER_SIZE chars
  state.bufp = state.buf;
  //if(R_Verbose) REprintf(" >R_ReplConsole(): before \"for(;;)\" {main.c}\n");
 
  for(;;) {

        status = Rf_ReplIteration(rho, savestack, browselevel, &state);
	printf("\033[0;31m[%s] status: %d ...\033[0m\n", __func__, status);
	printf("\033[0;34mSuccess\033[0m\n\n");

        if(status < 0) {
          if (state.status == PARSE_INCOMPLETE)
            error(_("unexpected end of input"));
          return;
        }
  }
}
*/

void Thread_setInterruptable();

// Info_backend_run
void *Thread_handleInputEvents(void *arg)
{
  if(!sys_threads){ // FIXME
    error(_("sys_threads is not initialized, FIXME (%s:%d)\n"),
			  __FILE__, __LINE__);
  }

  sigset_t sig_set;
  sigemptyset(&sig_set);
  sigaddset(&sig_set, SIGINT);
  int rc = pthread_sigmask(SIG_BLOCK, &sig_set, NULL);
  if(rc)
    fprintf(stderr, "[WARNING] pthread_sigmask(SIG_BLOCK, &{SIGINT}, NULL): %d\n", rc);

  sem_t *sem = (sem_t *) ((void **)arg)[0];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[1];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
          syscall(SYS_gettid), THREAD_STATE_NEW, (unsigned long) &sem);
  *sth = th;

  free(th->name);
  th->name = strdup("InputHandler");

  pthread_mutex_lock(sys_threads->mutex);
    vectorAdd(sys_threads, th);
  pthread_mutex_unlock(sys_threads->mutex);

  pthread_setspecific(currentThreadKey, th);
  th->state = THREAD_STATE_RUNNABLE;

  for(RCNTXT *cptr = R_GlobalContext; cptr; cptr = cptr->nextcontext)
            if(!cptr->nextcontext){ // cptr: ToplevelContext
               th->R_GlobalContext = cptr;
               break;
            }
  sem_post(sem);

  Thread_setInterruptable();

  InputHandler *handler;
  struct timespec wait;
  clock_gettime(CLOCK_REALTIME, &wait);
  //wait.tv_sec += (long) timeout;
  unsigned long start_time = wait.tv_sec;
  int count =0 ;

  for(;;) {
    // Info_backend_run_select
    handler = __InputHandlers_selectInputHandler(1000);
    if(handler){

      if(handler->userData){ //printf("[%s] handle ...\n", __func__);
     
        handler->handler(handler->userData);
      
      } else {
        //if(Supr_verbose)
          fprintf(stderr, "\033[0;33mWarning in %s@%s:%d, handler: %p, handler->userData: %p\033[0m\n",
		  __func__, __FILE__, __LINE__, handler, handler->userData);
      }

    } else {
      InputHandler *h = Supr_R_InputHandlers->next;
      int len = 0;
      while(h) { len++; h=h->next;}
      clock_gettime(CLOCK_REALTIME, &wait);
      if(wait.tv_sec - start_time < 1000 && count>=10 && len>0){
        fprintf(stderr, "Warning in %s@%s:%d. sleep(len=%d)\n",
		       	__func__, __FILE__, __LINE__, len);
        sleep(len);
	count = 0;
      }

      count++;
      start_time = wait.tv_sec;
    }
  }

}

void Thread_startEventHandler()
{
  //if(Supr_options.info)
  basic_info(__func__);

  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&sem, &eventHandlerThread};

  int rc = pthread_create(&thread, NULL, Thread_handleInputEvents, arg);

  sem_wait(&sem);
  sem_destroy(&sem);
  //printf("Started %s\n", __func__);
}


//static int Thread_cb_linehandler_running = 1;
//static char *Thread_cb_linehandler_line = NULL;

typedef struct thread_readline_struct {
  void (*cb_linehandler) (char *line);
  const char *prompt;
  char *line;
  struct sigaction *sigint_action;
  struct sigaction *old_sigint_action;
  struct sigaction *sigwinch_action;
  struct sigaction *old_sigwinch_action;
  struct sigaction *sigusr2_action;
  struct sigaction *old_sigusr2_action;
  //JMP_BUF sigint_jmpbuf;
  int running;
  int sig; // signum ? ...
  siginfo_t *info;
  void *ucontext;
} thread_rl_t;

static void Thread_cb_linehandler (char *line);

static thread_rl_t __thread_rl = {Thread_cb_linehandler, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL};

int Supr_getSignal()
{
  return __thread_rl.sig;
}
int Supr_setSignal(int sig)
{
  int ret = __thread_rl.sig;
  __thread_rl.sig = sig;
  return ret;
}

static void Thread_cb_linehandler (char *line)
{
  //printf("[%s] input line: \"%s\"\n", __func__, line);
  __thread_rl.line = line;
  //if(line)
  //if(line &&strlen(line))
  {
    __thread_rl.running = 0;
    rl_already_prompted = 1;
  }
  /*
  else fprintf(rl_outstream, "%s", __thread_rl.prompt);
  fflush(rl_outstream);
  rl_already_prompted = 1;
  */
}


/*
void __funmap() {
  const char **names = rl_funmap_names();
  for(int i=0; names[i]; i++){
    printf("funmap: %s\n", names[i]);
  }
  free(names);

  printf("funmap: \n");
  rl_function_dumper(1);
}
*/

/*
char *simple_readline(const char *prompt)
{
  static unsigned char *buf = NULL;
  static size_t buf_size = 0;
  static FILE *tmp_file = NULL;
  if(!buf) {
    buf_size = 1024;
    buf = (unsigned char *)malloc(buf_size+1);

    char path[PATH_MAX];
    char *home = getenv("HOME");
    sprintf(path, "%s/tmp/check.out", home);
    tmp_file = fopen(path, "w");
    fprintf(tmp_file, "pid: %d\n", getpid());
    fprintf(stderr, "pid: %d\n", getpid());
    off_t offset;
    offset=lseek(fileno(stdin), 0, SEEK_CUR);
    fprintf(tmp_file, "offset: %ld\n", offset);
    fprintf(stderr, "offset: %ld\n", offset);
    off_t len;
    len = lseek(fileno(stdin), 0, SEEK_END);
    fprintf(tmp_file, "len: %ld\n", len);
    fprintf(stderr, "len: %ld\n", len);
	    fflush(tmp_file);
    lseek(fileno(stdin), offset, SEEK_SET);
	    fflush(stderr);
    if(len == offset)
    {
       fprintf(tmp_file, "offset == len\n");
       fprintf(stderr, "offset == len\n");
	    fflush(tmp_file);
	    fflush(stderr);
	    return NULL;
    } else {
       fprintf(tmp_file, "offset != len\n");
       fprintf(stderr, "offset != len\n");
	    fflush(tmp_file);
	    fflush(stderr);
    }
  }
  size_t len = 0;
  int c;
  for(; (c = getchar()) != -1; ){
	  //if(c==0){
    fprintf(tmp_file, "Read: %d\n", c);
	    fflush(tmp_file);
	 // }
    if(len >= buf_size){
      unsigned char *tmp = buf;
      size_t size = buf_size + buf_size/2;
      buf = (unsigned char *)malloc(size+1);
      memcpy(buf, tmp, len);
      buf_size = size;
      free(tmp);
    }

    buf[len++] = c;

    if(tmp_file) {
	    fputc(c, tmp_file);
	    fflush(tmp_file);
    }

    if(c=='\n' || c == 0){
      buf[len++] = 0;
      char *line = (char *)malloc(len);
      memcpy(line, buf, len);
      return line;
    }
  }

  if(len==0) {
    //fclose(tmp_file);
    return NULL;
  } else {
      buf[len++] = 0;
      char *line = (char *)malloc(len);
      memcpy(line, buf, len);
      return line;
  }
}
*/

char *Thread_readline(const char *prompt)
{



	/*
  if(!Supr_isatty){
    return simple_readline(prompt);
  }
  */


//	__funmap();

  static int do_init = TRUE;
  if( TRUE ){
    if(__thread_rl.sigwinch_action)
      sigaction(SIGWINCH, __thread_rl.sigwinch_action,
		     __thread_rl.old_sigwinch_action);
  
    if(__thread_rl.sigint_action)
      sigaction(SIGINT, __thread_rl.sigint_action, 
		     __thread_rl.old_sigint_action);
  
    if(__thread_rl.sigusr2_action) {
//  printf("[%s] sigaction( ...__thread_rl.sigusr2_action...)\n", __func__);
      sigaction(SIGUSR2, __thread_rl.sigusr2_action, 
		     __thread_rl.old_sigusr2_action);
      sigset_t sig_set;
      sigemptyset(&sig_set);
      sigaddset(&sig_set, SIGUSR2);
      pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
      // does rl block SIGUSR2???
    }

  }

  __thread_rl.prompt = prompt;

  static char *_prompt = "";
  //if( do_init )
  if(prompt && strcmp(prompt, _prompt))
  {
    rl_callback_handler_install (prompt, __thread_rl.cb_linehandler);

    //fprintf(rl_outstream, "%s", prompt);
    //fprintf(rl_outstream, "[%d:]", __LINE__);
    fflush(rl_outstream);

    //rl_already_prompted = 1;
    // prompt can be different ...
    // do_init = FALSE;
  }
  //rl_callback_handler_install ("", __thread_rl.cb_linehandler);
  
  __thread_rl.running = 1;
  __thread_rl.sig     = 0;

//  rl_callback_handler_install (prompt, __thread_rl.cb_linehandler);

  /*
  JMP_BUF thisbuf;
  if(!SETJMP(thisbuf))
      printf("[%s] SETJMP(thisbuf): 0 (%s:%d)\n", __func__, __FILE__, __LINE__);
      */

  {
    //rl_erase_empty_line = 1;
    //printf("[%s] rl-version: %o\n", __func__, rl_readline_version);
    //printf("%s", prompt);
    //fflush(stdout);
    //rl_already_prompted = 1;
    //rl_startup_hook = 
  }
  //printf("\033[0;32m[[%s >>>]] \033[0m", __func__); fflush(stdout);

  while (__thread_rl.running)
  {
      fd_set fds;
      int r;

      FD_ZERO (&fds);
      FD_SET (fileno (rl_instream), &fds);

      r = select (FD_SETSIZE, &fds, NULL, NULL, NULL);
      if (r < 0 && errno != EINTR)
        {
          perror ("rltest: select");
          rl_callback_handler_remove ();
          break;
        }
      //if (sigwinch_received)
      if (__thread_rl.sig) {
        if (__thread_rl.sig == SIGWINCH) {
//	  printf("[%s] sigwinch_received\n", __func__);
	  //if(window_resized())
	  //rl_resize_terminal ();
//	  sigwinch_received = 0;
	  if(info_setDisplayed(FALSE))
	    rl_redisplay();
	  
	} else if (__thread_rl.sig == SIGINT){
//	  fprintf(stderr, "[%s] SIGINT rc: %d, errno: %d (==%d), error: %s\n", __func__, r, errno, EINTR, strerror(errno));

	 
	  rl_done = 1;
          fprintf(rl_outstream, "\n");
          //rl_callback_read_char (); 
        //readline (prompt); // ???

          rl_free_line_state();
          rl_cleanup_after_signal();
          rl_reset_after_signal();

	  break;
	} else if (__thread_rl.sig == SIGUSR2){
	  fprintf(stderr, "[%s] SIGUSR2 rc: %d, errno: %d (==%d), error: %s\n",
			  __func__, r, errno, EINTR, strerror(errno));

	  rl_done = 1;
          fprintf(rl_outstream, "\n");
          //rl_callback_read_char (); 
          rl_free_line_state();
          rl_cleanup_after_signal();
          rl_reset_after_signal();
	  break;
        }
      }
      /*
      else if (sigint_received)
	{
	  printf("[%s] sigint_received\n", __func__);
	  sigint_received = 0;
	  //LONGJMP(thisbuf, 0);
	  LONGJMP(thisbuf, 1);
	}
	*/

      if (r < 0)
	continue;

      if (FD_ISSET (fileno (rl_instream), &fds))
        rl_callback_read_char ();
      // rl_line_buffer; see 2.3 readline variables
  }
  rl_already_prompted = 0;
  
 if (__thread_rl.sig) {
    fprintf(stderr, "%s:%d. __thread_rl.sig OKAY// DELETE ...\n", __FILE__, __LINE__);
 }

  //rl_callback_sigcleanup ();
  {
    //rl_free_line_state();
    //rl_cleanup_after_signal();
  }

  int sig = rl_pending_signal();
  if(sig) fprintf(stderr, "[%s] rl_pending_signal(): %d\n", __func__, sig);
  // char *line = readline(prompt);

  //rl_clear_signals();
  //rl_catch_signals = 0;
  //int rc = rl_set_signals ();

  return __thread_rl.line;
}

//char *(*ptr_readline)(const char *prompt) = readline;

//static JMP_BUF Console_read_jmpbuf;

void Thread_SigactionSIGUSR2_rl(int sig, siginfo_t *ip, void *cntxt)
{
  supr_thread_t *cth = currentThread();
  char buf[254];
  printf("\033[0;31m%s: IS CALLED, data: %s\033[0m\n", __func__,
		  ptrToString(cth->data, buf, 256));
  c_backtrace();

  __thread_rl.sig = sig;
  __thread_rl.info = ip;
  __thread_rl.ucontext = cntxt;
}

void Console_read_SigactionINT_new(int sig, siginfo_t *ip, void *cntxt)
{
  supr_thread_t *cth = currentThread();

  //fprintf(stderr, "\033[0;31m%s: IS CALLED\n", __func__);
  char buf[256];
  //fprintf(stderr,"\033[0;31m%s: cth->data: %s, %p\033[0m\n", __func__, ptrToString(cth->data, buf, 256), PTHREAD_ERROR);

  //printf("\033[0;31m%s: CALL rl_cleanup_after_signal()\033[0m\n", __func__);

  __thread_rl.sig = sig;
  __thread_rl.info = ip;
  __thread_rl.ucontext = cntxt;

  {
    struct sigaction oldUsr2Act;

    struct sigaction sa;
    sa.sa_sigaction = Console_read_SigactionINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, &oldUsr2Act);

    /*
    printf("[%s] oldUsr2Act.sa_flags & SA_SIGINFO: %d\n", __func__,
		    oldUsr2Act.sa_flags & SA_SIGINFO);
    printf("[%s] oldUsr2Act.sa_sigaction: %p (%p)\n", __func__,
		    oldUsr2Act.sa_sigaction, Thread_SigactionSIGUSR2);
    printf("[%s] oldUsr2Act.sa_handler:   %p (%p)\n", __func__,
		    oldUsr2Act.sa_handler, Thread_SigactionSIGUSR2);

    printf("[%s] oldUsr2Act.sa_flags: %d\n", __func__,
		    oldUsr2Act.sa_flags);
    printf("[%s] oldUsr2Act.sa_mask (blocked): \n", __func__);
    */
    // check pthread_sigmask and sigprocmask???
    // sigpending
    sigset_t sig_set;
    sigemptyset(&sig_set);
    int rc = sigpending(&sig_set);
    if(rc != 0)
      fprintf(stderr, "[%s] Error (rc: %d): sigpending, %s\n",  __func__,
		     rc,  strerror(errno));
    /*
    printf("[%s] sigpending: \n", __func__);
    //sigsetops
    printf("[%s] sigismember(&sig_set, SIGUSR2): %d\n", __func__,
		    sigismember(&sig_set, SIGUSR2));
    printf("[%s] sigismember(&sig_set, SIGINT): %d\n", __func__,
		    sigismember(&sig_set, SIGINT));
		    */

    if(sigismember(&sig_set, SIGUSR2)){

      for(;;){
        rc = sigwait(&sig_set, &sig);
        if(rc != 0)
	       	printf("[%s] Error: sigwait(&sig_set, &sig), %s\n", __func__,
		      strerror(errno));
        //printf("[%s] sigwait(&sig_set, &sig): sig: %d\n", __func__, sig);
	if(sig == SIGUSR2) {
          //printf("[%s] Signal handling thread got signal, %d (SIGUSR2)\n", __func__, sig);
	  __thread_rl.sig = SIGUSR2;
	  break;
	}
      }
    }


    sigaction(SIGUSR2, &oldUsr2Act, NULL);

  }



  //    sigaction(SIGINT, __thread_rl.old_sigint_action, __thread_rl.sigint_action );
 // LONGJMP(Console_read_jmpbuf, 1);

  
  //if(cth->data == PTHREAD_ERROR) Thread_SigactionSIGUSR2(sig, ip, cntxt);
  //sigaction(SIGINT, __thread_rl.old_sigint_action, NULL);
}

void Thread_SigactionSIGWINCH(int sig, siginfo_t *ip, void *cntxt)
{
  int rows, cols;
  static int save_rows=0, save_cols=0;
  rl_get_screen_size(&rows, &cols);
  if(rows != save_rows || cols != save_cols){
    if(save_rows)
      fprintf(stderr, "[window size: %d x %d]\n", rows, cols);
    save_rows = rows;
    save_cols = cols;
    rl_resize_terminal();
  }
}

// stop?
SEXP Thread_startInputHandler()
{
  Thread_startEventHandler();
  return R_NilValue;
}


/*
#include <R_ext/RStartup.h>
extern void R_CleanUp(SA_TYPE saveact, int status, int runLast);
extern int R_Slave;
*/

// testing
#define CONSOLE_LINEREAD_EOF NULL

/*
SEXP Supr_checkJMP(const char *msg)
{
//    memcpy(__cjmpbuf, __R_ToplevelContext->cjmpbuf, sizeof(jmp_buf));
  RCNTXT *__R_ToplevelContext = R_GlobalContext;
  while(__R_ToplevelContext->nextcontext)
	  __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  printf("R_ToplevelContext->cjmpbuf: %ld\n", __R_ToplevelContext->cjmpbuf);
  printf("R_ToplevelContext->cjmpbuf: %p\n", &__R_ToplevelContext->cjmpbuf);

  fprintf(stdout, "Caller msg: %s\n", msg);
  unsigned char *byte = (unsigned char*) &__R_ToplevelContext->cjmpbuf;
  for(int i=0; i < sizeof(jmp_buf); i++){
    fprintf(stdout, " %d", byte[i]);
  }
  fprintf(stdout, "\n");

  return R_NilValue;
}
*/

/*
static char *Supr_quit()
{
  SEXP call, val;

  call  = PROTECT(LCONS(install("detach"), CONS(mkString("package:supr2"), 
		    CONS(R_TrueValue, R_NilValue))));
  SET_TAG(CDDR(call), install("unload"));
  val = eval(call, R_BaseEnv);
  UNPROTECT(1);

  int unload_namespace = FALSE;
  call  = PROTECT(LCONS(install("isNamespaceLoaded"),
			  CONS(mkString("supr2"), R_NilValue)));
  val = eval(call, R_BaseEnv);
  unload_namespace = asLogical(val);
  UNPROTECT(1);

  if(unload_namespace){
    call  = PROTECT(LCONS(install("unloadNamespace"),
			  CONS(mkString("supr2"), R_NilValue)));
    val = eval(call, R_BaseEnv);
    UNPROTECT(1);
  }


  if(R_Interactive){

    char buf[strlen(Supr_sysHome)+256];
    sprintf(buf, "library.dynam.unload(\"libsupr\", \"%s\")\n", Supr_sysHome);
    char *ret = (char*) malloc(strlen(buf)+1);
    memcpy(ret, buf, strlen(buf)+1);

    R_thread_fini();

    return ret;
  }
  
  return NULL;
}
*/

int my_ReplConsole(SEXP rho, int savestack, int browselevel)
{
  int status = -1;
  R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};
  state.buf[0] = '\0';
  state.buf[CONSOLE_BUFFER_SIZE] = '\0';
  state.bufp = state.buf;

  char *prompt[] = {">> ", "+  "};
  char prompt_buf[256];
  /*
  {
    sprintf(prompt_buf, "%s", prompt[0]);

#define BACKTRACE_SIZE 32
    void *array[BACKTRACE_SIZE];
    int  size = backtrace(array, BACKTRACE_SIZE);
    char **strings = backtrace_symbols(array, size);
    for(int i=0; i<size; i++){
      char *str = strings[i];
      if(strstr(str, "(+")) continue;
      str = strtok(str, "(");
      str = strtok(NULL, "+");
      char buf[256];
      snprintf(buf, 256, "%s/%s", str, prompt_buf);
      memcpy(prompt_buf, buf, strlen(buf)+1);
    }
    free(strings);
    prompt[0] = prompt_buf;
#undef BACKTRACE_SIZE
  }
  */

  /*
  printf("[%s] Reset sigaction(SIGUSR2, &sa, NULL);\n", __func__);
  {
    struct sigaction sa;
    sa.sa_sigaction = Thread_SigactionSIGUSR2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);
  }
  */
  static int do_init = TRUE;

  if(Supr_verbose)
    fprintf(stderr, "[%s] Start REPL ...\n", __func__);

  for(;;) {

      
	  /*
    for(int i=0; i< R_PPStackTop; i++){
    printf(" \033[0;32mR_PPStack[%d]:\033[0m\n", i);
	    PrintValue(R_PPStack[i]);
    }
    */

    R_PPStackTop = savestack;

    /*
    printf(" \033[0;32mexpr before save: %s\033[0m\n", state.buf);
    printf(" R_PPStackTop: %d\n", R_PPStackTop);
    printf(" currentThread()->R_PPStackTop: %d\n",
		    currentThread()->save_R_PPStackTop);
		    */
    supr_thread_t *cth = (supr_thread_t *) currentThread();
    if(!cth) {
      printf("currentThread(): %p\n", cth);
      return -1;
    }


    //printf("OKAY 1\n");
    BEGIN_R_FREE();

    //printf("OKAY 1.2\n");
    /*
       {
	    int jb_rc;
            if(! (jb_rc=SETJMP(Console_read_jmpbuf)))
	      printf("[%s] BEGIN_R_FREE START, SETJMP rc: %d, Whoops\n",
			      __func__, jb_rc);

            printf("[%s] BEGIN_R_FREE START, SETJMP rc: %d, Contine\n", __func__, jb_rc);
       }
       */

       if(do_init){

      //if(is_tty) {

        struct sigaction sa;
        sa.sa_sigaction = Console_read_SigactionINT_new;
        sigemptyset(&sa.sa_mask);
        sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
        //sigaction(SIGINT, &sa, &R_oldIntAct);
        __thread_rl.sigint_action = &sa;
        __thread_rl.old_sigint_action = &R_oldIntAct;
      //} else { __thread_rl.sigint_action = NULL; }

      //{
        struct sigaction usr2_sa;
        usr2_sa.sa_sigaction = Thread_SigactionSIGUSR2_rl;
        sigemptyset(&usr2_sa.sa_mask);
        usr2_sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
        __thread_rl.sigusr2_action = &usr2_sa;
        __thread_rl.old_sigusr2_action = &__R_oldUsr2Act;
      //}

      //if(is_tty) {
        struct sigaction winch_sa;
        winch_sa.sa_sigaction = Thread_SigactionSIGWINCH;
        sigemptyset(&winch_sa.sa_mask);
        winch_sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
        __thread_rl.sigwinch_action = &winch_sa;
        __thread_rl.old_sigwinch_action = &R_oldWinchAct;
      //} else { __thread_rl.sigwinch_action = NULL; }

	do_init = FALSE;
       }
__thread_rl.sig = 0;

    //  supr_thread_t *
      cth = (supr_thread_t *) currentThread();
      cth->data = NULL;



      if(R_Interactive){

	if(!*state.bufp){ // __R_ReadConsole
	  for(;;){

            char *line = ptr_readline(prompt[state.prompt_type-1]);

	    if(!line) {
	      if( line == CONSOLE_LINEREAD_EOF ) {
		    /*
		    {
		      printf("line: \"%s\" line=NULL\n", line);
		      off_t cur = lseek(fileno(stdin), 0, SEEK_CUR);
		      off_t end = lseek(fileno(stdin), 0, SEEK_END);
		      printf("cur: %ld, end: %ld\n", cur, end);
		      lseek(fileno(stdin), cur, SEEK_SET);
		      fflush(stdout);
		    }
		    */
  	        do_init = FALSE; // FIXME and do more ...
		int quit = TRUE;
		if(R_Interactive){//printf("Quit SupR ...\n"); //Supr_quit(); 
		//	continue;
                  while (TRUE) {
		    char *buf = ptr_readline("quit SupR? [y/n] ");
		    if(buf){
		      if(*buf != 'y') 
		        quit = FALSE;
		      break;
		    }
		  }
		}
		if(quit) {
		  rl_set_prompt("[INFO] Supr_quit ...");
		  Supr_state = SUPR_QUITTING;
                  do_init = TRUE;
	          return -1;
		}
		else 
		  continue;
	      }
//		    R_CleanUp(SA_NOSAVE, 1, 0); // quit, no save, no .Last, status=1 
		    //R_CleanUp(SA_NOSAVE, -1, 0); // quit, no save, no .Last, status=1 
		    //R_CleanUp(SA_NOSAVE, -1, 0); // quit, no save, no .Last, status=1 
		    // static void end_Rmainloop(void) in R/main.c
		       /* refrain from printing trailing '\n' in slave mode */
		    
		    /*
    if (!R_Slave)
        Rprintf("\n");
    // run the .Last function. If it gives an error, will drop back to main loop.
    R_CleanUp(SA_DEFAULT, 0, 1);
		    */
		    continue;
	    } else if(strlen(line)==0) {
//		    printf("line: \"%s\" strlen(line)==0\n", line);
		    continue;
	    }

	    if(__thread_rl.sig){
              //printf("\t[%s] __thread_rl.sig: %d\n", __func__, __thread_rl.sig);
	      //if(__thread_rl.sig == SIGINT) LONGJMP(Console_read_jmpbuf,1);

	      if(__thread_rl.sig == SIGUSR2)
	        Thread_SigactionSIGUSR2(__thread_rl.sig, __thread_rl.info,
			       	__thread_rl.ucontext); // NORET
	      else if(__thread_rl.sig == SIGINT && cth->data == PTHREAD_ERROR)
	        Thread_SigactionSIGUSR2(__thread_rl.sig, __thread_rl.info,
			       	__thread_rl.ucontext); // NORET
	      else printf("\t[%s] ignored ... TODO (%s:%d)\n", __func__,
			__FILE__, __LINE__);

	      continue;
	    }


	    if(line && strlen(line)>0){
	      int len = strlen(line);
	      memcpy(state.buf, line, strlen(line)+1);
	      //memcpy(state.bufp, line, strlen(line));
	      len = strlen(state.buf);
	      state.buf[len++] = '\n';
	      state.buf[len++] = 0;
  	      state.bufp = state.buf;
	      //printf("\t[%s] state.bufp: %s\n", __func__, state.bufp);

            //if(status>0)
	    {
	      if(line[strlen(line)-1] == '\n')
	        line[strlen(line)-1] = 0;
	      add_history(line);
            }
	      free(line);
	      break;
	    } else
		    free(line);
	  }
	}
	

      //{
      //  sigaction(SIGINT, &R_oldIntAct, NULL);
      //}
      sigaction(SIGINT, __thread_rl.old_sigint_action, NULL);
      sigaction(SIGWINCH, __thread_rl.old_sigwinch_action, NULL);
      sigaction(SIGUSR2, __thread_rl.old_sigusr2_action, NULL);

      } else {
        //int rc = R_ReadConsole(">>>> ", state.buf, CONSOLE_BUFFER_SIZE, 0);
        int rc = R_ReadConsole(prompt[state.prompt_type-1], state.buf,
		       	CONSOLE_BUFFER_SIZE, 0);
	if(rc == 0) return -1;
        state.bufp = state.buf;
      }

    END_R_FREE();

    R_CheckUserInterrupt();

    //if(Supr_verbose) fprintf(stderr, " \033[0;32m__CurrentExpr: %s\033[0m\n", state.buf);

    /*
    { // checking
      SEXP save_stack = findVar(install(".save.stack."),
		      EXTPTR_PROT(currentThread()->R_thread));
      int n = LENGTH(save_stack);
      for(int i=0; i<n; i++){
        SEXP e = VECTOR_ELT(save_stack, i);
        printf("2%d: %s\n", i, e ? type2char(TYPEOF(e)): "ERROR, e = (null)");
      }
    }
    */

    //FIXME-FIXME
    status = Rf_ReplIteration(rho, savestack, browselevel, &state);

  //  printf("\033[0;31m[%s] status: %d, prompty: %d\033[0m\n", __func__, status, state.prompt_type);

    if(status < 0) {
          if (state.status == PARSE_INCOMPLETE)
	  {
           // error(_("unexpected end of input"));
		  if(Supr_verbose) printf("? unexpected end of input\n");
		  
	  }
          return 0; // ???
    }
  }
  

  /*
	R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};
	//pthread_mutex_unlock(&cth->mutex);
	if(!setjmp(__R_ToplevelContext->cjmpbuf)) {
	  int savestack = 0;
	  int browselevel=0;
          __ReplIteration(R_GlobalEnv, savestack, browselevel, &state);
	  printf("\033[0;34mSuccess\033[0m\n");
	} else {
	  printf("\033[0;34mFailuer\033[0m\n");
	}
	*/
  return 0; // ???
}

void  __check_session_exit()
{
  printf("[%s] never called?\n", __func__);
}

void tmp_CheckStack(void *data)
{
	// lock R_Globals?
	// Check R_interrupts_suspended, doing GC
  supr_thread_t *cth = currentThread();
  if(cth->R_eval_state == 1) { // running R_eval
    //pthread_mutex_lock(&__thread_mutex);
	RCNTXT *save_cntxt = R_GlobalContext;
	unsigned long save_cstackstart = R_CStackStart;
	R_GlobalContext = currentThread()->R_GlobalContext;
	R_CStackStart = currentThread()->R_CStackStart;
	CheckStack();
	currentThread()->data = PTHREAD_CANCELED;

        memcpy(__R_ToplevelContext->cjmpbuf, cth->cjmpbuf, sizeof(jmp_buf));

	//pthread_mutex_lock(&cth->mutex);
	pthread_cond_signal(&cth->cond);

	error("PTHREAD_CANCELED");
	// no return ...
	R_GlobalContext = save_cntxt;
	R_CStackStart = save_cstackstart;
    //pthread_mutex_unlock(&__thread_mutex);
  } else if(cth->R_eval_state == 2) { // in R_FREE/R_EVAL_UNLOCK state
    printf("[%s] state: 2, LOCK\n", __func__);
    pthread_mutex_lock(&cth->mutex);
	pthread_cond_signal(&cth->cond);
        printf("[%s] state: 2, UNLOCK\n", __func__);
    pthread_mutex_unlock(&cth->mutex);
    pthread_exit(PTHREAD_CANCELED); // FIXME
  } else if(cth->R_eval_state == 0) {

    printf("\033[0;35m cth->mutex.__data.__owner: %d\033[0m\n",
	    cth->mutex.__data.__owner);

    if(cth->mutex.__data.__owner != cth->tid) {
      printf("state: 0, LOCK\n");
      pthread_mutex_lock(&cth->mutex);
    } else {
	    __FIXME__(__func__);
    }

	currentThread()->data = PTHREAD_CANCELED;

	pthread_cond_signal(&cth->cond);
        printf("state: 0, UNLOCK\n");
    pthread_mutex_unlock(&cth->mutex);
    // Cleanup?? TODO
    //pthread_exit(PTHREAD_CANCELED); // FIXME
    pthread_cancel(pthread_self()); // FIXME
  }

}

void Thread_main_reset()
{ // FIXME??
  int rc;
  supr_thread_t *cth = currentThread();

  rc = pthread_mutex_trylock(&__thread_mutex);
  rc = pthread_mutex_unlock(&__thread_mutex);
  rc = pthread_mutex_trylock(threads->mutex);
  rc = pthread_mutex_unlock(threads->mutex);
  rc = pthread_mutex_trylock(&cth->mutex);
  rc = pthread_mutex_unlock(&cth->mutex);

  // FIXME ??
  Supr_running = FALSE;
}

void Thread_main_run_cend(void *data)
{
  //printf("\033[0;36m[%s] is called by error functions?\033[0m\n", __func__);
//  CheckStack();
}

/*
// from R/src/main/errors.c
#define RESULT_SIZE 4

static SEXP mkHandlerEntry(SEXP klass, SEXP parentenv, SEXP handler, SEXP rho,
                           SEXP result, int calling)
{
    SEXP entry = allocVector(VECSXP, 5);
    SET_VECTOR_ELT(entry, 0, klass);
    SET_VECTOR_ELT(entry, 1, parentenv);
    SET_VECTOR_ELT(entry, 2, handler);
    SET_VECTOR_ELT(entry, 3, rho);
    SET_VECTOR_ELT(entry, 4, result);
    SETLEVELS(entry, calling);
    return entry;
}
*/

static int __R_interrupted;
SEXP __R_interrupt_handle()
{
  printf("[%s] is called. sleep(1) ... \n", __func__);
      __R_interrupted = TRUE;
	sleep(1);
  return R_NilValue;
}

/*
// An awkward approach, if not to modify R src
static void __R_ClearerrConsole()
{
  printf("[%s] is called\n", __func__);
 
#define BACKTRACE_SIZE 256
  void *array[BACKTRACE_SIZE];
  int  size = backtrace(array, BACKTRACE_SIZE);
  char **strings = backtrace_symbols(array, size);
  for(int i=0; i<size; i++){
    char *str = strings[i];
    if(strstr(str, "Rf_onintr")){
      __R_interrupted = TRUE;
      break;
    }
  }
  free(strings);
#undef BACKTRACE_SIZE


  sleep(10);
  __save_R_ClearerrConsole();
}
*/


extern InputHandler *R_InputHandlers;

/*
void  __InputHandlers_reset(){
  InputHandler *h = R_InputHandlers;
  int i=0;
  for(; h; h = h->next){
    printf("\033[0;33m[TODOD: %s] %2d: fileDescriptor: %d\033[0m\n",
		    __func__ , ++i, h->fileDescriptor);
  }
}
*/

// FIXME
// Info_backend_run_select
InputHandler *__InputHandlers_selectInputHandler(int timeout)
{

//	printf("[%s]\n", __func__);

  InputHandler *h;
 
  fd_set readfds;
  /*
  int max_fd = 0;

  FD_ZERO(&readfds);

  BEGIN_R_EVAL();
    h = R_InputHandlers;
    for(; h; h = h->next){
      if(h->fileDescriptor == 0) continue;
      FD_SET(h->fileDescriptor, &readfds);
      if(h->fileDescriptor > max_fd) max_fd = h->fileDescriptor;
      printf("[%s] h->fileDescriptor: %d\n", __func__, h->fileDescriptor);
    }
  END_R_EVAL();

  if(timeout == 0 ){ // for the main thread
    return max_fd ? h : NULL;
  }
  */
  while(TRUE){

    struct timeval tv;
    tv.tv_sec=timeout;
    tv.tv_usec=0;

    int max_fd = 0;
    FD_ZERO(&readfds);
#ifdef SUPR3
    h = Supr_R_InputHandlers;
    //h = Supr_R_InputHandlers->next;
#else
    BEGIN_R_EVAL();
      h = R_InputHandlers;
#endif
      for(; h; h = h->next){
        if(h->fileDescriptor == 0) continue;
        if(h->fileDescriptor == -1) {
          //fprintf(stderr, "Error in %s, fd: %d\n", __func__, h->fileDescriptor);
	  continue;
	}
        FD_SET(h->fileDescriptor, &readfds);
        if(h->fileDescriptor > max_fd) max_fd = h->fileDescriptor;
//        printf("[%s] h->fileDescriptor: %d\n", __func__, h->fileDescriptor);
      }
#ifdef SUPR3
#else
    END_R_EVAL();
#endif


    /*
    FD_ZERO(&readfds);
    int i=0;
    for(; h; h = h->next){
      if(h->fileDescriptor == 0) continue;
      FD_SET(h->fileDescriptor, &readfds);
      if(h->fileDescriptor > max_fd) max_fd = h->fileDescriptor;
    }
    */

    if(max_fd == 0) return NULL;

    int ns = select(max_fd + 1, &readfds, NULL, NULL, &tv);
    //int ns = select(FD_SETSIZE, &readfds, NULL, NULL, &tv);
    //printf("[%s] ns: %d\n", __func__, ns);
    if(ns == 0){
	  if(time) continue;
          return NULL;
    } else if(ns == -1){
      fprintf(stderr, "\n[%s] Error: select, (errno=%d) %s (%s:%d)\n", __func__,
		      errno, strerror(errno), __FILE__, __LINE__);
      {
        //h = Supr_R_InputHandlers;
        h=Supr_R_InputHandlers->next;//Supr_R_InputHandlers->fileDescriptor==-1
        InputHandler *t = Supr_R_InputHandlers;
        for(; h; t=h, h = h->next){
          if(h->fileDescriptor == 0) continue;
          //if(h->fileDescriptor == -1) continue;
          //FD_SET(h->fileDescriptor, &readfds);
          //if(h->fileDescriptor > max_fd) max_fd = h->fileDescriptor;
	  int msg;
	  ssize_t n = recv(h->fileDescriptor, &msg, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
          //fprintf(stderr, "\t\033[0;31mfd: %d. n: %ld\033[0m\n", h->fileDescriptor, n);
	  if(n == -1){
            fprintf(stderr, "\t\033[0;31mfd: %d. n: %ld, handler: %p, %s\033[0m\n",
			    h->fileDescriptor, n, h, strerror(errno));
	    /*
	    if(h->userData) {
	      supr_socket_conn_t * sc = (supr_socket_conn_t *)
			    h->userData;
              fprintf(stderr, "\t\t\033[0;33mconn: %s//%s:%d, fd: %d\033[0m\n",
			    sc->cmd, sc->host, sc->port, sc->fd);
	    }
	    */
	    close(h->fileDescriptor); // TODO
            t->next = h->next;
	    h = t;
	  }
	  //t = h;
        }
      }
	  return NULL;
    }

//    if(Supr_verbose){ printf("\n%s (%s:%d), ns: %d\n", __func__, __FILE__, __LINE__, ns); }

    InputHandler *handler=NULL;
#ifdef SUPR3
    for(h = Supr_R_InputHandlers; h; h = h->next)
#else
    BEGIN_R_EVAL();
      for(h = R_InputHandlers; h; h = h->next)
#endif
      {
        if(FD_ISSET(h->fileDescriptor, &readfds)) {
          if(fcntl(h->fileDescriptor, F_GETFD) != -1) {
	    handler = h;
            break; 
	  }
        }
      }
#ifdef SUPR3
#else
    END_R_EVAL();
#endif

    if(handler && !handler->userData){
       error_info("\n[%s] Error in select, (%s:%d), handler->userData: %p\n",
	       __func__, __FILE__, __LINE__, handler->userData);
    }

//    if(Supr_verbose){ printf("\n%s (%s:%d), ns: handler: %p, handler->userData: %p\n", __func__, __FILE__, __LINE__, handler, handler->userData); }

    return handler;
  }

  return NULL;
}

// from Defn.h
//#define DEFAULTDEPARSE		1089

//void __addCondHands_init()
SEXP __addCondHands_init()
{
  /*
  SEXP __R_HandlerStack = __R_ToplevelContext->handlerstack;
  //fprintf(stderr, "[%s] R_HandlerStack:\n", __func__);
  PrintValue(__R_HandlerStack);
  */
  static SEXP sInterruptHandler = NULL;

  if(!sInterruptHandler) { // protect???
    sInterruptHandler = install(".SuprInterruptHandler");
    Supr_protect(sInterruptHandler);
    SET_SYMVALUE(sInterruptHandler, R_NilValue);

  }

  SEXP call = SYMVALUE(sInterruptHandler);

  if(call == R_NilValue){

    SEXP name = PROTECT(mkString("interrupt"));

    SEXP func_body = PROTECT(LCONS(install(".Call"),
		     CONS(mkString("__R_interrupt_handle"), R_NilValue)));
  
    //SEXP formals = PROTECT(CONS(install("..."), R_NilValue));
    SEXP formals = PROTECT(CONS(R_MissingArg, R_NilValue));
    SET_TAG(formals, install("..."));
    SEXP intr_handler = PROTECT(allocSExp(CLOSXP));
    SET_FORMALS(intr_handler, formals);
    SET_BODY(intr_handler, func_body);
    SET_CLOENV(intr_handler, R_GlobalEnv);

    SEXP handler_list = PROTECT(allocVector(VECSXP, 1));
    SET_VECTOR_ELT(handler_list, 0, intr_handler);

    call = PROTECT(LCONS(install(".Internal"),
		  CONS(LCONS(install(".addCondHands"),
	  	  CONS(name, CONS(handler_list,
		  CONS(R_GlobalEnv, CONS(R_GlobalEnv,
		  CONS(R_TrueValue, //R_FalseValue,
			  R_NilValue)))))), R_NilValue)));
    UNPROTECT(6);
    SET_SYMVALUE(sInterruptHandler, call);
  }

  //SEXP oldstack = eval(call, R_GlobalEnv);
  return eval(call, R_GlobalEnv);

  /*
  {
    SEXP expr = PROTECT(Rf_deparse1m(call, 0, DEFAULTDEPARSE));
    //PrintValue(expr);
    for(int i=0; i<LENGTH(expr); i++)
    {
	  printf("%s\n", CHAR(STRING_ELT(expr, i)));
    }
  }
  */

}

// called when Supr_fini
void __addCondHands_fini(SEXP oldCondHandstack)
{
  //printf("\033[0;32mFIXME: implement %s, oldCondHandstack:\n", __func__);
  //PrintValue(oldCondHandstack); // errors.c: do_resetCondHands
  //printf("\033[0m\n");

  SEXP call = PROTECT(LCONS(install(".Internal"),
		  CONS(LCONS(install(".resetCondHands"),
	  	             CONS(oldCondHandstack, R_NilValue)), R_NilValue
			  )));
  eval(call, R_GlobalEnv);
  UNPROTECT(1);
}

//#include <python3.6m/Python.h>

const char *Thread_stateToString(int state)
{
  static char buf[64];
  switch(state){
    case THREAD_STATE_NEW: return "NEW";
    case THREAD_STATE_RUNNABLE: return "RUNNABLE";
    case THREAD_STATE_BLOCKED: return "BLOCKED";
    case THREAD_STATE_WAITING: return "WAITING";
    case THREAD_STATE_TIMED_WAITING: return "TIMED_WAITING";
    case THREAD_STATE_TERMINATED: return "TERMINATED";
    default: sprintf(buf, "Unknown state: %d", state);
	     return buf;
  }
  return NULL;
}

void Thread_dumper()
{
	// lock???
  fprintf(stdout, "\nThreads:\n");
  pid_t pid = getpid();
  for(int i=0; i<vectorSize(threads); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads,i);
    int is_proc = th->pid != pid;
    fprintf(stdout, "%2d. %s %s \t%s%d%s %d %s\n", i+1,
		    is_proc ? "*" : " ", th->name,
	    is_proc ? "\033[0;32m" : "", th->pid, is_proc ? "\033[0m" : "",
	    th->tid, Thread_stateToString(th->state));
  }
  fprintf(stdout, "\n");

  fprintf(stdout, "\nSys.threads:\n");
  for(int i=0; i<vectorSize(sys_threads); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(sys_threads,i);
    int is_proc = th->pid != pid;
    fprintf(stdout, "%2d. %s %s \t%s%d%s %d %s\n", i+1,
		    is_proc ? "*" : " ", th->name,
	    is_proc ? "\033[0;32m" : "", th->pid, is_proc ? "\033[0m" : "",
	    th->tid, Thread_stateToString(th->state));
  }
  fprintf(stdout, "\n");

  fprintf(stdout, "\nDCL.threads:\n");
  for(int i=0; i<vectorSize(dcl_threads); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(dcl_threads,i);
    int is_proc = th->pid != pid;
    fprintf(stdout, "%2d. %s %s \t%s%d%s %d %s\n", i+1,
		    is_proc ? "*" : " ", th->name,
	    is_proc ? "\033[0;32m" : "", th->pid, is_proc ? "\033[0m" : "",
	    th->tid, Thread_stateToString(th->state));
  }
  fprintf(stdout, "\n");

  // .ThreadEnv
}

#ifdef USE_PYTHON

static int Py_initialized = FALSE;

#ifdef __USE_PYTHON__   //delete python; see rython.c

#define __Py_Print(obj, str) do { \
        fprintf(stdout, "[%s:%d] %s :: ", __FILE__, __LINE__, (str));    \
        PyObject_Print((obj), stdout, Py_PRINT_RAW);    \
        fprintf(stdout, "\n");   \
} while(0)

// Py_module_list
typedef struct _struct_py_module {
  PyObject *module;
  struct _struct_py_module *next;
} py_module_t;

typedef struct _struct_py {
  char *progname;
  py_module_t *module_list;
} py_runtime_t; // experimental...

py_runtime_t __Py_runtime = {"Rython", NULL};
py_runtime_t *Rython_runtime = &__Py_runtime;

SEXP PyObject_toROject(PyObject *obj)
{
  if(!obj || obj == Py_None)
    return R_NilValue;

  static SEXP PythonSEXP = NULL;
  if(!PythonSEXP) PythonSEXP = install("PyObject");

  SEXP ret = R_NilValue;
  if(PyUnicode_Check(obj)) {
    char *cstr;
    PyArg_Parse(obj, "s", &cstr); // free???
    return mkString(cstr);
  } else if(PySequence_Check(obj)){

    size_t n = PySequence_Size(obj);
    fprintf(stdout, "PySequence ... size: %ld\n", n);
    if(n==0) return allocVector(VECSXP,0);

    PyObject *elem = PySequence_GetItem(obj, 0);
    if(PyUnicode_Check(elem)) {
      ret = PROTECT(allocVector(STRSXP, n));
      for(size_t i=0; i<n; i++) {
        PyObject *elem = PySequence_GetItem(obj, i);
        char *cstr;
        PyArg_Parse(elem, "s", &cstr);
        SET_STRING_ELT(ret, i, mkChar(cstr));
      }
      UNPROTECT(1);
      return ret;
    } else  if(PyFloat_Check(elem)){ //printf("PyFloat\n");
      ret = PROTECT(allocVector(REALSXP, n));
      for(size_t i=0; i<n; i++)
         PyArg_Parse(PySequence_GetItem(obj, i), "d", REAL(ret)+i);
      UNPROTECT(1);
      return ret;
    } else if(PyNumber_Check(elem)){
      ret = PROTECT(allocVector(INTSXP, n));
      for(size_t i=0; i<n; i++)
         PyArg_Parse(PySequence_GetItem(obj, i), "i", INTEGER(ret)+i);
      UNPROTECT(1);
      return ret;
    } else {

    fprintf(stdout, "TODO (%s:%d) ...\n", __FILE__, __LINE__);
	    
//__Py_Print(Py_TYPE(elem), "\033[0;31melem TYPE\033[0m");
//__Py_Print(obj, "obj: Sequence");

    }


  } else if(PyList_Check(obj)){
    size_t n = PyList_Size(obj);
    fprintf(stdout, "PyList ... size: %ld\n", n);
    ret = PROTECT(allocVector(VECSXP, n));
    for(size_t i=0; i<n; i++) 
       SET_VECTOR_ELT(ret, i, PyObject_toROject(PyList_GetItem(obj, i)));
    UNPROTECT(1);
    return ret;

  } else if(PyNumber_Check(obj)){
    fprintf(stdout, "PyNumber ...\n");
    if(PyFloat_Check(obj)){ printf("PyFloat\n");
      double val;
      PyArg_Parse(obj, "d", &val);
      return ScalarReal(val);

    } else if(PySequence_Check(obj)) {
          fprintf(stderr, "FIXME : Py... Sequence to SEXP\n");
      size_t n = PySequence_Size(obj);
      if(n ==0) return null;
      //PyObject *item = PySequence_GetItem(obj, 0);
      ret = PROTECT(allocVector(REALSXP, n));
      for(size_t i=0; i<n; i++)
         PyArg_Parse(PySequence_GetItem(obj, i), "d", REAL(ret)+i);
      UNPROTECT(1);
      return ret;

    } else if(PyTuple_Check(obj)) {
            printf("Py... Tuple\n");
    } else {  printf("Py... int\n");
      int val;
      PyArg_Parse(obj, "i", &val);
      return ScalarInteger(val);
    }

  } else if(PyDict_Check(obj)){
    fprintf(stdout, "PyDict ...\n"); printf("Py... Dict\n");
    size_t size = PyDict_Size(obj); //PyObject *keys = PyObject_Dir(obj);
    PyObject *keys = PyDict_Keys(obj);
    if(PyList_Check(keys)) PyList_Sort(keys);
    //printf("PySequence_Check(keys) = %d\n", PySequence_Check(keys));
    ret = PROTECT(allocVector(VECSXP, size));
    SEXP names = PROTECT(allocVector(STRSXP, size));
    char *key_str;
    const char *value_str;
    for(int i=0; i<size; i++){ // FIXME
       PyObject *key = PySequence_GetItem(keys, i);
       PyArg_Parse(key, "s", &key_str);
       PyObject *value = PyDict_GetItem(obj, key);
       fprintf(stdout, "[%d] ", i);
       PyObject *repr = PyObject_Repr(value);
       PyArg_Parse(repr, "s", &value_str);
       //value_str = PyString_AsString(repr);
       fprintf(stderr, "%s\n", value_str);
       SET_STRING_ELT(names, i, mkChar(key_str));
       SEXP rv = PROTECT(R_MakeExternalPtr(value, R_NilValue, R_NilValue));
       setAttrib(rv, R_ClassSymbol, mkString("PythonObject"));
       SET_VECTOR_ELT(ret, i, rv);
    }
    setAttrib(ret, R_NamesSymbol, names);
    UNPROTECT(2);
    return ret;

  } else if(PyModule_Check(obj)){
    fprintf(stdout, "PyModule ...\t -> PyObject_Dir(obj):\n");
    return PyObject_toROject(PyObject_Dir(obj));
  }

  Py_INCREF(obj);
  Py_INCREF(obj); // why?

  // why
  ret = PROTECT(R_MakeExternalPtr(obj, PythonSEXP, null));
  PyObject *repr = PyObject_Repr(obj);
  const char *value_str;
  PyArg_Parse(repr, "s", &value_str);
  setAttrib(ret, install(">>>"), PROTECT(mkString(value_str)));

  UNPROTECT(2);
  return ret;


}

//SEXP Rython_findObject(SEXP r_name)
static PyObject *Rython_findObject(const char *obj_name)
{
  //const char *obj_name = CHAR(asChar(r_name));
  PyObject *sys_module = PyImport_AddModule("sys");
  PyObject *sys_dict   = PyModule_GetDict(sys_module);

  PyObject *local_dict  = PyDict_GetItemString(sys_dict, "supr_local_dict");
  PyObject *global_dict = PyDict_GetItemString(sys_dict, "supr_global_dict");

  PyObject *main_module = PyImport_AddModule("__main__");
  PyObject *main_dict = PyModule_GetDict(main_module);

  PyObject *sm_dict = PyDict_GetItemString(sys_dict, "modules");
  PyObject *obj = NULL;

  int len = strlen(obj_name);
  char buffer[len+1];

  PyObject *dicts[] = {local_dict, global_dict, main_module,
          PyImport_AddModule("builtins"),
          PyImport_AddModule("sys"),
          NULL};

  int d = 0;
  PyObject *dict = dicts[0];
  for(; dict; dict = dicts[++d]) {
    if(PyModule_Check(dict)) dict = PyModule_GetDict(dict);
    sprintf(buffer, "%s", obj_name);
    char obj_buffer[len+1];

    char *s = buffer;
    while(s){
//        printf("[%d] %s\n", d, s);
      if(obj = PyDict_GetItemString(dict, s)) break;
      int i = strlen(s) - 1;
//        printf("[%d] <%p>\n", i, obj);
      for(; i>=0; i--) {
        if(buffer[i] == '.'){
          memcpy(obj_buffer, buffer, strlen(obj_name)+1);
          obj_buffer[i] = 0;
          s = obj_buffer;
          if(strlen(s)==0) s = NULL;
          break;
        }
      }
      if(i<0) break;
    }

    if(!obj) continue;

    if(strlen(s) < len){
      sprintf(buffer, "%s", obj_name+strlen(s)+1);
      sprintf(buffer, "%s", obj_name+strlen(s)+1);
//    printf("\n\033[0;33mbuffer = %s, ", buffer);
      char *t = buffer;
      while(strstr(t, ".")){
        for(int i=0; i<strlen(t); i++){
          if(t[i]=='.'){
              t[i] = 0;
              obj = PyObject_GetAttrString(obj, t);
              if(!obj) return NULL;
              /*
    printf("\n\033[0;34mobject, ");
              printf("t = %s\n", t);
    PyObject_Print(obj, stdout, Py_PRINT_RAW);
    printf("\033[0m\n\n");
    */
              t += i+1;
              break;
          }
        }
      }
      obj = PyObject_GetAttrString(obj, t);
    }
    break;
  }

  return obj;

//  return R_NilValue;
}	

//SEXP 
static const char *Rython_getDoc(PyObject *obj)
{
    PyFunctionObject *func = NULL;

  if (PyMethod_Check(obj)){ // PyMethodObject
    __Py_Print(obj, "PyMethod:\n");
        PyMethodObject *meth = (PyMethodObject *) obj;
        return Rython_getDoc(meth->im_func);
  } else if (PyFunction_Check(obj)) { // PyFunctionObject
    __Py_Print(obj, "PyFunction:\n");
// see funcobject.h
        func = (PyFunctionObject*) obj;

//      return func->func_doc;
        PyObject *repr = PyObject_Repr(func->func_doc);
        const char *doc_str;
        PyArg_Parse(repr, "s", &doc_str);
        return doc_str; // free??? double check ...
  } else if (PyCFunction_Check(obj)) { // PyCFunctionObject
//    Py_Print(obj, "PyCFunction:\n");
//PyObject_HEAD
//PyMethodDef *m_ml; Description of the C function to call
//PyObject    *m_self;Passed as 'self' arg to the C func, can be NULL
//PyObject    *m_module; /* The __module__ attribute, can be anything */
//PyObject    *m_weakreflist; /* List of weak references */
    PyMethodDef *m_ml = ((PyCFunctionObject*)obj)->m_ml;
// onst char  *ml_name;
// PyCFunction ml_meth;
// int         ml_flags;
// const char  *ml_doc;
    return m_ml->ml_doc;
  } else {

        PyObject *repr = PyObject_Repr(obj);
        const char *doc_str;
        PyArg_Parse(repr, "s", &doc_str);
        return doc_str; // free??? double check ...
  }
}



SEXP Python_import(SEXP r_name, SEXP r_from)
{
  //if( !Py_initialized)
  if( ! Py_IsInitialized() )
  { // testing
    Py_Initialize();
//    Py_initialized = TRUE;
    fprintf(stderr, "Py_IsInitialized: %d\n", Py_IsInitialized());

    PyObject *pName, *pModule;

    //pName = PyUnicode_DecodeFSDefault("numpy");
    pName = PyUnicode_DecodeFSDefault("sys");
    fprintf(stdout, "pName: %p, PyObject_Print:\033[0;35m\n", pName);

    if(PyErr_Occurred()){
      PyErr_Print();
      PyErr_Clear();
    } else {
      PyObject_Print(pName, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\033[0m\n");
    }
    
    pModule = PyImport_Import(pName);
    if(PyErr_Occurred()){
      PyErr_Print();
    }
    Py_DECREF(pName);

    fprintf(stdout, "pModule: %p, PyObject_Print:\033[0;35m\n", pModule);
   
    PyObject_Print(pModule, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\033[0m\n");

  }


  PyObject *pModule = NULL;
  const char *name = CHAR(asChar(r_name));
  const char *from = CHAR(asChar(r_from));
  if(name){
    PyObject *globals = NULL; // PyDict_New();
    PyObject *locals = NULL;  //PyDict_New();
    PyObject *fromlist = NULL; // for now
    pModule = PyImport_ImportModuleEx(name, globals, locals, fromlist);
    __Py_Print(pModule, "import from");
    if(PyErr_Occurred()) {
      PyErr_Print(); // for now
      PyErr_Clear();
//      Py_XDECREF(pName);
      error(_("Python Error Occurred"));
      //Py_XDECREF(pModule);
    }

    {
       SEXP val = PyObject_toROject(pModule);
       PrintValue(val);
    }

    py_module_t *ml = (py_module_t *)malloc(sizeof(py_module_t));
    ml->module = pModule;
    ml->next = Rython_runtime->module_list;
    Rython_runtime->module_list = ml;

  }

  int i=0;
  for(py_module_t *ml=Rython_runtime->module_list; ml; ml=ml->next) {
     fprintf(stdout, "\n%4d: %s ", ++i, PyModule_GetName(ml->module));
     PyObject_Print(ml->module, stdout, Py_PRINT_RAW);
  }
  fprintf(stdout, "\n");

  SEXP retval = PROTECT(R_MakeExternalPtr(pModule, R_NilValue, R_NilValue));
  setAttrib(retval, R_ClassSymbol, mkString("PythonModule"));
  UNPROTECT(1);

  return retval;
}

static PyObject *SEXP_toPyObject(SEXP s)
{
  static SEXP PythonSEXP = NULL;
  if(!PythonSEXP) PythonSEXP = install("PyObject");

  PyObject *obj;
  if(s == R_NilValue)
    return Py_None; // return NULL;
  else if(TYPEOF(s) == LISTSXP){
    int n=0;
    for(SEXP t = s; t != R_NilValue; t = CDR(t)) n++;
    obj = PyTuple_New(n);
    n = 0;
    for(SEXP t = s; t != R_NilValue; t = CDR(t)) {
      PyTuple_SetItem(obj, n++, SEXP_toPyObject(CAR(t)));
    }
    return obj;
  } else if (TYPEOF(s) == REALSXP){
    if (LENGTH(s)==1){
      obj = PyFloat_FromDouble(REAL(s)[0]);
      return obj;
    } else { // ???

      PyObject *list = PyList_New(LENGTH(s));
      for (size_t i = 0; i < LENGTH(s); i++) {
        PyList_SET_ITEM(list, i, PyFloat_FromDouble(REAL(s)[i]));
      }
      return list;
    }
  } else if (TYPEOF(s) == INTSXP){
    if (LENGTH(s)==1){
      return Py_BuildValue("i", INTEGER(s)[0]);
    } else {
      PyObject *list = PyList_New(LENGTH(s));
      for (size_t i = 0; i < LENGTH(s); i++)
        PyList_SET_ITEM(list, i, Py_BuildValue("i", INTEGER(s)[i]));
      return list;
    }
  } else if (TYPEOF(s) == SYMSXP){
    PyObject *obj =  Rython_findObject(CHAR(PRINTNAME(s)));
    if(!obj) error(_("Python cannot find object '%s'"), CHAR(PRINTNAME(s)));
    return obj;
  } else if (TYPEOF(s) == EXTPTRSXP && R_ExternalPtrTag(s) == PythonSEXP){
    PyObject *obj = R_ExternalPtrAddr(s);
    //CHECK_REFCNT(obj);
    _Py_CHECK_REFCNT(obj);
    Py_INCREF(obj); // for now CHECK REFCNT?
    return obj;
  } else if (TYPEOF(s) == STRSXP){
    size_t n = LENGTH(s);
    if(n==0) return PyList_New(0);
    if(n==1){
      return PyUnicode_DecodeFSDefault(CHAR(STRING_ELT(s,0)));
    } else {
      PyObject *list = PyList_New(n);
      for (size_t i = 0; i < n; i++)
              PyList_SET_ITEM(list, i, Py_BuildValue("s",
                                     CHAR(STRING_ELT(s, i))));
      return list;
    }
  }

  error(_("SEXP_toPyObject (%s): not fully implemented"),
                  type2char(TYPEOF(s)));
  return NULL;
}



// _put
SEXP Rython_Assign(SEXP r_name, SEXP r_value, SEXP r_dict)
{// testing ..
  PyObject *sys_module = PyImport_AddModule("sys");
  PyObject *sys_dict   = PyModule_GetDict(sys_module);
  PyObject *global_dict = PyDict_GetItemString(sys_dict, "supr_global_dict");

  const char *var_name = CHAR(asChar(r_name));
  PyObject *val = SEXP_toPyObject(r_value);

  if(val) {
    PyDict_SetItemString(global_dict, var_name, val);
  } else {
    error(_("(%s:%d)"), __FILE__, __LINE__);
  }

  return R_NilValue;
}

// This is a starting point
SEXP do_python(SEXP call, SEXP op, SEXP args, SEXP env)
{
#ifdef USE_PYTHON
  const char *progname = "Embeded Python"; // _01 ???
  //Py_SetProgramName(progname);  // optional but recommended
  Py_Initialize();
  // for now ...
  py_runtime_t *py_runtime = malloc(sizeof(py_runtime_t));
  py_runtime->progname = strdup(progname);
  py_runtime->module_list = NULL; // deprecated ...
  /*
  __py_AddModule(call, "__main__", py_runtime);
  __py_AddModule(call, "sys", py_runtime);
  __py_AddModule(call, "builtins", py_runtime);
  __py_AddModule(call, "numpy", py_runtime);
  */
  {
    PyObject *sys_module = PyImport_AddModule("sys");
    PyObject *global_dict = PyDict_New();
//    PySys_SetObject("supr_local_dict", PyDict_New());
    PySys_SetObject("supr_local_dict", global_dict);
    PySys_SetObject("supr_global_dict", PyDict_New());


    PyDict_SetItemString(global_dict, "__main__",
                    PyImport_AddModule("__main__"));

  }

  SEXP py_ptr = PROTECT(R_MakeExternalPtr(py_runtime, null, null));

  // FIXME...
  SEXP klass = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                          //findVar(install("Object"), R_ClassEnv),
                  ScalarInteger(29)));
  //setAttrib(py_ptr, R_ClassEnvSymbol, klass);
  setAttrib(py_ptr, R_ClassSymbol, klass);
  setAttrib(klass, R_NameSymbol, mkString("Python"));
  setAttrib(klass, R_ClassSymbol, mkString(".Class"));
  //setAttrib(klass, R_ClassEnvSymbol, findVar(install("Class"), R_ClassEnv));
  //setAttrib(klass, R_ClassSymbol, findVar(install("Class"), R_ClassEnv));
  //defineVar(install("Python"), klass, R_ClassEnv);

  SEXP callClassFun =  findFun(install(".callClassFun"), R_BaseEnv);

  // construct these from the above python_funs ???
  /*
  defineVar(install("SimpleString"),    callClassFun, klass);
  defineVar(install("SimpleFile"),    callClassFun, klass);
  defineVar(install("CallObject"),    callClassFun, klass);
  */

  /*
  T_class_fun_t *pfun = python_funs;
  for(int i=0; pfun[i].name; i++)
          defineVar(install(pfun[i].name),    callClassFun, klass);
	  */

  /*
  for(int i=0; pfun[i].name; i++){
    defineVar(install(pfun[i].name),    callClassFun, klass);
    SEXP fun = PROTECT(allocSExp(CLOSXP));
    CLOSENV(fun) = R_BaseEnv;
  }
  */


//  SEXP R_DocSymbol = install("doc");

  //R_RegisterCFinalizer(py_ptr, python_finalizer);

  /*
  printf("Examples:\n\nSimpleString(\"from time import time, ctime\\n"
      "print('Today is', ctime(time()))\\n\")\n");
  printf("\nSimpleFile(\"script.py\")\n\n");
  */

  //T_PROTECT(py_ptr);
  UNPROTECT(2);

  return py_ptr;
#else
  error(_("not implemented"));
#endif
}

#endif  // delete Python



////////////////////////////////////////////
//
// run python3.6m-config --cflags to see the compile and link flags???
//
// run python3.6m

static void *__Python_REPL(void *data)
{
  printf("use Python\n");
//  rl_callback_handler_remove(); // Okay

  //char *argv[] = {"python3.6m"};

  wchar_t *argv[1]; // = {"python3.6m"};

  {
    if (setlocale(LC_ALL, "") == NULL) {
               perror("setlocale");
               exit(EXIT_FAILURE);
    }

    size_t mbslen = mbstowcs(NULL, "python3.6m", 0);
    if (mbslen == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
    }

    argv[0] = calloc(mbslen + 1, sizeof(wchar_t));
    if (argv[0] == NULL) {
               perror("calloc");
               exit(EXIT_FAILURE);
    }

    if (mbstowcs(argv[0], "python3.6m", mbslen + 1) == (size_t) -1) {
               perror("mbstowcs");
               exit(EXIT_FAILURE);
           }

  }

  printf("sizeof(wchar_t): %ld\n", sizeof(wchar_t));
  int argc = sizeof(argv)/sizeof(wchar_t*);

  Py_Main(argc, argv);
}

// #define PY_UNICODE_TYPE wchar_t
// no the right way ?
SEXP Sys_Python()
{
  error("deprecated");
  Sys_switch = NULL;
  pthread_mutex_lock(&OS_system_lock);

    rl_callback_handler_remove(); // Okay
    __Python_REPL(NULL);

    pthread_cond_wait(&OS_system_cond, &OS_system_lock);
  pthread_mutex_unlock(&OS_system_lock);

  return R_NilValue;//FIXME
}

static int __Ctr_P_command_func(int count, int key)
{
  printf("count: %d, key: %d\n", count, key);
  // save R history???

  //suspend R?
  // use a new thread to do Python?

  // shutdown rl?
  // return -1;

  Sys_switch = __Python_REPL;


  return 0;

  if( !Py_initialized) {
    Py_Initialize();
    Py_initialized = TRUE;
    fprintf(stderr, "Py_IsInitialized: %d\n", Py_IsInitialized());

    PyObject *pName, *pModule;

    //pName = PyUnicode_DecodeFSDefault("numpy");
    pName = PyUnicode_DecodeFSDefault("sys");
    fprintf(stdout, "pName: %p, PyObject_Print:\033[0;35m\n", pName);

    if(PyErr_Occurred()){
      PyErr_Print();
      PyErr_Clear();
    } else {
      PyObject_Print(pName, stdout, Py_PRINT_RAW);
      fprintf(stdout, "\033[0m\n");
    }
    
    pModule = PyImport_Import(pName);
    if(PyErr_Occurred()){
      PyErr_Print();
    }
    Py_DECREF(pName);

    fprintf(stdout, "pModule: %p, PyObject_Print:\033[0;35m\n", pModule);
   
    PyObject_Print(pModule, stdout, Py_PRINT_RAW);
    fprintf(stdout, "\033[0m\n");

  }

  rl_save_prompt();
  rl_message("\033[0;32m<Python: Unimplemented>\033[0m");
  sleep(3);
  rl_restore_prompt();
  rl_clear_message();

  return 0;
}
#else
static int __Ctr_P_command_func(int count, int key)
{
  printf("count: %d, key: %d\n", count, key);
}
#endif

static int __Ctr_R_command_func(int count, int key)
{
  //printf("count: %d, key: %d\n", count, key);
  //rl_message("count: %d, key: %d", count, key);
  rl_save_prompt();
  rl_message("\033[0;32m<R: running>\033[0m");
  sleep(3);
  rl_restore_prompt();
  rl_clear_message();
}

static int rjni_strcmp(const void *a, const void *b);

// print the shared objects
static int __Ctr_S_command_func(int count, int key)
{
  printf("\nThread_C_SharedObjects: %p\n\n", Thread_C_SharedObjects);

  if(!Thread_C_SharedObjects) return 0;

  pthread_mutex_lock(Thread_C_SharedObjects->mutex);

  int n;
  char **keys = Hashtable_keySet(Thread_C_SharedObjects, &n);
  qsort(keys, n, sizeof(char *), rjni_strcmp);
  for(int i=0; i<n; i++){
    SEXP val = (SEXP) Hashtable_get(Thread_C_SharedObjects, keys[i]);
    fprintf(stdout, "%s: %s\n", keys[i], type2char(TYPEOF(val)));
  }
  pthread_mutex_unlock(Thread_C_SharedObjects->mutex);

  free(keys);
  fprintf(stdout, "\n");

  rl_save_prompt();
  rl_message("\033[0;32m<Thread_C_SharedObjects>\033[0m");
  sleep(3);
  rl_restore_prompt();
  rl_clear_message();

}

void Connection_dumper()
{
  fprintf(stdout, "Connections:\n");
  for(int i=0; i<sizeof(connections)/sizeof(supr_socket_conn_t*); i++){
    if(connections[i]){
      fcntl(i, F_GETFD);
      fprintf(stdout, "%3d. fcntl(%3d, F_GETFD): %s\n", i, i, strerror(errno));
      //if(fcntl(h->fileDescriptor, F_GETFD) == -1)
    }
  }
  fprintf(stdout, "\n");
}

static int __Ctr_T_command_func(int count, int key)
{
  rl_save_prompt();
  Thread_dumper();

  fprintf(stdout, "R_lock.owner: %d\n", __thread_mutex.__data.__owner);

  Connection_dumper();


  rl_message("\033[0;32m<thread info>\033[0m");
  sleep(3);
  rl_restore_prompt();
  rl_clear_message();
}

// enable auto print messages
static int __Ctr_I_command_func(int count, int key)
{
  Supr_display_message = ! Supr_display_message;
 // fprintf(stderr, "%s is called\n", __func__);
}

static int __Ctr_D_command_func(int count, int key)
{
 // fprintf(stderr, "%s is called\n", __func__);
  printf("Ctr^D: jump?\n");
  // KeyboardInterrupt
  //PyErr_SetString(PyExc_KeyboardInterrupt, "\\Ctr-D");
  //PyErr_SetNone(PyExc_KeyboardInterrupt);
  //RCNTXT *cntxt = R_GlobalContext;
  //longjmp(cntxt->cjmpbuf, 0);

  //c_backtrace();
  //PyErr_SetNone(PyExc_KeyboardInterrupt);
}


typedef struct keyseq_bind_struct {
  const char *key_seq;
  int (*cmd_func)(int count, int key);
  struct keyseq_bind_struct *next;
} keyseq_bind_t;

static keyseq_bind_t __C_P_bind = {"\\C-P", __Ctr_P_command_func, NULL};
static keyseq_bind_t __C_R_bind = {"\\C-R", __Ctr_R_command_func, &__C_P_bind};
static keyseq_bind_t __C_S_bind = {"\\C-L", __Ctr_S_command_func, &__C_R_bind};
static keyseq_bind_t __C_T_bind = {"\\C-T", __Ctr_T_command_func, &__C_S_bind};
static keyseq_bind_t __C_I_bind = {"\\C-I", __Ctr_I_command_func, &__C_T_bind};
static keyseq_bind_t __C_D_bind = {"\\C-D", __Ctr_D_command_func, &__C_I_bind};

static keyseq_bind_t *keyseq_bind_root =  &__C_D_bind;

static int __rl_startup_hook()
{
  int rc;

  keyseq_bind_t *kb = keyseq_bind_root;
  while(kb){
    rc = rl_bind_keyseq(kb->key_seq, kb->cmd_func);
    kb = kb->next;
  }

//    printf("Bind KeySeq \"%s\" to func, rc: %d\n", kb->key_seq, rc);
  /*
  const char *Ctr_P = "\\C-P";
  printf("Bind KeySeq \"%s\" to func\n", Ctr_P);
  rc = rl_bind_keyseq(Ctr_P, __Ctr_P_command_func);
  printf("rc: %d\n", rc);

  const char *Ctr_R = "\\C-R";
  rc = rl_bind_keyseq("\\C-R", __Ctr_R_command_func);
  printf("rc: %d\n", rc);
  */

  return 0;
}	


#ifdef SUPR3
int Thread_main_run_Rmainloop(void) // delete me ...
{
	 return NA_INTEGER;
}
#else // SUPR3

//static int inSuprEval = FALSE;

//void Thread_main_run_Rmainloop(void)
// returns for EOF
int Thread_main_run_Rmainloop(void)
{
  SEXP oldCondHandstack;

  {
	
      SEXP sleepVar = findVar(install("sleepVar"), R_GlobalEnv);
      if(sleepVar == R_UnboundValue){
         fprintf(stderr, "\033[0;31m%s: sleepVar == R_UnboundValue\n", __func__);
      } else sleep(300);

  }
  
 

 // printf("CHECK ...R_ToplevelContext->cjmpbuf: %ld\n", __R_ToplevelContext->cjmpbuf);
  //printf("R_ToplevelContext->cjmpbuf: %p\n", &__R_ToplevelContext->cjmpbuf);
//	inSuprEval = TRUE;
  //printf("[%s] In ... sizeof(jmp_buf): %ld\n", __func__ ,sizeof(jmp_buf));
  //printf("[%s] In ... sizeof(JMP_BUF): %ld\n", __func__ ,sizeof(JMP_BUF));
//  fprintf(stderr,"\n\n");
//  fprintf(stderr, "\t\t\033[0;46m<<<Welcome to %s>>>\033[0m\n", __func__);
//  fprintf(stderr, "\n\n");
	/*
  static int test_tty = TRUE;
  static int is_tty   = FALSE;
  if(test_tty){
    errno = 0;
    is_tty = isatty(STDIN_FILENO);
    if(errno) {
          printf("[%s] Error: %s STDIN_FILENO: %d (%s:%d)\n", __func__,
                          strerror(errno), STDIN_FILENO,
                          __FILE__, __LINE__);

	  if(errno == ENOTTY){
            char buf[PATH_MAX];
            int n = readlink("/proc/self/fd/1", buf, sizeof(buf));
            buf[n]=0;
            printf("[%s] file_name: %s\n", __func__, buf);

            struct stat sb;
            if(fstat(STDOUT_FILENO,&sb) != -1){
              printf("[%s] is.fifo: %d\n", __func__, S_ISFIFO(sb.st_mode));
            }
          } 
	  is_tty = FALSE;
          //return NULL;
    }
    if(is_tty){
      char buf[PATH_MAX];
      int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
      if(rc) {
          printf("[%s] Error: %s (%s:%d)\n", __func__, strerror(errno),
                          __FILE__, __LINE__);
          //return NULL;
      } else 
        printf("ttyname: %s\n", buf);
    }
    test_tty = FALSE;
    Supr_isatty = is_tty;
    fflush(stdout);
  }
  */


  static int do_rl_startup_hook = TRUE;
  if(do_rl_startup_hook){
//    printf("rl_startup_hook: %p\n", rl_startup_hook);
    rl_startup_hook = __rl_startup_hook;
    do_rl_startup_hook = FALSE;
  } else {
    rl_startup_hook = NULL;
  }

  static jmp_buf __cjmpbuf;
  static int save_jmpbuf = TRUE;

  if(save_jmpbuf) {
    memcpy(__cjmpbuf, __R_ToplevelContext->cjmpbuf, sizeof(jmp_buf));
    save_jmpbuf = FALSE;
  }

  __R_interrupted = FALSE;
    /* Here is the real R read-eval-loop. */
    /* We handle the console until end-of-file. */
  supr_thread_t *cth = currentThread(); // main_thread

  cth->R_GlobalContext = R_GlobalContext = __R_ToplevelContext;
  cth->save_R_PPStackTop = R_PPStackTop;

  int rc = pthread_mutex_trylock(&__thread_mutex);
  if( rc == 0 ){
    pthread_mutex_unlock(&__thread_mutex);
  } else {
    printf("[Warning] pthread_mutex_trylock: %d\n", rc); 
    pthread_mutex_unlock(&__thread_mutex);
    pthread_mutex_destroy(&__thread_mutex);
    pthread_mutex_init(&__thread_mutex, NULL);
  } 

  //rc = pthread_mutex_lock(&__thread_mutex);
  int repl_rc;
  BEGIN_R_EVAL();
  //supr_R_Busy(TRUE);

    if(TYPEOF(__R_ToplevelContext->handlerstack) == NILSXP)
      oldCondHandstack = __addCondHands_init();
    else {
      printf("[%s] existing R_ToplevelContext->handlerstack:\n", __func__);
      PrintValue(__R_ToplevelContext->handlerstack);
    }

    SEXP syscall = R_NilValue;
    syscall = PROTECT(LCONS(install("SupR.repl"), R_NilValue));

    /*
    SEXP intr_handler = PROTECT(LCONS(install(".Call"),
			  CONS(mkString("__R_interrupt_handle"), R_NilValue)));
    SEXP result = PROTECT(allocVector(VECSXP, RESULT_SIZE));
    SEXP intr_handler_entry = PROTECT(mkHandlerEntry(mkString("interrupt"),
		  R_GlobalEnv, intr_handler, R_GlobalEnv, result, 1));

    __R_ToplevelContext->handlerstack = CONS(intr_handler_entry,
		    __R_ToplevelContext->handlerstack);
    UNPROTECT(3);
    */

    RCNTXT cntxt;
    SEXP env = R_GlobalEnv;
    begincontext(&cntxt, CTXT_RETURN, syscall, env, env, R_NilValue, R_NilValue);

      // UNPROTECT(1); // syscall is protected by cntxt
      cntxt.cend = &Thread_main_run_cend;
      cntxt.cenddata = NULL;

      /*
      if(TYPEOF(__R_ToplevelContext->handlerstack) == NILSXP) {
        SEXP __R_HandlerStack = cntxt.handlerstack;
        printf("[%s] R_HandlerStack:\n", __func__);
        PrintValue(__R_HandlerStack);

        __R_ToplevelContext->handlerstack = CONS(__R_HandlerStack,
		      __R_ToplevelContext->handlerstack);
      }
      */
      /*
      {
        SEXP v = SYMVALUE(install("version"));
        PrintValue(v);
	printf("typeof(vesion): %s\n", type2char(TYPEOF(v)));
	int n = LENGTH(v);
	for(int i=0; i<n; i++){
	  printf("name: %s\n", CHAR(STRING_ELT(getAttrib(v, R_NamesSymbol),
					  i)));
	  printf("typeof(vesion): %s\n", type2char(TYPEOF(VECTOR_ELT(v,i))));
	}
      }
      */

  CheckThreadMain();
      if (!setjmp(__R_ToplevelContext->cjmpbuf))
      {

        memcpy(R_ToplevelContext_cjmpbuf, __R_ToplevelContext->cjmpbuf,
		    sizeof(jmp_buf));
        memcpy(cth->cjmpbuf, __R_ToplevelContext->cjmpbuf, sizeof(jmp_buf));

        //my_ReplConsole(R_GlobalEnv, 0, 0);
        repl_rc = my_ReplConsole(R_GlobalEnv, R_PPStackTop, 0);

      } else {

        __ReplIteration = NULL;

//if(ptr_R_Busy != supr_R_Busy) save_ptr_R_Busy = ptr_R_Busy;
ptr_R_Busy = supr_R_Busy;

	if(__R_interrupted){
          printf("\033[0;31m[%s] %s INTERRUPTED \033[0m\n",
			  __func__, cth->name);
	}

	if(!cth){
		__FIXME__("cth == NULL");
		exit(1);
	}

        if(__thread_mutex.__data.__owner == cth->tid){
	  pthread_mutex_unlock(&__thread_mutex);
        //  printf("[%s] %s UNLOCKED __thread_mutex\n", __func__, cth->name);
        }

  //CheckThreadMain();

        { 
	  if(__thread_mutex.__data.__owner == cth->tid){
            int rc = pthread_mutex_unlock(&__thread_mutex);
	  }

	  if(cth->data == PTHREAD_ERROR) {
          printf("[%s] \033[0;31mPTHREAD_ERROR: jump to run_Rmainloop\033[0m\n",
			  __func__);
	    Thread_main_reset();
Supr_running = FALSE;
	    //longjmp(__cjmpbuf, 0);
//inSuprEval = FALSE;
	    LONGJMP(__cjmpbuf, 0);
	  }

 // CheckThreadMain();

          supr_thread_t *ccth = currentThread(); // main_thread
	  //if(ccth)
	  {


  /*
          for(int i=0; i<vectorSize(threads); i++){
	    supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads,i);
	    printf("[%s] %2d. name: %s, state: %d\n", __func__, i+1, th->name,
			      th->state);
	    printf("[%s]     cth->name: %s, cth->state: %d (%p, %p)\n",
			    __func__, cth->name, cth->state, th, cth);
	    printf("cth: %p (ccth: %p), th: %p,  main_thread: %p, currentThread(): %p)\n",
			    cth, ccth, th, main_thread, currentThread());
  CheckThreadMain();
	  }
	  */

            for(int i=vectorSize(threads)-1; i>=0; i--){
	      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads,i);
	      if(th == cth) continue;

	    //int c_rc = pthread_cancel(th->ptid);
	      run_t *run = newRunnable(tmp_CheckStack, NULL);

	      pthread_mutex_lock(&th->mutex);
//	      printf("[%s] name: %s, state: %d\n", __func__, th->name, th->state);
	        if(th->state == THREAD_STATE_TERMINATED){
	          pthread_mutex_unlock(&th->mutex);
	          continue;
	        }
	        th->data = NULL;
	        th->runnable = run;
		{
		  SuprSignal_set(SIGUSR2);
		}
	        int c_rc = pthread_kill(th->ptid, SIGUSR2);
	        printf("run: %p,  c_rc: %d, %s\n", run, c_rc, strerror(c_rc));

	        if(c_rc == 0){
	          pthread_cond_wait(&th->cond, &th->mutex);
	          void *retval;

		  th->state = THREAD_STATE_TERMINATED;
	          pthread_mutex_unlock(&th->mutex);

		  if(TRUE){ // FIXME
	            int j_rc =  pthread_join(th->ptid, &retval);
	            char buf[256];
	            printf("\tj_rc: %d, retval: %s\n", j_rc,
				    ptrToString( retval, buf, 256));
		    vectorRemove(threads, i);
		    Supr_decref(th); // FIXME
		  }
	        } else {
	          pthread_mutex_unlock(&th->mutex);
		}
	        run->class->finalize(run->class, run);
	      //pthread_mutex_unlock(&th->mutex);
	    }
	  }
        }
	if(Supr_verbose){
          printf("[%s] \033[0;m jump to run_Rmainloop\033[0m\n", __func__);
	}
	//if(cth)
          Thread_main_reset();
        //longjmp(__cjmpbuf, 0);
//inSuprEval = FALSE;
	Supr_running = FALSE;
        LONGJMP(__cjmpbuf, 0);
      }
    //end_Rmainloop(); /* must go here */

    endcontext(&cntxt);

  //supr_R_Busy(FALSE);
  END_R_EVAL();

  // if(rc == -1){
//          printf("\033[0;31m[%s] RETURN, repl_rc: %d\033[0m\n", __func__, repl_rc);
//	  return -1;
//	}
//  Supr_detach(FALSE);

  //memcpy(__R_ToplevelContext->cjmpbuf, R_ToplevelContext_cjmpbuf, sizeof(jmp_buf)); // check R_ToplevelContext_cjmpbuf
  //Supr_checkJMP(__func__);

  memcpy(__R_ToplevelContext->cjmpbuf, save_R_ToplevelContext_cjmpbuf,
		  sizeof(jmp_buf));
  //Supr_checkJMP(__func__);

  //Supr_detach(TRUE);

  __addCondHands_fini(oldCondHandstack);

  //
  if(R_Interactive) {
    rl_callback_handler_remove();
    rl_callback_sigcleanup ();
    //rl_clear_history();
    char *call =  Supr_quit();
    //printf("Call: %s\n", call);
    //int n= rl_insert_text(call);
    //fprintf(stdout, "rl_insert_text(call): %d\n", n);
    //fflush(stdout);

    rl_startup_hook = NULL;
    keyseq_bind_t *kb = keyseq_bind_root;
    while(kb){
      //rc = rl_bind_keyseq(kb->key_seq, kb->cmd_func);
      rc = rl_bind_keyseq(kb->key_seq, NULL);
      kb = kb->next;
    }

    // remove key bindings
    rl_initialize();
    rl_reset_line_state();
    //free(call);
    int n= rl_insert_text(call);
    //fprintf(stdout, "rl_insert_text(call): %d\n", n);
    //rl_message(call);

    //add_history(call);
    free(call);

//    SEXP func_body = PROTECT(LCONS(install("library.dynam.unload"),
//         CONS(mkString("libsupr"), CONS(mkString(Supr_sysHome), R_NilValue))));
    SEXP func_body = PROTECT(LCONS(install("{"), R_NilValue));
    /*
    SETCDR(func_body, CONS(LCONS(install("library.dynam.unload"),
         CONS(mkString("libsupr"), CONS(mkString(Supr_sysHome), R_NilValue))),
	 CONS(R_FalseValue, R_NilValue)));
	 */
#define SUPR_UNLOAD_CHECK
#ifdef SUPR_UNLOAD_CHECK
    SETCDR(func_body, CONS( // 1
         LCONS(install("library.dynam.unload"),
               CONS(mkString("libsupr"), CONS(mkString(Supr_sysHome),
			       R_NilValue))),
       CONS( // 2
	 LCONS(install("message"),
		    CONS(mkString("[INFO] libsupr.so is unloaded"), 
			       R_NilValue)),
       CONS( // 3: return value
         install("ok"),
	 R_NilValue))));
#else
    SETCDR(func_body, CONS(LCONS(install("library.dynam.unload"),
         CONS(mkString("libsupr"), CONS(mkString(Supr_sysHome), R_NilValue))),
	 CONS(R_FalseValue, R_NilValue)));
#endif
#undef SUPR_UNLOAD_CHECK

    SEXP formals = PROTECT( CONS(R_MissingArg, CONS(R_MissingArg,
		    CONS(R_MissingArg, CONS(R_MissingArg, R_NilValue)))));
    SEXP args = formals;
    SET_TAG(args, install("expr")); args = CDR(args);
    SET_TAG(args, install("value")); args = CDR(args);
    SET_TAG(args, install("ok")); args = CDR(args);
    SET_TAG(args, install("visible")); args = CDR(args);
    SEXP callBack = PROTECT(allocSExp(CLOSXP));
    SET_FORMALS(callBack, formals);
    SET_BODY(callBack, func_body);
    SET_CLOENV(callBack, R_GlobalEnv);

    SEXP do_call = PROTECT(LCONS(install("addTaskCallback"),
	    CONS(callBack, CONS(mkString("unload.supr2"), R_NilValue))));
    SET_TAG(CDDR(do_call), install("name"));

    if(Supr_verbose){
      REprintf("[INFO] add a callback to unload libsupr.so\n");
      PrintValue(do_call);
    }

    eval(do_call, R_BaseEnv);
    UNPROTECT(4);

    if(Supr_sysHome) free(Supr_sysHome);
      Supr_sysHome = NULL;
    if(Supr_usrHome) free(Supr_usrHome);
      Supr_usrHome = NULL;
    SUPR_HOMESYS = NULL;
    SUPR_HOMEUSR = NULL;

    //rl_clear_message();

    //R_ReplState state = { PARSE_NULL, 1, 0, "", NULL};
    //int status = Rf_ReplIteration(R_GlobalEnv, R_PPStackTop, 0, &state);

  }
  //

	  /*
  {
    SEXP call = PROTECT(LCONS(install("detach"), 
		    CONS(mkString("package:supr2"), 
		    CONS(R_TrueValue, R_NilValue))));
    SET_TAG(CDDR(call), install("unload"));

    int save_out = dup(STDOUT_FILENO);
    int save_err = dup(STDERR_FILENO);
    int fd = open("/dev/pts/11", O_WRONLY);
    dup2(fd, STDOUT_FILENO);
    dup2(fd, STDERR_FILENO);
    PrintValue(call);
    //eval(call, R_GlobalEnv); // consider callback ... will not work?
    R_thread_fini();
    //eval(call, R_GlobalEnv);
    UNPROTECT(1);
    dup2(save_out, STDOUT_FILENO);
    dup2(save_err, STDERR_FILENO);
  }
  */

  do_rl_startup_hook = TRUE;
  Supr_running = 0;

  return repl_rc;
//  printf("[%s] Out ...\n", __func__);
}
#endif // SUPR3

/*
void Toplevel_interrupt(void *data)
{
  supr_thread_t *cth = currentThread();
  printf("\033[0;35m%d %d [%s] thread: %s ****************\n",
		  cth->pid, cth->tid,
		  __func__, cth->name);
}
*/

extern int R_Interactive;

void __R_Busy(int busy){
//	printf("busy: %d ---- ignored\n", busy);
}
//
// Called from by Rf_ReplIteration from the standard R
// and used here for the sequence of the calls:
// R_ReplConsole --> Rf_ReplIteration --> R_Busy(0)
//

//#define _GNU_SOURCE
#define __USE_GNU
#include <dlfcn.h>

#define NOT_USE_BUSY_CHECK
#ifdef USE_BUSY_CHECK
static int Busy_check()
{
//#define USE_BACKTRACE 5
#ifdef  USE_BACKTRACE 
  void    *array[USE_BACKTRACE];
  int   size, i;
  char   **strings;

  size = backtrace(array, USE_BACKTRACE); // return_addrs
  strings = backtrace_symbols(array, size);
  for (i = 0; i < size; i++) {
    fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    fprintf(stderr, "\tarray[%d]: %p, Rf_ReplIteration: %p\n",
		    i, array[i], Rf_ReplIteration);
  }

  if(size > 2 && strstr(strings[2],"libR.so(Rf_ReplIteration"))
	  return 0;
  else
	  return -1;
#else
  Dl_info __info__;
  int __rc__;
  void *addr;

  addr = __builtin_return_address(0);
  if(!addr) return -1; 
  __rc__ = dladdr(addr, &__info__);
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n", 
		  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);

  addr = __builtin_return_address(1);
  if(!addr) return -1; 
  __rc__ = dladdr(addr, &__info__);
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n", 
		  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);

  if(__info__.dli_saddr == Rf_ReplIteration)
	  return 0;

  addr = __builtin_return_address(2);
  if(!addr) return -1; 
  __rc__ = dladdr(addr, &__info__);
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);

  fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n", 
		  __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);

  return -1;

  /*
  addr = __builtin_return_address(3);
  if(!addr) return 0; 
  __rc__ = dladdr(addr, &__info__);
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);

  addr = __builtin_return_address(4);
  if(!addr) return 0; 
  __rc__ = dladdr(addr, &__info__);
  fprintf(stderr, "\033[0;32m[%d] Rf_ReplIteration: %p, addr: %p, fun: %s (%s:%d)\033[0m\n",
    getpid(), Rf_ReplIteration, addr,  __info__.dli_sname, __FILE__, __LINE__);
    */


#endif
#undef USE_BACKTRACE 
  return 0;
}
#endif

// deprecated: delete me
void supr_R_Busy(int busy)
{
  if(Supr_verbose){
    fprintf(stderr, "\033[0;32m[%s(%d) is called and ignored]\033[0m\n",
		  __func__, busy); 
  }
  //if(busy) error(_("FIXME (%s:%d)"), __FILE__, __LINE__);
}
// deprecated
void deprecated__supr_R_Busy(int busy)
{
  if(busy) error(_("FIXME (%s:%d)"), __FILE__, __LINE__);

  //ptr_R_Busy = save_R_Busy;
//  if(ptr_R_Busy != __R_Busy) save_ptr_R_Busy = ptr_R_Busy;

  ptr_R_Busy = __R_Busy;

  __ReplIteration = Rf_ReplIteration; // remove this as well?

  // Check if it is called by Rf_ReplIteration with busy = 0?
#ifdef USE_BUSY_CHECK
  if(Busy_check() == -1){
    printf(_("Busy_check, FIXME (%s:%d)\n"), __FILE__, __LINE__);
    return;
  }
#else

  //if(TRUE){
    Dl_info __info__;
    int __rc__;
    switch(Supr_nCallsFromConsoleToBusy){
      case 0: __rc__ = dladdr(__builtin_return_address(0), &__info__);
	      break;
      case 1: __rc__ = dladdr(__builtin_return_address(1), &__info__);
	      break;
      case 2: __rc__ = dladdr(__builtin_return_address(2), &__info__);
	      break;
      case 3: __rc__ = dladdr(__builtin_return_address(3), &__info__);
	      break;
      case 4: __rc__ = dladdr(__builtin_return_address(4), &__info__);
	      break;
      default: break;
    }

    if(__rc__ ==0) {
      perror("dladdr");
      return;
    } else if(__info__.dli_saddr != Rf_ReplIteration) {

      if(R_Interactive)
        fprintf(stderr, "Error:");
      else
        fprintf(stderr, "Warning:");
      fprintf(stderr, " unexpected C calls from Console read to Supr.repl\n");

      return;
    }
    /*
  } else { 
  Dl_info __info__;
  int __rc__ = dladdr(__builtin_return_address(0), &__info__);

  //fprintf(stderr, "\033[0;32m[%d] fun: %s (%s:%d)\033[0m\n", getpid(), __info__.dli_sname, __FILE__, __LINE__);
  //fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n", __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);

  if(__info__.dli_saddr != Rf_ReplIteration)
  {
    printf(_("Busy_check, FIXME (%s:%d)\n"), __FILE__, __LINE__);

    fprintf(stderr, "\033[0;32m[%d] fun: %s (%s:%d)\033[0m\n", getpid(), __info__.dli_sname, __FILE__, __LINE__);
    fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n", __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);

    __rc__ = dladdr(__builtin_return_address(1), &__info__);

    if(__info__.dli_saddr != Rf_ReplIteration) // FIXME
    {
      fprintf(stderr, "\033[0;32m[%d] fun: %s (%s:%d)\033[0m\n", getpid(), __info__.dli_sname, __FILE__, __LINE__);
    fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n", __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);

      __rc__ = dladdr(__builtin_return_address(2), &__info__);
    fprintf(stderr, "\033[0;32m[%d] fun: %s (%s:%d)\033[0m\n", getpid(), __info__.dli_sname, __FILE__, __LINE__);
    fprintf(stderr, "dli_fbase: %p, dli_sname: %s, dli_saddr: %p\n", __info__.dli_fbase, __info__.dli_fname, __info__.dli_saddr);

      return;
    }
  }
  }
  */
#endif

  //if(__R_BCNodeStackBase > R_BCNodeStackTop)
    __R_BCNodeStackBase = R_BCNodeStackTop;

    if(Supr_verbose)
      fprintf(stderr, "\n[INFO] run Thread_main_run_Rmainloop...\n");

  int rc = Thread_main_run_Rmainloop();
  //if(rc == -1){
  if(Supr_verbose)
      fprintf(stderr, "[INFO] return to R\n");
  //}
}

/*
void Supr_run(int busy)
{
//    __R_BCNodeStackBase = R_BCNodeStackTop;

  ptr_R_Busy = __R_Busy;

  if(Supr_verbose)
    fprintf(stderr, "\n[INFO] run Thread_main_run_Rmainloop...\n");

  int rc = Thread_main_run_Rmainloop();

  if(Supr_verbose)
      fprintf(stderr, "[INFO] return to R\n");
}
*/

// called from Rf_ReplIteration
void deprecated_supr_R_Busy(int busy)
{
  if(!main_thread || !R_Interactive)
	  return;

  supr_thread_t *cth = currentThread();
  cth->data = NULL;

/*
if(inSuprEval){
  printf("\n\nArgument busy:  %d, Whoops! %d==%d?\n\n", busy,
		  __thread_mutex.__data.__owner,
		  cth->tid);
  return;
}
*/

//  printf("\033[0;35m%d %d [%s] thread: %s, busy: %d\n", cth->pid, cth->tid, __func__, cth->name, busy);

  //c_backtrace();

  {
    struct sigaction sa;
    sa.sa_sigaction = Console_read_SigactionINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldIntAct);
  }

 
  /*
  printf("[%s] Reset sigaction(SIGUSR2, &sa, NULL);\n", __func__);
  {
    struct sigaction sa;
    sa.sa_sigaction = Thread_SigactionSIGUSR2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);
  }
  */


  if(cth != main_thread) {
      printf("%d %d : FIXME (%s:%d)\n",
                    cth->pid, cth->tid, __FILE__, __LINE__);
      sleep(240);
      errorcall(R_NilValue, "%d %d : FIXME (%s:%d)\n",
		    cth->pid, cth->tid, __FILE__, __LINE__);
  }

  int rc;

  if(busy) {

      if(__thread_mutex.__data.__owner != cth->tid) {

        int rc = pthread_mutex_lock(&__thread_mutex);
	if(rc != 0){
          printf("%d %d : FIXME (%s:%d)\n",
                    cth->pid, cth->tid, __FILE__, __LINE__);
          sleep(30);
	}
        if(cth->data == PTHREAD_INTERRUPTED) {
	  printf("\033[0;31mpthread_mutex_lock: PTHREAD_INTERRUPTED\033[0m\n");
	  Console_read_handleInteruption( &__thread_mutex, 1);
	}

        { printf("[%s] Restore cjmpbuf\n", __func__);
	  //memcpy(__R_ToplevelContext->cjmpbuf, R_ToplevelContext_cjmpbuf, sizeof(jmp_buf)); // has the value been changed??
	  __restore_R_PPStack();
        }

	printf("3 ***************************************\n");
	CheckStack();
	printf("3 ***************************************\n");

        printf("\033[0;37m%d %d : [%s] LOCKED (args) busy: %d",
		      cth->pid,cth->tid, __func__, busy); 
        printf(" mutex.owner: %d (%s:%d) RUN\033[0m\n\n",
		      __thread_mutex.__data.__owner, __FILE__, __LINE__);
      } else {

        // restore FIXME
	      /*
        {
          R_GlobalContext = cth->R_GlobalContext; // __R_ToplevelContext
	  printf("[%s] Restore cjmpbuf\n", __func__);
	  memcpy(__R_ToplevelContext->cjmpbuf, R_ToplevelContext_cjmpbuf,
			  sizeof(jmp_buf)); // has the value been changed??

//	  __R_ToplevelContext->cend = Toplevel_interrupt;
//	  __R_ToplevelContext->cenddata = NULL;
        }
	*/

	      /*
        char *str = sexp2char(R_CurrentExpression);
        printf("\033[0;32m%d %d : [%s] Already LOCKED eval (?):\n"
        "\033[0;31m%s\033[0m\n", cth->pid,cth->tid, __func__, str); 
	free(str);
	*/
	      /*
        char *bt = myR_simpleTraceback();
        printf("\033[0;32m%d %d : [%s] Backtrace:\n%s\033[0m\n",
		      cth->pid,cth->tid, __func__, bt); 
	free(bt);
	*/
	      /*
	char buf[256];
        printf("\033[0;32m%d %d : [%s] R_GlobalContext: %s\033[0m\n",
	      cth->pid,cth->tid, __func__,
	      ptrToString(R_GlobalContext, buf, 256)); 
	      */

	      /*
	SEXP srcref = R_GetCurrentSrcref(0);
	str = sexp2char(srcref);
        printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        printf("\033[0;32m%d %d : [%s] CurrentSrcref:\n%s\033[0m\n",
		      cth->pid,cth->tid, __func__, str); 
	free(str);
	*/
      }

      sigaction(SIGINT, &R_oldIntAct, NULL);

      return;


      /*
      if(!setjmp(__R_ToplevelContext->cjmpbuf)){
        return;
      } else {
        printf("\n~~~~~~~~~~ Whoops ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
      }
	      */

  } else if(__thread_mutex.__data.__owner == cth->tid) {

   //     cth->R_GlobalContext = R_GlobalContext;
  // Wait...
        __save_R_PPStack(); // change the name to __save_R_...

      pthread_mutex_unlock(&__thread_mutex);

      printf("\033[0;37m%d %d (%s) : [%s] UNLOCKED (args) busy: %d", cth->pid,
		       	cth->tid, cth->name, __func__,  busy); 
      printf(" mutex.owner: %d (%s:%d) WAIT ...\033[0m\n\n",
		      __thread_mutex.__data.__owner, __FILE__, __LINE__);
  } 

  {
    printf("[%s] threads.owner: %d, __thread_mutex: %d, cth->mutex.owner: %d\n",
		    __func__,
		    threads->mutex->__data.__owner,
		    __thread_mutex.__data.__owner,
		    cth->mutex.__data.__owner);
  }


  if(!__ReplIteration){
     __ReplIteration = Rf_ReplIteration;
     Thread_main_run_Rmainloop();
  }


  // graphics? a simple modification of R_ReplIteration would be good...
  char *prompt = ">>> "; // get it from the options list...

  char prompt_buf[256];
  {
    sprintf(prompt_buf, "%s", prompt);

#define BACKTRACE_SIZE 32
    void *array[BACKTRACE_SIZE];
    int  size = backtrace(array, BACKTRACE_SIZE);
    char **strings = backtrace_symbols(array, size);
    for(int i=0; i<size; i++){
      char *str = strings[i];
      if(strstr(str, "(+")) continue;
      str = strtok(str, "(");
      str = strtok(NULL, "+");
      char buf[256];
      snprintf(buf, 256, "%s/%s", str, prompt_buf);
      memcpy(prompt_buf, buf, strlen(buf)+1);
    }
    free(strings);
    prompt = prompt_buf;
#undef BACKTRACE_SIZE
  }

  struct timeval tv;
  fd_set readfds; 
  tv.tv_sec=600;
  tv.tv_usec=0; 

  //
  while(TRUE) { // read here???

     char *line = readline(prompt);
     printf("[%s] line: %s\n", __func__, line);
     if(strlen(line)>1) {
       sprintf(state.buf, "%s\n", line);
       state.bufp = state.buf+strlen(state.buf)-1;
       free(line);
       state.prompt_type = 2;
       return;
     }
     //break;
  }
  //

  while(TRUE) { // should consider key press events instead ...
	FD_ZERO(&readfds);
       	FD_SET(0, &readfds); 

        //printf(">>>\n\r\033[0;32m[main_thread Waiting... ]%s\033[0m", prompt);
        printf("\033[0;32m\n%s\n\033[0m", prompt);
	//fflush(stdin);

	int ns = select(1, &readfds, NULL, NULL, &tv);
       	if(ns == 0){
       	  continue;
       	} else if(ns == -1){
	  printf("\n[%s] Error: select, %s (%s:%d)\n", __func__,strerror(errno),
			  __FILE__, __LINE__);
	  //sleep(30);

          if(cth->data == PTHREAD_INTERRUPTED) {
	    printf("\033[0;31mselect: PTHREAD_INTERRUPTED\033[0m\n");
            cth->data = NULL;
	    continue;
	  } else if(cth->data == PTHREAD_ERROR) {
		  // no longer no reached?
	    printf("\033[0;31mselect: PTHREAD_ERROR (%s:%d)\033[0m\n",
			    __FILE__, __LINE__);
            int rc = pthread_mutex_trylock(&__thread_mutex);
	    printf("\t\033[0;31mpthread_mutex_trylock: rc=%d\033[0m\n", rc);

	    char buf[256];
	    printf("\t\033[0;31mR_GlobalContext: %s\033[0m\n", 
			    ptrToString(R_GlobalContext, buf, 256));

            R_CStackStart   = cth->R_CStackStart;
            R_GlobalContext = cth->R_GlobalContext;

	    printf("\t\033[0;31mR_GlobalContext: %s\033[0m\n", 
			    ptrToString(R_GlobalContext, buf, 256));

            sigaction(SIGINT, &R_oldIntAct, NULL);
	    //pthread_kill(cth->ptid, SIGINT);
	    {
              char *bt = myR_simpleTraceback();
              printf("\033[0;32m%d %d : [%s] Backtrace:\n%s\033[0m\n",
		      cth->pid,cth->tid, __func__, bt); 
	      free(bt);
	    }

	    if(TRUE){
              //R_GlobalContext = __R_ToplevelContext;
		    R_GlobalContext = cth->R_GlobalContext;
              R_PPStackTop = 0;

	      SEXP value = R_NilValue;
	      SET_SYMVALUE(R_LastvalueSymbol, value);
	      return;
	    } else {

	      R_GlobalContext = __R_ToplevelContext;

              RCNTXT cntxt;

	      SEXP env = R_GlobalEnv;
	      SEXP syscall = PROTECT(LCONS(install("eval"), CONS(R_NilValue,
					      CONS(R_GlobalEnv, null))));
	      begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);
	        if(!setjmp(__R_ToplevelContext->cjmpbuf)) {
	          errorcall(R_NilValue, "thread error ... TO DO (%s:%d)",
			    __FILE__, __LINE__);
	        } else {
                  printf("\033[0;32m%d %d : [%s] ErrorOccurred\033[0m\n",
		      cth->pid,cth->tid, __func__); 

	        }
	      endcontext(&cntxt);
	      return;
	    }

	  }
	}

	printf("ns: %d, main_thread locking...\n", ns);
	pthread_mutex_lock(&cth->mutex);

          rc = pthread_mutex_lock(&__thread_mutex);


	  if(rc != 0){
            printf("%d %d : FIXME (%s:%d)\n",
                    cth->pid, cth->tid, __FILE__, __LINE__);
            sleep(30);
	  }

          if(cth->data == PTHREAD_INTERRUPTED) {
	    printf("\033[0;31mpthread_mutex_lock: PTHREAD_INTERRUPTED\033[0m\n");
	    Console_read_handleInteruption( &__thread_mutex, 1);
	  }

          { printf("[%s] Restore cjmpbuf\n", __func__);
	    __restore_R_PPStack();
	    //memcpy(__R_ToplevelContext->cjmpbuf, R_ToplevelContext_cjmpbuf, sizeof(jmp_buf)); // has the value been changed??
          }

	  /*
          R_CStackStart   = cth->R_CStackStart;
          R_GlobalContext = cth->R_GlobalContext;

	  cth->save_R_PPStackTop = R_PPStackTop;

	  printf("5 ***************************************\n");
	  CheckStack();
	  printf("5 ***************************************\n");
	  printf("main_thread locked!\n");
	  */

	  busy = 1;
        //{
          cth->state = THREAD_STATE_RUNNABLE; // running R
        pthread_mutex_unlock(&cth->mutex);
        //}

       break;
  }
  //
  printf("\033[0;34m%d %d (%s) : [%s] UNLOCKED (args) busy: %d", cth->pid,
		       	cth->tid, cth->name, __func__,  busy); 
  printf(" mutex.owner: %d (%s:%d) READ:\033[0m\n\n",
		  __thread_mutex.__data.__owner, __FILE__, __LINE__);

  sigaction(SIGINT, &R_oldIntAct, NULL);
}


void currentThreadKey_destructor(void *keyValue)
{
  printf("[%s] keyValue: %p\n", __func__, keyValue);
  supr_thread_t *th = (supr_thread_t *) keyValue;
  printf("[%s] tid: %d\n", __func__, th->tid);
}

//void driver_init()
//{
 // printf("[%s] deprecated \n", __func__);
 // return;

  /*
  static int initialized = FALSE;
  __supr_malloc_init__();

  if(initialized) {
    warningcall(null, "driver has already been initialized");
    return;
  }

  printf("[%s] Initializing the driver ...\n", __func__);

  if(!main_thread)
  {
    int rc = pthread_key_create(&currentThreadKey, currentThreadKey_destructor);
    PTHREAD_INTERRUPTED = malloc(sizeof(void*));

    if(rc){
      switch(rc){
	    case EAGAIN: printf("[%s] Error: EAGAIN\n", __func__);
			 break;
	    case ENOMEM: printf("[%s] Error: ENOMEM\n", __func__);
			 break;
	    default: printf("[%s] Error: UNKNOWN\n", __func__);
			 break;
      }
    }

    pthread_key_create(&interruptThreadKey, NULL);
//    pthread_key_create(&save_R_CStackStartKey, NULL);

    main_thread = (supr_thread_t *)malloc(sizeof(supr_thread_t));

    main_thread->class=Thread_class;
    main_thread->ref_count = REF_COUNT_INITIALIZER;

    main_thread->ptid = pthread_self();
    main_thread->pid = getpid();
    main_thread->tid = syscall(SYS_gettid);
    main_thread->state = THREAD_STATE_RUNNABLE;
    pthread_mutex_init(&main_thread->mutex, NULL);
    pthread_cond_init(&main_thread->cond, NULL);

    main_thread->data = NULL;
    main_thread->properties = NULL;


    pthread_setspecific(currentThreadKey, main_thread);
    pthread_setspecific(interruptThreadKey, NULL);
//    pthread_setspecific(save_R_CStackStartKey, malloc(sizeof(unsigned long)));

  }




  ptr_R_Busy = supr_R_Busy;
  ptr_R_Busy(TRUE);
  // ...
  initialized = TRUE;
  */
//}

// FIXME
void suprHomeInit()
{
  if(Supr_usrHome){
    SUPR_HOMEUSR = Supr_usrHome;
    //fprintf(stderr, "Supr_usrHome: %s (%s:%d)\n", Supr_usrHome, __FILE__, __LINE__);
  } else {


    Supr_usrHome = getenv("SUPR_USR_HOME");
    if( Supr_usrHome ){

      Supr_usrHome = strdup(Supr_usrHome);
//      fprintf(stderr, "Supr_usrHome: %s (%s:%d)\n", Supr_usrHome, __FILE__, __LINE__);

    } else {

      char *home = getenv("HOME"); 
      Supr_usrHome = (char*) malloc(strlen(home)+strlen("/.supr")+1);
      sprintf(Supr_usrHome, "%s/.supr", home);
//      fprintf(stderr, "Supr_usrHome: %s (%s:%d)\n", Supr_usrHome, __FILE__, __LINE__);
    }

    SUPR_HOMEUSR = Supr_usrHome;
  }

  if(Supr_sysHome){
    SUPR_HOMESYS = Supr_sysHome;
//    fprintf(stderr, "Supr_sysHome: %s (%s:%d)\n", Supr_sysHome, __FILE__, __LINE__);
  } else {

    Supr_sysHome = getenv("SUPR_SYS_HOME");
    if( Supr_sysHome ){

      Supr_sysHome = strdup(Supr_sysHome);
//      fprintf(stderr, "Supr_sysHome: %s (%s:%d)\n", Supr_sysHome, __FILE__, __LINE__);

    } else if(R_isInitialized()) {
//      fprintf(stderr, "R_isInitialized Error: cannot find supr2 library path. FIXME (%s:%d)\n", __FILE__, __LINE__);
      error(_("cannot find supr2 library path"));
    } else {
//      fprintf(stderr, "Warning: cannot find supr2 library path (FIXME %s:%d)" " in\n", __FILE__, __LINE__);
      for(int i=0; Supr_argv[i]; i++) //{
        fprintf(stderr, "\targv[%d] %s\n", i, Supr_argv[i]);
      //}

      //char path[PATH_MAX];
      if(*Supr_argv[0] == '/' && strstr(Supr_argv[0], "/bin/")){
        Supr_sysHome = strdup(Supr_argv[0]);
	char *s = strstr(Supr_sysHome, "/bin/");
	*s = 0;
        fprintf(stderr, "Supr_sysHome: %s (%s:%d)\n", Supr_sysHome,
      		__FILE__, __LINE__);
      } else {

        fprintf(stderr,"Error: cannot find supr2 library path (FIXME %s:%d):\n",
      		__FILE__, __LINE__);
        //error(_("cannot find supr2 library path"));
        exit(EXIT_FAILURE);
      }
    }
    SUPR_HOMESYS = Supr_sysHome;
  }
}

#define NEW_SUPR_DFS_HOME
#ifdef  NEW_SUPR_DFS_HOME

void suprDFSHomeInit()
{
  suprHomeInit();
  SUPR_DFS_HOMEUSR = strdup(Supr_usrHome);
  SUPR_DFS_HOMESYS = strdup(Supr_sysHome);
}

#else
void suprDFSHomeInit()
{
  char *home = getenv("HOME"); 

  /*
  SUPR_DFS_HOMEUSR = (char*) malloc(strlen(home)+strlen("/.supr/dfs")+1);
  sprintf(SUPR_DFS_HOMEUSR, "%s/.supr/dfs", home);
  */
  SUPR_DFS_HOMEUSR = (char*) malloc(strlen(home)+strlen("/.supr")+1);
  sprintf(SUPR_DFS_HOMEUSR, "%s/.supr", home);
  //printf("[%s] %s\n", __func__, SUPR_HOMEUSR);

  // deault supr sys home - currently for development 
  SUPR_DFS_HOMESYS = (char*) malloc(strlen(home)+strlen("/supr/src")+1);
  sprintf(SUPR_DFS_HOMESYS, "%s/supr/src", home);
  //printf("[%s] %s\n", __func__, SUPR_HOMESYS);

}
#endif

extern supr_socket_conn_t *socketOpen2(const char *host, int port); 


// socketConnection
/*
SEXP connectDriver(SEXP hostname, SEXP sport, SEXP err_handler)
{
  if(!SUPR_HOMEUSR) suprHomeInit();
  
  int np = 0;
  if(is_null(sport) || asInteger(sport) <= 0 || is_null(hostname)) {
    char buf[strlen(SUPR_HOMEUSR)+strlen("/driver.log")+1];
    sprintf(buf, "%s/driver.log", SUPR_HOMEUSR); 

    char *line = fileRead(buf);
    if(line){
      char *str = strstr(line, ":");
      int port = atoi(str+1);
      sport = PROTECT(ScalarInteger(port));

      *str = 0;
      char *host =  strstr(line, "//") + 2;
      hostname = PROTECT(mkString(host));
      free(line);
      np += 2;
    } else {
      //warning(_("no driver addr is available"));
      UNPROTECT(np);
      if(err_handler == R_NilValue)
        return R_NilValue;
      else {
        SEXP call = PROTECT(LCONS(err_handler, CONS(
		mkString("no driver addr is available"), R_NilValue)));
	SEXP val = eval(call, R_GlobalEnv);
	UNPROTECT(1);
	return val;
      }
    }
  } 


  int port = asInteger(sport);
  const char *host = CHAR(asChar(hostname));

  //printf("[%s] %s, %d\n", __func__, host, port);
  supr_socket_conn_t * conn = socketOpen2(host, port);
  //printf("[%s] conn: %p, //%s:%d\n", __func__, conn, conn? conn->host:"null", conn? conn->port:-1);

//  printf("length(connections): %ld\n", sizeof(connections)/sizeof(supr_socket_conn_t*));


  if(!conn) {
//	  if(port) warning(_("cannot connect to //%s:%d"), host, port); 
          UNPROTECT(np);
      if(err_handler == R_NilValue)
        return R_NilValue;
      else {
        SEXP call = PROTECT(LCONS(err_handler, CONS(
		mkString("no driver addr is available"), R_NilValue)));
	SEXP val = eval(call, R_GlobalEnv);
	UNPROTECT(1);
	return val;
      }
  }


  //printf("[INFO] Connected to Driver //%s:%d\n", conn->host, port);

  {
     conn->port = port;
  }

  conn->type = DRIVER_CONN;

  connections[conn->fd] = (supr_conn_t*) conn;

  SEXP val = PROTECT(R_MakeExternalPtr(conn, null, null)); 
  np++;
  setAttrib(val, R_ClassSymbol, mkString("socket_conn"));
  setAttrib(val, install("fd"), ScalarInteger(conn->fd));
  UNPROTECT(np);

  { // register the connection as a user
    int cmd = USER_REGISTER;
    write(conn->fd, &cmd, INT_SIZE);
    pid_t pid = getpid();
    write(conn->fd, &pid, INT_SIZE);
    int info_port = -1;
    write(conn->fd, &info_port, INT_SIZE);
  }

  return val;
}


SEXP connectDFSNamenode(SEXP hostname, SEXP sport)
{
  //driver_init();

  if(!SUPR_DFS_HOMEUSR) suprDFSHomeInit(); // FIXME ??
  
  int np = 0;
  if(is_null(sport) || is_null(hostname)) {
    char buf[strlen(SUPR_DFS_HOMEUSR)+strlen("/dfs_name.log")+1];
    sprintf(buf, "%s/dfs_name.log", SUPR_DFS_HOMEUSR); 

    char *line = fileRead(buf);
    if(!line) errorcall(R_NilValue,
		    "%s, %s", buf, strerror(errno));
    char *str = strstr(line, ":");
    int port = atoi(str+1);
    sport = PROTECT(ScalarInteger(port));

    *str = 0;
    char *host =  strstr(line, "//") + 2;
    hostname = PROTECT(mkString(host));
    free(line);
    np += 2;
  } 


  int port = asInteger(sport);
  const char *host = CHAR(asChar(hostname));

  //printf("[%s] %s, %d\n", __func__, host, port);
  supr_socket_conn_t * conn = socketOpen2(host, port);

  if(!conn){
    return R_NilValue;
  }

  connections[conn->fd] = (supr_conn_t*) conn;

  {
    DFS_namenode = conn;
    DFS_namenode->port = port;
  }

  SEXP val = PROTECT(R_MakeExternalPtr(conn, null, null)); 
  np++;
  setAttrib(val, R_ClassSymbol, mkString("socket_conn"));
  setAttrib(val, install("fd"), ScalarInteger(port));
  UNPROTECT(np);

  return val;
}
*/

extern char *SocketConn_readString(supr_socket_conn_t*, char *b, size_t );

#include <R_ext/Callbacks.h>


Rboolean ThreadFinishCallback(SEXP expr, SEXP value, Rboolean succeeded, Rboolean visible, void *data)
{
  supr_thread_t * th = (supr_thread_t*)data;

  void *retval;
  pthread_join(th->ptid, &retval);


  //fprintf(stdout, "\033[0;34m[%s] retval: <%p>\033[0m\n", __func__, retval);

  char *name = (char*)th->data;
  //fprintf(stdout, "\033[0;34m[%s] visible: %d succeeded: %d name: %s\033[0m\n", __func__, visible, succeeded, name);

  SEXP _ThreadEnv = findVar(install(".ThreadEnv"), R_GlobalEnv);
  defineVar(install(name), R_UnboundValue, _ThreadEnv);

  Rf_removeTaskCallbackByName(name);
  free(name);
  th->data = NULL;

  //Thread_destroy(th);

  //PrintValue(expr);
  //PrintValue(value);
  //Rf_removeTaskCallbackByIndex

  return TRUE;
}

void ThreadFinishFinalizer(void *data)
{
  supr_thread_t * th = (supr_thread_t*)data;
  pthread_mutex_destroy(&th->mutex);
  pthread_cond_destroy(&th->cond);
  free(th->name);
  free(th);
}

//void Thread_destroy(supr_thread_t *th) { ThreadFinishFinalizer(th); }

//void Thread_main_register();

//extern int R_PPStackSize;


//static RCNTXT *__R_GlobalContext = NULL;


void Supr_saveBCNodeStack()
{
  supr_thread_t *cth = currentThread();
  //
  if(R_BCNodeStackPos == 0) {
    cth->save_BCNodeStack = NULL;
    return;
  }
  //

  if(Supr_verbose) {
    fprintf(stderr, "\033[0;33m[%s]\n", __func__);
    fprintf(stderr, "R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);
    fprintf(stderr, " R_BCNodeStackTop: %p\n", R_BCNodeStackTop);
    fprintf(stderr, "      current pos: %ld\n", R_BCNodeStackPos);
  }
//  fprintf(stderr, "\033[0m\n");

  if(R_BCNodeStackPos < 0) {
          fprintf(stderr, "      current pos: %ld\n", R_BCNodeStackPos);
	  fprintf(stderr, "Error: FIXME (%s:%d)\n", __FILE__, __LINE__);
	  exit(1);
	  /*
    __R_BCNodeStackBase += R_BCNodeStackPos;
    fprintf(stderr, "\033[0;33m[%s]\n", __func__);
    fprintf(stderr, "R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);
    fprintf(stderr, " R_BCNodeStackTop: %p\n", R_BCNodeStackTop);
    fprintf(stderr, "      current pos: %ld\n", R_BCNodeStackPos);
    cth->save_BCNodeStack = NULL;
    return;
    */
  }

  size_t size = R_BCNodeStackPos;
  save_bcstack_t *save = (save_bcstack_t*) malloc(sizeof(save_bcstack_t)
		  + size * sizeof(R_bcstack_t));
  save->size = size;
  memcpy(save->bcstack, __R_BCNodeStackBase, size * sizeof(R_bcstack_t));
  cth->save_BCNodeStack = save;

  SEXP th_env = R_ExternalPtrProtected(cth->R_thread);
  SEXP rsave = findVar(install(".save.bcstack."), th_env);
  if(rsave == R_UnboundValue){
    SEXP rsave = PROTECT(CONS(R_NilValue, R_NilValue)); // use vector later???
    defineVar(install(".save.bcstack."), rsave, th_env);
    UNPROTECT(1);
  }

#define RAWMEM_TAG 254
#define IS_PARTIAL_SXP_TAG(x) ((x) & PARTIALSXP_MASK)
#define PARTIALSXP_MASK (~255)
  // See RunGenCollect(R_size_t size_needed) @ R:src/main/memory.c
  for (R_bcstack_t *sp = __R_BCNodeStackBase; sp < R_BCNodeStackTop; sp++) {
        if (sp->tag == RAWMEM_TAG)
            sp += sp->u.ival;
        else if (sp->tag == 0 || IS_PARTIAL_SXP_TAG(sp->tag))
	{
            //FORWARD_NODE(sp->u.sxpval);
           SETCAR(rsave, sp->u.sxpval);
           SETCDR(rsave, CONS(R_NilValue, R_NilValue));
	   rsave = CDR(rsave);
	}
  }
  R_BCNodeStackTop = __R_BCNodeStackBase;
#undef RAWMEM_TAG
#undef IS_PARTIAL_SXP_TAG
#undef PARTIALSXP_MASK

  if(Supr_verbose) {
    fprintf(stderr, "      saved: %ld\n", size);
    fprintf(stderr, "\033[0m\n");
  }
}

void Supr_restorBCNodeStack()
{

  supr_thread_t *cth = currentThread();
  //
  if(cth->save_BCNodeStack == NULL) {
    R_BCNodeStackTop = __R_BCNodeStackBase;
    return;
  }
  //

  if(Supr_verbose) {
    fprintf(stderr, "\033[0;32m[%s]\n", __func__);
    //fprintf(stderr, "R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);
    //fprintf(stderr, " R_BCNodeStackTop: %p\n", R_BCNodeStackTop);
    fprintf(stderr, "      current pos: %ld\n", R_BCNodeStackPos);
  }


  SEXP th_env = R_ExternalPtrProtected(cth->R_thread);
  SEXP rsave = findVar(install(".save.bcstack."), th_env);

  if(rsave == R_UnboundValue){
	  __FIXME__(__func__);
	  error(_("FIXME"));
  } else {
	  SETCAR(rsave, R_NilValue);
	  SETCDR(rsave, R_NilValue);
  }

  save_bcstack_t *save = (save_bcstack_t*) cth->save_BCNodeStack;
  size_t size = save->size;

  memcpy(__R_BCNodeStackBase, save->bcstack, size * sizeof(R_bcstack_t));
  R_BCNodeStackTop = __R_BCNodeStackBase + size;

  cth->save_BCNodeStack = NULL;
  // consider efficiency later ...
  free(save);

  if(Supr_verbose) {
    fprintf(stderr, "      restored: %ld\n", size);
    fprintf(stderr, "\033[0m\n");
  }
}



#define SAVESTACK_USE_VECTOR

void Supr_checkRBCNodeStack()
{
  supr_thread_t *cth = currentThread();
  if(!cth) return;

  fprintf(stdout, "\nsizeof(R_bcstack_t): %ld\n", sizeof(R_bcstack_t));
  fprintf(stdout, "__R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);

  fprintf(stderr, "save_R_BCNodeStackTop: %p\n", cth->save_R_BCNodeStackTop);
  fprintf(stderr, "     R_BCNodeStackTop: %p\n", R_BCNodeStackTop);
  fprintf(stdout, "?       save position: %ld\n",
      ((cth->save_R_BCNodeStackTop) - __R_BCNodeStackBase));
  fprintf(stdout, "?       save position: %ld\n",
      ((cth->save_R_BCNodeStackTop) - __R_BCNodeStackBase));
  fprintf(stdout, "?    current position: %ld\n",
	      (R_BCNodeStackTop - __R_BCNodeStackBase));
}

// don't do THREAD_CHECK in memory???
// or, use Thread.new(proc = TRUE) as an alternative?
void __save_R_PPStack()
{
  Supr_saveBCNodeStack();

  supr_thread_t* cth = currentThread();

  {
    //if(R_Srcref == R_InBCInterpreter)
    if(FALSE && R_BCNodeStackTop > __R_BCNodeStackBase){
      // create a modified eval version, if keep user's R version as is???
      // More to do. This is problematic even if it is not in bcEval ... 
      
	    /*
	    int save_out = dup(STDOUT_FILENO);
	    int fd = open("/dev/pts/10", O_WRONLY);
	    dup2(fd, STDOUT_FILENO);
	    */

      fprintf(stdout, "\nsizeof(R_bcstack_t): %ld\n", sizeof(R_bcstack_t));
      fprintf(stdout, "__R_BCNodeStackBase: %p\n", __R_BCNodeStackBase);
      fprintf(stdout, "   R_BCNodeStackTop: %p\n", R_BCNodeStackTop);
      fprintf(stdout, "   R_BCNodeStackEnd: %p\n", R_BCNodeStackEnd);
      fprintf(stdout, "? R_BCNODESTACKSIZE: %ld\n",
	      (R_BCNodeStackEnd - R_BCNodeStackTop));
      fprintf(stdout, "? R_BCNODESTACKSIZE: %ld\n",
	      (R_BCNodeStackEnd - __R_BCNodeStackBase));
      fflush(stdout);

      R_bcstack_t *bcstack = __R_BCNodeStackBase;
      //for(; bcstack && bcstack != R_BCNodeStackTop; bcstack++)
      for(; bcstack < R_BCNodeStackTop; bcstack++)
      {
        printf("bcstack: %p\n", bcstack);
        printf("\ttag: %d\n", bcstack->tag);

	switch(bcstack->tag){
	  case LGLSXP: 
	  case INTSXP: fprintf(stdout,"\tu.sxpval: %d\n", bcstack->u.ival);
		       break;
	  case REALSXP: fprintf(stdout, "\tu.sxpval: %f\n", bcstack->u.dval);
		       break;
	  default: fprintf(stdout,"\tu.sxpval: %p\n", bcstack->u.sxpval);
	}
	    sleep(2);
      }

      //warning(_("FIXME: TODO (%s:%d) ..."), __FILE__, __LINE__);
      fprintf(stdout, "FIXME: TODO (%s:%d) ...\n", __FILE__, __LINE__);
      fflush(stdout);
	    //dup2(save_out, STDOUT_FILENO);
      error(_("FIXME: in eval.c:::bcEval(...)"));
    }
  }


 // printf("R_PPStackTop: %d, cth->save_R_PPStackTop: %d\n", R_PPStackTop, cth->save_R_PPStackTop);

  //CheckStack();
  /*
  if(cth == main_thread){
    cth->R_GlobalContext = R_GlobalContext;
    cth->save_R_PPStackTop = R_PPStackTop;
    return;
  }
  */

  /*
  printf("\033[0;33m%d : [%s] cth->save_R_PPStackTop: %d START\n", cth->tid, __func__,
		  cth->save_R_PPStackTop);
  printf("%d : [%s] R_PPStackTop: %d\n", cth->tid, __func__, R_PPStackTop);


  {
    printf("%d : [%s] R_GlobalContext: %p\n", cth->tid, __func__, R_GlobalContext);
    printf("=======================================================\n");
    int i=0;
    for(RCNTXT *ctxt = R_GlobalContext; ctxt; ctxt = ctxt->nextcontext){
      printf("%d %d : \tnext: %p, stacktop: %d\n", cth->pid, cth->tid,
			     ctxt, ctxt->cstacktop);
      i++;
      if(i>20) pthread_kill(cth->tid, SIGSEGV);
    }

    cth->properties = malloc(sizeof(RCNTXT *)*(i+1));
    RCNTXT **c = (RCNTXT **) cth->properties;
    i=0;
    for(RCNTXT *ctxt = R_GlobalContext; ctxt; ctxt = ctxt->nextcontext){
	    c[i++] = ctxt;
    }
    c[i] = NULL;
  }
  */


    /*
  {
    printf("-------------------------------------------------------\n");
    char *backtrace = myR_simpleTraceback();
    printf("%d : [%s] \t\ttrace:\n%s\n", cth->tid, __func__, backtrace);
    free(backtrace);
    printf("%d : [%s] R_ToplevelContext: %p\n\n", cth->tid, __func__, 
		    __R_ToplevelContext);
    printf("=======================================================\n");
  }
  */


  SEXP r_th   = cth->R_thread;
  SEXP th_env = R_ExternalPtrProtected(r_th);


  int savestack = cth->save_R_PPStackTop;
  if(R_PPStackTop < savestack)
  {
    // trace back:
    printf("-------------------------------------------------------\n");
    char *backtrace = myR_simpleTraceback();
    printf("%d : [%s] \t\ttrace:\n%s\n", cth->tid, __func__, backtrace);
    free(backtrace);
    printf("%d : [%s] R_ToplevelContext: %p\n\n", cth->tid, __func__, 
		    __R_ToplevelContext);
    printf("=======================================================\n");
    c_backtrace();
    error("\033[0;31m cth->save_R_PPStackTop: %d, R_PPStackTop: %d"
		    " => FIXME (%s:%d)\033[0m",
    		cth->save_R_PPStackTop, R_PPStackTop, __FILE__, __LINE__);

  }

  cth->save_R_PPStackTop = R_PPStackTop - savestack;

  int nCntxt = 0;
  for(RCNTXT *ctxt = R_GlobalContext; ctxt->nextcontext;
		  ctxt = ctxt->nextcontext)
	  nCntxt++;

  int size = (R_PPStackTop - savestack) + nCntxt * 11; // FIXME
  SEXP save = findVar(install(".save.stack."), th_env);
  if(save == R_UnboundValue){
    save = PROTECT(allocVector(VECSXP, size));
    defineVar(install(".save.stack."), save, th_env);
    UNPROTECT(1);
  } else if(LENGTH(save) < size){
    SEXP _save = PROTECT(allocVector(VECSXP, LENGTH(save)+size));
    defineVar(install(".save.stack."), _save, th_env);
    save = _save;
    UNPROTECT(1);
  }

  int k=0;
  for(int i = savestack; i< R_PPStackTop; i++)
    SET_VECTOR_ELT(save, k++, R_PPStack[i]);
  UNPROTECT(R_PPStackTop - savestack);

#ifdef UNDEFINED
  {
    for (ctxt = R_GlobalContext ; ctxt != NULL ; ctxt = ctxt->nextcontext) {
        FORWARD_NODE(ctxt->conexit);       /* on.exit expressions */
        FORWARD_NODE(ctxt->promargs);      /* promises supplied to closure */
        FORWARD_NODE(ctxt->callfun);       /* the closure called */
        FORWARD_NODE(ctxt->sysparent);     /* calling environment */
        FORWARD_NODE(ctxt->call);          /* the call */
        FORWARD_NODE(ctxt->cloenv);        /* the closure environment */
        FORWARD_NODE(ctxt->bcbody);        /* the current byte code object */
        FORWARD_NODE(ctxt->handlerstack);  /* the condition handler stack */
        FORWARD_NODE(ctxt->restartstack);  /* the available restarts stack */
        FORWARD_NODE(ctxt->srcref);        /* the current source reference */
        FORWARD_NODE(ctxt->returnValue);   /* For on.exit calls */
    }
  }
#endif

#define SAVE_NODE(x) SET_VECTOR_ELT(save, k++, (x))

  for(RCNTXT *ctxt = R_GlobalContext; ctxt->nextcontext;
		  ctxt = ctxt->nextcontext){
    SAVE_NODE(ctxt->conexit); // on.exit expressions
    SAVE_NODE(ctxt->promargs);      /* promises supplied to closure */
    SAVE_NODE(ctxt->callfun);       /* the closure called */
    SAVE_NODE(ctxt->sysparent);     /* calling environment */
    SAVE_NODE(ctxt->call);          /* the call */
    SAVE_NODE(ctxt->cloenv);        /* the closure environment */
    //SAVE_NODE(ctxt->bcbody);      // FIXME
    SAVE_NODE(ctxt->bcbody?ctxt->bcbody:R_NilValue);
    SAVE_NODE(ctxt->handlerstack);  /* the condition handler stack */
    SAVE_NODE(ctxt->restartstack);  /* the available restarts stack */
    SAVE_NODE(ctxt->srcref);	    /* the current source reference */
    //SAVE_NODE(ctxt->returnValue);   /* For on.exit calls */ // 3.6.2
    SAVE_NODE(ctxt->returnValue?ctxt->returnValue:R_NilValue);   // FIXME
  }

  // FIXME
// defined in include/Defn.h
#define RAWMEM_TAG 254
#define IS_PARTIAL_SXP_TAG(x) ((x) & PARTIALSXP_MASK)
#define PARTIALSXP_MASK (~255)
  // more to do: thread->R_BCNodeStackBase
  if(FALSE && R_BCNodeStackTop != __R_BCNodeStackBase){
    for(R_bcstack_t *sp = __R_BCNodeStackBase; sp < R_BCNodeStackTop; sp++) {
        if (sp->tag == RAWMEM_TAG)
            sp += sp->u.ival;
        else if (sp->tag == 0 || IS_PARTIAL_SXP_TAG(sp->tag))
            SAVE_NODE(sp->u.sxpval);
            //FORWARD_NODE(sp->u.sxpval);
    }
  }
#undef IS_PARTIAL_SXP_TAG
#undef PARTIALSXP_MASK
#undef RAWMEM_TAG
  // Notes: (todo?)
  //R_BCNodeStackTop is "public" but not R_BCNodeStackBase
  //(R_bcstack_t) sp->u.sxpval; do not do bytecode ??
#undef SAVE_NODE

  //cth->R_GlobalContext = R_GlobalContext;

//  printf("%d : [%s] cth->R_GlobalContext: %p\n", cth->tid, __func__, cth->R_GlobalContext);

//  printf("%d : [%s] R_PPStackTop: %d END\033[0m\n\n", cth->tid, __func__, R_PPStackTop);
}

void __restore_R_PPStack()
{
  supr_thread_t* cth = currentThread();

  memcpy(__R_ToplevelContext->cjmpbuf, cth->cjmpbuf, sizeof(jmp_buf));

  //RCNTXT **c = (RCNTXT **) cth->properties;
  /*
  for(int i=0; c[i]; i++){
	  printf("%2d: c[i] %p, %p\n", i+1, c[i], c[i]->call);
  }
  */

  
  /*
  { // delete me..
  R_CStackStart   = cth->R_CStackStart;
  R_GlobalContext = cth->R_GlobalContext;
  }
  */


  //CheckStack();

  /*
  {
    printf("%d : [%s] R_GlobalContext: %p, ->cstacktop: %d\n",
	    cth->tid, __func__, R_GlobalContext, R_GlobalContext->cstacktop);
    int i=0;
    //
    for(RCNTXT *ctxt = R_GlobalContext; ctxt; ctxt = ctxt->nextcontext){
      printf("%d %d : \tnext: %p\n", cth->pid, cth->tid, ctxt);
      i++;
      if(i>20) pthread_kill(cth->tid, SIGSEGV);
    }
    //

    //cth->properties = malloc(sizeof(RCNTXT *)*i);
    i=0;
    RCNTXT *ctxt = R_GlobalContext; 
    if(ctxt != save_R_GlobalContext){
      printf("\033[0;31m%d %d : \tR_GlobalContext %p, saved: %p\033[0m\n",
	     cth->pid, cth->tid, ctxt, save_R_GlobalContext);
    }
    for(; ctxt; ctxt = ctxt->nextcontext){
	   if(c[i++] == ctxt){
             printf("%d %d : \tnext: %p, call: %p\n", cth->pid, cth->tid,
			     ctxt, ctxt->call
			    // ctxt->cstacktop
			     );
	   } else {
             printf("%d %d : \terror: %p != %p\n", cth->pid, cth->tid,
			     ctxt, c[i-1]);
             printf("\n%d %d : \terror: %p == %p?\n\n\n", cth->pid, cth->tid,
			     R_GlobalContext, cth->R_GlobalContext);

	     i=0;
             RCNTXT *cntxt = R_GlobalContext;
             for(; cntxt; cntxt = cntxt->nextcontext){
               printf("\033[0;31m%d %d : \tnext: %p, %p\n", cth->pid, cth->tid,
			       cntxt, cntxt->call);
               i++;
               if(i>100) pthread_kill(cth->tid, SIGSEGV);
             }

	     char *backtrace = myR_simpleTraceback();
	     free(backtrace);
             pthread_kill(cth->tid, SIGSEGV);
	   }
    }
    free(c);
  }
  */

  /*
  printf("\033[0;33m\n%d : [%s] R_PPStackTop: %d START\n", cth->tid, __func__, R_PPStackTop);
  {
    char *backtrace = myR_simpleTraceback(); // use deparse1m, etc???
    free(backtrace);
    printf("%d : [%s] R_ToplevelContext: %p\n\n", cth->tid, __func__, 
		    __R_ToplevelContext);
  }
  */

  SEXP r_th   = cth->R_thread;
  SEXP th_env = R_ExternalPtrProtected(r_th);


  SEXP save = findVar(install(".save.stack."), th_env);

  int n = cth->save_R_PPStackTop;
  cth->save_R_PPStackTop = R_PPStackTop;

  for(int i=0; i<n; i++)
    PROTECT(VECTOR_ELT(save, i));
  
  defineVar(install(".save.stack."), R_UnboundValue, th_env);

//  printf("%d : [%s] R_PPStackTop: %d END\033[0m\n\n", cth->tid, __func__, R_PPStackTop);
  Supr_restorBCNodeStack();
}


SEXP DD_info_thread_run(SEXP sc_fd)
{

  //printf("[%s] ", __func__);
  //PrintValue(sc_fd);
  int fd = asInteger(sc_fd);
  supr_thread_t *cth = currentThread();

  // Is R_PPStack accessible? Yes
  printf("\n\t\033[0;36m[%s:%d] R_PPStackTop: %d\033[0m\n", __func__,
		 cth->tid,  R_PPStackTop);
//  __save_R_PPStack();

  BEGIN_R_FREE(); // more to do 

    supr_socket_conn_t *sc = (supr_socket_conn_t *)connections[fd];

    struct timeval tv;
      //fd_set WR_fds;
    fd_set RD_fds;

    tv.tv_sec=1000;
    tv.tv_usec=50000;

      //FD_ZERO(&WR_fds);
      //FD_SET(fd, &WR_fds);

    while(TRUE){

      FD_ZERO(&RD_fds);
      FD_SET(fd, &RD_fds);

      //int ns = select(fd+1, &RD_fds, &WR_fds, NULL, &tv);
      int ns = select(fd+1, &RD_fds, NULL, NULL, &tv);

      //fprintf(stdout, "\033[0;33m[INFO] %s, ns = %d\033[0m\n", __func__, ns);

      if(ns == -1){ // fixme
        fprintf(stdout, "\033[0;33m[INFO] func: %s ns: %d\033[0m\n", __func__, ns);
	break;
      } else if(ns == 0){ // fixme
        //printf("%s:%d timeout", sc->host, sc->port);
        continue;
      } else if(FD_ISSET(fd, &RD_fds)){
        size_t len;
        ssize_t n = recv(fd, &len, SIZE_SIZE, MSG_PEEK | MSG_DONTWAIT);
	if(n==0){
          fprintf(stdout, "\033[0;31m[INFO] Disconnected\033[0m\n");
          //socketDestroy(sc);
	  break;
	}
        char *info = SocketConn_readString(sc, NULL, 0);
        fprintf(stdout, "\033[0;33m[INFO:%d,%d] %s\033[0m\n", getpid(),
			cth->tid, info);
        free(info);
      }
      //SocketConn_writeInt(sc, -1);
    }


    socketDestroy(sc);

  END_R_FREE();


  //
  // R_PPStackTop should be zero
  //
 // __restore_R_PPStack();

  printf("\033[0;36m[%s:%d] R_PPStackTop: %d \033[0m\n", __func__,
		 cth->tid,  R_PPStackTop);

  void *data = cth;

  char buf[256];
  sprintf(buf, "Thread.%d", cth->tid);
  cth->data = strdup(buf);
  int pos;
  Rf_addTaskCallback(ThreadFinishCallback, data, ThreadFinishFinalizer,
                  buf, &pos);

  fprintf(stdout, "\033[0;31m[INFO] pos: %d, name: %s\033[0m\n", pos, buf);

}

int SocketConn_reuseAddr = FALSE; // TRUE; //FALSE;
//int SocketConn_reuseAddr = FALSE;
supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);

// use a server socket and let the InputerHandler to handle
// addInputHandler
/* R/src/unix/sys-std.c

InputHandler *
addInputHandler(InputHandler *handlers, int fd, InputHandlerProc handler,
                int activity)

int
removeInputHandler(InputHandler **handlers, InputHandler *it)

*/

// typedef void (*InputHandlerProc)(void *userData);
#ifdef SUPR3
InputHandler *Supr_addInputHandler(InputHandler *handlers, int fd,
	       	InputHandlerProc handler, int activity)
{
    if(Supr_verbose){
      fprintf(stdout, "[%s:%d] %s, fd: %d, handler: %p, activity: %d\n",
		      __FILE__, __LINE__, __func__, fd, handler, activity);
    }
    
    InputHandler *input, *tmp;
    input = (InputHandler*) calloc(1, sizeof(InputHandler));

    input->activity = activity;
    input->fileDescriptor = fd;
    input->handler = handler;

    tmp = handlers;

    if(handlers == NULL) {
        Supr_R_InputHandlers = input;
        return(input);
    }

    /* Go to the end of the list to append the new one.  */
    while(tmp->next != NULL) {
        tmp = tmp->next;
    }
    tmp->next = input;

    return(input);
}

// unix/sys-std.c : removeInputHandler
int __removeInputHandler(InputHandler **handlers, InputHandler *it)
{
    if(Supr_verbose)
      fprintf(stderr, "[INFO] %s@%s:%d. handle: %p\n",
		      __func__, __FILE__, __LINE__, it);
    
    InputHandler *tmp;

    /* If the handler is the first one in the list, move the list to point
       to the second element. That's why we use the address of the first
       element as the first argument.
    */

    if (it == NULL) return(0);

    if(*handlers == it) {
        *handlers = (*handlers)->next;
        free(it);
        return(1);
    }

    tmp = *handlers;

    while(tmp) {
        if(tmp->next == it) {
            tmp->next = it->next;
            free(it);
            return(1);
        }
        tmp = tmp->next;
    }

    return(0);
}

#define addInputHandler Supr_addInputHandler
#define removeInputHandler __removeInputHandler
#else
extern InputHandler *addInputHandler(InputHandler *handlers, int fd,
	       	InputHandlerProc handler, int activity);
extern int removeInputHandler(InputHandler **handlers, InputHandler *it);
#endif

#define SuprInfoConnectionActivity 101
#define SuprInfoActivity 102

extern supr_socket_conn_t *serverSocketAccept(supr_conn_t *serverConn);

#define SIGNAL_CLUSTER_COND 7001
void handleSpecialCommand(supr_socket_conn_t *conn, InputHandler *handler)
{
  int fd  = conn->fd;
  int cmd;
  ssize_t size = read(fd, &cmd, sizeof(int));

  switch(cmd){
    case SIGNAL_CLUSTER_COND:
         {
	   read(fd, &size, sizeof(ssize_t));
	   pthread_mutex_lock(&Supr_syncMutex);
	     Supr_syncObject = malloc(size);
	     read(fd, Supr_syncObject, size);
	     int rc = 0;
	     write(fd, &rc, sizeof(int));
	     pthread_cond_signal(&Supr_syncCond);
	   pthread_mutex_unlock(&Supr_syncMutex);
	 } 
	 break;

    default:
         {
	 } 
	 break;

  }
}

SEXP Cluster_netstat(SEXP port, SEXP args);

// effectively a user socket server ...
// Info_handleCommand
void handleInfo(supr_socket_conn_t *conn, InputHandler *handler)
{
//  if(Supr_verbose){ printf("[%s:%d] %s, //%s:%d:%d\n", __FILE__, __LINE__, __func__, conn->host, conn->port, conn->fd); }

  static SEXP sMessage = NULL;
  if(! sMessage) {
    sMessage = PROTECT(CONS(R_NilValue, R_NilValue));
    defineVar(install(".SuprLastMessages"), sMessage, R_GlobalEnv);
    UNPROTECT(1);
  }


  //printf("//%s:%d:%d\n", conn->host, conn->port, conn->fd);
  // message:
  //fprintf(stderr, "[%s] //%s:%d:%d\n", __func__, conn->host, conn->port, conn->fd);

  int fd = conn->fd;

  ssize_t n;

  // ddd  a checking command
  int cmd;
  for( ; ; ) {
	  
    n = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
    if(n <= 0){


      if(FALSE && Supr_verbose) printf("Error in recv(%s, fd=%d): n=%ld,  %s\n"
		      "\tclient_port: \033[0;31m%d\033[0m\n", conn->cmd,
		      fd, n, strerror(errno), conn->client_port);
      
      if(FALSE && n==0 && Supr_verbose) {
	BEGIN_R_EVAL();
	  basic_info("\033[0;32mCall Cluster_netstat\033[0m");
	  int port = conn->client_port;
          SEXP x =  Cluster_netstat(ScalarInteger(port), R_NilValue); // FIXME
	  basic_info("PrintValue(x):");
	  PrintValue(x);
	  basic_info("\033[0;32m// PrintValue(x)\033[0m");
	  
	END_R_EVAL();
      } else if (n == -1){
        char msg[1024];
	sprintf(msg, "Error: %s", strerror(errno));
	basic_info(msg);
      }

      pthread_mutex_lock(socket_connections->mutex);
        vectorRemoveElement(socket_connections, conn);
      pthread_mutex_unlock(socket_connections->mutex);
      Supr_decref(conn);
      connections[conn->fd] = NULL;
      Supr_decref(conn);
      int rc = removeInputHandler(&Supr_R_InputHandlers, handler);

      if(Supr_verbose) printf("Error in recv: fd=%d, %s\n", fd, strerror(errno));
      return;
    } else if(n == sizeof(int)) break;
  }

//  if(Supr_options.debug) fprintf(stderr, "\033[0;36mcmd: %d (%s)\033[0m\n", cmd, cmd2char(cmd));

  switch(cmd){

    case CLUSTER_PING:
	 {
           read(fd, &cmd, INT_SIZE);
           int cmd = CLUSTER_PONG;
           write(fd, &cmd, INT_SIZE);
         }
	 return;

    case CLUSTER_PROC_CMD:
	 {
           read(fd, &cmd, INT_SIZE);
           int len;
           read(fd, &len, INT_SIZE);
	   char buf[len + strlen(conn->host)+1 ];
           read(fd, buf, len);
	   char *s = buf + strlen(buf);
	   sprintf(buf + strlen(buf), "@%s", conn->host);
	   s = strstr(s, ".");
	   if(s) *s = '\000';
	   conn->cmd = strdup(buf);
	   if(Supr_options.verbose)
             fprintf(stderr, "\033[0;36m\n%s\t[INFO] Connected\033[0m\n",
			   conn->cmd);
	   int rc = 0;
           write(fd, &rc, INT_SIZE);
         }
	 return;

    case CLUSTER_CONNECT_DRIVER:
    case CLUSTER_CONNECT_DFSNAME:
    case CLUSTER_CONNECT_MASTER:
    //case CLUSTER_CONNECT_THREADSERVER:
	 { // notify by dfs_name and  master (and driver)
           read(fd, &cmd, INT_SIZE);
	   int len;
           read(fd, &len, INT_SIZE);
	   char addr[len];
	   read(fd, addr, len);
           if(Supr_options.debug)
	     fprintf(stderr, "\033[0;36msocket server addr: %s\033[0m\n",addr);
	   int rc =0;
           write(fd, &rc, INT_SIZE);
	   rc = pthread_mutex_trylock(&Supr_syncMutex);
	   if(rc ==0){
              if(Supr_options.debug)
	        fprintf(stderr, "\033[0;35msocket server addr: %s\033[0m\n",addr);
	       if(Supr_syncObject){
	         Supr_syncObject = strdup(addr);
	         pthread_cond_signal(&Supr_syncCond);
	       }
	     pthread_mutex_unlock(&Supr_syncMutex);
	   }
	 }
	 return;

    case SUPR_INFO:
	 {
           read(fd, &cmd, INT_SIZE);
	   int len;
           read(fd, &len, INT_SIZE);
	   char msg[len];
           read(fd, msg, len);
	   int rc = 0;
	   write(fd, &rc, sizeof(int));
	   if(conn->cmd)
	     fprintf(stderr, "%s [INFO] %s\n", conn->cmd, msg);
	   else if(strstr(msg, "[INFO")) 
	     fprintf(stderr, "%s\n", msg);
	   else 
	     fprintf(stderr, "[INFO] %s\n", msg);
	   /*
           {
	     if(strstr(msg, " mu = 0.00")){
               char *t = strstr(msg, " mu = 0.00") + strlen(" mu = 0.0054567531749");
	       fprintf(stdout, "\"%s\"\n", t);
	     }
	   }
	   */
	 }
	 return;

    case CLUSTER_INFO:
         read(fd, &cmd, INT_SIZE);
	 break;

    case THREADSERVER_STARTED:
	 {
           read(fd, &cmd, INT_SIZE);
	   int len;
           read(fd, &len, INT_SIZE);
	   char addr[len];
           read(fd, addr, len);
	   int rc = 0;
           write(fd, &rc, INT_SIZE);

	   rc = pthread_mutex_trylock(&Supr_syncMutex);
           if(rc ==0) {
	     rc = pthread_mutex_unlock(&Supr_syncMutex);
	     if(Supr_syncObject){
	       Supr_syncObject = strdup(addr);
	       pthread_cond_signal(&Supr_syncCond);
	     }
	     pthread_mutex_unlock(&Supr_syncMutex);
	   } /* else {
	   rc = pthread_mutex_lock(&Supr_syncMutex);
  fprintf(stderr, "\033[0;36mlocked\033[0m\n");
	     if(Supr_syncObject){
	       Supr_syncObject = strdup(addr);
	       pthread_cond_signal(&Supr_syncCond);
	     }
	   pthread_mutex_unlock(&Supr_syncMutex);
	   }*/
	 }
	 return;

    case SET_CONN_PID:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
           int pid;
           read(fd, &pid, sizeof(int));
           conn->pid = pid;
           int type;
           read(fd, &type, sizeof(int)); // ?
	  // int rc=0; write(fd, &rc, sizeof(int)); // ?
         }
         return;

    case CLUSTER_WHO:
         {
           read(fd, &cmd, INT_SIZE);
           int msg[] = {INFO_CONN, getpid(), geteuid()}; // INFO_CONN_SERVER
           write(fd, msg, sizeof(msg));
         }
         return;

    case SOCKET_SERVER_REGISTER:
	 {
           read(fd, &cmd, INT_SIZE);
	   int len;
           read(fd, &len, INT_SIZE);
	   char msg[len];
           read(fd, msg, len);
	   conn->att = strdup(msg);
	   int rc = 0;
	   write(fd, &rc, sizeof(int));
//	   fprintf(stderr, "%s [SOCKET_SERVER] %s\n", conn->cmd, msg);
	 }
	 return;

    case CLUSTER_MSG_SEND:
	 {
	   int header[3];
           read(fd, header, sizeof(header));
	   int len_addr = header[1];
	   int len_raw = header[2];

	   /*
	   if(len_addr == 0 && len_raw == 0){
	     int rc = 0;
             write(fd, &rc, sizeof(int));
	     void *msg = malloc(sizeof(header));
	     memcpy(msg, header, sizeof(header));
	     pthread_mutex_lock(messages->mutex);
	       vectorAdd(messages, msg);
	       if(messages_cond) pthread_cond_signal(messages_cond);
	     pthread_mutex_unlock(messages->mutex);
	   }
	   */

	   void *msg = malloc(sizeof(header) + len_addr+len_raw);
	   memcpy(msg, header, sizeof(header));
           read(fd, msg+sizeof(header), len_addr);
	   //fprintf(stderr, "%s [CLUSTER_MSG_SEND] addr: %s, len_raw: %d\n", conn->cmd, (char*) msg+sizeof(header), len_raw);
	   // set BLOCK mode ...
           ssize_t size = read(fd, msg+sizeof(header)+len_addr, len_raw);
//	   fprintf(stderr, "%s [CLUSTER_MSG_SEND] addr: %s, len_raw: %d, read: %ld\n", conn->cmd, (char*) msg+sizeof(header), len_raw, size);
	   int rc = 0;
           write(fd, &rc, sizeof(int));
	   pthread_mutex_lock(messages->mutex);
	     vectorAdd(messages, msg);
	     if(messages_cond) pthread_cond_signal(messages_cond);
	   pthread_mutex_unlock(messages->mutex);

	   /*
	   if(Supr_options.info){
             SEXP messages =  Cluster_messages();
	     fprintf(stderr, "\033[0;33m[INFO] Received messages:\033[0m\n");
	     BEGIN_R_EVAL();
	       PROTECT(messages);
	       PrintValue(messages);
	     END_R_EVAL();
	   }
	   */
	 }
	 return;


    case INFO_SERVER_SHUTDOWN:
	 {
           read(fd, &cmd, sizeof(int));
	   //fprintf(stderr, "%s, cmd: %d\n", __func__, cmd);

           pthread_mutex_lock(socket_connections->mutex);
             vectorRemoveElement(socket_connections, conn);
           pthread_mutex_unlock(socket_connections->mutex);

	   /*
           Supr_decref(conn);
           connections[conn->fd] = NULL; // FIXME for large RLIMIT_NOFILE??
           Supr_decref(conn);
	   */
           int rc = removeInputHandler(&Supr_R_InputHandlers, handler);
	   // InputHandler *handler
	   // InputHandler *Supr_R_InputHandlers = &Supr_BasicInputHandler;
	   int count = 0;
	   while(Supr_R_InputHandlers->next)
	   {
	     //int rc = removeInputHandler(&Supr_R_InputHandlers, handler);
	     InputHandler *h = Supr_R_InputHandlers->next;
	     count++;
	       
	     //fprintf(stderr, "%d. rm handler %p, fileDescriptor: %d\n", count, h, h->fileDescriptor); 
	     supr_socket_conn_t *sc = NULL;
             pthread_mutex_lock(socket_connections->mutex);
	       for(int i=0; i<vectorSize(socket_connections); i++){
                 sc = (supr_socket_conn_t *)
		 	vectorElementAt(socket_connections, i);
	         if(sc->fd == h->fileDescriptor)
		 {
		   vectorRemove(socket_connections, i);
		   break;
		 }
		 else sc=NULL;
	       }
	       
             pthread_mutex_unlock(socket_connections->mutex);

	     //if(sc) fprintf(stderr, "\t fd: %d, addr: %s:%d\n", sc->fd, sc->host, sc->port);
	     Supr_decref(sc);

	     int rc = removeInputHandler(&Supr_R_InputHandlers, h);
	   }
	   
	   write(fd, &count, sizeof(int));
	 }
	 return;


    case CLUSTER_INFO_DISCONNECT:
         read(fd, &cmd, INT_SIZE);

    default: 
      pthread_mutex_lock(socket_connections->mutex);
        vectorRemoveElement(socket_connections, conn);
      pthread_mutex_unlock(socket_connections->mutex);

      Supr_decref(conn);
      connections[conn->fd] = NULL;
      Supr_decref(conn);
      int rc = removeInputHandler(&Supr_R_InputHandlers, handler);

      if(cmd == CLUSTER_INFO_DISCONNECT && Supr_options.verbose){
        fprintf(stderr, "\033[0;31m%s, %s is disconnected\n\n\033[0m",
		       	__func__, conn->cmd);
      } else {
        printf("Error in %s, unknown command\n", __func__);
        if(Supr_verbose)
	      printf("Error in %s, unknown command\n", __func__);
      }
      return;
  }

  
  //int msg_header[2]; //{type, level};
  int msg_header[4]; //{cmd, color, type, level};
  char *msg;
  size_t len;

  /*
  fprintf(stderr, "get msg_header\n");
  for( ; ; ) {
	  
    n = recv(fd, msg_header, sizeof(msg_header), MSG_PEEK | MSG_DONTWAIT);
    if(n <= 0){
      pthread_mutex_lock(socket_connections->mutex);
        vectorRemoveElement(socket_connections, conn);
      pthread_mutex_unlock(socket_connections->mutex);
      // message:
      //fprintf(stderr, "[%s] conn->ref_count: %d\n", __func__, conn->ref_count);
      Supr_decref(conn);
      connections[conn->fd] = NULL;
      Supr_decref(conn);
      int rc = removeInputHandler(&Supr_R_InputHandlers, handler);

      fprintf(stderr, "Error in %s(conn->proc_cmd: %s): %s (%s:%d)\n",
		      __func__, conn->cmd,
	      strerror(errno), __FILE__, __LINE__);

      if(Supr_verbose){
	      fprintf(stderr, "Error in recv: %s\n", strerror(errno));
      }
      // message:
      //fprintf(stderr, "[%s] Error in recv: %s (n=%ld)\n", __func__, strerror(errno), n);
      return;
    } else if(n == sizeof(msg_header)) {
	    break;
    } else {
      //message:
	      //fprintf(stderr, "n: %ld\n", n); sleep(5); // testing
	      //printf("n: %ld\n", n); sleep(.01); // testing
    }
  }
  fprintf(stderr, "got msg_header\n");
  */

//  if(Supr_verbose){ printf("[%s:%d] %s, //%s:%d:%d\n", __FILE__, __LINE__, __func__, conn->host, conn->port, conn->fd); }

  /*
  int type, level; // hand errors later...
  n = read(fd, &type, INT_SIZE);  //fprintf(stderr, "type: %d\n", type);
printf("n: %ld, type: %d\n", n, type);
  n = read(fd, &level, INT_SIZE); //fprintf(stderr, "level: %d\n", level);
printf("n: %ld, level: %d\n", n, level);
  n = read(fd, &len, SIZE_SIZE);  //fprintf(stderr, "len: %ld\n", len);
printf("n: %ld, len: %ld\n", n, len);
  char buf[len];
  n = read(fd, buf, len);
printf("n: %d\n", n);
*/

  //fprintf(stderr, "Supr_display_message: %d [%d %d] %s\n", Supr_display_message, type, level, buf);
  // color, type, level, length(message), message
  // color: \033 [ 0/1 ; n m pad1 pad2 // also server as a way of checking?

  unsigned char color[8];
  n = read(fd, color, sizeof(color));  //fprintf(stderr, "type: %d\n", type);
  if(color[0] != '\033' || color[1] != '[' || (color[3]!=';'&&color[3]!='m'))
  {
     fprintf(stderr, "\033[0;31m[ERROR] %s:%d:%s, unknown format from %s:%d::%d (%s). Remove handler: %p etc\033[0m\n",
		     __FILE__, __LINE__, __func__,
		     conn->host, conn->port, conn->fd, conn->cmd, handler);
     //sleep(120);

     removeInputHandler(&Supr_R_InputHandlers, handler);
     // remove conn?
     return;
  }
  color[7] = 0;
  //n = read(fd, &type, INT_SIZE);  //fprintf(stderr, "type: %d\n", type);
  //n = read(fd, &level, INT_SIZE); //fprintf(stderr, "level: %d\n", level);

//printf("%sTESTING\n", color);

  int type, level;
  n = read(fd, &type, sizeof(int));

  if(type < 0){
    fprintf(stderr, "\033[0;36mspecial command from conn->cmd: %s\033[0m\n", conn->cmd);
    handleSpecialCommand(conn, handler);
    return;
  }

//printf("n: %ld, type: %d\n", n, type);
  n = read(fd, &level, sizeof(int));
//printf("n: %ld, level: %d\n", n, level);
  n = read(fd, &len, sizeof(ssize_t));
//printf("n: %ld, len: %ld\n", n, len);
  char buf[len];
  n = read(fd, buf, len);

  if(buf[len-1]){
    fprintf(stderr, "\033[0;31m[%s]Whoops, buf[len-1]=%d\033[0m\n",__func__,buf[len-1]);
  }

  // FIXME ...
  if(conn->cmd)
  { fprintf(stdout, "\033[0;33m%s[%d]\t", conn->cmd, conn->fd); }

  /*
  {
    char *t = buf;
    while(*t){
      if(!isprint(*t)){
        fprintf(stderr, "buf has non-print characters: %d\n", *t);
        fprintf(stderr, "buf=\"%s\"\n", buf);
        fprintf(stderr, "len=%ld, buf[len-1]: %d\n", len, buf[len-1]);
      }
      t++;
    }
  }
  */

  switch(type){
    case INFO_WARNING: fprintf(stdout, "%s[WARNING]\033[0m %s\n", color, buf);
	    break;
    case INFO_ERROR: fprintf(stdout, "%s[ERROR]\033[0m %s\n", color, buf);
	    break;
    case INFO_DFS_ERROR: fprintf(stdout, "%s[DFS_ERROR]\033[0m %s\n",
					 color, buf);
	    break;
    case DEBUG_INFO_TYPE: fprintf(stdout, "%s[DEBUG]\033[0m %s\n",
					 color, buf);
	    break;
    case VERBOSE_INFO_TYPE: fprintf(stdout, "%s[VERBOSE]\033[0m %s\n",
					 color, buf);
	    break;
    case DEFAULT_INFO_TYPE: fprintf(stdout, "%s[INFO]\033[0m %s\n", color, buf);
	    break;
    default: fprintf(stdout, "%s[INFO]\033[0m %s\n", color, buf);

	     break;
  }

  /*
  if(Supr_display_message)
  {
    //fprintf(stdout, "[%d %d] %s\n", type, level, buf);
    fprintf(stdout, "[INFO] %s\n", buf);
//    rl_redisplay();
  }
  else {
    SEXP msg = PROTECT(CONS(mkString(buf), CDR(sMessage)));
    SET_TAG(msg, install(conn->host)); // FIXME
    SETCDR(sMessage, msg);
    UNPROTECT(1);
  }
  */

  int rc = 0;
  write(fd, &rc, INT_SIZE);
}

// SuprInfo_handler?
void Supr_info_handler(void *userData)
{
  if(!userData){
    fprintf(stderr, "\033[0;31mError in [%s:%d] %s, handler: %p, userData: %p, pid: %d, tid: %d\033[0m\n",
    	__FILE__, __LINE__, __func__, Supr_info_handler, userData, getpid(), gettid());
    sleep(60);
    exit(1);
    return;
  }

  void **args = (void**) userData;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) args[0];

  if(conn->type == INFO_CONN_SERVER){

    if(Supr_options.verbose){
      fprintf(stderr, "\033[0;33m[User:%s] do serverSocketAccept\033[0m\n",
                          __func__);
    }

    supr_socket_conn_t *clientConn = serverSocketAccept((supr_conn_t*)conn);
    if(clientConn){
      if(Supr_options.verbose){
        fprintf(stderr, "\033[0;33m[User:%s] clientConn->fd = %d\033[0m\n",
                          __func__, clientConn->fd);
      }

      Supr_incref(clientConn);
      connections[clientConn->fd] = (supr_conn_t*) clientConn;
      clientConn->type = INFO_CONN;

      pthread_mutex_lock(socket_connections->mutex);
        vectorAdd(socket_connections, clientConn);
      pthread_mutex_unlock(socket_connections->mutex);

      InputHandler *ih = addInputHandler(Supr_R_InputHandlers, clientConn->fd,
		  Supr_info_handler, SuprInfoActivity);
      void **data = malloc(2*sizeof(void*));
      data[0] = clientConn;
      data[1] = ih;
      ih->userData = data;
      if(Supr_verbose){
        printf("\033[0;33m[User:%s:%d] %s, ih: %p, ih->userData: %p\033[0m\n",
                          __FILE__, __LINE__, __func__, ih, ih->userData);
      }
    } else {
      if(Supr_options.verbose){
        fprintf(stderr, "\033[0;33m[User:%s] clientConn = %p\033[0m\n",
                          __func__, clientConn);
      }
    }
  } else {
    handleInfo(conn, (InputHandler *)args[1]);
  }

}

static void SocketConn_check(const char *host, int port, int kill_proc)
{
  fprintf(stderr, "[%s:%d:%s] host: %s, port: %d, kill: %d\n",
		__FILE__, __LINE__, __func__, host, port, kill_proc);
}

/*
static void __SocketConn_check(const char *host, int port, int kill_proc)
{
  int fd = socket_client(host, port);

  //int pong = tryPingSocketServer2(host, port);
  //fprintf(stderr, "pong: %d (CLUSTER_PONG: %d)\n", pong, CLUSTER_PONG);
 

  // use netstat -tulpen and look at the
  // "Local Address" "PID/Program name" columns

  if(fd != -1) {
    close(fd);
  } else {
    kill_proc = FALSE;
  }

  if(kill_proc){
    if(strcmp(host, Supr_hostname) == 0){
      char cmd[256];
      
      //sprintf(cmd, "netstat -tulpen | grep %d", port);
      //sprintf(cmd, "lsof -i TCP:R | grep %d", port);
      // list open files
      char template[64];
      sprintf(template, "/tmp/supr_XXXXXX");
      int fd = mkstemp(template);
      FILE *file = fdopen(fd, "w");
      sprintf(cmd, "lsof -i TCP | grep \"%d[ \t]*(LISTEN)\" >> %s",
		     	 port, template);
      //fprintf(stdout, "[%s] template: %s\033[0;31m\n", __func__, template); 
      system(cmd);
      fflush(file);
      rewind(file);
      struct stat sb;
      if(fstat(fd, &sb) == -1 || sb.st_size == 0) {
	      close(fd);
	      return;
      }

      char buf[sb.st_size+1];
      read(fd, buf, sb.st_size);
      buf[sb.st_size] = 0;

      char *s = strstr(buf, "LISTEN");
      if(s){
        //fprintf(stderr, "[%s] buf: %s\n\033[0;36m", __func__, buf); 
	s = buf;
	for(int i=0; s; i++){
          char *t = strstr(s, "\n");
	  if(t){
	    *t = 0; t++;
	  } else {
	    break;
	  }
	  if(strstr(s, "LISTEN")){
            fprintf(stderr, "[INFO] [%s] s: %s\n", __func__, s); 
	    char *prog = s;
	    while(*s !=' ' && *s != '\t') s++;
	    *s = 0; s++;
	    while(*s && (*s == ' ' || *s == '\t')) s++;
	    pid_t pid = atoi(s);
            fprintf(stderr, "[%s] cmd: %s, pid: %d\n", __func__, prog, pid); 
	    int rc = kill(pid, SIGKILL);
	    if(rc == -1){
              fprintf(stderr, "[INFO] [%s] kill(%d, SIGKILL): %s\n", __func__,
			      pid, strerror(errno)); 
	    }
	    for(;;){
              int fd = socket_client(host, port);
	      if(fd == -1) break;
              fprintf(stderr, "[%s] socket_client(%s, %d): %d\n", __func__,
			      host, port, fd); 
	      close(fd);
	      sleep(1);
	    }
	  }
	  s = t;
	}
      }

      close(fd);
      unlink(template);
      fprintf(stderr, "[%s] TO DO ...\033[0m\n", __func__); 
      fprintf(stdout, "\033[0m"); 
    } else {
      char cmd[256];
      sprintf(cmd, "ssh %s 'netstat -tulpen | grep %d'", host, port);
      system(cmd);
      fprintf(stderr, "[%s] TO DO ...\033[0m", __func__); 
    }
  }

  fprintf(stderr, "\033[0m"); 
}
*/

void Supr_registerSocketServer(supr_socket_conn_t *server, supr_socket_conn_t *info_sc)
{
  if(!info_sc || !server) return;

  int cmd = SOCKET_SERVER_REGISTER;
  write(info_sc->fd, &cmd, sizeof(int));
  char addr[strlen(server->host)+32];
  sprintf(addr, "%s:%d", server->host, server->port);
  int len = strlen(addr)+1;
  write(info_sc->fd, &len, sizeof(int));
  write(info_sc->fd, addr, len);
  int rc;
  read(info_sc->fd, &rc, sizeof(int));
}

// from driver
SEXP Info_getInfoSever(SEXP address, SEXP driver){
  if(TYPEOF(driver) == NILSXP) error(_("invalid argment 'driver'"));

  SEXP conn = getAttrib(driver, install("conn"));
  supr_socket_conn_t *sc;
  if(TYPEOF(conn) == EXTPTRSXP){
      sc = (supr_socket_conn_t *) R_ExternalPtrAddr(conn);
  } else {
      SEXP addr = getAttrib(driver, install("address"));
      if(TYPEOF(addr) == STRSXP && LENGTH(addr)>0)
        sc = trySocketOpen1(CHAR(STRING_ELT(addr, 0)));
  }

  if(!sc) error(_("cannot connect to driver"));

  int fd = sc->fd;
  if(TYPEOF(address) == NILSXP){
      int cmd = INFO_SERVER_GET;
      ssize_t size = write(fd, &cmd, sizeof(int));
      int len;
      size += read(fd, &len, sizeof(int));
      char addr[len];
      size += read(fd, addr, len);
      int rc = 0;
      size += write(fd, &rc, sizeof(int));
      return mkString(addr);
  } else {
          int cmd = INFO_SERVER_REGISTER;
          ssize_t size = write(fd, &cmd, sizeof(int));
	  const char *addr;
	  if(TYPEOF(address) == EXTPTRSXP &&
		  TYPEOF(getAttrib(address, install("address"))) != NILSXP){
	    addr = CHAR(asChar(getAttrib(address, install("address"))));
	  } else {
	    addr = CHAR(asChar(address));
	  }
          int len = strlen(addr)+1;
          size += write(fd, &len, sizeof(int));
          size += write(fd, addr, len);
	  int rc;
          size += read(fd, &rc, sizeof(int));
	  return ScalarInteger(rc);
	  // ...
  }
}

// cleanup
SEXP Supr_quit(){
  int rc;
  if(socket_connections){
      
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	      vectorElementAt(socket_connections,i);
              //vectorRemove(socket_connections,i);
      fprintf(stderr, "\tclose(%s:%d:%s) ...\n", sc->host, sc->port, sc->cmd);
      if(sc->att){
        fprintf(stderr, "\t\tsocket server: %s\n", (char*)sc->att);
	//supr_socket_conn_t *ss = trySocketOpen1((char*)sc->att);
	supr_socket_conn_t *ss = socketOpen1((char*)sc->att);
	if(ss){
          int cmd = INFO_SERVER_REGISTER;
          ssize_t size = write(ss->fd, &cmd, sizeof(int));
	  int len = 1;
	  char c = 0;
          size += write(ss->fd, &len, sizeof(int));
          size += write(ss->fd, &c, len);
          fprintf(stderr, "\t\twrote total size: %ld (== 9)\n", size);
	  if(size < 9){
            fprintf(stderr, "\tError: %s\n", strerror(errno));
	  } else {
            size += read(ss->fd, &rc, sizeof(int));
            fprintf(stderr, "\t\twrote and read total size: %ld (== 13)\n",
			    size);
	  }
	}
	free(sc->att);
	sc->att = NULL;
      }
      //int cmd = CLUSTER_INFO_DISCONNECT;
      //int rc = write(sc->fd, &cmd, sizeof(int));
      if(rc == -1)
        fprintf(stderr, "\tError: %s\n", strerror(errno));
    }
    

    // cancel info_handler ...

    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
              vectorRemove(socket_connections,i);
	      //vectorElementAt(socket_connections,i);
      fprintf(stderr, "\tfree(%s:%d:%s) ...\n", sc->host, sc->port, sc->cmd);
      close(sc->fd);
      //free(sc); // FIXME
    }
    
  }


  // Check connections[] as well
  return R_NilValue;
}

static void Info_connection_finalizer(SEXP s)
{
  //fprintf(stderr, "%s ...\n", __func__);
  supr_socket_conn_t *sc = (supr_socket_conn_t *) R_ExternalPtrAddr(s);
  close(sc->fd); // more to do... /close ...
  free(sc);

  //Supr_quit();
}


SEXP DD_enableInfo(SEXP r_level)
{
  if(!socket_connections)
    socket_connections = newVector(TRUE);

  supr_thread_t *ih_th = NULL;
  if(sys_threads){
    for(int i=0; i<vectorSize(sys_threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(sys_threads,i);
      if(strcmp(th->name, "InputHandler")==0){
	      ih_th = th;
	      break;
      }
    }
  }

  if(! ih_th) {
    printf("[INFO] %s: Start (SupR) InputHandler\n", __func__);
    Thread_startInputHandler();
  }


  int port = -1;
  SEXP infoPort = findVar(install("info"), SuprContextEnv);
  /*
  {
    fprintf(stderr, "[%s:%d%s] infoPort: \n", __FILE__, __LINE__, __func__);
    PrintValue(infoPort);
  }
  */

//  int reuse_addr = TRUE;
  
  if(infoPort != R_UnboundValue){
    const char *addr = CHAR(asChar(infoPort));
    const char *s = strstr(addr, ":");
    if(s){
      port = atoi(s ? (s+1) : addr);
      nports = strstr(s, "+") ? 0 : 1;
    } else {
      port = 1024; //reuse_addr = FALSE;
      nports = 0;
    }

  }

  supr_socket_conn_t *conn = serverSocketOpen3(port, nports, cmd);
  if(!conn)
	  error(_("cannot open info server socket"));

  Supr_options.port = conn->port;

  Supr_incref(conn);
  connections[conn->fd] = (supr_conn_t*) conn;
  conn->type = INFO_CONN_SERVER;

  printf("[INFO] %s: Started INFO_CONN_SERVER\n", __func__);

  pthread_mutex_lock(socket_connections->mutex);
    vectorAdd(socket_connections, conn);
  pthread_mutex_unlock(socket_connections->mutex);

  InputHandler *ih = addInputHandler(Supr_R_InputHandlers, conn->fd,
		  Supr_info_handler, SuprInfoConnectionActivity);

  //ih->userData = conn;
  void **data = malloc(2*sizeof(void*));
  data[0] = conn;
  data[1] = ih;
  ih->userData = data;

  {
    if(! SUPR_HOMEUSR) suprHomeInit();
    char fileName[strlen(SUPR_HOMEUSR)+strlen("/message.log")+1];
    sprintf(fileName, "%s/message.log", SUPR_HOMEUSR);
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\npid:%d\n", conn->port, getpid());
    size_t size = fileWrite(fileName, buf, strlen(buf)+1);
    printf("[INFO] %s: Wrote\n\"%s\"\nto File %s\n", __func__, buf, fileName);
  }

  msg_serverSocketConn = conn; // FIXME???

  SEXP infoServer = PROTECT(R_MakeExternalPtr(conn, R_NilValue, R_NilValue));
  setAttrib(infoServer, R_ClassSymbol, mkString("SocketServer"));
  char addr[strlen(conn->host)+32];
  sprintf(addr, "%s:%d", conn->host, conn->port);
  setAttrib(infoServer, install("address"), mkString(addr));
  R_RegisterCFinalizerEx(infoServer, Info_connection_finalizer, TRUE);
  conn->cmd = strdup("infoServer");

  UNPROTECT(1);
  return infoServer;
}

SEXP DD_sendUserInfo(SEXP message, SEXP type, SEXP level, SEXP hostname,
	       	SEXP port)
{
  static supr_socket_conn_t *conn = NULL;
  if(port != R_NilValue){
    const char *host = hostname == R_NilValue ? "localhost"
	    : CHAR(asChar(hostname));
    conn = socketOpen2(host, asInteger(port));
  }

  if(!conn)
  {
    if(! SUPR_HOMEUSR) suprHomeInit();
    char fileName[strlen(SUPR_HOMEUSR)+strlen("/message.log")+1];
    sprintf(fileName, "%s/message.log", SUPR_HOMEUSR);

    char *addr = fileRead(fileName);
    char *host = strstr(addr, "//")+2;
    char *str = strstr(host, ":");
    *str = 0; 
    int port = atoi(str+1);
    conn = socketOpen2(host, port);
    free(addr);
  }

  if(!conn)
	  error(_("No info connection is available"));
  // Supr_CheckConn(conn)?

  int Type = asInteger(type);
  int Level = asInteger(level);
  write(conn->fd, &Type, INT_SIZE);
  write(conn->fd, &Level, INT_SIZE);

  const char *msg = CHAR(asChar(message));
  size_t len  = strlen(msg) + 1;
  write(conn->fd, &len, SIZE_SIZE);
  write(conn->fd, msg, len);


  size_t n;
  int timeout = 5; // FIXME
  int rc;

  BEGIN_R_FREE();
  for(int i=0; i<timeout; i++){
    n = recv(conn->fd, &rc, INT_SIZE, MSG_PEEK | MSG_DONTWAIT);
    if(n == INT_SIZE)  break;
    
    sleep(1);
  }

  END_R_FREE();


  if(n == INT_SIZE) {
      read(conn->fd, &rc, INT_SIZE);
      return ScalarInteger(rc);
  }

  warning(_("no response in %d seconds"), timeout);
  return R_NilValue;
}

SEXP DD_getMessages()
{
	/*
  static SEXP sMessages = NULL;
  if(!sMessages) sMessages = install(".SuprLastMessages");
  SEXP messages = PROTECT(SYMVALUE(sMessages));
  SET_SYMVALUE(sMessages, R_NilValue);
  UNPROTECT(1);
  */
  SEXP sMessages = findVar(install(".SuprLastMessages"), R_GlobalEnv);
  if(sMessages == R_UnboundValue) 
	  return R_NilValue;
  SEXP messages = PROTECT(CDR(sMessages));
  SETCDR(sMessages, R_NilValue);
  UNPROTECT(1);
  return messages;
}

/*
SEXP __deprecated_DD_enableInfo(SEXP r_level)
{
  if(!socket_connections)
    socket_connections = newVector(TRUE);

  if(!DFS_namenode)
    errorcall(R_NilValue, "Not connected to DFS Namenode");

  int level = asInteger(r_level);

  printf("[%s] Connecting %s:%d\n", __func__,
		  DFS_namenode->host, DFS_namenode->port);

  supr_socket_conn_t * conn = socketOpen2(DFS_namenode->host,
		 DFS_namenode->port);
  connections[conn->fd] = (supr_conn_t*) conn;
  conn->type = INFO_CONN;

  pthread_mutex_lock(socket_connections->mutex);
    vectorAdd(socket_connections, conn);
  pthread_mutex_unlock(socket_connections->mutex);

  int cmd = INFO_REGISTER;
  write(conn->fd, &cmd, INT_SIZE);
  write(conn->fd, &level, INT_SIZE);

  supr_thread_t *cth = currentThread();
  if(!cth) {
	  //driver_init();
          cth = currentThread();
          if(!cth) errorcall(R_NilValue, "FIXME (%s:%d)", __FILE__, __LINE__);
  }

  {// testing Thread.functions ...
  printf("\033[0;36m[%s:%d] R_PPStackTop: %d\033[0m\n", __func__,
		 cth->tid,  R_PPStackTop);

    SEXP expr = PROTECT(LCONS(install(".Call"),
		    CONS(mkString("DD_info_thread_run"), 
		    CONS(ScalarInteger(conn->fd), R_NilValue))));
    SEXP thread = PROTECT(Thread_new(expr, R_NilValue, R_NilValue,
			    R_GlobalEnv, mkString("INFO-thread"),
			    R_FalseValue));
    printf("[%s] Starting thread:\n", __func__); PrintValue(thread);
    SEXP val = PROTECT(Thread_start(thread));
    printf("[%s] Started thread:\n", __func__); PrintValue(thread);

    defineVar(install("info.thread"), thread, R_GlobalEnv); // FIXME
    UNPROTECT(3);

  printf("\033[0;36m[%s:%d] R_PPStackTop: %d\033[0m\n", __func__,
		 cth->tid,  R_PPStackTop);

  }

  int rc = 0;
  printf("\033[0;36m[%s:%d] return: %d\033[0m\n", __func__, cth->tid, rc);
  return ScalarInteger(rc);
}
*/

struct sigaction save_sigaction;
void DisableInfo_SigactionInt(int sig, siginfo_t *ip, void *context)
{
  printf("\033[0;31m[%s]\033[0m\n", __func__); 

  sigaction(SIGINT, &save_sigaction, NULL);
}

SEXP DD_disableInfo()
{
  if(!socket_connections)
	  return R_NilValue;

  {
    struct sigaction sa;
    sa.sa_sigaction = DisableInfo_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }


  /*
  pthread_mutex_lock(socket_connections->mutex);
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
      if(sc->type == INFO_CONN){
	printf("[%s] disconnect: %d\n", __func__, sc->fd);
        socketDestroy(sc);
        vectorRemove(socket_connections, i);
      }
    }
  pthread_mutex_unlock(socket_connections->mutex);
  */

  SEXP thread = findVar(install("info.thread"), R_GlobalEnv); // FIXME
  //SEXP thread_ptr = findVar(install(".thread"), thread); // FIXME
  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  pthread_kill(th->ptid, SIGINT);

  return R_NilValue;
}



/* inode:
       The following mask values are defined for the file  mode  component  of
       the st_mode field:

           S_ISUID     04000   set-user-ID bit
           S_ISGID     02000   set-group-ID bit (see below)
           S_ISVTX     01000   sticky bit (see below)

           S_IRWXU     00700   owner has read, write, and execute permission
           S_IRUSR     00400   owner has read permission
           S_IWUSR     00200   owner has write permission
           S_IXUSR     00100   owner has execute permission

           S_IRWXG     00070   group has read, write, and execute permission
           S_IRGRP     00040   group has read permission
           S_IWGRP     00020   group has write permission
           S_IXGRP     00010   group has execute permission

           S_IRWXO     00007   others  (not  in group) have read, write, and
                               execute permission
           S_IROTH     00004   others have read permission
           S_IWOTH     00002   others have write permission
           S_IXOTH     00001   others have execute permission
*/

/*
void statPrint(struct stat *sb)
{
  //printf("[%s] st_uid: %d, st_size: %ld, st_mtim: %ld\n",
  char buf[128]; 
  struct tm result;
  localtime_r(&sb->st_mtim.tv_sec, &result);
  asctime_r(&result, buf);
  char *s = strstr(buf, "\n");
  if(s) *s = 0;
//		  asctime(localtime(&sb->st_mtim.tv_sec))
  printf("[%s] %d \t %ld \t%s", S_ISDIR(sb->st_mode)? "*": " ",
		  sb->st_uid, sb->st_size, buf
		 // asctime(localtime(&sb->st_mtim.tv_sec))
		  );
}
*/



size_t __socket_read__(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }
    }

    ssize_t n = read(fd, buf + len,  size - len);

    if(n <= 0){
            printf("read(fd=%d, n = %d, %s\n", fd, n, strerror(errno));
	    //sleep(5);
            return -1;
//          errorcall(null, "read, n = %d, %s", n, strerror(errno));
    }

    /*  n = -1: If no messages are available at the socket, the receive calls wait  for
       a  message  to arrive, unless the socket is nonblocking (see fcntl(2)),
       in which case the value -1 is returned and the external variable  errno
       is set to EAGAIN or EWOULDBLOCK.  The receive calls normally return any
       data available, up to the requested amount,  rather  than  waiting  for
       receipt of the full amount requested.
       */

    len += n;
  }
}


#define read(fd, buf, size) __socket_read__((fd), (buf), (size))

/*
SEXP DD_create(SEXP r_name)
{
  int fd = DFS_namenode->fd;
  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_CREATE;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
  } 

  return ScalarInteger(rc);
}

SEXP DD_list(SEXP r_name)
{
  int fd = DFS_namenode->fd;
  const char *name = CHAR(asChar(r_name));
  int cmd = DFS_DD_LIST;
  write(fd, &cmd, INT_SIZE);
  size_t len = strlen(name)+1;
  write(fd, &len, SIZE_SIZE);
  write(fd, name,  len);

  // 
  int rc;
  read(fd, &rc, INT_SIZE);
  if(rc == -1) {
    read(fd, &len, SIZE_SIZE);
    char err[len];
    read(fd, err, len);
    errorcall(R_NilValue, "%s", err);
  } 

  struct stat sb;
  read(fd, &sb.st_mode, sizeof(mode_t));


  if(S_ISDIR(sb.st_mode)){

    read(fd, &rc, INT_SIZE);

    if(rc == -1){
      read(fd, &len, SIZE_SIZE);
      char err[len];
      read(fd, err, len);
      errorcall(R_NilValue, "%s", err);
    }

    //struct dirent *dp;
    while(TRUE){
      
      read(fd, &len, SIZE_SIZE);
      if(len == 0) break;

      char d_name[len];
      read(fd, d_name, len);

      read(fd, &rc, INT_SIZE);

      if(rc == -1){
        read(fd, &len, SIZE_SIZE);
        char err[len];
        read(fd, err, len);
        //errorcall(R_NilValue, "%s: %s", d_name, err);
        printf("%s: %s\n", d_name, err);
      } else {
        read(fd, &sb, sizeof(struct stat));
        statPrint(&sb);
      }
      printf(" \t%s\n", d_name);
    }

  } else {
    read(fd, &sb, sizeof(struct stat));
    statPrint(&sb);
  }


  return R_NilValue;

}

*/
#undef read


shm_io_info_t *driver_io = NULL;
extern class_t *SocketConn_class;

// deprecated
SEXP Driver_info()
{
//  if(!driver_io) error("no driver connection");
//  if(!__supr_context || !__supr_context->driver_shm_io) error("no driver connection");

  //shm_io_info_t *io = __supr_context->driver_shm_io;
  shm_io_info_t *io = driver_shm_io;
  int cmd = CLUSTER_DRIVER_INFO;
  shm_io_write(io, io->out, &cmd, sizeof(int));

  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  return SO_toRObject(so, size);
}
//

SEXP stopDriver(SEXP stop_master)
{
//  if(!driver_io) error("no driver connection");
  //if(!__supr_context || !__supr_context->driver_shm_io)
  if(!driver_shm_io) {
    return R_NilValue;
  }

  //shm_io_info_t *io = __supr_context->driver_shm_io;
  shm_io_info_t *io = driver_shm_io;

  int cmd = CLUSTER_DRIVER_STOP;
  int args[] = {cmd, asLogical(stop_master)};
  shm_io_write(io, io->out, args, sizeof(args));
  // destroy driver_io
  driver_io = NULL;

  // FIXME: use Supr_decref
  for(int i=0; i<sizeof(connections)/sizeof(supr_socket_conn_t*); i++){
    if(connections[i]){
      if(connections[i]->class == SocketConn_class){
        close(((supr_socket_conn_t*) connections[i])->fd);
	connections[i]->class->finalize(connections[i]->class,
			connections[i]);
	connections[i] = NULL;
      }
    }
  }

  /*
  __supr_context->driver_sc = NULL;
  __supr_context->dnn_sc = NULL;
  __supr_context->msg_sc = NULL;
  */

  return R_NilValue;
}

// testing int SuprNode_create(const char *name, char **argv, int use_tty, double timeout, void **retval);

//SEXP __startDriver(SEXP sport, SEXP args);
/*
SEXP startDriver(SEXP sport)
{
  return __startDriver(sport, R_NilValue);
}

SEXP __startDriver(SEXP sport, SEXP args)
{
  if(!SUPR_HOMESYS) suprHomeInit();
  char shm_name[128];
  sprintf(shm_name, "supr-driver.%d.%d",geteuid(), getpid());
  if(Supr_verbose){
    printf("[%d] %s\n", getpid(), shm_name);
  }

  char CMD_PATH[PATH_MAX];
  
  //sprintf(CMD_PATH, "%s/%s", SUPR_HOMESYS, SYS_COMMAND_DRIVER);

  //sprintf(CMD_PATH, "%s/bin/%s", SUPR_HOMESYS, SYS_COMMAND_DRIVER);
  sprintf(CMD_PATH, "%s/bin/%s", Supr_sysHome, SYS_COMMAND_DRIVER);

  //sprintf(CMD_PATH, "%s/driver", SUPR_HOMESYS);
  //Rprintf("[%s] cmd path: %s\n", __func__,  CMD_PATH);
 

  const char *port = CHAR(asChar(sport));

//  const char *_out = (out==R_NilValue) ? "" : CHAR(asChar(out));
// sprintf(CMD_PATH, "/usr/bin/env");
  char *ld_lib_path = getenv("LD_LIBRARY_PATH");
  if(!ld_lib_path) ld_lib_path = "";
  char ld_path[strlen("LD_LIBRARY_PATH")+strlen(SUPR_HOMESYS)+strlen("libs")+5];
  //sprintf(ld_path,"LD_LIBRARY_PATH=\"%s/libs\"", SUPR_HOMESYS);
  sprintf(ld_path,"LD_LIBRARY_PATH=%s/libs", SUPR_HOMESYS);
  char cmd_driver[strlen(SUPR_HOMESYS)+strlen("bin/driver")+5];
  sprintf(cmd_driver,"%s/bin/driver", SUPR_HOMESYS);

  //Rprintf("[%s] ld_path: %s\n", __func__,  ld_path);
  //Rprintf("[%s] (driver) cmd path: %s\n", __func__,  CMD_PATH);

  char *verbose_str = Supr_verbose ? "TRUE" : "FALSE";

  char *argv_b[] = { //CMD_PATH, "env", ld_path, cmd_driver,
          //CMD_PATH, "driver",
          CMD_PATH, CMD_PATH,
          "-port", (char*) port,
          "-shm", shm_name, //  "-out", (char*) _out,// "--window",
          "-verbose", verbose_str,
          "-usr", Supr_usrHome,
          "-sys", Supr_sysHome,
          "-dfs", Supr_dfsHome,
          (char*) NULL
  };

  if(Supr_verbose){
    printf("[%s] CMD_PATH: %s\n", __func__, CMD_PATH);
  }
  
  char **argv; // NULL terminated array of strings (char *)
  argv = Exec_createArgs((const char **)argv_b, args);

  //for(int i=0; argv[i]; i++){ Rprintf("%d. %s\n", i, argv[i]); }

  int use_window = FALSE;
  //{
    for(int i=0; argv[i]; i++){
      //printf("%d. %s\n", i, argv[i]);
      if((strcmp(argv[i],"-stdout")==0 || strcmp(argv[i],"-driver.stdout")==0 )
		      && argv[i+1] && strcmp(argv[i+1], "--window")==0 )
        use_window = TRUE;
    }
  //}
  //printf("use_window: %d\n", use_window);

  void *retval;

  int rc;

  //Supr_verbose = TRUE;

  char hostname[256];
  gethostname(hostname, 256);
  char buf[strlen(hostname)+strlen("Driver@")+1];
  sprintf(buf, "Driver@%s", hostname);
  char *window_name = buf;

  rc = SuprNode_create(window_name, argv, use_window, 60, &retval);
  Exec_freeArgs(argv);

  if(rc == -1 || retval == NULL){
    warning(_("%s"), strerror(errno));
    return R_NilValue;
  }

  shm_io_info_t *io =(shm_io_info_t *) retval;
  size_t size;
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  //free(ptr);


  pid_t *driver_pid  = (pid_t *) shm_io_read(io, io->in, &size, NULL);
  
  //free(ptr);
  if(Supr_verbose){
    printf("\033[0;32mdriver_pid: %d\n", *driver_pid);
  }

  int int_port;
//#define DO_INFO_MSG 
//#ifdef  DO_INFO_MSG 
  for(;;){
    ptr = shm_io_read(io, io->in, &size, NULL);
    int len = ((int*) ptr)[0]; // or code? len is not used ...
    free(ptr);
    if(len <= 0) {
      int_port = len;
      break;
    }
    ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "[INFO] %s\n", (char*) ptr);
  }
//#else
//  ptr = shm_io_read(io, io->in, &size, NULL);
//  int_port = ((int*) ptr)[0];
//#endif






  if(int_port == -1){
    //free(ptr);
    error(_("Cannot start driver")); // FIXME
  //} else if (int_port>0){
   // warning(_("timedout in waiting to hear from  %s more workers"), int_port);
  } else { // int_port == 0
    //free(ptr);
    //ptr = shm_io_read(io, io->in, &size, NULL);
    //int_port = ((int*) ptr)[0];
  }
  ptr = shm_io_read(io, io->in, &size, NULL);
  int_port = ((int*) ptr)[0];

  //free(ptr);

  {
	   int status;
	   // FIXME, waitpid ...
  }

  SEXP r_io = PROTECT(R_MakeExternalPtr(io, null, null));
  setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
  setAttrib(r_io, R_NameSymbol, mkString(shm_name));
  setAttrib(r_io, install("port"), ScalarInteger(int_port));
  UNPROTECT(1);

  return r_io;
  // need a SpurContext
}
*/



/*
void SuprContext_dumper(FILE *file)
{
  supr_context_t *c = __supr_context;
  char buf[256];

  if(!c) {
    printf("[%s] Error: cannot find SuprContext\n");
    return;
  }
  fprintf(file, "\nSuprContext:\n");
  fprintf(file, "\tsys_home: %s\n", c->sys_home);
  fprintf(file, "\tusr_home: %s\n", c->usr_home);
  fprintf(file, "\tdfs_home: %s\n", c->dfs_home);


  if(c->driver_shm_io){
    sprintf(buf, "name: %s, size: %ld", c->driver_shm_io->shm_info.shm_name,
		    c->driver_shm_io->shm_info.size);
  } else {
    sprintf(buf, "(null)");
  }
  fprintf(file, "\tdriver_shm_io: %s\n", buf);

  if(c->driver_mmap_io){
    sprintf(buf, "name: %s, size: %ld", c->driver_mmap_io->file_name,
		    c->driver_mmap_io->buf_size);
  } else {
    sprintf(buf, "(null)");
  }
  fprintf(file, "\tdriver_mmap_io: %s\n", buf);

  if(c->driver_sc){
    sprintf(buf, "//%s:%d, fd: %d", c->driver_sc->host, c->driver_sc->port,
		    c->driver_sc->fd);
  } else {
    sprintf(buf, "(null)");
  }
  fprintf(file, "\tdriver_sc: %s\n", buf);

  if(c->dnn_sc){
    sprintf(buf, "//%s:%d, fd: %d", c->dnn_sc->host, c->dnn_sc->port,
		    c->dnn_sc->fd);
  } else {
    sprintf(buf, "(null)");
  }
  fprintf(file, "\tdnn_sc: %s\n", buf);

  if(c->msg_ss){
    sprintf(buf, "//%s:%d, fd: %d", c->msg_ss->host, c->msg_ss->port,
		    c->msg_ss->fd);
  } else {
    sprintf(buf, "(null)");
  }
  fprintf(file, "\tmsg_ss: %s\n", buf);

  fprintf(file, "\n");
}
*/

/*
static void SuprContext_finalizer(SEXP s)
{


  supr_context_t *c = (supr_context_t *) R_ExternalPtrAddr(s);

  if(c) Supr_decref(c);
 // else if(!c)
	  return;



 
  fprintf(stderr, "free: mmap_io\n");
  if(c->driver_mmap_io){
    if(*c->driver_mmap_io->file_name == '/')
      unlink(c->driver_mmap_io->file_name); // 
    else
      shm_unlink(c->driver_mmap_io->file_name); // 
  }

  fprintf(stderr, "free: shm_io, FIXME\n");
  if(c->driver_shm_io){
    //shm_io_destroy(c->driver_shm_io);
  }

  //FIXME -> Supr_decref
  //if(c->driver_sc){
    //supr_socket_conn_t *sc = c->driver_sc;
    //sc->class->finalize(sc->class, sc);
    //Supr_decref(c->driver_sc);
  //}

  //if(c->dnn_sc){
    //supr_socket_conn_t *sc = c->driver_sc;
    //sc->class->finalize(sc->class, sc);
    //Supr_decref(c->dnn_sc);
    //Supr_decref(c->msg_ss);
  //}
  // to do...


  free(c);

  {
    // kill all threads???
    supr_thread_t *cth = currentThread();
    for(int i=0; i< vectorSize(sys_threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(sys_threads,i);
      if(th == cth) continue;
      pthread_cancel(th->ptid);
    }
    for(int i=0; i< vectorSize(threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads,i);
      if(th == cth) continue;
      pthread_cancel(th->ptid);
    }
    for(int i=0; i< vectorSize(dcl_threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(dcl_threads,i);
      if(th == cth) continue;
      pthread_cancel(th->ptid);
    }
  }
  fprintf(stderr, "%s is done\n", __func__);
}
*/

/*
const char *SuprContext_toString(struct class_struct *class, void *object)
{
  __FIXME__(__func__);
  return "SuprContext TODO";
}
*/

/*
void SuprContext_finalize(struct class_struct *class, void *object)
{
  fprintf(stderr, "[%s] object: %p\n", __func__, object);
  supr_context_t *c = (supr_context_t *) object;
  fprintf(stderr, "[%s] ref_count: %d\n", __func__, c->ref_count);

  c->sys_home = NULL; // free?
  c->usr_home = NULL; // free?
  c->dfs_home = NULL; // free?

  if(c->driver_shm_io){
    __FIXME__(__func__);

    //shm_io_destroy(c->driver_shm_io);
    c->driver_shm_io = NULL;
  }

  if(c->driver_mmap_io){
    //__FIXME__(__func__);
    // mmap_io_destroy(...):

    mmap_io_t *mmap_io = c->driver_mmap_io;
    int rc = pthread_mutex_trylock(&mmap_io->lock);
    if(rc == 0){
      fprintf(stderr, "mmap_io->buf_size: %ld\n", mmap_io->buf_size);

      //int cmd = CLUSTER_MMAP_CLOSE;
      ((int*) mmap_io->buf)[0] = CLUSTER_MMAP_CLOSE;
      sprintf(mmap_io->buf + INT_SIZE, "TESTING close ...");
      mmap_io->data_size = INT_SIZE + strlen(mmap_io->buf+INT_SIZE)+1;

      rc = pthread_cond_signal(&mmap_io->cond);
      rc = pthread_mutex_unlock(&mmap_io->lock);
    } else {

      warning(_("pthread_mutex_trylock, rc: %d"), rc);
      __FIXME__(__func__);
    }

    if(*mmap_io->file_name == '/')
      unlink(mmap_io->file_name); // 
    else
      shm_unlink(mmap_io->file_name); // 

    free(mmap_io->file_name);

    pthread_mutex_destroy(&mmap_io->lock);
    pthread_cond_destroy(&mmap_io->cond);
    munmap((void *) mmap_io, sizeof(mmap_io_t) + mmap_io->buf_size);

    c->driver_mmap_io = NULL;
  }

  if(c->driver_sc){
    Supr_decref(c->driver_sc);
    c->driver_sc = NULL;
  }

  if(c->dnn_sc){
    Supr_decref(c->dnn_sc);
    c->dnn_sc = NULL;
  }

  if(c->msg_ss){
    __FIXME__(__func__);
    c->msg_ss = NULL;
  }


  free(c);
}
*/

/*
static class_t __SuprContext_class = {"SuprContext", SuprContext_toString,
                      SuprContext_finalize}; 
class_t *SuprContext_class = &__SuprContext_class;

static mmap_io_t *SuprContext_mmapConn(supr_socket_conn_t *driver_sc) {

	if(!driver_sc  || strcmp(driver_sc->host, Supr_hostname))
		return NULL;

        char mmap_io_name[256];
        sprintf(mmap_io_name, "usr-driver.%d.%d", geteuid(), getpid());
        mmap_io_t *mmap_io = mmap_io_create(mmap_io_name);
        if(mmap_io) {
          mmap_io->file_name = strdup(mmap_io_name); // be careful...
          //c->driver_mmap_io = mmap_io;
          if(mmap_io) {
            int cmd = CLUSTER_MMAP_CONN;
	    write(driver_sc->fd, &cmd, INT_SIZE);
	    size_t len = strlen(mmap_io_name) + 1;
	    write(driver_sc->fd, &len, SIZE_SIZE);
	    write(driver_sc->fd, mmap_io_name, len);

	    int rc;
	    read(driver_sc->fd, &rc, INT_SIZE);

	    if(rc == 0){ // mmap_io_client
              pthread_mutex_lock(&mmap_io->lock);

                ((int*)mmap_io->buf)[0] = 0; // FIXME
                sprintf((char*)mmap_io->buf + INT_SIZE, "User: %d", getpid());
                mmap_io->data_size = INT_SIZE + strlen(mmap_io->buf + INT_SIZE)
			             + 1;
	        pthread_cond_signal(&mmap_io->cond);
	        pthread_cond_wait(&mmap_io->cond, &mmap_io->lock);

	      //printf("\033[0;34mmmap_io: %s\033[0m\n", (char*)mmap_io->buf);
              pthread_mutex_unlock(&mmap_io->lock);
	    }
          }
        } 

	return mmap_io;
}

SEXP SuprContext_create(SEXP driver_hostname, SEXP driver_port, SEXP args) // args: options
{
	 error(_("deprecated %s"), __func__);
}
*/

/*
SEXP SuprContext_create(SEXP driver_hostname, SEXP driver_port, SEXP args) // args: options
{
  if(__supr_context) error(_("SuprContext exists"));


  supr_context_t *c = malloc(sizeof(supr_context_t)); // class?
  c->class = SuprContext_class;
  c->ref_count = REF_COUNT_INITIALIZER;
  c->padding = 0;

  c->driver_shm_io  = NULL;
  c->driver_mmap_io = NULL;
  c->driver_sc = NULL;
  c->dnn_sc    = NULL;
  c->msg_ss    =  msg_serverSocketConn;

// if(!SUPR_HOMESYS) suprHomeInit(); fprintf(stderr, "Supr_usrHome: %s\n", Supr_usrHome); c->sys_home = SUPR_HOMESYS; c->usr_home = SUPR_HOMEUSR;

  if(!Supr_sysHome) suprHomeInit();
//fprintf(stderr, "Supr_usrHome: %s\n", Supr_usrHome);
  c->sys_home = Supr_sysHome;
  c->usr_home = Supr_usrHome;
  c->dfs_home = Supr_dfsHome;

  // RCNTXT cntxt; begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv, R_NilValue, R_NilValue); cntxt.cend = NULL; endcontext(&cntxt);

  // connect driver
  SEXP driver_conn = connectDriver(driver_hostname, driver_port,
		  R_NilValue);

  int driver_conn_type;
#define EXISTING_DRIVER	0
#define NEW_DRIVER	1

  if(driver_conn != R_NilValue) { // check dfs_name.log
    char path[PATH_MAX];
    sprintf(path, "%s/dfs_name.log", Supr_usrHome);
    if(access(path, F_OK) != 0){
      fprintf(stderr, "Warning: %s doesn't exists\n", path);
      error(_("connected to an invalid driver given in %s/driver.log\n"),
      	Supr_usrHome);
    }
  } 
  
  if(driver_conn != R_NilValue) {
    // work with the existing driver
    // through the socket connection
    c->driver_sc = R_ExternalPtrAddr(driver_conn);
    Supr_incref(c->driver_sc);
    driver_conn_type = EXISTING_DRIVER;
    fprintf(stdout, "\033[0;31mConnected to an existing driver: //%s:%d\033[0m\n",
    	c->driver_sc->host, c->driver_sc->port);

  } else { // Start the driver
    //SEXP out = RList_findVar("driver.stdout", args);
    //if(out == R_UnboundValue) out = R_NilValue;
    //SEXP driver = __startDriver(driver_port, out);
    fprintf(stdout, "\033[0;37m");

    SEXP driver = __startDriver(driver_port, args);
    fprintf(stdout, "\033[0m"); 
    fflush(stdout);

    if(driver != R_NilValue) {
//      supr_socket_t *sc = R_ExternalPtrAddr(driver);
//      SEXP driver_port = getAttrib(driver, install("port"));
      driver_conn = connectDriver(R_NilValue, R_NilValue, R_NilValue);
//fprintf(stderr, "Supr_usrHome: %s\n", Supr_usrHome);
//fprintf(stderr, "driver_conn: %p\n", driver_conn);
      c->driver_shm_io = R_ExternalPtrAddr(driver);
    }
  
    if(driver_conn != R_NilValue) {
      c->driver_sc = R_ExternalPtrAddr(driver_conn);
      Supr_incref(c->driver_sc);
      if(!c->driver_shm_io){
        warning(_("no driver_shm_io connection"));
	    // TODO ...
      }

      if(!c->driver_mmap_io){
        char mmap_io_name[256];
        sprintf(mmap_io_name, "usr-driver.%d.%d", geteuid(), getpid());
        mmap_io_t *mmap_io = mmap_io_create(mmap_io_name);
        if(mmap_io) {
          mmap_io->file_name = strdup(mmap_io_name); // be careful...
          c->driver_mmap_io = mmap_io;
          if(mmap_io) {
            int cmd = CLUSTER_MMAP_CONN;
	    write(c->driver_sc->fd, &cmd, INT_SIZE);
	    size_t len = strlen(mmap_io_name) + 1;
	    write(c->driver_sc->fd, &len, SIZE_SIZE);
	    write(c->driver_sc->fd, mmap_io_name, len);

	    int rc;
	    read(c->driver_sc->fd, &rc, INT_SIZE);
	//printf("rc: %d\n", rc);

	    if(rc == 0){
              pthread_mutex_lock(&mmap_io->lock);
                sprintf((char*)mmap_io->buf, "From User: %d", getpid());
	        pthread_cond_signal(&mmap_io->cond);
	        pthread_cond_wait(&mmap_io->cond, &mmap_io->lock);
	      //printf("\033[0;34mmmap_io: %s\033[0m\n", (char*)mmap_io->buf);
              pthread_mutex_unlock(&mmap_io->lock);
	    }
          }
        } else {
	      printf("Error: %s\n", strerror(errno));
        }
      }



    }
    driver_conn_type = NEW_DRIVER;
  }

  // connect DFS_namenode
  //.Call("connectDFSNamenode", NULL, NULL)
  SEXP dfs_nn = connectDFSNamenode(R_NilValue, R_NilValue);
  if(dfs_nn == R_NilValue){
    warning(_("couldn't connect to DFS"));
  } else {
    c->dnn_sc = R_ExternalPtrAddr(dfs_nn);
    Supr_incref(c->dnn_sc);
  }

  __supr_context = c;

  switch(driver_conn_type){
    case NEW_DRIVER:
	 { //
  	   if( ! c->msg_ss ){
    		  SEXP level = PROTECT(ScalarInteger(0));
    		  DD_enableInfo(level);
    		  UNPROTECT(1);
    		  c->msg_ss    =  msg_serverSocketConn;
  	    }

  	    if( c->msg_ss ) {
    	        Supr_incref(c->msg_ss);
    		if(c->driver_sc){
      		  int cmd = USER_INFO_ENABLED;
      		  write(c->driver_sc->fd, &cmd, INT_SIZE);
      		  write(c->driver_sc->fd, &c->msg_ss->port, INT_SIZE);
      		  int rc;
      		  read(c->driver_sc->fd, &rc, INT_SIZE);
	          fprintf(stderr,"[INFO] usr.info return code: %d\n", rc);
    	        } else {
	          fprintf(stderr,"[INFO] driver socket server is not available\n");
		}
  	    } else {
	      fprintf(stderr,"[INFO] cannot establish the info connection\n");
	    }
	 }
	 break;

    case EXISTING_DRIVER:
	 if(c->driver_sc) {
	   warning(_("info connection is not implemented with exiting driver"));
	   //driver_shm_io
	   char shm_name[128];
	   sprintf(shm_name, "supr-driver.%d.%d",geteuid(), getpid());
	   if(Supr_verbose) {
	       printf("[%d] %s\n", getpid(), shm_name);
           }

	   size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
	   shm_io_info_t *io = shm_io_create(shm_name, block_size);

	   int cmd = CLUSTER_SHM_CONN;
	   write(c->driver_sc->fd, &cmd, INT_SIZE);
	   size_t len = strlen(shm_name) + 1;
	   write(c->driver_sc->fd, &len, SIZE_SIZE);
	   write(c->driver_sc->fd, shm_name, len);
	   int rc;
	   read(c->driver_sc->fd, &rc, INT_SIZE);
	   if(Supr_verbose) {
	       printf("[%d] %s, rc: %d\n", getpid(), shm_name, rc);
           }
	   c->driver_shm_io = io;
	 }
	 break;

    default: break;
  }
#undef EXISTING_DRIVER
#undef NEW_DRIVER
  //SuprContext_dumper(stdout);

  SEXP r_cntxt = PROTECT(R_MakeExternalPtr(c, null, null));
  Supr_incref(c);

  setAttrib(r_cntxt, R_ClassSymbol, mkString("SuprContext"));
  UNPROTECT(1);

  R_RegisterCFinalizerEx(r_cntxt, SuprContext_finalizer, TRUE);

  {
    SEXP _SuprContext = findVar(install(".SuprContext"), R_GlobalEnv);
    if(//_SuprContext == R_UnboundValue ||
		    TYPEOF(_SuprContext) != LISTSXP){
      _SuprContext = PROTECT(CONS(r_cntxt, R_NilValue));
      SET_TAG(_SuprContext, install("cntxt.ptr"));
      defineVar(install(".SuprContext"), _SuprContext, R_GlobalEnv);
      UNPROTECT(1);
    } else {
      SEXP s = _SuprContext;
      while(s != R_NilValue){
        if(TAG(s) == R_NilValue){ // shouldn't happen ... remove it
      	  SET_TAG(s, install("cntxt.ptr"));
	  SETCAR(s, r_cntxt);
	  break;
	} else if(strcmp("cntxt.ptr", CHAR(PRINTNAME(TAG(s))))==0){
	  SETCAR(s, r_cntxt);
	  break;
	}
	s = CDR(s);
      }

      if(s == R_NilValue){
        while(CDR(_SuprContext) != R_NilValue)
	  _SuprContext = CDR(_SuprContext);

	s = PROTECT(CONS(r_cntxt, CDR(_SuprContext)));
      	SET_TAG(s, install("cntxt.ptr"));
	SETCDR(_SuprContext, s);
	UNPROTECT(1);
      }
    }
  }

  return r_cntxt;
}
*/

extern SEXP DD_operation(SEXP what, SEXP name, SEXP args);

int Supr_killSocketServer2(int port, void *_killed_cmds){

    basic_info(cmd);
    basic_info(__func__);

    char *cmd = "netstat -ano -p tcp";
    vector_t *killed_cmds = (vector_t *)_killed_cmds;
    char template[64];
    sprintf(template, "/tmp/supr_XXXXXX");
    int fd = mkstemp(template);

    pid_t pid = fork();
    if(pid<0) {
	    printf("Error: fork(): %s\n", strerror(errno));
	    return -1;
    }
    //uid_t uid = getuid();
    uid_t euid = geteuid();

    if(pid == 0){
       int stdout_fd = dup(STDOUT_FILENO);
       int rc = dup2(fd, STDOUT_FILENO);
       char CMD[256];
       //sprintf(CMD, "ps -ww U %d", euid);
       sprintf(CMD, "netstat -ano -p tcp | grep %d", port);
       if(rc != -1) {
         //rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
         rc = execl("/bin/sh", "sh", "-c", CMD, (char *) 0);
         dup2(stdout_fd, STDOUT_FILENO);
         fprintf(stderr, "execl, rc: %d\n", rc);
	 close(fd);
         exit(0);
       } else {
         exit(1);
       }
    }

    int status;
    pid_t _pid = waitpid(pid, &status, 0);
    while(_pid != pid){
      _pid = waitpid(pid, &status, 0);
      fprintf(stderr, "waitpid, status: %d, _pid: %d, target_pid: %d\n", status,
		      _pid, pid);
      if(_pid == -1){
        fprintf(stderr, "Error: waitpid, %s\n", strerror(errno));
	break;
      }
      if(_pid != pid){ sleep(1); }
    }
    fprintf(stderr, "waitpid, status: %d\n", status);

    struct stat sb;
    int rc = fstat(fd, &sb);
    fprintf(stderr, "file: %s, size: %ld\n", template, sb.st_size);
    int new_fd = open(template, O_RDONLY);
    char *txt = (char*) malloc(sb.st_size+1);
    ssize_t size = read(new_fd, txt, sb.st_size);
    fprintf(stderr, "fd: %d, read: %s, size: %ld\n", fd, template, size);
    txt[sb.st_size] = 0;
    close(new_fd);
    close(fd);

    unlink(template);

    fprintf(stderr, "FIXME... TODO, port: %d\n", port);
    fprintf(stderr, "txt:\n%s\n", txt);
    if(!strstr(txt, "LISTEN")  && !strstr(txt, "ESTABLISHED")){
      free(txt);
      return 0;
    }

    if(strstr(txt, "LISTEN")){
      basic_info(txt);
      char *s = strstr(txt, "LISTEN") + strlen("LISTEN");
      pid_t pid = atoi(s);
      if(pid > 0 && pid != getpid()) {
	int rc = kill(pid, 0);
	if(rc ==0){
	  rc = kill(pid, SIGKILL);
          //fprintf(stderr, "kill pid: %d, rc: %d\n", pid, rc);

	  char msg[1024];
	  sprintf(msg,"%d kill(%d, 0): %d, %s\n", getpid(), pid, rc,
			 rc == -1 ? strerror(errno) : "");
	  basic_info(msg);
	  {
	    supr_socket_conn_t *sc = trySocketOpen2(Supr_hostname, port);
	    basic_info("trySocketOpen:");
	    if(!sc){
	      sprintf(msg,"%s", strerror(errno));
	      basic_info(msg);
	    } else {
	      sprintf(msg,"connected! [%s]", strerror(errno));
	      basic_info(msg);
	    }
	  }

	  if(killed_cmds) {
            char *line = strtok(txt, "\n");
	    vectorAdd(killed_cmds, strdup(line));
	    s = strstr(line, "LISTEN");
	    if(s) vectorAdd(killed_cmds, strdup(s));
	  }

	  rc = kill(pid, 0);
	  sprintf(msg,"%d kill(%d, 0): %d, %s\n", getpid(), pid, rc, strerror(errno));
	  basic_info(msg);

          free(txt);
          return 0;
	}
      }
    }
    
    char *line = strtok(txt, "\n");
    char port_str[32];
    sprintf(port_str, "%d", port);
    while(line){
      fprintf(stderr, "line: %s\n", line);
      if(!strstr(line, "ESTABLISHED")) {
        line = strtok(NULL, "\n");
        continue;
      }
      char *s = line, *t;
      int i=0;
      for(; i<4; i++){
	t = s;
        while(s && *s != ' ' && *s !='\t') s++;
        while(s && *s == ' ' || *s =='\t') s++;
      }
      fprintf(stderr, "\tt: %s\n", t);
      if(!strstr(line, port_str)) continue;
      for(; i<6; i++){
	t = s;
        while(s && *s != ' ' && *s !='\t') s++;
        while(s && *s == ' ' || *s =='\t') s++;
      }
      fprintf(stderr, "\tt: %s\n", t);
      pid_t pid = s ? atoi(s) : (-1);
      if(pid > 0 && pid != getpid()) {
	int rc = kill(pid, 0);
	if(rc ==0){
	  //rc = kill(pid, SIGKILL);
          fprintf(stderr, "!kill pid: %d, rc: %d (t:%s)\n", pid, rc, t);
	  if(killed_cmds) {
	    vectorAdd(killed_cmds, strdup(line));
	    if(t) vectorAdd(killed_cmds, strdup(t));
	    if(s) vectorAdd(killed_cmds, strdup(s));
	  }
	}
      }

      line = strtok(NULL, "\n");
    }
   

    free(txt);
    return 0;
}

int Supr_killSocketServer(const char *syscmd, int port, void *_killed_cmds){
    char *cmd = "ps aux"; // -pa
    vector_t *killed_cmds = (vector_t *)_killed_cmds;
    char template[64];
    sprintf(template, "/tmp/supr_XXXXXX");
    int fd = mkstemp(template);

    pid_t pid = fork();
    if(pid<0) {
	    printf("Error: fork(): %s\n", strerror(errno));
	    return -1;
    }
    //uid_t uid = getuid();
    uid_t euid = geteuid();

    if(pid == 0){
       int stdout_fd = dup(STDOUT_FILENO);
       int rc = dup2(fd, STDOUT_FILENO);
       char CMD[256];
       sprintf(CMD, "ps -ww U %d", euid);
       if(rc != -1) {
         //rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
         rc = execl("/bin/sh", "sh", "-c", CMD, (char *) 0);
         dup2(stdout_fd, STDOUT_FILENO);
         fprintf(stderr, "execl, rc: %d\n", rc);
	 close(fd);
         exit(0);
       } else {
         exit(1);
       }
    }

    int status;
    pid_t _pid = waitpid(pid, &status, 0);
    while(_pid != pid){
      _pid = waitpid(pid, &status, 0);
      fprintf(stderr, "waitpid, status: %d, _pid: %d, target_pid: %d\n", status,
		      _pid, pid);
      if(_pid == -1){
        fprintf(stderr, "Error: waitpid, %s\n", strerror(errno));
	break;
      }
      if(_pid != pid){ sleep(1); }
    }
    fprintf(stderr, "waitpid, status: %d\n", status);

    struct stat sb;
    int rc = fstat(fd, &sb);
    fprintf(stderr, "file: %s, size: %ld\n", template, sb.st_size);
    int new_fd = open(template, O_RDONLY);
    char *txt = (char*) malloc(sb.st_size+1);
    ssize_t size = read(new_fd, txt, sb.st_size);
    fprintf(stderr, "fd: %d, read: %s, size: %ld\n", fd, template, size);
    txt[sb.st_size] = 0;
    close(new_fd);
    close(fd);

    unlink(template);

    errno = 0;
    /*
    char login_r[32];
    rc = getlogin_r(login_r, sizeof(login_r));
    char *login = login_r;
    */
    /*
    char *login = getlogin();
    if(!login) {
      fprintf(stderr, "Error: getlogin_r, %s\n", strerror(errno));
    }
    */

    char *line = strtok(txt, "\n");
    char port_str[32];
    sprintf(port_str, "-port %d", port);
    while(line){
      if(strstr(line, syscmd) && strstr(line, port_str)){
        fprintf(stderr, "line: %s\n", line);
	pid_t pid = atoi(line);
	if(pid != getpid()) {
	  int rc = kill(pid, SIGKILL);
          fprintf(stderr, "kill pid: %d, rc: %d\n", pid, rc);
	  if(killed_cmds)
	    vectorAdd(killed_cmds, strdup(line));
	}
      }

      line = strtok(NULL, "\n");
    }

    free(txt);
    return 0;
}




int SocketConn_cleanup(const char *service, int port)
{
	/*
  SEXP all = RList_findVar("all", args);
  int shutdown_all = FALSE;
  if(all != R_UnboundValue) shutdown_all = asLogical(all);
  */

  //if(shutdown_all){
    // system: execl("/bin/sh", "sh", "-c", command, (char *) 0);
    char *cmd = "netstat -tpae"; // -pa

    char template[64];
    sprintf(template, "/tmp/supr_XXXXXX");
    int fd = mkstemp(template);

    printf("tmp/supr_XXXXXX: %s\n", template);
    fflush(stdout);

    pid_t pid = fork();
    if(pid<0) {
	    printf("Error: fork(): %s\n", strerror(errno));
	    return -1;
    }

    if(pid == 0){
       // close allConnections  or do beforeFork() and afterFork()?

       int stdout_fd = dup(STDOUT_FILENO);
       int rc = dup2(fd, STDOUT_FILENO);
       if(rc != -1) {
         rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
         dup2(stdout_fd, STDOUT_FILENO);
         printf("execl, rc: %d\n", rc);
	 close(fd);
         exit(0);
       } else {
         exit(1);
       }
    }

    int status;
    pid_t _pid = waitpid(pid, &status, 0);
    while(_pid != pid){
      _pid = waitpid(pid, &status, 0);
      printf("waitpid, status: %d, _pid: %d, target_pid: %d\n", status,
		      _pid, pid);
      //if(_pid != pid){ sleep(1); }
      if(_pid == -1){
        printf("Error: waitpid, %s\n", strerror(errno));
        fflush(stdout);
	break;
      }
      if(_pid != pid){
	      sleep(1);
      }
      fflush(stdout);
    }
    printf("waitpid, status: %d\n", status);

    struct stat sb;
    int rc = fstat(fd, &sb);
    printf("file: %s, size: %ld\n", template, sb.st_size);
    int new_fd = open(template, O_RDONLY);
    char *txt = (char*) malloc(sb.st_size+1);
    ssize_t size = read(new_fd, txt, sb.st_size);
    printf("fd: %d, read: %s, size: %ld\n", fd, template, size);
    txt[sb.st_size] = 0;
    close(new_fd);
    close(fd);

    char *line = strtok(txt, "\n");

    char port_str[32];
    sprintf(port_str, "%d", port);

    char port_str_ex[32];
    sprintf(port_str_ex, ":%d ", port);

    char hostname[256];
    char *addr = NULL;
    if(port != -1){
      gethostname(hostname, 256);
      sprintf(hostname+strlen(hostname), ":%d", port);
      addr = hostname;
    }

    char login_r[32];
    rc = getlogin_r(login_r, sizeof(login_r));
    char *login = login_r;
    if(rc != 0) {
      fprintf(stderr, "Error: getlogin_r, %s\n", strerror(rc));
      fprintf(stderr, "Error: getlogin_r, %s\n", strerror(errno));
      login = NULL;
    }

    fprintf(stdout, "port: %d, addr: %s, login: %s\n", port, addr, login);

    while(line){ 
	    //fprintf(stdout, "line: %s\n", line);
      char *str;
      if(  (str=strstr(line, service))
           &&(port == -1 ||  strstr(line, port_str)) ){

        fprintf(stdout, "line: %s\n", line);
	while(!isspace(*str)) str--;
	pid = atoi(str);
        fprintf(stdout, "pid: %d\n", pid);
	int rc = kill(pid, SIGINT);
	if(rc == -1) 
          fprintf(stdout, "Error in kill(%d, SIGINT): %s\n", pid,
			  strerror(errno));
	else {
		/*
	  char cmd[256];
	  sprintf(cmd, "kill -9 %d", pid);
          rc = system(cmd);
          fprintf(stdout, "kill -9 %d: %s\n", pid, strerror(errno));
	  */
	  if(pid != getpid()) kill(pid, SIGKILL);
	}

	fflush(stdout);

      /*} else if(addr && strstr(line, addr)){
	str = line + strlen(line) -1;
	while(!isspace(*str)) str--;
	pid = atoi(str);
        fprintf(stderr, "\033[0;36mWarning: %s, pid: %d\033[0m\n", line, pid);
	*/
      } else if(strstr(line, port_str_ex) && login && strstr(line, login)){
	str = line + strlen(line) -1;
	while(isspace(*str)) str--;
	while(!isspace(*str)) str--;
	pid = atoi(str);
	int rc = kill(pid, 0);
        fprintf(stderr, "\033[0;35mWarning: %s, pid: %d, rc: %d\033[0m\n",
			  line, pid, rc);
	if(pid){
	  if(pid != getpid()) rc = kill(pid, SIGKILL);
          fprintf(stderr, "\033[0;36mWarning: %s, pid: %d, rc: %d\033[0m\n",
			  line, pid, rc);
	}
      }
      line = strtok(NULL, "\n");
    }

    free(txt);
    //unlink(template);
  //}
  
  return 0;
}

// FIXME
SEXP SuprContect_cleanup(SEXP args)
{
	/*
  SEXP all = RList_findVar("all", args);
  int shutdown_all = FALSE;
  if(all != R_UnboundValue) shutdown_all = asLogical(all);
  */

  //if(shutdown_all){
    // system: execl("/bin/sh", "sh", "-c", command, (char *) 0);
    char *cmd = "netstat -pa";

    char template[64];
    sprintf(template, "/tmp/sdfs_XXXXXX");
    int fd = mkstemp(template);

    pid_t pid = fork();
    if(pid == 0){
       // close allConnections  or do beforeFork() and afterFork()?

       int stdout_fd = dup(STDOUT_FILENO);
       int rc = dup2(fd, STDOUT_FILENO);
       if(rc != -1) {
         rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
         dup2(stdout_fd, STDOUT_FILENO);
         printf("execl, rc: %d\n", rc);
	 close(fd);
         exit(0);
       } else {
         exit(1);
       }
    }

    int status;
    pid_t _pid = waitpid(pid, &status, 0);
    while(_pid != pid){
      _pid = waitpid(pid, &status, 0);
      printf("waitpid, status: %d\n", status);
    } 
    printf("waitpid, status: %d\n", status);
    struct stat sb;
    int rc = fstat(fd, &sb);
    printf("file: %s, size: %ld\n", template, sb.st_size);
    int new_fd = open(template, O_RDONLY);
    char *txt = (char*) malloc(sb.st_size+1);
    ssize_t size = read(new_fd, txt, sb.st_size);
    printf("fd: %d, read: %s, size: %ld\n", fd, template, size);
    txt[sb.st_size] = 0;
    close(new_fd);
    close(fd);

    char *line = strtok(txt, "\n");

    while(line){
        //fprintf(stdout, "line: %s\n", line);
      char *str;
      if(  (str=strstr(line, SYS_COMMAND_DFS_NAMENODE))
         ||(str=strstr(line, SYS_COMMAND_DFS_DATANODE))
         ||(str=strstr(line, SYS_COMMAND_MASTER))
         ||(str=strstr(line, SYS_COMMAND_DRIVER))
         ||(str=strstr(line, SYS_COMMAND_WORKER))
         ||(str=strstr(line, SYS_COMMAND_TASKRUNNER))
	 ){
        fprintf(stdout, "line: %s\n", line);
	while(!isspace(*str)) str--;
	pid = atoi(str);
        fprintf(stdout, "pid: %d\n", pid);
	int rc = kill(pid, SIGINT);
	if(rc == -1) 
          fprintf(stdout, "Error in kill(%d, SIGINT): %s\n", pid,
			  strerror(errno));
	else {
		/*
	  char cmd[256];
	  sprintf(cmd, "kill -9 %d", pid);
          rc = system(cmd);
          fprintf(stdout, "kill -9 %d: %s\n", pid, strerror(errno));
	  */
		if(pid != getpid()) kill(pid, SIGKILL);
	}

      }
      line = strtok(NULL, "\n");
    }

    free(txt);
    //unlink(template);
  //}
  
  return R_NilValue;
}

static int RList_exists(const char *name, SEXP s)
{
  while(s != R_NilValue){
    if(TAG(s) != R_NilValue) {
      fprintf(stdout, "(%s) TAG: %s, name: %s\n",
		      type2char(TYPEOF(TAG(s))),
		      CHAR(PRINTNAME(TAG(s))), name);
      if(strcmp(CHAR(PRINTNAME(TAG(s))), name)==0)
	      return TRUE;
    } else if (TYPEOF(CAR(s)) == SYMSXP){
      fprintf(stdout, "(%s) CAR: %s, name: %s\n",
		      type2char(TYPEOF(CAR(s))),
		      CHAR(PRINTNAME(CAR(s))), name);
      if(strcmp(CHAR(PRINTNAME(CAR(s))), name)==0)
	      return TRUE;
    }

//    if(TAG(s) != R_NilValue && strcmp(CHAR(PRINTNAME(TAG(s))), name)==0) return TRUE;
    s = CDR(s);
  }
  return FALSE;
}

// SC = SuprContext
SEXP SC_nTaskrunners(SEXP worker, SEXP n)
{
  const char *addr = CHAR(asChar(worker));
  char buf[strlen(addr)+1];
  memcpy(buf, addr, strlen(addr)+1);
  char *host = strstr(buf, "//")+2;
  char *str = strstr(buf, ":");
  *str = 0; str++;
  int port = atoi(str);

  int fd = socket_client(host, port);
  if(fd == -1)
	  error(_("%s"), strerror(errno));

  int cmd = CLUSTER_SET_NTRS;
  int _n;
  if(TYPEOF(n) == NILSXP){
    write(fd, &cmd, INT_SIZE);
    cmd = 0;
    write(fd, &cmd, INT_SIZE);

  } else if(TYPEOF(n) == INTSXP){
    _n = asInteger(n);
    write(fd, &cmd, INT_SIZE);
    cmd = 1;
    write(fd, &cmd, INT_SIZE);
    write(fd, &_n,  INT_SIZE);

  } else if(TYPEOF(n) == REALSXP){
    write(fd, &cmd, INT_SIZE);
    cmd = 2;
    write(fd, &cmd, INT_SIZE);
    double r = asReal(n);
    write(fd, &r,  sizeof(double));

  } else {
    close(fd);
    error(_("invalid argument type"));
  }
  read(fd, &_n,  INT_SIZE);
  close(fd);
  return ScalarInteger(_n);
}

SEXP Worker_options(SEXP worker, SEXP args)
{
  SEXP retval = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP s = args, t = retval;
  while(s != R_NilValue) {
    if(TAG(s) != R_NilValue){
      const char *name = CHAR(PRINTNAME(TAG(s)));
      if(strcmp(name, "ntrs")==0 || strcmp(name, "nTaskrunners")==0){
        SEXP val = SC_nTaskrunners(worker, CAR(s));
	SETCDR(t, CONS(val, R_NilValue));
	t = CDR(t);
	SET_TAG(t, TAG(s));
      } else {
        warning(_("not implemeneted for `%s`"), name);
      }
    } else {
      warning(_("unnamed argment is ignored"));
    }
    s = CDR(s);
  }
  UNPROTECT(1);
  return CDR(retval);
}


#ifndef SUPR3

SEXP SuprConf_toRObject(supr_conf_t *conf)
{
  SEXP value = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP ret = value;
  while(conf){
   //Rprintf("%s: %s\n", conf->name, conf->value);
   SETCDR(ret, CONS(mkString(conf->value), R_NilValue)); 
   ret = CDR(ret);
   SET_TAG(ret, install(conf->name));
   conf = conf->next;
  }
  UNPROTECT(1);
  return CDR(value);
}

int SuprConf_readFile(FILE *file, supr_conf_t **conf_addr)
{
  supr_conf_t *conf = *conf_addr;
  size_t size = lseek(fileno(file), 0, SEEK_END);
  char buf[size+1];
  lseek(fileno(file), 0, SEEK_SET); 
  read(fileno(file), buf, size);
  buf[size] = 0;
  char *line = strtok(buf, "\n");
  for(; line; line = strtok(NULL, "\n")){

	  //Rprintf("line: %s\n", line);

    char *s = line;
    while(*s && *s != '#' && (*s == ' ' || *s == '\t'))
	    s++;
    if(*s == 0 || *s == '#')
	    continue;

    const char *name;
    char *t = strstr(s, " ");
    if(t) {
	    *t = 0;
	    t++;
    } else continue;

    if(strcmp(s, "Namenode")==0){
      name = "dfs.name";
    } else if(strcmp(s, "Datanode")==0){
      name = "dfs.data";
    } else if(strcmp(s, "Master")==0){
      name = "master";
    } else if(strcmp(s, "Driver")==0){
      name = "driver";
    } else if(strcmp(s, "Worker")==0){
      name = "worker";
    } else if(strcmp(s, "Infonode")==0){
      name = "info";
    } else if(strcmp(s, "Filetransfer")==0){
      name = "file.transfer";
    } else {
      continue;
    }

    s = strstr(t, "//");
    if(s){

      supr_conf_t *c = conf;
      while(c){
        if(strcmp(c->name, name)==0){
	  char *value = (char*) malloc(strlen(c->value)+strlen(s)+2);
	  sprintf(value, "%s;%s", c->value, s);
	  free(c->value);
	  c->value = value;
          break;
        }
	c = c->next;
      }
      if(c) continue;

      c = malloc(sizeof(supr_conf_t));
      c->next = conf;
      c->name = strdup(name);
      c->value= strdup(s);
      conf = c;
    }
  }

  *conf_addr = conf;
  return 0;
}

int SuprConf_update(SEXP args, supr_conf_t **conf_addr)
{
  supr_conf_t *conf = *conf_addr;
  while(args != R_NilValue){
    const char *name = NULL;
    const char *value= NULL;
    if(TAG(args) != R_NilValue){
      name = CHAR(PRINTNAME(TAG(args)));
      if(  strcmp(name, "driver")==0
         ||strcmp(name, "master")==0
         ||strcmp(name, "dfs.data")==0
         ||strcmp(name, "dfs.name")==0
         ||strcmp(name, "worker")==0
         ||strcmp(name, "info")==0
         ||strcmp(name, "file.transfer")==0){
        value = CHAR(asChar(CAR(args)));
      }
    }
    if(name && value){
        supr_conf_t *c = conf;
	while(c){
          if(strcmp(c->name, name)==0){
		  free(c->value);
		  c->value= strdup(value);
		  break;
	  }
	  c = c->next;
	}

	if(!c) {
	  c = malloc(sizeof(supr_conf_t));
	  c->next = conf;
	  c->name = strdup(name);
	  c->value= strdup(value);
	  conf = c;
	}
    }
    args = CDR(args);
  }
  *conf_addr = conf;
  return 0;
}

static SEXP SuprContext_conf(SEXP args, SEXP save, SEXP env)
{
  if(!Supr_usrHome)
    error(_("usr.home is not available, FIXME"));
  
  if(!Supr_conf){
    char path[strlen(Supr_usrHome) + strlen("supr.conf")+2];
    sprintf(path, "%s/%s", Supr_usrHome, "supr.conf");

    FILE *conf = fopen(path, "r");
    if(!conf){
      warning(_("SuprConfFile: %s, %s"), path, strerror(errno));
    } else {
      SuprConf_readFile(conf, &Supr_conf);
      fclose(conf);
    }

  }

  SuprConf_update(args, &Supr_conf);

  SEXP value = PROTECT(CONS(R_NilValue, R_NilValue));
  SEXP s = value;
  while(args != R_NilValue){
    if(TAG(args) == R_NilValue){
      const char *name = CHAR(asChar(CAR(args)));
      supr_conf_t *c = Supr_conf;
      while(c){
        if(strcmp(name, c->name)==0){
          SETCDR(s, CONS(mkString(c->value), R_NilValue));
	  s = CDR(s);
	  SET_TAG(s, install(name));
	  break;
	}
	c = c->next;
      }
      if(c == NULL){
          SETCDR(s, CONS(NA_STRING, R_NilValue));
	  s = CDR(s);
	  SET_TAG(s, install(name));
      }
    }
    args = CDR(args);
  }
  UNPROTECT(1);

  if(CDR(value) != R_NilValue) 
    return CDR(value);
  else
    return SuprConf_toRObject(Supr_conf);
}

static SEXP SuprContext_start(SEXP args, SEXP env)
{
  //R_thread_init();

  SuprContext_conf(args, R_FalseValue, env);

  SEXP  r_cntxt;
  if(__supr_context) {
    r_cntxt = PROTECT(R_MakeExternalPtr(__supr_context, null, null));
    setAttrib(r_cntxt, R_ClassSymbol, mkString("SuprContext"));
  } else {
    SEXP host = PROTECT(mkString("localhost"));
    SEXP port = PROTECT(ScalarInteger(-1)); // default
    r_cntxt = SuprContext_create(host, port, args);
    UNPROTECT(2);
    PROTECT(r_cntxt);
  }

  UNPROTECT(1);
  return r_cntxt;
}

// return TRUE if successful
//static SEXP SuprContext_close(SEXP args, SEXP env)
// FIXME
// Jobs ???
static SEXP SuprContext_stop(SEXP args, SEXP env)
{
  if(!__supr_context)
    return R_TrueValue;

  warning(_("not fully implemented"));
  //supr_context_t *c = malloc(sizeof(supr_context_t)); // class?

  supr_context_t *c = __supr_context;
  //Supr_decref(c); ?
  c->padding = 0;

  c->driver_shm_io  = NULL; // disconnect
  c->driver_mmap_io = NULL; // disconnect
  c->driver_sc = NULL; // driver_close ...
  c->dnn_sc    = NULL;
  c->msg_ss    = NULL; // close  msg_serverSocketConn;

  //if(!SUPR_HOMESYS) suprHomeInit();
  c->sys_home = NULL;
  c->usr_home = NULL;
  c->dfs_home = NULL;

  //supr_context_t *c = malloc(sizeof(supr_context_t)); // class?
  __supr_context = NULL;

  return R_TrueValue;
}
#endif // SUPR3

SEXP Supr_check()
{
  // Check libsupr.so objects ...
  if(!main_thread){
   Supr_detach(TRUE);
   error(_("SupR is not initialized"));
  }

  // Check R objects ...
  SEXP val;
  val = findVar(install(".ThreadEnv"), R_GlobalEnv);
  if(val == R_UnboundValue){
    _ThreadEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install(".ThreadEnv"), _ThreadEnv, R_GlobalEnv);
    UNPROTECT(1);

    SEXP envir = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(envir, R_GlobalEnv);

    defineVar(install(".type"), R_FalseValue, envir);
    SEXP c_thread = PROTECT(R_MakeExternalPtr(main_thread, R_NilValue, envir));
    defineVar(install(main_thread->name), c_thread, _ThreadEnv);
    setAttrib(c_thread, R_ClassSymbol, mkString("Thread"));
    UNPROTECT(2);


  }
  
  
  return R_NilValue;
}

/*
static int SuprContext_check()
{
  if(!__supr_context) return 0;

  int rc, cmd;

  // Check __supr_context->driver_sc)
  if(__supr_context->driver_sc){
    rc = fcntl(__supr_context->driver_sc->fd, F_GETFD);
    if(rc == -1) {
      Supr_decref(__supr_context->driver_sc);
      __supr_context->driver_sc = NULL;
      error(_("check driver connection, %s"), strerror(errno));
    }

    {
      cmd = CLUSTER_PING;
      ssize_t n = socketWrite(__supr_context->driver_sc->fd, &cmd, INT_SIZE);
      if(n == -1) {
	Supr_decref(__supr_context->driver_sc);
	__supr_context->driver_sc = NULL;
        error(_("driver, disconnected"));
      }

      n = socketRead(__supr_context->driver_sc->fd, &cmd, INT_SIZE);
      if(n == -1) {
	Supr_decref(__supr_context->driver_sc);
	__supr_context->driver_sc = NULL;
        error(_("driver, disconnected"));
      }
      
    }
  }
  
  // Check __supr_context->dnn_sc)
  if(__supr_context->dnn_sc){
    rc = fcntl(__supr_context->dnn_sc->fd, F_GETFD);
    if(rc == -1) {
      Supr_decref(__supr_context->dnn_sc);
      __supr_context->dnn_sc = NULL;
      error(_("check dfs_name connection, %s"), strerror(errno));
    }

    {
      cmd = CLUSTER_PING;
      ssize_t n = socketWrite(__supr_context->dnn_sc->fd, &cmd, INT_SIZE);
      if(n == -1) {
        Supr_decref(__supr_context->dnn_sc);
        __supr_context->dnn_sc = NULL;
        error(_("dfs_name, disconnected"));
      }

      n = socketRead(__supr_context->dnn_sc->fd, &cmd, INT_SIZE);
      if(n == -1) {
        Supr_decref(dnn_sc);
        __supr_context->dnn_sc = NULL;
        error(_("dfs_name, disconnected"));
      }
      
    }
  }
  return 0;
}
*/

// if error occurs, raise R error 
// use a macro, instead of func...
static ssize_t R_socketRead(int fd, void *buf, size_t size)
{
  ssize_t n = socketRead(fd, buf, size);

  if(n==-1) {
    if(errno)
	  error(_("%s"), strerror(errno));
    else
	  error(_("disconnected"));
	  //error(_("unexpected end of input"));
  }

  return n;
}


extern void DD_fini();

void mmap_io_destroy(semaphore_t *semap);

static void Supr_checkContextSettings()
{
  // checking driver.
  char *cmds[] = {"driver", "master", "dfs_name", "dfs_data", "worker", 
                "taskrunner", NULL};
  for(int i=0; cmds[i]; i++){

    char *host = Supr_hostname;
    char *cmd = cmds[i];

    fprintf(stderr, "\033[0;34m\n[CHECKING] %s///%s ---- START\n", host, cmd);

    pid_t pid = fork();
    if(pid==-1) {
      error(_("fork(), %s"), strerror(errno));
    } else if(pid){

      int status;
      errno = 0;
      int rc = waitpid(pid, &status, 0);

      fprintf(stderr, "waitpid(pid=%d, &status, 0): %d, status: %d\n",
          pid, rc, status);

      if(status && WIFEXITED(status)) {
        fprintf(stderr, "WEXITSTATUS(status): %d\n", WEXITSTATUS(status));
        fprintf(stderr, "WEXITSTATUS(status): %d, ssh %s ...\n",
                       WEXITSTATUS(status), host);
      }
      if(status)
        fprintf(stderr, "\033[0;31m/* [CHECKING] %s  ---- DONE */\033[0m\n\n",
		cmd);
      else
        fprintf(stderr, "\033[0;32m/* [CHECKING] %s  ---- DONE */\033[0m\n\n",
		cmd);

      continue;
 
    } else {
      const char *format = "source .suprrc;" //" env;"
          " $SUPR_SYS_HOME/bin/%s --help"; 
      char ssh_arg[strlen(format) + strlen(cmd) + 256];
      sprintf(ssh_arg, format, cmd);


      fprintf(stderr, "ssh %s %s\n", host, ssh_arg);
      int rc = execl("/usr/bin/ssh", "ssh", host, ssh_arg, (char*) NULL);
      fprintf(stderr, "Error: [%s] run worker: rc =  %d, %s\n", __func__,
        rc, strerror(errno));
      exit(EXIT_FAILURE);
    }
  }

  // Checking for driver.log, dfs_name.log, and master.log
  char *logs[] = {"driver.log", "dfs_name.log", "master.log", NULL};
  char *home = getenv("HOME");
  fprintf(stderr, "\033[0;35mCheck log file: \n");
  for(int i=0; logs[i]; i++){
    char *log = logs[i];
    char path[PATH_MAX];
    if(Supr_usrHome)
      sprintf(path, "%s/%s", Supr_usrHome, log);
    else
      sprintf(path, "%s/.supr/%s", home, log);
    int fd = open(path, O_RDONLY);
    if(fd == -1){
      fprintf(stderr, "[INFO] %s: %s\n", path, strerror(errno)); 
      continue;
    }
    struct stat sb;
    int rc = fstat(fd, &sb);
    if(rc == -1){
      fprintf(stderr, "[INFO] %s: %s\n", path, strerror(errno)); 
      continue;
    }

    char buf[sb.st_size+1];
    ssize_t n = read(fd, buf, sb.st_size);
    if(n != sb.st_size){
      fprintf(stderr, "[INFO] %s: %s\n", path, strerror(errno)); 
      continue;
    }
    buf[sb.st_size] = 0;
    close(fd);
    char *pid_str = strstr(buf, "pid:");
    pid_t pid = atoi(pid_str + strlen("pid:"));

    char *host = strstr(buf, "//") + 2;
    char *s = strstr(host, ":");
    *s = 0;

    //if(strcmp(host, Supr_hostname))
    {
      fprintf(stderr, "[INFO] Check or kill ? %s\n", buf);
      char cmd[strlen(buf)+256];
      sprintf(cmd, "ssh %s 'kill -9 %d'", host, pid);
      int rc = system(cmd);
      fprintf(stderr, "[INFO] Kill ..., rc: %d, rm: %s\n", rc, path);
      //unlink(path);
      
      continue;
    }


    sprintf(path, "/proc/%d", pid);
    rc = stat(path, &sb);

    if(rc == -1){
      fprintf(stderr, "[INFO] %s: %s\n", path, strerror(errno)); 
      continue;
    }

    fprintf(stderr, "[INFO] %s, sb.st_uid: %d (%d, %d)\n", path, sb.st_uid,
    	getuid(), geteuid());

    if(sb.st_uid != getuid() && sb.st_uid != geteuid()) {
      if(Supr_usrHome)
        sprintf(path, "%s/%s", Supr_usrHome, log);
      else
        sprintf(path, "%s/.supr/%s", home, log);
      fprintf(stderr, "[INFO] rm %s\n", path);
      unlink(path);
      continue;
    }

    // cmd line
    sprintf(path, "/proc/%d/cmdline", pid);
    FILE *cmdline = fopen(path, "r");
      int c;
      size_t size = 0;
      for(;;){
        c = fgetc(cmdline);
        size++; // printf(" %d", c);
        if(c==-1) break;// putchar(c);

      }
      //printf("\n");
      rewind(cmdline);
      char *cmd = (char*) malloc(size);
      size = 0;
      int argc = 0;
      for(;;){
        c = fgetc(cmdline);
        if(c==-1) {
          cmd[size++] = 0;
          break;
        } else if(c==0) {
          argc++;
        }
        cmd[size++] = c;
      }
    fclose(cmdline);

    char *name = strdup(log); 
    s = strstr(name, ".log");
    if(s) *s = 0;
    fprintf(stderr, "[INFO] cmd: %s, log: %s\n", cmd, log);
    if(strstr(cmd, name)){
      fprintf(stderr, "[INFO] cmd: %s, alive\n", cmd);
    } else {
      fprintf(stderr, "[INFO] cmd: %s, \n", cmd);
    }
    free(name);
    free(cmd);

  }
  fprintf(stderr, "\033[0m\n");

}

// FIXME ?
// The usage of this function is currently intended for calling the
// SuprContext.what(...) function ...
#ifndef SUPR3
SEXP SuprContext(SEXP what, SEXP args, SEXP env)
{
  if(Supr_verbose && !__supr_context)
    Supr_checkContextSettings();
    

  /*
  fprintf(stderr, "Supr_sysHome: %s\n", Supr_sysHome);
  fprintf(stderr, "Supr_usrHome: %s\n", Supr_usrHome);
  fprintf(stderr, "Supr_dfsHome: %s\n", Supr_dfsHome);

  if(!Supr_dfsHome){ // FIXME
    if(Supr_usrHome){
      Supr_dfsHome = strdup(Supr_usrHome);
      SUPR_DFS_HOMEUSR =  strdup(Supr_usrHome);
    }
  }
  */


  int rc = 0;

  if(what != R_NilValue){
    const char *what_cmd = CHAR(asChar(what));
    if(strcmp(what_cmd, "usr.dir")==0){
//      fprintf(stderr, "args:\n");
//      PrintValue(args);
      if(args != R_NilValue){
        if(__supr_context)
	  error(_("shutdown the current context, SuprContext(shutdown)"));
        
	SEXP new_dir = CAR(args);
	if(TYPEOF(new_dir) == STRSXP){
	  const char *dir_str = CHAR(STRING_ELT(new_dir, 0));

	  /*
	  struct stat sb;
	  int rc =  stat(dir_str, &sb);
	  if(rc == -1){
	    
	  } else if () {
	    
	  }
	  */

	  Supr_usrHome = strdup(dir_str);
	  SUPR_HOMEUSR = strdup(dir_str); // delete me ...

	  DIR* dir = opendir(dir_str);
	  if(!dir){
	    warning(_("%s, %s"), dir_str, strerror(errno));
	  } else {
	    closedir(dir);
	  }

	}
      }
      return Supr_usrHome ?  mkString(Supr_usrHome) : R_NilValue;
    } else if(strcmp(what_cmd, "dfs.dir")==0){
      if(args != R_NilValue){
        if(__supr_context)
	  error(_("shutdown the current context, SuprContext(shutdown)"));
	SEXP new_dir = CAR(args);
	if(TYPEOF(new_dir) == STRSXP){
	  const char *dir_str = CHAR(STRING_ELT(new_dir, 0));
	  Supr_dfsHome = strdup(dir_str);
	  SUPR_DFS_HOMEUSR = strdup(dir_str); // delete me ...
	}
      }
      return Supr_dfsHome ?  mkString(Supr_dfsHome) : R_NilValue;
    } else if(strcmp(what_cmd, "sys.dir")==0){
      fprintf(stderr, "(ignored) args:\n");
      PrintValue(args);
      return Supr_sysHome ?  mkString(Supr_sysHome) : R_NilValue;
    } else if(strcmp(what_cmd, "conf")==0){
      return SuprContext_conf(R_NilValue, R_FalseValue, env);
    }
  }
 


  Supr_check();
  SuprContext_check();

  if(what == R_NilValue){
    if(__supr_context){
      SEXP  r_cntxt = PROTECT(R_MakeExternalPtr(__supr_context, null, null));
      setAttrib(r_cntxt, R_ClassSymbol, mkString("SuprContext"));
      UNPROTECT(1);
      return r_cntxt;
    } else {
      SEXP r_sc = SuprContext_start(args, env);
      if(__supr_context->driver_sc && ! __supr_context->driver_mmap_io)
        __supr_context->driver_mmap_io
	       	= SuprContext_mmapConn(__supr_context->driver_sc);
      return r_sc;
    }
  }

  const char *what_cmd = CHAR(asChar(what));

  if((strcmp(what_cmd, "shutdown")==0
      ||strcmp(what_cmd, "close")==0
     ) && __supr_context == NULL)
    return R_NilValue;

  if(strcmp(what_cmd, "start")==0){

    if(__supr_context)
      error(_("SuprContext exists"));

    SEXP r_sc =  SuprContext_start(args, env);
    if(__supr_context->driver_sc && ! __supr_context->driver_mmap_io)
        __supr_context->driver_mmap_io
	       	= SuprContext_mmapConn(__supr_context->driver_sc);

    return r_sc;
  }
 
  //if(strcmp(what_cmd, "restart")==0) return SuprContext_stop(args, env);

  if(strcmp(what_cmd, "restart")==0){
    if(__supr_context)
       SuprContext_stop(args, env);
    return SuprContext_start(args, env);
  }

  if(strcmp(what_cmd, "cleanup")==0)
    return SuprContect_cleanup(args);
 
  SEXP  r_cntxt;
  if(__supr_context) {
//    SuprContext_dumper(stdout);
    r_cntxt = PROTECT(R_MakeExternalPtr(__supr_context, null, null));
    setAttrib(r_cntxt, R_ClassSymbol, mkString("SuprContext"));
  } else {
    SEXP host = PROTECT(mkString("localhost"));
    //SEXP port = PROTECT(ScalarInteger(0)); 
    SEXP port = PROTECT(ScalarInteger(-1)); // default
    r_cntxt = SuprContext_create(host, port, args);
    UNPROTECT(2);
    PROTECT(r_cntxt);
  }

  if(strcmp(what_cmd, "shutdown")==0){
    UNPROTECT(1);
    int cmd = CLUSTER_SHUTDOWN;
    int all = TRUE; // FIXME
    if(__supr_context->driver_sc) {
      write(__supr_context->driver_sc->fd, &cmd, INT_SIZE);
      write(__supr_context->driver_sc->fd, &all, INT_SIZE);
      // SHUT_RD, SHUT_WR, SHUT_RDWR
      shutdown(__supr_context->driver_sc->fd, SHUT_WR);
      int rc = read(__supr_context->driver_sc->fd, &cmd, INT_SIZE);
      shutdown(__supr_context->driver_sc->fd, SHUT_RDWR); // ??
      rc = close(__supr_context->driver_sc->fd); // More to do
      Supr_decref(__supr_context->driver_sc);
      __supr_context->driver_sc = NULL;

      // close ...
      if(__supr_context->driver_shm_io) {
        shm_io_destroy(__supr_context->driver_shm_io);
        __supr_context->driver_shm_io = NULL;
      }

      if(__supr_context->driver_mmap_io) {
        mmap_io_destroy(__supr_context->driver_mmap_io);
        __supr_context->driver_mmap_io = NULL;
      }

      __supr_context = NULL;
      DD_fini();

      {
        SEXP _SuprContext = findVar(install(".SuprContext"), R_GlobalEnv);
	if(TYPEOF(_SuprContext) == LISTSXP){
          SEXP s = _SuprContext;
	  while(s != R_NilValue){
            if(TAG(s) != R_NilValue && 
	      strcmp("cntxt.ptr", CHAR(PRINTNAME(TAG(s))))==0){
	         SETCAR(s, R_NilValue);
		 break;
	    }
	    s = CDR(s);
	  }
	}
      }

      {
        char path[PATH_MAX];
	sprintf(path, "%s/%s", Supr_usrHome, "dfs_name.log");
	unlink(path);
	sprintf(path, "%s/%s", Supr_usrHome, "master.log");
	unlink(path);
	sprintf(path, "%s/%s", Supr_usrHome, "driver.log");
	unlink(path);

      }

 

      return ScalarInteger(rc);
    } else {
      error(_("not connected to driver"));
    }
  } else if(strcmp(what_cmd, "close")==0){

    Supr_decref(__supr_context);
    fprintf(stderr, "[%s], __supr_context->ref_count: %d\n", __func__,
			  __supr_context->ref_count);

	  // use a macro?
    SEXP _SuprContext = findVar(install(".SuprContext"), R_GlobalEnv);
    if(TYPEOF(_SuprContext) == LISTSXP){
            SEXP s = _SuprContext;
            while(s != R_NilValue){
              if(TAG(s) != R_NilValue &&
                strcmp("cntxt.ptr", CHAR(PRINTNAME(TAG(s))))==0){
		   SEXP r_cntxt = CAR(s);
		   if(R_ExternalPtrAddr(r_cntxt) == __supr_context
				   && __supr_context->ref_count)
	             Supr_decref(__supr_context);
		   R_SetExternalPtrAddr(r_cntxt, NULL);
                   SETCAR(s, R_NilValue);
                   break;
              }
              s = CDR(s);
            }
    }

    __supr_context = NULL;
    return R_NilValue;

  } else if(strcmp(what_cmd, "driver")==0){ // Get DriverContext

    if(args != R_NilValue){
      const char *cmd = CHAR(asChar(CAR(args)));
      if(strcmp(cmd, "disconnect")==0){
        UNPROTECT(1);
        // close ...
        if(__supr_context->driver_shm_io) {

	  int cmd = DU_DISCONNECT;
	  shm_io_info_t *io = __supr_context->driver_shm_io;
	  size_t n = shm_io_write(io, io->out, &cmd, sizeof(int));
	  void *p = shm_io_read(io, io->in, &n, NULL);
	  int rc = ((int*)p)[0];
	  REprintf("rc: %d\n", rc);

          shm_io_destroy(__supr_context->driver_shm_io);
          __supr_context->driver_shm_io = NULL;
        }

        if(__supr_context->driver_mmap_io) {
          mmap_io_destroy(__supr_context->driver_mmap_io);
          __supr_context->driver_mmap_io = NULL;
        }

        if(__supr_context->driver_sc) {
          Supr_decref(__supr_context->driver_sc);
          __supr_context->driver_sc = NULL;
        }

        __supr_context = NULL;
        DD_fini();

        {
          SEXP _SuprContext = findVar(install(".SuprContext"), R_GlobalEnv);
	  if(TYPEOF(_SuprContext) == LISTSXP){
            SEXP s = _SuprContext;
	    while(s != R_NilValue){
              if(TAG(s) != R_NilValue && 
	        strcmp("cntxt.ptr", CHAR(PRINTNAME(TAG(s))))==0){
	           SETCAR(s, R_NilValue);
		   break;
	      }
	      s = CDR(s);
	    }
	  }
        }

	/*
        {
        char path[PATH_MAX];
	sprintf(path, "%s/%s", Supr_usrHome, "dfs_name.log");
	unlink(path);
	sprintf(path, "%s/%s", Supr_usrHome, "master.log");
	unlink(path);
	sprintf(path, "%s/%s", Supr_usrHome, "driver.log");
	unlink(path);
        }
	*/

        return R_NilValue;
      } else {
        error(_("unknown command '%s'"), cmd);
      }
      return R_NilValue;
    }

    int cmd = CLUSTER_GET_CONTEXT;
    if(__supr_context->driver_sc){
      ssize_t size = write(__supr_context->driver_sc->fd, &cmd, INT_SIZE);

      so_t so;
      R_socketRead(__supr_context->driver_sc->fd, &so, sizeof(so_t));

      so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
      memcpy(s, &so, sizeof(so_t));

      //size = read(__supr_context->driver_sc->fd, s->val, s->size);
      R_socketRead(__supr_context->driver_sc->fd, s->val, s->size);

      SEXP ret = SO_toRObject(s, sizeof(so_t)+so.size);
      free(s);
      UNPROTECT(1);
      return ret;
    }
  } else if(strcmp(what_cmd, "dfs")==0){ // Get DriverContext
    int cmd = CLUSTER_GET_CONTEXT;
    if(__supr_context->dnn_sc){
      write(__supr_context->dnn_sc->fd, &cmd, INT_SIZE);
      so_t so;
      R_socketRead(__supr_context->dnn_sc->fd, &so, sizeof(so_t));
      so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
      memcpy(s, &so, sizeof(so_t));
      R_socketRead(__supr_context->dnn_sc->fd, s->val, s->size);

      SEXP ret = SO_toRObject(s, sizeof(so_t)+so.size);
      free(s);
      UNPROTECT(1);
      return ret;
    }
  } else if(strcmp(what_cmd, "master")==0){ // Get DriverContext
    int cmd = CLUSTER_GET_CONTEXT;
    char *master_addr = NULL;
    if(__supr_context->driver_sc){
      write(__supr_context->driver_sc->fd, &cmd, INT_SIZE);
      so_t so;
      R_socketRead(__supr_context->driver_sc->fd, &so, sizeof(so_t));
      so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
      memcpy(s, &so, sizeof(so_t));
      R_socketRead(__supr_context->driver_sc->fd, s->val, s->size);
      SEXP ret = SO_toRObject(s, sizeof(so_t)+so.size);
      free(s);
      SEXP master = RList_findVar("MASTER", ret);
      if(master == R_UnboundValue)
        error(_("no master connection"));
      else
        master_addr = strdup(CHAR(STRING_ELT(master, 0)));
      UNPROTECT(1);
    } else {
      error(_("no driver connection"));
    }

    //printf("master_addr: %s\n", master_addr);

    char *host = strstr(master_addr, "//")+2;
    char *str  = strstr(host, ":"); *str = 0; str++;
    int port = atoi(str);
    //printf("master_addr: //%s:%d\n", host, port);
    int fd = socket_client(host, port);
    free(master_addr);
    if(fd == -1) error(_("%s"), strerror(errno));
    //printf("connected, fd: %d\n", fd);

    write(fd, &cmd, INT_SIZE);
    so_t so;
    R_socketRead(fd, &so, sizeof(so_t));
    so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
    memcpy(s, &so, sizeof(so_t));
    R_socketRead(fd, s->val, s->size);
    SEXP ret = SO_toRObject(s, sizeof(so_t)+so.size);
    free(s);

    //shutdown(fd);
    close(fd);

    return ret;
  } else if(strcmp(what_cmd, "worker")==0){ // Get DriverContext

    int cmd = CLUSTER_GET_CONTEXT;
    char *master_addr = NULL;
    SEXP ret;
    if(__supr_context->driver_sc){
      write(__supr_context->driver_sc->fd, &cmd, INT_SIZE);
      so_t so;
      R_socketRead(__supr_context->driver_sc->fd, &so, sizeof(so_t));
      so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
      memcpy(s, &so, sizeof(so_t));
      R_socketRead(__supr_context->driver_sc->fd, s->val, s->size);
      ret = SO_toRObject(s, sizeof(so_t)+so.size);
      free(s);
      UNPROTECT(1);
    } else {
      error(_("no driver connection"));
    }

    PROTECT(ret);

    SEXP val = PROTECT(CONS(R_NilValue, R_NilValue));
    SEXP t = val;
    while(ret != R_NilValue){
      if(TAG(ret) != R_NilValue &&
         strcmp(CHAR(PRINTNAME(TAG(ret))),"WORKER")==0){
        char *worker_addr = strdup(CHAR(STRING_ELT(CAR(ret), 0)));
        //printf("worker_addr: %s\n", worker_addr);
        char *host = strstr(worker_addr, "//")+2;
        char *str  = strstr(host, ":"); *str = 0; str++;
        int port = atoi(str);
        //printf("worker_addr: //%s:%d\n", host, port);
        //fprintf(stderr, "Connecting //%s:%d ...\n", host, port);
        int fd = socket_client(host, port);
        free(worker_addr);
        if(fd == -1) error(_("%s"), strerror(errno));
        //printf("connected, fd: %d\n", fd);

        write(fd, &cmd, INT_SIZE);
        so_t so;
	ssize_t n = R_socketRead(fd, &so, sizeof(so_t));
	if(n != sizeof(so_t)) {
		close(fd);
		error(_("read, %s"), strerror(errno));
	}
        so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
        memcpy(s, &so, sizeof(so_t));
	n = R_socketRead(fd, s->val, s->size);
	if(n != s->size) {
		close(fd);
		error(_("read, %s"), strerror(errno));
	}

        SEXP val = SO_toRObject(s, sizeof(so_t)+so.size);
	//PrintValue(val);
	SETCDR(t, CONS(val, R_NilValue));
	t = CDR(t);
	SET_TAG(t, install(CHAR(STRING_ELT(CAR(ret), 0))));
        free(s);
        close(fd);
      }
      ret = CDR(ret);
    }

    UNPROTECT(2);
    return CDR(val);
  }

  { // checking connections
    if(__supr_context->driver_sc &&
	   fcntl(__supr_context->driver_sc->fd, F_GETFD)==-1) 
    {
      Supr_decref(__supr_context->driver_sc); // TODO
      __supr_context->driver_sc = NULL;
    }
    if(__supr_context->dnn_sc &&
	    fcntl(__supr_context->dnn_sc->fd, F_GETFD)==-1) 
    {
      Supr_decref(__supr_context->dnn_sc); // TODO
      __supr_context->dnn_sc = NULL;
    }
  }

  if(what == R_NilValue)
  {
    UNPROTECT(1);
    return r_cntxt;
  }

  const char *_what = CHAR(asChar(what));
  if(strcmp(_what,"print")==0)
    SuprContext_dumper(stdout);
  /*
  else if(strcmp(_what,"close")==0) {
    supr_context_t *c = __supr_context;
    if(c->driver_sc) {
      close(c->driver_sc->fd); // testing conn->att...
      Supr_decref(c->driver_sc); // TODO
      c->driver_sc = NULL;
    }

    if(c->driver_mmap_io){
      if(*c->driver_mmap_io->file_name =='/')
	      unlink(c->driver_mmap_io->file_name);
      else
	      shm_unlink(c->driver_mmap_io->file_name);
      mmap_io_close(c->driver_mmap_io);
      c->driver_mmap_io = NULL;
    }

    if(c->driver_shm_io){
	    shm_io_destroy(c->driver_shm_io);
	    c->driver_shm_io = NULL;
    }

    if(c->driver_sc) {
      close(c->dnn_sc->fd);
      Supr_decref(c->dnn_sc); // TODO
      c->dnn_sc = NULL;
    }
  }
  */
  else if(strcmp(_what,"driver")==0) { // driver.info
    UNPROTECT(1);
    return Driver_info();
  } else if(strcmp(_what,"dfs")==0) { // driver.info
    SEXP what = PROTECT(mkString("info"));
    SEXP val = DD_operation(what, R_NilValue, R_NilValue);
    UNPROTECT(2);
    return val;
  } else
	  error(_("unknown action '%s'"), _what);

  UNPROTECT(1);
  return R_NilValue;
}
#endif //SUPR3

/*
SEXP deprecated_startDriver(SEXP sport)
{

  if(!SUPR_HOMESYS) suprHomeInit();

  char shm_name[128];
  sprintf(shm_name, "supr.driver-%d-%d",geteuid(), getpid());
  printf("[%d] %s\n", getpid(), shm_name);

  //SEXP shm_conn = R_shmCreate
  size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
  shm_io_info_t *io = shm_io_create(shm_name, block_size);

  driver_io = io;

  SEXP r_io = PROTECT(R_MakeExternalPtr(io, null, null));
  setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
  setAttrib(r_io, R_NameSymbol, mkString(shm_name));
  UNPROTECT(1);


  pid_t pid = fork();
  if(pid) {
    fprintf(stderr, "%s: proc %d is to run \"%s\"\n", __func__, pid, "driver");
    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: \"%s\"\033[0m\n", (char*) ptr);

    pid_t *driver_pid  = (pid_t *) shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: serverSocket: port = %d\033[0m\n",
		    driver_pid[0]);

    ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: serverSocket: port = %d\033[0m\n",
		    ((int*) ptr)[0]);

    // set "java"Driver_PID
    R_setJavaDriverPID(ScalarInteger(driver_pid[0]));


    //atexit(doCleanups);

    {
    supr_thread_t *cth = currentThread();
    cth->pid = getpid();
    printf("cth: %p, cth->save_R_PPStackTop: %d\n", cth,
		    cth->save_R_PPStackTop);
    }

    return r_io;
  }
    {
    supr_thread_t *cth = currentThread();
    cth->pid = getpid();
    cth->tid = syscall(SYS_gettid);
    printf("cth: %p, cth->save_R_PPStackTop: %d\n", cth,
		    cth->save_R_PPStackTop);
    }


  char DRIVER_CMD_PATH[PATH_MAX];
  sprintf(DRIVER_CMD_PATH, "%s/driver", SUPR_HOMESYS);
  printf("[%s] cmd path: %s\n", __func__,  DRIVER_CMD_PATH);

  const char *port = CHAR(asChar(sport));

#define USE_XTERM
#ifdef  USE_XTERM

  char *argv[] = {
          DRIVER_CMD_PATH,
          "-port", (char*) port,
          "-shm", shm_name,
          (char*) NULL
  };

  //int argc = sizeof(args)/sizeof(char*);
  //supr_xterm_t *xterm = supr_xterm2("master", argv);
  supr_xterm_t *xterm = supr_xterm2("Driver", argv);
  if(xterm)
  {
    printf("[%s] run driver: xterm =  %p\n", __func__, xterm);
  }
  else
  {
    printf("[%s] run driver: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
  }
  exit(0);

#else

  int rc = execl(DRIVER_CMD_PATH, "driver",
		  "-port", port,
		  "-shm", shm_name,
	  (char*) NULL);
  printf("[%s] run driver: rc =  %d, %s\n", __func__, rc, strerror(errno));

#endif

//  exit(0);
  
}
*/


// subdir under worker
// deprecated?
SEXP startWorker(SEXP sport, SEXP subdir, SEXP master)
{
  if(!SUPR_HOMESYS) suprHomeInit();

  char shm_name[128];
  sprintf(shm_name, "supr.worker-%d-%d-%s",geteuid(), getpid(),
		 CHAR(asChar(subdir)));
  printf("[%d] %s\n", getpid(), shm_name);

  //SEXP shm_conn = R_shmCreate
  size_t block_size = sysconf(_SC_PAGE_SIZE);
  shm_io_info_t *io = shm_io_create(shm_name, block_size);

  //worker_io = io;

  SEXP r_io = PROTECT(R_MakeExternalPtr(io, null, null));
  setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
  setAttrib(r_io, R_NameSymbol, mkString(shm_name));
  UNPROTECT(1);


  pid_t pid = fork();
  if(pid) {

    fprintf(stderr, "%s: child proc %d is to run \"%s\"\n", __func__, pid, "worker");
    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: \"%s\"\033[0m\n", (char*) ptr);
    ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: serverSocket: port = %d\033[0m\n",
		    ((int*) ptr)[0]);
    return r_io;
  }

  char CMD_PATH[PATH_MAX];
  sprintf(CMD_PATH, "%s/worker", SUPR_HOMESYS);
  printf("[%s] cmd path: %s\n", __func__,  CMD_PATH);

  const char *port = CHAR(asChar(sport));

#define USE_XTERM
#ifdef  USE_XTERM

  char *argv[] = {
	  CMD_PATH,
          "-port", (char*) port,
          "-shm", shm_name,
	  "-dir", (char*) CHAR(asChar(subdir)),
	  "-master", (char*) CHAR(asChar(master)),
          (char*) NULL
  };

  supr_xterm_t *xterm = supr_xterm2("Worker", argv);

  if(xterm)
  {
    printf("[%s] run worker: xterm =  %p\n", __func__, xterm);
  }
  else
  {
    printf("[%s] run worker: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
  }

#else

  // FIXME
  int rc = execl(CMD_PATH, "worker",
		  "-port", port,
		  "-shm", shm_name,
	  (char*) NULL);
  printf("[%s] run worker: rc =  %d, %s\n", __func__, rc, strerror(errno));

#endif

  {
    int status;
    pid_t pid = waitpid(-1, &status, 0);
    printf("[%s:%d] run worker: waitpid(-1,...) =  %d, %s\n",
		    __func__, getpid(), pid, strerror(errno));

    //sleep(10);
  }

  exit(0);
  
}

/*
SEXP startWorker(SEXP hostname, SEXP sport, SEXP subdir, SEXP master_addr,
		SEXP stdout_conn)
{
  const char *host = host == R_NilValue ? "localhost" 
	  : CHAR(asChar(hostname));
  int port = asInteger(sport);
  const char *dir = subdir == R_NilValue ? NULL
	  : CHAR(asChar(subdir));
  const char *master = master_addr == R_NilValue ? NULL
	  : CHAR(asChar(master_addr));

  int is_atty = isatty(STDOUT_FILENO);

  if(stdout_conn == R_NilValue){
  }
}
*/





char interrupt_message_buf[256];

// testing only
SEXP Driver_eval(SEXP expr, SEXP env){

  shm_io_info_t *io = driver_io;
  int cmd = DU_DRIVER_EVAL;

  SEXP vec = PROTECT(allocVector(VECSXP, 2));
  SET_VECTOR_ELT(vec, 0, expr);
  SET_VECTOR_ELT(vec, 1, env);

  size_t size;
  so_t *so = SO_valueOf(vec, &size);
  so->ref_count = cmd;

  shm_io_write(io, io->out, so, sizeof(so_t)+so->size);
  free(so);

  UNPROTECT(1);

  so = (so_t*)shm_io_read(io, io->in, &size, NULL);

  printf("[%s] size: %ld, obj->type: %d\n", __func__, size, so->obj_type);
  if(so->obj_type == SUPR_ERROR){
     char err[so->size];
     memcpy(err, so->val, so->size);
     free(so);
     errorcall(R_NilValue, "%s", err);
  }

  SEXP val = SO_toRObject(so, sizeof(so_t)+so->size);
  free(so);

  return val;

}

SEXP R_simpleTryEval(SEXP expr, SEXP env, int *errorOccurred)
{
#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue
//#define SETJMP(x) setjmp(x)

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  }


#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      val = eval(expr, env);
      UNPROTECT(1);

    } else {

      ThreadError_print(R_curErrorBuf());

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n",
                    __FILE__, __LINE__, save, R_PPStackTop);
  }
  return val;

#undef null
#undef R_ToplevelContext
}


SEXP R_simpleTryEval4(SEXP (*func)(SEXP args), SEXP args, SEXP env,
	       	int *errorOccurred)
{
  printf("[%s] \n", __func__);

#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  }


#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = null; // PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      //val = eval(expr, env);
      val = func(args); 
      UNPROTECT(1);

    } else {

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n",
                    __FILE__, __LINE__, save, R_PPStackTop);
  }
  return val;

#undef null
#undef R_ToplevelContext
}


int shm_io_readInt(shm_io_info_t *io)
{
  size_t data_size;
  void *ptr = shm_io_read(io, io->in, &data_size, NULL);
  /*
  { char msg[1024];
    sprintf(msg, "[%s:%d] ptr: %p", __FILE__, __LINE__, ptr);
    Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
  }
  */
  int val = ((int*)ptr)[0];
  /*
  { char msg[1024];
    sprintf(msg, "[%s:%d] val: %d", __FILE__, __LINE__, val);
    Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
  }
  */
  free(ptr);
  /*
  { char msg[1024];
    sprintf(msg, "[%s:%d] val: %d", __FILE__, __LINE__, val);
    Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
  }
  */
  return val;
}

int shm_io_writeInt(shm_io_info_t *io, int val)
{
  return shm_io_write(io, io->out, &val, sizeof(int));
}

int shm_io_writeChar(shm_io_info_t *io, const char *val)
{
  size_t size = 0;
  if(val) {
    size = strlen(val) + 1;
    shm_io_write(io, io->out, &size, SIZE_SIZE);
    shm_io_write(io, io->out, (void *)val, size);
  } else {
    shm_io_write(io, io->out, &size, SIZE_SIZE);
  }
  return size;
}


so_t *SO_valueOf(SEXP r_object, size_t *length)
{
#define TEST_R_objectToBytes3
#ifdef TEST_R_objectToBytes3
  static size_t offset = sizeof(so_t);

  so_t *so = (so_t*) R_objectToBytes3(r_object, length, offset);
  so->ref_count  = 1;
  so->mem_type  =  0;
  so->sys_type  =  0; // R
  so->obj_type = SUPR_SERIALIZED_ROBJ;
  so->size  = *length - offset;
  return so;
#else
  size_t size;
  void *data = R_objectToBytes(r_object, &size);

  so_t *so = (so_t*) malloc(sizeof(so_t) + size);

  so->ref_count  = 1;
  so->mem_type  =  0; // TODO
  so->sys_type  =  0;
  so->obj_type = SUPR_SERIALIZED_ROBJ;
  so->size  = size;

  // add a so_t object before R_objectToBytes(): do this later...

  memcpy(so + 1, data,  size);
  free(data);

  *length = sizeof(so_t) + size;

  return so;
#endif 
#undef TEST_R_objectToBytes3

}

void shm_io_writeSuprObject(shm_io_info_t *io, SEXP r_object)
{
#define TEST_R_objectToBytes3
#ifdef TEST_R_objectToBytes3
  size_t size;
  size_t offset = sizeof(so_t);
  so_t *so = (so_t*) R_objectToBytes3(r_object, &size, offset);
  so->ref_count  = 0;
  so->mem_type  =  0; // TODO
  so->sys_type  =  0;
  so->obj_type = SUPR_SERIALIZED_ROBJ;
  so->size  = size - offset;
  size_t n = shm_io_write(io, io->out, so, size);
  free(so);

#else
  size_t size;
  void *data = R_objectToBytes(r_object, &size);
  so_t *so = (so_t*) malloc(sizeof(so_t) + size);

  so->ref_count  = 0;
  so->mem_type  =  0; // TODO
  so->sys_type  =  0;
  so->obj_type = SUPR_SERIALIZED_ROBJ;
  so->size  = size;

  memcpy(so + 1, data,  size);

free(data);

  size_t n = shm_io_write(io, io->out, so, sizeof(so_t) + size);
  free(so); // fixme by using strbuf...
#endif
#undef TEST_R_objectToBytes3
}

void  R_SigactionInt(int sig, siginfo_t *ip, void *context)
{

  printf("\033[0;31m[%s] interrupt (kill %d)\033[0m\n", __func__, javaDriver_PID);
  //c_backtrace();

  R_isInterrupted = TRUE;

//#define TEST_SOCKET_NOTIFY
#ifdef TEST_SOCKET_NOTIFY
//  socket_sync_notify(R_NilValue);
  socket_sync_interrupt(R_NilValue);
#else
  //kill(javaDriver_PID, SIGUSR1);
  {
	  SuprSignal_set(SIGUSR2);
  }
  kill(javaDriver_PID, SIGUSR1);
#endif
  //kill(javaDriver_PID, SIGINT);

  sigaction(SIGINT, &R_oldactInt, NULL);
  //errorcall(R_NilValue, "Interrupted");
}


void R_setIntsigHandler()
{
    static int R_oldactInt_saved = FALSE;

    R_isInterrupted = FALSE;

    struct sigaction sa;
    sa.sa_sigaction = R_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;

    if(R_oldactInt_saved){
      sigaction(SIGINT, &sa, NULL);
    } else {
      sigaction(SIGINT, &sa, &R_oldactInt);
    }
}

void R_resetIntsigHandler()
{
  R_isInterrupted = FALSE;
  sigaction(SIGINT, &R_oldactInt, NULL);
}

SEXP R_setJavaDriverPID(SEXP pid){

  javaDriver_PID = INTEGER(pid)[0];
  rDriver_PID = getpid();

  return R_NilValue;
}

void SUPR_setSignalHandler(
		void (*int_action)(int, siginfo_t *, void *),
		void (*usr1_action)(int, siginfo_t *, void *),
		void (*usr2_action)(int, siginfo_t *, void *)
		){

  void (*int_signal_action)(int, siginfo_t *, void *)  = SUPR_SigactionSIGINT;
  void (*usr1_signal_action)(int, siginfo_t *, void *) = SUPR_SigactionSIGUSR1;
  void (*usr2_signal_action)(int, siginfo_t *, void *) = SUPR_SigactionSIGUSR2;
  if(int_action) int_signal_action = int_action;
  if(usr1_action) usr1_signal_action = usr1_action;
  if(usr2_action) usr2_signal_action = usr2_action;

  //{
    pid_t ppid = getppid();
    //printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] ppid = %d\n", __func__, ppid);

    pid_t pid = getpid();
    pid_t pgid = getpgrp();
    //printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] pid = %d\tpgid = %d\n", __func__, pid, pgid);

    if(pgid == ppid){
      int rc = setpgrp(); // set process group to itself
      if(rc == -1)
        printf("Error: %s\n", strerror(errno));

      pid = getpid();
      pgid = getpgrp();
//      printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] pid = %d\tpgid = %d\n", __func__, pid, pgid);
    }

  //}

  signalHandlerThread_ptid = pthread_self();
  signalHandlerThread_tid = ((unsigned int)syscall(SYS_gettid));
  //printf("\033[0;33m[%s(SIGUSR1 & SIGINT)] pthread.self()=%ld, tid=%d\033[0m\n", __func__, signalHandlerThread_ptid, signalHandlerThread_tid);

  {
    struct sigaction sa;
    sa.sa_sigaction = usr1_signal_action; // SUPR_SigactionSIGUSR1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, &Java_oldactUsr1);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = usr2_signal_action; // SUPR_SigactionSIGUSR2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = int_signal_action; // SUPR_SigactionSIGINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &Java_oldactInt);
    //RJNI_SIG_BLOCK(SIGINT);
  }

}

#define   DRIVER_SYNC_NOTIFY  31
#define   DRIVER_INTERRUPT  32

//static char jSyncObject[256] = {0};

  /*
SEXP  socket_sync_interrupt(SEXP obj_ref)
{
  errorcall(R_NilValue, "not implemented (%s:%d)", __FILE__, __LINE__);
  socket_conn_t *s_conn = (socket_conn_t *) // FIXME
	  NULL;
          //rjni_getExternalPtr("socket.conn", R_GlobalEnv);

  //if(!jSyncObject) jSyncObject = "";
  const char *ref = jSyncObject;
  if(TYPEOF(obj_ref) == STRSXP)
    ref = CHAR(STRING_ELT(obj_ref,0));

  unsigned char buf[2*sizeof(int)+strlen(ref)];
  sprintf(buf+2*sizeof(int), "%s",ref);

  int *intVal = (int*) buf;
  intVal[0] =  DRIVER_INTERRUPT; // DRIVER_SYNC_NOTIFY;
  intVal[1] = (int) strlen(ref);

  if(s_conn->endian == BIG_ENDIAN) {
    printf("[%s] to BIG_ENDIAN\n", __func__);
    for(int i=0; i<2; i++)
      intVal[i] = htobe32(intVal[i]);
  } else {
    for(int i=0; i<2; i++)
      intVal[i] = htole32(intVal[i]);
  }

  printf("[%s] write (..., [%d, %d, ...]\n", __func__, intVal[0], intVal[1]);
  write(s_conn->fd, buf, sizeof(buf));

  printf("[%s] read an int value ....\n", __func__);
  size_t len = 0;
  size_t size = sizeof(int);
  while(len < size){
    len += read(s_conn->fd, buf+len, size-len);
  }
  printf("[%s] read (intVal = %d)\n", __func__, be32toh(*((int*)buf)));

  return R_NilValue;
}
  */

/*
SEXP  socket_sync_notify(SEXP obj_ref)
{
  errorcall(R_NilValue, "not implemented (%s:%d)", __FILE__, __LINE__);
  socket_conn_t *s_conn = (socket_conn_t *) // FIXME
	  NULL;
   //       rjni_getExternalPtr("socket.conn", R_GlobalEnv);

  //if(!jSyncObject) jSyncObject = "";
  const char *ref = jSyncObject;
  if(TYPEOF(obj_ref) == STRSXP)
    ref = CHAR(STRING_ELT(obj_ref,0));

  unsigned char buf[2*sizeof(int)+strlen(ref)];
  sprintf(buf+2*sizeof(int), "%s",ref);

  int *intVal = (int*) buf;
  intVal[0] =  DRIVER_SYNC_NOTIFY;
  intVal[1] = (int) strlen(ref);

  if(s_conn->endian == BIG_ENDIAN) {
    printf("[%s] to BIG_ENDIAN\n", __func__);
    for(int i=0; i<2; i++)
      intVal[i] = htobe32(intVal[i]);
  } else {
    for(int i=0; i<2; i++)
      intVal[i] = htole32(intVal[i]);
  }

  printf("[%s] write (..., [%d, %d, ...]\n", __func__, intVal[0], intVal[1]);
  write(s_conn->fd, buf, sizeof(buf));

  printf("[%s] read an int value ....\n", __func__);
  size_t len = 0;
  size_t size = sizeof(int);
  while(len < size){
    len += read(s_conn->fd, buf+len, size-len);
  }
  printf("[%s] read (intVal = %d)\n", __func__, be32toh(*((int*)buf)));

  return R_NilValue;
}
*/



static pthread_t Supr_SigactionSIGINT_enabled_ptid = 0;

void Supr_interrupt_disable()
{
//	basic_info(__func__);
  Supr_SigactionSIGINT_enabled_ptid = 0;
  sigaction(SIGINT, &R_oldactInt, NULL);
}

// change the name...
void  Supr_SigactionSIGINT_enabled(int sig, siginfo_t *ip, void *context)
{
  //fprintf(stderr, "%s\n", __func__);
  //basic_info(__func__);

  supr_thread_t * cth = currentThread();
  //fprintf(stderr, "thread: %s\n", cth->name);

  if(!pthread_equal(cth->ptid, Supr_SigactionSIGINT_enabled_ptid))
  {
    int rc=pthread_kill(Supr_SigactionSIGINT_enabled_ptid, SIGINT);
    //fprintf(stderr, "pthread_kill(,SIGINT): %d\n", rc);
    if( rc != 0){
      fprintf(stderr, "Error: pthread_kill(,SIGINT): %d\n", rc);
    }
    return;
  }

  //fprintf(stderr, "\033[0;31mContinue: %s\033[0m\n", cth->name);

  //printf("jSyncObject: %s\n", jSyncObject); // FIXME
  char *intr_ref = (char*)cth->properties;
  //fprintf(stderr, "intr_ref: %s\n", intr_ref); // FIXME

  if(driver_sc){
    //int fd = __supr_context->driver_sc->fd;
    int fd = driver_sc->fd;
    int cmd = USER_INTERRUPT;
    write(fd, &cmd, INT_SIZE);
    //char *intr_ref = jSyncObject;
    size_t len = strlen(intr_ref) + 1;
    write(fd, &len, SIZE_SIZE);
    write(fd, intr_ref, len);
    //error(_("USER_INTERRUPTED"));
    int rc;
    //fprintf(stderr, "read ...\n");
    //FIXME: use timedwait ...
    read(fd, &rc, INT_SIZE);
    //fprintf(stderr, "rc :%d\n", rc);

    /*
    if(cth->data){
      shm_io_info_t *io = (shm_io_info_t *) cth->data;
      int rc = shm_io_reset(io, 1);
      fprintf(stderr, " shm_io_reset(io, 1)\n", rc);
    }
    */

  } else {
    basic_info("FIXME");
  }

  Supr_interrupt_disable();

  /*
  {
    basic_info("Call cth->fun");
    char msg[1024];
    sprintf(msg, "tid: %d, fun: %p, data: %p", cth->tid, cth->fun, cth->data);
    basic_info(msg);
  }
  */

  if(cth->fun) // cleanup?
    cth->fun(cth->data); 
}

void Supr_interrupt_enable()
{
  //basic_info(__func__);

  supr_thread_t * cth = currentThread();
  Supr_SigactionSIGINT_enabled_ptid = cth->ptid;

  struct sigaction sa;
  sa.sa_sigaction = Supr_SigactionSIGINT_enabled;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
  sigaction(SIGINT, &sa, &R_oldactInt);

}

void Supr_onClusterEvalIntr(void *data)
{
	char msg[1024];
  sprintf(msg, "LINE: %d\n", *((int *)data));
  basic_info(msg);
  //io->reset()
  Supr_interrupt_disable();
  //c_backtrace();
}

static supr_socket_conn_t *dcl_sc = NULL;//???

SEXP DCL_init(SEXP r_name)
{
  const char *name = CHAR(asChar(r_name));
  printf("name: %s\n", name);

  // FIXME
  //if(__supr_context->driver_sc)
  if(driver_sc)
  { //close(__supr_context->driver_sc->fd);
    printf("close __supr_context->driver_sc\n");
    close(driver_sc->fd);
    Supr_decref(driver_sc);
    //__supr_context->driver_sc = NULL;
    driver_sc = NULL;
  }
  /*
  if(__supr_context->msg_ss){ //close(__supr_context->driver_sc->fd);
    printf("close __supr_context->msg_ss\n");
    close(__supr_context->msg_ss->fd);
    Supr_decref(__supr_context->msg_ss);
    __supr_context->msg_ss = NULL;
  }
  */

  if( ! dcl_sc )
    error(_("No socket connection is available")); 

  int cmd = DCL_CONN;
  write(dcl_sc->fd, &cmd, INT_SIZE);
  pid_t ppid = getppid();
  write(dcl_sc->fd, &ppid, INT_SIZE);

  size_t len = strlen(name) + 1;
  write(dcl_sc->fd, &len, SIZE_SIZE);
  write(dcl_sc->fd, name, len);

  //read(dcl_sc->fd, &rc, INT_SIZE);

  //Supr_decref(__supr_context->driver_sc);
  //__supr_context->driver_sc = dcl_sc;
  driver_sc = dcl_sc;
  dcl_sc = NULL;

  // if host == 'localhost', use MMAP_CONN???
  //
  //ThreadProc_lock(r_name);
    //ThreadProc_notify(r_name, R_TrueValue);
  //ThreadProc_unlock(r_name);
  //
  
  return R_NilValue;
}


/*
SEXP DCL_nextEvent(SEXP args)
{

  //int fd = __supr_context->driver_sc->fd;
  int fd = driver_sc->fd;
  int cmd = DCL_EVENT_GET;
  write(fd, &cmd, INT_SIZE);

  size_t size;
  so_t *s = SO_valueOf(args, &size);

  char *var_name = NULL;

  BEGIN_R_FREE();

    write(fd, s, sizeof(so_t) + s->size);

free(s);

    size_t len;
    read(fd, &len, SIZE_SIZE);
    //char var_name[len];
    var_name = (char*) malloc(len);
    read(fd, var_name, len);

    //printf("var_name: %s\n", var_name);

    if(len > 1){

      so_t so;
      read(fd, &so, sizeof(so_t)); 
      s = (so_t *) malloc(sizeof(so_t) + so.size);
      memcpy(s, &so, sizeof(so_t));
      read(fd, s->val, s->size); 
    }

  END_R_FREE();

  if(strlen(var_name) == 0)
	  return R_NilValue;

  SEXP retval = PROTECT(CONS(SO_toRObject(s, sizeof(so_t) + s->size),
			  R_NilValue));
  SET_TAG(retval, install(var_name));
  free(s);
  free(var_name);

  //PrintValue(retval);

  UNPROTECT(1);
  return retval;
}
*/

static jmp_buf cluster_eval_jmp_env; // fixme

// shm_io_interrupt...?
static void R_cluster_eval_interrupt(void *data){
  if(data) {
    basic_info("Cancel submission...");
    basic_info("data: %p, LINE: %d", data, *((int*) data));

    longjmp(cluster_eval_jmp_env, 0); // FIXME
  } else {
    verbose_info("cancel waiting...");
    supr_thread_t *cth = currentThread();
    cth->fun  = NULL;
    cth->data = PTHREAD_INTERRUPTED;
  }

}

/*
SEXP Pthread_sigmask(SEXP S_how)
{
  const char *str_how = S_how == R_NilValue? "NULL": CHAR(asChar(S_how));

      sigset_t sig_set;
      sigemptyset(&sig_set);
      sigaddset(&sig_set, SIGINT);

      int rc;
  if(strcmp(str_how, "BLOCK")==0)
  {
      rc = pthread_sigmask(SIG_BLOCK, &sig_set, NULL);
      fprintf(stderr, "pthread_sigmask(SIG_BLOCK...): %d\n", rc);
      sleep(30);
      rc = sigpending(&sig_set);
      fprintf(stderr, "sigpending(...): %d\n", rc);
      rc = sigismember(&sig_set, SIGINT);
      fprintf(stderr, "sigismember(&sig_set, SIGINT): %d\n", rc);
  }
  else if(strcmp(str_how, "UNBLOCK")==0)
  {
      rc = sigpending(&sig_set);
      fprintf(stderr, "sigpending(...): %d\n", rc);
      rc = sigismember(&sig_set, SIGINT);
      fprintf(stderr, "sigismember(&sig_set, SIGINT): %d\n", rc);

      rc = pthread_sigmask(SIG_UNBLOCK, &sig_set, NULL);
      fprintf(stderr, "pthread_sigmask(SIG_BLOCK...): %d\n", rc);
      sleep(30);

  } else {
     //warning(_("unknown 'how': %s"), str_how);
      rc = sigpending(&sig_set);
      fprintf(stderr, "sigpending(...): %d\n", rc);
      rc = sigismember(&sig_set, SIGINT);
      fprintf(stderr, "sigismember(&sig_set, SIGINT): %d\n", rc);
  }
  return R_NilValue;
}
*/

//static void (*R_sighandler)(int) = NULL;

/*
static supr_thread_t *intr_thread = NULL;

void *IntrThread_run(void *data)
{
  sigset_t sig_set;
  sigset_t old_sig_set;
  sigemptyset(&sig_set);
  sigaddset(&sig_set, SIGINT);
  int rc = pthread_sigmask(SIG_UNBLOCK, &sig_set, &old_sig_set);
  rc = sigismember(&old_sig_set, SIGINT);
  fprintf(stderr, "*. sigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);
  if(rc == 1){
    basic_info("SIGINT is blocked again (why?)");
  }

  supr_thread_t *cth = SUPR_CURRENT_THREAD();
//  sem_t sem; sem_init(&sem, 0, 0);
  while(TRUE){
    
    {
      rc = pthread_sigmask(SIG_UNBLOCK, &sig_set, &old_sig_set);
      rc = sigismember(&old_sig_set, SIGINT);
      fprintf(stderr, "*. sigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);
    }
	 
    double timeout = 30; // Supr_options.timeout;
    struct timespec wait;
    clock_gettime(CLOCK_REALTIME, &wait);
    wait.tv_sec += (long) timeout;

    pthread_mutex_lock(&cth->mutex);
      pthread_cond_timedwait(&cth->cond, &cth->mutex, &wait);
    pthread_mutex_unlock(&cth->mutex);


//	 int rc = sem_wait(&sem); basic_info(strerror(errno));
  }
}

void *IntrThread_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
                  (unsigned long) &data);
  *sth = th;

  free(th->name);
  char name[256];
  sprintf(name, "IntrThread.%d", gettid());
  th->name = strdup(name);
  th->state = THREAD_STATE_RUNNABLE;

  pthread_mutex_lock(sys_threads->mutex);
    vectorAdd(sys_threads, th);
  pthread_mutex_unlock(sys_threads->mutex);

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  IntrThread_run(data);

  pthread_exit(th);

  return NULL;
}


supr_thread_t *startIntrThread(void *data)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {data, &sem, &sth};
  int rc = pthread_create(&thread, NULL, IntrThread_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  return sth;
}
*/


SEXP R_cluster_eval(SEXP expr, SEXP x, SEXP envir,
	       SEXP error_handler,  SEXP par,
        SEXP env, SEXP wait, // SEXP dcl
	SEXP combine
	)
{
  if(TYPEOF(combine) != LGLSXP && TYPEOF(combine) != CLOSXP)
	  error(_("invalid 'combine' argument"));

 // if(!intr_thread) intr_thread = startIntrThread(NULL);
  supr_thread_t *cth = currentThread();

  //shm_io_info_t *io = __supr_context->driver_shm_io;
  shm_io_info_t *io = driver_shm_io;
  if(!io) error(_("driver_shm_io is not available"));

  
  if(Supr_options.debug)
    show_shm_io_info(io);

  pid_t driver_pid = io->out->pid;
  pid_t driver_tid = io->out->padding; // the ui to handle the cmd
  if(driver_tid==0)
    error(_("driver %d shm user interface is not available"), driver_pid);

  SEXP klass = getAttrib(x, R_ClassSymbol);
  if(TYPEOF(x) == STRSXP && klass != R_NilValue &&
		  strcmp(CHAR(asChar(klass)), "DD")==0){
     // TODO? 
  } else if(TYPEOF(x) != VECSXP){
    errorcall(R_NilValue, "not implemented for %s data type",
                    type2char(TYPEOF(x)));
  }

  SEXP val;
  int status = 0;

  char ref[32];
  sprintf(ref, "%d", driver_tid);

  cth->fun = R_cluster_eval_interrupt;
  cth->data = io;
  cth->properties = strdup(ref);

  {
      sigset_t sig_set;
      sigset_t old_sig_set;
      sigemptyset(&sig_set);
      sigaddset(&sig_set, SIGINT);
      int rc = pthread_sigmask(SIG_BLOCK, &sig_set, &old_sig_set);
      /*
      rc = sigismember(&old_sig_set, SIGINT);
      fprintf(stderr, "1. sigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);
      if(rc == 1){
	      basic_info("SIGINT is already blocked");
      }
      */
  }

  Supr_interrupt_enable();
  int job_id;

  RCNTXT cntxt;

  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);

    cntxt.cend = &Supr_onClusterEvalIntr;
    cntxt.cenddata = &status;


    if(!setjmp(cluster_eval_jmp_env)){

	    /*
      sigset_t sig_set;
      sigemptyset(&sig_set);
      sigaddset(&sig_set, SIGINT);
      int rc = pthread_sigmask(SIG_BLOCK, &sig_set, NULL);

      {
       // raise(SIGINT);
        sigset_t sig_set;
        rc = sigpending(&sig_set);
        fprintf(stderr, "\033[0;32msigpending(...): %d\n", rc);
        rc = sigismember(&sig_set, SIGINT);
        fprintf(stderr, "sigismember(&sig_set, SIGINT): %d\033[0m\n", rc);
        R_sighandler = signal(SIGINT, SIG_DFL);
      }
      */

      int cmd = DU_JOB_SUBMIT;
      size_t n = shm_io_write(io, io->out, &cmd, sizeof(int));
      job_id = shm_io_readInt(io);

      //basic_info("Read job_id");

      // args
      SEXP ee = PROTECT(allocVector(VECSXP, 3));
      SEXP expr_names = PROTECT(allocVector(STRSXP, 3));
      SET_VECTOR_ELT(ee, 0, expr);
      SET_VECTOR_ELT(ee, 1, envir);
      SET_VECTOR_ELT(ee, 2, ScalarInteger(job_id));
      SET_STRING_ELT(expr_names, 0, mkChar("expr"));
      SET_STRING_ELT(expr_names, 1, mkChar("envir"));
      SET_STRING_ELT(expr_names, 2, mkChar("id"));
      setAttrib(ee, R_NamesSymbol, expr_names);

      shm_io_writeSuprObject(io, ee);
      shm_io_writeSuprObject(io, x);

      shm_io_writeInt(io, LOGICAL(wait)[0]);
      UNPROTECT(2);

      // error.handler: for the driver
      shm_io_writeSuprObject(io, error_handler);
     
      // par: job-specific Cluster.sharedObjects
      shm_io_writeSuprObject(io, par);

      //basic_info("Sent par");
      const char *dcl_name = NULL; // dcl == R_NilValue ? NULL : CHAR(asChar(dcl));

#define __NOT_USE_DATACHANGELISTENER__
#ifndef __NOT_USE_DATACHANGELISTENER__
      if(dcl_name && strlen(dcl_name)){
        supr_thread_t *dcl_thread = NULL;
        pthread_mutex_lock(dcl_threads->mutex);
          for(int i=0; i<vectorSize(dcl_threads); i++){
            supr_thread_t *th = (supr_thread_t *)
		  vectorElementAt(dcl_threads,i);
	    if(strcmp(th->name, dcl_name)==0){
		dcl_thread = th;
		break;
	    }
          }
          if(!dcl_thread){
            SEXP error_handler = R_NilValue;
            SEXP new_dcl_name = R_NilValue;
            SEXP dcl_proc = R_TrueValue;

	  //{
	    //dcl_sc = socketOpen(__supr_context->driver_sc);
	    dcl_sc = socketOpen(driver_sc);
	    if(!dcl_sc)
	      error(_("cannot open socket connextion to Driver"));
	  //}

	  //{ // insert dcl_init?
	    SEXP args = PROTECT(CONS(mkString(dcl_name), R_NilValue));


//	    SET_TAG(args, install("name")); 
	    //fprintf(stderr,"[%s] dcl_name: %s\n", __func__, dcl_name);
	    SEXP dcl_init = PROTECT(LCONS(install(".Call"),
		    CONS(mkString("DCL_init"), args))); 
	    dcl_expr = PROTECT(LCONS(install("{"),
                        CONS(dcl_init, CONS(dcl_expr, R_NilValue))));
	    //PrintValue(dcl_expr);
	  //}
            SEXP th = Thread_new(dcl_expr, R_NilValue, error_handler,
		       	dcl_envir, new_dcl_name, dcl_proc);
	    dcl_thread = (supr_thread_t *) R_ExternalPtrAddr(th);
            pthread_mutex_lock(threads->mutex);
	      vectorRemoveElement(threads, dcl_thread);
            pthread_mutex_unlock(threads->mutex);

	    SEXP _ThreadEnv = findVar(install(".ThreadEnv"), R_GlobalEnv);

	  //Sync_lock(CAR(args)); ////
	    Thread_start(th, R_NilValue);

	    defineVar(install(dcl_thread->name), R_UnboundValue, _ThreadEnv);
	    vectorAdd(dcl_threads, dcl_thread);

	    //SEXP timeout = PROTECT(ScalarReal(60));
	    //Sync_wait(CAR(args), timeout); ////
	  //Sync_unlock(CAR(args)); ////

	    UNPROTECT(3);
	    if(dcl_sc){
              Supr_decref(dcl_sc);
	      dcl_sc = NULL;
	    }

	  // More to do ...
          }
        pthread_mutex_unlock(dcl_threads->mutex);

        struct timeval tv;
        fd_set readfds;

        tv.tv_sec=30;
        tv.tv_usec=50000;

        //int fd = __supr_context->driver_sc->fd;
        int fd = driver_sc->fd;
        FD_ZERO(&readfds);
        FD_SET(fd, &readfds);

        int ns = select(fd+1, &readfds, NULL, NULL, &tv);
        if(ns <= 0){
            printf("Warning: select(): %d\n", ns);
        } else {
	  int rc;
	  ssize_t  size = read(fd, &rc, INT_SIZE);
	  printf("recv/read: rc = %d\n", rc);
        }

      }
#endif // __NOT_USE_DATACHANGELISTENER__

#ifndef __NOT_USE_DATACHANGELISTENER__
      //printf("? dcl_name: %s\n", dcl_name);
      //shm_io_writeChar(io, dcl_name);

      //basic_info("Sent dcl_name");

      if(dcl_name && strlen(dcl_name))
        shm_io_writeInt(io, LOGICAL(dcl_sync)[0]);
#endif // __NOT_USE_DATACHANGELISTENER__

      job_id = shm_io_readInt(io);


      size_t size;

      //basic_info("Read job_id (why again?)");

      if(job_id == -1){ // FIXME?
        char *err = shm_io_read(io, io->in, &size, NULL);
	char buf[size];
	memcpy(buf, err, size);
	free(err);
        error(_("%s"), buf); // FIXME, get the error message ...
      }

      R_isInterrupted = FALSE;
      if(LOGICAL(wait)[0]) {

    
        char *ref = (char *) shm_io_read(io, io->in, &size, NULL);
        //printf("[%s] Read sync object reference: \"%s\"\n", __func__, ref);
        cth->properties = ref; // FIXME...

        cth->data = NULL;

  {
      sigset_t sig_set;
      sigset_t old_sig_set;
      sigemptyset(&sig_set);
      sigaddset(&sig_set, SIGINT);
      int rc = pthread_sigmask(SIG_UNBLOCK, &sig_set, &old_sig_set);
      /*
      rc = sigismember(&old_sig_set, SIGINT);
      fprintf(stderr, "5. sigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);
      rc = pthread_sigmask(SIG_UNBLOCK, &sig_set, &old_sig_set);
      rc = sigismember(&old_sig_set, SIGINT);
      if(rc == 1){
	      error_info("SIGINT is blocked again (why?)");
      } else {
	      error_info("SIGINT is unblocked");
      }
      */
  }




        so_t *so;
        so = (so_t*) shm_io_read(io, io->in, &size, NULL); // why?? interrupted

        if(size==0) {
	  basic_info(strerror(errno));
	  so = (so_t*) shm_io_read(io, io->in, &size, NULL);
	}
      
        val = SO_toRObject(so, size);
        free(so);


        if(cth->data == PTHREAD_INTERRUPTED){
          warning("interrupted cluster_eval");
          R_isInterrupted = TRUE;
	  val = newUserJob(job_id, combine, env); // future:
        }
        //PROTECT(val); PrintValue(val); UNPROTECT(1);
        free(cth->properties);
        cth->properties = NULL;
      } else {
        val = newUserJob(job_id, combine, env); 
      }

    } else {
      error(_("cancelled"));
      //util.c: shm_io_reset(shm_io_info_t *io, shm_io_block_t *in)
    }


  endcontext(&cntxt);

  Supr_interrupt_disable();
  {
      sigset_t sig_set;
      sigset_t old_sig_set;
      sigemptyset(&sig_set);
      sigaddset(&sig_set, SIGINT);
      int rc = pthread_sigmask(SIG_UNBLOCK, &sig_set, &old_sig_set);
      /*
      rc = sigismember(&old_sig_set, SIGINT);
      fprintf(stderr, "5. sigismember(&old_sig_set, SIGINT): %d\033[0m\n", rc);
      rc = pthread_sigmask(SIG_UNBLOCK, &sig_set, &old_sig_set);
      rc = sigismember(&old_sig_set, SIGINT);
      if(rc == 1){
	      error_info("SIGINT is blocked again (why?)");
      } else {
	      error_info("SIGINT is unblocked");
      }
      */
  }


  cth->fun =  NULL;
  cth->data = NULL;

  USE_R_SIGINT_HANDLER();

  defineVar(install(".LastValue"), val, SuprEnv);
  if(R_isInterrupted)
    error(_("interrupted job %d: check .GlobalEnv$.SuprEnv$.LastValue"),job_id);
    //raise(SIGINT);
  
  if(LOGICAL(wait)[0]) 
    return Job_combine(val, combine, env);
  else 
    return val;
}


void du_error_handler(void *data)
{
  SEXP *val = (SEXP *) data;
  printf("[%s] is called\n", __func__);
}

SEXP R_future(SEXP job, SEXP op, SEXP timeout)
{
  //shm_io_info_t *io = driver_io;//(shm_io_info_t *) R_ExternalPtrAddr(shm_conn);
  //shm_io_info_t *io = driver_io;// FIXME
  //if(!__supr_context) error(_("the supr context is not available"));
  //shm_io_info_t *io = __supr_context->driver_shm_io;
  shm_io_info_t *io = driver_shm_io;

  int job_id;
  if(TYPEOF(job) == EXTPTRSXP){
  } else {
    job_id = asInteger(job);
  }

  const char *cmd_name = CHAR(asChar(op));
  int cmd = DU_JOB_ISDONE;
  double _timeout;

  if(strcmp(cmd_name, "cancel") == 0){
    cmd = DU_JOB_CANCEL;
  } else if(strcmp(cmd_name, "is.done") == 0){
    cmd = DU_JOB_ISDONE;
    /*
  } else if(strcmp(cmd_name, "get") == 0){
    cmd = DU_JOB_GET;
    _timeout = asReal(timeout);
    */
  } else {
    errorcall(R_NilValue, "invalid argument '%s'", cmd_name);
  }

  R_isInterrupted = FALSE;
  R_setIntsigHandler();

  RCNTXT cntxt;
  SEXP val = R_NilValue;

  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);
    cntxt.cend = du_error_handler;
    cntxt.cenddata = &val;

    if(cmd == DU_JOB_GET){

      unsigned char args[2*sizeof(int)+sizeof(double)];
      ((int*)args)[0] = cmd;
      ((int*)args)[1] = job_id;
      ((double*)(args+2*sizeof(int)))[0] = _timeout;
      shm_io_write(io, io->out, args, sizeof(args));


    } else {
      int args[] = {cmd, job_id};
      shm_io_write(io, io->out, args, sizeof(args));

      fprintf(stderr, "[%s] OKAY 1\n", __func__);
    }

    size_t size;
    so_t *s = (so_t *) shm_io_read(io, io->in, &size, NULL); 
      fprintf(stderr, "[%s] OKAY 2\n", __func__);
    val = SO_toRObject(s, size);
    free(s);


  endcontext(&cntxt);

  R_resetIntsigHandler();

  return val;
}

so_t *URI_get(const char *uri, int remove)
{
    char uri_name[strlen(uri)+1];
    memcpy(uri_name, uri, sizeof(uri_name));

    char *host = strstr(uri_name, "//")+2;
    char *str = strstr(uri_name, ":");
    if(!str){
	    sprintf(Supr_curErrorBuf, "[%d@%s] invalid address: '%s'",
			    getpid(), Supr_hostname, uri);
	    error_info(Supr_curErrorBuf);

	    sleep(120);
	    raise(SIGSEGV);

	    char *buf = NULL;
	    Supr_debug2(getpid(), &buf);
	    if(buf) error_info(buf);
	    free(buf);
	    error(_("%s"), Supr_curErrorBuf);
    }
    *str = 0; str++;
    int port = atoi(str);
    char *data_name = strstr(str, "#")+1;

    //printf("[%s] Connecting %s:%d\n", __func__, host, port);
    int sc_fd = socket_client(host, port);
    //printf("[%s] Connecting %s:%d -> fd = %d\n", __func__, host, port, sc_fd);
    // check error...
    /*
    int cmd = TR_CLUSTER_GET;
    write(sc_fd, &cmd, sizeof(int));
    write(sc_fd, &remove, sizeof(int));

    int len = strlen(data_name)+1;
    write(sc_fd, &len, sizeof(int));
    write(sc_fd, data_name, len);
    */
    int len = strlen(data_name)+1;
    char bytes[3*sizeof(int)+len];
    int *x = (int*) bytes; x[0] = TR_CLUSTER_GET; x[1] = remove; x[2] = len;
    memcpy(bytes + 3*sizeof(int), data_name, len);
    write(sc_fd, bytes, sizeof(bytes));

    so_t so;
    //printf("[%s] Reading %s:%d\n", __func__, host, port);
    size_t size = socketRead(sc_fd, &so, sizeof(so_t));

    so_t *s = (so_t*) malloc(sizeof(so_t) + so.size);
    //printf("[%s] Reading %s:%d\n", __func__, host, port);
    size = socketRead(sc_fd, s +1, so.size);
    memcpy(s, &so, sizeof(so_t));
    s->ref_count = 1;

    //printf("[%s] Closing %s:%d\n", __func__, host, port);
    close(sc_fd);

    return s;
}

SEXP Cluster_getNumTaskrunners(SEXP x, SEXP env)
{
  int job_id = tr_cntxt.job_id;
  int tr_id  = tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;

  int args[] = {TR_NTASKRUNNERS, job_id, 0, 0};
  int cmd = TR_SEND_DRIVER;
  //size_t size = 0;
  size_t len = 0;

  char *monitor_name = NULL;

  fprintf(stderr, "[%s] type of x: %s\n", __func__, type2char(TYPEOF(x)));

  if(TYPEOF(x) == NILSXP){
	  /*
    shm_io_write(io, io->out, &cmd, sizeof(int));
    shm_io_write(io, io->out, args, sizeof(args));
    so_t *s = shm_io_read(io, io->in, &size, NULL);
    SEXP val = SO_toRObject(s, sizeof(so_t) + s->size);
    free(s);
    return val;
    */

  } else  if(TYPEOF(x) == LANGSXP){

    const char *x_str = CHAR(asChar(CADR(x)));
    //fprintf(stderr, "[%s] x_str: %s\n", __func__, x_str);
    if(strcmp(x_str, ".JobEnv")){
      const char *m_str = CHAR(asChar(CADDR(x)));
      //fprintf(stderr, "[%s] m_str: %s\n", __func__, m_str);
      //SEXP mutex = PROTECT(mkString(m_str));
      //SEXP val = TR_wait(mutex, r_timeout, env);
      //UNPROTECT(1);
      //return val;
      monitor_name = (char*) m_str;
      len = strlen(monitor_name)+1;
    } else {
      error(_("unimplemented type '%s'"), x_str);
    }

    /*
    if(Supr_threadType == 1) { //  local process ...
      return Supr_localProcSyncWait(x, r_timeout);
    } else if(Supr_threadType == 2) { //  remote  process ...
      return Supr_remoteProcSyncWait(x, r_timeout);
    }
    */
  } else {
    error(_("invalid '%s' argument"), "monitor");
  }


  //x = PROTECT(eval(x, env));

  shm_io_write(io, io->out, &cmd, sizeof(int));

  char buf[sizeof(args)+len];
  *((size_t *) (args + 2)) = len;
  memcpy(buf, args, sizeof(args));

  if(len)
    memcpy(buf + sizeof(args), monitor_name, len);


  shm_io_write(io, io->out, buf, sizeof(buf));

  /*
  fprintf(stderr, "[%s:%d] waiting\n", __func__, __LINE__);
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  int n = *((int*) ptr);
  free(ptr);
  fprintf(stderr, "[%s:%d] size = %ld, val = %d\n", __func__, __LINE__, size, n);
  return ScalarInteger(n);
  */

  so_t *s = shm_io_read(io, io->in, &len, NULL);
  SEXP val = SO_toRObject(s, sizeof(so_t) + s->size);
  free(s);
  return val;
}

SEXP Cluster_getRObject(SEXP addr, SEXP name, SEXP remove)
{
  const char *_addr = CHAR(asChar(addr));
  const char *_name = CHAR(asChar(name));
  char buf[strlen(_addr) + strlen(_name) + 2];
  sprintf(buf, "%s#%s", _addr, _name);
  int _remove = asLogical(remove);
  so_t *s = URI_get(buf, _remove);
  /*
  SEXP val = SO_toRObject(s, sizeof(so_t) + s->size);
  free(s);
  return val;
  */
  return SO_toRObj(s);
}


int (*get_shm_identityCode)(void) = NULL;
extern char *r2str(SEXP x, char *buf, int buf_size);

SEXP TR_combine(SEXP x, SEXP combine, SEXP env)
{
//MALLOC_MARK(0);
//MALLOC_MARK(__LINE__);
  int job_id = tr_cntxt.job_id;
  int tr_id  = tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;

  int args[] = {TR_COMBINE, job_id, tr_id, 0};
  SEXP result = R_NilValue;

  int pi;
  PROTECT_WITH_INDEX(x, &pi);

  //get_shm_identityCode = NULL;

  while(TRUE){
  
//MALLOC_MARK(__LINE__);
    char shm_name[256];
    int id_no = get_shm_identityCode ?  get_shm_identityCode() : 0;
    {
      size_t size; //void *raw = SUPR_serialize(x, env, &size);
      void *raw = SO_valueOf(x, &size); //so_t *SO_valueOf(SEXP r_object, size_t *length)

      sprintf(shm_name, "RTR_%d_TASK_%d_%d_%d", geteuid(), job_id, tr_id,
                      id_no);
      void *mem_ptr = rjni_shm_create(shm_name, size);

      memcpy(mem_ptr, raw, size);
      munmap(mem_ptr, size);

      //{ // FIXME???
	      fprintf(stderr, "[%s:%d] raw.size: %ld\n",__func__,__LINE__,
			      size);
	      free(raw);
      //}

      args[3] = id_no;
      shm_io_write(io, io->out, args, sizeof(args));
    }
    size_t size;

    so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
    void *ptr =  so; //shm_io_read(io, io->in, &size, NULL);

    if(so->obj_type == SUPR_UNBOUND_VALUE){ // the current x is the final result
      result = x;
//      printf("[%s] Received SUPR_UNBOUND_VALUE, keep it as the final result\n", __func__);
      free(so);
      shm_unlink(shm_name);
      break;
    } else if(so->obj_type == SUPR_NILSXP){
      result = R_NilValue; // done, without having the final result
//      printf("Received SUPR_NILSXP, done and take NULL to report\n");
      free(so);
      break;
    } else if(   so->obj_type == SUPR_SHM_NAME // data in shm
              || so->obj_type == SUPR_URI){
      shm_unlink(shm_name);
      SEXP y = R_NilValue;

      int buf_size = 256;
      char buf[buf_size];

      if(so->obj_type == SUPR_SHM_NAME){

	      /*
        {
          fprintf(stderr, "[%s] combine(x=%s, )\n", __func__,
                        r2str(x, buf, sizeof(buf)));
        }
        PrintValue(x);
	*/

        char *_shm_name = (char*) (ptr+sizeof(so_t)+sizeof(int));


        //fprintf(stderr, "size = %ld, strlen((char*)ptr) = %ld\n", size, strlen(_shm_name));
        //fprintf(stderr, "[%s] str = %s\n", __func__, _shm_name);

        void *mem_ptr = rjni_shm_open(_shm_name, &size); // fixme?
        //fprintf(stderr, "[%s] mem_ptr = %p\n", __func__, mem_ptr);

        if(!mem_ptr)
          //errorcall(R_NilValue, "[%s] %s", _shm_name, strerror(errno));
          error(_("[%s] %s"), _shm_name, strerror(errno));

        y = PROTECT(SO_toRObject(mem_ptr, size));

//      munmap(mem_ptr, size);
        munmap(mem_ptr, size);
//#define TESTING_NO_UNLINK
#ifndef TESTING_NO_UNLINK
      shm_unlink(_shm_name);
#endif


      //{
        //free(ptr);
      //}
//MALLOC_MARK(__LINE__);

      } else {
	char *uri = (char*) (so+1);
	//uri += sizeof(int);
//	printf("[%s] uri: %s\n", __func__, uri);
        so_t *s = URI_get(uri, 1);
        y = PROTECT(SO_toRObject(s, s->size+sizeof(so_t)));
	free(s);
      }

//MALLOC_MARK(__LINE__);
      /*
      {
        fprintf(stderr, "[%s] combine(, y=%s)\n", __func__,
                        r2str(x, buf, sizeof(buf)));
      }

      PrintValue(y);
      */

      if(TYPEOF(x) == NILSXP) { // fix me
        x = y;
        REPROTECT(x, pi);
        UNPROTECT(1);
      } else if(TYPEOF(y) == NILSXP) { // fix me
        UNPROTECT(1);
      } else {
        R_CheckUserInterrupt();
        SEXP call = PROTECT(LCONS(combine, CONS(x, CONS(y, R_NilValue))));
        x = eval(call, env);
        REPROTECT(x, pi);
//        UNPROTECT(3);
        UNPROTECT(2);
      }


      free(ptr);
//      fprintf(stderr, "[%s] combined value (x+%d): %d\n", __func__,
//                    INTEGER(y)[0], INTEGER(x)[0]);
//      printf("[%s] combined value:\n", __func__);
      /*
      {
        fprintf(stderr, "[%s] combined value: x=%s\n", __func__,
                        r2str(x, buf, sizeof(buf)));
      }
      PrintValue(x);
      */
    } else {
      char *buf = NULL;
      Supr_debug2(getpid(), &buf);
      if(buf) error_info(buf); 
      free(buf);

      errorcall(R_NilValue, "unknown so_object (%s:%d)",
			    __FILE__, __LINE__);
    }
  }
  UNPROTECT(1);
//MALLOC_MARK(__LINE__);
  return result;
}

static int rjni_strcmp(const void *a, const void *b)
{
  return strcmp(*((char **) a), *((char **) b));
}


// FIXME
size_t __read(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }
    }

    int n = read(fd, buf + len,  size - len);

    if(n <= 0){
            printf("[%s] read, n = %d, %s\n", __func__, n, strerror(errno));
            return -1;
//          errorcall(null, "read, n = %d, %s", n, strerror(errno));
    }

    /*  n = -1: If no messages are available at the socket, the receive calls wait  for
       a  message  to arrive, unless the socket is nonblocking (see fcntl(2)),
       in which case the value -1 is returned and the external variable  errno
       is set to EAGAIN or EWOULDBLOCK.  The receive calls normally return any
       data available, up to the requested amount,  rather  than  waiting  for
       receipt of the full amount requested.
       */

    len += n;
  }
}



so_t *SO_read(int fd)
{
  so_t so;
  size_t size;
  size = __read(fd, &so, sizeof(so_t));
  if(size != sizeof(so_t))
  {
    fprintf(stderr, "Fixme (%s:%d)", __FILE__, __LINE__);
    sleep(30);
  }
  so_t *s = (so_t *) malloc(sizeof(so_t) + so.size);
  memcpy(s, &so, sizeof(so_t));
  size = __read(fd, s+1, so.size);
  if(size != so.size)
  {
    fprintf(stderr, "Fixme (%s:%d)", __FILE__, __LINE__);
    sleep(30);
  }
  s->ref_count = 1;
  return s;
}

SEXP TR_combine_bykey(SEXP x, SEXP combine, SEXP env)
{
MALLOC_MARK(0);
MALLOC_MARK(__LINE__);
//	printf("[%s] %d\n", __func__, getpid());
  int job_id = tr_cntxt.job_id;
  int tr_id  = tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;

  int pi;
  PROTECT_WITH_INDEX(x, &pi);

  if(TYPEOF(x) == VECSXP){
    SEXP s = x;
    x =  PROTECT(allocSExp(ENVSXP));
    REPROTECT(x, pi);  
    UNPROTECT(1);
    SET_ENCLOS(x, R_EmptyEnv);
    SEXP keys = getAttrib(s, R_NamesSymbol);
    int len = LENGTH(keys);
    for(int i=0; i<len; i++){
      const char *key = CHAR(STRING_ELT(keys, i));
      if(key) defineVar(install(key), VECTOR_ELT(s, i), x);
    }
  } else if(TYPEOF(x) != ENVSXP){
    errorcall(R_NilValue, "invalid argument of type %s",
		    type2char(TYPEOF(x)));
  }

  SEXP keys = PROTECT(R_lsInternal(x, TRUE));
  int nkeys = LENGTH(keys);

  //if(nkeys == 0){ }

  // a simple implementation
  char **key_ptrs = malloc(nkeys*sizeof(char*));
  for(int i=0; i<nkeys; i++){
    //const char *key = CHAR(STRING_ELT(keys, i)); key_ptrs[i] = (char*) key;
    key_ptrs[i] = (char*) CHAR(STRING_ELT(keys, i));
  }
  qsort(key_ptrs, nkeys, sizeof(char *), rjni_strcmp);

//  SEXP rawVector = PROTECT(allocVector(VECSXP, nkeys));
  size_t size = sizeof(int) + nkeys*(2*sizeof(size_t));
  size_t key_size = 0;
  size_t val_size = 0;
//#ifdef USE_SUPR_SERIALIZE
  void  **raw_vector = malloc(nkeys*sizeof(void*)); // free?
  size_t *len_vector = malloc(nkeys*sizeof(size_t)); // free?
//#endif

  int __nkeys = nkeys;

  for(int i=0; i<nkeys; i++){
    const char *key = key_ptrs[i];
    printf("[%s] key[%d] %s\n", __func__, i, key);
    key_size  += strlen(key) + 1;
    SEXP val = findVar(install(key), x);

//#ifdef USE_SUPR_SERIALIZE
    size_t len;
//MALLOC_MARK(__LINE__);
    raw_vector[i] = SO_valueOf(val, &len); // SUPR_serialize(val, env, &len);
//MALLOC_MARK(__LINE__);
    len_vector[i] = len;
    val_size += sizeof(size_t) + len;
//#endif
  }
  size += key_size + val_size;

  // sizeof(size_t) = sizeof(void *)

  // qsort keys 
  /* shm_mem struct:
   * [len][keyAddr/Off][valAddr/Off]    
   * [[key ...0]]
   * [[size val ...]]
   */
  char shm_name[256]; // CBK - Combine By Key
  sprintf(shm_name, "RTR_%d_TASK_%d_%d_CBK", geteuid(), job_id, tr_id);
MALLOC_MARK(__LINE__);
  void *mem_ptr = rjni_shm_create(shm_name, size);
MALLOC_MARK(__LINE__);
  size_t key_offset = sizeof(int) + nkeys*(2*sizeof(size_t));
  size_t val_offset = key_offset + key_size;
  void *ptr = mem_ptr;
  *((int*) ptr) = nkeys;
  ptr += sizeof(int);
  size_t *idx = (size_t*)(mem_ptr + sizeof(int));
  for(int i=0; i<nkeys; i++){
    *idx = key_offset;
    *(idx + nkeys) = val_offset;
    idx++;
    const char *key = key_ptrs[i];
    memcpy(mem_ptr + key_offset, key, strlen(key)+1);
    key_offset += strlen(key)+1;

//#ifdef USE_SUPR_SERIALIZE
    size_t len = len_vector[i];
    memcpy(mem_ptr + val_offset, &len, sizeof(size_t));
    val_offset += sizeof(size_t);
    memcpy(mem_ptr + val_offset, raw_vector[i], len);
    val_offset += len;
//#endif
  }
  free(key_ptrs);
  // checking
  /*
  {
    int n = *((int*)mem_ptr);
    printf("[%s] nkeys = %d\n", __func__, n);
    size_t *_key_offset = (size_t*)(mem_ptr + sizeof(int));
    size_t *_val_offset = mem_ptr + sizeof(int) + n*sizeof(size_t);
    for(int i=0; i<n; i++){
      char *key = (char*)(mem_ptr + _key_offset[i]);
      printf("[%s] key[%d] = %s\n", __func__, i,  key);
      void *val = (void*)(mem_ptr + _val_offset[i] + sizeof(size_t));
      SEXP rval = PROTECT(LCONS(install("unserialize"),
		    CONS((SEXP) val, R_NilValue)));
      rval = PROTECT(eval(rval, env));
      PrintValue(rval);
      UNPROTECT(2);
    }
  }
  */

#define COMBINE_BYKEY_DEBUG
#ifdef COMBINE_BYKEY_DEBUG
  SEXP key_values = PROTECT(allocSExp(ENVSXP));
  SET_ENCLOS(key_values, R_EmptyEnv);
#endif

MALLOC_MARK(__LINE__);
  {
    int args[] = {TR_COMBINE_BYKEY, job_id, tr_id, nkeys};
    char *buf = malloc(sizeof(args)+ strlen(shm_name)+1 + key_size);
    memcpy(buf, args, sizeof(args));
    memcpy(buf + sizeof(args), shm_name, strlen(shm_name)+1);
    size_t offset = sizeof(args)+ strlen(shm_name)+1;

    int n = *((int*)mem_ptr);
    memcpy(buf + offset, mem_ptr + sizeof(int)+2*n*sizeof(size_t), key_size);
    size_t *_key_offset = (size_t*)(mem_ptr + sizeof(int));

    char keySeparator = ';';
    char *str = buf + sizeof(args)+ strlen(shm_name);
    for(int i=0; i<key_size; i++) {
      if(str[i] == 0) str[i] = keySeparator;
    }

    printf("[%s] buf+ = %s\n", __func__, buf+sizeof(args));
    //sendDriverMessage(io, job_id, tr_id, buf+sizeof(args));
    
    shm_io_write(io, io->out, buf, sizeof(args)+strlen(shm_name)+1 + key_size);

    //{ // FIXME?
	    free(buf);
    //}
  }
  munmap(mem_ptr, size);
MALLOC_MARK(__LINE__);
 
  int cbk_rc = -1; // return code
  //SEXP ret_val = R_UnboundValue;
  int key_idx = 0;
//////////////////////////////// 
  while(TRUE)
  {
    size_t size;
    //char *_shm_name; //??
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    printf("[%s:%d] size = %ld, val = %d\n", __func__, __LINE__,
		    size, ((char *)ptr)[0]);

    if(size == 1) {
	    free(ptr);
	    break;
    }

    char *str = (char*) ptr;
#define SEPARATOR ';'
    printf(" * [%s]  Received = %s\n", __func__, str);
    char *key = str;
    while(*str){
      //printf(" ~ ~ [%s]  %s\n", __func__, key);
      if(*str == SEPARATOR){ *str = 0; str++; break; }
      str++;
    }
    printf(" ~ [%s]  key = %s\n", __func__, key);
    char dupkey[strlen(key)+1];
    sprintf(dupkey, "%s", key);
    key = dupkey;

    int i=0;

    SEXP reduced = R_UnboundValue;
    int pi;
    PROTECT_WITH_INDEX(reduced, &pi);

    printf("\n\033[0;34m[%s:%d] local combine, key = %s\033[0m\n",
		    __func__, __LINE__, key);
    while(TRUE){ // local combine
      char *shm_name = str;
      if(*str == 0) break;
      while(*str){
        if(*str == SEPARATOR){ *str = 0; str++; break; }
        str++;
      }
      i++;
      printf(" ~ [%d]  shm_name = %s\n\n", i, shm_name);

      {
	size_t size;
        void *mem_ptr = rjni_shm_open(shm_name, &size); // fixme?

        int n = *((int*)mem_ptr);
        printf("[%s] nkeys = %d\n", __func__, n);
        size_t *_key_offset = (size_t*)(mem_ptr + sizeof(int));
	int idx = 0;
	for(; idx < n; idx++){ // use bsearch ??? later ...
          char *__key = (char*)(mem_ptr + _key_offset[idx]);
          if(strcmp(key, (char*)(mem_ptr + _key_offset[idx]))==0)
	    break;
	}
	if(idx == n) 
          errorcall(R_NilValue, "ERROR (%s, %d)", __FILE__, __LINE__);

        size_t *_val_offset = mem_ptr + sizeof(int) + n*sizeof(size_t);

	size_t len = *((size_t *) (mem_ptr + _val_offset[idx]));
        void *val = (void*)(mem_ptr + _val_offset[idx] + sizeof(size_t));
	SEXP rval = PROTECT(SO_toRObject(val, len));
        rval = PROTECT(eval(rval, env));
	printf("Value: \n");
        PrintValue(rval);

	if(reduced == R_UnboundValue){
	  reduced = rval;
	} else {
          SEXP call = PROTECT(LCONS(combine,
		  CONS(reduced, CONS(rval, R_NilValue))));
	  reduced = eval(call, env);
	  UNPROTECT(1);
	}
	REPROTECT(reduced, pi);
        UNPROTECT(2);

	printf("key = %s, Reduced Value: \n", key);
        PrintValue(reduced);

	munmap(mem_ptr, size);
	  
      }
    }


    if(str != ptr + size - 1){
      char *str = (char*) ptr;
      fprintf(stderr, "CHECK: %s\n", str);
      while(*str && *str != ';'){
	      str++;
      }
      str++;
      fprintf(stderr, "CHECK: %d (%c)\n", *(str-1), *(str-1));
      fprintf(stderr, "CHECK: %s\n", str);
      errorcall(R_NilValue, "ERROR (%s, %d)", __FILE__, __LINE__);
    }

    printf("\n\033[0;32m[%s:%d] Cluster-level combine, key = %s\033[0m\n",
		    __func__, __LINE__, key);
    while(TRUE) { // cluster-level combine

      SEXP call = R_NilValue; 
      SEXP raw = R_NilValue; 
     
      size_t size;
      so_t *so = SO_valueOf(reduced, &size);

      char shm_name[256]; // CBK - Combine By Key
      sprintf(shm_name, "RTR_%d_TASK_%d_%d_CBK_%d", geteuid(),
		      job_id, tr_id, key_idx++);
     
MALLOC_MARK(__LINE__);
      void *mem_ptr = rjni_shm_create(shm_name, size);
MALLOC_MARK(__LINE__);
      memcpy(mem_ptr, so, size);
      /*
      {
	 printf("====================================================\n");
	 printf("[%s:%d] Testing SO_valueOf and SO_toRObject:\n",
			 __func__, __LINE__);
      for(int i=0; i<so->size +sizeof(so_t); i++){
        printf(" %02d", ((unsigned char*)so)[i]);
	if((1+i)%8==0) printf("\n");
      }
      printf("\n");
	 printf("[%s:%d] shm_name: //%s:%d#%s ,size=%ld\n", __func__, __LINE__,
			 tr_cntxt.host, tr_cntxt.port,
			 shm_name, size);
	 PrintValue(reduced);
         SEXP rval = PROTECT(SO_toRObject(mem_ptr, so->size+sizeof(so_t)));
	 PrintValue(rval);
	 printf("====================================================\n");
	 UNPROTECT(1);
      }
      */
      munmap(mem_ptr, size);

      //{ // FIXME?
	      free(so);
      //}

      // CL: cluster-level?
      char key_value[strlen(key)+1+strlen(shm_name)+1];
#define STRING_SEPARATOR '\n'

      sprintf(key_value, "%s%c%s", key, STRING_SEPARATOR, shm_name);
#undef STRING_SEPARATOR
      int len = strlen(key_value)+1;
      int args[] = {TR_COMBINE_BYKEY, job_id, tr_id, len};
      char buf[sizeof(args)+strlen(key_value)+1];
      memcpy(buf, args, sizeof(args));
      memcpy(buf + sizeof(args), key_value, len);

      int cmd = TR_SEND_DRIVER;
      shm_io_write(io, io->out, &cmd, sizeof(int));
      shm_io_write(io, io->out, buf, sizeof(buf));

      //char *_shm_name; //??
      void *ptr = shm_io_read(io, io->in, &size, NULL);
      //printf("[%s:%d] size = %ld, val = %d\n", __func__, __LINE__, size, ((char *)ptr)[0]);

      so_t *s = (so_t *) ptr;
      printf("\033[0;33m[%s:%d] Received obj_type = %d\033[0m\n",
		      __func__, __LINE__, s->obj_type);
      
      if(s->obj_type <= 2 ){
        cbk_rc = s->obj_type;
#ifdef COMBINE_BYKEY_DEBUG
	if(cbk_rc <= 1){ // the current value is the final result for the key
          defineVar(install(key), mkString(shm_name), key_values);
	}
#endif
        free(ptr);
        break;
      }  else if (s->obj_type  != SUPR_URI){
         errorcall(R_NilValue, "obj_type: %d FIXME (%s:%d)", s->obj_type,
			 __FILE__, __LINE__);
      }

      shm_unlink(shm_name);

      // URI
      char *uri = (char*) (s+1);
      //uri += sizeof(int);
      printf("[%s:%d] key: %s, uri: %s\n", __func__, __LINE__, key, uri);
      //s = URI_get(uri, 1);
      s = URI_get(uri, 0);
      printf("[%s:%d] size: %ld\n", __func__, __LINE__, s->size +sizeof(so_t));
      /*
      for(int i=0; i<s->size +sizeof(so_t); i++){
        printf(" %02d", ((unsigned char*)s)[i]);
	if((i+1)%8==0) printf("\n");
      }
      printf("\n");
      */
      free(ptr);
      SEXP rval = PROTECT(SO_toRObject(s, s->size+sizeof(so_t)));
      free(s);

      call = PROTECT(LCONS(combine, CONS(reduced, CONS(rval, R_NilValue))));
      reduced = eval(call, env);
      REPROTECT(reduced, pi);

      UNPROTECT(2);

      printf("\033[0;33mCluster-level combined value: \n\033[0m");
      PrintValue(reduced);
    }

    printf("\n");

    UNPROTECT(1); // reduced
    free(ptr);
#undef SEPARATOR

    // TODO
    //break;
    int args[] = {TR_COMBINE_BYKEY, job_id, tr_id};
    shm_io_write(io, io->out, args, sizeof(args));
  }

  UNPROTECT(2);

#ifdef COMBINE_BYKEY_DEBUG
  keys = PROTECT(R_lsInternal(key_values, TRUE));
  nkeys = LENGTH(keys);
  SEXP val = PROTECT(allocVector(STRSXP, nkeys));
  SEXP names = PROTECT(allocVector(STRSXP, nkeys));
  for(int i=0; i<nkeys; i++){
    SEXP key = STRING_ELT(keys, i);
    SEXP elem = findVar(install(CHAR(key)), key_values);
    SET_STRING_ELT(val, i, STRING_ELT(elem, 0));
    SET_STRING_ELT(names, i, key);
  }
  setAttrib(val, R_NamesSymbol, names);
  printf("[%s:%d] workerServer: %s:%d\n", __func__, __LINE__,
		  tr_cntxt.host, tr_cntxt.port);
  //
  char buf[strlen(tr_cntxt.host)+64];
  sprintf(buf, "//%s:%d", tr_cntxt.host, tr_cntxt.port);
  setAttrib(val, install("location"), mkString(buf));
 //
  UNPROTECT(3); // key_values
  UNPROTECT(1); // key_values
  //{ // FIXME?
    for(int i=0; i < __nkeys;  i++){
      free(raw_vector[i]);
    }
    free(raw_vector);
    free(len_vector);
  //}
MALLOC_MARK(__LINE__);
  return val;
#else
  //{ // FIXME?
    for(int i=0; i < __nkeys;  i++){
      free(raw_vector[i]);
    }
    free(raw_vector);
    free(len_vector);
  //}
MALLOC_MARK(__LINE__);
  return ScalarLogical(cbk_rc); 
#endif

  //return ScalarLogical(cbk_rc == 0); // combine_bykey is finished
                                     // Driver/rjobs[job-id]/result
}

#define ADD_JOBID_TO_MUTEX

static vector_t *syncMutexVector = NULL;

void sync_error_handle(void *data)
{
  char *m = (char*) vectorRemove(syncMutexVector,
		  vectorSize(syncMutexVector)-1);

  shm_io_info_t *io = tr_cntxt.io;
  
  char args[sizeof(int)+strlen(m)+1];
  ((int*)args)[0] = TR_CLUSTER_UNSYNC;
  memcpy(args+sizeof(int), m, strlen(m)+1);

  shm_io_write(io, io->out, args, sizeof(args));

  size_t size;
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  free(ptr);
}


SEXP TR_sync_eval(SEXP expr, SEXP mutex, SEXP env)
{
//MALLOC_MARK(0);
//MALLOC_MARK(__LINE__);
  const char *m = CHAR(asChar(mutex));

#ifdef ADD_JOBID_TO_MUTEX
  char mutex_buf[strlen(m)+64];
  sprintf(mutex_buf, "%s.%d", m, tr_cntxt.job_id);
  m = mutex_buf;
#endif

  if(!syncMutexVector) {
    syncMutexVector = newVector(FALSE);
  }

  int i = vectorSize(syncMutexVector)-1;
  for(; i>=0; i--){
    char *s = (char*) vectorElementAt(syncMutexVector, i);
    if(strcmp(s, m)==0) {
      errorcall(R_NilValue, "already synchronized on '%s'", m);
    }
  } //int job_id = tr_cntxt.job_id; //int tr_id =  tr_cntxt.tr_id;

  shm_io_info_t *io = tr_cntxt.io;

  if(!io){
      errorcall(R_NilValue, "tr_cntxt.io is not available");
  }

  char args[sizeof(int)+strlen(m)+1];
  ((int*)args)[0] = TR_CLUSTER_SYNC;
  memcpy(args+sizeof(int), m, strlen(m)+1);
  //printf("[%s] synchronizing... ", __func__);
  shm_io_write(io, io->out, args, sizeof(args));
  size_t size;

  void *ptr = shm_io_read(io, io->in, &size, NULL);
  int rc = ((int*)ptr)[0];
  free(ptr);

  if(rc == 2){
	  error(_("JOB CANCELLED"));
  }

  //printf("[%s] synchronized (rc: %d)\n ... eval: ...\n", __func__, rc);

  vectorAdd(syncMutexVector, (char*) m);
  //printf("[%s] syncMutexVector: %s\n ... eval: ...\n", __func__, objectToString(syncMutexVector));

  RCNTXT cntxt;
  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);
    cntxt.cend = &sync_error_handle;
    cntxt.cenddata = args; 

MALLOC_MARK(__LINE__);
    SEXP val = PROTECT(eval(expr, env));
MALLOC_MARK(__LINE__);
    //PrintValue(expr);
    //PrintValue(val);
    UNPROTECT(1);

  endcontext(&cntxt);


  vectorRemove(syncMutexVector, vectorSize(syncMutexVector)-1);
  //printf("[%s] syncMutexVector: %s\n ... eval: ...\n", __func__, objectToString(syncMutexVector));

  ((int*)args)[0] = TR_CLUSTER_UNSYNC;
  shm_io_write(io, io->out, args, sizeof(args));
  ptr = shm_io_read(io, io->in, &size, NULL);
  rc = ((int*)ptr)[0];
  if(rc == -1){
	  error(_("JOB CANCELLED"));
  }
  free(ptr);

  //printf("[%s] desynchronized (rc: %d)\n", __func__, rc);

//MALLOC_MARK(__LINE__);
  return val;
}

SEXP TR_isSynchronized(SEXP monitor)
{
  const char *m = CHAR(STRING_ELT(monitor,0));
  int i = vectorSize(syncMutexVector)-1;
  for(; i>=0; i--){
    char *s = (char*) vectorElementAt(syncMutexVector, i);
    if(strcmp(s, m)==0) break;
  }
  return ScalarLogical(i >= 0);
}

// time: a serialized expr
SEXP TR_wait(SEXP monitor, SEXP time, SEXP env)
{
//MALLOC_MARK(__LINE__);
  //const char *m = CHAR(STRING_ELT(monitor,0));
  const char *m = CHAR(STRING_ELT(monitor,0));

#ifdef ADD_JOBID_TO_MUTEX
  char mutex_buf[strlen(m)+64];
  sprintf(mutex_buf, "%s.%d", m, tr_cntxt.job_id);
  m = mutex_buf;
#endif

  // checking ..
  int i = vectorSize(syncMutexVector)-1;
  for(; i>=0; i--){
    char *s = (char*) vectorElementAt(syncMutexVector, i);
    if(strcmp(s, m)==0) break;
  }
  if(i < 0) errorcall(R_NilValue, "attempt to wait on unsynchronized '%s'", m);

  //int job_id = tr_cntxt.job_id;
  //int tr_id = tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;

// supr.h #define TR_WAIT_USE_TIME_EXPR
  double dtime = 0;
#ifndef TR_WAIT_USE_TIME_EXPR
  
  if(TYPEOF(time) == REALSXP){
    dtime = REAL(time)[0];
  } else if(TYPEOF(time) == INTSXP){
    dtime = INTEGER(time)[0];
  }
#endif
 

  char args[sizeof(int)+ sizeof(double)+ strlen(m)+1];
  ((int*)args)[0] = TR_CLUSTER_WAIT;
  ((double*)(args+sizeof(int)))[0] = dtime;
  memcpy(args+sizeof(int)+sizeof(double), m, strlen(m)+1);
  shm_io_write(io, io->out, args, sizeof(args));

#ifdef TR_WAIT_USE_TIME_EXPR
  shm_io_write(io, io->out, RAW(time), LENGTH(time));
#endif


  printf("\033[0;31m[%s] wait... \n", __func__);

  size_t size;
  //char *shm_name =NULL;
  void *ptr = shm_io_read(io, io->in, &size, NULL);


  SEXP rc;
  if(((int*)ptr)[0]==-1){
    if(((int*)ptr)[1]==-1){
      error(_("%s"), ((char*)ptr)+2*sizeof(int));
    } else {
      double *v = (double*)(ptr+2*sizeof(int));
      rc = ScalarReal(v[0]);
    }
  } else if(((int*)ptr)[0]==2){
	  error(_("JOB CANCELLED"));
  } else {
    rc = ScalarInteger(((int*)ptr)[0]);
  }
  printf("[%s] woken up, rc = %d\n", __func__, INTEGER(rc)[0]);
  free(ptr);

//MALLOC_MARK(__LINE__);
  return rc;
}

SEXP TR_notify(SEXP monitor,  SEXP all, SEXP env)
{
//MALLOC_MARK(__LINE__);
  //const char *m = CHAR(STRING_ELT(monitor,0));
  const char *m = CHAR(asChar(monitor));

#ifdef ADD_JOBID_TO_MUTEX
  char mutex_buf[strlen(m)+64];
  sprintf(mutex_buf, "%s.%d", m, tr_cntxt.job_id);
  m = mutex_buf;
#endif

  // checking ..
  int i = vectorSize(syncMutexVector)-1;
  for(; i>=0; i--){
    char *s = (char*) vectorElementAt(syncMutexVector, i);
    if(strcmp(s, m)==0) break;
  }
  if(i < 0)
    errorcall(R_NilValue,"attempt to notify on unsynchronized '%s'", m);
  

  //int job_id = tr_cntxt.job_id;
  //int tr_id = tr_cntxt.job_id;
  shm_io_info_t *io = tr_cntxt.io;


  char args[sizeof(int) + strlen(m)+1];
  ((int*)args)[0] = INTEGER(all)[0] ==0 ?
          TR_CLUSTER_NOTIFY: TR_CLUSTER_NOTIFYALL;
  memcpy(args+sizeof(int), m, strlen(m)+1);
  shm_io_write(io, io->out, args, sizeof(args));

  printf("[%s] wait... \n", __func__);

  size_t size;
  //char *shm_name =NULL;
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  SEXP rc = ScalarInteger(((int*)ptr)[0]);
  free(ptr);

//MALLOC_MARK(__LINE__);

  return rc;
}


Rboolean TR_exist_par(SEXP name, SEXP rjob_id)
{
  int job_id = tr_cntxt.job_id;
  if(job_id<0) // error(_("not a taskrunner session"));
  {
    job_id = asInteger(rjob_id);
    int tr_id = -1;
    const char * c_name = CHAR(STRING_ELT(name, 0));
    int args[] = {CLUSTER_BYTE_MSG,TR_EXIST_PAR,job_id,tr_id, strlen(c_name)+1};
    unsigned char bytes[sizeof(args)+strlen(c_name)+1];
    memcpy(bytes, args, sizeof(args));
    memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);

    int fd = -1;
    //{
      SEXP driver = findVar(install("driver"), SuprContextEnv);
      if(driver != R_UnboundValue){
        SEXP scPtr = getAttrib(driver, install("conn"));
        supr_socket_conn_t * sc = (supr_socket_conn_t *)
                R_ExternalPtrAddr(scPtr);
        if(sc) fd = sc->fd;
      }
    //}
    if(fd == -1) error(_("cannot find the driver connection"));

    write(fd, bytes, sizeof(args)+strlen(c_name)+1);
    so_t *so = SO_read(fd);
    /*
    size_t size = sizeof(so) + so->size;
    SEXP val = SO_toRObject(so, size);
    free(so);
    return asLogical(val);
    */
    return asLogical(SO_toRObj(so));
  }

  int tr_id =  tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;
  if(io == NULL) error(_("connection 'shm_io' not available"));

  if(TYPEOF(rjob_id) != NILSXP)
    job_id = asInteger(rjob_id);
  
  const char *c_name = CHAR(STRING_ELT(name, 0));
  unsigned char bytes[4*sizeof(int)+strlen(c_name)+1];
  int args[] = {TR_EXIST_PAR, job_id, tr_id, strlen(c_name)+1};

  memcpy(bytes, args, sizeof(args));
  memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));
  shm_io_write(io, io->out, bytes, sizeof(bytes));

  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  /*
  SEXP val = SO_toRObject(so, size);
  free(so);
  return asLogical(val);
  */
  return asLogical(SO_toRObj(so));
}



SEXP TR_objects_par(SEXP rjob_id)
{
  int job_id = tr_cntxt.job_id;
  if(job_id<0) // error(_("not a taskrunner session"));
  {
    job_id = asInteger(rjob_id);
    int tr_id = -1;
    int args[] = {CLUSTER_BYTE_MSG, TR_LIST_PAR, job_id, tr_id};

    int fd = -1;
    //{
      SEXP driver = findVar(install("driver"), SuprContextEnv);
      if(driver != R_UnboundValue){
        SEXP scPtr = getAttrib(driver, install("conn"));
        supr_socket_conn_t * sc = (supr_socket_conn_t *)
                R_ExternalPtrAddr(scPtr);
        if(sc) fd = sc->fd;
      }
    //}
    if(fd == -1) error(_("cannot find driver connection"));

    write(fd, args, sizeof(args));
    so_t *so = SO_read(fd);
    /*
    size_t size = sizeof(so) + so->size;
    SEXP val = SO_toRObject(so, size);
    free(so);
    return val;
    */
    return SO_toRObj(so);
  }

  int tr_id =  tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;
  if(io == NULL) error(_("connection 'shm_io' not available"));

  if(TYPEOF(rjob_id) != NILSXP)
    job_id = asInteger(rjob_id);
  
  int args[] = {TR_LIST_PAR, job_id, tr_id};

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));
  shm_io_write(io, io->out, args, sizeof(args));

  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  /*
  SEXP val = SO_toRObject(so, size);
  free(so);
  return val;
  */
  return SO_toRObj(so);
}


int TR_remove_par(SEXP name, SEXP rjob_id)
{
  int job_id = tr_cntxt.job_id;
  if(job_id<0) // error(_("not a taskrunner session"));
  {
    job_id = asInteger(rjob_id);
    int tr_id = -1;
    const char * c_name = CHAR(STRING_ELT(name, 0));
    int args[] = {CLUSTER_BYTE_MSG,TR_REMOVE_PAR,job_id,tr_id, strlen(c_name)+1};
    unsigned char bytes[sizeof(args)+strlen(c_name)+1];
    memcpy(bytes, args, sizeof(args));
    memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);

    int fd = -1;
    //{
      SEXP driver = findVar(install("driver"), SuprContextEnv);
      if(driver != R_UnboundValue){
        SEXP scPtr = getAttrib(driver, install("conn"));
        supr_socket_conn_t * sc = (supr_socket_conn_t *)
                R_ExternalPtrAddr(scPtr);
        if(sc) fd = sc->fd;
      }
    //}
    if(fd == -1) error(_("cannot find driver connection"));

    write(fd, bytes, sizeof(args)+strlen(c_name)+1);
    so_t *so = SO_read(fd);
    /*
    size_t size = sizeof(so) + so->size;
    SEXP val = SO_toRObject(so, size);
    free(so);
    return asInteger(val);
    */
    return asInteger(SO_toRObj(so));
  }

  int tr_id =  tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;
  if(io == NULL) error(_("connection 'shm_io' not available"));

  if(TYPEOF(rjob_id) != NILSXP)
    job_id = asInteger(rjob_id);
  
  const char *c_name = CHAR(STRING_ELT(name, 0));
  unsigned char bytes[4*sizeof(int)+strlen(c_name)+1];
  int args[] = {TR_REMOVE_PAR, job_id, tr_id, strlen(c_name)+1};

  memcpy(bytes, args, sizeof(args));
  memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));
  shm_io_write(io, io->out, bytes, sizeof(bytes));

  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  /*
  SEXP val = SO_toRObject(so, size);
  free(so);
  return asInteger(val);
  */
  return asInteger(SO_toRObj(so));
}



SEXP TR_put_par(SEXP name, SEXP value, SEXP rjob_id) {
  int job_id = tr_cntxt.job_id;
  if(job_id<0) {
    job_id = asInteger(rjob_id);
    int tr_id = -1;
    const char * c_name = CHAR(STRING_ELT(name, 0));
    size_t len;
    void *raw = SO_valueOf(value, &len);
    int args[] = {CLUSTER_BYTE_MSG, TR_PUT_PAR, job_id,tr_id, strlen(c_name)+1};
    unsigned char bytes[sizeof(args)+strlen(c_name)+1+len];
    memcpy(bytes, args, sizeof(args));
    memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);
    memcpy(bytes+sizeof(args) + strlen(c_name)+1, raw, len);
    free(raw); //

    int fd = -1;
    //{
      SEXP driver = findVar(install("driver"), SuprContextEnv);
      if(driver != R_UnboundValue){
        SEXP scPtr = getAttrib(driver, install("conn"));
        supr_socket_conn_t * sc = (supr_socket_conn_t *)
                R_ExternalPtrAddr(scPtr);
        if(sc) fd = sc->fd;
      }
    //}
    if(fd == -1) error(_("cannot find driver connection"));

    write(fd, bytes, sizeof(args)+strlen(c_name)+1+len);

    so_t *so = SO_read(fd);
    /*
    size_t size = sizeof(so) + so->size;
    SEXP val = SO_toRObject(so, size);
    free(so); //
    return val;
    */
    return SO_toRObj(so);
  }

  int tr_id =  tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;
  if(io == NULL) error(_("no taskrunner connection"));

  if(TYPEOF(rjob_id) != NILSXP) job_id = asInteger(rjob_id);
  
  const char * c_name = CHAR(STRING_ELT(name, 0));

  size_t len;
  void *raw = SO_valueOf(value, &len);

  // use malloc
  unsigned char bytes[4*sizeof(int)+strlen(c_name)+1+len];
  int args[] = {TR_PUT_PAR, job_id, tr_id, strlen(c_name)+1};
  memcpy(bytes, args, sizeof(args));
  memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);
  memcpy(bytes+sizeof(args) + strlen(c_name)+1, raw, len);
  free(raw); //

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));
  shm_io_write(io, io->out, bytes, sizeof(bytes));

  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  /*
  SEXP val = SO_toRObject(so, size);
  free(so); //
  return val;
  */
  return SO_toRObj(so);
}





SEXP TR_get_par(SEXP name, SEXP rjob_id)
{
  int job_id = tr_cntxt.job_id;
  if(job_id<0) // error(_("not a taskrunner session"));
  {
    job_id = asInteger(rjob_id);
    int tr_id = -1;
    const char * c_name = CHAR(STRING_ELT(name, 0));
    int args[] = {CLUSTER_BYTE_MSG,TR_GET_PAR, job_id, tr_id, strlen(c_name)+1};
    unsigned char bytes[sizeof(args)+strlen(c_name)+1];
    memcpy(bytes, args, sizeof(args));
    memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);

    int fd = -1;
    //{
      SEXP driver = findVar(install("driver"), SuprContextEnv);
      if(driver != R_UnboundValue){
        SEXP scPtr = getAttrib(driver, install("conn"));
        supr_socket_conn_t * sc = (supr_socket_conn_t *)
                R_ExternalPtrAddr(scPtr);
        if(sc) fd = sc->fd;
      }
    //}
    if(fd == -1) error(_("cannot find driver connection"));

    write(fd, bytes, sizeof(args)+strlen(c_name)+1);
    so_t *so = SO_read(fd);

    /*
    size_t size = sizeof(so) + so->size;
    if(so->obj_type == SUPR_ERROR){
      SEXP err = mkChar((char*)(so+1));
      free(so);
      error(_("%s"), CHAR(err)); 
    }

    SEXP val = SO_toRObject(so, size);
    free(so);
    return val;
    */
    return SO_toRObj(so);

  }

  int tr_id =  tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;
  if(io == NULL) {
    return R_UnboundValue;
  }

  if(TYPEOF(rjob_id) != NILSXP)
    job_id = asInteger(rjob_id);
  
  const char *c_name = CHAR(STRING_ELT(name, 0));
  unsigned char bytes[4*sizeof(int)+strlen(c_name)+1];
  int args[] = {TR_GET_PAR, job_id, tr_id, strlen(c_name)+1};

  memcpy(bytes, args, sizeof(args));
  memcpy(bytes+sizeof(args), c_name, strlen(c_name)+1);

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));
  shm_io_write(io, io->out, bytes, sizeof(bytes));

  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  /*
  if(so->obj_type == SUPR_ERROR){
    SEXP err = mkChar((char*)(so+1));
    free(so);
    error(_("%s"), CHAR(err)); 
  }
  SEXP val = SO_toRObject(so, size);
  free(so);
  return val;
  */
  return SO_toRObj(so);
}


// create a countdown object at the driver, if not exists 
// FIXME...
/*
SEXP TR_countdown(SEXP name, SEXP max_count, SEXP arg_list)
{
  int job_id = tr_cntxt.job_id;
  int tr_id  = tr_cntxt.tr_id; 
  shm_io_info_t *io = tr_cntxt.io;

  const char *cname = CHAR(STRING_ELT(name, 0));
  int args[] = {TR_COUNTDOWN_CREATE, job_id, tr_id, INTEGER(max_count)[0],
	  strlen(cname)+1};
  size_t size = sizeof(args) +  (strlen(cname)+1);

  size_t s_size;
  so_t *so = SO_valueOf(arg_list, &s_size);
  
  size += s_size;

  void *buf = malloc(size);
  memcpy(buf, args, sizeof(args));
  memcpy(buf +  sizeof(args), cname, strlen(cname)+1);
  memcpy(buf +  sizeof(args) +strlen(cname)+1, so, s_size);

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));

  shm_io_write(io, io->out, buf, size);
  free(buf);

  so = (so_t*) shm_io_read(io, io->in, &size,  NULL);

  SEXP val = SO_toRObject(so, size);
  free(so);

  PrintValue(val);

  return val;
}


// count: more generally Condition? 
// list: a list of key-value pairs
SEXP TR_countAndGet(SEXP countdown, SEXP list)
{
MALLOC_MARK(__LINE__);
  int job_id = tr_cntxt.job_id;
  int tr_id  = tr_cntxt.tr_id; 
  shm_io_info_t *io = tr_cntxt.io;

  const char *name = CHAR(asChar(countdown));
  int len = strlen(name)+1;

  int args[] = {TR_COUNTDOWN_DECREASE, job_id, tr_id, len};

  size_t size;

  if(length(list)){
    size_t offset = sizeof(args) + len + sizeof(so_t);
    void *ptr = R_objectToBytes3(list, &size, offset);
    memcpy(ptr, args, sizeof(args));
    memcpy(ptr + sizeof(args), name, len);

    so_t *so = (so_t*) (ptr+sizeof(args) + len);
    so->ref_count  = 1;
    so->mem_type  =  0;
    so->sys_type  =  0;
    so->obj_type = SUPR_SERIALIZED_ROBJ;
    so->size  = size - offset;

    shm_io_write(io, io->out, ptr, size);
    free(ptr);
  } else {
    size  = sizeof(args) + len + sizeof(so_t);
    unsigned char ptr[size];
    memcpy(ptr, args, sizeof(args));
    memcpy(ptr + sizeof(args), name, len);
    so_t *so = (so_t*)(ptr+sizeof(args) + len);
    so->ref_count  = 1;
    so->mem_type  =  0;
    so->sys_type  =  0;
    so->obj_type = SUPR_NILSXP;
    so->size  = 0;
    shm_io_write(io, io->out, ptr, size);
  }

  so_t *raw = (so_t *) shm_io_read(io, io->in, &size, NULL);
  int n = *((int*)raw);
  free(raw);

  //printf("size: %ld, n: %d\n", size, n);
  SEXP ret;
  if(n==0){
    ret = R_NilValue;
  } else if(n==1){
      raw = (so_t *) shm_io_read(io, io->in, &size, NULL);
      ret = SO_toRObject(raw, size);
      free(raw);
  } else {
    ret = PROTECT(allocVector(VECSXP, n));
    int m = 0;
    SEXP x;
    for(int i=0; i<n; i++){
      raw = (so_t *) shm_io_read(io, io->in, &size, NULL);
      SEXP val = SO_toRObject(raw, size);
      if(val != R_NilValue) {
	      m++; // FIXME for efficiency ...
	      x = val;
      }
      free(raw);
      SET_VECTOR_ELT(ret, i, val);
    }
    if(m==0) {
	    ret = R_NilValue;
    } else if (m==1){
	    ret = x;
    }
    UNPROTECT(1);
  }

  //PrintValue(ret);
MALLOC_MARK(__LINE__);

  return ret;
}


SEXP TR_countdown_reset(SEXP name, SEXP arg_list) // arg_list = list(...)
{
  int job_id = tr_cntxt.job_id;
  int tr_id  = tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;

  const char *cname = CHAR(STRING_ELT(name, 0));
  int len = strlen(cname)+1;

  int args[] = {TR_COUNTDOWN_RESET, job_id, tr_id, len};
  size_t size = sizeof(args) +  len;

  size_t s_size;
  so_t *so = SO_valueOf(arg_list, &s_size);
  size += s_size;

  void *buf = malloc(size);
  memcpy(buf, args, sizeof(args));
  memcpy(buf +  sizeof(args), cname, len);
  memcpy(buf +  sizeof(args) + len, so, s_size);

  int cmd = TR_SEND_DRIVER;
  shm_io_write(io, io->out, &cmd, sizeof(int));

  shm_io_write(io, io->out, buf, size);
  free(buf);

  so = (so_t*) shm_io_read(io, io->in, &size,  NULL);

  SEXP val = SO_toRObject(so, size);
  free(so);

  return val;
}
*/




// R_thread development

//
/*
static supr_thread_t *main_thread = NULL;
static vector_t *Thread_threads = NULL;
*/

//extern unsigned long R_CStackStart;
  //int __save_R_CStackStart__ = R_CStackStart;   \

/*
#define BEGIN_R_EVAL()     do      {       \
  pthread_mutex_lock(&main_thread->mutex);      \
  void *dummy;  \
  __save_R_CStackStart__ = R_CStackStart;   \
  R_CStackStart = (unsigned long) &dummy

#define END_R_EVAL()   \
  R_CStackStart = __save_R_CStackStart__;       \
  pthread_mutex_unlock(&main_thread->mutex);    \
} while(0)
*/


/*
void Thread_test_run1(SEXP env)
{
  BEGIN_R_EVAL();
    //SEXP expr = findVar(install(".expr"), env);
    defineVar(install(".expr"), ScalarInteger(1000), env);

  END_R_EVAL();
}
*/

// Monitors?

static pthread_mutex_t monitor_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutexattr_t recursiveMutexAttr;
/*
 * pthread_condattr_t *cattr
//	pthread_condattr_init(pthread_condattr_t *cattr); 
 * Prototype:
int	pthread_condattr_setpshared(pthread_condattr_t *cattr, int pshared);

#include <pthread.h>

pthread_condattr_t cattr;
int ret;

// all processes 
ret = pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_SHARED);

// within a process
ret = pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_PRIVATE);
*/


static class_t *Monitor_class = NULL;

const char *monitorToChar(class_t *class, void *object)
{
  supr_monitor_t *m = (supr_monitor_t *) object;
  printf("name: %s, tid: %d\n", m->name, m->tid);
  return "Monitor"; // TODO
}

void monitorFinalize(class_t *class, void *object)
{
  supr_monitor_t *m = (supr_monitor_t *) object;
  pthread_mutex_destroy(&m->mutex);
  pthread_cond_destroy(&m->cond);
  free(m);
}

supr_monitor_t *Monitor_new(const char *name)
{
  supr_monitor_t *m = (supr_monitor_t *) malloc(sizeof(supr_monitor_t));
  static int unnamed_id = 0;
  if(Monitor_class){
//    printf("[%s] Monitor_class->name: %s\n", __func__, Monitor_class->name);
  } else {
    errorcall(R_NilValue, "no Monitor_class, FIXME (%s:%d)",__FILE__, __LINE__);
  }
  m->class = Monitor_class;
  m->ref_count = REF_COUNT_INITIALIZER;
  m->tid = -1;
  pthread_mutex_init(&m->mutex, &recursiveMutexAttr);
  pthread_cond_init(&m->cond, NULL);

  pthread_mutex_lock(monitors->mutex);
    vectorAdd(monitors, m);
    if(name)
      m->name = strdup(name);
    else { 
      char buf[64];
      sprintf(buf, "%d", ++unnamed_id);
      m->name = strdup(buf);
    }
  pthread_mutex_unlock(monitors->mutex);

  return m;
}

static void monitor_finalizer(SEXP s)
{
  printf("[%s] is called\n", __func__);

  supr_monitor_t *m = (supr_monitor_t *) R_ExternalPtrAddr(s);

  pthread_mutex_lock(monitors->mutex);
    vectorRemoveElement(monitors, m);
  pthread_mutex_unlock(monitors->mutex);

  m->class->finalize(m->class, m);

}

SEXP Monitor_toString(SEXP rmonitor)
{
  if(TYPEOF(rmonitor) == EXTPTRSXP){
    supr_monitor_t *m = (supr_monitor_t *) R_ExternalPtrAddr(rmonitor);
    if( m->class == Monitor_class) {
      char buf[256];
      sprintf(buf,"name: %s, tid: %d, mutex.owner: %d", m->name, m->tid,
		      m->mutex.__data.__owner);
      return mkString(buf);
    }
  }
  error(_("not a monitor object"));
  return R_NilValue; // not reached
}

SEXP Monitor_info(SEXP args)
{
//    PrintValue(args);

  SEXP ret;
  if(args == R_NilValue){
    pthread_mutex_lock(monitors->mutex);
      ret = PROTECT(allocVector(STRSXP, vectorSize(monitors)));
      for(int i=0; i<vectorSize(monitors); i++){
        supr_monitor_t *m = (supr_monitor_t *) vectorElementAt(monitors, i);
        char buf[256];
//        printf("%4d: name: %s, tid: %d, mutex.owner: %d\n", i+1, m->name,  m->tid, m->mutex.__data.__owner);
        sprintf(buf,"name: %s, tid: %d, mutex.owner: %d", m->name, m->tid,
		      m->mutex.__data.__owner);
        SET_STRING_ELT(ret, i, mkChar(buf));
      }
    pthread_mutex_unlock(monitors->mutex);
    UNPROTECT(1);
    return ret;
  } else {
    ret = args;
    while(args != R_NilValue){

      SEXP x = CAR(args);
      if(strcmp(CHAR(asChar(getAttrib(x, R_ClassSymbol))), "monitor"))
	      x = getAttrib(x, install("monitor"));

      if(strcmp(CHAR(asChar(getAttrib(x, R_ClassSymbol))), "monitor")==0)
      {
        supr_monitor_t *m = (supr_monitor_t *) R_ExternalPtrAddr(x);
        char buf[256];
        sprintf(buf,"name: %s, tid: %d, mutex.owner: %d", m->name, m->tid,
		      m->mutex.__data.__owner);
        SETCAR(args, mkString(buf));

      } else 
        SETCAR(args, R_NilValue);
      
      args = CDR(args);
    }
    return ret;
  }
  return R_NilValue;
}


const char * __pthread_mutex_lock_error(int rc)
{
  switch(rc){
    case EAGAIN:
      return "the maximum number of recursive locks has been exceeded";
    case EINVAL:
      return "thread's priority error";
    case ENOTRECOVERABLE:
      return "the state protected by the mutex is not recoverable";
    case EOWNERDEAD:
      return "the previous owning thread terminated while holding the mutex lock";
    case EBUSY:
      return "it was already locked";
    case EPERM:
      return "the current thread does not own the mutex";
    case EDEADLK:
      return "a deadlock condition was detected";
    default: return "unknown cause";
  }
  return NULL;
}

static void Sync_mutex_unlock(void *data)
{
  supr_monitor_t *m = (supr_monitor_t *) data;
  m->tid =  0;
  pthread_mutex_unlock(&m->mutex);
}

#define R_MONITOR_CLASS_NAME "monitor"

// create a monitor, and attach to x if possible ...
static SEXP Monitor_create(SEXP x, const char *name)
{
  int rc;
  SEXP monitor;

  // FIXME?
  BEGIN_R_FREE();
  rc = pthread_mutex_lock(&monitor_mutex);
  END_R_FREE();

  if(rc != 0)
    error(_("%s"), __pthread_mutex_lock_error(rc));

    supr_monitor_t *m = Monitor_new(name);
    monitor = PROTECT(R_MakeExternalPtr(m, R_NilValue, R_NilValue));
    R_RegisterCFinalizerEx(monitor, monitor_finalizer, TRUE);
    setAttrib(monitor, R_ClassSymbol, mkString(R_MONITOR_CLASS_NAME));
    UNPROTECT(1);

  rc = pthread_mutex_unlock(&monitor_mutex);

  if(x != R_NilValue)
    setAttrib(x, install(R_MONITOR_CLASS_NAME), monitor);

  return monitor;
}

static supr_monitor_t *Supr_getMonitor(SEXP x, int create_if_not_exists)
{
  SEXP monitor;
  SEXP klass = getAttrib(x, R_ClassSymbol);
  if(klass != NULL && strcmp(CHAR(asChar(klass)), "monitor")== 0) 
    monitor = x;
  else {
    monitor = getAttrib(x, install("monitor"));
    if(monitor == R_NilValue && create_if_not_exists)
      monitor = Monitor_create(x, NULL);
    else if(TYPEOF(monitor) != EXTPTRSXP) 
      error("not a monitor object (%s:%d)", __FILE__, __LINE__);
  }
  supr_monitor_t *m = (supr_monitor_t *) R_ExternalPtrAddr(monitor);
  if(m->class != Monitor_class)
    error("not a monitor object (%s:%d)", __FILE__, __LINE__);
  return m;
}

#define NOT_IMPLEMENTED error(_("NOT_IMPLEMENTED %s (%s:%d)"),	\
	       	__func__,  __FILE__, __LINE__);

SEXP ThreadProc_lock(SEXP name);
SEXP ThreadProc_unlock(SEXP name);
SEXP ThreadProc_wait(SEXP name, SEXP timeout);
SEXP ThreadProc_notify(SEXP name, SEXP all);

// x: LCONS(install("$"), CONS(obj_symbol, CONS(name_symbol, R_NilValue)))
//static
SEXP Supr_localProcSyncEval(SEXP expr, SEXP x, SEXP env)
{
	/*
  {
	  printf("%s\n", __func__);
    fprintf(stderr, "Supr_threadType: %d\n", Supr_threadType);
    fprintf(stderr, "typeof(monitor x): %s\n", type2char(TYPEOF(x)));
    fprintf(stderr, "typeof(monitor x): %s, [%d =?= (LANGSXP=%d)]\n",
		  type2char(TYPEOF(x)), TYPEOF(x), LANGSXP);
    PrintValue(x);
  }
  */

  if(TYPEOF(x) != LANGSXP)
	error(_("invalid monitor argument"));

  const char *shared_env = NULL, *name = NULL;
  SEXP s = CDR(x);
  if(s != R_NilValue){
    shared_env = CHAR(asChar(CAR(s)));
    s = CDR(s);
  }
  if(s != R_NilValue){
    name = CHAR(asChar(CAR(s)));
    s = CDR(s);
  }

  if(!name)
	error(_("invalid monitor argument"));

  if(strcmp(shared_env, "ClusterEnv")==0){
    fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    NOT_IMPLEMENTED
  } else if(strcmp(shared_env, "SharedEnv")==0){
    //fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    char buf[strlen(shared_env)+strlen(name)+2];
    sprintf(buf, "%s$%s", shared_env, name);
    //SEXP r_name = PROTECT(mkString(name));
    SEXP r_name = PROTECT(mkString(buf));
    SEXP rc =  ThreadProc_lock(r_name);
    UNPROTECT(1);

    //fprintf(stderr, "ThreadProc_lock(name): ");
    //PrintValue(rc);
    if(INTEGER(rc)[0] != 0)
      error(_("failed to lock '%s'"), buf);
    
    SEXP retval = eval(expr, env);

    rc =  ThreadProc_unlock(r_name);

    {
      fprintf(stderr, "ThreadProc_unlock(name): ");
      PrintValue(rc);
    }

    return retval;
  } else {
    fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    NOT_IMPLEMENTED
  }

  return R_NilValue;
}

SEXP Supr_remoteProcSyncEval(SEXP expr, SEXP x, SEXP env)
{
  NOT_IMPLEMENTED
}

SEXP Supr_localProcSyncWait(SEXP x, SEXP r_timeout)
{
  if(TYPEOF(x) != LANGSXP) error(_("invalid monitor argument"));
  const char *shared_env = NULL, *name = NULL;
  SEXP s = CDR(x);
  if(s != R_NilValue){
    shared_env = CHAR(asChar(CAR(s)));
    s = CDR(s);
  }
  if(s != R_NilValue){
    name = CHAR(asChar(CAR(s)));
    s = CDR(s);
  }
  if(!name) error(_("invalid monitor argument"));

  if(strcmp(shared_env, "ClusterEnv")==0){
    fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    NOT_IMPLEMENTED
  } else if(strcmp(shared_env, "SharedEnv")==0){
    //fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    char buf[strlen(shared_env)+strlen(name)+2];
    sprintf(buf, "%s$%s", shared_env, name);
    //SEXP r_name = PROTECT(mkString(name));
    SEXP r_name = PROTECT(mkString(buf));
    SEXP retval =  ThreadProc_wait(r_name, r_timeout);
    UNPROTECT(1);

    //fprintf(stderr, "ThreadProc_lock(name): ");
    //PrintValue(rc);
    if(INTEGER(retval)[0] == -1)
      error(_("failed to wait '%s'"), buf);
    
    return retval;
  } else {
    fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    NOT_IMPLEMENTED
  }

}

SEXP Supr_remoteProcSyncWait(SEXP x, SEXP r_timeout)
{
  NOT_IMPLEMENTED
}

SEXP Supr_localProcSyncNotify(SEXP x, SEXP r_all)
{
  if(TYPEOF(x) != LANGSXP) error(_("invalid monitor argument"));
  const char *shared_env = NULL, *name = NULL;
  SEXP s = CDR(x);
  if(s != R_NilValue){
    shared_env = CHAR(asChar(CAR(s)));
    s = CDR(s);
  }
  if(s != R_NilValue){
    name = CHAR(asChar(CAR(s)));
    s = CDR(s);
  }
  if(!name) error(_("invalid monitor argument"));

  if(strcmp(shared_env, "ClusterEnv")==0){
    fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    NOT_IMPLEMENTED
  } else if(strcmp(shared_env, "SharedEnv")==0){
    //fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    char buf[strlen(shared_env)+strlen(name)+2];
    sprintf(buf, "%s$%s", shared_env, name);
    //SEXP r_name = PROTECT(mkString(name));
    SEXP r_name = PROTECT(mkString(buf));
    SEXP retval = ThreadProc_notify(r_name, r_all);
    UNPROTECT(1);

    //fprintf(stderr, "ThreadProc_lock(name): ");
    //PrintValue(rc);
    if(INTEGER(retval)[0] == -1)
      error(_("failed to notify '%s'"), buf);
    
    return retval;
  } else {
    fprintf(stderr, "shared_env: %s, name: %s\n", shared_env, name);
    NOT_IMPLEMENTED
  }

}

SEXP Supr_remoteProcSyncNotify(SEXP x, SEXP r_call)
{
  NOT_IMPLEMENTED
}

#define TEST_GET_MONITOR

/* x: substitute(monitor) in sync.eval(monitor, expr)
 * where monitor can be a symbol, JobEnv$sym, or Cluster$sym
*/

#ifdef SUPR3

/*
int supr3_lock(const char *whichEnv,  const char *whichObj)
{
  int port = localEnvPort;
  const char *host = localEnvHost;
  if((*whichEnv == 'C' || *whichEnv == 'c') && clusterEnvHost){
    port = clusterEnvPort;
    host = clusterEnvHost;
  }

  if(!host)
    error(_("%s is not available"), whichEnv);

  supr_socket_conn_t *sc = socketOpen2(host, port);

  int cmd = THREAD_PROC_LOCK;
  write(sc->fd, &cmd, sizeof(int)); 
  int len = strlen(whichObj)+1;
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, whichObj, len); 

  int rc;
  read(sc->fd, &rc, sizeof(int));

  close(sc->fd);
  free(sc); // FIXME ?

  return rc;
}
*/

/*
int supr3_unlock(const char *whichEnv,  const char *whichObj)
{
  int port = localEnvPort;
  const char *host = localEnvHost;
  if((*whichEnv == 'C' || *whichEnv == 'c') && clusterEnvHost){
    port = clusterEnvPort;
    host = clusterEnvHost;
  }

  if(!host)
    error(_("%s is not available"), whichEnv);

  supr_socket_conn_t *sc = socketOpen2(host, port);

  int cmd = THREAD_PROC_UNLOCK;
  write(sc->fd, &cmd, sizeof(int)); 
  int len = strlen(whichObj)+1;
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, whichObj, len); 

  int rc;
  read(sc->fd, &rc, sizeof(int));

  close(sc->fd);
  free(sc); // FIXME ?

  return rc;
}
*/

static void sync_eval_cleanup(void *data){
  const char *whichEnv = (char *) ((void**) data)[0];
  const char *whichObj = (char *) ((void**) data)[1];
  supr_socket_conn_t *sc = (supr_socket_conn_t *) ((void**) data)[2];

  int cmd = THREAD_PROC_UNLOCK;
  write(sc->fd, &cmd, sizeof(int)); 
  int len = strlen(whichObj)+1;
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, whichObj, len); 

  int rc;
  read(sc->fd, &rc, sizeof(int));

  close(sc->fd);
  free(sc);
}

supr_socket_conn_t * ThreadServer_getMonitorConn(const char *whichEnv,
   const char * whichObj)
{
  RCNTXT *cntxt = R_GlobalContext;
  while(cntxt){
    if(cntxt->cend == sync_eval_cleanup){
      void **data = (void **)cntxt->cenddata;
      const char *env = (const char *) data[0];
      const char *obj = (const char *) data[1];
      supr_socket_conn_t *conn = (supr_socket_conn_t *) data[2];
      if(strcmp(env, whichEnv)==0 && strcmp(obj, whichObj)==0)
        return conn;
    }

    cntxt = cntxt->nextcontext;
  }

  return NULL;
}



// For job/driver: no server is given
SEXP Sync_eval(SEXP monitor, SEXP expr, SEXP env)
{
  int nUNPROTECT = 0;
  if(TYPEOF(monitor) == LANGSXP && strcmp(CHAR(asChar(CAR(monitor))), "$")) {
    monitor = PROTECT(eval(monitor, env));
    nUNPROTECT++;
  }

  if(TYPEOF(monitor) == SYMSXP || TYPEOF(monitor) == STRSXP) {
      // use the default sync server
      SEXP mutex;
      if(TYPEOF(monitor) == SYMSXP) {
        mutex = PROTECT(mkString(CHAR(PRINTNAME(monitor))));
        nUNPROTECT++;
      } else 
        mutex = monitor;

//basic_info("default sync server: TR_sync_eval");
//basic_info(CHAR(asChar(mutex)));

      SEXP retval = TR_sync_eval(expr, mutex, env);
      UNPROTECT(nUNPROTECT);
      return retval;
  }

  int save = R_PPStackTop;

  //SEXP whichEnv = R_UnboundValue;
  const char *whichEnv = NULL;
  const char *whichObj = NULL;

  char *host = NULL;
  int port = -1;
  
  if(TYPEOF(monitor) == LANGSXP) {

    if( strcmp(CHAR(asChar(CAR(monitor))), "$") == 0 ) {

      SEXP server = PROTECT(eval(CADR(monitor), env));
      nUNPROTECT++;

      

      if(!IS_USER_DATABASE(server)) { // FIXME
	 PrintValue(server);
         error(_("invalid 'sharedEnv' argument in 'sharedEnv$monitor'"));
      }

      whichObj = CHAR(asChar(CADDR(monitor)));

      if(server == SuprJobEnv)
        return TR_sync_eval(expr, mkString(whichObj), env);

      whichEnv = CHAR(STRING_ELT(getAttrib(server, install("address")), 0));

    } else {
      error(_("invalid argument 'monitor'"));
    }
  } else
    error(_("invalid argument 'monitor'"));

  char whichEnv_str[strlen(whichEnv)+1];
  strcpy(whichEnv_str, whichEnv);
  whichEnv = whichEnv_str;
  UNPROTECT(nUNPROTECT);

  if(ThreadServer_getMonitorConn(whichEnv, whichObj))
    error(_("already synchronized on %s$%s"), whichEnv, whichObj);

      
//{
  supr_socket_conn_t *sc = NULL;
  if(!host) {
    char hostname[strlen(whichEnv)+1];
    strcpy(hostname, whichEnv);
    host = hostname;
    char *port_str = strstr(hostname, ":");
    if(!port_str) error(_("invalid thread.server: %s"), whichEnv);
    *port_str = '\0';
    port_str++;
    port = atoi(port_str);
    sc = socketOpen2(host, port);
    if(!sc) error(_("cannot connect to %s:%d"), host, port);
  } else {
    sc = socketOpen2(host, port);
    if(!sc) error(_("cannot connect to %s:%d"), host, port);
  }

  int cmd = THREAD_PROC_LOCK;
  write(sc->fd, &cmd, sizeof(int)); 
  int len = strlen(whichObj)+1;
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, whichObj, len); 

  int rc;
  read(sc->fd, &rc, sizeof(int));

  //close(sc->fd);
  //free(sc); // FIXME ?

//}

  RCNTXT cntxt;
  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);

    cntxt.cend = &sync_eval_cleanup;
    void *args[] = {(void*) whichEnv, (void*) whichObj, sc};
    cntxt.cenddata = args;
     
    SEXP val = PROTECT(eval(expr, env)); 

// R_Visible = FALSE;
  endcontext(&cntxt);



  UNPROTECT(1);

  cmd = THREAD_PROC_UNLOCK;
  write(sc->fd, &cmd, sizeof(int)); 
  len = strlen(whichObj)+1;
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, whichObj, len); 

  read(sc->fd, &rc, sizeof(int));

  close(sc->fd);
  free(sc);

  if(save != R_PPStackTop)
       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
	     __FILE__, __LINE__, __func__, save, R_PPStackTop);

  return val;
}


#else

SEXP Sync_eval(SEXP expr, SEXP x, SEXP env)
{
//	int savestack = R_PPStackTop;
// an name to object: ymbol
// an shared object: language

  if(TYPEOF(x) != LANGSXP) error(_("invalid argument 'x'"));


  if( strcmp(CHAR(asChar(CAR(x))), "$") == 0 ) {

    const char *x_str = CHAR(asChar(CADR(x)));
    //fprintf(stderr, "[%s] x_str: %s\n", __func__, x_str);

    if(strcmp(x_str, ".LocalEnv")){
      x = CADDR(x);
    } else {

      if(strcmp(x_str, ".JobEnv")){
        const char *m_str = CHAR(asChar(CADDR(x)));
        //fprintf(stderr, "[%s] m_str: %s\n", __func__, m_str);
        SEXP mutex = PROTECT(mkString(m_str));
        SEXP val = TR_sync_eval(expr, mutex, env);
        UNPROTECT(1);
        return val;
      }

      if(Supr_threadType == 1) { //  local process ...
        return Supr_localProcSyncEval(expr, x, env);
      } else if(Supr_threadType == 2) { //  remote  process ... NOT TESTED?
        return Supr_remoteProcSyncEval(expr, x, env);
      }
    }
  }

  x = PROTECT(eval(x, env));
  
  //  thread_syncEval:

  SEXP val = R_NilValue;
  RCNTXT cntxt;
  supr_monitor_t *m;
  int rc;

  supr_thread_t *cth = currentThread();


  Thread_setState(cth, THREAD_STATE_BLOCKED);

#ifdef  TEST_GET_MONITOR
  m = Supr_getMonitor(x, TRUE);
#else

  BEGIN_R_FREE();
  rc = pthread_mutex_lock(&monitor_mutex);
  END_R_FREE();

  if(rc != 0)
	  errorcall(R_NilValue, "%s", __pthread_mutex_lock_error(rc));

    SEXP monitor = getAttrib(x, install("monitor"));
    
    if(TYPEOF(monitor) == NILSXP){
      //SEXP _x = Rf_deparse1line(x, TRUE);
      //supr_monitor_t *m = Monitor_new(CHAR(asChar(_x)));
      supr_monitor_t *m = Monitor_new(NULL);
      //printf("[%s] m->class: %p\n", __func__, m->class);
      monitor = PROTECT(R_MakeExternalPtr(m, R_NilValue, R_NilValue));
      R_RegisterCFinalizerEx(monitor, monitor_finalizer, TRUE);
      setAttrib(x, install("monitor"), monitor);
      setAttrib(monitor, R_ClassSymbol, mkString("monitor"));
      UNPROTECT(1);
    }
  rc = pthread_mutex_unlock(&monitor_mutex);
  
  if(rc != 0) 
      errorcall(R_NilValue, "%s", __pthread_mutex_lock_error(rc));

  m = (supr_monitor_t *) R_ExternalPtrAddr(monitor);
#endif

  BEGIN_R_FREE();
  Thread_setState(cth, THREAD_STATE_BLOCKED);
  rc = pthread_mutex_lock(&m->mutex);
  END_R_FREE();

  //CheckStack();

  if(rc == -1)
    errorcall(R_NilValue, "pthread_mutex_lock, %s", __pthread_mutex_lock_error(rc));

  m->tid = cth->tid;


  begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);
    cntxt.cend = Sync_mutex_unlock;
    cntxt.cenddata = m;

    //CheckStack();
    val = eval(expr, env);

  endcontext(&cntxt);

  m->tid =  0;
  rc = pthread_mutex_unlock(&m->mutex);
  Thread_setState(cth, THREAD_STATE_RUNNABLE);

  if(rc == -1)
    errorcall(R_NilValue, "pthread_mutex_unlock, %s", 
		    __pthread_mutex_lock_error(rc));

//printf("[%s] end R_PPStackTop: %d -> %d\n", __func__, savestack,R_PPStackTop);
  UNPROTECT(1);
  return val;
}

#endif

supr_monitor_t *Supr_findMonitor()
{
  for(RCNTXT *cntxt_ptr = R_GlobalContext;
      cntxt_ptr; cntxt_ptr = cntxt_ptr->nextcontext) {
    if(cntxt_ptr->cend
       && cntxt_ptr->cend == Sync_mutex_unlock
       && cntxt_ptr->cenddata
       && ((supr_monitor_t *)cntxt_ptr->cenddata)->class == Monitor_class) {
      return cntxt_ptr->cenddata;
    }
  }
  error(_("cannot find any synchronized monitor"));
  return NULL; // not reached
}

#ifdef SUPR3

// modify and use supr_thread_t later ...
/*
typedef struct supr3_thread_struct {
  pthread_mutex_t mutex; //
  pthread_cond_t cond;  //
  //pthread_t pthread; // ptid
  pthread_t ptid; // ptid
  supr_socket_conn_t *conn;
  unsigned long R_CStackStart;
  SEXP sharedEnv;
  void *data;
} supr3_thread_t;
*/

vector_t *ThreadServer_socket_connections = NULL;

void ThreadServer_removeConn(supr_socket_conn_t *conn){
  printf("\033[0;31m//%s:%d, fd: %d\033[0m\n", conn->host, conn->port,
                  conn->fd);
  int type = conn->type;

  close(conn->fd);
  vectorRemoveElement(ThreadServer_socket_connections, conn);

  /* TODO?
  if(conn->att){
    vector_t *att = (vector_t *) conn->att;
    for(int i=vectorSize(att)-1; i>=0; i--){
      object_t *obj = (object_t *) vectorRemove(att, i);
      if(obj->class == Runnable_class){
         run_t *r = (run_t *) obj;
         r->run(r->data);
      }
    }
  }
  */

}

typedef struct supr3_thread_info_struct {
  pid_t pid;
  int fd;
  int state;
  int padding;
  supr_socket_conn_t *conn;
  supr_socket_conn_t *join_conn;
} supr3_thread_info_t;

static hashtable_t *threadInfoHashtable = NULL;

static pid_t ThreadServer_tid = 0;

void ThreadServer_backend_cleanup(void *arg)
{
  if(gettid() != ThreadServer_tid) return;

  fprintf(stderr, "%d: %s\n", gettid(), __func__);
  // threads
  int n;
  pthread_mutex_lock(threadInfoHashtable->mutex);
    char **keys = Hashtable_keySet(threadInfoHashtable, &n);
    free(keys);
    for(int i=0; i<n; i++){
      supr3_thread_info_t *info = (supr3_thread_info_t *)
      		hashtableGet(threadInfoHashtable, keys[i]);
      fprintf(stderr, "\tpid: %d, state: %d\n", info->pid, info->state);

      // do waitpid?

      //
      char path[PATH_MAX];
      sprintf(path, "%s/stderr-%s.txt", Supr_threadDir, keys[i]); 
      unlink(path);
      sprintf(path, "%s/stdout-%s.txt", Supr_threadDir, keys[i]); 
      unlink(path);
      sprintf(path, "%s/return-%s.bin", Supr_threadDir, keys[i]); 
      unlink(path);
      sprintf(path, "%s/error-%s.txt", Supr_threadDir, keys[i]); 
      unlink(path);
      //
    }

    vector_t *conns = (vector_t *) arg;
    if(conns){
      for(int i= vectorSize(conns)-1; i>=0; i--){
        supr_socket_conn_t *sc = (supr_socket_conn_t *)vectorElementAt(conns,i);
        fprintf(stderr, "\tclose(//%s:%d)\n", sc->host, sc->port);
        close(sc->fd);
        sc->class->finalize(sc->class, sc);
        vectorRemove(conns,i);
      }
    }
  pthread_mutex_unlock(threadInfoHashtable->mutex);
}



// timedwait
typedef struct sync_wait_struct {

  //supr_socket_conn_t *conn;
  //const char *whichObj;

  char *monitor; // mutex;
  supr_socket_conn_t *sc;
  int cmd; // _SYNC_RETURN or _NOTIFY
  int job_id;
  int padding; // or used as the ref_count???

  int tid; // for timedwait
  struct timespec wait;
} sync_wait_t;

sync_wait_t *sync_wait_alloc(supr_socket_conn_t *conn, const char *monitor)
{
  sync_wait_t *sw = malloc(sizeof(sync_wait_t));
  sw->sc = conn;

  //sw->monitor= (char*)monitor;
  sw->monitor= malloc(strlen((char*)monitor)+1);
  strcpy(sw->monitor, monitor);
  return sw;
}

void sync_wait_free(sync_wait_t *sw)
{
  free(sw->monitor);
  free(sw);
}

static pthread_mutex_t sync_mutex = PTHREAD_MUTEX_INITIALIZER;
static supr_thread_t *timedwait_thread = NULL;

//static hashtable_t *driverMonitorEnvironment = NULL; // syncHashtable

static hashtable_t *syncHashtable = NULL;
static hashtable_t *waitHashtable = NULL;

static vector_t *timedwait_queue = NULL;
static supr3_thread_t *ThreadServer_timedwait_thread = NULL;

void sync_wait_queue_print(vector_t *sync_queue, const char *label)
{
      for(int i=0; i<vectorSize(sync_queue); i++)
      {
        sync_wait_t *sw = (sync_wait_t *) vectorElementAt(sync_queue,i);
        fprintf(stderr, "\t%s[%d]: %d\n", label, i, sw->sc->fd);
      }
}
    
// no need?
#define  TIMEDWAIT_QUEUE_CHANGED 60601


// whichObj: monitor object
vector_t *getWaitQueue(supr_socket_conn_t *conn, const char *whichObj)
{
  //if(!waitHashtable) waitHashtable = newHashtable(FALSE);
  vector_t *wait_queue = (vector_t *) hashtableGet(waitHashtable, whichObj);

  if(!wait_queue){
    wait_queue = newVector(FALSE);
    hashtablePut(waitHashtable, whichObj, wait_queue);
  }
  return wait_queue;
}

vector_t *getSyncQueue(supr_socket_conn_t *conn, const char *whichObj)
{
  //if(!syncHashtable) syncHashtable = newHashtable(FALSE);
  vector_t *sync_queue = (vector_t *) hashtableGet(syncHashtable, whichObj);

  if(!sync_queue){
    sync_queue = newVector(FALSE);
    hashtablePut(syncHashtable, whichObj, sync_queue);
  }
  return sync_queue;
}



void ThreadServer_lock(supr_socket_conn_t *conn, const char *whichObj)
{
  if(Supr_verbose)
    fprintf(stderr, "[%s] whichObj: %s, conn->fd: %d\n", __func__,
		    whichObj, conn->fd);
  pthread_mutex_lock(syncHashtable->mutex);

    vector_t *sync_queue = Hashtable_get(syncHashtable, whichObj);

    if(sync_queue){
      if(vectorSize(sync_queue) == 0){
        int rc = 0;
        ssize_t size = write(conn->fd, &rc, sizeof(int));
      }
      vectorAdd(sync_queue, sync_wait_alloc(conn, whichObj));
    } else {
      int rc = 0;
      ssize_t size = write(conn->fd, &rc, sizeof(int));

      sync_queue = newVector(FALSE);
      vectorAdd(sync_queue, sync_wait_alloc(conn, whichObj));
      Hashtable_put(syncHashtable, whichObj, sync_queue);

      BEGIN_R_EVAL();

        supr_thread_t *cth = SUPR_CURRENT_THREAD();
	SEXP vecPtr = PROTECT(R_MakeExternalPtr(sync_queue, R_NilValue,
			       	R_NilValue));
	SEXP S_sync = PROTECT(allocVector(VECSXP, 2));
	SEXP S_names = PROTECT(allocVector(STRSXP, 2));
	SET_VECTOR_ELT(S_sync, 0, vecPtr);
	SET_VECTOR_ELT(S_sync, 1, R_NilValue);
	SET_STRING_ELT(S_names, 0, mkChar("lock"));
	SET_STRING_ELT(S_names, 1, mkChar("wait"));
	setAttrib(S_sync, R_NamesSymbol, S_names);
	SEXP sync_monitor = findVar(install(whichObj), cth->sharedEnv);
	if(sync_monitor == R_UnboundValue || TYPEOF(sync_monitor)==NILSXP ){
	  sync_monitor = PROTECT(CONS(R_NilValue, R_NilValue));//FIXME
	  defineVar(install(whichObj), sync_monitor, cth->sharedEnv);
	  UNPROTECT(1);
	}
	setAttrib(sync_monitor, install("sync"), S_sync);

	UNPROTECT(3);
      END_R_EVAL();
      
    }

    if(Supr_verbose)
      sync_wait_queue_print(sync_queue, "sync_queue");
      /*
      for(int i=0; i<vectorSize(sync_queue); i++)
      {
        sync_wait_t *sw = (sync_wait_t *) vectorElementAt(sync_queue,i);
        fprintf(stderr, "\t sync_queue[%d]: %d\n", i, sw->sc->fd);
      }
      */
    
    if(Supr_verbose) {
      sync_wait_queue_print(sync_queue, "sync_queue");
      vector_t *wait_queue = getWaitQueue(conn, whichObj);
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }

  pthread_mutex_unlock(syncHashtable->mutex);
  if(Supr_verbose)
    fprintf(stderr, "[%s] whichObj: %s, conn->fd: %d\n", __func__,
		    whichObj, conn->fd);
}

void ThreadServer_unlock(supr_socket_conn_t *conn, const char *whichObj)
{
  if(Supr_verbose)
    fprintf(stderr, "[%s] whichObj: %s, conn->fd: %d\n", __func__,
		    whichObj, conn->fd);

  pthread_mutex_lock(syncHashtable->mutex);

    vector_t *sync_queue = Hashtable_get(syncHashtable, whichObj);

    if(Supr_verbose)
      sync_wait_queue_print(sync_queue, "sync_queue");

    if(!sync_queue){
      int rc = -1; // error message? use Sync_errno ?
      ssize_t size = write(conn->fd, &rc, sizeof(int));
      pthread_mutex_unlock(syncHashtable->mutex);
      return;
    }
    sync_wait_t *sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
    if(!sw || sw->sc != conn){

      if(!sw){
        fprintf(stderr, "\033[0;31m[%s] pid: %d, sw == NULL, FIXME\033[0m\n",
		       	__func__, getpid());
      }

      int rc = -1; // error message?
      ssize_t size = write(conn->fd, &rc, sizeof(int));
      pthread_mutex_unlock(syncHashtable->mutex);
      return;
    }
    vectorRemove(sync_queue, 0); 

    int rc = 0;
    ssize_t size = write(conn->fd, &rc, sizeof(int));

    sync_wait_free(sw);
      
    if(vectorSize(sync_queue)==0)  {
      Hashtable_delete(syncHashtable, (char*) whichObj);
    } else {
      sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
      int rc = 0;
      ssize_t size = write(sw->sc->fd, &rc, sizeof(int));
    }

    if(Supr_verbose) {
      sync_wait_queue_print(sync_queue, "sync_queue");
      vector_t *wait_queue = getWaitQueue(conn, whichObj);
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }
  pthread_mutex_unlock(syncHashtable->mutex);

  if(Supr_verbose)
    fprintf(stderr, "[%s] whichObj: %s, conn->fd: %d\n", __func__,
		    whichObj, conn->fd);
}

static int sync_wait_compare(const void *x, const void *y){

  sync_wait_t *a = (sync_wait_t *) *((void **)x);
  sync_wait_t *b = (sync_wait_t *) *((void **)y);

  /*
  printf("[%s] \ta: {%ld\t%ld}\n", __func__, a->wait.tv_sec, a->wait.tv_nsec);
  printf("[%s] \tb: {%ld\t%ld}\n", __func__, b->wait.tv_sec, b->wait.tv_nsec);
  */

  long a_nsec = a->wait.tv_sec*1000000000 + a->wait.tv_nsec;
  long b_nsec = b->wait.tv_sec*1000000000 + b->wait.tv_nsec;
  /*
  int k = (int) (a_nsec - b_nsec);
  printf("[%s] \tdiff: %d\n", __func__, k);
  */
  return (int) (a_nsec - b_nsec);
}

typedef struct wait_arg_struct {
	supr_socket_conn_t *conn;
	const char *whichObj;
	int nraw;
	int padding;
       	unsigned char *raw;
	double timeout;
} wait_arg_t;

// TODO
void wait_arg_preprocess(void *data){
  wait_arg_t *arg = (wait_arg_t *) data;
  SEXP raw = PROTECT(allocVector(RAWSXP, arg->nraw));
  fprintf(stderr, "%s:%d:%s arg->nraw: %d\n", __FILE__, __LINE__, __func__,
		  arg->nraw);
  memcpy(RAW(raw), arg->raw, arg->nraw);
  SEXP call= PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
  SEXP expr = PROTECT(eval(call,  R_BaseEnv)); // FIXME for driver...


//  SEXP val = PROTECT(eval(call, Thread_R_SharedEnv));
  supr_thread_t *cth = (supr_thread_t *)pthread_getspecific(currentThreadKey);
  SEXP val = PROTECT(eval(expr, cth->sharedEnv)); // FIXME for driver...

  arg->timeout = asReal(val);
  UNPROTECT(4);
  fprintf(stderr, "%s:%d:%s timeout: %g\n", __FILE__, __LINE__, __func__,
		  arg->timeout);
}

//void ThreadServer_wait(supr_socket_conn_t *conn, const char *whichObj, double timeout)
void ThreadServer_wait(supr_socket_conn_t *conn, const char *whichObj,
	       int nraw, unsigned char *raw_addr)
{
  if(Supr_verbose)
    fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
		    whichObj, conn->fd);

  double timeout;

  pthread_mutex_lock(syncHashtable->mutex);
    vector_t *wait_queue = getWaitQueue(conn, whichObj);
    vector_t *sync_queue = getSyncQueue(conn, whichObj);
    if(!wait_queue || !sync_queue){
        int rc = -1; // error message? use Sync_errno ?
        ssize_t size = write(conn->fd, &rc, sizeof(int));
        char err[1024];
        sprintf(err, "sync resource '%s' not found", whichObj); 
        int len = strlen(err)+1;
        size = write(conn->fd, &len, sizeof(int));
        size = write(conn->fd, err, len);
      pthread_mutex_unlock(syncHashtable->mutex);
      return;
    }
    sync_wait_t *sw = (sync_wait_t *) vectorRemove(sync_queue, 0);
    vectorAdd(wait_queue, sw);

    wait_arg_t wait_arg = {conn, whichObj, nraw, 0,  raw_addr, 0.0};
    //{
      int rc;
      BEGIN_R_EVAL();
        rc = R_ToplevelExec(wait_arg_preprocess, &wait_arg);
      END_R_EVAL();
      if(rc == TRUE)
	  timeout = wait_arg.timeout;
      else {
          rc = -1; // error message? use Sync_errno ?
	  write(conn->fd, &rc, sizeof(int));
	  const char *errbuf = R_curErrorBuf();
	  if(strstr(errbuf, "Error: "))
	    errbuf = strstr(errbuf, "Error: ") + strlen("Error: ");
          char err[strlen(errbuf)+256];
          sprintf(err, "failed to evaluate 'timeout', %s", errbuf);
          int len = strlen(err)+1;
          write(conn->fd, &len, sizeof(int));
          write(conn->fd, err, len);
        pthread_mutex_unlock(syncHashtable->mutex);
        return;
      }
    //}

    if(timeout > 0) { // add it to the timedwait_queue
        clock_gettime(CLOCK_REALTIME, &sw->wait);
        timeout += sw->wait.tv_sec + sw->wait.tv_nsec/((double)1000000000.0);
        long sec = (long) floor(timeout);
        long nsec = (long)((timeout-sec)*1000000000);
        sw->wait.tv_sec = sec;
        sw->wait.tv_nsec = nsec;
        vectorAdd(timedwait_queue, sw);
        qsort(timedwait_queue->elements, vectorSize(timedwait_queue),
                      sizeof(void *), sync_wait_compare);

        //pthread_mutex_lock(&timedwait_thread->mutex);
          //timedwait_thread->data = TIMEDWAIT_QUEUE_CHANGED;
          pthread_cond_signal(&ThreadServer_timedwait_thread->cond);
        //pthread_mutex_unlock(&timedwait_thread->mutex);
    }

    if(vectorSize(sync_queue)){
      sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
      int rc = 0;
      ssize_t size = write(sw->sc->fd, &rc, sizeof(int));
    } //else { } // keep 

    if(Supr_verbose) {
      sync_wait_queue_print(sync_queue, "sync_queue");
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }

  pthread_mutex_unlock(syncHashtable->mutex);

  if(Supr_verbose)
    fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
		    whichObj, conn->fd);
}

void ThreadServer_notify(supr_socket_conn_t *conn, const char *whichObj, int all)
{
  if(Supr_verbose)
    fprintf(stderr, "[%s] whichObj: %s, conn->fd: %d\n", __func__,
		    whichObj, conn->fd);
  
  pthread_mutex_lock(syncHashtable->mutex);
    vector_t *sync_queue = getSyncQueue(conn, whichObj);
    if(!sync_queue){
      int rc = -1; // error message? use Sync_errno ?
      ssize_t size = write(conn->fd, &rc, sizeof(int));
      pthread_mutex_unlock(syncHashtable->mutex);
      fprintf(stderr, "[%s] pid: %d, unlocked! ERROR\n", __func__, getpid());
      return;
    }

    vector_t *wait_queue = getWaitQueue(conn, whichObj);
    if(!wait_queue  || vectorSize(wait_queue)==0){
      int rc = 0; 
      ssize_t size = write(conn->fd, &rc, sizeof(int));
      pthread_mutex_unlock(syncHashtable->mutex);
      fprintf(stderr, "[%s] pid: %d, unlocked! No one to notify\n", __func__, getpid());
      return;
    }


    if(all){
        int lock_one = vectorSize(sync_queue) == 0
	       			&& vectorSize(wait_queue)>0;
        for(int i=vectorSize(wait_queue)-1; i>=0; i--){
          sync_wait_t *sw = (sync_wait_t *) vectorRemove(wait_queue, i);
          vectorRemoveElement(timedwait_queue, sw);//sync with timedwait thread!
          vectorAdd(sync_queue, sw);
        }

        if(lock_one){
          sync_wait_t *sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
          int rc = 0;
          ssize_t size = write(sw->sc->fd, &rc, sizeof(int));
        }
    } else {
        sync_wait_t *sw = (sync_wait_t *) vectorRemove(wait_queue, 0);

        vectorAdd(sync_queue, sw);
        vectorRemoveElement(timedwait_queue, sw);

//  fprintf(stderr, "[%s] pid: %d, vectorSize(sync_queue): %d, vectorSize(wait_queue): %d, vectorSize(timedwait_queue): %d\n", __func__, getpid(), vectorSize(sync_queue), vectorSize(wait_queue), vectorSize(timedwait_queue));

        if(vectorSize(sync_queue)==1){
          sw = (sync_wait_t *) vectorElementAt(sync_queue, 0);
          int rc = 0;
          ssize_t size = write(sw->sc->fd, &rc, sizeof(int));
        }
    }

    if(Supr_verbose) {
      sync_wait_queue_print(sync_queue, "sync_queue");
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }

  pthread_mutex_unlock(syncHashtable->mutex);

  int rc = 0; // error message? use Sync_errno ?
  ssize_t size = write(conn->fd, &rc, sizeof(int));

  //fprintf(stderr, "[%s] pid: %d, unlocked!\n", __func__, getpid());
  if(Supr_verbose)
    fprintf(stderr, "[%s] whichObj: %s, conn->fd: %d\n", __func__,
		    whichObj, conn->fd);
}


void thread_proc_put_cleanup(void *data)
{ 
fprintf(stderr, "[%s:%d] %s FIXME\n", __FILE__, __LINE__, __func__);
  R_CStackStart = save_cstackstart;
  R_unlock();
  supr_socket_conn_t *sc = (supr_socket_conn_t *)data;
  int rc = -1;
  write(sc->fd, &rc, sizeof(int));
}

void thread_proc_get_cleanup(void *data)
{ 
fprintf(stderr, "[%s:%d] %s FIXME\n", __FILE__, __LINE__, __func__);
  R_CStackStart = save_cstackstart;
  R_unlock();
  supr_socket_conn_t *sc = (supr_socket_conn_t *)data;
  int rc = -1;
  write(sc->fd, &rc, sizeof(int));
}

void thread_proc_new_cleanup(void *data)
{ 
fprintf(stderr, "[%s:%d] %s FIXME\n", __FILE__, __LINE__, __func__);
  R_CStackStart = save_cstackstart;
  R_unlock();
  supr_socket_conn_t *sc = (supr_socket_conn_t *)data;
  int rc = -1;
  write(sc->fd, &rc, sizeof(int));
}
void thread_proc_start_cleanup(void *data) // use a single fun?
{ 
fprintf(stderr, "[%s:%d] %s FIXME\n", __FILE__, __LINE__, __func__);
  R_CStackStart = save_cstackstart;
  R_unlock();
  supr_socket_conn_t *sc = (supr_socket_conn_t *)data;
  int rc = -1;
  write(sc->fd, &rc, sizeof(int));
}
void thread_proc_join_cleanup(void *data) // use a single fun?
{ 
fprintf(stderr, "[%s:%d] %s FIXME\n", __FILE__, __LINE__, __func__);
  R_CStackStart = save_cstackstart;
  R_unlock();
  supr_socket_conn_t *sc = (supr_socket_conn_t *)data;
  int rc = -1;
  write(sc->fd, &rc, sizeof(int));
}


typedef struct new_thread_info_struct {
	int pid;
	int fd;
	supr_socket_conn_t *conn;
} new_thread_info_t;

void ThreadServer_handle_JOIN(void *data){

   void **args = (void **)data;
   int fd = *((int*)args[0]);
   int *len_raw_addr = ((int*)args[1]);
   int cpid = *((int*) args[2]);
   unsigned char **bytes_addr = (unsigned char **)args[3];
   supr3_thread_t *cth = pthread_getspecific(currentThreadKey);

	       SEXP ret_val = PROTECT(Thread_join(ScalarInteger(cpid),
	       		R_FalseValue));

	       {
		 SEXP Threads = SuprThreads; 
		 char name[16];
		 sprintf(name, "%d", cpid); // FIXME
	         SEXP call = PROTECT(LCONS(install("rm"), CONS(install(name),
		 	CONS(Threads, R_NilValue))));
		 SET_TAG(CDDR(call), install("envir"));
	         eval(call, R_GlobalEnv);
		 UNPROTECT(1);
	       }


	       SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(ret_val, CONS(R_NilValue, R_NilValue))));
	       SEXP raw = eval(call, R_GlobalEnv);

	       int len_raw = LENGTH(raw); 
	       ssize_t size = write(fd, &len_raw, sizeof(int));
	       unsigned char *bytes = malloc(len_raw);
	       memcpy(bytes, RAW(raw), len_raw);
	       UNPROTECT(2);

	       *len_raw_addr = len_raw;
	       *bytes_addr = bytes;

}

//static vector_t *newThreads = NULL;
void ThreadServer_join(supr_socket_conn_t *conn, pid_t cpid) {

	   int fd = conn->fd;
	   size_t size;
//	   pid_t cpid;

	   //{
	     char *bytes = NULL;
	     int len_raw = 0;
	     R_lock();

	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;

//	     size = read(fd, &cpid, sizeof(int));

             void *args[4]={&fd, &len_raw, &cpid, &bytes};
             int rc = R_ToplevelExec(ThreadServer_handle_JOIN, args);


	     /*
	     RCNTXT cntxt;
	     begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);

	       cntxt.cend = &thread_proc_join_cleanup;
	       cntxt.cenddata = conn; // FIXME

//fprintf(stderr, "[%s:%d] (%s) OKAY -1\n", __FILE__, __LINE__, __func__);
	       SEXP ret_val = PROTECT(Thread_join(ScalarInteger(cpid),
	       		R_FalseValue));
//fprintf(stderr, "[%s:%d] (%s) OKAY 0\n", __FILE__, __LINE__, __func__);
//PrintValue(ret_val);
	       {
		 SEXP Threads = SuprThreads; // findVar(install(".Threads"), R_GlobalEnv);
		 char name[16];
		 sprintf(name, "%d", cpid); // FIXME
	         SEXP call = PROTECT(LCONS(install("rm"), CONS(install(name),
		 	CONS(Threads, R_NilValue))));
		 SET_TAG(CDDR(call), install("envir"));
	         eval(call, R_GlobalEnv);
		 UNPROTECT(1);
	       }

//fprintf(stderr, "[%s:%d] (%s) OKAY 1\n", __FILE__, __LINE__, __func__);

	       SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(ret_val, CONS(R_NilValue, R_NilValue))));
	       SEXP raw = eval(call, R_GlobalEnv);
//fprintf(stderr, "[%s:%d] (%s) OKAY 2\n", __FILE__, __LINE__, __func__);

	       len_raw = LENGTH(raw); 
	       size = write(fd, &len_raw, sizeof(int));
	       bytes = malloc(len_raw);
	       memcpy(bytes, RAW(raw), len_raw);
//fprintf(stderr, "[%s:%d] (%s) OKAY 3\n", __FILE__, __LINE__, __func__);
	       UNPROTECT(2);

	     endcontext(&cntxt);
	     */
	     R_CStackStart = R_CStackStart;
	     //PROTECT(raw);
	     R_unlock();

	     if(rc==1){
	       size = write(fd, bytes, len_raw);
	       free(bytes);
	     } else {
	       int rc = -1;
	       size = write(fd, &rc, sizeof(int));
	     }
	   //}

}


extern Rboolean R_ToplevelExec(void (*fun)(void *), void *data);

void ThreadServer_handle_GET(void *data){

   void **args = (void **)data;
   int fd = *((int*)args[0]);
   int len_raw = *((int*)args[1]);
   int *len_addr = (int*) args[2];
   unsigned char **bytes_addr = (unsigned char **)args[3];
   supr3_thread_t *cth = pthread_getspecific(currentThreadKey);

	       SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
	       read(fd, RAW(raw), len_raw);
	       SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
	   		R_NilValue)));
	       SEXP names = PROTECT(eval(call, R_GlobalEnv)); // names

	       SEXP sharedEnv = cth->sharedEnv;

	       int n = LENGTH(names);
	       SEXP values = PROTECT(allocVector(VECSXP, n));

	       for(int i=0; i<n; i++){
	         const char *name = CHAR(STRING_ELT(names, i));
	         SEXP val = findVar(install(name), sharedEnv);
		 SET_VECTOR_ELT(values, i, val);
	       }
		 
	       call = PROTECT(LCONS(install("serialize"),
                    CONS(values, CONS(R_NilValue, R_NilValue))));
	       raw = PROTECT(eval(call, R_GlobalEnv));
	       int len = LENGTH(raw);
	       *len_addr = len;

	       *bytes_addr = malloc(len);
	       memcpy(*bytes_addr, RAW(raw), len);
	   
	       write(fd, &len, sizeof(int));

//	       fprintf(stderr, "[%s] len: %d, *bytes_addr: %p\n", __func__, len, *bytes_addr);

	       UNPROTECT(6);

}

void ThreadServer_handle_REMOVE(void *data){
   void **args = (void **)data;
   int fd = *((int*)args[0]);
   int len_raw = *((int*)args[1]);
   int *len_addr = (int*) args[2];
   unsigned char **bytes_addr = (unsigned char **)args[3];
   supr3_thread_t *cth = pthread_getspecific(currentThreadKey);

	       SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
	       read(fd, RAW(raw), len_raw);
	       SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
	   		R_NilValue)));
	       SEXP names = PROTECT(eval(call, R_GlobalEnv)); // names

	       SEXP sharedEnv = cth->sharedEnv;

	       call = PROTECT(LCONS(install("rm"),
                    CONS(names, CONS(sharedEnv, R_NilValue))));
	       SET_TAG(CDR(call), install("list"));
	       SET_TAG(CDDR(call), install("envir"));
	       SEXP val = PROTECT(eval(call, R_GlobalEnv));

	       call = PROTECT(LCONS(install("serialize"),
                    CONS(val, CONS(R_NilValue, R_NilValue))));
	       raw = PROTECT(eval(call, R_GlobalEnv));
	       int len = LENGTH(raw);

	       unsigned char *bytes = malloc(len);
	       memcpy(bytes, RAW(raw), len);
	   
	       write(fd, &len, sizeof(int));

	       UNPROTECT(7);

	       *len_addr = len;
	       *bytes_addr = bytes;
}

void ThreadServer_handle_LIST(void *data){
   void **args = (void **)data;
   int fd = *((int*)args[0]);
   int len_raw = *((int*)args[1]);
   int *len_addr = (int*) args[2];
   unsigned char **bytes_addr = (unsigned char **)args[3];
   supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     

	       SEXP sharedEnv = cth->sharedEnv;

	       SEXP call = PROTECT(LCONS(install("ls"), CONS(R_TrueValue,
			CONS(sharedEnv, R_NilValue))));
               SET_TAG(CDR(call), install("all"));
               SET_TAG(CDDR(call), install("envir"));
	       SEXP names = PROTECT(eval(call, R_GlobalEnv)); // names
		 
	       call = PROTECT(LCONS(install("serialize"),
                    CONS(names, CONS(R_NilValue, R_NilValue))));
	       SEXP raw = PROTECT(eval(call, R_GlobalEnv));
	       int len = LENGTH(raw);

	       unsigned char *bytes = malloc(len);
	       memcpy(bytes, RAW(raw), len);
	       write(fd, &len, sizeof(int));
	       UNPROTECT(4);
	       *len_addr = len;
	       *bytes_addr = bytes;
}

void ThreadServer_handle_EXISTS(void *data){
   void **args = (void **)data;
   int fd = *((int*)args[0]);
   int len_raw = *((int*)args[1]);
   int *len_addr = (int*) args[2];
   unsigned char **bytes_addr = (unsigned char **)args[3];
   supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     
	       SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
	       read(fd, RAW(raw), len_raw);
	       SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
	   		R_NilValue)));
	       SEXP names = PROTECT(eval(call, R_GlobalEnv)); // names

	       SEXP sharedEnv = cth->sharedEnv;

	       int n = LENGTH(names);
	       SEXP values = PROTECT(allocVector(LGLSXP, n));

	       for(int i=0; i<n; i++){
	         const char *name = CHAR(STRING_ELT(names, i));
	         SEXP val = findVar(install(name), sharedEnv);
		 LOGICAL(values)[i] = val != R_UnboundValue;
	       }
		 
	       call = PROTECT(LCONS(install("serialize"),
                    CONS(values, CONS(R_NilValue, R_NilValue))));
	       raw = PROTECT(eval(call, R_GlobalEnv));
	       int len = LENGTH(raw);

	       unsigned char *bytes = malloc(len);
	       memcpy(bytes, RAW(raw), len);
	   
	       write(fd, &len, sizeof(int));

	       UNPROTECT(6);
	       *len_addr = len;
	       *bytes_addr = bytes;
}

void ThreadServer_handle_PUT(void *data){
   void **args = (void **)data;
   int fd = *((int*)args[0]);
   int len_raw = *((int*)args[1]);
   supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     
	       SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
	       read(fd, RAW(raw), len_raw);
	       SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
	   		R_NilValue)));
	       SEXP message = PROTECT(eval(call, R_GlobalEnv));

	       SEXP sharedEnv = cth->sharedEnv;
	       SEXP names = VECTOR_ELT(message, 0);
	       SEXP values = VECTOR_ELT(message, 1);
	       int n = LENGTH(names);
	       if(n==1){
		 defineVar(install(CHAR(STRING_ELT(names, 0))), values,
		 	sharedEnv);
	       } else {
	         for(int i=0; i < n; i++){
		   defineVar(install(CHAR(STRING_ELT(names, i))),
		             VECTOR_ELT(values, i), sharedEnv);
	         }
	       }
	       UNPROTECT(3);
}

extern SEXP R_lsInternal(SEXP env, Rboolean all);

void (*System_shutdown)(void *data) = NULL;

static void handleThreadServerShutdown(supr_socket_conn_t *conn){
  //basic_info(__func__);
// Threads
  BEGIN_R_EVAL();
    if(SuprThreads){
      SEXP names = R_lsInternal(SuprThreads, TRUE);
      char path[PATH_MAX];
      char msg[1024];
      for(int i=0; i<LENGTH(names); i++){
         pid_t pid = atoi(CHAR(STRING_ELT(names, i)));
	 if(pid == 0) continue;
	 int rc = kill(pid, 0);
	 if(rc == -1){
	   Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
	   sprintf(msg, "thread-%d, %s", pid, strerror(errno));
	   continue;
	 } 

	 rc = kill(pid, SIGKILL);
	 if(rc == -1){
	     Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
	     sprintf(msg, "kill(thread-%d), %s", pid, strerror(errno));
	     continue;
	 } 

	 int status;
         rc = waitpid(pid, &status, 0);
	 if(rc == -1){
	   Supr_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
	   sprintf(msg, "waitpid(thread-%d), %s", pid, strerror(errno));
	 }

	 sprintf(path, "%s/threads/%s/stdout-%d.txt", Supr_usrHome,
			 Supr_hostname, pid);
	 if(access(path,F_OK)==0)
		 unlink(path);
	 sprintf(path, "%s/threads/%s/stderr-%d.txt", Supr_usrHome,
			 Supr_hostname, pid);
	 if(access(path,F_OK)==0)
		 unlink(path);
	 sprintf(path, "%s/threads/%s/error-%d.txt", Supr_usrHome,
			 Supr_hostname, pid);
	 if(access(path,F_OK)==0)
		 unlink(path);
	 sprintf(path, "%s/threads/%s/return-%d.bin", Supr_usrHome,
			 Supr_hostname, pid);
	 if(access(path,F_OK)==0)
		 unlink(path);
      }
    }
  END_R_EVAL();

  if(System_shutdown) {
    //basic_info("Call System_shutdown(\"SHUTDOWN\")");
    System_shutdown("SHUTDOWN");
  } else {
    //basic_info("exit(EXIT_SUCCESS)");
    exit(EXIT_SUCCESS);
  }
}

int ThreadServer_handleCommand(supr_socket_conn_t *conn)
{
  //fprintf(stderr, "[%d:%s] %s\n", __LINE__, __FILE__, __func__);
  
  int fd = conn->fd;
  static int prev_cmd = -1;

  int cmd;
  {
    ssize_t len = 0;
    for(;;){
      len = recv(fd, &cmd, INT_SIZE, MSG_PEEK | MSG_DONTWAIT);
      if(len==sizeof(int)){
        break;
      } else if(len==0){
        verbose_info("[%d:%s:%s] disconect: %d\n", __LINE__, __FILE__,
		__func__, conn->fd);
        ThreadServer_removeConn(conn);
	return 0;
      }
    }
  }

  verbose_info("[%d:%s] %s, cmd: %d (%s)\n", __LINE__, __FILE__, __func__,
    cmd, cmd2char(cmd));

  switch(cmd){
    case CLUSTER_PING:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
//           fprintf(stderr, "\033[0;36m[PING] Read, size: %ld, cmd: %d\n", size, cmd);
           cmd = CLUSTER_PONG;
           size = write(fd, &cmd, sizeof(int));
//           fprintf(stderr, "\033[0;36m[PING] Write, size: %ld\n", size);
	 }
	 break;

    case THREAD_PROC_INTERRUPT:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
//           fprintf(stderr, "\033[0;36m[INTERRUPT] Read, size: %ld, cmd: %d\n", size, cmd);
           pid_t cpid;
	   size = read(fd, &cpid, sizeof(int));
	   int rc = kill(cpid, SIGKILL); // SIGQUIT?
	   {
	     char thread[16];
	     sprintf(thread, "%d", cpid);
	     supr3_thread_info_t *info = (supr3_thread_info_t *)
	     	hashtableGet(threadInfoHashtable, thread);
	     info->state = 3; // FIXME
	   }
           size = write(fd, &rc, sizeof(int));
//           fprintf(stderr, "\033[0;36m[INTERRUPT] Write, size: %ld\n", size);
	 }
	 break;

    case THREAD_PROC_LOCK:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
           //fprintf(stderr, "\033[0;36m[LOCK] Read, size: %ld, cmd: %d\n", size, cmd);
	   int len;
	   size = read(fd, &len, sizeof(int));
	   char whichObj[len];
	   size = read(fd, whichObj, len);
           //fprintf(stderr, "\033[0;36m[LOCK]  %s\n", whichObj);

           ThreadServer_lock(conn, whichObj);
	   /*
           int rc = 0;
           size = write(fd, &rc, sizeof(int));
           fprintf(stderr, "\033[0;36m[PING] Write, size: %ld\n", size);
	   */
	 }
	 break;

    case THREAD_PROC_UNLOCK:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
           //fprintf(stderr, "\033[0;36m[UNLOCK] Read, size: %ld, cmd: %d\n", size, cmd);
	   int len;
	   size = read(fd, &len, sizeof(int));
	   char whichObj[len];
	   size = read(fd, whichObj, len);
           //fprintf(stderr, "\033[0;36m[UNLOCK]  %s\n", whichObj);

           ThreadServer_unlock(conn, whichObj);
	   /*
           int rc = 0;
           size = write(fd, &rc, sizeof(int));
           fprintf(stderr, "\033[0;36m[PING] Write, size: %ld\n", size);
	   */
	 }
	 break;

    case THREAD_PROC_WAIT:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
           //fprintf(stderr, "\033[0;36m[WAIT] Read, size: %ld, cmd: %d\n", size, cmd);
	   int len;
	   size = read(fd, &len, sizeof(int));
	   char whichObj[len];
	   size = read(fd, whichObj, len);
	   //double timeout;
	   //size = read(fd, &timeout, sizeof(double));
           //fprintf(stderr, "\033[0;36m[WAIT]  %s\n", whichObj);
           //ThreadServer_wait(conn, whichObj, timeout);
	   size = read(fd, &len, sizeof(int));
	   unsigned char raw[len];
	   size = read(fd, raw, len);
           ThreadServer_wait(conn, whichObj, len, raw);
	 }
	 break;

    case THREAD_PROC_NOTIFY:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
           //fprintf(stderr, "\033[0;36m[NOTIFY] Read, size: %ld, cmd: %d\n", size, cmd);
	   int len;
	   size = read(fd, &len, sizeof(int));
	   char whichObj[len];
	   size = read(fd, whichObj, len);
	   int all;
	   size = read(fd, &all, sizeof(int));

           //fprintf(stderr, "\033[0;36m[NOTIFY]  %s\n", whichObj);

           ThreadServer_notify(conn, whichObj, all);
	 }
	 break;

    /*
    case THREAD_PROC_EVAL:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   int len_raw;
	   read(fd, &len_raw, sizeof(int));

	   {
	     R_lock();
	     RCNTXT cntxt;
	     begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);

	       cntxt.cend = &thread_proc_get_cleanup;
	       cntxt.cenddata = NULL; // FIXME

	       SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
	       read(fd, RAW(raw), len_raw);
	       SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
	   		R_NilValue)));
	       SEXP expr = PROTECT(eval(call, R_GlobalEnv)); // names

	       SEXP sharedEnv = findVar(install(".Thread.sharedEnv"),
	       		R_GlobalEnv);
	       if(sharedEnv == R_UnboundValue){
	         sharedEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                	ScalarInteger(DEFAULT_HASH_SIZE)));
		 defineVar(install(".Thread.sharedEnv"), sharedEnv,
		 	R_GlobalEnv);
		 UNPROTECT(1);
	       }

	       SEXP val = PROTECT(eval(expr, R_GlobalEnv)); // FIXME

	       call = PROTECT(LCONS(install("serialize"),
                    CONS(val, CONS(R_NilValue, R_NilValue))));
	       raw = PROTECT(eval(call, R_GlobalEnv));
	       int len = LENGTH(raw);

	       write(fd, &len, sizeof(int));
	       write(fd, RAW(raw), LENGTH(raw));

	       UNPROTECT(6);
	     endcontext(&cntxt);
	     R_unlock();
	   }

	 }
	 break;
	 */

    case THREAD_PROC_LIST:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   int len_raw;

	   int len;
	   char *bytes = NULL;
	   //{
	     R_lock();

	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;

	     void *args[4]={&fd, &len_raw, &len, &bytes};
	     int rc = R_ToplevelExec(ThreadServer_handle_LIST, args);
	     R_CStackStart = R_CStackStart;
	     R_unlock();

	   //}
	   if(rc) {
	     write(fd, bytes, len);
	     free(bytes);
	   } else {
	     rc = -1;
	     write(fd, &rc, sizeof(int));
	   }

	 }
	 break;

    case THREAD_PROC_EXISTS:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   int len_raw;
	   read(fd, &len_raw, sizeof(int));

	   int len;
	   char *bytes = NULL;
	   //{
	     R_lock();

	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;

	     void *args[4]={&fd, &len_raw, &len, &bytes};
	     int rc = R_ToplevelExec(ThreadServer_handle_EXISTS, args);
	     R_CStackStart = R_CStackStart;
	     R_unlock();

	   //}
	   if(rc){
	     write(fd, bytes, len);
	     free(bytes);
	   } else {
	     rc = -1;
	     write(fd, &rc, sizeof(int));
	   }

	 }
	 break;

    case THREAD_PROC_REMOVE:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   int len_raw;
	   read(fd, &len_raw, sizeof(int));

	   int len;
	   char *bytes = NULL;
	   //{
	     R_lock();

	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;

	     void *args[4]={&fd, &len_raw, &len, &bytes};
	     int rc = R_ToplevelExec(ThreadServer_handle_REMOVE, args);
	     R_CStackStart = R_CStackStart;
	     R_unlock();

	   //}
	   if(rc){
	     write(fd, bytes, len);
	     free(bytes);
	   } else {
	     rc = -1;
	     write(fd, &rc, sizeof(int));
	   }
	 }
	 break;


    case THREAD_PROC_GET:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   int len_raw;
	   read(fd, &len_raw, sizeof(int));

	   int len;
	   char *bytes = NULL;
	   //{
	     R_lock();

	     int save = R_PPStackTop;
	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;

#define USE_R_ToplevelExec
#ifdef USE_R_ToplevelExec
	     void *args[4]={&fd, &len_raw, &len, &bytes};
	     int rc = R_ToplevelExec(ThreadServer_handle_GET, args);
	   // rc = 1 -- normal
//	   fprintf(stderr, "?[%s] rc: %d\n", __func__, rc);
#else
	     RCNTXT cntxt;
	     begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);

	       cntxt.cend = &thread_proc_get_cleanup;
	       cntxt.cenddata = conn; // FIXME

	       SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
	       read(fd, RAW(raw), len_raw);
	       SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
	   		R_NilValue)));
	       SEXP names = PROTECT(eval(call, R_GlobalEnv)); // names

	       SEXP sharedEnv = cth->sharedEnv;

	       int n = LENGTH(names);
	       SEXP values = PROTECT(allocVector(VECSXP, n));

	       for(int i=0; i<n; i++){
	         const char *name = CHAR(STRING_ELT(names, i));
	         SEXP val = findVar(install(name), sharedEnv);
		 SET_VECTOR_ELT(values, i, val);
	       }
		 
	       call = PROTECT(LCONS(install("serialize"),
                    CONS(values, CONS(R_NilValue, R_NilValue))));
	       raw = PROTECT(eval(call, R_GlobalEnv));
	       len = LENGTH(raw);

	       bytes = malloc(len);
	       memcpy(bytes, RAW(raw), len);
	   
	       write(fd, &len, sizeof(int));

	       UNPROTECT(6);
	     endcontext(&cntxt);
#endif
//	       fprintf(stderr, "?[%s] len: %d, bytes: %p\n", __func__, len, bytes);
	     R_CStackStart = R_CStackStart;

	     if(save != R_PPStackTop)
	       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
		     __FILE__, __LINE__, __func__, save, R_PPStackTop);
	     R_unlock();

	   //}
	   if(rc){
	     write(fd, bytes, len);
	     free(bytes);
	   } else {
	     rc = -1;
	     write(fd, &rc, sizeof(int));
	   }

	 }
	 break;

    case THREAD_PROC_PUT:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   int len_raw;
	   read(fd, &len_raw, sizeof(int));

	   //{
	     R_lock();

	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;

	     void *args[4]={&fd, &len_raw};
	     int rc = R_ToplevelExec(ThreadServer_handle_PUT, args);
	     R_CStackStart = R_CStackStart;
	     R_unlock();
	   //}

	   rc -= 1;
	   write(fd, &rc, sizeof(int));
	 }
	 break;

    case THREAD_PROC_NEW:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   //list(expr, env, ...)
	   int len_raw; // FIXME?
	   size = read(fd, &len_raw, sizeof(int));
	   //fprintf(stderr, "%s: len_raw: %d\n", __func__, len_raw);

	   pid_t cpid;

	   { // use R_ToplevelExec ...
	     R_lock();
	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;
	     RCNTXT cntxt;
	     begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv,
                     R_NilValue, R_NilValue);

	       cntxt.cend = &thread_proc_new_cleanup;
	       cntxt.cenddata = conn; // FIXME

	       SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
	       read(fd, RAW(raw), len_raw);
	       SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
	   		R_NilValue)));
	       SEXP args = PROTECT(eval(call, R_GlobalEnv));

	       SEXP envir = PROTECT(allocSExp(ENVSXP));
	       SET_ENCLOS(envir, R_GlobalEnv);

	       SEXP rthread = PROTECT( Thread_new(VECTOR_ELT(args, 0),
	                     VECTOR_ELT(args, 1), VECTOR_ELT(args, 2),
	                     //VECTOR_ELT(args, 3),
			     envir,
			     VECTOR_ELT(args, 4),
			     R_NilValue));
	       cpid = INTEGER(rthread)[0];

	       //SEXP Threads = findVar(install(".Threads"), R_GlobalEnv);
	       SEXP Threads = SuprThreads; 
	       const char *name;
	       SEXP S_name = VECTOR_ELT(args, 4);
	       char port_str[16];
	       if(TYPEOF(S_name) == STRSXP || LENGTH(S_name) > 0){
	         name = CHAR(STRING_ELT(S_name, 0)); 
	       } else {
		 sprintf(port_str, "%d", cpid);
	         name = port_str;
	       }

	       defineVar(install(name), rthread, Threads);
	       UNPROTECT(5);

	     endcontext(&cntxt);
	     R_CStackStart = R_CStackStart;
	     R_unlock();
	   }

	   supr3_thread_info_t * info = malloc(sizeof(supr3_thread_info_t));
	   info->pid = cpid;
	   info->state = -1;
	   info->fd = -1; // child conn->fd
	   info->conn = conn; // client_conn
	   info->join_conn = NULL;

	   char thread[16];
	   sprintf(thread, "%d", cpid);
	   hashtablePut(threadInfoHashtable, thread, info);
	   //size = write(fd, &cpid, sizeof(int));
	 }
	 break;

    case THREAD_PROC_CHILD_START:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   pid_t cpid;
	   size = read(fd, &cpid, sizeof(int));
	   if(Supr_verbose)
	     fprintf(stderr, "[%s:%d] Start cpid: %d\n", __FILE__, __LINE__,
			     cpid);

	   char thread[16];
	   sprintf(thread, "%d", cpid);
	   supr3_thread_info_t *info = (supr3_thread_info_t *)
	     	hashtableGet(threadInfoHashtable, thread);

	   size = write(info->conn->fd, &cpid, sizeof(int));
	   info->fd = fd;
	   info->state = 0;
	 }
	 break;

    case THREAD_PROC_STATE:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   pid_t cpid;
	   size = read(fd, &cpid, sizeof(int));

	   if(cpid == -1){
	     size = read(fd, &cpid, sizeof(int));
	     int state;
	     size = read(fd, &state, sizeof(int));

	     if(Supr_verbose)
               fprintf(stderr, "\033[0;33m[STATE] thread: %d, reported state: %d\033[0m\n", cpid, state);
	     int rc = 0;
	     write(fd, &rc, sizeof(int));
	     if(state == 3) ThreadServer_removeConn(conn);

	     char thread[16];
	     sprintf(thread, "%d", cpid);
	     supr3_thread_info_t *info = (supr3_thread_info_t *)
	     	hashtableGet(threadInfoHashtable, thread);
	     if(!info) {
	       info = malloc(sizeof(supr3_thread_info_t));
	       info->pid = cpid;
	       info->join_conn = NULL;
	       hashtablePut(threadInfoHashtable, thread, info);
	     }
	     info->state = state;

	     if(Supr_verbose)
               fprintf(stderr, "\033[0;33m[STATE] info->join_conn: %p\033[0m\n", 
	     	info->join_conn);
	     if(state ==3 && info->join_conn) { // FIXME 
	       ThreadServer_join(info->join_conn, cpid);
	       hashtableDelete(threadInfoHashtable, thread);
	     }

	   } else {

	     char thread[16];
	     sprintf(thread, "%d", cpid);
	     supr3_thread_info_t *info = (supr3_thread_info_t *)
	     	hashtableGet(threadInfoHashtable, thread);
	     if(!info){
	       int rc = kill(cpid, THREAD_PROC_SIGSTATE);
	       write(fd, &rc, sizeof(int));
	     } else {
	       write(fd, &info->state, sizeof(int));
	     }
	   }
	 }
	 break;

    case THREAD_PROC_START:
         {
	   size_t size = read(fd, &cmd, sizeof(int));

	   pid_t cpid;
	   int rc = 0;


	   {
	     R_lock();

	     save_cstackstart = R_CStackStart;
	     supr3_thread_t *cth = pthread_getspecific(currentThreadKey);
	     R_CStackStart = cth->R_CStackStart;

	     size = read(fd, &cpid, sizeof(int));

	     char thread[16];
	     sprintf(thread, "%d", cpid);
	     supr3_thread_info_t *info = (supr3_thread_info_t *)
	     	hashtableGet(threadInfoHashtable, thread);

             if(info){
	       if(info->state==0){
	         size = write(info->fd, &cmd, sizeof(int));
	         info->state ++;
	       } else {
	         rc = -1;
	       }
	     } else {

	       RCNTXT cntxt;
	       begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv,
	       		R_BaseEnv, R_NilValue, R_NilValue);

	         cntxt.cend = &thread_proc_start_cleanup;
	         cntxt.cenddata = conn; // FIXME

	         SEXP val = Thread_start(ScalarInteger(cpid), R_NilValue);
		 rc = asInteger(val);

	       endcontext(&cntxt);
	     }
	     R_CStackStart = R_CStackStart;
	     R_unlock();
	   }

	   size = write(fd, &rc, sizeof(int));
	 }
	 break;

    case THREAD_PROC_JOIN:
         {
	   ssize_t size = read(fd, &cmd, sizeof(int));
	   pid_t cpid;
	   size = read(fd, &cpid, sizeof(int));

	   char thread[16];
	   sprintf(thread, "%d", cpid);
	   supr3_thread_info_t *info = (supr3_thread_info_t *)
	     	hashtableGet(threadInfoHashtable, thread);

	   if(!info){
	     int rc = -1;
	     write(fd, &rc, sizeof(int));
	   } else if(info->state <3) {
	     info->join_conn = conn;
	   } else {
	     ThreadServer_join(conn, cpid);
	     hashtableDelete(threadInfoHashtable, thread);
	   }
	 }
	 break;

    case THREAD_PROC_STOP:
         {
	   size_t size = read(fd, &cmd, sizeof(int));

	   int rc = 0;
	   write(fd, &rc, sizeof(int));
	   return -1;
	 }
	 break;

    case SUPR_INFO:
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   int len;
	   read(fd, &len, sizeof(int));
	   char *text = malloc(len);
	   read(fd, text, len);
	   fprintf(stderr, "\033[0;33m[INFO] %s\n\033[0m", text); 
	   int rc = 0;
	   write(fd, &rc, sizeof(int));
	 }
	 break;

    case THREAD_SERVER_SHUTDOWN:
         { // TODO
	   // terminate all threads ...
	   handleThreadServerShutdown(conn);
	   //no return
	   //exit(EXIT_SUCCESS);
	 }

	 break;




    default: // return -1;
	 {
	   if(Cluster_handleCommand)
	     return Cluster_handleCommand(conn);
	 }
	 /*
         {
	   size_t size = read(fd, &cmd, sizeof(int));
	   fprintf(stderr, "[%s:%d] %s: unknown command: %d\n",
	   	__FILE__, __LINE__, __func__, cmd);
	   int rc = -1;
	   write(fd, &cmd, sizeof(int));

	   // remove conn
           ThreadServer_removeConn(conn);
	    
	 }
	 break;
	 */
  }

  //fprintf(stderr, "\033[0m");
  return 0;
}

void createConnLog(supr_socket_conn_t *serverConn){
    char fileName[PATH_MAX];
    getcwd(fileName, PATH_MAX);
    char *syscmd = cmd;
    while(strstr(syscmd, "/")) syscmd = strstr(syscmd, "/") + 1;
    {
      char tmp[PATH_MAX];
      sprintf(tmp, "%s/%d", fileName, getpid());
      if(access(tmp, F_OK)==0) strcpy(fileName, tmp);
    }
    sprintf(fileName + strlen(fileName), "/%s.log", syscmd);
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\npid:%d\n", serverConn->port, getpid());
    size_t size = fileWrite(fileName, buf, strlen(buf)+1);
}

void ThreadServer_backend_run(supr3_thread_t *th)
{

//  fprintf(stderr, "\033[0;37m[%s:%d] %s: push(ThreadServer_backend_cleanup) by %d (with tid %d)\033[0m\n", __FILE__, __LINE__, __func__, getpid(), gettid());
  
//  pthread_cleanup_push(ThreadServer_backend_cleanup, ThreadServer_socket_connections);

  supr_socket_conn_t *serverConn = th->conn;

  ThreadServer_socket_connections = newVector(TRUE);
  vector_t *socket_connections = ThreadServer_socket_connections;

  vectorAdd(ThreadServer_socket_connections, serverConn);

  createConnLog(serverConn);
  
  int rc = 0;
  while(TRUE){
      struct timeval tv;
      //tv.tv_sec=1000;
      tv.tv_sec=100;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      //int fd = serverConn->fd;
      int max_fd = 0;

      // lock ...  printf("\n");
      for(int i=0; i<vectorSize(socket_connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i);

        //conn->print(conn);
        int fd = conn->fd;
        FD_SET(fd, &readfds);

        if(max_fd < fd) max_fd = fd;
      }
      //printf("Master: max_fd: %d\n", max_fd);

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
      //      fprintf(stderr, "Warning (%s): select()=%d\n", __func__, ns);
            if(ns==0) continue;
      } // else {
         //   fprintf(stderr,"[%s:%d] %s: select()=%d\n", __FILE__, __LINE__, __func__, ns);
//            fprintf(stderr, "%s: FD_ISSET(serverConn->fd, &readfds) = %d\n", __func__, FD_ISSET(serverConn->fd, &readfds));
      //} 

      for(int i = vectorSize(socket_connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i);
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
                continue;

        if(conn == serverConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(
	      (supr_conn_t*) serverConn // FIXME: ?
	      );
//          fprintf(stderr, "\033[0;31m[%s:%d] ThreadServer::clientConn, fd: %d\033[0m\n", __FILE__, __LINE__, clientConn->fd);

          vectorAdd(socket_connections, clientConn);

	  
	  /*
	  struct hostent *host_entry;
	  host_entry = gethostbyname(clientConn->host);
	  if(host_entry){
	    char IPbuffer[host_entry->h_length+1];
	    strncpy(IPbuffer, host_entry->h_addr_list[0],host_entry->h_length);
	    IPbuffer[host_entry->h_length] = '\0';
	    // TODO
            fprintf(stderr, "\033[0;31m[%s:%d] host: %s, IP addr: %s\033[0m\n",
                          __FILE__, __LINE__, clientConn->host, IPbuffer);
	    
	  }
	  */
	  /*
  { // IP/ip address:
 //   struct in_addr ipAddr = pclientAddr->sin_addr;
    char str[INET_ADDRSTRLEN];
  //  inet_ntop( AF_INET, &ipAddr, str, INET_ADDRSTRLEN );
    inet_ntop( AF_INET, &clientConn->sin_addr, str, INET_ADDRSTRLEN );
//    fprintf(stderr, "\033[0;35m[%s:%d] %s: str: %s\n\033[0m", __FILE__, __LINE__, __func__, str);
    unsigned char *ip = (unsigned char *) &clientConn->sin_addr;
    fprintf(stderr, "\033[0;35m[%s:%d] %s: unsigned char: %d.%d.%d.%d\n\033[0m",
                    __FILE__, __LINE__, __func__, ip[0], ip[1], ip[2], ip[3]);
  }
  */


        } else {
          rc = ThreadServer_handleCommand(conn);
	  if(rc == -1) break;
        }
      }
      if(rc == -1) break;
  }

}

void *ThreadServer_backendRun(void *arg)
{
  ThreadServer_tid = gettid();
  pthread_cleanup_push(ThreadServer_backend_cleanup,
  	ThreadServer_socket_connections);

  sigset_t set;
  sigemptyset(&set); 
  sigaddset(&set, SIGINT);
  int rc = pthread_sigmask(SIG_BLOCK, &set, NULL);
  if(rc != 0) error(_("pthread_sigmask, %s"), strerror(errno));

  //
  supr_socket_conn_t *conn = (supr_socket_conn_t*) ((void **)arg)[0];
  //printf("[%s] data = %p\n", __func__, data);

  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr3_thread_t **sth = (supr3_thread_t **) ((void **)arg)[2];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr3_thread_t *th = malloc(sizeof(supr3_thread_t));
  pthread_mutex_init(&th->mutex, NULL);
  pthread_cond_init(&th->cond, NULL);
  //th->ptid = pthread_self(); //th->pthread = pthread_self();
  th->conn = conn;
  th->R_CStackStart = (unsigned long) &conn; // See void *Thread_init(void *arg)
  th->data = (void*) ((void **)arg)[3];

  pthread_setspecific(currentThreadKey, th);

  th->pid = getpid();
  th->tid = gettid();
  th->ptid = pthread_self();
  th->name = strdup("threadserver");

  SEXP rho = PROTECT(R_NewHashedEnv(Thread_R_SharedEnv, //R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
  char name[32];
  sprintf(name, "\033[0;31m__ThreadServer_%d__\033[0m", gettid());
  //defineVar(install(name), rho, R_GlobalEnv);
  defineVar(install(name), rho, SuprEnv);
  th->sharedEnv = rho;
  UNPROTECT(1);

  setAttrib(rho, R_ClassSymbol, mkString("ThreadServer"));

  char addr[strlen(conn->host)+1+16];
  sprintf(addr, "%s:%d", conn->host, conn->port);
  setAttrib(rho, install("address"), mkString(addr));

  setAttrib(rho, install("host"), mkString(conn->host));
  setAttrib(rho, install("port"), ScalarInteger(conn->port));
  setAttrib(rho, install("type"), mkString("server"));
  
  *sth = th;
  Supr_threadServer = th;

  fprintf(stderr, "\033[0;33m[INFO] pid: %d, ThreadServer (tid: %d, pthread: %ld)\033[0m\n",
	 getpid(), gettid(), pthread_self());

  pthread_setspecific(currentThreadKey, th);
    pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  ThreadServer_backend_run(th);

  fprintf(stderr, "\033[0;31m[%s:%d] pop?\033[0m\n", __FILE__, __LINE__);
 
  ThreadServer_backend_cleanup(ThreadServer_socket_connections);

  pthread_exit(th);

  pthread_cleanup_pop(TRUE);

  return NULL; // not reached
}

void ThreadServer_backend_finalizer(SEXP s)
{
  supr3_thread_t *th = (supr3_thread_t *) R_ExternalPtrAddr(s);
  int rc = pthread_cancel(th->ptid); // int rc = pthread_cancel(th->pthread);
  rc = pthread_mutex_destroy(&th->mutex);
  rc = pthread_cond_destroy(&th->cond);
  free(th);
}

void ThreadServer_table_finalizer(SEXP s)
{
  R_ObjectTable *table = (R_ObjectTable *) R_ExternalPtrAddr(s);
  if(Supr_verbose)
    fprintf(stderr, "[%s:%d:%s]\n", __FILE__, __LINE__, __func__);
  free(table);
}

void ThreadServer_connect_finalizer(SEXP s)
{
  supr_socket_conn_t *sc = (supr_socket_conn_t *) R_ExternalPtrAddr(s);
  if(Supr_verbose)
    fprintf(stderr, "[%s:%d:%s]\n", __FILE__, __LINE__, __func__);
  close(sc->fd);
  free(sc); // use destroy... later FIXME 
}

void ThreadServer_timedwait_thread_run(supr3_thread_t *cth){

  while(TRUE){
    pthread_mutex_lock(syncHashtable->mutex);

      if(vectorSize(timedwait_queue) == 0){
        pthread_cond_wait(&cth->cond, syncHashtable->mutex);
      } else {
        sync_wait_t *sw = (sync_wait_t *) vectorElementAt(timedwait_queue,0);
        long sw_time = sw->wait.tv_sec*1000000000 + sw->wait.tv_nsec;

        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        long current_time = wait.tv_sec*1000000000 + wait.tv_nsec;

        if(sw_time <= current_time){
    if(Supr_verbose) {
      fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
		    sw->monitor, sw->sc->fd);
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }
          vectorRemoveElement(timedwait_queue, sw);
          char *mutex = sw->monitor;
          vector_t *wait_queue = getWaitQueue(sw->sc, sw->monitor);
          vector_t *sync_queue = getSyncQueue(sw->sc, sw->monitor);

    if(Supr_verbose) {
      fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
		    sw->monitor, sw->sc->fd);
      sync_wait_queue_print(sync_queue, "sync_queue");
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }

          if(!wait_queue || !sync_queue){
            fprintf(stderr, "[%s:%d:%s] ERROR, FIXME!\n",
			    __FILE__, __LINE__, __func__);
	  }
          vectorRemoveElement(wait_queue, sw);
          vectorAdd(sync_queue, sw);

    if(Supr_verbose) {
      fprintf(stderr, "[%d:%s] whichObj: %s, conn->fd: %d\n", __LINE__, __func__,
		    sw->monitor, sw->sc->fd);
      sync_wait_queue_print(sync_queue, "sync_queue");
      sync_wait_queue_print(wait_queue, "wait_queue");
      sync_wait_queue_print(timedwait_queue, "timedwait_queue");
    }

          if(vectorSize(sync_queue)==1){
            int rc = 0;
            ssize_t size = write(sw->sc->fd, &rc, sizeof(int));
	  }
          pthread_mutex_unlock(syncHashtable->mutex);
	  continue;
	} 

        pthread_cond_timedwait(&cth->cond, syncHashtable->mutex, &sw->wait);
      }
    pthread_mutex_unlock(syncHashtable->mutex);
  }

}

void *ThreadServer_timedwaitThreadRun(void *arg)
{
  sigset_t set;
  sigemptyset(&set); 
  sigaddset(&set, SIGINT);
  int rc = pthread_sigmask(SIG_BLOCK, &set, NULL);
  if(rc != 0)
    error(_("pthread_sigmask, %s"), strerror(errno));

  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[0];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr3_thread_t **sth = (supr3_thread_t **) ((void **)arg)[1];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr3_thread_t *th = malloc(sizeof(supr3_thread_t));

  pthread_mutex_init(&th->mutex, NULL);
  pthread_cond_init(&th->cond, NULL);
  th->ptid = pthread_self(); //th->pthread = pthread_self();
  th->conn = NULL;
  th->data = NULL;

  //
//  vectorAdd(threads, th);

  th->pid = getpid();
  th->tid = gettid();
  th->ptid= pthread_self();
  th->name= strdup(__func__);

  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  ThreadServer_timedwait_thread_run(th);

  pthread_exit(th);
  return NULL;
}




supr3_thread_t *ThreadServer_startTimedwaitThread()
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr3_thread_t *sth = NULL;
  void *arg[] = {&sem, &sth};
  int rc = pthread_create(&thread, NULL, ThreadServer_timedwaitThreadRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  //printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);


  return sth;
}





//
void *ThreadServer_proxyThreadRun(void *arg)
{
  sigset_t set;
  sigemptyset(&set); 
  sigaddset(&set, SIGINT);
  int rc = pthread_sigmask(SIG_BLOCK, &set, NULL);
  if(rc != 0)
    error(_("pthread_sigmask, %s"), strerror(errno));

  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[0];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr3_thread_t **sth = (supr3_thread_t **) ((void **)arg)[1];
  //printf("[%s] sth = %p\n", __func__, *sth);

  void (*run)(void*) = (void (*)(void*)) ((void **)arg)[2];
  void *run_data = (void *) ((void **)arg)[3];

  supr3_thread_t *th = malloc(sizeof(supr3_thread_t));
  //supr_thread_t *th = malloc(sizeof(supr3_thread_t));
  pthread_mutex_init(&th->mutex, NULL);
  pthread_cond_init(&th->cond, NULL);
  th->ptid = pthread_self(); //th->pthread = pthread_self();
  th->conn = NULL;
  th->data = NULL;



  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //ThreadServer_proxy_thread_run(th);
  run(run_data);

  pthread_exit(th);
  return NULL;
}


supr3_thread_t *ThreadServer_proxyThread(void (*run)(void*), void *data)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr3_thread_t *sth = NULL;
  void *arg[] = {&sem, &sth, run, data};
  int rc = pthread_create(&thread, NULL, ThreadServer_proxyThreadRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  //printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}
//

SEXP ThreadServer_start(SEXP S_port){

  // check Supr_usrHome/threads/Supr_hostname
  {
    //basic_info("%s: Supr_usrHome: %s\n", __func__, Supr_usrHome);
    //basic_info("%s: Supr_hostname: %s\n", __func__, Supr_hostname);
    char path[PATH_MAX];
    int n = snprintf(path, PATH_MAX, "%s/threads", Supr_usrHome);
    int rc = access(path, R_OK);
    if(rc==0){
      DIR *dir = opendir(path);
      if(!dir)
          error(_("opendir(%s): %s"), path, strerror(errno));
      closedir(dir);
    } else {
      int rc = mkdir(path, 0700);
      if(rc == -1)
          error(_("mkdir(%s): %s"), path, strerror(errno));
    }

    n = snprintf(path, PATH_MAX, "%s/threads/%s", Supr_usrHome, Supr_hostname);
    rc = access(path, R_OK);
    if(rc==0){
      DIR *dir = opendir(path);
      if(!dir)
          error(_("opendir(%s): %s"), path, strerror(errno));
      closedir(dir);
    } else {
      int rc = mkdir(path, 0700);
      if(rc == -1)
          error(_("mkdir(%s): %s"), path, strerror(errno));
    }

    DIR *dir = opendir(path);
    if(!dir)
          error(_("opendir(%s): %s"), path, strerror(errno));
    closedir(dir);
    Supr_threadDir = malloc(strlen(path)+1);
    strcpy(Supr_threadDir, path);
    fprintf(stderr, "\033[0;33m[INFO] thread dir: %s\033[0m\n", Supr_threadDir);
  }
   

  int port = INTEGER(S_port)[0];
  char hostname[256];
  int rc = gethostname(hostname, sizeof(hostname));

  int reuse_addr = port ? SocketConn_reuseAddr : FALSE;
  supr_socket_conn_t *conn = serverSocketOpen3(port, reuse_addr, cmd);

  if(!conn) error(_("cannot open the server socket"));

  // start a pthread to manage LocalEnv
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr3_thread_t *sth = NULL;

  void *arg[] = {conn, &sem, &sth, NULL};
  rc = pthread_create(&thread, NULL, ThreadServer_backendRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  vectorAdd(threads, sth);

  localEnvPort = sth->conn->port;
  localEnvHost = sth->conn->host;

  localThreadServerPort = sth->conn->port;
  localThreadServerHost = sth->conn->host;

  syncHashtable = newHashtable(TRUE);
  waitHashtable = newHashtable(TRUE);
  timedwait_queue = newVector(FALSE);

  if(threadInfoHashtable){
    // wait ...
    pthread_mutex_lock(threadInfoHashtable->mutex);
    pthread_mutex_unlock(threadInfoHashtable->mutex);
  } else 
    threadInfoHashtable = newHashtable(TRUE);

  supr3_thread_t *tw_th = ThreadServer_startTimedwaitThread();
  sth->data = tw_th; // FIXME

  vectorAdd(threads, tw_th);

  ThreadServer_timedwait_thread = tw_th;

  SEXP backendPtr = PROTECT(R_MakeExternalPtr(sth, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(backendPtr, ThreadServer_backend_finalizer, TRUE);
  setAttrib(sth->sharedEnv, install("pthread"), backendPtr);
  UNPROTECT(1);

  return sth->sharedEnv;
}

SEXP ThreadServer_ping(SEXP server, SEXP S_timeout);

SEXP ThreadServer_stop(SEXP server){

    {
      SEXP timeout = PROTECT(ScalarReal(0));
      SEXP ping = PROTECT(ThreadServer_ping(server, timeout));
      PrintValue(ping);
      UNPROTECT(2);
    }

    char buf[strlen(CHAR(STRING_ELT(server,0)))+1];
    strcpy(buf, CHAR(STRING_ELT(server,0)));
    char *port_str = strstr(buf, ":");
    char *host = buf;
    int port;
    if(port_str) {
      *port_str = 0;
      port_str++;
      port = atoi(port_str);
    } else {
      port = atoi(host);
    }
    supr_socket_conn_t *sc = socketOpen2(host, port);
    if(!sc)
      error(_("cannot connect to %s"), CHAR(STRING_ELT(server,0)));

    int cmd = THREAD_PROC_STOP;
    write(sc->fd, &cmd, sizeof(int));

    int rc;
    read(sc->fd, &rc, sizeof(int));
    close(sc->fd);
    free(sc); // use destroy ...

    Supr_threadServer = NULL;

    return ScalarInteger(rc);
}











SEXP ThreadServer_ping(SEXP server, SEXP S_timeout){

  supr_socket_conn_t *sc = NULL;

  SEXP conn = PROTECT(getAttrib(server, install("conn")));

  int destroy = FALSE;
  if(TYPEOF(conn) != NILSXP){
    sc = (supr_socket_conn_t *) R_ExternalPtrAddr(conn);
  } else {
    char buf[strlen(CHAR(STRING_ELT(server,0)))+1];
    strcpy(buf, CHAR(STRING_ELT(server,0)));
    char *port_str = strstr(buf, ":");
    char *host = buf;
    int port;
    if(port_str) {
      *port_str = 0;
      port_str++;
      port = atoi(port_str);
    } else {
      port = atoi(host);
    }
    sc = socketOpen2(host, port);
    destroy = TRUE;
  }
  UNPROTECT(1);

  if(!sc)
      error(_("cannot connect to %s"), CHAR(STRING_ELT(server,0)));

    /*
    int cmd = THREAD_PROC_JOIN;// use a proxy thread to do this? later...
    write(sc->fd, &cmd, sizeof(int));
    R_unlock();
    write(sc->fd, INTEGER(thread), sizeof(int));
    */

 /*
  int rc = 0;
  //supr3_thread_t *th = (supr3_thread_t *) R_ExternalPtrAddr(S_backend);

  //supr_socket_conn_t *sc = socketOpen2(th->conn->host, th->conn->port);

  int i= -1;
  if(sc){
    int cmd = CLUSTER_PING;
    ssize_t size =  write(sc->fd, &cmd, INT_SIZE);
    if(size != INT_SIZE){
          printf("Error in write: %s\n", strerror(errno));
    }

    i = 0;
    for(; i<60; i++){
          size = recv(sc->fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
          if(size == INT_SIZE) {
             break;
          }
          else {
            printf("Warning in recv, size: %ld (%s)\n", size, strerror(errno));
            sleep(1);
          }
    }
    if(i<60) {
	  size = read(sc->fd, &cmd, INT_SIZE);
                printf("Main, size: %ld, cmd: %d\n", size, cmd);
    } else {
          printf("Error in recv: %s\n", strerror(errno));
    }
    */
  //  int rc = -1;
  double time_elapsed=0;
  double timeout= REAL(S_timeout)[0];
    //for(;;)
  {
      struct timeval tv; // use timeout...
      //tv.tv_sec=1000;
      tv.tv_sec= (long) floor(timeout);
      tv.tv_usec=(long) floor((timeout - floor(timeout))*1000000); // FXIME

      fd_set readfds;
        FD_ZERO(&readfds);

      //int fd = serverConn->fd;
      int fd = sc->fd;
      int max_fd = fd;
      FD_SET(fd, &readfds);

      struct timespec wait_start;
      clock_gettime(CLOCK_REALTIME, &wait_start);

      int cmd = CLUSTER_PING;
      ssize_t size =  write(sc->fd, &cmd, INT_SIZE);

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
   //     rc = -1; //break;
        time_elapsed = -1;
      } else {
        size = recv(sc->fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
        if(size == INT_SIZE) {
	  struct timespec wait;
	  clock_gettime(CLOCK_REALTIME, &wait);
	  long nsec = wait.tv_nsec - wait_start.tv_nsec
	            +(wait.tv_sec - wait_start.tv_sec)*1000000000;
//	  rc = 0;
          time_elapsed = nsec/1000000000.0;
	  //break;
        }
      }
  }


  if(destroy) {
      close(sc->fd);
      free(sc); // FIXME?
  }

  //return ScalarInteger(i);
  return ScalarReal(time_elapsed);
}


supr_socket_conn_t* Sync_connect(SEXP server)
{
  char *host = NULL;
  int port;
  supr_socket_conn_t *sc = NULL;

  //if(Supr_verbose){
    verbose_info("[%s:%d:%s] OBJECT(server): %d\n", __FILE__, __LINE__,
		    __func__, OBJECT(server));
    verbose_info("[%s:%d:%s] inherits(server, \"UserDefinedDatabase\"): %d\n",
		    __FILE__, __LINE__,
		    __func__, inherits(server, "UserDefinedDatabase"));
  //}
  if(IS_USER_DATABASE(server))
    server = getAttrib(server, install("address"));


  if(Supr_verbose){
    fprintf(stderr, "[%s:%d:%s] server:\n", __FILE__, __LINE__, __func__);
    PrintValue(server);
  }

  if(TYPEOF(server) == STRSXP || LENGTH(server)>0){
    const char *addr = CHAR(STRING_ELT(server, 0));  
    //basic_info("%s: addr=%s", __func__, addr);

  //} else if(TYPEOF(server) == EXTPTRSXP){
    //supr3_thread_t *th = (supr3_thread_t *) R_ExternalPtrAddr(server);
    char buf[strlen(addr)+1];
    strcpy(buf, addr);
    char* port_str = strstr(buf, ":");
    host = buf;
    if(port_str){
      *port_str = 0;
      port_str++;
      port = atoi(port_str);
    } else {
      host = "localhost";
      port = atoi(buf);
    }
    if(Supr_verbose)
      fprintf(stderr, "[%s:%d:%s] host: %s, port: %d\n", __FILE__, __LINE__, 
		     __func__, host, port);
    sc = socketOpen2(host, port);
    if(!sc)
      error(_("cannot connect to %s:%d"), host, port);
  } else if(TYPEOF(server) == INTSXP || LENGTH(server)>0){
      host = "localhost";
      port = INTEGER(server)[0];
      fprintf(stderr, "[%s:%d] host: %s, port: %d\n", __FILE__, __LINE__, host, port);
      sc = socketOpen2(host, port);
      if(!sc)
        error(_("cannot connect to %s:%d"), host, port);
  } else {
    error(_("TODO"));
  }


  //supr_socket_conn_t *sc = socketOpen2(host, port); if(!sc) error(_("cannot connect %s:%d"), host, port);
  return sc;
}





Rboolean ThreadServer_exists(const char * const name, Rboolean *canCache, R_ObjectTable *tb){
//  fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__, name);
//  return FALSE;
//SEXP Sync_exists(SEXP x, SEXP server) {

  SEXP server = tb->privateData; 
  SEXP x = PROTECT(mkString(name));

  supr_socket_conn_t* sc =  Sync_connect(server);
  int cmd = THREAD_PROC_EXISTS;
  write(sc->fd, &cmd, sizeof(int));

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  UNPROTECT(5);

  close(sc->fd);
  free(sc); // FIXME

  return LOGICAL(ret_val)[0];
//}


}

SEXP     ThreadServer_get(const char * const name, Rboolean *canCache, R_ObjectTable *tb){
  //R_UnboundValue;
//  fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__, name);
//  return R_TrueValue;
//SEXP Sync_get(SEXP x, SEXP server) {

//  R_ObjectTable *tb = ThreadServer_createObjectTable(server);
// testing


  SEXP local = ((SEXP*)(tb+1))[0];
  if(TYPEOF(local) == ENVSXP){

//    if(local == tb->privateData) error(_("FIXME: %s:%d:%s"), __FILE__, __LINE__, __func__);

    SEXP val = findVar(install(name), local);
    if(val != R_UnboundValue)
      return val;
  }

  SEXP server = (SEXP) tb->privateData; 

  
  SEXP x = PROTECT(mkString(name));

  supr_socket_conn_t* sc =  Sync_connect(server);

  int cmd = THREAD_PROC_GET;
  write(sc->fd, &cmd, sizeof(int));

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  UNPROTECT(5);

  close(sc->fd);
  free(sc); // FIXME

  if(LENGTH(x)==1)
    return VECTOR_ELT(ret_val, 0);
  else 
    return ret_val;
//}


}

int ThreadServer_remove(const char * const name, R_ObjectTable *tb){
//  fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__, name);
//return NA_INTEGER;
//SEXP Sync_remove(SEXP x, SEXP server) {

  SEXP server = tb->privateData; 
  SEXP x = PROTECT(mkString(name));

  supr_socket_conn_t* sc =  Sync_connect(server);
  int cmd = THREAD_PROC_REMOVE;
  write(sc->fd, &cmd, sizeof(int));

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  UNPROTECT(5);

  close(sc->fd);
  free(sc); // FIXME

  return INTEGER(ret_val)[0];
//}

}

SEXP ThreadServer_assign(const char * const name, SEXP value, R_ObjectTable *tb)
{
  //fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__, name);
  SEXP server = tb->privateData; 
  SEXP x = PROTECT(mkString(name));

  //fprintf(stderr, "[%s:%d] (%s) server:\n", __FILE__, __LINE__, __func__);
  //PrintValue(server);
  supr_socket_conn_t* sc =  Sync_connect(server);


  int cmd = THREAD_PROC_PUT;
  write(sc->fd, &cmd, sizeof(int));


  // send list(x, val)
  SEXP message = PROTECT(allocVector(VECSXP, 2));
  SET_VECTOR_ELT(message, 0, x);
  SET_VECTOR_ELT(message, 1, value);

  //fprintf(stderr, "[%s:%d] (%s) message:\n", __FILE__, __LINE__, __func__);
  //PrintValue(message);

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(message, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  // receive the return code
  int rc;
  read(sc->fd, &rc, sizeof(int));
  R_lock();
  UNPROTECT(4);

  close(sc->fd);
  free(sc); // FIXME

  if(rc == 0)
    return value;
  else 
    error(_("ThreadServer_assign"));
//} 
}

//SEXP (*ThreadServer_objects)(R_ObjectTable *tb) = Cluster_objects;

//
SEXP ThreadServer_objects(R_ObjectTable *tb){

//  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
//  return R_NilValue;
//SEXP Sync_list(SEXP server) {

  SEXP server = tb->privateData; 

  supr_socket_conn_t* sc =  Sync_connect(server);
  sc->cmd = strdup(__func__);

  R_unlock();
  int cmd = THREAD_PROC_LIST;
  write(sc->fd, &cmd, sizeof(int));

  int raw_len;
  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  SEXP raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  SEXP call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  /*
  SEXP local = ((SEXP*)(tb+1))[0];
  if(TYPEOF(local) == ENVSXP){
    setAttrib(ret_val, install(".LocalEnv"), local);
  }
  */


  UNPROTECT(2);

  /*
  close(sc->fd);
  free(sc); // FIXME
  */
  Supr_decref(sc);

  return ret_val;
//}
}
//

Rboolean ThreadServer_canCache(const char * const name, R_ObjectTable *tb){
  fprintf(stderr, "[%s:%d] (%s) name: %s\n", __FILE__, __LINE__, __func__,
  	name);
  return FALSE;
}

void  ThreadServer_onDetach(R_ObjectTable *tb)
{
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}
void ThreadServer_onAttach(R_ObjectTable *tb)
{
  fprintf(stderr, "[%s:%d] (%s)\n", __FILE__, __LINE__, __func__);
}



//R_ObjectTable *ThreadServer_createObjectTable(SEXP server)
SEXP ThreadServer_createObjectTableEnv()
{
  //{
     //    #define IS_USER_DATABASE(rho)  (OBJECT((rho)) && inherits((rho), "UserDefinedDatabase"))

  //}

  R_ObjectTable *table = malloc(sizeof(R_ObjectTable) + sizeof(SEXP));
  table->type = NA_INTEGER; // TODO
  table->cachedNames = NULL;
  table->active = TRUE;

  table->exists = ThreadServer_exists;
  table->get = ThreadServer_get;
  table->remove = ThreadServer_remove;
  table->assign = ThreadServer_assign;
  table->objects= ThreadServer_objects;
  table->canCache = ThreadServer_canCache;

  table->onDetach = ThreadServer_onDetach;
  table->onAttach = ThreadServer_onAttach;

  //table->privateData = NULL;
  //table->privateData = table + 1;

  //SEXP udb = PROTECT(R_MakeExternalPtr(table, R_NilValue, R_NilValue));

  SEXP rho = PROTECT(allocSExp(ENVSXP));
  SET_ENCLOS(rho, R_EmptyEnv);
  SEXP tbPtr = PROTECT(R_MakeExternalPtr(table, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(tbPtr, ThreadServer_table_finalizer, TRUE);
  SET_HASHTAB(rho, tbPtr);

  OBJECT(rho) = TRUE;

  //setAttrib(rho, R_ClassSymbol, mkString("UserDefinedDatabase"));
  SEXP klass = PROTECT(allocVector(STRSXP, 2));
  SET_STRING_ELT(klass, 0, mkChar("ThreadServer"));
  SET_STRING_ELT(klass, 1, mkChar("UserDefinedDatabase"));
  setAttrib(rho, R_ClassSymbol, klass);

  //int what = OBJECT(rho) && inherits(rho, "UserDefinedDatabase");
  //fprintf(stderr, "[%s:%d] (%s) what: %d, val:\n", __FILE__, __LINE__, __func__, what);
  //SEXP val = findVar(install("any"), rho);
  //PrintValue(val);

  //setAttrib(rho, install("address"), server);

  UNPROTECT(3);

  table->privateData = rho;
  ((SEXP*)(table + 1))[0] = R_NilValue;

  return rho;
}

SEXP ThreadServer_connect(SEXP server)
{

    char buf[strlen(CHAR(STRING_ELT(server,0)))+1];
    strcpy(buf, CHAR(STRING_ELT(server,0)));
    char *port_str = strstr(buf, ":");
    char *host = buf;
    int port;
    if(port_str) {
      *port_str = 0;
      port_str++;
      //fprintf(stderr, "[%s] port_str: %s\n", __func__, port_str);
      port = atoi(port_str);
      //fprintf(stderr, "[%s] port: %d\n", __func__, port);
    } else {
      port = atoi(host);
      host = "localhost";
    }
    supr_socket_conn_t *sc = socketOpen2(host, port);
    if(!sc)
      error(_("cannot connect to %s"), CHAR(STRING_ELT(server,0)));

    //fprintf(stderr, "[%s] %s:%d\n", __func__, sc->host, sc->port);

    SEXP ret_val = PROTECT(ThreadServer_createObjectTableEnv());
    char addr[strlen(sc->host)+16];//sprintf(addr, "%s:%d", sc->host, sc->port);
    sc->port = port;
    sprintf(addr, "%s:%d", sc->host, sc->port);
    setAttrib(ret_val, install("address"), mkString(addr));

    SEXP scPtr = PROTECT(R_MakeExternalPtr(sc, R_NilValue, R_NilValue));
    R_RegisterCFinalizerEx(scPtr, ThreadServer_connect_finalizer, TRUE);
    //setAttrib(scPtr, R_ClassSymbol, mkString("conn"));

    setAttrib(ret_val, install("type"), mkString("client"));
    setAttrib(ret_val, install("host"), mkString(sc->host));
    setAttrib(ret_val, install("port"), ScalarInteger(sc->port));
    setAttrib(ret_val, install("conn"), scPtr);

  if(Supr_namespace){
    SEXP server = ret_val;
    SEXP localEnv = Cluster_setLocalEnvToObjectTable(server, R_NilValue);
    defineVar(install(".LocalEnv"), localEnv, localEnv);

    defineVar(install("address"), getAttrib(ret_val, install("address")),
    	localEnv);


    SEXP thread_new = findVar(install("Thread.new"), Supr_namespace);

    if(TYPEOF(thread_new) == PROMSXP){
      thread_new = PROTECT(eval(thread_new, R_GlobalEnv));
    }
    else PROTECT(thread_new);

    SEXP formals = FORMALS(thread_new);
    SEXP func = PROTECT(allocSExp(CLOSXP));
    SET_BODY(func, BODY(thread_new));
    SET_CLOENV(func, CLOENV(thread_new));
    SEXP func_formals=PROTECT(CONS(R_NilValue, R_NilValue));
    SEXP args=func_formals;

    while(TYPEOF(formals) != NILSXP){
      if(//TYPEOF(TAG(formals)) == SYMSXP &&
		      strcmp(CHAR(PRINTNAME(TAG(formals))),"server")==0){
        SETCDR(args, CONS(server, R_NilValue));
      } else {
        SETCDR(args, CONS(CAR(formals), R_NilValue));
      }
      args = CDR(args);
      SET_TAG(args, TAG(formals));

      formals = CDR(formals);
    }
    SET_FORMALS(func, CDR(func_formals));
    defineVar(install("new"), func, localEnv);
    UNPROTECT(3);

    SEXP ths_localfuns = findVar(install("ths.localfuns"), Supr_namespace);
    if(ths_localfuns != R_UnboundValue){
      if(TYPEOF(ths_localfuns) == PROMSXP){
        ths_localfuns = PROTECT(eval(ths_localfuns, R_GlobalEnv));
      }
      else PROTECT(ths_localfuns);
      if(TYPEOF(ths_localfuns) == LISTSXP){// defined in supr3
        SEXP s = ths_localfuns;
	while(TYPEOF(s) != NILSXP){
	  if(TYPEOF(CAR(s)) == CLOSXP){
		  
            SEXP f = CAR(s);
            SEXP formals = FORMALS(f);
	    SEXP func = PROTECT(allocSExp(CLOSXP));
	    SET_BODY(func, BODY(f));
	    SET_CLOENV(func, CLOENV(f));
	    SEXP func_formals=PROTECT(CONS(R_NilValue, R_NilValue));
	    SEXP args=func_formals; 
	    
	    while(TYPEOF(formals) != NILSXP){
	      if(strcmp(CHAR(PRINTNAME(TAG(formals))),"server")==0){
		      SETCDR(args, CONS(server, R_NilValue));
	      } else {
		      SETCDR(args, CONS(CAR(formals), R_NilValue));
	      }
	      args = CDR(args);
	      SET_TAG(args, TAG(formals)); 
	      formals = CDR(formals);
	    }
	    SET_FORMALS(func, CDR(func_formals));
            defineVar(TAG(s), func, localEnv);
	    UNPROTECT(2);

	  } else
            defineVar(TAG(s), CAR(s), localEnv);
	  s = CDR(s);
	} 
      }
      UNPROTECT(1);
    }
  }

    UNPROTECT(2);
    return ret_val;
}

/*
SEXP Sync_get(SEXP x, SEXP server)
{

//  R_ObjectTable *tb = ThreadServer_createObjectTable(server);
// testing

  supr_socket_conn_t* sc =  Sync_connect(server);
  int cmd = THREAD_PROC_GET;
  write(sc->fd, &cmd, sizeof(int));

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  UNPROTECT(4);

  close(sc->fd);
  free(sc); // FIXME

  if(LENGTH(x)==1)
    return VECTOR_ELT(ret_val, 0);
  else 
    return ret_val;
}



*/

/*
SEXP Sync_put(SEXP x, SEXP val, SEXP server)
{
  supr_socket_conn_t* sc =  Sync_connect(server);

  int cmd = THREAD_PROC_PUT;
  write(sc->fd, &cmd, sizeof(int));

  // send list(x, val)
  SEXP message = PROTECT(allocVector(VECSXP, 2));
  SET_VECTOR_ELT(message, 0, x);
  SET_VECTOR_ELT(message, 1, val);

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(message, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  // receive the return code
  int rc;
  read(sc->fd, &rc, sizeof(int));
  R_lock();
  UNPROTECT(3);

  close(sc->fd);
  free(sc); // FIXME

  return ScalarInteger(rc);
}

*/






/*
SEXP Sync_exists(SEXP x, SEXP server)
{
  supr_socket_conn_t* sc =  Sync_connect(server);
  int cmd = THREAD_PROC_EXISTS;
  write(sc->fd, &cmd, sizeof(int));

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  UNPROTECT(4);

  close(sc->fd);
  free(sc); // FIXME

  return ret_val;
}



*/






/*
SEXP Sync_remove(SEXP x, SEXP server)
{
  supr_socket_conn_t* sc =  Sync_connect(server);
  int cmd = THREAD_PROC_REMOVE;
  write(sc->fd, &cmd, sizeof(int));

  SEXP call = PROTECT(LCONS(install("serialize"),
  	CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = PROTECT(eval(call, R_GlobalEnv));
  int raw_len = LENGTH(raw);

  R_unlock();
  write(sc->fd, &raw_len, sizeof(int));
  write(sc->fd, RAW(raw), raw_len);

  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  UNPROTECT(4);

  close(sc->fd);
  free(sc); // FIXME

  return ret_val;
}


*/


/*
SEXP Sync_list(SEXP server)
{
  supr_socket_conn_t* sc =  Sync_connect(server);

  R_unlock();
  int cmd = THREAD_PROC_LIST;
  write(sc->fd, &cmd, sizeof(int));

  int raw_len;
  read(sc->fd, &raw_len, sizeof(int));
  if(raw_len == -1)
    error(_("Sync_get: FIXME")); // provide more info

  R_lock();
  SEXP raw = PROTECT(allocVector(RAWSXP, raw_len));
  read(sc->fd, RAW(raw), raw_len);
  SEXP call = PROTECT(LCONS(install("unserialize"),
  	CONS(raw, R_NilValue)));
  SEXP ret_val = eval(call, R_GlobalEnv);

  UNPROTECT(2);

  close(sc->fd);
  free(sc); // FIXME

  return ret_val;
}
*/

/*
SEXP Sync_remove(SEXP x, SEXP server)
{
  supr_socket_conn_t* sc =  Sync_connect(server);
  int cmd = THREAD_PROC_REMOVE;
return R_NilValue;
}

SEXP Sync_list(SEXP server)
{
  supr_socket_conn_t* sc =  Sync_connect(server);
  int cmd = THREAD_PROC_LIST;
return R_NilValue;
}
*/


SEXP Sync_wait(SEXP monitor, SEXP S_timeout, SEXP env)
{
  int nUNPROTECT = 0;

  if(TYPEOF(monitor) == LANGSXP && strcmp(CHAR(asChar(CAR(monitor))), "$")) {
    monitor = PROTECT(eval(monitor, env));
    nUNPROTECT++;
  }

  if(TYPEOF(monitor) == SYMSXP || TYPEOF(monitor) == STRSXP) {
      // use the default sync server
      if(TYPEOF(monitor) == SYMSXP) {
        monitor = PROTECT(mkString(CHAR(PRINTNAME(monitor))));
        nUNPROTECT++;
      } 

      SEXP retval = TR_wait(monitor, S_timeout, env);
      UNPROTECT(nUNPROTECT);
      return retval;
  }

  int save = R_PPStackTop;

  const char *whichEnv = NULL;
  const char *whichObj = NULL;

  char *host = NULL;
  int port = -1;
  
  if(TYPEOF(monitor) == LANGSXP) {

    if( strcmp(CHAR(asChar(CAR(monitor))), "$") == 0 ) {

      SEXP server = PROTECT(eval(CADR(monitor), env));
      nUNPROTECT++;

      if(!IS_USER_DATABASE(server)) { // FIXME
         PrintValue(server);
         error(_("invalid 'sharedEnv' argument in 'sharedEnv$monitor'"));
      }

      whichObj = CHAR(asChar(CADDR(monitor)));

      if(server == SuprJobEnv)
        return  TR_wait(mkString(whichObj), S_timeout, env);

      whichEnv = CHAR(STRING_ELT(getAttrib(server, install("address")), 0));

    } else {
      error(_("invalid argument 'monitor'"));
    }
  } else
    error(_("invalid argument 'monitor'"));

  //fprintf(stderr, "\033[0;33m%s(%s$%s, ...)\n", __func__,  whichEnv,  whichObj);

  char whichEnv_str[strlen(whichEnv)+1];
  strcpy(whichEnv_str, whichEnv);
  whichEnv = whichEnv_str;
  UNPROTECT(nUNPROTECT);
      
  //int rc = supr3_lock(whichEnv,  whichObj);

  supr_socket_conn_t *sc = ThreadServer_getMonitorConn(whichEnv, whichObj);
  if(!sc)
    error(_("must be synchronized on %s$%s"), whichEnv, whichObj);


  int cmd = THREAD_PROC_WAIT;
  write(sc->fd, &cmd, sizeof(int)); 
  int len = strlen(whichObj)+1;
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, whichObj, len); 

  //write(sc->fd, REAL(S_timeout), sizeof(double)); 
  len = LENGTH(S_timeout);
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, RAW(S_timeout), len); 


  int rc;
  read(sc->fd, &rc, sizeof(int));

  if(rc == -1){ // Error occurred, read the error code
    read(sc->fd, &len, sizeof(int));
    char err[len];
    read(sc->fd, err, len);
    error(_("%s"), err);
  }

  fprintf(stderr, "[%s:%d:%s] rc: %d\n", __FILE__, __LINE__, __func__, rc);

  if(save != R_PPStackTop)
       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
	     __FILE__, __LINE__, __func__, save, R_PPStackTop);

  return ScalarInteger(rc);

}

#else

// r_timeout unit: second
SEXP Sync_wait(SEXP x, SEXP r_timeout, SEXP env)
{
//  fprintf(stderr, "Supr_threadType: %d\n", Supr_threadType);


  if(TYPEOF(x) == LANGSXP){

    const char *x_str = CHAR(asChar(CADR(x)));
    //fprintf(stderr, "[%s] x_str: %s\n", __func__, x_str);
    if(strcmp(x_str, ".JobEnv")){
      const char *m_str = CHAR(asChar(CADDR(x)));
      //fprintf(stderr, "[%s] m_str: %s\n", __func__, m_str);
      SEXP mutex = PROTECT(mkString(m_str));
      SEXP val = TR_wait(mutex, r_timeout, env);
      UNPROTECT(1);
      return val;
    }

    if(Supr_threadType == 1) { //  local process ...
      return Supr_localProcSyncWait(x, r_timeout);
    } else if(Supr_threadType == 2) { //  remote  process ...
      return Supr_remoteProcSyncWait(x, r_timeout);
    } 
  }
  
  x = PROTECT(eval(x, env));


  supr_monitor_t *m;

#ifdef  TEST_GET_MONITOR
  //if(x == R_NilValue) m = Supr_findMonitor(); else // FIXME for processes
    m = Supr_getMonitor(x, FALSE);
#else
//int savestack = R_PPStackTop;
  SEXP monitor = getAttrib(x, install("monitor"));
  if(TYPEOF(monitor) != EXTPTRSXP)
    errorcall(R_NilValue, "illegal call (%s:%d)", __FILE__, __LINE__);

  m = (supr_monitor_t *) R_ExternalPtrAddr(monitor);
  //printf("[%s] m->class: %p\n", __func__, m->class);
  if(m->class != Monitor_class)
    errorcall(R_NilValue, "illegal call (%s:%d)", __FILE__, __LINE__);
#endif


  double timeout = asReal(r_timeout);
  int rc;
  supr_thread_t *cth = currentThread();

  int do_unlock = FALSE;

  if(m->tid != cth->tid) {
    if(m->mutex.__data.__owner == cth->tid)
      warning("FIXME, not the owner of the monitor (%s:%d)", __FILE__,
		    __LINE__);
    else {
      BEGIN_R_FREE();
        rc = pthread_mutex_lock(&m->mutex);
      END_R_FREE();
      if (rc != 0){
        error(_("failed to lock\n"));
      } else {
        m->tid = cth->tid;
	do_unlock = TRUE;
      }
    } 
  }

  BEGIN_R_FREE();

    if(timeout <= 0){
      Thread_setState(cth, THREAD_STATE_WAITING);
      rc = pthread_cond_wait(&m->cond, &m->mutex);
    } else {
      struct timespec wait;
      clock_gettime(CLOCK_REALTIME, &wait);
      wait.tv_sec += (long) timeout;

      Thread_setState(cth, THREAD_STATE_TIMED_WAITING);
      rc = pthread_cond_timedwait(&m->cond, &m->mutex, &wait);
      if(rc == ETIMEDOUT){
        if(m->mutex.__data.__owner != cth->tid) {
          int rc_lock = pthread_mutex_lock(&m->mutex);
	  printf("WHOOPS, shouldn't happen???\n");
	  __FIXME__(__func__);
	}
	
        if(m->mutex.__data.__owner == cth->tid)
		m->tid = cth->tid;
      }
    }

    if(m->mutex.__data.__owner == cth->tid)
		m->tid = cth->tid;

  END_R_FREE();

  UNPROTECT(1);

  if(do_unlock) {
      m->tid = 0;
      int rc = pthread_mutex_unlock(&m->mutex); // ...
  }

  return ScalarInteger(rc);
}

#endif

SEXP Sync_lock(SEXP x)
{
  supr_monitor_t *m;
#ifdef  TEST_GET_MONITOR
  m = Supr_getMonitor(x, FALSE);
#else
  SEXP monitor = getAttrib(x, install("monitor"));
  if(TYPEOF(monitor) != EXTPTRSXP)
    errorcall(R_NilValue, "not a monitor object (%s:%d)", __FILE__, __LINE__);

  m = (supr_monitor_t *) R_ExternalPtrAddr(monitor);
  //printf("[%s] m->class: %p\n", __func__, m->class);
  if(m->class != Monitor_class)
    errorcall(R_NilValue, "not a monitor object (%s:%d)", __FILE__, __LINE__);
#endif
  //printf("LOCKING ...\n");
  /*
  if(m->tid != currentThread()->tid)
    errorcall(R_NilValue, "illegal call, not the owner of the monitor");
    */

  int rc;
  supr_thread_t *cth = currentThread();

  BEGIN_R_FREE();

    rc = pthread_mutex_lock(&m->mutex);

  END_R_FREE();

  if(rc == 0)
    m->tid = cth->tid;

  return ScalarInteger(rc);
}

SEXP Sync_unlock(SEXP x)
{
  supr_monitor_t *m;
#ifdef  TEST_GET_MONITOR
  m = Supr_getMonitor(x, FALSE);
#else
  SEXP monitor = getAttrib(x, install("monitor"));
  if(TYPEOF(monitor) != EXTPTRSXP) {// do the same for Sync_eval, wait, and notify
	  // by creating Supr_getMonitor(SEXP x) ...
    SEXP klass = getAttrib(x, R_ClassSymbol);
    if(klass != NULL && strcmp(CHAR(asChar(klass)), "monitor")== 0) 
      monitor = x;
    else
      error("not a monitor object (%s:%d)", __FILE__, __LINE__);
  }
  m = (supr_monitor_t *) R_ExternalPtrAddr(monitor);
  if(m->class != Monitor_class)
    error("not a monitor object (%s:%d)", __FILE__, __LINE__);
#endif

  int rc;
  supr_thread_t *cth = currentThread();

  if(m->tid != cth->tid) {  // error ->SIGSEV: fixme
    if(m->mutex.__data.__owner != cth->tid) 
      error("illegal call, not the owner of the monitor (%s:%d)",
		    __FILE__, __LINE__);
    else {
      warning("Warning: FIXME (%s:%d)", __FILE__, __LINE__);
      fprintf(stderr, "Warning: FIXME (%s:%d)", __FILE__, __LINE__);
      c_backtrace();
    }
  } else
    m->tid = 0;

  if(m->mutex.__data.__owner != cth->tid) 
    error("unlock: %s is not the owner of %s", cth->name, m->name);
  
  rc = pthread_mutex_unlock(&m->mutex);
  return ScalarInteger(rc);
}

#ifdef SUPR3

SEXP Sync_notify(SEXP monitor, SEXP S_all, SEXP env)
{ //  fprintf(stderr, "Supr_threadType: %d\n", Supr_threadType);
  int nUNPROTECT = 0;
    if(TYPEOF(monitor) == LANGSXP && strcmp(CHAR(asChar(CAR(monitor))), "$")) {
    monitor = PROTECT(eval(monitor, env));
    nUNPROTECT++;
  }

  if(TYPEOF(monitor) == SYMSXP || TYPEOF(monitor) == STRSXP) {
      // use the default sync server
      if(TYPEOF(monitor) == SYMSXP) {
        monitor = PROTECT(mkString(CHAR(PRINTNAME(monitor))));
        nUNPROTECT++;
      }

      SEXP retval = TR_notify(monitor, S_all, env);
      UNPROTECT(nUNPROTECT);
      return retval;
  }

  int save = R_PPStackTop;
  const char *whichEnv = NULL;
  const char *whichObj = NULL;

  char *host = NULL;
  int port = -1;

  if(TYPEOF(monitor) == LANGSXP) {

    if( strcmp(CHAR(asChar(CAR(monitor))), "$") == 0 ) {

      SEXP server = PROTECT(eval(CADR(monitor), env));
      nUNPROTECT++;

      if(!IS_USER_DATABASE(server)) { // FIXME
         PrintValue(server);
         error(_("invalid 'sharedEnv' argument in 'sharedEnv$monitor'"));
      }

      whichObj = CHAR(asChar(CADDR(monitor)));

      if(server == SuprJobEnv)
        return TR_notify(mkString(whichObj), S_all, env);

      whichEnv = CHAR(STRING_ELT(getAttrib(server, install("address")), 0));

    } else {
      error(_("invalid argument 'monitor'"));
    }
  } else
    error(_("invalid argument 'monitor'"));

  //fprintf(stderr, "\033[0;33m%s(%s$%s, ...)\n", __func__,  whichEnv,  whichObj);

  char whichEnv_str[strlen(whichEnv)+1];
  strcpy(whichEnv_str, whichEnv);
  whichEnv = whichEnv_str;
  UNPROTECT(nUNPROTECT);
      
  supr_socket_conn_t *sc = ThreadServer_getMonitorConn(whichEnv, whichObj);
  if(!sc)
    error(_("must be synchronized on %s$%s"), whichEnv, whichObj);
  /*
  if(strcmp(whichEnv, "LocalEnv")==0){
  } else if(strcmp(whichEnv, "ClusterEnv")==0){
        error(_("ClusterEnv: TODO"));
  } else {
        error(_("invalid argument 'monitor'"));
  }
  */
  //int rc = supr3_lock(whichEnv,  whichObj);



/*
  int port = localEnvPort;
  const char *host = localEnvHost;
  if((*whichEnv == 'C' || *whichEnv == 'c') && clusterEnvHost){
    port = clusterEnvPort;
    host = clusterEnvHost;
  }

  if(!host)
    error(_("%s is not available"), whichEnv);

  supr_socket_conn_t *sc = socketOpen2(host, port);
  */

  int cmd = THREAD_PROC_NOTIFY;

  //fprintf(stderr, "\033[0;33m%s::cmd: %d\n", __func__,  cmd);

  write(sc->fd, &cmd, sizeof(int)); 
  int len = strlen(whichObj)+1;
  write(sc->fd, &len, sizeof(int)); 
  write(sc->fd, whichObj, len); 
  write(sc->fd, INTEGER(S_all), sizeof(int)); 

  int rc;
  read(sc->fd, &rc, sizeof(int));

  if(save != R_PPStackTop)
       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
	     __FILE__, __LINE__, __func__, save, R_PPStackTop);

  
  return ScalarInteger(rc);
}

#else
SEXP Sync_notify(SEXP x, SEXP r_all, SEXP env)
{ //  fprintf(stderr, "Supr_threadType: %d\n", Supr_threadType);
  if(TYPEOF(x) == LANGSXP){

    const char *x_str = CHAR(asChar(CADR(x)));
    //fprintf(stderr, "[%s] x_str: %s\n", __func__, x_str);
    if(strcmp(x_str, ".JobEnv")){
      const char *m_str = CHAR(asChar(CADDR(x)));
      //fprintf(stderr, "[%s] m_str: %s\n", __func__, m_str);
      SEXP mutex = PROTECT(mkString(m_str));
      SEXP val = TR_notify(mutex, r_all, env);
      UNPROTECT(1);
      return val;
    }

    if(Supr_threadType == 1) { //  local process ...
      return Supr_localProcSyncNotify(x, r_all);
    } else if(Supr_threadType == 2) { //  remote  process ...
      return Supr_remoteProcSyncNotify(x, r_all);
    } 
  }
  
  x = PROTECT(eval(x, env));
  supr_monitor_t *m;

#ifdef  TEST_GET_MONITOR
  //if(x == R_NilValue) m = Supr_findMonitor(); else // fixme for processes
  // or handle it in the R level...
    m = Supr_getMonitor(x, FALSE);
#else
  SEXP monitor = getAttrib(x, install("monitor"));
  if(TYPEOF(monitor) != EXTPTRSXP)
    error(_("not a monitor object"));
  m = (supr_monitor_t *) R_ExternalPtrAddr(monitor);
  if(m->class != Monitor_class)
    error(_("not a monitor object"));
#endif

  UNPROTECT(1);

  int do_unlock = FALSE;

  supr_thread_t *cth = currentThread();
  if(m->tid != cth->tid){
    if(m->mutex.__data.__owner == cth->tid)
      warning(_("FIXME, not the owner of the monitor (%s:%d)"),
			    __FILE__, __LINE__);
    else {

      int rc;
      BEGIN_R_FREE();
        rc = pthread_mutex_lock(&m->mutex);
      END_R_FREE();

      if(rc != 0){
	      error(_("failed to lock the monitor"));
      } else {
	      m->tid = cth->tid;
	      do_unlock = TRUE;
      }
    }
  }

  int all = asLogical(r_all);
  //printf("[%s] all: %d\n", __func__, all);

  int rc;
  if(all)
    rc = pthread_cond_broadcast(&m->cond);
  else 
    rc = pthread_cond_signal(&m->cond);

  if(do_unlock) {
	m->tid = 0;
	int rc = pthread_mutex_unlock(&m->mutex);
	// ...
  }
  return ScalarInteger(rc);
}
#endif

#include <execinfo.h>

SEXP Thread_expr(SEXP thread)
{
  int rc;
  SEXP expr;

  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  if(!th){
    errorcall(R_NilValue, "not a thread object");
  }

  rc = pthread_mutex_trylock(&th->mutex);
    SEXP envir = R_ExternalPtrProtected(thread);
    expr = findVar(install(".expr"), envir);
  if(rc == 0) pthread_mutex_unlock(&th->mutex);

  return expr;
}

SEXP Thread_envir(SEXP thread)
{
  int rc;
  SEXP envir;

  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  if(!th){
    errorcall(R_NilValue, "not a thread object");
  }

  rc = pthread_mutex_trylock(&th->mutex);
    envir = R_ExternalPtrProtected(thread);
  if(rc == 0) pthread_mutex_unlock(&th->mutex);

  // check the thread state and show warnings if necessary...
  return envir;
}

SEXP Thread_type(SEXP thread)
{
  int rc;
  SEXP type;

  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  if(!th){
    errorcall(R_NilValue, "not a thread object");
  }

  rc = pthread_mutex_trylock(&th->mutex);
    SEXP envir = R_ExternalPtrProtected(thread);
    type = findVar(install(".type"), envir);
  if(rc == 0) pthread_mutex_unlock(&th->mutex);

  return type;
}

SEXP Thread_name(SEXP thread)
{
  int rc;
  char *name;

  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  if(!th){
    errorcall(R_NilValue, "not a thread object");
  }
  //if(m->class != Monitor_class)
  // th = __getSuprThread(thread);

  // FIXME
  rc = pthread_mutex_trylock(&th->mutex);
    name = th->name;
  if(rc == 0) pthread_mutex_unlock(&th->mutex);

  return mkString(name);
}

SEXP Thread_state(SEXP thread)
{
  int rc, state;

  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  if(!th){
    errorcall(R_NilValue, "not a thread object");
  }
  //if(m->class != Monitor_class)
  // th = __getSuprThread(thread);

  // FIXME
  rc = pthread_mutex_trylock(&th->mutex);
    state = th->state;
  if(rc == 0) pthread_mutex_unlock(&th->mutex);

  return ScalarInteger(state);
}

void Thread_handleInterrupt();

static void  sleep_int_handler(int sig)
{
   pthread_setspecific(interruptThreadKey, PTHREAD_INTERRUPTED);

   // FIXME
   supr_thread_t *cth = currentThread();
   pthread_mutex_trylock(&cth->mutex);
     pthread_cond_signal(&cth->cond);
   pthread_mutex_unlock(&cth->mutex);
}

 


SEXP Thread_sleep(SEXP timeout)
{

  supr_thread_t *cth = currentThread();
  struct timespec rqtp;
  //clock_gettime(CLOCK_REALTIME, &rqtp);
  //rqtp.tv_sec += (long) asReal(timeout);

  double s =  asReal(timeout);
  if(s <= 0)
    return R_NilValue;

  rqtp.tv_sec = (long) floor(s);
  rqtp.tv_nsec = (long) (1000000000*(s - floor(s)));

  struct timespec rmtp;

  cth->data = NULL;
  pthread_setspecific(interruptThreadKey, NULL);
  pthread_setspecific(sigusr2HandlerKey, sleep_int_handler);

  int rc;

  BEGIN_R_FREE();

    rc = nanosleep(&rqtp, &rmtp);

  END_R_FREE();

  void *retval = pthread_getspecific(interruptThreadKey);
  if(Supr_verbose && retval == PTHREAD_INTERRUPTED) {
      printf("PTHREAD_INTERRUPTED\n");
  }

  pthread_setspecific(interruptThreadKey, NULL);
  pthread_setspecific(sigusr2HandlerKey, NULL);

  // FIXME: interrupt (via SIGUSR2) --> termination (error)
  if(rc == -1) {
    return mkString(strerror(errno)); // FIXME
    //warning(_("%s"), strerror(errno));
    //s = rmtp.tv_sec + rmtp.tv_nsec/1000000000.0;
    //error(_("INTERRUPTED"));
  } else {
    s = 0;
  }
  return ScalarReal(s);
}


#ifdef SUPR3

SEXP Thread_interrupt(SEXP thread)
{
  SEXP server = getAttrib(thread, install("server"));
  int rc;
  if(TYPEOF(server) != NILSXP){
    supr_socket_conn_t *sc = Sync_connect(server);
    int cmd = THREAD_PROC_INTERRUPT;
    R_unlock();
    write(sc->fd, &cmd, sizeof(int));
    write(sc->fd, INTEGER(thread), sizeof(int));
    read(sc->fd, &rc, sizeof(int));
    R_lock();
  } else {
    pid_t pid = INTEGER(thread)[0];
    //int rc = kill(pid, SIGINT);
    rc = kill(pid, SIGKILL);
  }
  return ScalarInteger(rc);
}

SEXP ThreadProc_state(SEXP thread)
{
  int save = R_PPStackTop;

  pid_t pid = INTEGER(thread)[0];

  SEXP server = getAttrib(thread, install("server"));

  int rc;
  if(TYPEOF(server) != NILSXP){
    supr_socket_conn_t *sc = Sync_connect(server);
    int cmd = THREAD_PROC_STATE;
    R_unlock();
    write(sc->fd, &cmd, sizeof(int));
    write(sc->fd, &pid, sizeof(int));

    read(sc->fd, &rc, sizeof(int));
    R_lock();
    close(sc->fd);
    free(sc); // FIXME
  } else {
    rc = kill(pid, SIGINT);
  }
  
  if(save != R_PPStackTop)
       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
	     __FILE__, __LINE__, __func__, save, R_PPStackTop);

  return ScalarInteger(rc);
}

#else

SEXP Thread_interrupt(SEXP thread)
{
  printf("%d %d [%s] R_wait_usec: %d\n",currentThread()->pid,
		  currentThread()->tid, __func__, R_wait_usec); 

  if(TYPEOF(thread) == NILSXP){// interrupt all
    supr_thread_t *cth = currentThread();

    double timeout = R_wait_usec + 30; //DEFAULT_TASKRUNNER_TIMEOUT;
    struct timespec wait;

    pthread_mutex_lock(threads->mutex);
      for(int i=0; i<vectorSize(threads); i++){
        supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
	if(th == cth)
       	  continue;
        pthread_mutex_lock(&th->mutex);
	  th->data = PTHREAD_ERROR;
	  {
		  SuprSignal_set(SIGUSR2);
	  }
          int rc = pthread_kill(th->ptid, SIGUSR2);

	  if(rc){
            supr_warning("interrupt %s, %s\n", th->name, strerror(rc));
	  } else {

            printf("%d %d [%s] pthread_kill(%s): %d\n",currentThread()->pid,
			  currentThread()->tid, __func__, th->name, rc); 

            clock_gettime(CLOCK_REALTIME, &wait);
            wait.tv_sec += (long) timeout;

            rc = pthread_cond_timedwait(&th->cond, &th->mutex, &wait);
	    if(rc == ETIMEDOUT)
	    {
              supr_warning("%s is not responsive. Try SIGINT\n", th->name);
	      if(strcmp(th->name, "Thread.main")==0){ // testing
                rc = pthread_kill(th->ptid, SIGINT);
	      }
	    }
	  }
	  
        pthread_mutex_unlock(&th->mutex);
      }
    pthread_mutex_unlock(threads->mutex);

  printf("%d %d [%s]\n",currentThread()->pid, currentThread()->tid, __func__); 
    Thread_handleInterrupt();
  printf("%d %d [%s]\n",currentThread()->pid, currentThread()->tid, __func__); 
    return R_NilValue; 
  }
  int rc = 0;
  // BEGIN_R_FREE
  //__save_R_PPStack();
  BEGIN_R_FREE();

  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  //if(m->class != Monitor_class)
  if(!th){
    errorcall(R_NilValue, "not a thread object");
  }

  pthread_mutex_lock(&th->mutex);
    th->data = NULL;
    {
		  SuprSignal_set(SIGUSR2);
    }
    rc = pthread_kill(th->ptid, SIGUSR2);
    pthread_cond_wait(&th->cond, &th->mutex); // -> timed wait
  pthread_mutex_unlock(&th->mutex);

  // END_R_FREE
  END_R_FREE();

  return ScalarInteger(rc);
}

#endif

void  Thread_getStackTrace(void *data)
{
  //c_backtrace();
#define THREAD_BACKTRACE_SIZE 20
  void  *array[THREAD_BACKTRACE_SIZE];
  int   size, i;
  char  **strings;

  size = backtrace(array, THREAD_BACKTRACE_SIZE); // return_addrs
  strings = backtrace_symbols(array, size);

  vector_t *v = newVector(FALSE);
  for(int i=2; i<size; i++){
    vectorAdd(v, strdup(strings[i]));
  }
  free(strings);
  ((supr_thread_t*)data)->data = v;

#undef THREAD_BACKTRACE_SIZE 
}

extern int R_interrupts_pending;

void Thread_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>> %s  -p %d -t %ld <<<<<<<<<<<<<\033[0m\n\n",
                  __func__, getpid(), syscall(SYS_gettid));
  if( R_interrupts_pending) exit(1);

//  printf("\033[0;31mPTHREAD_INTERRUPTED: %p\033[0m\n", PTHREAD_INTERRUPTED);
  sleep(240);
  exit(1);
}

SEXP Thread_stackTrace(SEXP thread)
{
  // BEGIN_R_FREE
  //__save_R_PPStack();

  supr_thread_t *th = (supr_thread_t *) R_ExternalPtrAddr(thread);
  //if(m->class != Monitor_class)
  if(!th){
    errorcall(R_NilValue, "not a thread object");
  }

  BEGIN_R_FREE();

  //// DEBUG
  {
    struct sigaction sa;
    sa.sa_sigaction = Thread_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }
  ////

  run_t *run = (run_t*) malloc(sizeof(run_t));
  run->run = Thread_getStackTrace;
  run->data=th;

  vector_t *stack_elems = NULL;

    pthread_mutex_lock(&th->mutex);
    th->data = run;

    {
      currentThread()->data = run;
    }
    {
	    SuprSignal_set(SIGUSR2);
    }
    int rc = pthread_kill(th->ptid, SIGUSR2);
    printf("[%s] rc: %d\n", __func__, rc); 
    if(rc){
      printf("[%s] rc: %d, %s\n", __func__, rc, strerror(rc)); 
      pthread_mutex_unlock(&th->mutex);
      errorcall(R_NilValue, "%s", strerror(rc)); 
    }

    pthread_cond_wait(&th->cond, &th->mutex); // timedwait ...
    stack_elems = (vector_t *) th->data;
    th->data = NULL;
  pthread_mutex_unlock(&th->mutex);

  if(stack_elems){
   for(int i=0; i<vectorSize(stack_elems); i++){
    char *str = (char*)vectorElementAt(stack_elems, i);
    if(strstr(str, "libsupr.so")){
      printf("[%d] %2d : ", th->tid, i+1);
      char *s = strtok(str, "(");
      printf("\033[0;33mfrom %s", s);
      s = strtok(NULL, "+");
      printf("\033[0;32m %s\033[0m\n", s);
    } else 
      printf("[%d] %2d : %s\n", th->tid, i+1, str);
   }
  }

  // END_R_FREE
  END_R_FREE();

  return R_NilValue;
}












/*
static void mutex_finalizer(SEXP s)
{
  printf("[%s] is called\n", __func__);
  pthread_mutex_t *mutex = (pthread_mutex_t *) R_ExternalPtrAddr(s);
  pthread_mutex_destroy(mutex);
  free(mutex);
}

static void cond_finalizer(SEXP s)
{
  printf("[%s] is called\n", __func__);
  pthread_cond_t *cond = (pthread_cond_t *) R_ExternalPtrAddr(s);
  pthread_cond_destroy(cond);
  free(cond);
}


SEXP Thread_mutex(){

  pthread_mutex_t *mutex = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(mutex, NULL);
  SEXP val = PROTECT(R_MakeExternalPtr(mutex, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(val, mutex_finalizer, TRUE);
  setAttrib(val, R_ClassSymbol, mkString("mutex"));
  UNPROTECT(1);
  return val;

}

SEXP Thread_cond(){

  pthread_cond_t *cond = (pthread_cond_t *) malloc(sizeof(pthread_cond_t));
  pthread_cond_init(cond, NULL);
  SEXP val = PROTECT(R_MakeExternalPtr(cond, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(val, cond_finalizer, TRUE);
  setAttrib(val, R_ClassSymbol, mkString("cond"));
  UNPROTECT(1);
  return val;

}

SEXP Thread_lock(SEXP r_mutex){

  int rc;
  BEGIN_R_FREE();
    pthread_mutex_t *mutex = R_ExternalPtrAddr(r_mutex);
    rc = pthread_mutex_lock(mutex);
  END_R_FREE();

  if(rc == -1) errorcall(R_NilValue, "%s", strerror(errno));
  return ScalarInteger(rc);
}

SEXP Thread_trylock(SEXP r_mutex){
  int rc;
  BEGIN_R_FREE();
    pthread_mutex_t *mutex = R_ExternalPtrAddr(r_mutex);
    rc = pthread_mutex_trylock(mutex);
  END_R_FREE();

  if(rc == -1) errorcall(R_NilValue, "%s", strerror(errno));
  return ScalarInteger(rc);
}

SEXP Thread_unlock(SEXP r_mutex){
  int rc;
  BEGIN_R_FREE();
    pthread_mutex_t *mutex = R_ExternalPtrAddr(r_mutex);
    rc = pthread_mutex_unlock(mutex);
  END_R_FREE();
  if(rc == -1) errorcall(R_NilValue, "%s", strerror(errno));
  return ScalarInteger(rc);
}

SEXP Thread_ownerOf(SEXP r_mutex){
  char buf[128];
  int rc = 0;
  BEGIN_R_FREE();
    pthread_mutex_t *mutex = R_ExternalPtrAddr(r_mutex);
    if(mutex->__data.__owner == 0)
	    rc = -1;
    else
      sprintf(buf, "Thread.%d", mutex->__data.__owner);
  END_R_FREE();
  if(rc == -1)
    return R_NilValue;
  else 
    return mkString(buf);
}

SEXP Thread_wait(SEXP r_cond, SEXP r_mutex){
  int rc;
  BEGIN_R_FREE();
    pthread_cond_t  *cond  = R_ExternalPtrAddr(r_cond);
    pthread_mutex_t *mutex = R_ExternalPtrAddr(r_mutex);
    rc = pthread_cond_wait(cond, mutex);
  END_R_FREE();
  if(rc == -1) errorcall(R_NilValue, "%s", strerror(errno));
  return ScalarInteger(rc);
}

SEXP Thread_timedwait(SEXP r_cond, SEXP r_mutex, SEXP r_timeout){
  int rc;
  BEGIN_R_FREE();
    pthread_cond_t  *cond  = R_ExternalPtrAddr(r_cond);
    pthread_mutex_t *mutex = R_ExternalPtrAddr(r_mutex);
    double timeout = asReal(r_timeout);
    if(timeout <= 0 ){
      rc = pthread_cond_wait(cond, mutex);
    } else {
      struct timespec wait;
      clock_gettime(CLOCK_REALTIME, &wait);
      timeout += wait.tv_sec + wait.tv_nsec/1000000000.0;
      wait.tv_sec = (long) floor(timeout);
      wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

      rc = pthread_cond_timedwait(cond, mutex, &wait);
    }
  END_R_FREE();
  if(rc == -1) errorcall(R_NilValue, "%s", strerror(errno));
  return ScalarInteger(rc);
}

SEXP Thread_signal(SEXP r_cond){
  int rc;
  BEGIN_R_FREE();
    pthread_cond_t  *cond  = R_ExternalPtrAddr(r_cond);
    rc = pthread_cond_signal(cond);
  END_R_FREE();
  if(rc == -1) errorcall(R_NilValue, "%s", strerror(errno));
  return ScalarInteger(rc);
}

SEXP Thread_broadcast(SEXP r_cond){
  int rc;
  BEGIN_R_FREE();
    pthread_cond_t  *cond  = R_ExternalPtrAddr(r_cond);
    int rc = pthread_cond_broadcast(cond);
  END_R_FREE();
  if(rc == -1) errorcall(R_NilValue, "%s", strerror(errno));
  return ScalarInteger(rc);
}
*/


void R_ThreadCleanUp(void *data)
{
}


/*
 * Error: -> interrupt main_thread -> jump to Thread_main_run
 * Cancel:-> collect backtrace     -> stop
 *
 */
// does it work??

void Thread_run(SEXP env, SEXP expr)
{
  supr_thread_t *cth = currentThread();

  //printf("\n\nIs Called:\n");

//  printf("%d %d [%s] Call R_MY_simpleTryEval\n", cth->pid, cth->tid, __func__);
  int errorOccurred = FALSE;
  SEXP error_handler = NULL;

  //int cleanup_execute = FALSE;
  //pthread_cleanup_push(R_ThreadCleanUp, env);

  BEGIN_R_EVAL();
      int savestack = R_PPStackTop;

//      Supr_copyGlobals();

      if(!expr)
	      expr = findVar(install(".expr"), env);
      //SEXP result=PROTECT(R_simpleTryEval(expr, env, &errorOccurred));
      SEXP val = R_NilValue;
      RCNTXT cntxt;

      cth->R_ToplevelContext = &cntxt;


      SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env,
					      R_NilValue))));
      defineVar(install(".syscall"), syscall, env);
      UNPROTECT(1);

      int ctxt_ret_code = CTXT_RETURN;
      ctxt_ret_code = CTXT_TOPLEVEL;

      begincontext(&cntxt, ctxt_ret_code, syscall, env, env,
		      R_NilValue, R_NilValue);


	// Note: &cntxt playes the role of R_ToplevelContext
	// See: restore_globals @ R:/src/main/context.c
      /* do not work....
        {
           RCNTXT *cptr = __R_ToplevelContext;
	   cptr->cstacktop = cntxt.cstacktop;
	   cptr->gcenabled = cntxt.gcenabled;
	   cptr->bcintactive = cntxt.bcintactive;
	   cptr->bcpc = cntxt.bcpc;
	   cptr->bcbody = cntxt.bcbody;
	   cptr->evaldepth = cntxt.evaldepth;
	   cptr->vmax = cntxt.vmax;
	   cptr->intsusp = cntxt.intsusp;
	   cptr->handlerstack = cntxt.handlerstack;
	   cptr->restartstack = cntxt.restartstack;
	   cptr->prstack = cntxt.prstack;
	   cptr->nodestack = cntxt.nodestack;
	   cptr->srcref = cntxt.srcref;
	}
	*/

        if(!setjmp(__R_ToplevelContext->cjmpbuf)) {

          memcpy(cth->cjmpbuf, __R_ToplevelContext->cjmpbuf, sizeof(jmp_buf));
          val = eval(expr, env);

        } else {

          errorOccurred = TRUE;
          const char *errbuf = R_curErrorBuf();
          val = mkString(errbuf);

	}

      endcontext(&cntxt);

      memcpy(__R_ToplevelContext->cjmpbuf, R_ToplevelContext_cjmpbuf,
		      sizeof(jmp_buf));

      if(errorOccurred){



        defineVar(install(".Error"), val, env);
        defineVar(install(".Traceback"), SYMVALUE(install(".Traceback")), env);

	SEXP warnings = SYMVALUE(install("last.warning"));
        //printf("\033[0;34m[%s] R_BaseEnv$last.warning (%s):\033[0m\n", cth->name, type2char(TYPEOF(warnings)));
        if(warnings != R_UnboundValue)
          defineVar(install(".Warnings"), warnings, env);


        if(cth->data != PTHREAD_CANCELED) {
          ThreadError_print(R_curErrorBuf());

          //SEXP
	  error_handler = findVar(install(".error.handler"), env);
          if(error_handler != R_UnboundValue){

	    SEXP call = PROTECT(LCONS(error_handler, CONS(val, R_NilValue)));
            defineVar(install(".Error.handler"), call, env);
	    UNPROTECT(1);

	    // prevent error.handler from being called again
	    defineVar(install(".error.handler"), R_UnboundValue, env);
	    error_handler = call;
          } else {
	    error_handler = NULL;
	  }
	}
	//if(SYMVALUE(install(".Traceback")) != R_UnboundValue) PrintValue(SYMVALUE(install(".Traceback")));

        char buf[256];
	if(Supr_verbose){
          printf("ErrorOccurred, R_GlobalContext: %s\n",
		      ptrToString(R_GlobalContext, buf, 256));
	}

	/*
        printf("%d %d [%s] cth->data: %s\n", cth->pid, cth->tid,
		      __func__, ptrToString(cth->data, buf, 256));

        printf("%d %d [%s] R_PPStackTop: %d -> %d\n", cth->pid, cth->tid,
		      __func__, savestack, R_PPStackTop);
		      */

	// The following treatment seems to work fine, because no GC
	// after calling R_restore_globals @ R:/src/main/context.c

	if(currentThread()->save_R_BCNodeStackTop != R_BCNodeStackTop) {
          fprintf(stderr, "save_R_BCNodeStackTop != R_BCNodeStackTop"); 
          fprintf(stderr, " (%s:%d)\n", __FILE__, __LINE__);
          Supr_checkRBCNodeStack();

	  R_BCNodeStackTop = currentThread()->save_R_BCNodeStackTop;
	}


      } else {
        //defineVar(install(".Result"), val, env);
        defineVar(install(".value"), val, env);
      }

      defineVar(install(".save.stack."), R_NilValue, env);


      //printf("[%s] R_PPStackTop: %d -> %d\n", __func__, savestack,R_PPStackTop);

  END_R_EVAL();

  if(cth->data == PTHREAD_CANCELED) {
    if(Supr_verbose){
      printf("%d %d [%s] RETURN (cancelled)\n\n", cth->pid, cth->tid, __func__);
    }
    pthread_cancel(cth->ptid);
  }

  //pthread_cleanup_pop(cleanup_execute);

      //printf("RETURN\n");
  if(errorOccurred) {
    if(Supr_verbose){
      printf("RETURN(errorOccurred)\n");
    }

    if(error_handler) {
      if(Supr_verbose){
        printf("RETURN(call error_handler)\n");
      }
      Thread_run(env, error_handler);
    } else  {
      if(Supr_verbose){
        printf("RETURN(call interrupt)\n");
      }
      Thread_interrupt(R_NilValue); // all = TRUE
    }
  }

  /*
  printf("%d %d [%s] RETURN (success) cth->Context: %p\n\n", cth->pid, cth->tid,
		  __func__, cth->R_GlobalContext);
  printf("%d %d [%s] RETURN (success) R_GlobalContext: %p\n", cth->pid,
		  cth->tid, __func__, R_GlobalContext);
		  */
//  sleep(6000);
}

SEXP Thread_current()
{
  supr_thread_t *cth = currentThread();
  return cth->R_thread;
}

// TODO
// main_thread: handle error
// other threads: stop?
void Thread_handleInterrupt()
{
  supr_thread_t *cth = currentThread();
  int rc;

  if(cth == main_thread){

    int run_R = TRUE;
    for(int i=0; i<vectorSize(threads); i++) {// R_threads, threads sunning R??
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
      printf("\033[0;31m%d %d [%s] name: %s, state: %d\033[0m\n",
            cth->pid, cth->tid, __func__, th->name, th->state);
      if(th->state != THREAD_STATE_TERMINATED){
	      sleep(1); // to do ...
      }
    }

    cth->data = PTHREAD_ERROR; // FIXME
    rc = pthread_kill(cth->ptid, SIGINT);
    // not return
    printf("\033[0;31m%d %d [%s] pthread_kill: %d\033[0m\n",
            cth->pid, cth->tid, __func__, rc);
  } else {
    rc = pthread_cancel(cth->ptid);
    // not return
    printf("\033[0;31m%d %d [%s] pthread_cancel: %d\033[0m\n",
            cth->pid, cth->tid, __func__, rc);
  }
}


void Thread_SigactionSIGUSR2(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;35m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n",
                  __func__);

  /*
  {// is it raised by external code?
    if(!Supr_verbose)
      fprintf(stderr,"\n\033[0;35m>>>>>>  %s    <<<<<<\033[0m\n", __func__);

    //int _supr_signal = SuprSignal_set(0);
    int _supr_signal = SuprSignal_get();

    if(_supr_signal != sig){
      fprintf(stderr,"\n\033[0;35m[%s] _supr_signal: %d\033[0m\n", __func__,
		      _supr_signal);
      exit(1); // FIXME
      return;
    } 
  }
  */

  supr_thread_t *cth = currentThread();

  void *msg = NULL;

  int rc = pthread_mutex_lock(&cth->mutex); // used timedwait?
  printf("\033[0;35m%d %d [%s] pthread_mutex_trylock: %d, owner: %d\033[0m\n",
	    cth->pid, cth->tid, __func__, rc, cth->mutex.__data.__owner);
  
    

    if(cth->data == PTHREAD_ERROR){
      printf("\033[0;31mPTHREAD_ERROR: %p\033[0m\n", PTHREAD_ERROR);
      msg = cth->data;
    } else if(cth->runnable){ // TODO
      cth->runnable->run(cth->runnable->data);
    } else if(cth->data){ // TODO
      run_t *runnable = (run_t *) cth->data;
      runnable->run(runnable->data);
    } else {
      printf("\033[0;31mPTHREAD_INTERRUPTED: %p, TODO ...\033[0m\n",
		      PTHREAD_INTERRUPTED);
      pthread_setspecific(interruptThreadKey, PTHREAD_INTERRUPTED);

      //Thread_handleInterrupt();
    }
    pthread_cond_signal(&cth->cond);

  pthread_mutex_unlock(&cth->mutex);

  if(msg == PTHREAD_ERROR){
    if(cth == main_thread){
      cth->data = msg;
      printf("\033[0;33m[%s] main_thread PTHREAD_ERROR: %p\033[0m\n",
		      __func__, PTHREAD_ERROR);
      fprintf(stderr, "\033[0;33m[%s] main_thread PTHREAD_ERROR: %p\033[0m\n",
		      __func__, PTHREAD_ERROR);

      // lock __thread_mutex???
      //if(__thread_mutex.__data.__owner != cth->tid)
      R_GlobalContext = cth->R_GlobalContext;
      R_CStackStart   = cth->R_CStackStart;
     

      if(FALSE){
        fprintf(stderr, "\033[0;33m[%s] FIXME (%s:%d)\033[0m\n", __func__,
			__FILE__, __LINE__);
      } else {
        char *backtrace = myR_simpleTraceback();
        printf("%d : [%s] \t\ttrace:\n%s\n\n\t\t\t\t(%s:%d)\n\n", cth->tid,
		      __func__, backtrace, __FILE__, __LINE__);
        free(backtrace);
      }

      // make errorcall_dflt jump to restart (Thread_main_run_Rmainloop)
      { 
        //memcpy(__R_ToplevelContext->cjmpbuf, __cjmpbuf, sizeof(jmp_buf));
        memcpy(__R_ToplevelContext->cjmpbuf, R_ToplevelContext_cjmpbuf,
		       	sizeof(jmp_buf));

        cth->R_GlobalContext = __R_ToplevelContext;
        cth->save_R_PPStackTop = 0;
        __ReplIteration = NULL;

	errorcall(R_NilValue, "\033[0;31mLongjmp from (%s:%d)\033[0m\n\n\n\n\n",
			__FILE__, __LINE__);
      }
      // do longjmp here...
      /*
      {
      printf("%d : [%s] \t\ttrace:\n%s\n\n\t\t\t\t(%s:%d) longjmp...\n\n", cth->tid,
		      __func__, backtrace, __FILE__, __LINE__);
      longjmp(__cjmpbuf, 0);


      int rc = pthread_kill(cth->ptid, SIGINT);
      }
      */
      // no return
    } else {
      printf("\033[0;31mpthread_cancel(%s) ...\033[0m\n", cth->name);
      int rc = pthread_cancel(cth->ptid);
      // no return
      printf("\033[0;31mpthread_cancel(%s): %d\033[0m\n", cth->name, rc);
    }
  }
}


void Thread_setInterruptable() // ???
{
    struct sigaction sa;
    sa.sa_sigaction = Thread_SigactionSIGUSR2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);

    pthread_setspecific(interruptThreadKey, NULL);
}


/*
static RCNTXT * copyRCNTXT(RCNTXT *dest, RCNTXT *src)
{
  //  RCNTXT *cntxt = (RCNTXT *) malloc(sizeof(RCNTXT));
  // use memcpy???

  cntxt->nextcontext = c->nextcontext;

  cntxt->callflag =     c->callflag;
  cntxt->cstacktop =    c->cstacktop;
  cntxt->evaldepth =    c->evaldepth;
  cntxt->promargs =     c->promargs;
  cntxt->callfun =      c->callfun;
  cntxt->sysparent =    c->sysparent;
  cntxt->call =         c->call;
  cntxt->cloenv =       c->cloenv;
  cntxt->conexit =      c->conexit;
  cntxt->cend =         c->cend;
  cntxt->cenddata =     c->cenddata;
  cntxt->vmax =         c->vmax;
  cntxt->intsusp =      c->intsusp;
  cntxt->handlerstack = c->handlerstack;
  cntxt->restartstack = c->restartstack;
  cntxt->prstack      = c->prstack; // don't copy this for threads ...

  cntxt->nodestack =    c->nodestack;
  //IStackval *intstack;
  cntxt->srcref =       c->srcref;
  cntxt->browserfinish= c->browserfinish;

  ////
  cntxt->threaddata   = NULL; // R_NilValue;
  if(cntxt->nextcontext != NULL){
    cntxt->nextcontext->threaddata   = NULL;
  ERROR}
  ////

  return dest;
}
*/

extern char *__r2str(SEXP x, char *buf, int buf_size, int debug);

char *sexp2char(SEXP x)
{
   int buf_size = 128*200;
   char buf[buf_size];
   //char *s = __r2str(x, buf, buf_size, 0);
   char *s = __r2str(x, buf, buf_size, 0);
   char *c = malloc(strlen(s)+1);
   memcpy(c, s, strlen(s)+1);
   return c;
}


char *__myR_simpleTraceback(const char *func, const char *file, int line)
{
  RCNTXT *cntxt = R_GlobalContext;
  int len  = 0;

  //CheckStack();

  cntxt = R_GlobalContext;

  /*
  { // debug
    if(cntxt != save_R_GlobalContext)
      fprintf(stderr, "cntxt != save_R_GlobalContext (%s:%d)\n",
		      __FILE__, __LINE__);
  }
  */

  int num=0;
  while(cntxt){
    SEXP call = cntxt->call;
//    fprintf(stderr, "\033[0;32m%d %d : cntxt = %p: %p\033[0m\n", currentThread()->pid, currentThread()->tid, cntxt, call);
    char *c = sexp2char(call);
    len += strlen(c)+1+1+32;
    //fprintf(stderr, "%d %d : cntxt = %p: %s\n", currentThread()->pid,
//		    currentThread()->tid, cntxt, c);
    //char buf[256];
    //fprintf(stderr, "%d %d : cntxt = %s: %s\n", currentThread()->pid,
//		    currentThread()->tid, ptrToString(cntxt, buf, 256), c);
    fprintf(stderr, "%d. %s\n", ++num, c);
    free(c);
    cntxt = cntxt->nextcontext;
  }


  char *str = malloc(len);
  char *s = str;
  cntxt = R_GlobalContext;
  /*
  { // debug
    if(cntxt != save_R_GlobalContext)
      fprintf(stderr, "cntxt != save_R_GlobalContext (%s:%d)\n",
		      __FILE__, __LINE__);
  }
  */
  int i=0;
  while(cntxt && cntxt->nextcontext){
    SEXP call = cntxt->call;
//    fprintf(stderr, "\033[0;34m%d %d : cntxt = %p: %p\033[0m\n", currentThread()->pid, currentThread()->tid, cntxt, call);
    char *c = sexp2char(call);
    if(i){ *s ='\n'; s++;}

    char b[16];
    sprintf(b, "%d: ", i++);
    memcpy(s, b, strlen(b));
    s += strlen(b);

    memcpy(s, c, strlen(c));
    s += strlen(c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  *s = 0;
  return str;
}

#define PROCESS_SHARED_SYNC
#ifdef PROCESS_SHARED_SYNC

#define SEMAPHORE_BUF_SIZE 4096
/*
struct semaphore { // change the name
	char *file_name;
        pthread_mutex_t lock;
        pthread_cond_t nonzero;
        unsigned int count; // not used
        int cmd;
 	pid_t parent_pid; // not used?
 	pid_t child_pid;
	size_t buf_size;
       	size_t data_size;
       	unsigned char buf[0]; 
};
typedef struct semaphore semaphore_t;
typedef struct semaphore sem_io_t;
*/

/*
semaphore_t *semaphore_create(char *semaphore_name);
semaphore_t *semaphore_open(char *semaphore_name);
//void semaphore_post(semaphore_t *semap);
//void semaphore_wait(semaphore_t *semap);
void semaphore_close(semaphore_t *semap);
*/


semaphore_t *
//semaphore_create(char *semaphore_name)
mmap_io_create(char *semaphore_name)
{ 
           int fd;
               semaphore_t *semap;
               pthread_mutexattr_t psharedm;
               pthread_condattr_t psharedc;

	       if(*semaphore_name == '/')
                 fd = open(semaphore_name, O_RDWR | O_CREAT | O_EXCL, 0666);
	       else
                 fd = shm_open(semaphore_name,
				 O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
               if (fd < 0)
                   return (NULL);
               //(void) ftruncate(fd, sizeof(semaphore_t));
               (void) ftruncate(fd, sizeof(semaphore_t) + SEMAPHORE_BUF_SIZE);
               (void) pthread_mutexattr_init(&psharedm);
               (void) pthread_mutexattr_setpshared(&psharedm,
                   PTHREAD_PROCESS_SHARED);
               (void) pthread_condattr_init(&psharedc);
               (void) pthread_condattr_setpshared(&psharedc,
                   PTHREAD_PROCESS_SHARED);
               semap = (semaphore_t *) mmap(NULL, sizeof(semaphore_t)
			       + SEMAPHORE_BUF_SIZE,
                       PROT_READ | PROT_WRITE, MAP_SHARED,
                       fd, 0);
	       semap->buf_size = SEMAPHORE_BUF_SIZE;
	       semap->data_size = 0;

	       semap->file_name = strdup(semaphore_name);
	       //printf("semap->file_name: %p\n", semap->file_name);
	       //printf("semap->file_name: %s\n", semap->file_name);

               close (fd);
               (void) pthread_mutex_init(&semap->lock, &psharedm);
               (void) pthread_cond_init(&semap->cond, &psharedc);
               semap->count = 0;
               return (semap);
	       // destroy...
}

//semaphore_t * semaphore_open(char *semaphore_name)
mmap_io_t * mmap_io_open(char *semaphore_name)
{
               int fd;
               semaphore_t *semap;

               //fd = open(semaphore_name, O_RDWR, 0666);
	       if(*semaphore_name == '/')
                 fd = open(semaphore_name, O_RDWR, 0666);
	       else
                 fd = shm_open(semaphore_name, O_RDWR, 0600);
	       size_t size;
               if (fd < 0)
                   return (NULL);

	       {
	         struct stat sb;
		 int rc = fstat(fd, &sb);
                 if (rc < 0) return (NULL);
		 size = sb.st_size;
		 //printf("size: %ld, sizeof(mmap_io_t)+SEMAPHORE_BUF_SIZE: %d\n", size, sizeof(mmap_io_t)+SEMAPHORE_BUF_SIZE);
	       }
               semap = (semaphore_t *) mmap(NULL, size,// sizeof(semaphore_t),
                       PROT_READ | PROT_WRITE, MAP_SHARED,
                       fd, 0);

	       semap->buf_size = SEMAPHORE_BUF_SIZE;
	       semap->data_size = 0;
	       //semap->file_name = strdup(semaphore_name);

               close (fd);
               return (semap);
}

/*
          void
           semaphore_post(semaphore_t *semap)
           {
               pthread_mutex_lock(&semap->lock);
               if (semap->count == 0)
                   pthread_cond_signal(&semap->nonzero);
               semap->count++;
               pthread_mutex_unlock(&semap->lock);
           }

           void
           semaphore_wait(semaphore_t *semap)
           {
               pthread_mutex_lock(&semap->lock);
               while (semap->count == 0)
                   pthread_cond_wait(&semap->nonzero, &semap->lock);
               semap->count--;
               pthread_mutex_unlock(&semap->lock);
           }
*/

//void semaphore_close(semaphore_t *semap)
void mmap_io_close(semaphore_t *semap)
{
               //munmap((void *) semap, sizeof(semaphore_t));
               munmap((void *) semap, sizeof(semaphore_t) + semap->buf_size);
}

void mmap_io_destroy(semaphore_t *semap)
{
  if(!semap) return;

  char file_name[PATH_MAX];
  if(semap->file_name){
    memcpy(file_name, semap->file_name, strlen(semap->file_name)+1);
    semap->file_name = NULL;
  } else {
    file_name[0] = 0;
  }

  mmap_io_close(semap);
 
  if(file_name[0]){

    if(*file_name == '/')
      unlink(file_name);
    else
      shm_unlink(file_name);
  }
}


#endif


void Thread_run_taskrunner(void *data)
{
  void **args = (void**) data;
  SEXP env  = (SEXP) args[0];
  SEXP expr = (SEXP) args[1];
  if(! expr || expr == R_UnboundValue)
	  error("cannot find 'expr'");

  /*
  { // delete me
    printf("\033[0;32m%d %d running as a taskrunner...\033[0m\n",
			  getpid(), syscall(SYS_gettid));
    PrintValue(mkString("Process is running"));
    PrintValue(env);
    printf("\033[0;32m%d %d running as a taskrunner...\033[0m\n",
			  getpid(), syscall(SYS_gettid));
  }
  */

  SEXP result = eval(expr, env);
  //defineVar(install(".Result"), result, env);
  defineVar(install(".value"), result, env);

  /*
  { // delete me
    for(int i=0; i<2; i++){
          printf("\033[0;32m%d %d running as a taskrunner...\033[0m\n",
			  getpid(), syscall(SYS_gettid));
          sleep(1);
    }
  }
  */
}

typedef struct thread_proc_io thread_proc_io_t;
struct thread_proc_io {
 semaphore_t *semap; // change the name "semaphore" ...
};

static thread_proc_io_t __thread_proc_io = {NULL};

void *sem_io_copy(sem_io_t *dest, const void *src, size_t n)
{
  static int idx = 0; // FXIME?

  dest->data_size = n;

  if(n < dest->buf_size) {
    memcpy(dest->buf, src, n);
    return dest->buf;
  } else {
    // assumming the buf_size is large enough to hold the following shm_name
    sprintf(dest->buf, "supr-shm.%d.%d.%d", geteuid(), getpid(), idx++);
    void *mem_ptr = rjni_shm_create(dest->buf, n);
    memcpy(mem_ptr, src, n);
    munmap(mem_ptr, n);
    return mem_ptr;
  }
}

SEXP sem_io_RObjectOf(sem_io_t *sem_io)
{
  SEXP val;
  if(sem_io->data_size <= sem_io->buf_size)
    BEGIN_R_EVAL();
      val = SO_toRObject((so_t*)sem_io->buf, sem_io->data_size);
    END_R_EVAL();
  else {
    size_t size;
    void *mem_ptr = rjni_shm_open((char*) sem_io->buf, &size);
    BEGIN_R_EVAL();
      val = SO_toRObject((so_t*) mem_ptr, size);
    END_R_EVAL();
    munmap(mem_ptr, size);
    shm_unlink((char*) sem_io->buf);
  }
  return val;
}

SEXP SuprShared_print(SEXP x, SEXP extra_args, SEXP env){
  fprintf(stderr, "addr: %p, type: %s\n", x, type2char(TYPEOF(x)));
  fprintf(stderr, "addr: %p, location: %s\n", x, CHAR(asChar(x)));
  if(strcmp(CHAR(asChar(x)), ".SharedEnv")==0){
     SEXP val = findVar(install(".SharedEnv"), R_GlobalEnv);
     return val;
  } /* else if(strcmp(CHAR(asChar(x)), ".ClusterEnv")==0){
    if(!__supr_context){
      warning("No supr context is not available");
    } else {
      NOT_IMPLEMENTED
    }
  }
  */
  return R_NilValue;
}

static SEXP ClusterEnv_put(SEXP x, SEXP name, SEXP value)
{
  //if(!__supr_context) error(_("no supr context is available"));

  // try socket conn
  
  //if(__supr_context->driver_sc)
  if(driver_sc)
  {
    int fd = driver_sc->fd; // Check fd?
    //int cmd = CLUSTER_BYTE_MSG;
    // {cmd, TR_PUT_PAR, job_id=0, tr_id=0, len, char var_name[len] so_t}?
    const char *c_name = CHAR(asChar(name));
    int len = strlen(c_name)+1;
    int args[] = {CLUSTER_BYTE_MSG, TR_PUT_PAR, -1, -1, len};
    write(fd, args, sizeof(args));
    write(fd, c_name, len);

    size_t size;
    so_t *s = SO_valueOf(value, &size);
    write(fd, s, size);
    free(s);

    int rc;
    read(fd, &rc, INT_SIZE);

    return ScalarInteger(rc);
  }

  NOT_IMPLEMENTED
}

//SEXP ThreadProc_put(SEXP name, SEXP value)
//SEXP Thread_put(SEXP name, SEXP value)
//SEXP Supr_localProcPut(SEXP name, SEXP value)
#ifndef SUPR3
SEXP SuprShared_put(SEXP x, SEXP name, SEXP value)
{
//  fprintf(stderr, "%s %s\n", type2char(TYPEOF(x)), type2char(TYPEOF(name)));
//  fprintf(stderr, "x: %p, location: %s\n", x, CHAR(asChar(x)));

  if(strcmp(CHAR(asChar(x)), ".ClusterEnv")==0){ // not .SharedEnv
    return ClusterEnv_put(x, name, value);
  } else if(strcmp(CHAR(asChar(x)), ".JobEnv")==0){ // not .SharedEnv
//	  .Call("TR_put_par", name, value, job, env)
    SEXP name_char = PROTECT(mkString(CHAR(asChar(name))));
    SEXP retval =  TR_put_par(name_char, value, R_NilValue);
    UNPROTECT(1);
    return retval;
  } else if(strcmp(CHAR(asChar(x)), ".SharedEnv")){ // not .SharedEnv
    NOT_IMPLEMENTED
  }

  if(Supr_threadType == 2){
    NOT_IMPLEMENTED
  }

  SEXP retval;

  if(Thread_R_SharedEnv){ // Thread_put
    const char *c_name = CHAR(asChar(name));
    /*
    SEXP sym;
    retval = findVar(sym = install(c_name), Thread_R_SharedEnv);
    if(retval == R_UnboundValue)
      retval = R_NilValue;
    defineVar(sym, value, Thread_R_SharedEnv);
    // rm??
    */
    pthread_mutex_lock(Thread_C_SharedObjects->mutex);
      defineVar(install(c_name), value, Thread_R_SharedEnv);
      Hashtable_put(Thread_C_SharedObjects, c_name, value);
    pthread_mutex_unlock(Thread_C_SharedObjects->mutex);

    //return retval;
    return value;
  }

  semaphore_t *semap = __thread_proc_io.semap;
  pthread_mutex_lock(&semap->lock);

    sprintf(semap->buf, "%s", CHAR(asChar(name)));
    semap->data_size = strlen(semap->buf)+1;
    semap->cmd = THREAD_PROC_PUT;

    pthread_cond_signal(&semap->cond);
    pthread_cond_wait(&semap->cond, &semap->lock);

    size_t size;
    so_t *so_ret = SO_valueOf(value, &size);
    //__thread_proc_io.put(CHAR(asChar(name)), so, size);
    semap->data_size = size;

      if(size < semap->buf_size)
      {
         memcpy(semap->buf, so_ret, size);
      } else {
	 sprintf(semap->buf, "supr-tproc.%d.%d", geteuid(), getpid());
	 void *mem_ptr = rjni_shm_create(semap->buf, size);
         memcpy(mem_ptr, so_ret, size);
	 munmap(mem_ptr, size);
      }
      free(so_ret);

    //semap->cmd = THREAD_PROC_PUT;

    pthread_cond_signal(&semap->cond);
    pthread_cond_wait(&semap->cond, &semap->lock);

    if(semap->data_size > semap->buf_size){
       size_t size;
       void *mem_ptr = rjni_shm_open((char*) semap->buf, &size);
       retval = SO_toRObject((so_t*) mem_ptr, size);
	       
       munmap(mem_ptr, size);
       shm_unlink((char*) semap->buf);
     } else 
       retval = SO_toRObject((so_t*) semap->buf, semap->data_size);

  pthread_mutex_unlock(&semap->lock);
  return retval;
}
#endif

// delete me
//SEXP (*Thread_put)(SEXP name, SEXP value) = Supr_localProcPut;


SEXP Cluster_jobOperation(SEXP what, SEXP job_id)
{
  //if(!__supr_context) error(_("no supr context is available"));

  // try socket conn
  
  //if(__supr_context->driver_sc)
  if(driver_sc)
  {
    int fd = driver_sc->fd; // Check fd?

    int cmd;
    const char *cmd_str = CHAR(asChar(what));
    if(strcmp(cmd_str, "info")==0){
      cmd = CLUSTER_JOB_INFO;
      
    } else if(strcmp(cmd_str, "malloc")==0){
      cmd = CLUSTER_MALLOC_PRINT;
     
    } else {
      error(_("invalid 'what' value"));
    }

    int args[] = {CLUSTER_BYTE_MSG, cmd, asInteger(job_id)};
    write(fd, args, sizeof(args));
    
    so_t so;
    read(fd, &so, sizeof(so_t)); 
    so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
    memcpy(s, &so, sizeof(so_t));
    read(fd, s->val, s->size);
    SEXP ret = SO_toRObject(s, sizeof(so_t)+so.size);
    free(s);
    return ret;
  }

  NOT_IMPLEMENTED
}



static SEXP ClusterEnv_get(SEXP x, SEXP name)
{
//  if(!__supr_context) error(_("no supr context is available"));

  // try socket conn
  
  //if(__supr_context->driver_sc)
  if(driver_sc)
  {
    int fd = driver_sc->fd; // Check fd?
    //int cmd = CLUSTER_BYTE_MSG;
    // TR_PUT_PAR 
    // {cmd, TR_GET_PAR, job_id=0, tr_id=0, len, char var_name[len]} :: so_t
    const char *c_name = CHAR(asChar(name));
    int len = strlen(c_name)+1;
    int args[] = {CLUSTER_BYTE_MSG, TR_GET_PAR, -1, -1, len};
    write(fd, args, sizeof(args));
    write(fd, c_name, len);
    so_t so;
    read(fd, &so, sizeof(so_t)); 
    so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
    memcpy(s, &so, sizeof(so_t));
    read(fd, s->val, s->size);
    SEXP ret = SO_toRObject(s, sizeof(so_t)+so.size);
    free(s);
    return ret;
  }

  NOT_IMPLEMENTED
}


//
// R_EVAL?
//SEXP ThreadProc_get(SEXP name)
//SEXP Supr_localProcGet(SEXP name)
//SEXP Thread_get(SEXP name)
#ifndef __SUPR3
SEXP SuprShared_get(SEXP x, SEXP name)
{
//  fprintf(stderr, "%s %s\n", type2char(TYPEOF(x)), type2char(TYPEOF(name)));
//  fprintf(stderr, "x: %p, location: %s\n", x, CHAR(asChar(x)));

  if(strcmp(CHAR(asChar(x)), ".ClusterEnv")==0){ // not .SharedEnv
    return ClusterEnv_get(x, name);
	//NOT_IMPLEMENTED
  } else if(strcmp(CHAR(asChar(x)), ".JobEnv")==0){ // not .SharedEnv
//	  .Call("TR_put_par", name, value, job, env)
    SEXP name_char = PROTECT(mkString(CHAR(asChar(name))));
    SEXP retval =  TR_get_par(name_char, R_NilValue);
    UNPROTECT(1);
    return retval;
  } else if(strcmp(CHAR(asChar(x)), ".SharedEnv")){ // not .SharedEnv
	NOT_IMPLEMENTED
  }

  if(Supr_threadType == 2){
	NOT_IMPLEMENTED
  }

  SEXP retval;

  if(Thread_R_SharedEnv){
    pthread_mutex_lock(Thread_C_SharedObjects->mutex);
      //defineVar(install(c_name), value, Thread_R_SharedEnv);
      //Hashtable_put(Thread_C_SharedObjects, c_name, value);
      retval = findVar(install(CHAR(asChar(name))), Thread_R_SharedEnv);
    pthread_mutex_unlock(Thread_C_SharedObjects->mutex);
    //retval = findVar(install(CHAR(asChar(name))), Thread_R_SharedEnv);
    if(retval == R_UnboundValue)
      error(_("object '%s' not found"), CHAR(asChar(name)));
    return retval;
  }

  semaphore_t *semap = __thread_proc_io.semap;
  pthread_mutex_lock(&semap->lock);

    sprintf(semap->buf, "%s", CHAR(asChar(name)));
    semap->data_size = strlen(semap->buf)+1;
    semap->cmd = THREAD_PROC_GET;

    pthread_cond_signal(&semap->cond);
    pthread_cond_wait(&semap->cond, &semap->lock);

    if(semap->data_size > semap->buf_size){
       size_t size;
       void *mem_ptr = rjni_shm_open((char*) semap->buf, &size);
       retval = SO_toRObject((so_t*) mem_ptr, size);
	       
       munmap(mem_ptr, size);
       shm_unlink((char*) semap->buf);
     } else 
       retval = SO_toRObject((so_t*) semap->buf, semap->data_size);

  pthread_mutex_unlock(&semap->lock);
  return retval;
}
#endif

// to be tested
#ifndef __SUPR3
SEXP ThreadProc_lock(SEXP name){
  SEXP retval;
  semaphore_t *semap = __thread_proc_io.semap;
  pthread_mutex_lock(&semap->lock);

    sprintf(semap->buf, "%s", CHAR(asChar(name)));
    semap->data_size = strlen(semap->buf)+1;
    semap->cmd = THREAD_PROC_LOCK;

    pthread_cond_signal(&semap->cond);
    pthread_cond_wait(&semap->cond, &semap->lock);

    // FIXME?
    /*
    if(semap->data_size > semap->buf_size){
       size_t size;
       void *mem_ptr = rjni_shm_open((char*) semap->buf, &size);
       retval = SO_toRObject((so_t*) mem_ptr, size);
	       
       munmap(mem_ptr, size);
       shm_unlink((char*) semap->buf);
     } else 
       retval = SO_toRObject((so_t*) semap->buf, semap->data_size);
    */
    int rc = ((int*) semap->buf)[0];
    //printf("rc: %d\n");
    retval = ScalarInteger(rc);

  pthread_mutex_unlock(&semap->lock);
  return retval;
}

SEXP ThreadProc_unlock(SEXP name){
  SEXP retval;
  semaphore_t *semap = __thread_proc_io.semap;
  pthread_mutex_lock(&semap->lock);

    sprintf(semap->buf, "%s", CHAR(asChar(name)));
    semap->data_size = strlen(semap->buf)+1;
    semap->cmd = THREAD_PROC_UNLOCK;

    pthread_cond_signal(&semap->cond);
    pthread_cond_wait(&semap->cond, &semap->lock);

    /*
    // FIXME?
    if(semap->data_size > semap->buf_size){
       size_t size;
       void *mem_ptr = rjni_shm_open((char*) semap->buf, &size);
       retval = SO_toRObject((so_t*) mem_ptr, size);
	       
       munmap(mem_ptr, size);
       shm_unlink((char*) semap->buf);
     } else 
       retval = SO_toRObject((so_t*) semap->buf, semap->data_size);
     */
    int rc = ((int*) semap->buf)[0];
//    printf("rc: %d\n", rc);
    retval = ScalarInteger(rc);

  pthread_mutex_unlock(&semap->lock);
  return retval;
}

SEXP ThreadProc_wait(SEXP name, SEXP timeout){
  SEXP retval;
  semaphore_t *semap = __thread_proc_io.semap;
  pthread_mutex_lock(&semap->lock);

    *((double*)semap->buf) = asReal(timeout);
    sprintf(semap->buf + sizeof(double), "%s", CHAR(asChar(name)));
    semap->data_size = sizeof(double) + strlen(semap->buf)+1;
    semap->cmd = THREAD_PROC_WAIT;

    pthread_cond_signal(&semap->cond);
    pthread_cond_wait(&semap->cond, &semap->lock);

    // FIXME?
    /*
    if(semap->data_size > semap->buf_size){
       size_t size;
       void *mem_ptr = rjni_shm_open((char*) semap->buf, &size);
       retval = SO_toRObject((so_t*) mem_ptr, size);
	       
       munmap(mem_ptr, size);
       shm_unlink((char*) semap->buf);
     } else 
       retval = SO_toRObject((so_t*) semap->buf, semap->data_size);
     */
    int rc = ((int*) semap->buf)[0];
    retval = ScalarInteger(rc);

  pthread_mutex_unlock(&semap->lock);
  return retval;
}

SEXP ThreadProc_notify(SEXP name, SEXP all){
  SEXP retval;
  semaphore_t *semap = __thread_proc_io.semap;
  pthread_mutex_lock(&semap->lock);

    *((int*)semap->buf) = asInteger(all);
    sprintf(semap->buf + sizeof(int), "%s", CHAR(asChar(name)));
    semap->data_size = sizeof(int) + strlen(semap->buf)+1;
    semap->cmd = THREAD_PROC_NOTIFY;

    pthread_cond_signal(&semap->cond);
    pthread_cond_wait(&semap->cond, &semap->lock);

    // FIXME?
    /*
    if(semap->data_size > semap->buf_size){
       size_t size;
       void *mem_ptr = rjni_shm_open((char*) semap->buf, &size);
       retval = SO_toRObject((so_t*) mem_ptr, size);
	       
       munmap(mem_ptr, size);
       shm_unlink((char*) semap->buf);
     } else 
       retval = SO_toRObject((so_t*) semap->buf, semap->data_size);
     */
     int rc = ((int*) semap->buf)[0];
     retval = ScalarInteger(rc);

  pthread_mutex_unlock(&semap->lock);
  return retval;
}

//SEXP Thread_put(SEXP name, SEXP value)
//{
//}


#endif



//void Thread_run_taskrunner_manager(SEXP env, SEXP data)
// deleted ...
void Thread_run_taskrunner_manager(SEXP env, void *data)
{
  semaphore_t *semap = (semaphore_t *) data;

//    printf("\033[0;34m%d %d SIGNAL! semap: %p\033[0m\n", getpid(), syscall(SYS_gettid), semap);
  pthread_cond_signal(&semap->cond);

//    printf("\033[0;34m%d %d WAIT! semap: %p\033[0m\n", getpid(), syscall(SYS_gettid), semap);

  int running = TRUE;
  while(running){

    pthread_cond_wait(&semap->cond, &semap->lock);

    switch(semap->cmd){
      case THREAD_PROC_GET:
	   {
	     //SEXP val = findVar(install(semap->buf), env);
	     so_t *so;
	     size_t size;
	     BEGIN_R_EVAL();
	       //SEXP val = findVar(install(semap->buf), R_GlobalEnv);
	       pthread_mutex_lock(Thread_C_SharedObjects->mutex); // dead-lock?
	         SEXP val = findVar(install(semap->buf), Thread_R_SharedEnv);
	         so = SO_valueOf(val, &size);
	       pthread_mutex_unlock(Thread_C_SharedObjects->mutex); 
	     END_R_EVAL();
	     void *ptr = sem_io_copy(semap, so, size);
             pthread_cond_signal(&semap->cond);
	     free(so);
	   }
	   break; 

      case THREAD_PROC_PUT:
	   {
	     char *name = strdup(semap->buf);
             pthread_cond_signal(&semap->cond);
             pthread_cond_wait(&semap->cond, &semap->lock);
	     SEXP val = sem_io_RObjectOf(semap);
	     //defineVar(install(name), val, env);
	     BEGIN_R_EVAL();
	       //defineVar(install(name), val, R_GlobalEnv);
	       pthread_mutex_lock(Thread_C_SharedObjects->mutex); // dead-lock?
	         defineVar(install(name), val, Thread_R_SharedEnv);
		 Hashtable_put(Thread_C_SharedObjects, name, val);
	       pthread_mutex_unlock(Thread_C_SharedObjects->mutex); 
	     END_R_EVAL();
             pthread_cond_signal(&semap->cond);
	     free(name);
	   }
	   break;

      case THREAD_PROC_LOCK:
	   {
	     char *name = strdup(semap->buf);

	     //printf("name: %s\n", name);
	     char *c_name = strstr(name, "$");
	     if(c_name) {
	       *c_name = 0;
	       c_name++;
	       if(strcmp(name, "SharedEnv")){
	         warning(_("ignore '%s' argument"), name);
	       }
	     } else 
	       c_name = name;
	     //printf("name: %s, c_name: %s\n", name, c_name);


	     int retval;
	     BEGIN_R_EVAL();

	       /*
	       SEXP m = findVar(install(semap->buf), R_GlobalEnv);
	       SEXP v = Sync_lock(m); 
	       retval = INTEGER(v)[0];
	       */

	       SEXP x, monitor;

	       pthread_mutex_lock(Thread_C_SharedObjects->mutex); // dead-lock?
		 SEXP _SharedEnv = findVar(install(".SharedEnv"), R_GlobalEnv);
	         x = findVar(install(c_name), _SharedEnv);
		 if(x == R_UnboundValue){
                    x = PROTECT(CONS(R_NilValue, R_NilValue));
		    defineVar(install(c_name), x, _SharedEnv);
		    UNPROTECT(1);
		 }
		 monitor = getAttrib(x, install("monitor"));
		 if(monitor == R_NilValue){
			 // lock monitor_root ???
                   supr_monitor_t *m = Monitor_new(NULL);
		   monitor = PROTECT(R_MakeExternalPtr(m, R_NilValue,
					   R_NilValue));
		   R_RegisterCFinalizerEx(monitor, monitor_finalizer, TRUE);
		   setAttrib(x, install("monitor"), monitor);
		   setAttrib(monitor, R_ClassSymbol, mkString("monitor"));
		   UNPROTECT(1);
		 }
	       pthread_mutex_unlock(Thread_C_SharedObjects->mutex); 

	       //SEXP m = findVar(install(semap->buf), R_GlobalEnv);
	       //SEXP v = Sync_lock(m); 
	       SEXP v = Sync_lock(x); 
	       retval = INTEGER(v)[0];

	      // printf("name: %s, c_name: %s, retval: %d\n", name, c_name, retval);
//	       fflush(stdout); sleep(2);

	     END_R_EVAL();
	     memcpy(semap->buf, &retval, INT_SIZE);
             pthread_cond_signal(&semap->cond);
	     free(name);
	   }
	   break;

      case THREAD_PROC_UNLOCK:
	   {
	     char *name = strdup(semap->buf);

	     //printf("name: %s\n", name);
	     char *c_name = strstr(name, "$");
	     if(c_name) {
	       *c_name = 0;
	       c_name++;
	       if(strcmp(name, "SharedEnv")){
	         warning(_("ignore '%s' argument"), name);
	       }
	     } else 
	       c_name = name;
	     //printf("name: %s, c_name: %s\n", name, c_name);

	     int retval;
	     BEGIN_R_EVAL();
	       /*
	       SEXP m = findVar(install(semap->buf), R_GlobalEnv);
	       SEXP v = Sync_unlock(m); 
	       retval = INTEGER(v)[0];
	       */

	       SEXP x; //, monitor;
	       pthread_mutex_lock(Thread_C_SharedObjects->mutex); // dead-lock?
		 SEXP _SharedEnv = findVar(install(".SharedEnv"), R_GlobalEnv);
	         x = findVar(install(c_name), _SharedEnv);
		 /*
		 if(x == R_UnboundValue){
                    x = PROTECT(CONS(R_NilValue, R_NilValue));
		    defineVar(install(c_name), x, _SharedEnv);
		    UNPROTECT(1);
		 }
		 monitor = getAttrib(x, install("monitor"));
		 if(monitor == R_NilValue){
                   supr_monitor_t *m = Monitor_new(NULL);
		   monitor = PROTECT(R_MakeExternalPtr(m, R_NilValue,
					   R_NilValue));
		   R_RegisterCFinalizerEx(monitor, monitor_finalizer, TRUE);
		   setAttrib(x, install("monitor"), monitor);
		   setAttrib(monitor, R_ClassSymbol, mkString("monitor"));
		   UNPROTECT(1);
		 }
		 */
	       pthread_mutex_unlock(Thread_C_SharedObjects->mutex); 

	       if(x == R_UnboundValue){
	         retval = -1;
		 __FIXME__(__func__);
	       } else {
	         SEXP v = Sync_unlock(x); 
	         retval = INTEGER(v)[0];
	       }


	     END_R_EVAL();
	     memcpy(semap->buf, &retval, INT_SIZE);
             pthread_cond_signal(&semap->cond);
	     free(name);
	   }
	   break;

      case THREAD_PROC_WAIT: // handle errors ... Use ToplevelEval???
	   {
	     double timeout = *((double*)semap->buf);
	     char *name = strdup(semap->buf+sizeof(double));

	     //printf("name: %s\n", name);
	     char *c_name = strstr(name, "$");
	     if(c_name) {
	       *c_name = 0;
	       c_name++;
	       if(strcmp(name, "SharedEnv")){
	         warning(_("ignore '%s' argument"), name);
	       }
	     } else 
	       c_name = name;
	     //printf("name: %s, c_name: %s\n", name, c_name);

	     int retval;
	     BEGIN_R_EVAL();
	       /*
	       SEXP m = findVar(install(semap->buf), R_GlobalEnv);
	       SEXP v = Sync_wait(m, ScalarReal(timeout), R_GlobalEnv); 
	       retval = INTEGER(v)[0];
	       */

	       SEXP x; //, monitor;
	       pthread_mutex_lock(Thread_C_SharedObjects->mutex); // dead-lock?
		 SEXP _SharedEnv = findVar(install(".SharedEnv"), R_GlobalEnv);
	         x = findVar(install(c_name), _SharedEnv);
	       pthread_mutex_unlock(Thread_C_SharedObjects->mutex); 

	       if(x == R_UnboundValue){
	         retval = -1;
		 __FIXME__(__func__);
	       } else {
	         SEXP v = Sync_wait(x, ScalarReal(timeout), R_GlobalEnv); 
	         retval = INTEGER(v)[0];
	       }

	     END_R_EVAL();
	     memcpy(semap->buf, &retval, INT_SIZE);
             pthread_cond_signal(&semap->cond);
	     free(name);
	   }
	   break;

      case THREAD_PROC_NOTIFY:
	   {
  	     printf("\033[0;34m%d %d cmd: THREAD_PROC_NOTIFY\033[0m\n",
			     getpid(), syscall(SYS_gettid));
	     int all = *((int*)semap->buf);
	     char *name = strdup(semap->buf+INT_SIZE);

	     //printf("name: %s\n", name);
	     char *c_name = strstr(name, "$");
	     if(c_name) {
	       *c_name = 0;
	       c_name++;
	       if(strcmp(name, "SharedEnv")){
	         warning(_("ignore '%s' argument"), name);
	       }
	     } else 
	       c_name = name;
	     //printf("name: %s, c_name: %s\n", name, c_name);

	     int retval;
	     BEGIN_R_EVAL();
	       /*
	       SEXP m = findVar(install(semap->buf), R_GlobalEnv);
	       SEXP v = Sync_notify(m, ScalarLogical(all), R_GlobalEnv); 
	       retval = INTEGER(v)[0];
	       */

	       SEXP x; //, monitor;
	       pthread_mutex_lock(Thread_C_SharedObjects->mutex); // dead-lock?
		 SEXP _SharedEnv = findVar(install(".SharedEnv"), R_GlobalEnv);
	         x = findVar(install(c_name), _SharedEnv);
	       pthread_mutex_unlock(Thread_C_SharedObjects->mutex); 

	       if(x == R_UnboundValue){
	         retval = -1;
		 __FIXME__(__func__);
	       } else {
	         SEXP v = Sync_notify(x, ScalarLogical(all), R_GlobalEnv); 
	         retval = INTEGER(v)[0];
	       }

	     END_R_EVAL();
	     memcpy(semap->buf, &retval, INT_SIZE);
             pthread_cond_signal(&semap->cond);
	     free(name);
	   }
	   break;

      case THREAD_PROC_EXIT:
	   {
  	     printf("\033[0;34m%d %d cmd: THREAD_PROC_EXIT\033[0m\n",
			     getpid(), syscall(SYS_gettid));
	     SEXP retval;
  	     if(semap->data_size > semap->buf_size){
  	       printf("\033[0;34m%d %d DONE!\033[0m use shm\n", getpid(),
			     syscall(SYS_gettid));
	       size_t size;
	       void *mem_ptr = rjni_shm_open((char*) semap->buf, &size);

	       BEGIN_R_EVAL();
                 retval = SO_toRObject((so_t*) mem_ptr, size);
	         //defineVar(install(".Result"), retval, env);
	         defineVar(install(".value"), retval, env);
	         //PrintValue(ScalarInteger(LENGTH(retval)));
	       END_R_EVAL();
	       
	       munmap(mem_ptr, size);
	       shm_unlink((char*) semap->buf);
	     } else {
  	       printf("\033[0;34m%d %d DONE!\033[0m use buf\n", getpid(),
			     syscall(SYS_gettid));
	       BEGIN_R_EVAL();
                 retval = SO_toRObject((so_t*) semap->buf, semap->data_size);
	         //defineVar(install(".Result"), retval, env);
	         defineVar(install(".value"), retval, env);
	         //PrintValue(retval);
	       END_R_EVAL();
	     }


  	     printf("\033[0;34m%d %d DONE!\033[0m\n", getpid(),
			     syscall(SYS_gettid));

	     running = FALSE;
	     break; //to do
	   }
      default: printf("Error: unknown command %d\n", semap->cmd);
	       running = FALSE;
	       break;
    }
  }
    
  pthread_mutex_unlock(&semap->lock);
  //semaphore_close(semap);
  printf("\033[0;34m%d %d DONE!\033[0m\n", getpid(), syscall(SYS_gettid));
}

void *Thread_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  int process = *((int *) ((void **)arg)[3]);
  char *host  = (char*) ((void **)arg)[4]; // free?

  supr_thread_t *th = NULL; // retval
  semaphore_t *semap = NULL;
  char semaphore_name[256];

#ifdef PROCESS_SHARED_SYNC
  if(host) { // use a smaller stacksize???
    
    //pid_t pid = fork();

    //  find thread server or suprd?
    //if(pid){
	  // TO DO ...

    th = newThread(pthread_self(),
		    getpid(), // ???
		    syscall(SYS_gettid),
		    THREAD_STATE_NEW, (unsigned long) &data);
    //} else { }

  } else if(process) { // use a smaller stacksize???

    //semaphore_t *semap = semaphore_create("/tmp/semaphore");

    sprintf(semaphore_name, "/tmp/sema_io.%d.%ld", getpid(),
		    syscall(SYS_gettid));

    sprintf(semaphore_name, "supr-sema_io.%d.%ld", getpid(),
		    syscall(SYS_gettid));

    //semap = semaphore_create(semaphore_name);
    semap = mmap_io_create(semaphore_name);

    if(semap == NULL)
	    exit(1);

    pthread_mutex_lock(&semap->lock);
    pid_t pid = fork();

    if(pid){

      // wait for the child process to signal
      pthread_cond_wait(&semap->cond, &semap->lock);

      th = newThread(pthread_self(), pid, // child proc
          	syscall(SYS_gettid), // child proc manager
	  	THREAD_STATE_NEW, (unsigned long) &data);

    } else {
      Supr_threadType = process;
      {
        R_Interactive = FALSE;
	// reset thread list

	if(Supr_verbose){
	  printf("\033[0;36mbefore re-init:\n");
	  Thread_dumper();
	}

	for(int i = vectorSize(threads)-1; i>=0; i--){
          supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads,i);
	  if(i==0){ // More to do?

            th->pid = getpid();
	    th->ptid = pthread_self();
	    th->tid = syscall(SYS_gettid);
	    th->R_CStackStart = (unsigned long) &data;
	    pthread_setspecific(currentThreadKey, th);

	  } else {
            vectorRemove(threads,i);
	    th->class->finalize(th->class, th);
	  }
	}

	for(int i = vectorSize(sys_threads)-1; i>=0; i--){
            supr_thread_t *th = (supr_thread_t *)
		    vectorElementAt(sys_threads,i);
            vectorRemove(sys_threads,i);
	    /*
	    int rc = pthread_cancel(th->ptid);
	    void *retval;
	    fprintf(stderr, "\npthread_cancel: %d\npthread_join ...\n", rc);
	    pthread_join(th->ptid, &retval);
	    fprintf(stderr, "\npthread_join: %p\n\n", retval);
	    */

	    th->class->finalize(th->class, th);
	}
	for(int i = vectorSize(dcl_threads)-1; i>=0; i--){
            supr_thread_t *th = (supr_thread_t *)
		    vectorElementAt(dcl_threads,i);
            vectorRemove(dcl_threads,i);
	    th->class->finalize(th->class, th);
	}
	//while(R_InputHandlers) {
	//{
		/*
	  InputHandler *h = R_InputHandlers;
	  for(; h; h = h->next){
            fprintf(stderr, "\nh->fileDescriptor: %d\n", h->fileDescriptor);
	    // FIXME
            //close(h->fileDescriptor);
	  }
	  */
	  /*
	  if(h->fileDescriptor != 0)
	      removeInputHandler(&R_InputHandlers, h);
	      */
	  //if(h->fileDescriptor == 0) break;
	//}
        //}

	printf("__thread_mutex.__data.__owner: %d\n",
			__thread_mutex.__data.__owner);
	pthread_mutex_destroy(&__thread_mutex);
	pthread_mutex_init(&__thread_mutex, NULL);
	__supr_R_Busy(TRUE);
  //R_SetSyncEvalLock(TRUE);
	if(Supr_verbose){
	  printf("__thread_mutex.__data.__owner: %d\n",
			__thread_mutex.__data.__owner);
	  printf("\033[0;36mafter re-init:\033[0m\n");
	  Thread_dumper();
	}

	// remove InputHanders
	InputHandler *h = R_InputHandlers;
	R_InputHandlers = NULL;
	//int rc = removeInputHandler(&R_InputHandlers, InputHandler *it)

	/*
	if(__supr_context){
	  __supr_context->driver_shm_io = NULL;
	  __supr_context->driver_mmap_io = NULL;
	}
	*/

	// to share objects with the parent R process
	Thread_C_SharedObjects = NULL;
	Thread_R_SharedEnv = NULL;
        defineVar(install(".SharedEnv"), R_UnboundValue, R_GlobalEnv);

	SEXP proxy = PROTECT(CONS(R_NilValue, R_NilValue));
	setAttrib(proxy, R_ClassSymbol, mkString("SuprShared"));
        defineVar(install(".SharedEnv"), proxy, R_GlobalEnv);
	UNPROTECT(1);


	__supr_R_Busy(FALSE);
  //R_SetSyncEvalLock(FALSE);
      }

      __thread_proc_io.semap = semap;

      pthread_mutex_lock(&semap->lock);

        pthread_cond_signal(&semap->cond);

        printf("\033[0;32m%d %d Child Proc Signaled. Wait to start ..\033[0m\n",
		       	getpid(), syscall(SYS_gettid));

        pthread_cond_wait(&semap->cond, &semap->lock);

      pthread_mutex_unlock(&semap->lock);


      //pthread_mutex_lock(&semap->lock);
      //pthread_mutex_unlock(&semap->lock);

      //semaphore_close(semap);
      //
      //Thread_run_taskrunner((SEXP) data, NULL);
      //Rboolean R_ToplevelExec(void (*fun)(void *), void *data);

      BEGIN_R_EVAL();
        SEXP env = (SEXP) data;
        SET_SYMVALUE(install("last.warning"), R_UnboundValue);

        R_CStackStart = (unsigned long) (&data);

        void *args[] = {data, findVar(install(".expr"), env)};


        Rboolean success = R_ToplevelExec(Thread_run_taskrunner, args);

        SEXP val, names;

        SEXP warnings = SYMVALUE(install("last.warning"));

        int np = 0;

        if( success ){

	  int len =  warnings == R_UnboundValue ? 1 : 2;

          val = PROTECT(allocVector(VECSXP, len));
          names = PROTECT(allocVector(STRSXP, len));
	  np += 2;
          SET_STRING_ELT(names, 0, mkChar("value"));
          //SET_VECTOR_ELT(val, 0, findVar(install(".Result"), env));
          SET_VECTOR_ELT(val, 0, findVar(install(".value"), env));
	  if(warnings != R_UnboundValue){
            SET_STRING_ELT(names, 1, mkChar("warning"));
            SET_VECTOR_ELT(val, 1, warnings);
	  }

        } else {

          SEXP error_handler = findVar(install(".error.handler"), env);

	  if(error_handler != R_UnboundValue){

	    SEXP error_1 =  PROTECT(mkString(R_curErrorBuf()));
	    SEXP tb_1 = PROTECT(SYMVALUE(install(".Traceback")));

	    {
		    //printf("\033[0;35m.Traceback\n");
		    if(tb_1 == R_UnboundValue){// printf("R_UnboundValue\n");
		       tb_1 = PROTECT(mkString(CHAR(NA_STRING)));
	               np ++;
		    } /* else {
		      printf("type: %s\n", type2char(TYPEOF(tb_1)));
		      PrintValue(tb_1);
		    }
		    printf("\033[0m\n");
		    */
	    }

	    np += 2;

	    SEXP call = PROTECT(LCONS(error_handler, CONS(env, R_NilValue)));
            defineVar(install(".error.handler"), call, env);
            UNPROTECT(1);

            void *args[] = {data, call};
            success = R_ToplevelExec(Thread_run_taskrunner, args);

            if( success ){

	      int len =  warnings == R_UnboundValue ? 3 : 4;
              val = PROTECT(allocVector(VECSXP, len));
              names = PROTECT(allocVector(STRSXP, len));
	      np += 2;

              SET_STRING_ELT(names, 0, mkChar("error"));
              SET_STRING_ELT(names, 1, mkChar("traceback"));
              SET_STRING_ELT(names, 2, mkChar("handle.value"));

              SET_VECTOR_ELT(val, 0, error_1);
              SET_VECTOR_ELT(val, 1, tb_1);
              //SET_VECTOR_ELT(val, 2, findVar(install(".Result"), env));
              SET_VECTOR_ELT(val, 2, findVar(install(".value"), env));

	      if(warnings != R_UnboundValue){
                SET_STRING_ELT(names, len-1, mkChar("warning"));
                SET_VECTOR_ELT(val, len-1, warnings);
	      }

            } else {

	      int len =  warnings == R_UnboundValue ? 4 : 5;
              val = PROTECT(allocVector(VECSXP, len));
              names = PROTECT(allocVector(STRSXP, len));
	      np += 2;

              SET_STRING_ELT(names, 0, mkChar("error"));
              SET_STRING_ELT(names, 1, mkChar("traceback"));
              SET_STRING_ELT(names, 2, mkChar("handle.error"));
              SET_STRING_ELT(names, 3, mkChar("handle.traceback"));

              SET_VECTOR_ELT(val, 0, error_1);
              SET_VECTOR_ELT(val, 1, tb_1);
              SET_VECTOR_ELT(val, 2, mkString(R_curErrorBuf()));
              SET_VECTOR_ELT(val, 3, SYMVALUE(install(".Traceback")));

	      if(warnings != R_UnboundValue){
                SET_STRING_ELT(names, len-1, mkChar("warning"));
                SET_VECTOR_ELT(val, len-1, warnings);
	      }

	    }

	  } else {

	    int len =  warnings == R_UnboundValue ? 2 : 3;

            val = PROTECT(allocVector(VECSXP, len));
            names = PROTECT(allocVector(STRSXP, len));
	    np += 2;

            SET_STRING_ELT(names, 0, mkChar("error"));
            SET_STRING_ELT(names, 1, mkChar("traceback"));
            SET_VECTOR_ELT(val, 0, mkString(R_curErrorBuf()));
            SET_VECTOR_ELT(val, 1, SYMVALUE(install(".Traceback")));

	    if(warnings != R_UnboundValue){
              SET_STRING_ELT(names, 2, mkChar("warning"));
              SET_VECTOR_ELT(val, 2, warnings);
	    }
	  }
          //defineVar(install(".Error"), mkString(R_curErrorBuf()), env);
          //defineVar(install(".Traceback"),SYMVALUE(install(".Traceback")),env);
        }
        setAttrib(val, R_NamesSymbol, names);
        size_t size;
        so_t *so_ret = (so_t*)SO_valueOf(val, &size);
        UNPROTECT(np);
        printf("semap->buf_size: %ld, required size: %ld\n", semap->buf_size,
		      size);

        semap->data_size = size;

        if(size < semap->buf_size)
        {
	      printf("Use buf\n");
          memcpy(semap->buf, so_ret, size);
        } else {
	      printf("Use shm\n");
	  sprintf(semap->buf, "supr-tproc.%d.%d", geteuid(), getpid());
	  void *mem_ptr = rjni_shm_create(semap->buf, size);
          memcpy(mem_ptr, so_ret, size);
	  munmap(mem_ptr, size);
        }
        free(so_ret);


        pthread_mutex_lock(&semap->lock);
        //so_t *so = (so_t*)  semap->buf;

	//sprintf(semap->buf, "success: %d", success);
	//semap->data_size = strlen(semap->buf)+1;

          semap->cmd = THREAD_PROC_EXIT;

          pthread_cond_signal(&semap->cond);
        pthread_mutex_unlock(&semap->lock);

        printf("\033[0;32m%d %d done! result: %s\033[0m\n\n", getpid(),
		      syscall(SYS_gettid), success ? "TRUE":"FALSE");

        //semaphore_close(semap);
        mmap_io_close(semap);
      END_R_EVAL();

      exit(0); // FIXME
    }
  } else {
    th = newThread(pthread_self(), getpid(), syscall(SYS_gettid),
		    THREAD_STATE_NEW, (unsigned long) &data);
  
  }
#else
  th = newThread(pthread_self(), getpid(), syscall(SYS_gettid), 
		  THREAD_STATE_NEW, (unsigned long) &data);
#endif

  *sth = th;

  pthread_mutex_lock(threads->mutex);
    vectorAdd(threads, th);
  pthread_mutex_unlock(threads->mutex);
  
  
  pthread_setspecific(currentThreadKey, th);

//#define THREAD_SAVE_CONTEXT
#ifdef  THREAD_SAVE_CONTEXT
  // save cntxts
  int nCntxt = 0;
  // use the save toplevel
  for(RCNTXT *cptr = R_GlobalContext; cptr->nextcontext;
		  cptr = cptr->nextcontext)
	  nCntxt++;

  RCNTXT __cntxt[nCntxt];

  nCntxt = 0;
  for(RCNTXT *cptr = R_GlobalContext; cptr->nextcontext;
		  cptr = cptr->nextcontext) {
    memcpy(&__cntxt[nCntxt++], cptr, sizeof(RCNTXT));
    printf("%d : [%s] \t\tcntxt: %p\n", th->tid, __func__, &__cntxt[nCntxt-1]);
  }
  for(int i=0; i<nCntxt-1; i++)
    __cntxt[i].nextcontext = &__cntxt[i+1];

  th->R_GlobalContext = &__cntxt[0];

  {
    char *backtrace = myR_simpleTraceback();
    printf("%d : [%s] \t\ttrace:\n%s\n", th->tid, __func__, backtrace);
    free(backtrace);

    RCNTXT *save = R_GlobalContext;
    R_GlobalContext = &__cntxt[0];

    backtrace = myR_simpleTraceback();
    printf("\033[0;35m%d : [%s] \t\ttrace:\n%s\033[0m\n",
		    th->tid, __func__, backtrace);
    free(backtrace);
    printf("\n\n");

    R_GlobalContext = save;
  }

#else 
  //{
    for(RCNTXT *cptr = R_GlobalContext; cptr; cptr = cptr->nextcontext)
	    if(!cptr->nextcontext){ // cptr: ToplevelContext
               th->R_GlobalContext = cptr;
	       break;
	    }
  //}
#endif

//  pthread_cleanup_push((void (*)(void *))pthread_mutex_unlock, &th->mutex);

  // FIXME
  Thread_setInterruptable();
  
  pthread_mutex_lock(&th->mutex);
//    printf("%d %d [%s] Initialized -> Waiting...\n\n", th->pid, th->tid,__func__);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
    th->state = THREAD_STATE_RUNNABLE;
  pthread_mutex_unlock(&th->mutex);

//  pthread_cleanup_pop(FALSE);

//  printf("%d %d [%s] Run...\n", th->pid, th->tid, __func__);


#ifdef PROCESS_SHARED_SYNC
  if(process) {
      //unlink(semaphore_name);
    Thread_run_taskrunner_manager((SEXP) data, (SEXP) semap);
    if(*semap->file_name == '/')
      unlink(semap->file_name);
    else
      shm_unlink(semap->file_name);
    //semaphore_close(semap);
    mmap_io_close(semap);
  } else 
    Thread_run((SEXP) data, NULL);
#else
  Thread_run((SEXP) data, NULL);
#endif

  Thread_setState(th, THREAD_STATE_TERMINATED);

  
//  printf("%d %d [%s] Exit ... th->R_GlobalContext: %p\n", th->pid, th->tid, __func__, th->R_GlobalContext);
//  printf("%d %d [%s] Exit ... R_GlobalContext: %p\n", th->pid, th->tid, __func__, R_GlobalContext);
//  pthread_exit(th); // FIXME
  pthread_exit(data); // FIXME
  return NULL;

}

#define USE_CANCELLABLE_JOIN
#ifdef USE_CANCELLABLE_JOIN

void *join_run(void *arg){
  //volatile
  void **args =  (void **)arg;
  sem_t *sem_ptr = (sem_t *) args[0];

  int i=0;
  
  while(TRUE){
    //fprintf(stdout, "\033[0;32m[%ld] %d. Wait...\033[0m\n", syscall(SYS_gettid), i++);
    sem_wait(sem_ptr); 
    //fprintf(stdout, "\033[0;32m[%ld] Continue...\033[0m\n", syscall(SYS_gettid));
    pthread_t pthread = *((pthread_t*)args[3]);
    //fprintf(stdout, "\033[0;32m      pthread: %ld\033[0m\n", *((pthread_t*)args[3]));
    void *retval;
    int rc = pthread_join(pthread, &retval);
    *((int *)args[3]) = rc;
    *((void **)args[4]) = retval;

    //sleep(10);
    //volatile
    pthread_mutex_t *mutex_ptr = (pthread_mutex_t*)args[1]; // FIXME
    //volatile
    pthread_cond_t   *cond_ptr = (pthread_cond_t*)args[2]; 
    pthread_mutex_lock(mutex_ptr);
      pthread_cond_signal(cond_ptr);
    pthread_mutex_unlock(mutex_ptr);

    /*
    int rc = -1;
    *((int *)args[3]) = rc;
    *((void **)args[4]) = sem_ptr; 
    */

  }

  return NULL;
}

static pthread_mutex_t *cj_mutex_ptr = NULL;
static pthread_cond_t  *cj_cond_ptr = NULL;

void Thread_cancelJoinSigactionInt(int sig, siginfo_t *ip, void *context)
{
  //fprintf(stdout, "\033[0;32m[%ld] Sigaction...\033[0m\n", syscall(SYS_gettid));
  if(cj_mutex_ptr && cj_cond_ptr){
    pthread_mutex_lock(cj_mutex_ptr);
      pthread_mutex_t *mutex_ptr = cj_mutex_ptr;
      pthread_cond_t  *cond_ptr  = cj_cond_ptr;
      cj_mutex_ptr = NULL;
      cj_cond_ptr  = NULL;
      pthread_cond_signal(cond_ptr);
    pthread_mutex_unlock(mutex_ptr);
  }
}

#define JOIN_CANCELLED 9999

static int Supr_cancallableJoin(pthread_t pthread, void **retval)
{
  static pthread_t cancalling_thread = 0;
  static int initialize = TRUE;

  static sem_t sem;
  static void *args[] = {&sem, NULL, NULL, NULL, NULL}; // &cth->mutex, &cth->cond, ..

  if(initialize){
    sem_init(&sem, 1, 0);
    int rc = pthread_create(&cancalling_thread, NULL, join_run, args);
    initialize = FALSE;
  }

  supr_thread_t *cth = currentThread();
  args[1] = &cth->mutex;
  args[2] = &cth->cond;
  args[3] = &pthread;
  args[4] = retval;

  int rc;

  pthread_mutex_lock(&cth->mutex);

    cj_mutex_ptr = &cth->mutex;
    cj_cond_ptr  = &cth->cond;

    struct sigaction save_sigaction;
    {
      struct sigaction sa;
      sa.sa_sigaction = Thread_cancelJoinSigactionInt;
      sigemptyset(&sa.sa_mask);
      sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
      sigaction(SIGINT, &sa, &save_sigaction);
    }

    sem_post(&sem);

    pthread_cond_wait(&cth->cond, &cth->mutex);

    sigaction(SIGINT, &save_sigaction, NULL);

    if(cj_mutex_ptr){
      cj_mutex_ptr = NULL;
      cj_cond_ptr  = NULL;
    } else {
      //fprintf(stdout, "\033[0;31m Cancelled \"join\"\033[0m\n");
      rc = pthread_cancel(cancalling_thread);
      if(rc == 0){
	void *retval;
        rc = pthread_join(cancalling_thread, &retval);
        //fprintf(stdout, "\033[0;31m rc: %d, retval: %p\033[0m\n", rc, retval);
      } /*else {
        //fprintf(stdout, "\033[0;31m Error, rc: %d, ESRCH: %d\033[0m\n", rc, ESRCH);
      }*/
      sem_destroy(&sem);
      initialize = TRUE;
      pthread_mutex_unlock(&cth->mutex);

      rc = JOIN_CANCELLED;
      return rc;
    }

  pthread_mutex_unlock(&cth->mutex);

  rc =  *((int *)args[3]);
  //fprintf(stdout, "\033[0;31m[%d] rc: %d\033[0m\n", cth->tid, rc);
  //fprintf(stdout, "\033[0;31m     retval  : %p\033[0m\n", *((void **)args[4]));
  //fprintf(stdout, "\033[0;31m     sem_addr: %p\033[0m\n", &sem);

  return rc;
}

/*
SEXP Supr_cj(){
  pthread_t pthread = pthread_self();
  void *retval;
  fprintf(stdout, "\033[0;34m\tpthread: %ld\033[0m\n", pthread);
  int rc =  Supr_cancallableJoin(pthread, &retval);
  fprintf(stdout, "\033[0;34m\trc: %d\033[0m\n", rc);
  fprintf(stdout, "\033[0;34m\tretval: %p\033[0m\n", retval);
  return ScalarInteger(rc);
}
*/

#endif

#ifdef SUPR3

void proxyThread_join_run(void *data){
  void **args = (void **)data;
  SEXP thread = (SEXP) args[0];
  supr_socket_conn_t *sc = (supr_socket_conn_t *) args[1];
  supr3_thread_t *th = (supr3_thread_t *) pthread_getspecific(currentThreadKey);
  free(data); // FIXME...

  int len;
  ssize_t size = read(sc->fd, &len, sizeof(int));
  unsigned char *lenAndRaw = malloc(sizeof(int) + len);
  ((int*) lenAndRaw)[0] = len;
  size = read(sc->fd, lenAndRaw + sizeof(int), len);

  //fprintf(stderr, "[line: %d] len_raw: %d\n", __LINE__, len);

  pthread_mutex_lock(&th->mutex);
    th->data = lenAndRaw;
    pthread_cond_signal(&th->cond);
  pthread_mutex_unlock(&th->mutex);

  pthread_exit(lenAndRaw);
}


void  Thread_SigactionInt4Join(int sig, siginfo_t *ip, void *context)
{
  supr_thread_t *th = (supr_thread_t *) pthread_getspecific(currentThreadKey); 
  //fprintf(stderr, "[%s:%d] %s(sig=%d,...), pid: %d, tid: %d\n", __FILE__, __LINE__, __func__, sig, th->pid, th->tid);
  if(th->data){
   supr3_thread_t *t = (supr3_thread_t *) th->data;
    pthread_mutex_lock(&t->mutex);
      pthread_cond_signal(&t->cond);
    pthread_mutex_unlock(&t->mutex);
  }
  // Create a thread to continue ... ???
}

// thread: pid for now
SEXP Thread_join(SEXP thread, SEXP useProxy)
{
  int save = R_PPStackTop;

  static struct sigaction actInt;
  static struct sigaction oldActInt;

  //{ use a sig_init(...)???
    actInt.sa_sigaction = Thread_SigactionInt4Join;
    sigemptyset(&actInt.sa_mask);
    actInt.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &actInt, &oldActInt);
  //}

  SEXP proxy = getAttrib(thread, install("proxy.thread"));
  if(TYPEOF(proxy) != NILSXP){
    supr3_thread_t *th = (supr3_thread_t *) R_ExternalPtrAddr(proxy);
    R_unlock();
    pthread_mutex_lock(&th->mutex);
      int rc;
      if(!th->data) {
	supr_thread_t *cth = (supr_thread_t *) pthread_getspecific(
			currentThreadKey);
	cth->data = th;
        rc = pthread_cond_wait(&th->cond, &th->mutex);
	cth->data = NULL;
      }

      if(!th->data) {
	//fprintf(stderr, "rc: %d, errno: %d (EINTR: %d, ENOMEM: %d)\n", rc, errno, EINTR, ENOMEM);

        pthread_mutex_unlock(&th->mutex);
        sigaction(SIGINT, &oldActInt, NULL);
	R_lock();
	error(_("pthread_cond_wait, %s"), strerror(errno));
      }

      sigaction(SIGINT, &oldActInt, NULL);

    pthread_mutex_unlock(&th->mutex);

    void *lenAndRaw;
    pthread_join(th->ptid, &lenAndRaw); //pthread_join(th->pthread, &lenAndRaw);
    int len_raw = ((int*)lenAndRaw)[0];
    //fprintf(stderr, "[line: %d] len_raw: %d\n", __LINE__, len_raw);
    R_lock();

    SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
    //ssize_t size = read(sc->fd, DATAPTR(raw), len_raw);
    memcpy(DATAPTR(raw), lenAndRaw + sizeof(int), len_raw);
    SEXP call = PROTECT(LCONS(install("unserialize"),
                                  CONS(raw, R_NilValue)));
    SEXP ret_val = PROTECT(eval(call, R_GlobalEnv));
    UNPROTECT(3);
    free(lenAndRaw);


    // destroy th.... TODO
    pthread_mutex_destroy(&th->mutex);
    pthread_cond_destroy(&th->cond);
    free(th);

    if(save != R_PPStackTop)
       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
	     __FILE__, __LINE__, __func__, save, R_PPStackTop);

    //if(TYPEOF(ret_val) != NILSXP) setAttrib(ret_val, R_ClassSymbol, install("ThreadResult"));

    return ret_val;
  }

  SEXP server = getAttrib(thread, install("server"));

  if(TYPEOF(server) != NILSXP){

    /*
    char buf[strlen(CHAR(STRING_ELT(server,0)))+1];
    strcpy(buf, CHAR(STRING_ELT(server,0)));
    char *port_str = strstr(buf, ":");
    char *host = buf;
    int port;
    if(port_str) {
      *port_str = 0;
      port_str++;
      port = atoi(port_str);
    } else {
      port = atoi(host);
    }
    supr_socket_conn_t *sc = socketOpen2(host, port);
    if(!sc) {
      sigaction(SIGINT, &oldActInt, NULL);
      error(_("cannot connect %s"), CHAR(STRING_ELT(server,0)));
    }
    */

    supr_socket_conn_t *sc = Sync_connect(server);

    int cmd = THREAD_PROC_JOIN;// use a proxy thread to do this? later...
    write(sc->fd, &cmd, sizeof(int));
    //write(sc->fd, INTEGER(thread), sizeof(int));
    R_unlock();
    write(sc->fd, INTEGER(thread), sizeof(int));
    
    {
      /*
      struct timeval tv;
      tv.tv_sec=0;
      tv.tv_usec=50000;
      */

      fd_set readfds;
      FD_ZERO(&readfds);

      int fd = sc->fd;
      FD_SET(fd, &readfds);
      int max_fd = fd;

      errno = 0;
      int ns = select(max_fd+1, &readfds, NULL, NULL, NULL);
      if(ns <= 0){
          sigaction(SIGINT, &oldActInt, NULL);

	  fprintf(stderr, "errno: %d (EINTR: %d, ENOMEM: %d)\n",
	  	errno, EINTR, ENOMEM);

          // Create a thread to continue ... ???
	  void **data = malloc(sizeof(void*)*2);
	  data[0] = thread;
	  data[1] = sc;
          supr3_thread_t *proxy = ThreadServer_proxyThread(
	  				proxyThread_join_run, (void *) data);
          R_lock();
	  SEXP proxyPtr = PROTECT(R_MakeExternalPtr(proxy,
	  	R_NilValue, R_NilValue));

	  //R_RegisterCFinalizerEx(proxyPtr, ThreadServer_proxyThread_finalizer, TRUE);
	  setAttrib(thread, install("proxy.thread"), proxyPtr);

	  error(_("select, %s"), strerror(errno));
      }

      sigaction(SIGINT, &oldActInt, NULL);
    }

    int len_raw;
    read(sc->fd, &len_raw, sizeof(int));
    R_lock();
    if(len_raw == -1) error(_("join, %s"), strerror(errno));

    SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
    ssize_t size = read(sc->fd, DATAPTR(raw), len_raw);
    //
    while(size < len_raw){
       if(Socket_available(sc)==0) break;
       ssize_t n = read(sc->fd, DATAPTR(raw) + size, len_raw - size);
       size += n;
    }
    //
    if(size == len_raw){
      SEXP call = PROTECT(LCONS(install("unserialize"),
                                  CONS(raw, R_NilValue)));
      SEXP ret_val = PROTECT(eval(call, R_GlobalEnv));
      close(sc->fd);
      free(sc); // FIXME ... keep it ?
      UNPROTECT(3);

      //if(TYPEOF(ret_val) != NILSXP) setAttrib(ret_val, R_ClassSymbol, install("ThreadResult"));
      return ret_val;
    } else {
      close(sc->fd);
      free(sc); // FIXME ... keep it ?
      error(_("%s[%d,] '%s'(%d), len_raw: %d, len_read: %ld, FIXME"),
		      __FILE__, __LINE__, __func__,
		      asInteger(thread), len_raw, size);
    }
  }
  

  pid_t cpid = INTEGER(thread)[0];
  int status;
  pid_t pid = waitpid(cpid, &status, 0);
  //  pid = waitpid(thread_env->R_pid, &status, 0);
  if(pid == -1){
      if(errno == ECHILD) {
        printf("\033[0;31m[%d] Warning: waitpid, %s\033[0m\n",
		getpid(), strerror(errno));
      } else 
        printf("\033[0;31m[%d] Error: waitpid, %s\033[0m\n",
	getpid(), strerror(errno));

      error(_("waitpid: %s"), strerror(errno));
  }

  //fprintf(stderr, "[%s:%d:%s]\n", __FILE__, __LINE__, __func__);

  //{
    int nitems = 3;
    SEXP ret_val;
    char path[PATH_MAX];
    sprintf(path, "%s/return-%d.bin", Supr_threadDir, cpid);
    int fd = open(path, O_RDONLY);
    if(fd == -1) { // FIXME: handle killed processes?
      //error(_("open(%s): %s\n"), path, strerror(errno));
      nitems--;
      ret_val = PROTECT(allocVector(VECSXP, nitems));
      nitems = 0;
    } else {
      struct stat sb;
      fstat(fd, &sb);

      int len = (int) sb.st_size;
      SEXP raw = PROTECT(allocVector(RAWSXP, len));
      ssize_t size = read(fd, DATAPTR(raw), sb.st_size);
      if(size != sb.st_size) error(_("read: %s"), strerror(errno));
    
      SEXP call = PROTECT(LCONS(install("unserialize"),
                                  CONS(raw, R_NilValue)));
      SEXP val = PROTECT(eval(call, R_GlobalEnv));

      ret_val = PROTECT(allocVector(VECSXP, nitems));
      nitems = 0;
      SET_VECTOR_ELT(ret_val, nitems++, val);
      UNPROTECT(3);
      unlink(path);
    }

    // stdin
    {
    }

    // stdout
    {
      SEXP out = PROTECT(allocVector(STRSXP, 1));
      sprintf(path, "%s/stdout-%d.txt", Supr_threadDir, cpid);
      int fd = open(path, O_RDONLY);
      if(fd == -1) error(_("open(%s): %s\n"), path, strerror(errno));
      struct stat sb;
      fstat(fd, &sb);

      int len = (int) sb.st_size;
      char *txt = malloc(len+1);
      ssize_t size = read(fd, txt, sb.st_size);
      txt[len] = 0;
      SET_STRING_ELT(out, 0, mkChar(txt));
      free(txt);

      close(fd);
      unlink(path);

      //setAttrib(ret_val, install("stdout"), out);
      SET_VECTOR_ELT(ret_val, nitems++, out);
      UNPROTECT(1);
    }

    // stderr
    {
      SEXP err = PROTECT(allocVector(STRSXP, 1));
      sprintf(path, "%s/stderr-%d.txt", Supr_threadDir, cpid);
      int fd = open(path, O_RDONLY);
      if(fd == -1) error(_("open(%s): %s\n"), path, strerror(errno));
      struct stat sb;
      fstat(fd, &sb);

      int len = (int) sb.st_size;
      char *txt = malloc(len+1);
      ssize_t size = read(fd, txt, sb.st_size);
      txt[len] = 0;
      SET_STRING_ELT(err, 0, mkChar(txt));
      free(txt);

      close(fd);
      unlink(path);

      //setAttrib(ret_val, install("stderr"), err);
      SET_VECTOR_ELT(ret_val, nitems++, err);
      UNPROTECT(1);
    }

    SEXP names = PROTECT(allocVector(STRSXP, nitems));
    if(nitems==3){
      nitems = 0;
      SET_STRING_ELT(names, nitems++, mkChar("value"));
    } else {
      nitems = 0;
    }
    SET_STRING_ELT(names, nitems++, mkChar("stdout"));
    SET_STRING_ELT(names, nitems++, mkChar("stderr"));
    setAttrib(ret_val, R_NamesSymbol, names);
    {
        char path[PATH_MAX];
	sprintf(path, "%s/error-%d.txt", Supr_threadDir, getpid());
	if(access(path, F_OK)==0) {
	  int fd = open(path, O_RDONLY);
	  if(fd == -1) error(_("open(%s): %s\n"), path, strerror(errno));
	  struct stat sb;
	  fstat(fd, &sb);
	  
	  int len = (int) sb.st_size;
	  char *txt = malloc(len+1);
	  ssize_t size = read(fd, txt, sb.st_size);
	  txt[len] = 0;
	  setAttrib(ret_val, install("error"), mkString(txt));
	  
	  free(txt);
	  close(fd);
	  unlink(path);
	}
    }


    UNPROTECT(2);

    close(fd);
    unlink(path);
  //}

  //if(TYPEOF(ret_val) != NILSXP) setAttrib(ret_val, R_ClassSymbol, install("ThreadResult"));
  return ret_val;

}

#else
SEXP Thread_join(SEXP c_thread)
{
  //SEXP c_thread = findVar(install(".thread"), thread_env);

  if(TYPEOF(c_thread) != EXTPTRSXP)
     errorcall(R_NilValue, "Not a Thread object");
  supr_thread_t *th = R_ExternalPtrAddr(c_thread);
  if(!th)
    errorcall(R_NilValue, "cannot find thread");

  if(th->class != Thread_class)
     errorcall(R_NilValue, "Not a Thread object");

  void *retval;
  int rc;
  const char *err = NULL;

  BEGIN_R_FREE(); // BEGIN_R_EVAL_UNLOCK()


#ifdef USE_CANCELLABLE_JOIN
    printf("th->ref_count: %d\n", th->ref_count);
    if(th->ref_count){
      rc = Supr_cancallableJoin(th->ptid, &retval);
    } else {
      rc = JOIN_CANCELLED + 10; // FIXME
      err = "FIXME";
    }
#else
    rc = pthread_join(th->ptid, &retval);
    if(rc != 0) err = strerror(errno); // thread safe???
#endif

  END_R_FREE(); // END_R_EVAL_UNLOCK()

  // USE a vector instead of env for efficiency???
  if(rc == 0){
    char thread_name[128];
    sprintf(thread_name, "Thread.%d", th->tid);
    SEXP _ThreadEnv = findVar(install(".ThreadEnv"), R_GlobalEnv);
    defineVar(install(thread_name), R_UnboundValue, _ThreadEnv);

    pthread_mutex_lock(threads->mutex);
      vectorRemoveElement(threads, th);
    pthread_mutex_unlock(threads->mutex);

    R_SetExternalPtrAddr(c_thread, NULL);

    setAttrib(c_thread, R_ClassSymbol, mkString("TerminatedThread"));
    setAttrib(c_thread, R_NameSymbol, mkString(th->name));
    setAttrib(c_thread, install("environment"), (SEXP) retval);
    /*
    size_t len = strlen(th->name)+1;
    char th_name[len];
    memcpy(th_name, th->name, len);
    */

    Thread_destroy(th);

  }


  if(rc == 0) {
    return (SEXP) retval;
  } else if(rc == JOIN_CANCELLED) // FIXME
  {
    //error(_("CANCELLED"));
    SuprError_setCMessage("CANCELLED");
    return R_ErrorValue;
  } else {
    //error(_("%s"), err);
    //error(_("Error: %s"), err);
    char message[256];
    if(err)
      sprintf(message, "%s", err);
    else
      sprintf(message, "unknown (TODO)");
    SuprError_setCMessage(message);
    return R_ErrorValue; 
  }

}

#endif

SEXP Thread_check(SEXP args, SEXP env)
{
  c_backtrace();
  //sleep(120);
  return R_NilValue;
}



#ifdef SUPR3
// thread: pid, //local for now...
SEXP Thread_start(SEXP thread, SEXP dots){

	/*
  if(TYPEOF(thread) != INTSXP)
    error(_("invalid argument 'thread'"));

  SEXP cl = getAttrib(thread, R_ClassSymbol);
  if(cl == R_NilValue || strcmp(CHAR(asChar(cl)),"Thread"))
    error(_("invalid argument 'thread'"));
    */

  int save = R_PPStackTop;

  SEXP server = PROTECT(getAttrib(thread, install("server")));

  //fprintf(stdout, "\033[0;31m------- tid: %d\n", gettid());
  //PrintValue(thread);
  //PrintValue(server);
  //fprintf(stdout, "-------\n\033[0m");

  // for clients
  if(TYPEOF(server) != NILSXP){

    SEXP address = getAttrib(server, install("address"));
    char buf[strlen(CHAR(STRING_ELT(address, 0)))+1];
    strcpy(buf, CHAR(STRING_ELT(address, 0)));
    char *port_str = strstr(buf, ":");
    char *host = buf;
    int port;
    if(port_str) {
      *port_str = 0;
      port_str++;
      port = atoi(port_str);
    } else {
      port = atoi(host);
    }
    supr_socket_conn_t *sc = socketOpen2(host, port);
    if(!sc)
      error(_("cannot connect to %s"), CHAR(STRING_ELT(address,0)));

    int cmd = THREAD_PROC_START;
    write(sc->fd, &cmd, sizeof(int));
    R_unlock();
    write(sc->fd, INTEGER(thread), sizeof(int));
    
    int rc;
    read(sc->fd, &rc, sizeof(int));
    R_lock();

    close(sc->fd);
    free(sc); // FIXME ... keep it ?

    SEXP ret_val = PROTECT(ScalarInteger(rc));
    //setAttrib(ret_val, install("server"), server);
    UNPROTECT(2);

    if(save != R_PPStackTop)
       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
	     __FILE__, __LINE__, __func__, save, R_PPStackTop);

    return ret_val;
  }
  UNPROTECT(1);
  
  // for ThreadServer
  pid_t pid = INTEGER(thread)[0];
  shm_io_info_t *io = NULL;

  int rc = 0;
  {

    char shm_name[256];
    sprintf(shm_name, "Thread.%d", pid);
    io = shm_io_open(shm_name);


    if(!io){ // TODO
      //error(_("[%d:%s] %s cannot open %s\n\t%s"), __LINE__, __FILE__, __func__, shm_name, strerror(errno));
      rc = -1;
    } else {

      int cmd = THREAD_START;
      shm_io_write(io, io->out, &cmd, sizeof(int));
    }
    // shm_io_close

  }
  return ScalarInteger(rc);
  //
}

#else

/*
SEXP Thread_start(SEXP c_thread){

  if(TYPEOF(c_thread) != EXTPTRSXP)
     errorcall(R_NilValue, "Not a Thread object");
  
  supr_thread_t *th = R_ExternalPtrAddr(c_thread);
  if(th == NULL || th->class != Thread_class)
     errorcall(R_NilValue, "Not a Thread object");

  int rc;
  pthread_mutex_lock(&th->mutex);
    rc = pthread_cond_signal(&th->cond);
  pthread_mutex_unlock(&th->mutex);

//  printf("[%s] return from pthread_cond_signal(%s), rc: %d\n", __func__, th->name, rc);
  if(rc) error("pthread_cond_signal: %d\n", rc);
  //return ScalarInteger(rc);
  return c_thread;
}
*/

#endif



static int R_thread_initialized = FALSE;
static int  __supr_initialized = FALSE;

#define __USE_GNU
#include <dlfcn.h>
#include <link.h>


int __dl_iter_callback (struct dl_phdr_info *info, size_t size, void *data)
{
  char *target = (char*) data;
  printf("info->dlpi_name: %s, target: %s\n", info->dlpi_name, target);
  return strstr(info->dlpi_name, target) ? 1 : 0;
}


  /*
static int Supr_initialize()
{
  if(__supr_initialized)
	  return -1;

  // is libR.so loaded?
  int rc = dl_iterate_phdr( __dl_iter_callback, "libR.so");
  if(!rc) return -1;

  printf("R_GlobalContext: %d\n", R_GlobalContext);

  if(!R_GlobalContext) return -1;

  SEXP call = PROTECT(LCONS(install("commandArgs"), R_NilValue));
  SEXP args = eval(call, R_GlobalEnv);
  printf("pid: %d, commandArgs:\n", getpid());
  PrintValue(args);
  int n = LENGTH(args);
  for(int i=0; i<n; i++){ // More to do
    const char *arg = CHAR(STRING_ELT(args, i));
    if(strcmp(arg, "-v")==0) {
      Supr_verbose = TRUE;
    }
  }
  UNPROTECT(1);

  R_thread_init();

  __supr_initialized = TRUE;
  return 0;
}
  */


static int supr_finalize()
{
  //printf("finalize ...\n");
  //c_backtrace();

  supr_thread_t *cth = currentThread();

  if(Supr_verbose)
  {
    printf("pid: %d, main_thread->pid: %d, cth->pid: %d\n", getpid(),
		  main_thread->pid, cth->pid);
  }

  if(cth != main_thread){
    // let the main thread to do it ... fixme later ...
    printf("cth != main_thread ... FIXME\n"); 
    return -1;
  }

  //printf("cancel threads ...\n");
  pthread_mutex_lock(threads->mutex);
    for(int i = vectorSize(threads)-1; i>=0; i--){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
      if(!th || th == cth) continue;
      int rc = pthread_cancel(th->ptid);
      if(rc == 0){
        void *retval;
        pthread_join(th->ptid, &retval);
      }
      vectorRemoveElement(threads, th);
    }
  pthread_mutex_unlock(threads->mutex);

  //printf("cancel sys_threads ...\n");

  pthread_mutex_lock(sys_threads->mutex);
    for(int i = vectorSize(sys_threads)-1; i>=0; i--){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(sys_threads, i);
      if(!th || th == cth) continue;
      int rc = pthread_cancel(th->ptid);
      if(rc == 0){
        void *retval;
        pthread_join(th->ptid, &retval);
      }
      vectorRemoveElement(sys_threads, th);
    }
  pthread_mutex_unlock(sys_threads->mutex);

  /*
  if(Supr_verbose && main_thread && main_thread->class
		  && main_thread->class->finalize)
  {
    printf("main_thread: %p\n", main_thread);
    printf("main_thread->class: %p\n", main_thread->class);
    printf("main_thread->class->finalize: %p\n",
		    main_thread->class->finalize);
    printf("Thread_class: %p\n", Thread_class);
    printf("threadFinalize: %p\n", threadFinalize);
    printf("threadDestroy: %p\n", threadDestroy);
    main_thread->class->finalize(main_thread->class, main_thread);
  }
  */
  
  if(main_thread)
    main_thread->class->finalize(main_thread->class, main_thread);

  main_thread = NULL;

  R_thread_initialized = FALSE;
  __supr_initialized = FALSE;

  __supr_malloc_finalize();

  return 0;
}

static int Supr_initialized()
{
  return __supr_initialized;
}

supr_thread_t *Thread_main_init()
{
  if(main_thread) {
    return main_thread; // FIXME
    warning(_("FIXME: main_thread is already initialized"));
  }

#ifndef SUPR3
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  }

  memcpy(save_R_ToplevelContext_cjmpbuf, __R_ToplevelContext->cjmpbuf,
		  sizeof(jmp_buf));

  memcpy(R_ToplevelContext_cjmpbuf, __R_ToplevelContext->cjmpbuf,
		  sizeof(jmp_buf));

  //Supr_checkJMP(__func__);

  //supr_thread_t *th = (supr_thread_t *)malloc(sizeof(supr_thread_t));
#endif

  supr_thread_t *th = newThread(pthread_self(),
		  getpid(), (pid_t) syscall(SYS_gettid),
		  THREAD_STATE_RUNNABLE, R_CStackStart);
  fprintf(stderr, "%s_%d: main_thread is initialized, data: %p\n", __FILE__, __LINE__,
		  th->data);

#ifndef SUPR3
  th->R_GlobalContext = __R_ToplevelContext;

  th->name = strdup("Thread.main");
#endif

  supr_init();

  {
    void *val = pthread_getspecific(currentThreadKey);
    if(val){
      error("pthread_getspecific(currentThreadKey): %p", val);
    }
  }
  pthread_setspecific(currentThreadKey, th);
  pthread_setspecific(interruptThreadKey, NULL);

  //Thread_threads = newVector(TRUE);
  if(!threads)
    threads = newVector(TRUE);

  pthread_mutex_lock(threads->mutex);
    vectorAdd(threads, th);
    {
      void *val = pthread_getspecific(currentThreadKey);
      if(val != th){
        error("pthread_getspecific(currentThreadKey): %p != (th) %p", val, th);
      }
    }
  pthread_mutex_unlock(threads->mutex);

  if(!Monitor_class){
    Monitor_class = newClass("Monitor", monitorToChar, monitorFinalize);
    pthread_mutexattr_init(&recursiveMutexAttr);
    pthread_mutexattr_settype(&recursiveMutexAttr, PTHREAD_MUTEX_RECURSIVE);
    //pthread_mutexattr_destroy(&RecursiveMutexAttr);
  }

  main_thread = th;

  { //void Thread_main_register()
    SEXP envir = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(envir, R_GlobalEnv);

    defineVar(install(".type"), R_FalseValue, envir);

    SEXP c_thread = PROTECT(R_MakeExternalPtr(main_thread, R_NilValue, envir));

    SEXP _ThreadEnv = findVar(install(".ThreadEnv"), R_GlobalEnv);
    if( _ThreadEnv == R_UnboundValue) {
      _ThreadEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
      defineVar(install(".ThreadEnv"), _ThreadEnv, R_GlobalEnv);
      UNPROTECT(1);
    }
    /*
    char thread_name[128];
    sprintf(thread_name, "Thread.%d", main_thread->tid);
    defineVar(install(thread_name), c_thread, _ThreadEnv);
    */
    defineVar(install(main_thread->name), c_thread, _ThreadEnv);
    setAttrib(c_thread, R_ClassSymbol, mkString("Thread"));
    UNPROTECT(2);
  
    main_thread->R_thread = c_thread;
  }

  monitors = newVector(TRUE);
  ptr_readline = Thread_readline;

  using_history();

  return main_thread;
}

supr_thread_t *Thread_main_fini()
{
  monitors = NULL; // FIXME: free ...
  supr_fini();
  main_thread = NULL; // FIXME: free
}

//void Thread_main_register();


void Supr_gdb_xterm(int sig, int pid, int tid)
{
  int xterm_fd;
  char *slavename = NULL;
  FILE *f_slave = NULL;
  pid_t xterm_pid;

  char *pSptyName = NULL;
  if((xterm_fd = posix_openpt(O_RDWR | O_NONBLOCK | O_NOCTTY))==-1
             || grantpt(xterm_fd) == -1
             || unlockpt(xterm_fd) == -1
             || !(pSptyName = ptsname(xterm_fd))
         ) {
    error_info("posix_openpt | grantpt | unlockpt | ptsname, %s",
      strerror(errno));
      return;
  }

  int master = xterm_fd;
  slavename = pSptyName;

  /*
  int xterm_in_fd = open(slavename, O_RDONLY);
  int xterm_out_fd = open(slavename, O_WRONLY);
  int xterm_err_fd = open(slavename, O_WRONLY);

  int save_in  = dup(STDIN_FILENO);
  int save_out = dup(STDOUT_FILENO);
  int save_err = dup(STDERR_FILENO);

  dup2(xterm_in_fd, STDIN_FILENO);
  dup2(xterm_out_fd, STDOUT_FILENO);
  dup2(xterm_err_fd, STDERR_FILENO);
  */

  char buf[256], window[256];
  snprintf(buf, sizeof(buf), "-S%s/%d -e gdb -p %d", strrchr(slavename,'/')+1, master, pid);
  xterm_pid = fork();
  if(!xterm_pid) {
    int rc = execlp("xterm", "xterm", buf, (char *)0);
    error_info("execlp(\"xterm\", ...), %s", pid, strerror(errno));
        _exit(1);
  } else {
    
/*
    int status;
    basic_info("waitpid: Wait\n");
    errno = 0;
    int rc = waitpid(cpid, &status, 0);
    basic_info("(%s:%d) waitpid(%d, ...), rc: %d, status: %d, err: %s\n",
             __FILE__, __LINE__, cpid, rc, status, strerror(errno));
*/
//    basic_info("1. xterm_pid: %d", xterm_pid);

    f_slave = fopen(slavename, "r+");
    fgets(window, sizeof window, f_slave);
    basic_info("window: %s", window);


    int xterm_in_fd = open(slavename, O_RDONLY);
    int xterm_out_fd = open(slavename, O_WRONLY);
    int xterm_err_fd = open(slavename, O_WRONLY);

    int save_in  = dup(STDIN_FILENO);
    int save_out = dup(STDOUT_FILENO);
    int save_err = dup(STDERR_FILENO);

    dup2(xterm_in_fd, STDIN_FILENO);
    dup2(xterm_out_fd, STDOUT_FILENO);
    dup2(xterm_err_fd, STDERR_FILENO);
  
    //fclose(f_slave);
    fprintf(stderr, "%s:~ $ # pid=%d, tid=%d\n", Supr_hostname, pid, tid);
    fprintf(stderr, "%s:~ $ gdb -p %d\n", Supr_hostname, pid);

    pid_t gdb_pid = fork();
    if(gdb_pid){ // FIXME, see _gdb_C...

      int status;
      basic_info("waitpid: Wait\n");
      errno = 0;
      int rc = waitpid(gdb_pid, &status, 0);
      basic_info("(%s:%d) waitpid(%d, ...), rc: %d, status: %d, err: %s\n",
             __FILE__, __LINE__, gdb_pid, rc, status, strerror(errno));

      for(int i=0; i<10; i++) {
        sleep(2); // FIXME
	fprintf(stderr, "\033[0;31m.\033[0m");
      }
      exit(EXIT_FAILURE);
    } else {
      char pid_str[64];
      sprintf(pid_str, "%d", pid);
      int rc = execlp("gdb", "gdb", "-p", pid_str, (char *)0);
      if(rc==-1) 
        error_info("system(\"gdb - p %d\"), %s", pid, strerror(errno));
        _exit(1);
    }
    
    dup2(save_in, STDIN_FILENO);
    dup2(save_out, STDOUT_FILENO);
    dup2(save_err, STDERR_FILENO);

    kill(xterm_pid, SIGKILL);
  }

}


void  SUPR_SigactionAbort(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr,"\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  fprintf(stderr, "\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));

  sleep(440);
}

void  SUPR_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  {
    error_info("\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
           getpid(), syscall(SYS_gettid));
    Supr_gdb_xterm(sig, getpid(), (int)syscall(SYS_gettid));
  }


	/*
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);
  fprintf(stderr,"\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));
  fprintf(stderr, "\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));

  */
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  sleep(180);
  //if(info_addr)
  {
    //info_sc = socketOpen1(info_addr); // FIXME
    char msg[1024];
    sprintf(msg, "\033[0;31m\n[%s] pid=%d, tid=%ld\033[0m\n",
                    __func__, getpid(), syscall(SYS_gettid));
    //Supr_debug = TRUE;
    //Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
    basic_info(msg); // error_info()?

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
	    basic_info(buf);
    //  Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);

  sleep(120);

}


//
//               FIXME by making it simpler?
//
// init after R engine has already been started
void Thread_SigactionSIGWINCH_dflt(int sig, siginfo_t *ip, void *cntxt)
{
//  fprintf(stderr, "[%s] is called\n", __func__);

	/*
  rl_save_prompt();
  rl_message("\033[0;32m<%s is called>\033[0m", __func__);
//  sleep(2);
  rl_restore_prompt();
  rl_clear_message();
  */

}

void Supr_killall(char *name)
{
  char cmd[1024+strlen(name)];
  char template[64];
  sprintf(template, "/tmp/supr_XXXXXX");
  int fd = mkstemp(template);
  sprintf(cmd, "ps -Ao uid,ppid,pid,args |grep --regexp="
		  "\"^%d\\( [0-9]*\\)* \\(\\/[0-9A-Za-z]*\\)*%s\" > %s",
		  geteuid(), name, template);
  int rc = system(cmd);

  struct stat sb;
  if(fstat(fd, &sb) != -1){
    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    buf[sb.st_size] = 0;

    //printf("template\n\n");
    printf("template: %s\n", buf);

    char *str = strtok(buf, "\n");
     // printf("template: str: %s\n", str);
    while(str){
      int uid;
      int ppid;
      int pid;
      sscanf(str, "%d %d %d", &uid, &ppid, &pid);
      //printf("template: %d %d %d\n", uid, ppid, pid);
      if(pid !=getpid()){
        printf("template: kill(%d,  SIGKILL);\n", pid);
      }
      str = strtok(NULL, "\n");
    }
      printf("template\n\n");

    // TODO...
  }

  close(fd);

  //write(fd, cmd, strlen(cmd));
  
  //printf("template: %s\n", template);
  //printf("template, cmd: %s\n", cmd);


  unlink(template);
}

// void attribute_hidden Rstd_Busy(int which) { } // defined in unix/sys-std.c
static void Rdefault_Busy(int which)
{
}

SEXP R_thread_fini()
{
  if(Supr_verbose){
    printf("FIXME (%s:%d): implement %s!\n", __FILE__, __LINE__, __func__);
  }

  if(!R_thread_initialized){
    __FIXME__(__func__);
    return R_NilValue;
  }

  Thread_main_fini();

  /*
	  _ThreadEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
  defineVar(install(".ThreadEnv"), _ThreadEnv, R_GlobalEnv);
  UNPROTECT(1);
  */

  defineVar(install(".ThreadEnv"), R_UnboundValue, R_GlobalEnv); // FIXME

  /*
  if(!Thread_C_SharedObjects) {
    Thread_C_SharedObjects = newHashtable(TRUE);
    Thread_R_SharedEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install(".SharedEnv"), Thread_R_SharedEnv, R_GlobalEnv);
    UNPROTECT(1);
  }
  */
  defineVar(install(".SharedEnv"), R_UnboundValue, R_GlobalEnv); // FIXME

  /*
  if(!threads) threads = newVector(TRUE);
  if(!sys_threads) sys_threads = newVector(TRUE);
  if(!dcl_threads) dcl_threads = newVector(TRUE);
  */

  threads = NULL; // FIXME
  sys_threads = NULL; // FIXME
  dcl_threads = NULL; // FIXME


  signal(SIGWINCH, SIG_IGN); //sigaction(SIGWINCH, NULL, NULL);
  signal(SIGUSR2, SIG_IGN); // FIXME: R_...
  //signal(SIGINT, SIG_IGN); // FIXME: R_...
  sigaction(SIGINT, &R_oldIntAct, NULL);

  supr_fini();
  //ptr_R_Busy = save_ptr_R_Busy; // FIXME
  ptr_R_Busy = Rdefault_Busy;

  R_thread_initialized = FALSE;

  return R_NilValue;
}


SEXP R_thread_init()
{

//  save_ptr_R_Busy = ptr_R_Busy;
  // Is R ready/loaded?

// FIXME
  printf("%s:%d REMOVE ME\n");
  if(!tr_cntxt.io){
    printf("%s:%d REMOVE ME\n");
    tr_cntxt.firstSubset = R_NilValue;
  }

  Supr_save_R_ToplevelContext();

  {
    struct sigaction * winch_sa = &R_oldWinchAct;
    winch_sa->sa_sigaction = Thread_SigactionSIGWINCH_dflt;
    sigemptyset(&winch_sa->sa_mask);
    winch_sa->sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGWINCH, winch_sa, NULL);
  }


//  printf("[%s] is called by %d/%d\n", __func__, getpid(), syscall(SYS_gettid));
  //static int R_thread_initialized = FALSE;

  if(R_thread_initialized){
    //c_backtrace();
    //sleep(5);
    //error("R_thread has already been initialized");
    warning("R_thread has already been initialized");
    printf("Warning: R_thread has already been initialized\n");
    // do checking?
    return R_NilValue;
  }

  /*
  if(!R_ErrorValue){
    SEXP R_ErrorValue = PROTECT(mkString("SuprError")); // no PROTECT?
    defineVar(install(".SuprError"), R_ErrorValue, R_GlobalEnv);
    setAttrib(R_ErrorValue, R_ClassSymbol, mkString("SuprError"));
    setAttrib(R_ErrorValue, install("message"), R_NilValue);
    UNPROTECT(1);
  }
  */
  SuprError_check();

  { // debug
    struct sigaction sa;
    sa.sa_sigaction = Thread_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, &R_oldSigSegvAct);
  }


  /*
  {
    struct sigaction * winch_sa = &R_oldWinchAct;
    winch_sa->sa_sigaction = Thread_SigactionSIGWINCH_dflt;
    sigemptyset(&winch_sa->sa_mask);
    winch_sa->sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGWINCH, winch_sa, NULL);
  }
  */

  {
    struct sigaction * sa = &__R_oldUsr2Act;
    sa->sa_sigaction = Thread_SigactionSIGUSR2;
    sigemptyset(&sa->sa_mask);
    sa->sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, sa, NULL);
  }

  supr_init();
  ptr_R_Busy = supr_R_Busy;

  for(int i=0; i<sizeof(connections)/sizeof(supr_socket_conn_t*); i++){
    connections[i] = NULL;
  }

  /*
  if(R_thread_initialized){
    warningcall(R_NilValue, "R_thread has already been initialized");
    return R_NilValue;
  }
  */

  if(!threads) threads = newVector(TRUE);
  if(!sys_threads) sys_threads = newVector(TRUE);
  if(!dcl_threads) dcl_threads = newVector(TRUE);

  if(!Thread_C_SharedObjects) {
    Thread_C_SharedObjects = newHashtable(TRUE);
    Thread_R_SharedEnv = PROTECT(R_NewHashedEnv(R_GlobalEnv, //R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install(".SharedEnv"), Thread_R_SharedEnv, R_GlobalEnv);
    UNPROTECT(1);
  }

  //SEXP
	  _ThreadEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
  defineVar(install(".ThreadEnv"), _ThreadEnv, R_GlobalEnv);
  UNPROTECT(1);

  if(main_thread){
    error("main_thread has been initialized?\n");
  }

  Thread_main_init(); 


  //Thread_main_register();

  // DEBUG
  {
    struct sigaction sa;
    sa.sa_sigaction = SUPR_SigactionAbort;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGABRT, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = SUPR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }

  // FIXME: R_BCNodeStackBase can be smaller than R_BCNodeStackTop,
  // for example, when supr pakage is loaded by R functions from
  // the R library function. To be fixed by supr_R_Busy
  //__R_BCNodeStackBase = R_BCNodeStackTop;
#ifndef SUPR3
  Supr_setR_BCNodeStackBase();
#endif
  


#ifdef R_CHECK_THREAD
  if(Supr_verbose){
    printf("\033[0;31mR_CHECK_THREAD: %s\033[0m\n", R_check_thread_expr);
  }
  // use a new thread, possibly with a child process, to check?
#endif


  R_thread_initialized = TRUE;

  return R_NilValue;
}


// make this a part of R_thread_init...

/*
void Thread_main_register()  { 
//    printf("[%s] is called\n", __func__);
    static int registered = FALSE; 

    //if(registered) return;
    if(registered) {
	    printf("Warning: already registered\n");
	    return;
    }

    registered = TRUE;

    //{ currentThread()->save_CStackStart = R_CStackStart; // ???  }
    SEXP envir = PROTECT(allocSExp(ENVSXP));
    SET_ENCLOS(envir, R_GlobalEnv);

    SEXP c_thread = PROTECT(R_MakeExternalPtr(main_thread, R_NilValue, envir));

    SEXP _ThreadEnv = findVar(install(".ThreadEnv"), R_GlobalEnv);
    if( _ThreadEnv == R_UnboundValue) {
      _ThreadEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
      defineVar(install(".ThreadEnv"), _ThreadEnv, R_GlobalEnv);
      UNPROTECT(1);
    }
    char thread_name[128];
    sprintf(thread_name, "Thread.%d", main_thread->tid);
    defineVar(install(thread_name), c_thread, _ThreadEnv);
    setAttrib(c_thread, R_ClassSymbol, mkString("Thread"));
    UNPROTECT(2);
  //}

    main_thread->R_thread = c_thread;
    //main_thread->R_GlobalContext = R_GlobalContext;
}
*/

#ifdef SUPR3

// testing

int Supr_port(SEXP conn){
   SEXP attr = getAttrib(conn, install("port"));
   if(TYPEOF(attr) != NILSXP) return INTEGER(attr)[0];

   attr = getAttrib(conn, install("address"));
   if(TYPEOF(attr) != NILSXP) {
     const char *s = CHAR(STRING_ELT(attr, 0));
     s = strstr(s, ":"); if(s) s++;
     return atoi(s);
   }

   if(TYPEOF(conn) == STRSXP){
     const char *s = CHAR(STRING_ELT(conn, 0));
     s = strstr(s, ":"); if(s) s++;
     return atoi(s);
   } 

   error(_("cannot find port in %s"), asChar(conn));
   return -1;
}
char* Supr_host(SEXP conn){
   SEXP attr = getAttrib(conn, install("host"));
   if(TYPEOF(attr) != NILSXP) {
      const char *host = CHAR(STRING_ELT(attr, 0));
      char *h = malloc(strlen(host)+1);
      strcpy(h, host);
      return  h;
   }

   attr = getAttrib(conn, install("address"));
   if(TYPEOF(attr) != NILSXP) {
     const char *s = CHAR(STRING_ELT(attr, 0));
     char *h = malloc(strlen(s)+1);
     strcpy(h, s);
     s = strstr(h, ":"); if(s) s='\0';
     return h;
   }
   if(TYPEOF(conn) == STRSXP){
     const char *s = CHAR(STRING_ELT(conn, 0));
     char *h = malloc(strlen(s)+1);
     strcpy(h, s);
     s = strstr(h, ":"); if(s) s='\0';
     return h;
   } 

   error(_("cannot find host in %s"), asChar(conn));
   return NULL;
}

// get rid of conn later ... to user only
SEXP Supr_info(SEXP conn, SEXP text){

  const char *sys_cmd = cmd;

  if(conn != R_NilValue)
    warning(_("conn is replaced by NULL"));

  conn = R_NilValue;

  int port = -1;
  char *host = NULL;
  int info_conn = FALSE;
  if(TYPEOF(conn) == NILSXP){
    if(info_addr){
      char *s = strchr(info_addr, ':');
      if(s) {
        *s = 0; 
	host = strdup(info_addr);
	port = atoi(s+1);
	*s = ':';
      } else {
        error(_("invalid 'info_addr'")); // FIXME
      }
    } else if(info_sc){ // delete me
      warning(_("FIXME: %s:%d"), __FILE__, __LINE__);
      port = info_sc->port;
      host = strdup(info_sc->host);
      info_conn = TRUE;
    } else {
      SEXP infoServer = findVar(install("info"), SuprContextEnv);
//
      if(TYPEOF(infoServer) != NILSXP){
        port = Supr_port(infoServer);
        host = Supr_host(infoServer);
      } else 
	    error(_("cannot find info connection"));
//
/*
      if(TYPEOF(infoServer) == NILSXP){
	    error(_("cannot find info connection"));
      } else if(TYPEOF(infoServer) == STRSXP){ // for taskrunner
        const char *addr = CHAR(STRING_ELT(infoServer, 0));

        info_conn = TRUE;
	fprintf(stderr, "addr: %s, info_conn: %d\n", addr, info_conn);

	port = atoi(strchr(addr, ':'));
	char *s = strstr(addr,"//");
	host = strdup(s ? s + 2:addr);
	s = strchr(host, ':');
	if(s) *s = 0;
      } else {
        port = Supr_port(infoServer);
        host = Supr_host(infoServer);
      }
*/
    }
  } else {
    port = Supr_port(conn);
    host = Supr_host(conn);
  }

  supr_socket_conn_t * sc = socketOpen2(host, port);

  if(!sc) error(_("cannot find info connection '%s:%d'"), host, port);
  free(host);

 
  if(info_conn) {
    int cmd = CLUSTER_PROC_CMD;
    write(sc->fd, &cmd, sizeof(int));
    char str_cmd[256];
    int len = strlen(sys_cmd)+1;
    write(sc->fd, &len, sizeof(int));
    write(sc->fd, sys_cmd, len);
    int rc;
    read(sc->fd, &rc, sizeof(int));
  }
  

  int cmd = SUPR_INFO;
  write(sc->fd, &cmd, sizeof(int));

  
  int len = LENGTH(text);
  int size = 0;
  for(int i=0; i<len; i++) size += strlen(CHAR(STRING_ELT(text,i)))+1; 
  write(sc->fd, &size, sizeof(int));

  char *msg = malloc(size);
  *msg = 0;

  for(int i=0; i<len; i++){
    //write(sc->fd, CHAR(STRING_ELT(text,i)), strlen(CHAR(STRING_ELT(text,i))));
    //char c = i==(len-1)? '\0':'\n';
    //write(sc->fd, &c, 1);
    if( i == (len-1))
      sprintf(msg + strlen(msg), "%s", CHAR(STRING_ELT(text,i)));
    else
      sprintf(msg + strlen(msg), "%s\n", CHAR(STRING_ELT(text,i)));
  }

  write(sc->fd, msg, size);


  int rc;
  read(sc->fd, &rc, sizeof(int));


  cmd = CLUSTER_INFO_DISCONNECT;
  write(sc->fd, &cmd, sizeof(int));

  close(sc->fd);
  free(sc); // destroy?
  return ScalarInteger(rc);
}

static struct sigaction Thread_intAct;
static struct sigaction Thread_intAct_old;

void Thread_SigactionInt(int sig, siginfo_t *ip, void *context){
  fprintf(stderr, "[%s:%d] %s is called: pid: %d, threadState: %d\n",
  	__FILE__, __LINE__, __func__, getpid(), threadState);
  {
    Thread_intAct.sa_sigaction = Thread_SigactionInt;
    sigemptyset(&Thread_intAct.sa_mask);
    Thread_intAct.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGINT, &Thread_intAct, NULL);
    sigaction(THREAD_PROC_SIGSTATE, &Thread_intAct, NULL);
  }
}

static char* C_Thread_name() {
  char buf[256];
  sprintf(buf, "thread-%d", getpid());
  return strdup(buf);
}

/* Use a R session to implement a thread
*/
SEXP Thread_new(SEXP expr, SEXP args, SEXP error_handler, SEXP env, SEXP name,
		SEXP server)
{
  shm_io_info_t *io = NULL;
  
  int save = R_PPStackTop;

  if(TYPEOF(server) == NILSXP){

    if(localThreadServerPort <= 0){
      char shm_name[256];
      sprintf(shm_name, "Thread.new.%d", getpid()); 
      size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
      io = shm_io_create(shm_name, block_size);
      //io = shm_io_open(shm_name);

      if(!io){
        error(_("[%d:%s] %s cannot open %s\n\t%s"), __LINE__, __FILE__,
        __func__, shm_name, strerror(errno));
      }
    }

  } else {
    if(!IS_USER_DATABASE(server))
      error(_("invalid server argument"));

    SEXP address = getAttrib(server, install("address"));
    if(TYPEOF(address) != STRSXP)
      error(_("invalid server argument"));

    char buf[strlen(CHAR(STRING_ELT(address,0)))+1];
    strcpy(buf, CHAR(STRING_ELT(address,0)));
    char *port_str = strstr(buf, ":");
    char *host = buf;
    int port;
    if(port_str) {
      *port_str = 0;
      port_str++;
      port = atoi(port_str);
    } else {
      port = atoi(host);
    }
    supr_socket_conn_t *sc = socketOpen2(host, port);
    if(!sc)
      error(_("cannot connect to %s"), CHAR(STRING_ELT(address,0)));

    int cmd = THREAD_PROC_NEW;
    write(sc->fd, &cmd, sizeof(int));
    // Send Expr, env, etc... as a list
    // list(expr, args, error_handler, env, name)
    SEXP S_args = PROTECT(allocVector(VECSXP, 5));
    SET_VECTOR_ELT(S_args, 0, expr);
    SET_VECTOR_ELT(S_args, 1, args);
    SET_VECTOR_ELT(S_args, 2, error_handler);
    //SET_VECTOR_ELT(S_args, 3, env);
    SET_VECTOR_ELT(S_args, 3, R_EmptyEnv);
    SET_VECTOR_ELT(S_args, 4, name);

    SEXP call = PROTECT(LCONS(install("serialize"), CONS(S_args,
                CONS(R_NilValue, R_NilValue))));
    SEXP raw = PROTECT(eval(call, R_GlobalEnv));

    R_unlock();
    int len = LENGTH(raw);
    write(sc->fd, &len, sizeof(int));

    write(sc->fd, RAW(raw), len);
    
    int cpid;
    read(sc->fd, &cpid, sizeof(int)); 
    R_lock();

    close(sc->fd);
    free(sc); // FIXME...

    SEXP ret_val = PROTECT(ScalarInteger(cpid));
    setAttrib(ret_val, install("server"), server);

    UNPROTECT(4);

    if(save != R_PPStackTop)
       fprintf(stderr, "[%s:%d:%s] save: %d, R_PPStackTop: %d\n",
	     __FILE__, __LINE__, __func__, save, R_PPStackTop);

    return ret_val;
  }

  errno = 0;
  pid_t pid = fork();
  if(pid < 0 ) error(_("fork: %s"), strerror(errno));

  if(pid) {

    if(io) {
      size_t size;
      fprintf(stderr, "\033[0;33m[%d:%s] parent: %d, Reading ...\033[0m\n",
    	__LINE__, __func__, getpid());
      char *something = (char *) shm_io_read(io, io->in, &size, NULL);
      fprintf(stderr, "\033[0;33m[%d:%s] parent: %d, Read: \"%s\"\033[0m\n",
    	__LINE__, __func__, getpid(), something);
      //shm_io_close(io);
    }

    return ScalarInteger(pid); // child proc id
  }

  /////////////////////////////////////////////////////////
  //                     child proc:
  /////////////////////////////////////////////////////////

  pid = getpid();

  // block SIGINT

  sigset_t newMask, oldMask;
  sigemptyset(&newMask);
  sigemptyset(&oldMask);
  sigaddset(&newMask, SIGINT);
  sigprocmask(SIG_BLOCK, &newMask, &oldMask);


  // clean
  {
    while(vectorSize(ThreadServer_socket_connections)){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorRemove(ThreadServer_socket_connections, 0);
      close(sc->fd);
      free(sc); // FIXME
    }
  }

  cmd = C_Thread_name();

  supr_socket_conn_t *sc =  localThreadServerPort > 0 ?
  	socketOpen2(localThreadServerHost, localThreadServerPort) : NULL;

  ForkedChild_sc = sc;

  {
    Thread_intAct.sa_sigaction = Thread_SigactionInt;
    sigemptyset(&Thread_intAct.sa_mask);
    Thread_intAct.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGINT, &Thread_intAct, &Thread_intAct_old);
    sigaction(THREAD_PROC_SIGSTATE, &Thread_intAct, &Thread_intAct_old);
  }

  close(STDIN_FILENO);
  threadState++;


  if(TYPEOF(server) == NILSXP){
    
    if(sc){
      int cmd = THREAD_PROC_CHILD_START;
      write(sc->fd, &cmd, sizeof(int));
      write(sc->fd, &pid, sizeof(int));

      // wait ... to start
      read(sc->fd, &cmd, sizeof(int));

    } else {
    //shm_io_close(io);
      io = NULL;

      char shm_name[256];
      sprintf(shm_name, "Thread.%d", getpid()); 
      //io = shm_io_open(shm_name);
      size_t block_size =  8* sysconf(_SC_PAGE_SIZE);
      io = shm_io_create(shm_name, block_size);
      fprintf(stderr, "\033[0;31m[%d:%s] my  pid: %d, created shm_io: %s\033[0m\n", __LINE__, __func__, getpid(), shm_name);


      // testing
      char buf[256];
      sprintf(buf, "\033[0;31m%d: Hello %d!\033[0m", getpid(), getppid());
      shm_io_write(io, io->out, buf, strlen(buf)+1);

      // info the parent process
      sprintf(shm_name, "Thread.new.%d", getppid()); 
      shm_io_info_t *pio = shm_io_open(shm_name);
      sprintf(buf, "%d: Hello %d!", getpid(), getppid());
      shm_io_write(pio, pio->out, buf, strlen(buf)+1);
      // shm_io_close(pio);


      size_t size = 0;
      fprintf(stderr, "\033[0;31m[%d:%s] my  pid: %d, Waiting to start ...\033[0m\n", __LINE__, __func__, getpid());

      // wait to start // testing
      int *something = (int*) shm_io_read(io, io->in, &size, NULL);

      fprintf(stderr, "\033[0;31m[%d:%s] ppid: %d, my pid: %d. Read! size: %ld\033[0m\n", __LINE__, __func__, getppid(), getpid(), size);

    }
    
    threadState++;

    //int *port = (int*) shm_io_read(io, io->in, &size, NULL);
    //tr_cntxt.port = *port;
    //char hostname[256];
    //gethostname(hostname, sizeof(hostname));
    //tr_cntxt.host = strdup(hostname);


  } else {
    error(_("TODO: %d:%s"), __LINE__, __FILE__);
  }

// shm_open and shm_unlink

  //sleep(100);
  //fprintf(stderr, "\033[0;31m[%d:%s] my  pid: %d, Read:\033[0m\n", __LINE__, __func__, getpid());
  //sleep(300);
  //exit(EXIT_SUCCESS);
  //fprintf(stderr, "\033[0;31m[%d:%s] my  pid: %d, Continue\033[0m\n", __LINE__, __func__, getpid());
  
  SEXP envir =  PROTECT(allocSExp(ENVSXP));
  SET_ENCLOS(envir, env);

  setAttrib(envir, R_ClassSymbol, mkString("ThreadEnv"));

  while(args != R_NilValue){
    SEXP tag = TAG(args);
    if(TYPEOF(tag) == SYMSXP)
      defineVar(tag, CAR(args), envir);
    args = CDR(args);
  }

  if(isFunction(error_handler))
    defineVar(install("error.handler"), error_handler, envir);

  

  defineVar(install(".expr"), expr, envir);
  defineVar(install(".server"), server, envir); // FIXME

  //
  {
    char path[PATH_MAX];
    sprintf(path, "%s/stdout-%d.txt", Supr_threadDir, getpid());
    unlink(path);

    errno = 0;
    FILE *out = fopen(path, "w");
    if(out)
      dup2(fileno(out), STDOUT_FILENO);
    else {
      if(sc){
        int cmd = SUPR_INFO;
        write(sc->fd, &cmd, sizeof(int));
	int len = strlen(strerror(errno)) + +strlen(path) + 64;
	char msg[len];
	sprintf(msg, "Error in open(%s), %s", path, strerror(errno));
	len=strlen(msg)+1;
        write(sc->fd, &len, sizeof(int));
        write(sc->fd, msg, len);
	int rc;
        read(sc->fd, &rc, sizeof(int));
      }
    }
  }
  //

  //
  {
    char path[PATH_MAX];
    sprintf(path, "%s/stderr-%d.txt", Supr_threadDir, getpid());
    unlink(path);

    errno = 0;
    FILE *err = fopen(path, "w");
    if(err)
      dup2(fileno(err), STDERR_FILENO);
    else {
      if(sc){
        int cmd = SUPR_INFO;
        write(sc->fd, &cmd, sizeof(int));
	int len = strlen(strerror(errno)) + +strlen(path) + 64;
	char msg[len];
	sprintf(msg, "Error in open(%s), %s", path, strerror(errno));
	len=strlen(msg)+1;
        write(sc->fd, &len, sizeof(int));
        write(sc->fd, msg, len);
	int rc;
        read(sc->fd, &rc, sizeof(int));
      }
    }
  }
  //

  // clean 
  {
    // RCNTXTs
    RCNTXT *cntxt_ptr = R_GlobalContext;
    RCNTXT *ToplevelContext = R_GlobalContext;
    for(; cntxt_ptr; cntxt_ptr = cntxt_ptr->nextcontext){
      //fprintf(stderr, "\033[0;33m[%d:%s] cntxt: %p\033[0m\n", __LINE__, __func__, cntxt_ptr);
      //fprintf(stderr, "\t\033[0;33m[%d:%s] call:\033[0m\n", __LINE__, __func__);
      //PrintValue(cntxt_ptr->call);
      ToplevelContext = cntxt_ptr;
    }

    R_GlobalContext = ToplevelContext;

    /*
    cntxt_ptr = R_GlobalContext;
    for(; cntxt_ptr; cntxt_ptr = cntxt_ptr->nextcontext){
      fprintf(stderr, "\033[0;33m[%d:%s] cntxt: %p\033[0m\n",
        __LINE__, __func__, cntxt_ptr);
      fprintf(stderr, "\t\033[0;33m[%d:%s] call:\033[0m\n",
        		__LINE__, __func__);
      PrintValue(cntxt_ptr->call);
    }
    */
  }


  /*
  // begincontext ...
  SEXP val = PROTECT(eval(expr, envir));
  // endcontext ...
  */

  int errorOccurred = FALSE;

  RCNTXT cntxt;
  int ctxt_ret_code = CTXT_RETURN;
//  ctxt_ret_code = CTXT_TOPLEVEL;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env,
                                              R_NilValue))));
  defineVar(install(".syscall"), syscall, envir);
  UNPROTECT(1);

  SEXP val = R_NilValue;

  RCNTXT *__R_ToplevelContext = R_GlobalContext;
  if(__R_ToplevelContext->nextcontext) error(_("[%d] Whoops"), __LINE__);

  memcpy(save_R_ToplevelContext_cjmpbuf, __R_ToplevelContext->cjmpbuf,
                  sizeof(jmp_buf));


  begincontext(&cntxt, ctxt_ret_code, syscall, envir, envir,
                      R_NilValue, R_NilValue);

    //if(!SETJMP(cntxt.cjmpbuf))
    //if(!setjmp(cntxt.cjmpbuf))
    if(!setjmp(__R_ToplevelContext->cjmpbuf))
    {
//     fprintf(stderr, "\033[1;31m[%s] OKAY 1\033[0m\n", __func__);
     //memcpy( R_GlobalContext->cjmpbuf, cntxt.cjmpbuf, sizeof(jmp_buf));

          val = eval(expr, envir);

 //    fprintf(stderr, "\033[1;31m[%s] OKAY 2\033[0m\n", __func__);

    } else {

//     fprintf(stderr, "\033[1;31m[%s] OKAY 3\033[0m\n", __func__);
     
          errorOccurred = TRUE;
//	  fprintf(stderr, "[%s] Error: %d\n", __func__, errorOccurred);
          const char *errbuf = R_curErrorBuf();
          val = R_UnboundValue; // mkString(errbuf);
//	  fprintf(stderr, "[%s:%d:%s] Error: %s\n", __FILE__, __LINE__, __func__, errbuf);

          char path[PATH_MAX];
	  sprintf(path, "%s/error-%d.txt", Supr_threadDir, getpid());
	  unlink(path);
	  int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
	  if(fd == -1){
	  } else {
	    ssize_t size = write(fd, errbuf, strlen(errbuf));
	    close(fd);
	  }

    }

 //    fprintf(stderr, "\033[1;31m[%s] OKAY 4\033[0m\n", __func__);

  endcontext(&cntxt);

  if(errorOccurred){ // FIXME?

    SEXP errHandler = findVar(install("error.handler"), envir);
    if(errHandler != R_UnboundValue){
      SEXP err_msg = strlen(R_curErrorBuf()) ?
	      	PROTECT(mkString(R_curErrorBuf())) : R_NilValue;

      begincontext(&cntxt, ctxt_ret_code, syscall, envir, envir,
                      R_NilValue, R_NilValue);
        if(!setjmp(__R_ToplevelContext->cjmpbuf)) {

	  SEXP call = PROTECT(LCONS(install("traceback"), R_NilValue));
	  SEXP tb = PROTECT(eval(call, envir));

	  /*
	  PrintValue(tb);
	  */

  //        fprintf(stderr, "\033[1;32m");
	  tb = findVar(install(".Traceback"), R_BaseEnv);
	  if(tb!=R_UnboundValue) PrintValue(tb);
   //       fprintf(stderr, "\033[0m");

	  call = PROTECT(LCONS(install("error.handler"), //errHandler,
                    CONS(err_msg, CONS(envir, R_NilValue))));
	  eval(call, envir);
    //      fprintf(stderr, "\033[1;31m[%s] OKAY 5\033[0m\n", __func__);
	} else {
     //     fprintf(stderr, "\033[1;31m[%s] OKAY 6, Error in error.handler\033[0m\n", __func__);

          const char *errbuf = R_curErrorBuf();
//	  fprintf(stderr, "[%s] Error: %s\n", __func__, errbuf);
	}

      endcontext(&cntxt);
    }
  }

  threadState++;

  
  // Save it to shm ...
  if(val != R_UnboundValue) {
    SEXP call = PROTECT(LCONS(install("serialize"),
    			 CONS(val, CONS(R_NilValue, R_NilValue))));
    SEXP raw = eval(call, envir);

    char path[PATH_MAX];
    sprintf(path, "%s/return-%d.bin", Supr_threadDir, getpid());
    unlink(path);
    errno = 0;
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if(fd == -1){
      if(sc){
        int cmd = SUPR_INFO;
        write(sc->fd, &cmd, sizeof(int));
	int len = strlen(strerror(errno)) + +strlen(path) + 64;
	char msg[len];
	sprintf(msg, "Error in open(%s): %d, %s", path, fd, strerror(errno));
	len=strlen(msg)+1;
        write(sc->fd, &len, sizeof(int));
        write(sc->fd, msg, len);
	int rc;
        read(sc->fd, &rc, sizeof(int));
      }
    } else {

      /*
      if(sc){
        int cmd = SUPR_INFO;
        write(sc->fd, &cmd, sizeof(int));
	int len = strlen(strerror(errno)) + +strlen(path) + 64;
	char msg[len];
	sprintf(msg, "fd: %d, %s, %s", fd, path, strerror(errno));
	len=strlen(msg)+1;
        write(sc->fd, &len, sizeof(int));
        write(sc->fd, msg, len);
	int rc;
        read(sc->fd, &rc, sizeof(int));
      }
      */

      ssize_t size = write(fd, RAW(raw), LENGTH(raw));
      close(fd);
    }

    UNPROTECT(1);
  }

  threadState++;

  close(STDERR_FILENO);
  close(STDOUT_FILENO);

  //supr_socket_conn_t *sc = socketOpen2(localEnvHost, localEnvPort);
  if(sc){
    int cmd = THREAD_PROC_STATE; // Use THREAD_PROC_CHILD_STATE ?
    write(sc->fd, &cmd, sizeof(int));
    cmd = -1;
    write(sc->fd, &cmd, sizeof(int));
    pid = getpid();
    write(sc->fd, &pid, sizeof(int));
    write(sc->fd, &threadState, sizeof(int));
    int rc;
    read(sc->fd, &rc, sizeof(int));
    close(sc->fd);
    free(sc); // FIXME

  }
  // quit
  SEXP call = PROTECT(LCONS(install("quit"),
                          CONS(mkString("no"), R_NilValue)));

  eval(call, R_GlobalEnv);


  UNPROTECT(3); // not reached
}

#else

// native, proc, and remote?
SEXP Thread_new(SEXP expr, SEXP args, SEXP error_handler, SEXP env,SEXP name,
		SEXP proc)
{

  if(!main_thread){
    //main_thread = Thread_main_init();
	  error("Thread.main is not initialized");
  }

  SEXP envir =  PROTECT(allocSExp(ENVSXP));
  SET_ENCLOS(envir, env);

  setAttrib(envir, R_ClassSymbol, mkString("ThreadEnv"));

  
  //defineVar(install(".args"), args, envir);
  while(args != R_NilValue){
    SEXP tag = TAG(args);
    if(TYPEOF(tag) == SYMSXP)
      defineVar(tag, CAR(args), envir);
    args = CDR(args);
  }

  if(isFunction(error_handler))
    defineVar(install(".error.handler"), error_handler, envir);

  defineVar(install(".expr"), expr, envir);
  defineVar(install(".type"), proc, envir);

//  defineVar(install("Expr"), expr, envir);
//    printf("\t[%s] envir: <%p>\n", __func__, envir);

  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;

  int process;
  char *host = NULL;
  if(TYPEOF(proc) == STRSXP){
    process  = TRUE;
    host = strdup(CHAR(asChar(proc)));
    warning(_("remote thread is not yet implemented"));
  } else {
    process  = asLogical(proc);
  }

  void *arg[] = {envir, &sem, &sth, &process, host};
  int rc = pthread_create(&thread, NULL, Thread_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  /*
  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  */

  //printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  //SEXP c_thread = PROTECT(R_MakeExternalPtr(sth, R_NilValue, R_NilValue));
  SEXP c_thread = PROTECT(R_MakeExternalPtr(sth, R_NilValue, envir));

  SEXP _ThreadEnv = findVar(install(".ThreadEnv"), R_GlobalEnv);
  if(_ThreadEnv == R_UnboundValue){
    _ThreadEnv = PROTECT(R_NewHashedEnv(R_EmptyEnv,
                ScalarInteger(DEFAULT_HASH_SIZE)));
    defineVar(install(".ThreadEnv"), _ThreadEnv, R_GlobalEnv);
    UNPROTECT(1);
  }
  char thread_name[128];
  sprintf(thread_name, "Thread.%d", sth->tid);
  defineVar(install(thread_name), c_thread, _ThreadEnv);
  setAttrib(c_thread, R_ClassSymbol, mkString("Thread"));

  /*
  defineVar(install(".thread"), c_thread, envir);
  setAttrib(envir, R_ClassSymbol, mkString("thread"));
  */
  UNPROTECT(2);

  sth->R_thread = c_thread;
  if(TYPEOF(name) != NILSXP)
    sth->name = strdup(CHAR(asChar(name)));

  //return envir;
  return c_thread;
}

#endif

///////////////////////
//// sub-interpretor? experimental ...

// SEXP R_ParseVector(SEXP text, int n, ParseStatus *status, SEXP srcfile);

typedef SEXP REXP;

#define SUPR_CLASS(s) (s)->gengc_next_node
#define SUPR_SETCLASS(s, c) (s)->gengc_next_node = c

// struct { class; refcnt; SEXP } REXP; ???

/*
// Wrap SEXPREC by adding a class and refcnt
typedef struct {
  class_t *class;
  int ref_count;
  int padding; // resrved -> is_async? // pthread_mutex_t *lock;
  SEXPREC rec;
  void *val[0];
} SupRObject, SuprObject;

SEXP __Supr_eval(SEXP expr, SEXP env);

#define SUPR_REAL(o) REAL(&(o)->rec) 
#define SUPR_CAR(o) CAR(&(o)->rec) 
#define SUPR_SETCAR(x, y) CAR(&(x)->rec) = &(y)->rec 
#define SUPR_CDR(o) CDR(&(o)->rec) 
#define SUPR_SETCDR(x, y) CDR(&(x)->rec) = &(y)->rec
#define SUPR_TAG(o) TAG(&(o)->rec) 
#define SUPR_SET_TAG(x, y) SET_TAG(&(x)->rec, &(y)->rec)
*/


/*
#define USE_REXP
#ifdef USE_REXP
typedef struct VECTOR_SEXPREC {
    SEXPREC_HEADER;
    struct vecsxp_struct vecsxp;
} VECTOR_SEXPREC, *VECSEXP;

typedef union { VECTOR_SEXPREC s; double align; } SEXPREC_ALIGN;
#endif
*/

/*

     case NILSXP:        return "NILSXP";
    case SYMSXP:        return "SYMSXP";
    case LISTSXP:       return "LISTSXP";
    case CLOSXP:        return "CLOSXP";
    case ENVSXP:        return "ENVSXP";
    case PROMSXP:       return "PROMSXP";
    case LANGSXP:       return "LANGSXP";
    case SPECIALSXP:    return "SPECIALSXP";
    case BUILTINSXP:    return "BUILTINSXP";
    case CHARSXP:       return "CHARSXP";
    case LGLSXP:        return "LGLSXP";
    case INTSXP:        return "INTSXP";
    case REALSXP:       return "REALSXP";
    case CPLXSXP:       return "CPLXSXP";
    case STRSXP:        return "STRSXP";
    case DOTSXP:        return "DOTSXP";
    case ANYSXP:        return "ANYSXP";
    case VECSXP:        return "VECSXP";
    case EXPRSXP:       return "EXPRSXP";
    case BCODESXP:      return "BCODESXP";
    case EXTPTRSXP:     return "EXTPTRSXP";
    case WEAKREFSXP:    return "WEAKREFSXP";
    case S4SXP:         return "S4SXP";
    case RAWSXP:        return "RAWSXP";
    case NEWSXP:        return "NEWSXP"; // should never happen (memory.h)
    case FREESXP:       return "FREESXP";
    default:            return "<unknown>";

*/

// Defn.h
#define PTR2VEC(n)      (((n)>0)?(((n)*sizeof(SEXP)-1)/sizeof(VECREC)+1):0)
typedef struct {
        union {
                SEXP            backpointer;
                double          align;
        } u;
} VECREC, *VECP;
// Defn.h


typedef struct {
  REXP rec_ptr; 
} DefinedVar_t, *DefinedVar;

static DefinedVar __define(SEXP initializer, SEXP env);


static REXP free_node_list = NULL; // use class field ptr to form a list
static int free_node_cnt = 0;

// FIXME?
#define __SETCAR(x, y) CAR(x) = y
#define __SETCDR(x, y) CDR(x) = y
#define __SET_TAG(x, y) TAG(x) = y
// TAG(LCONS) is for comment (?)

/*
#define SUPR_INIT_REFCNT(a) (a)->ref_count = 1;
#define SUPR_SET_TYPEOF(a, t) SET_TYPEOF(&(a)->rec, t)
#define SUPR_ATTRIB(a) ATTRIB(&(a)->rec)
*/

/* // Rinternals:

# define REFCNT(x) ((x)->sxpinfo.named)

#if defined(COMPUTE_REFCNT_VALUES)
# define REFCNT(x) ((x)->sxpinfo.named)
# define TRACKREFS(x) (TYPEOF(x) == CLOSXP ? TRUE : ! (x)->sxpinfo.spare)
#else
# define REFCNT(x) 0
# define TRACKREFS(x) FALSE
#endif

#if defined(COMPUTE_REFCNT_VALUES)
# define SET_REFCNT(x,v) (REFCNT(x) = (v))
# if defined(EXTRA_REFCNT_FIELDS)
#  define SET_TRACKREFS(x,v) (TRACKREFS(x) = (v))
# else
#  define SET_TRACKREFS(x,v) ((x)->sxpinfo.spare = ! (v))
# endif
# define DECREMENT_REFCNT(x) do {                                       \
        SEXP drc__x__ = (x);                                            \
        if (REFCNT(drc__x__) > 0 && REFCNT(drc__x__) < REFCNTMAX)       \
            SET_REFCNT(drc__x__, REFCNT(drc__x__) - 1);                 \
    } while (0)
# define INCREMENT_REFCNT(x) do {                             \
        SEXP irc__x__ = (x);                                  \
        if (REFCNT(irc__x__) < REFCNTMAX)                     \
            SET_REFCNT(irc__x__, REFCNT(irc__x__) + 1);       \
    } while (0)
#else
# define SET_REFCNT(x,v) do {} while(0)
# define SET_TRACKREFS(x,v) do {} while(0)
# define DECREMENT_REFCNT(x) do {} while(0)
# define INCREMENT_REFCNT(x) do {} while(0)
#endif

#define ENABLE_REFCNT(x) SET_TRACKREFS(x, TRUE)
#define DISABLE_REFCNT(x) SET_TRACKREFS(x, FALSE)


*/

void Rexp_freeNode(REXP s)
{
  SUPR_SETCLASS(s, free_node_list);
  free_node_list = s;
  free_node_cnt ++;
}

#define SUPR_INIT_REFCNT(s) do {	\
       size_t *__refcnt_ptr___ = (size_t *)(&(s)->gengc_prev_node);	\
       *__refcnt_ptr___ = 0;	\
} while(0)

#define SUPR_INCREF(s) do {	\
       size_t *__refcnt_ptr___ = (size_t *)(&(s)->gengc_prev_node);	\
       *__refcnt_ptr___ ++;	\
} while(0)

#define SUPR_DECREF(s) do {	\
	size_t *__refcnt_ptr___ = (size_t *)(&(s)->gengc_prev_node);	\
	*__refcnt_ptr___ --;	\
	if(*__refcnt_ptr___ <= 0) 	\
		Rexp_freeNode(s);	\
} while(0)

static SEXPREC __UnmarkedNodeTemplate;

REXP __Supr_eval(SEXP expr, SEXP rho);

REXP Rexp_allocNode(SEXPTYPE type)
{
  REXP s;
  if(free_node_list){ // Lock...
    s = free_node_list;
    free_node_list = SUPR_CLASS(free_node_list);
    free_node_cnt --;
  } else {
    s = (REXP) malloc(sizeof(SEXPREC));
  }
  s->sxpinfo = __UnmarkedNodeTemplate.sxpinfo;

  SET_TYPEOF(s, type); // SET_TYPEOF OK - defined macro
  ATTRIB(s) = R_NilValue;

  SUPR_INIT_REFCNT(s);
  SUPR_SETCLASS(s, NULL);

  return s;
}

REXP Rexp_newList(REXP car, REXP cdr)
{
  REXP a = Rexp_allocNode(LISTSXP);
  SUPR_INCREF(a);

  //__SETCAR(a, car);
  //__SETCDR(a, cdr);
  //__SET_TAG(a, R_NilValue);
  SETCAR(a, car);
  SETCDR(a, cdr);
  SET_TAG(a, R_NilValue);

  return a;
}

REXP Rexp_newExternalPtr(void *ptr, SEXP sym)
{
  REXP a = Rexp_allocNode(EXTPTRSXP);
  SUPR_INCREF(a);

  EXTPTR_PTR(a) = ptr;
  EXTPTR_PROT(a) = R_NilValue;
  EXTPTR_TAG(a) = sym;

  return a;
}

REXP Rexp_allocList(size_t len)
{
  SEXP s = R_NilValue;
  for(size_t i=0; i<len; i++)
    s = Rexp_newList(R_NilValue, s);
  
  return s;
}

// R: main/memory.c
#define intCHARSXP 73
// fixme? R: include/Defn.h
# define R_SIZE_T_MAX SIZE_MAX

REXP Rexp_allocVector(SEXPTYPE type, size_t len)
{
  REXP s;
  if(len == 1){
    switch(type){
      case REALSXP:
      case INTSXP:
      case LGLSXP:
	   {
             s = Rexp_allocNode(type);
	     SETSCALAR(s, 1);
	     SET_STDVEC_LENGTH(s, (R_len_t) len);
	     SET_STDVEC_TRUELENGTH(s, 0);
	     return s;
	   }
	   break;
    }
  }


  size_t size = PTR2VEC(len); // ???

  if (len > R_XLEN_T_MAX)
        error(_("vector is too large, %ld"), len);
  else if (len < 0 )
        error(_("negative length vectors are not allowed"));
    /* number of vector cells to allocate */
  switch (type) {
    case NILSXP:
        return R_NilValue;
    case RAWSXP:
        size = len *sizeof(unsigned char); //BYTE2VEC(length);
	       break;
    case CHARSXP:
        error("use of allocVector(CHARSXP ...) is defunct\n");
    case intCHARSXP:
        type = CHARSXP;
        size = (len+1) * sizeof(char); // BYTE2VEC(length + 1);
        break;
    case LGLSXP:
    case INTSXP:
        if (len <= 0)
            size = 0;
        else {
            if (len > R_SIZE_T_MAX / sizeof(int))
                error(_("cannot allocate vector of length %d"), len);
            size = len * sizeof(int); //INT2VEC(length);
        }
        break;
    case REALSXP:
        if (len <= 0)
            size = 0;
        else {
            if (len > R_SIZE_T_MAX / sizeof(double))
                error(_("cannot allocate vector of length %d"), len);
            size = len * sizeof(double); //FLOAT2VEC(length);
        }
        break;
    case CPLXSXP:
        if (len <= 0)
            size = 0;
        else {
            if (len > R_SIZE_T_MAX / sizeof(Rcomplex))
                error(_("cannot allocate vector of length %d"), len);
            size = len * 2*sizeof(double); // ??COMPLEX2VEC(length);
        }
        break;
    case STRSXP:
    case EXPRSXP:
    case VECSXP:
        if (len <= 0)
            size = 0;
        else {
            if (len > R_SIZE_T_MAX / sizeof(SEXP))
                error(_("cannot allocate vector of length %d"), len);
            size = len * sizeof(SEXP); //PTR2VEC(len);
        }
        break;
    case LANGSXP:
        if(len == 0) return R_NilValue;
        s = Rexp_allocList(len);
        SET_TYPEOF(s, LANGSXP);
        return s;
    case LISTSXP:
        return Rexp_allocList(len);
    default:
        error(_("invalid type/length (%s/%d) in vector allocation"),
              type2char(type), len);
  }

  size_t hdrsize = sizeof(SEXPREC_ALIGN);
  size += hdrsize;
  s = (REXP) malloc(size); // free... TODO
  printf("type: %s, len: %d, size: %ld\n", type2char(type), len, size);

  s->sxpinfo = __UnmarkedNodeTemplate.sxpinfo;
  SET_TYPEOF(s, type);
  ATTRIB(s) = R_NilValue;
  SUPR_INIT_REFCNT(s);
  SUPR_SETCLASS(s, NULL);

  SET_STDVEC_LENGTH(s, (R_len_t) len);

  return s;
}

SEXP __SET_VECTOR_ELT(SEXP x, size_t i, SEXP v)
{
  return VECTOR_ELT(x, i) = v; // VECTOR_ELT defined macro
}

void __SET_SYMVALUE(SEXP x, SEXP v) {
  SYMVALUE(x) = v;
}
void __SET_PRINTNAME(SEXP x, SEXP v) {
  PRINTNAME(x) = v; 
}


static REXP Rexp_valueOf(SEXP expr, SEXP env)
{
  printf("type: %s\n", type2char(TYPEOF(expr)));

  REXP c = R_NilValue;

  switch(TYPEOF(expr)){
    case EXPRSXP: {// return Rexp_copyEXPRSXP(expr);
           int n = length(expr); // printf("length(expr): %d\n", n);
	   size_t size = PTR2VEC(n);
           //printf("size: %ld\n", size);
	   size_t hdrsize = sizeof(SEXPREC_ALIGN);
           //printf("hdrsize: %ld\n", hdrsize);
	   size = hdrsize + size * sizeof(VECREC);
           //printf("size: %ld\n", size);

           c = (REXP) malloc(size);
	   c->sxpinfo = __UnmarkedNodeTemplate.sxpinfo;
	   //memcpy(c, expr, size); // FIXME

           SET_TYPEOF(c, EXPRSXP);
           ATTRIB(c) = R_NilValue; // TODO
	   c->gengc_next_node = NULL; // for refcnt ?
	   c->gengc_prev_node = NULL;
	    SET_STDVEC_LENGTH(c, (R_len_t) n);

	   for(int i=0; i<n; i++){
             //__SET_VECTOR_ELT(c, i, Rexp_valueOf(VECTOR_ELT(expr, i)));
             REXP e = Rexp_valueOf(VECTOR_ELT(expr, i), env);
             __SET_VECTOR_ELT(c, i, e);
	     {
               printf("(%s) e: \n", type2char(TYPEOF(e)));
	       PrintValue(e);
               SEXP val = __Supr_eval(e, env);
               printf("(%s) v: \n", type2char(TYPEOF(e)));
	       PrintValue(e);
	     }
	   }
	 }
	 break;

    case LANGSXP: {
           if(expr != R_NilValue) {
	     c = Rexp_newList(Rexp_valueOf(CAR(expr), env), R_NilValue);
	     SET_TYPEOF(c, LANGSXP);
//	     __SET_TAG(c, install("# My Comment..."));
	   }
	   
	   expr = CDR(expr);
	   REXP d = c;

           while(expr != R_NilValue){
             __SETCDR(d, Rexp_newList(Rexp_valueOf(CAR(expr), env),
				     R_NilValue));
	     d = CDR(d);
	     expr = CDR(expr);
	   }

	   /*
	   d = c;
	   while(d != R_NilValue){
	     printf("d-type: %s\n", type2char(TYPEOF(d)));
	     printf("car-type: %s\n", type2char(TYPEOF(CAR(d))));
	     d = CDR(d);
	   }

	   PrintValue(c);
	   */
	 }
	 break;

    case SYMSXP: {
	   size_t size = sizeof(SEXPREC);
	   //printf("sym: %s, size: %ld\n", CHAR(PRINTNAME(expr)), size);
           c = (REXP) malloc(sizeof(SEXPREC));
	   c->sxpinfo = __UnmarkedNodeTemplate.sxpinfo;
           SET_TYPEOF(c, SYMSXP);
	   __SET_SYMVALUE(c, Rexp_valueOf(SYMVALUE(expr), env));
	   __SET_PRINTNAME(c, Rexp_valueOf(PRINTNAME(expr), env));
	   ATTRIB(c) = R_NilValue;
//	   PrintValue(c);
	 }
	 break;

    case BUILTINSXP: { // FIXME
           c = expr;
	 }
	 break;

    case CHARSXP: { // FIXME
           c = expr;
	 }
	 break;

    case REALSXP: { // FIXME
			  /*
	   int n = length(expr);
	   //size_t actual_size;
	   //printf("sizeof(R_len_t): %ld\n", sizeof(R_len_t)); int
	   if(n == 1){
             c = (REXP) malloc(sizeof(SEXPREC));
	     //actual_size = sizeof(double);
	     c->sxpinfo = __UnmarkedNodeTemplate.sxpinfo;
	     SETSCALAR(c, 1);
	     SET_STDVEC_LENGTH(c, (R_len_t) n);
	     SET_STDVEC_TRUELENGTH(c, 0);
	     //printf("c ... -> ... dataptr: %ld\n", (unsigned long) REAL(c) - (unsigned long) c);
	     *REAL(c) = *REAL(expr);
	   } else {
             error(_("not implemented type"));
	   }
           SET_TYPEOF(c, REALSXP);
           ATTRIB(c) = R_NilValue; // TODO
	   c->gengc_next_node = NULL; // for refcnt ?
	   c->gengc_prev_node = NULL;
//	   PrintValue(c);
//	   */
	   int n = LENGTH(expr);
           c = Rexp_allocVector(REALSXP, n);
	   memcpy(REAL(c), REAL(expr), n*sizeof(double));
	 }
	 break;

    case INTSXP: {
	   int n = LENGTH(expr);
           c = Rexp_allocVector(INTSXP, n);
	   memcpy(INTEGER(c), INTEGER(expr), n*sizeof(int));
	 }
	 break;

    default:
   	 error(_("not implemented type: %s (%s:%d)"),
			 type2char(TYPEOF(expr)), __FILE__, __LINE__);
  }


  return c;


  /*
  SEXP r = allocVector(RAWSXP, 1);
  printf("sizeof(SEXPREC_ALIGN): %ld (=?= %ld)\n",
		 sizeof(SEXPREC_ALIGN),
		 (unsigned long)DATAPTR(r) - (unsigned long) r); 

  printf("sizeof(SEXPREC): %ld\n", sizeof(SEXPREC));



  REXP c = (REXP) malloc(sizeof(SEXPREC_ALIGN));

  memcpy(c, expr, sizeof(SEXPREC_ALIGN));

  c->attrib = NULL;
  c->gengc_next_node = NULL;
  c->gengc_prev_node = NULL;

  return c;
  */
}

void Rexp_finalizer(SEXP s)
{
  REXP x = (REXP) R_ExternalPtrAddr(s);
  printf("is called\n");
  // to do
}

#define UNMARK_NODE(s) (MARK(s)=0)


// R_disable_bytecode

SEXP Supr_parse(SEXP text, SEXP env)
{
  static int initialize = TRUE;
  if(initialize){
    UNMARK_NODE(&__UnmarkedNodeTemplate);
  }

  ParseStatus status;
  SEXP srcfile = R_NilValue;
  int n = -1;
  SEXP expr = PROTECT(R_ParseVector(text, n, &status, srcfile));

  REXP ex = Rexp_valueOf(expr, env); // Rexp_new()

  expr = PROTECT(R_MakeExternalPtr(ex, R_NilValue, R_NilValue));
  R_RegisterCFinalizer(expr, Rexp_finalizer);
  setAttrib(expr, R_ClassSymbol, mkString("SuprSexp"));

  UNPROTECT(2);

  {
    PrintValue(ex);
    SEXP val = __Supr_eval(ex, R_GlobalEnv);
    printf("After:\n");
    PrintValue(val);
  }

  return expr;
}

#define UNIMPLEMENTED_TYPE(pref, s) error(_("%s: %s"), (pref), type2char(TYPEOF(s)))

REXP SuprCFunc_colon(REXP self, REXP args, REXP kwlist)
{
	printf("is called\n");
  REXP x = CAR(args); args = CDR(args);
  REXP y = CAR(args);

  int a;
  double b;
  if(TYPEOF(x) == REALSXP){
    double d = REAL(x)[0];
    if(d - floor(d) == 0) {
      a = (int) d;
    } else {
      double a = d;
      if(TYPEOF(y) == REALSXP){
        b = REAL(y)[0];
      } else if(TYPEOF(y) == INTSXP){
        b = INTEGER(y)[0];
      } else {
        error(_("invalid argmunment 'y'"));
      }

      REXP z;
      if(b >= a){
        int n = 1 + (int)floor(b-a);
	printf("n: %d\n", n);
        z = Rexp_allocVector(REALSXP, n);
        double *c = REAL(z);
        for(int i=0; i<n; i++) c[i] = a + i;
      } else {
        int n = 1 + (int)floor(a-b);
	printf("n: %d\n", n);
        z = Rexp_allocVector(REALSXP, n);
        double *c = REAL(z);
        for(int i=0; i<n; i++) c[i] = a - i;
      }
      return z;
    }
  } else if(TYPEOF(x) == INTSXP) {
    a = INTEGER(x)[0];
  } else {
    error(_("invalid argmunment 'x'"));
  }

  if(TYPEOF(y) == REALSXP){
        b = REAL(y)[0];
  } else if(TYPEOF(y) == INTSXP){
        b = INTEGER(y)[0];
  } else {
        error(_("invalid argmunment 'y'"));
  }

  REXP z;
  if(b>=a){
    int n = 1 + (int)floor(b-a);
	printf("n: %d\n", n);
    z = Rexp_allocVector(INTSXP, n);
    int *c = INTEGER(z);
    for(int i=0; i<n; i++) c[i] = a + i;
  } else {
    int n = 1 + (int)floor(a-b);
	printf("n: %d\n", n);
    z = Rexp_allocVector(INTSXP, n);
    int *c = INTEGER(z);
    for(int i=0; i<n; i++) c[i] = a - i;
  }
  return z;
}

REXP SuprCFunc_sin(REXP self, REXP args, REXP kwlist)
{ printf("is called\n");
  REXP x = CAR(args);
  int len = LENGTH(x);
  REXP z;
  switch(TYPEOF(x)){
    case REALSXP: {
	   z = x; // TODO
           double *a = REAL(x);
  	   double *b = REAL(z);
           for(int i=0; i<len; i++) b[i] = sin(a[i]);
	   return z;
	 }
	 break;
    default: UNIMPLEMENTED_TYPE("sin", x);
  }
  return R_NilValue;
}


REXP SuprCFunc_arith(REXP self, REXP args, REXP kwlist)
{
  const char *op = "+"; // use int values???

  if(TYPEOF(self) == SYMSXP) {
	  printf("is called with 'self' = %s\n", CHAR(PRINTNAME(self)));
  } else if(TYPEOF(self) == EXTPTRSXP) {
	  printf("\033[0;35mis called with 'self' = %s\n",
			  CHAR(PRINTNAME(EXTPTR_TAG(self))));
	  op = CHAR(PRINTNAME(EXTPTR_TAG(self)));
  } else {
	  printf("is called\n");
  }
  fprintf(stdout, "\033[0m");


  REXP x = CAR(args); args = CDR(args);

  REXP z;
  if(args == R_NilValue){
    int n = LENGTH(x);
    z = Rexp_allocVector(TYPEOF(x), n);
    if(TYPEOF(x) == REALSXP){
      double *a = REAL(x);
      double *c = REAL(z);
      if(strcmp(op, "+")==0)
        for(int i=0; i<n; i++) c[i] = a[i];
      else if(strcmp(op, "-")==0)
        for(int i=0; i<n; i++) c[i] = -a[i];
      else 
        UNIMPLEMENTED_TYPE(op, x);
    } else if(TYPEOF(x) == INTSXP){
      int *a = INTEGER(x);
      int *c = INTEGER(z);
      if(strcmp(op, "+")==0)
        for(int i=0; i<n; i++) c[i] = a[i];
      else if(strcmp(op, "-")==0)
        for(int i=0; i<n; i++) c[i] = -a[i];
      else 
        UNIMPLEMENTED_TYPE(op, x);
    } else {
      UNIMPLEMENTED_TYPE(op, x);
    }
    return z;
  }

  REXP y = CAR(args); 
  int m = LENGTH(x);
  int n = LENGTH(y);
  int len = m;
  if(n > m){
    z = x; x = y; y = z;
    m = n; n = len; len = m;
  }
  switch(TYPEOF(x)){
    case REALSXP: {
           double *a = REAL(x);
	   z = Rexp_allocVector(REALSXP, len);
           double *c = REAL(z);
	   if(TYPEOF(y) == REALSXP){
  	     double *b = REAL(y);
             if(strcmp(op, "+")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i];
	     } else if(strcmp(op, "*")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i];
	     }
	     
	   } else if(TYPEOF(y) == INTSXP){
  	     int *b = INTEGER(y);
             if(strcmp(op, "+")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i];
	     } else if(strcmp(op, "*")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i];
	     }
	     
	   } else {
    	     UNIMPLEMENTED_TYPE(op, y);
	   }
	   return z;
	 }
	 break;

    case INTSXP: {
           int *a = INTEGER(x);
	   if(TYPEOF(y) == REALSXP){
  	     double *b = REAL(y);
	     z = Rexp_allocVector(REALSXP, len);
             double *c = REAL(z);
             if(strcmp(op, "+")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i];
	     } else if(strcmp(op, "*")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i];
	     }
	     
	   } else if(TYPEOF(x) == INTSXP){
  	     int *b = INTEGER(y);
	     z = Rexp_allocVector(INTSXP, len);
             int *c = INTEGER(z);
             if(strcmp(op, "+")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] + b[i];
	     } else if(strcmp(op, "*")==0) {
	       if(n < len)
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i%n];
	       else
	         for(int i=0; i<len; i++) c[i] = a[i] * b[i];
	     }
	     
	   } else {
    	     UNIMPLEMENTED_TYPE(op, y);
	   }
	   return z;
	 }
	 break;

    default: UNIMPLEMENTED_TYPE(op, x);
  }
  return R_NilValue;
}

typedef REXP (*SuprCFunc)(REXP self, REXP args, REXP kwlist);

REXP SuprCFunc_new(SEXP sym, SuprCFunc func)
{
	// testing
  return Rexp_newExternalPtr(func, sym);
}

REXP __findVar(SEXP sym, SEXP env)
{
  // testing
  const char *name = CHAR(PRINTNAME(sym));
  if(   strcmp(name, "+")==0 || strcmp(name, "-")==0
     || strcmp(name, "*")==0 || strcmp(name, "/")==0
		  ){
    return SuprCFunc_new(sym, SuprCFunc_arith);
  } else if(strcmp(CHAR(PRINTNAME(sym)), ":")==0){
    return SuprCFunc_new(sym, SuprCFunc_colon);
  } else if(strcmp(CHAR(PRINTNAME(sym)), "sin")==0){
	  printf("SuprCFunc_sin: %p\n", SuprCFunc_sin);
    return SuprCFunc_new(sym, SuprCFunc_sin);
  }
  UNIMPLEMENTED_TYPE(CHAR(PRINTNAME(sym)), sym);
  return R_UnboundValue;
}

REXP __Supr_evalList(SEXP list, SEXP rho)
{
  if(list == R_NilValue) return R_NilValue;
  REXP val = Rexp_newList(__Supr_eval(CAR(list), rho), R_NilValue);
  list = CDR(list);
  REXP tmp = val;
  while(list != R_NilValue) {
    REXP v = __Supr_eval(CAR(list), rho);
    __SETCDR(tmp, Rexp_newList(v, R_NilValue));
    tmp  = CDR(tmp);
    list = CDR(list);
  }
  return val;
}

SEXP __Supr_eval(SEXP expr, SEXP rho)
{
  switch(TYPEOF(expr)){
    case NILSXP:
    case LISTSXP:
    case LGLSXP:
    case INTSXP:
    case REALSXP:
    case STRSXP:
    case CPLXSXP:
    case RAWSXP:
    case S4SXP:
    case SPECIALSXP:
    case BUILTINSXP:
    case ENVSXP:
    case CLOSXP:
    case VECSXP:
    case EXTPTRSXP:
    case WEAKREFSXP:
    case EXPRSXP:
         return expr;
    default: 
	 break;
//   	 error(_("[%s] not implemented type: %s"), __func__, type2char(TYPEOF(expr)));
  }

  SEXP tmp = R_NilValue;
  SEXP op = R_NilValue;
  switch (TYPEOF(expr)) {
    //case BCODESXP:
    case SYMSXP:
	 {
	   SEXP tmp = findVar(expr, rho);
           if (tmp == R_UnboundValue)
             error(_("object '%s' not found"), CHAR(PRINTNAME(expr)));
             //error(_("object '%s' not found"), EncodeChar(PRINTNAME(e)));
	 }
	 break;

    case LANGSXP: {
           if (TYPEOF(CAR(expr)) == SYMSXP) {
             SEXP ecall = expr;
	     if (R_GlobalContext != NULL &&	// FIXME??
                    (R_GlobalContext->callflag == CTXT_CCODE))
                ecall = R_GlobalContext->call;
	     //op = findFun3(CAR(expr), rho, ecall);
	     op = __findVar(CAR(expr), rho);
	   } else {
	     op = __Supr_eval(CAR(expr), rho);
	   }
	   printf("\033[0;33mop:\n");
	   PrintValue(op);

	   if (TYPEOF(op) == EXTPTRSXP) { // SuprCFunc 
		   printf("\n\033[0;32m<SuprCFunc>\n\n");
              tmp = __Supr_evalList(CDR(expr), rho); // allow kwlist match?
		   printf("args:\n");
	      PrintValue(tmp);
	      printf("SuprCFunc_add: %p\n", EXTPTR_PTR(op));
	      SuprCFunc func = (SuprCFunc)EXTPTR_PTR(op);
	      tmp = func(op, tmp, R_NilValue);
		   printf("value:\n");
	      PrintValue(tmp);
	   } else if (TYPEOF(op) == SPECIALSXP) {
		   printf("\n<SPECIALSXP>\n\n");
	   }
	   else if (TYPEOF(op) == BUILTINSXP) {
		   printf("\n\033[0;32m<BUILTINSXP>\n\n");
              tmp = __Supr_evalList(CDR(expr), rho); // allow kwlist match?
		   printf("args:\n");
	      PrintValue(tmp);
	      tmp = ((SuprCFunc)EXTPTR_PTR(op))(R_NilValue, tmp, R_NilValue);
		   printf("value:\n");
	      PrintValue(tmp);
	   }
	   else if (TYPEOF(op) == CLOSXP) {
		   printf("\n<CLOSXP>\n");
	   }
	   else
            error(_("attempt to apply non-function"));

	   fprintf(stdout,"\033[0m\n");
	 }
	 break;

    case DOTSXP:
         error(_("'...' used in an incorrect context"));

    default: 
	error(_("[%s] not implemented type: %s (%s:%d)"), __func__,
			 type2char(TYPEOF(expr)), __FILE__, __LINE__);
  }


  return tmp;
}

/*
typedef struct {
  REXP rec_ptr; 
} DefinedVar_t, *DefinedVar;
*/

static DefinedVar __define(SEXP initializer, SEXP env)
{
  REXP ptr = Rexp_valueOf(initializer, env);
  DefinedVar var = (DefinedVar) malloc(sizeof(DefinedVar_t));
  var->rec_ptr = ptr;
  return var;
}

static void __undefine(DefinedVar var)
{
  SUPR_DECREF(var->rec_ptr);
  free(var);
  printf("free: %p\n", var);
}

static void DefinedVar_finalizer(SEXP s)
{
  DefinedVar var = (DefinedVar) R_ExternalPtrAddr(s); 
  __undefine(var);
}

SEXP Supr_define(SEXP list, SEXP rho)
{
  SEXP s = list;
  SEXP t = R_NilValue; // unnamed
  PrintValue(s);

  int pi;
  PROTECT_WITH_INDEX(t, &pi);

  while(s != R_NilValue) {
    if(TAG(s) != R_NilValue){
      SEXP capsule = PROTECT(R_MakeExternalPtr(__define(CAR(s), rho), 
			  R_NilValue, R_NilValue));
      setAttrib(capsule, R_ClassSymbol, mkString("DefinedVar"));
      R_RegisterCFinalizerEx(capsule, DefinedVar_finalizer, TRUE);

      defineVar(TAG(s), capsule, rho);
      UNPROTECT(1);
    } else {
      t = CONS(CAR(s), t);
      REPROTECT(t, pi);
    }
    s = CDR(s);
  }

  if(t == R_NilValue){
    UNPROTECT(1);
    return R_NilValue;
  } else {


    SEXP x;
    if(CDR(t) == R_NilValue) 
      x = PROTECT(CAR(t));
    else {
      int n = length(t);
      x = PROTECT(allocVector(VECSXP, n));
      for(int i=0; i<n; i++){
	      SET_VECTOR_ELT(x, i, CAR(t));
	      t = CDR(t);
      }
    }
    SEXP capsule = PROTECT(R_MakeExternalPtr(__define(x, rho), 
			  R_NilValue, R_NilValue));
    setAttrib(capsule, R_ClassSymbol, mkString("DefinedVar"));
    R_RegisterCFinalizerEx(capsule, DefinedVar_finalizer, TRUE);
    UNPROTECT(3);
    return capsule;
  } 
}

SEXP DefinedVar_print(SEXP x)
{
  PrintValue(((DefinedVar_t *)EXTPTR_PTR(x))->rec_ptr);
}

SEXP Supr_eval(SEXP expr, SEXP rho)
{
  REXP r = __Supr_eval(R_ExternalPtrAddr(expr), rho);
  return r; // FIXME: TODO
}

//


// Check port 7208 
//  netstat -ano -p tcp | grep 7208


char *Cluster_netstat_C(int port, char *args){

   const char *cmd_arg = "-ano -p tcp ";
   if(args) cmd_arg = args;

   char buf[strlen(cmd_arg)+256+1024*8];
   sprintf(buf, "netstat %s | grep %d", cmd_arg, port);
   fprintf(stderr,"\033[0;33m[stderr: ");
   FILE *out = popen(buf, "r");
   char *line = buf;

   vector_t *v = newVector(FALSE);

   int len = 1; // leading '\n'
   while(line = fgets(buf, sizeof(buf), out)){
     vectorAdd(v, strdup(line));
     len += strlen(line);
   }
   pclose(out);
   fprintf(stderr,"]\033[0m");

   char *ret_val = malloc(len+1);
   ret_val[len] = 0;
   len = 1;
   *ret_val = '\n';
   while(vectorSize(v)>0){
     line = vectorRemove(v, 0);
     memcpy(ret_val + len, line, strlen(line));
     len += strlen(line);
     free(line);
   }
   vectorDestroy(v);
   return ret_val;
}


SEXP Cluster_netstat(SEXP port, SEXP args){

   const char *cmd_arg = "-ano -p tcp ";
   if(TYPEOF(args) != NILSXP) cmd_arg = CHAR(asChar(args));

   char buf[strlen(cmd_arg)+256+1024];
   sprintf(buf, "netstat %s | grep %d", cmd_arg, INTEGER(port)[0]);
   fprintf(stderr, "\033[0;31m[stderr: ");
   FILE *out = popen(buf, "r");
   char *line = buf;

   SEXP ret_val = PROTECT(CONS(R_NilValue, R_NilValue));
   SEXP s = ret_val;
   while(line = fgets(buf, sizeof(buf), out)){
     //fprintf(stderr, "%s", line);
     SETCDR(s, CONS(mkString(line), R_NilValue));
     s = CDR(s);
   }
   pclose(out);
   fprintf(stderr, "]\033[0m");
   UNPROTECT(1);
   return CDR(ret_val);
}

void debugHandleCommand(supr_socket_conn_t *conn, vector_t *connections)
{
  int fd = conn->fd;
  //conn->print(conn);

  char msg[1024];
  int cmd;
  {
    ssize_t n = 0;
    for( ; ; ) {
      n = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
      if(n <= 0){
        //fprintf(stderr, "\033[0;31mrecv conn(fd: %d) is disconnected " "(n=%ld)\033[0m\n\n", conn->fd, n);
        char buf[256];
        sprintf(buf, " [%s:%d:%s:RemoveConn] fd: %d, type: %d, recv size = %ld",
                        __FILE__, __LINE__, __func__, conn->fd, conn->type, n);
        Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

        vectorRemoveElement(connections, conn);
	// FIXME
        close(conn->fd);
        Supr_decref(conn);
        return;
      } else if( n == INT_SIZE) break;
    }

    if(Supr_debug){
      char buf[256];
      sprintf(buf, "[%s] fd: %d, type: %d, recv size = %ld, cmd = %d (%s)",
                   __func__, conn->fd, conn->type, n, cmd, cmd2char(cmd));
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);
    }

  }



  switch(cmd){

    case CLUSTER_PING:
         {
           read(fd, &cmd, INT_SIZE);
           int cmd = CLUSTER_PONG;
           write(fd, &cmd, INT_SIZE);
         }
         return;


    case 0:
    default:
      {
        read(fd, &cmd, sizeof(int));

        sprintf(msg, "\033[0;32m%s pid: %d, tid: %d\033[0m",
                        __func__, getpid(), gettid());
        Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

        for(int i=0; i < vectorSize(sys_threads); i++){
          supr_thread_t *th = (supr_thread_t *)vectorElementAt(sys_threads,i);
          sprintf(msg, "thread[%d] name: %s, tid: %d", i, th->name, th->tid);
          Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);
          /*
          if(!pthread_equal(th->ptid, pthread_self())){
            vector_t *strace = newVector(FALSE);
            th->fun = do_backtrace;
            th->data = strace;
            pthread_mutex_lock(&th->mutex);
              pthread_kill(th->ptid, SIG_BACKTRACE);
              pthread_cond_wait(&th->cond, &th->mutex); // do timedwait !
            pthread_mutex_unlock(&th->mutex);
            Cluster_sendSimpleMessage(__func__, msg_color, DEBUG_INFO_TYPE, 0);
            while(vectorSize(strace)){
              char *line = vectorRemove(strace, 0);
              fprintf(stderr, "line: %s\n", line);
              Cluster_sendSimpleMessage(line, msg_color, DEBUG_INFO_TYPE, 0);
              free(line);
            }
            vectorDestroy(strace);
            th->fun = NULL;
            th->data = NULL;
          }
          */
        }

        if(Supr_debug){
          char *buf= NULL;
          Supr_debug2(getpid(), &buf); // TODO
          if(buf)
            Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

          free(buf);
        }

        int rc = 0;
        write(fd, &rc, sizeof(int));
      }
      break;
  }
}



void supr_debug_thread_cleanup(void *data){
  Cluster_sendSimpleMessage(__func__, msg_color, DEBUG_INFO_TYPE, 0);
}


void debug_run(supr_socket_conn_t *debugConn, const char *info_addr)
{
  pthread_cleanup_push(supr_debug_thread_cleanup,
                  pthread_getspecific(currentThreadKey));

  vector_t *connections = newVector(FALSE);
  vectorAdd(connections, debugConn);

  char msg[1024];

    while(TRUE) {

      struct timeval tv;
      tv.tv_sec=100;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      int max_fd = 0;

      for(int i=0; i<vectorSize(connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(connections, i);

        int fd = conn->fd;
        FD_SET(fd, &readfds);

        if(fd > max_fd) max_fd = fd;
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }

      for(int i = vectorSize(connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(connections, i);
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
                continue;

        if(conn == debugConn){
	  // FIXMEME: replace supr_conn_t with supr_socket_conn_t?
          supr_socket_conn_t *clientConn = serverSocketAccept(
			  (supr_conn_t *)debugConn);
          sprintf(msg, "\033[0;34mNewConn, host: %s, fd: %d\033[0m\n",
                          clientConn->host, clientConn->fd);
          Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

          if(clientConn && clientConn->fd != -1){
            vectorAdd(connections, clientConn);
          }
        } else {
          debugHandleCommand(conn, connections);
        }
      }
  }

  pthread_cleanup_pop(TRUE);
}



void *debug_init(void *arg)
{
  void **args = (void**)arg;
  int port = ((int*)args[0])[0];
  char *info_addr = (char *) args[1];
  sem_t *sem = (sem_t *) args[2];
  supr_thread_t **sth = (supr_thread_t **) args[3];

  //{
  int reuse_addr = port ? SocketConn_reuseAddr : FALSE;
  supr_socket_conn_t *debugConn = serverSocketOpen(port, reuse_addr);
  // FIXME: TODO
#define DEBUG_CONN 7001
  debugConn->type = DEBUG_CONN;
  //}

  //if(debugConn){
    supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
                  (unsigned long) &args[0]);

    *sth = th;
    free(th->name);
    char name[256];
    sprintf(name, "debug.%d.%d", getpid(), gettid());
    th->name = strdup(name);
    th->conn = debugConn;

    vectorAdd(sys_threads, th);

    pthread_setspecific(currentThreadKey, th);
  //}

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  if(debugConn)
    debug_run(debugConn, info_addr);

  pthread_exit(th);
  return NULL;
}



supr_thread_t *startDebugThread(int port, const char * info_addr)
{

  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, (char*) info_addr, &sem, &sth};
  int rc = pthread_create(&thread, NULL, debug_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);


  return sth;
}

#define SHM_DIR "/dev/shm"

SEXP shm_operations(SEXP args){

    DIR *dir = opendir(SHM_DIR);
    if(!dir) {
      fprintf(stderr, "Error in opendir(%s), %s\n", SHM_DIR, strerror(errno));
      return R_NilValue;
    }

    struct dirent *dp;

    size_t n = strlen(shm_prefix);
    int len = 0;
    while((dp = readdir(dir))){
      if(strncmp(dp->d_name, shm_prefix, n)==0) len++;
    }
    closedir(dir);

    dir = opendir(SHM_DIR);
    // list
    //if(TYEPOF(args)==NILSXP) ...
    SEXP names = PROTECT(allocVector(STRSXP, len));
    len = 0;
    while((dp = readdir(dir))){
      if(strncmp(dp->d_name, shm_prefix, n)==0) 
        SET_STRING_ELT(names, len++, mkChar(dp->d_name));
    }
    closedir(dir);
    UNPROTECT(1);

  return names;
}

SEXP Taskrunner_messages()
{
  int job_id = tr_cntxt.job_id;
  if(job_id<0) return R_NilValue;
  int tr_id =  tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;
  if(io == NULL) return R_NilValue;

  int args[] = {TR_GET_MSG, job_id, tr_id, getpid(), gettid()};
  shm_io_write(io, io->out, args, sizeof(args));

  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  SEXP val = SO_toRObject(so, size);
  free(so);

  return val;
}

// receive one message
SEXP Taskrunner_recv(SEXP S_timeout)
{
  int job_id = tr_cntxt.job_id;
  if(job_id<0) return R_NilValue;
  int tr_id =  tr_cntxt.tr_id;
  shm_io_info_t *io = tr_cntxt.io;
  if(io == NULL) return R_NilValue;

  int args[] = {TR_RECV_MSG, job_id, tr_id, getpid(), gettid(), 0, 0};
  double timeout = asReal(S_timeout);
  if(Supr_options.verbose) {
	  char msg[256];
	  sprintf(msg, "timeout: %f", timeout);
	  verbose_info(msg);
  }
  memcpy(args+5, &timeout, sizeof(double)); // sizeof(double) = 2*sizeof(int)
  shm_io_write(io, io->out, args, sizeof(args));

  /*
  size_t size;
  so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
  SEXP val = SO_toRObject(so, size);
  free(so);
  */

  size_t size;
  void *ptr = shm_io_read(io, io->in, &size, NULL);
  if(size == sizeof(int) && ((int*)ptr)[0] == -1)
	  return R_NilValue;

  int len = (int) size;
  SEXP x = PROTECT(allocVector(RAWSXP, len));
  memcpy(RAW(x), ptr, len);
  Rboolean success = R_ToplevelExec(Supr_unserialize1, &x);
  PROTECT(x);

  if(success)
	  return x; // return NULL after timeout?
  else 
	  error(_("%s"), R_curErrorBuf());
}

static supr_thread_t *pthread_wait_interrupt_thread = NULL;

void  pthread_wait_interrupt_igaction(int sig, siginfo_t *ip, void *context)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  if(cth != pthread_wait_interrupt_thread){
    pthread_kill(pthread_wait_interrupt_thread->ptid, sig);
    return;
  }

  if(cth->fun) cth->fun(cth->data);
  cth->data = PTHREAD_INTERRUPTED;
  
}

void pthread_wait_interrupt_setEnabled(int val)
{
  if(val) {
    pthread_wait_interrupt_thread = SUPR_CURRENT_THREAD();
    struct sigaction sa;
    sa.sa_sigaction = pthread_wait_interrupt_igaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, NULL);
  } else {
    sigaction(SIGINT, &R_oldactInt, NULL);
    pthread_wait_interrupt_thread = NULL;
  }
}

void Cluster_recv_C(void *data){
  SEXP arg = (SEXP) data;
  SEXP S_timeout = PROTECT(CAR(arg));
  SEXP val = R_NilValue;

  void *msg = NULL;
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  pthread_mutex_lock(messages->mutex);
    if(vectorSize(messages)){
      msg = vectorRemove(messages, 0);
    } else {
      messages_cond = &cth->cond;

      cth->fun = (void (*)(void*)) pthread_cond_signal;
      cth->data = messages_cond;
      pthread_wait_interrupt_setEnabled(TRUE);

      double timeout = asReal(S_timeout);
      if(timeout > 0){
        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
        timeout += save_time;
        wait.tv_sec = (long) floor(timeout);
        wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));
        int rc = pthread_cond_timedwait(messages_cond, messages->mutex, &wait);
      } else {
	      // setInterruptable ...
        int rc = pthread_cond_wait(messages_cond, messages->mutex);
      }
      
      pthread_wait_interrupt_setEnabled(FALSE);

      messages_cond = NULL;
      if(vectorSize(messages))
        msg = vectorRemove(messages, 0);
    }
  pthread_mutex_unlock(messages->mutex);

  cth->fun = NULL;
  if(cth->data == PTHREAD_INTERRUPTED){
    cth->data = NULL;
    kill(getpid(), SIGINT);
  } else {
    cth->data = NULL;
  }

  if(msg){
    int *header = (int*) msg;
    int len_addr = header[1];
    int len_raw = header[2];
    if(len_addr == 0 && len_raw==0){
      free(msg);
    } else {
      char *addr = strdup(msg+sizeof(int)*3);
      SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
      memcpy(RAW(raw), msg+sizeof(int)*3+len_addr, len_raw);
      //fprintf(stderr, "addr: %s, len_raw: %d\n", addr, len_raw);
      free(msg);

      SEXP call = PROTECT(LCONS(install("unserialize"),CONS(raw, R_NilValue)));
      val = eval(call, R_BaseEnv);
      UNPROTECT(2);
    }
  }
  UNPROTECT(1);

  SETCAR(arg, val);
}

void Cluster_messages_C(void *data){

  SEXP val = PROTECT(CONS(R_NilValue, R_NilValue));
  *((SEXP*) data) = val;

  while(vectorSize(messages)){
    void *msg = vectorRemove(messages, 0);
    int *header = (int*) msg;
    int len_addr = header[1];
    int len_raw = header[2];
   
    if(len_addr == 0 && len_raw == 0){
      free(msg);
      SETCDR(val, CONS(R_NilValue, R_NilValue));
      val = CDR(val);
    } else {
      char *addr = strdup(msg+sizeof(int)*3);
      SEXP raw = PROTECT(allocVector(RAWSXP, len_raw));
      memcpy(RAW(raw), msg+sizeof(int)*3+len_addr, len_raw);
      //fprintf(stderr, "addr: %s, len_raw: %d\n", addr, len_raw);
      free(msg);

      SEXP call = PROTECT(LCONS(install("unserialize"),CONS(raw, R_NilValue)));
      SEXP v = eval(call, R_BaseEnv);

      SETCDR(val, CONS(v, R_NilValue));
      val = CDR(val);
      SET_TAG(val, install(addr));
      UNPROTECT(2);
    }
  }

  UNPROTECT(1);
}

SEXP (*__cluster_messages_ptr__)() = NULL;

SEXP Cluster_messages(){

  if(__cluster_messages_ptr__)
	  return __cluster_messages_ptr__();

  SEXP retval;
  Rboolean success;
  BEGIN_R_EVAL();
    pthread_mutex_lock(messages->mutex);
    success = R_ToplevelExec(Cluster_messages_C, &retval);
    pthread_mutex_unlock(messages->mutex);
  END_R_EVAL();
  if(success)
    return CDR(retval);
  else 
    error(_("%s"), R_curErrorBuf());
}

supr_socket_conn_t *Cluster_findMsgConn(const char *to)
{

  // direct connection
  if(to && strcmp(to, "user")==0  && info_sc) {
    return info_sc;
  }

  if(msg_sc) {
    return msg_sc;
  } else if(parent_sc) {
    return parent_sc;
  } else if(info_sc) {
    return info_sc;
  } else return NULL;
}

SEXP Cluster_info(SEXP S_msg)
{
  const char *msg = CHAR(asChar(S_msg));
  //fprintf(stderr, "msg: \"%s\"\n", msg);
  char *s = strdup(msg);
  {
    char *t = s;
    while(*t){
      if(!isprint(*t)){
	fprintf(stderr, "msg has non-printable characters:\n \"%s\"\n", msg);
      }
      t++;
    }
  }
  basic_info(s);
  free(s);
  return R_NilValue;
}

SEXP Cluster_send(SEXP S_msg, SEXP S_addr)
{ // FIXME

  if(TYPEOF(S_addr) != STRSXP) error(_("invalid argument"));

  /*
  supr_socket_conn_t *sc = Cluster_findMsgConn(CHAR(asChar(S_addr)));

  int fd = -1;
  if(!sc) {
  // shm_io for taskrunners ... TODO
    error(_("cannot find message connection"));
  } else
    fd = sc->fd;

  */
  int cmd = CLUSTER_MSG_SEND;
  int len = 0;
  void *bytes = NULL;

  const char *addr = NULL;
  BEGIN_R_EVAL();
    //if(TYPEOF(S_addr) == STRSXP){
      addr = CHAR(asChar(S_addr));
      if(!addr) error(_("invalid address"));
    //} // ...
  //END_R_EVAL();

  //BEGIN_R_EVAL();
    PrintValue(S_msg);

    SEXP call = PROTECT(LCONS(install("serialize"),
			  CONS(S_msg, CONS(R_NilValue, R_NilValue))));
    SEXP raw = eval(call, R_BaseEnv);
    // int (cmd), int (addr_len+1), addr_len+1, int(LENGTH(raw)), LENGTH(raw) 
    //fprintf(stderr, "LENGTH(raw): %d\n", LENGTH(raw));
    int len_addr = strlen(addr)+1;
    len = 3*sizeof(int) + len_addr + LENGTH(raw);
    bytes = malloc(len);
    ((int*) bytes)[0] = cmd; 
    ((int*) bytes)[1] = len_addr;
    ((int*) bytes)[2] = LENGTH(raw); // len_raw
    memcpy(bytes + 3*sizeof(int), addr, len_addr);
    memcpy(bytes + 3*sizeof(int) + len_addr, RAW(raw), LENGTH(raw));

  END_R_EVAL();

  if(tr_cntxt.io){// for taskrunners
    shm_io_info_t *io = tr_cntxt.io;
    int cmd = TR_SEND_DRIVER;
    shm_io_write(io, io->out, &cmd, sizeof(int));
    shm_io_write(io, io->out, bytes, len);

    size_t size;
    so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
    SEXP val = SO_toRObject(so, size);
    free(so);
    return val;

  } else {

    supr_socket_conn_t *sc = Cluster_findMsgConn(CHAR(asChar(S_addr)));
    int fd = -1;
    if(!sc) { // shm_io for taskrunners ... TODO
      error(_("cannot find message connection"));
    } else
      fd = sc->fd;



    int flags = fcntl(fd, F_GETFL);
    if(flags & O_NONBLOCK){
      fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
    }

    ssize_t size = write(sc->fd, bytes, len);
    free(bytes);

    if(size != len)
      error(_("wrote %ld bytes"), size);
    if(size == -1)
      error(_("%s"), strerror(errno));

    int rc;
    size = read(sc->fd, &rc, sizeof(int));

    if(size == sizeof(int))
      return ScalarInteger(rc);
    else if(size == -1)
      error(_("%s"), strerror(errno));
    else
      error(_("TODO: %s:%d"), __FILE__, __LINE__);
  }
}

SEXP (*__cluster_recv_ptr__)(SEXP timeout) = NULL;

SEXP Cluster_recv(SEXP timeout){

  if(__cluster_recv_ptr__)
    return __cluster_recv_ptr__(timeout);

  SEXP retval = PROTECT(CONS(timeout, R_NilValue));
  Rboolean success;
  BEGIN_R_EVAL();
    success = R_ToplevelExec(Cluster_recv_C, retval);
  END_R_EVAL();
  UNPROTECT(1);
  R_CheckUserInterrupt();
  if(success)
    return CAR(retval);
  else 
    error(_("%s"), R_curErrorBuf());
}

// ignore S_addr for now...
SEXP Cluster_broadcast(SEXP S_list, SEXP S_addr)
{
  if(tr_cntxt.io){ // taskrunners
    SEXP x = S_list;
    Rboolean success = R_ToplevelExec(Supr_serialize1, &x);
    if(success){
      PROTECT(x);
      shm_io_info_t *io = tr_cntxt.io;
      int cmd = TR_SEND_DRIVER;
      shm_io_write(io, io->out, &cmd, sizeof(int));

      void *ptr = malloc(3*sizeof(int)+LENGTH(x));
      int *hd = (int*) ptr;
      hd[0] = CLUSTER_MSG_BROADCAST;
      hd[1] = tr_cntxt.job_id;
      hd[2] = LENGTH(x);
      memcpy(ptr + 3*sizeof(int), RAW(x), LENGTH(x)); // use so_t instead?
      shm_io_write(io, io->out, ptr, 3*sizeof(int) + LENGTH(x));

      size_t size;
      so_t *so = (so_t*) shm_io_read(io, io->in, &size, NULL);
      SEXP val = SO_toRObject(so, size);
      free(so);
      UNPROTECT(1);
      return val;
    } else {
      error(_("%s"), R_curErrorBuf());
    }
  } else if(strcmp(proc_cmd, "R")==0){ // user
    supr_socket_conn_t *sc = NULL;
    SEXP driver = findVar(install("driver"), SuprContextEnv);
    int fd = -1;
    if(driver != R_UnboundValue){
        SEXP scPtr = getAttrib(driver, install("conn"));
        sc = (supr_socket_conn_t *) R_ExternalPtrAddr(scPtr);
	if(sc) fd=sc->fd;
    }
    if(fd == -1) error(_("cannot find driver connection"));

    SEXP x = S_list;
    Rboolean success = R_ToplevelExec(Supr_serialize1, &x);
    PROTECT(x);

    int job_id = 0;
    SEXP S_job = findVar(install("job"), SuprJobEnv); 
    if(S_job != R_UnboundValue)
      job_id = asInteger(S_job);
    //basic_info("job_id: %d", job_id);

    void *ptr = malloc(3*sizeof(int)+LENGTH(x));
    int *hd = (int*) ptr;
    hd[0] = CLUSTER_MSG_BROADCAST;
    hd[1] = job_id;
    hd[2] = LENGTH(x);
    memcpy(ptr + 3*sizeof(int), RAW(x), LENGTH(x)); // use so_t instead?

    int cmd = CLUSTER_BYTE_MSG;
    write(fd, &cmd, sizeof(int));
    write(fd, ptr, 3*sizeof(int)+LENGTH(x));
    int rc;
    read(fd, &rc, sizeof(int));
    free(ptr);
    UNPROTECT(1);
    return ScalarInteger(rc);
  } else if(parent_sc){ // TODO
    supr_socket_conn_t *sc = parent_sc;
    SEXP x = S_list;
    Rboolean success = R_ToplevelExec(Supr_serialize1, &x);
    PROTECT(x);

    void *ptr = malloc(3*sizeof(int)+LENGTH(x));
    int *hd = (int*) ptr;
    hd[0] = CLUSTER_MSG_BROADCAST;
    hd[1] = 0; // to driver?
    hd[2] = LENGTH(x);
    memcpy(ptr + 3*sizeof(int), RAW(x), LENGTH(x)); // use so_t instead?

    write(sc->fd, ptr, 3*sizeof(int)+LENGTH(x));
    int rc;
    read(sc->fd, &rc, sizeof(int));
    free(ptr);
    UNPROTECT(1);
    return ScalarInteger(rc);
  } else {
	  error(_("No parent connection is available"));
  }
  return R_NilValue;
}

/*
void __pthread_mutex_unlock(void *data)
{
  basic_info(R_curErrorBuf());
  pthread_mutex_unlock((pthread_mutex_t*)data);
}
*/

SEXP Cluster_broadcasted(SEXP S_new, SEXP S_timeout)
{
  if(tr_cntxt.io){
    //shm_io_info_t *io = tr_cntxt.io;
    //int job_id = tr_cntxt.job_id;
    if(!asLogical(S_new)) return SuprBroadcastedEnv;

    broadcast_lock_t *bc = tr_cntxt.bc_sync;

    ssize_t size = 9;
    void *ptr = NULL;

    //int oldcancelstate;
    //pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);

    int destroy = FALSE;
    pthread_rwlock_rdlock(&bc->rwlock);

    //RCNTXT cntxt;
    //begincontext(&cntxt, CTXT_CCODE, R_NilValue, R_BaseEnv, R_BaseEnv, R_NilValue, R_NilValue);
      //cntxt.cend = &__pthread_mutex_unlock;
      //cntxt.cenddata = &bc->mutex;

      if(tr_cntxt.bc_id == bc->bc_id) {

        pthread_rwlock_unlock(&bc->rwlock);

	double timeout = asReal(S_timeout);
	if(timeout < 0) timeout = 0;

        pthread_mutex_lock(&bc->mutex);
	  if(bc->destroy){
            pthread_mutex_unlock(&bc->mutex);
	    error(_("job cancelled"));
	    //basic_info("sleep(2*300)");
	    //sleep(600);
	  }
	  if(timeout == 0)
            pthread_cond_wait(&bc->cond, &bc->mutex);
	  else {
            struct timespec wait;
            clock_gettime(CLOCK_REALTIME, &wait);
            double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
            timeout += save_time;

            wait.tv_sec = (long) floor(timeout);
            wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));

	    int rc = pthread_cond_timedwait(&bc->cond, &bc->mutex, &wait);
	    if(rc) warning(_("pthread_cond_timedwait: %d"), rc);
	    destroy = bc->destroy;
	  }
        pthread_mutex_unlock(&bc->mutex);

	if(destroy){ // FIXME
	    error(_("job cancelled"));
	    //basic_info("sleep(600)");
	    //sleep(600);
	}

        pthread_rwlock_rdlock(&bc->rwlock);

      }

      if(tr_cntxt.bc_id != bc->bc_id) //char *shm_name = bc->shm_name;
        ptr = Supr_shm_open(bc->shm_name, &size);



       if(ptr){
          Rboolean success;
          int len = ((int*)ptr)[2];
          SEXP x = PROTECT(allocVector(RAWSXP, len));
          memcpy(RAW(x), ptr + 3*sizeof(int), len);
          success = R_ToplevelExec(Supr_unserialize1, &x);
          PROTECT(x);

          if(success && TYPEOF(x) == VECSXP){
            SEXP names = getAttrib(x, R_NamesSymbol);
            if(TYPEOF(names) == STRSXP){

              for(int i=0; i<LENGTH(x); i++) 
                defineVar(install(CHAR(STRING_ELT(names, i))),
                             VECTOR_ELT(x, i), SuprBroadcastedEnv);

              tr_cntxt.bc_id = bc->bc_id;
	      //basic_info("broadcastedEnv is updated!");
            }
          } else {
         // error_info(...);
          }
          UNPROTECT(2);
          munmap(ptr, size);
        }
    //endcontext(&cntxt);
    pthread_rwlock_unlock(&bc->rwlock);
  } else {
    error(_("Implemented only for taskrunners"));
  }

  return SuprBroadcastedEnv;
}

//
//Rboolean success = R_ToplevelExec(void (*fun)(void *), void *data);

void Supr_serialize1(void *data)
{
  SEXP x = (SEXP) ((void **)data)[0];
  SEXP call = PROTECT(LCONS(install("serialize"),
                              CONS(x, CONS(R_NilValue, R_NilValue))));
  SEXP raw = eval(call, R_BaseEnv);
  UNPROTECT(1);
  ((void **)data)[0] = raw;
}

void Supr_unserialize1(void *data)
{
  SEXP raw = (SEXP) ((void **)data)[0];
  SEXP call = PROTECT(LCONS(install("unserialize"),
                              CONS(raw, R_NilValue)));
  SEXP val = eval(call, R_BaseEnv);
  UNPROTECT(1);
  ((void **)data)[0] = val;
}

SEXP (*cluster_timeout_ptr)() = NULL;

SEXP Cluster_timeout()
{
  if(cluster_timeout_ptr)
	  return cluster_timeout_ptr();
  else 
	  return ScalarReal(0.0);
}


// test socket block read and write
/*
SEXP Cluster_test(SEXP arg){
  supr_socket_conn_t *sc = socketOpen1("liu1.stat.purdue.edu:7203");
  if(!sc) error(_("cannot open 'liu1.stat.purdue.edu:7203'"));
  int cmd = CLUSTER_TEST;  


  write(sc->fd, &cmd, sizeof(int));
  //ssize_t size = DFLT_SO_RCVBUF;
  //DFLT_NONBLOCK
  fprintf(stderr, "DFLT_NONBLOCK: %d\n", DFLT_NONBLOCK);
  fprintf(stderr, "DFLT_SO_RCVBUF: %d\n", DFLT_SO_RCVBUF);
  fprintf(stderr, "DFLT_SO_SNDBUF: %d\n", DFLT_SO_SNDBUF);

#ifdef write
#pragma message("\033[0;31mwrite is defined\033[0m\n")
#pragma message "1205. value of write(x, y, z) = " VALUE(write(x, y, z))
#endif
#ifdef read
#pragma message("\033[0;31mread is defined\033[0m\n")
#pragma message "1205. value of read(x, y, z) = " VALUE(read(x, y, z))
#endif

  ssize_t size = 2*DFLT_SO_SNDBUF;
  //ssize_t size = 2*DFLT_SO_RCVBUF;
  fprintf(stderr, "DFLT_SO_RCVBUF: %d, size = 2*DFLT_SO_RCVBUF: %ld\n",
		  DFLT_SO_RCVBUF, size);

  ssize_t n = write(sc->fd, &size, sizeof(ssize_t));
  fprintf(stderr, "wrote: %ld/%ld\n", n, sizeof(ssize_t));

  void *ptr = malloc(size);
  n = write(sc->fd, ptr, size);
  fprintf(stderr, "wrote: %ld/%ld\n", n, size);

  n = read(sc->fd, &size, sizeof(ssize_t));
  fprintf(stderr, "read: %ld/%ld\n", n, sizeof(ssize_t));

  if(n == -1){
    fprintf(stderr, "[%d] Error: %s\n", __LINE__, strerror(errno));
  } else {
    fprintf(stderr, "to receive: %ld\n", size);

    void *a = ptr;
    do {
      n = read(sc->fd, a, size);
      if(n == -1) error(_("%s"), strerror(errno));
      fprintf(stderr, "\tread: %ld/%ld\n", n, size);
      size -= n;
      a += n;
    } while(size);

    n = read(sc->fd, &size, sizeof(ssize_t));
    if(n==-1)
      fprintf(stderr, "[%d] Error: %s\n", __LINE__, strerror(errno));
    else
      fprintf(stderr, "sent: %ld\n", size);
  }


  //
  //[x] BLOCK: 'write' through for the specified size?
  //      : 'read' may still need to read multiple times, each with size > 0 
  //
  //   It says that BLOCK is more efficient...
  //
  // How about NONBLOCK?
  //[ ] NONBLOCK: write may need to write multiple times
  //         : 'read' returns immediately,  -1, if no data.




  free(ptr);
  return ScalarReal(size-n);
}
*/


SEXP read_rso(const char *path)
{
  int fd = open(path, O_RDONLY);
  if(fd == -1) error(_("read(%s), %s"), path, strerror(errno)); 

  so_t so;
  ssize_t size = read(fd, &so, sizeof(so_t));
  if(size != sizeof(so_t)) {
    close(fd);
    error(_("read(%s), %s"), path, strerror(errno)); 
  }

  SEXP raw = PROTECT(allocVector(RAWSXP, so.size));
  size = read(fd, RAW(raw), so.size);
  if(size != so.size) {
    close(fd);
    error(_("read(%s), %s"), path, strerror(errno)); 
  }

  SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw,
                        R_NilValue)));
  SEXP val = eval(call, R_GlobalEnv);
  UNPROTECT(2);
  return val;
}








