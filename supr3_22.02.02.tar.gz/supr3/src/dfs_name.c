
//#include "supr.h"
//#include "util.h"
#include "dd.h"


#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#include <math.h>

//#ifndef malloc
#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)
//#endif

// FIXME
//#define USE_LOCALHOST


#ifndef _
#define _(x) (x)
#endif

#define msg_color "\033[0;34m"
#define ERROR_SEPARATOR ";\n"


#define RUN_AS_DAEMON_PROC
extern int   Supr_debug;
extern char *Supr_message;
static char *notify_addr = NULL;
extern char *info_addr;
static char msg[1024];

extern char *shm_prefix;
extern const char *cmd;
extern SEXP SuprEnv;
extern SEXP SuprJobEnv;

extern char *X11_str;

//extern double supr_floor(double x);

extern pthread_mutex_t Supr_syncMutex; // = PTHREAD_MUTEX_INITIALIZER;
extern pthread_cond_t  Supr_syncCond; //  = PTHREAD_COND_INITIALIZER;
extern void *Supr_syncObject;
static int isWaitingForDatanode = FALSE;

void  Namenode_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context);

extern vector_t *cleanups;
extern void doCleanups();
extern void addCleanups(void (*run)(void *), void *data);



//#define  DEBUG_VECTOR
#ifdef   DEBUG_VECTOR


int __vectorDestroy(vector_t *vec, const char* func, const char *file, int line) {
  printf("[%s] %s (%s:%d): [vec=%p, vec->elements=%p]\n", __func__,
		  func, file, line, vec, vec->elements);
 return vectorDestroy(vec);
}

void *__vectorAdd(vector_t *vec, void *elem, const char* func, const char *file, int line) {
  printf("[%s] %s (%s:%d): [vec=%p, vec->elements=%p]\n", __func__,
		  func, file, line, vec, vec->elements);
  return vectorAdd(vec, elem);
}

vector_t *__newVector(int sync, const char* func, const char *file, int line) {
	vector_t *vec = newVector(sync);
  printf("[%s] %s (%s:%d): [vec=%p, vec->elements=%p]\n", __func__,
		  func, file, line, vec, vec->elements);
  return vec;
}

#define vectorDestroy(v) __vectorDestroy((v), __func__, __FILE__, __LINE__)
#define vectorAdd(v, e) __vectorAdd((v), (e), __func__, __FILE__, __LINE__)
#define newVector(s) __newVector((s), __func__, __FILE__, __LINE__)
#endif

//pthread_key_t stacktraceKey;
//pthread_key_t taskrunnerThreadKey;

extern char *Supr_sysHome;
extern char *Supr_usrHome;
extern char *Supr_dfsHome;

typedef struct DT_thread_task_struct {
  void (*fun)(void *);
  void *data;
} DT_thread_task_t;

vector_t *DT_thread_tasks = NULL;
#define gettid() ((int)syscall(SYS_gettid))


//extern FILE *stdlog;
//extern int Supr_stdlog_fileno;
//extern char *Supr_stdlog_filename;

int stdout_fileno_save = -1;
int stderr_fileno_save = -1;

void __printf__(const char *format, ...)
{
        static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  va_list ap;
  va_start(ap, format);
  pthread_mutex_lock(&mutex);

  /*if(stdlog) {
    vfprintf(stdlog, format, ap);
    fflush(stdlog);
  } else {
  */
    vprintf(format, ap);
    fflush(stdout);
  //}

  pthread_mutex_unlock(&mutex);
}

#define printf __printf__("(%s:%d) ", __FILE__, __LINE__); __printf__



extern supr_socket_conn_t *info_sc; // = NULL;
supr_socket_conn_t *socketServerConn = NULL;

extern char *connTypeToStr(int type);
char *index_html_header = NULL;
char *html_dir = NULL;
extern void Html_sendError(supr_socket_conn_t *conn, const char *file_name);

extern char *SUPR_HOMEUSR;
extern char *SUPR_HOMESYS;
extern void suprHomeInit();

extern char *SUPR_DFS_HOMEUSR;
extern char *SUPR_DFS_HOMESYS;
extern void suprDFSHomeInit();

extern char *Exec_timestamp(char *buf, size_t buf_size);

size_t __read__(int fd, void *buf, size_t size);


pthread_key_t interruptThreadKey;

supr_socket_conn_t *serverConn = NULL;
supr_socket_conn_t *backendConn = NULL;

//vector_t *socket_connections = NULL;
extern vector_t *socket_connections;
//vector_t *threads = NULL;
extern vector_t *threads;

pthread_mutex_t tasks_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  tasks_cond  = PTHREAD_COND_INITIALIZER;
vector_t *tasks = NULL;

typedef struct task_struct {
  void (*run)(struct task_struct *);
  void *data;
} task_t;

task_t *newTask(void (*run)(task_t *), void *data){
  task_t *task = (task_t *) malloc(sizeof(task_t));
  task->run = run;
  task->data= data;
  return task;
}


/*


// FIXME...
typedef struct {
  //w_job_t *job;
  //shm_io_info_t *io;
  //pid_t   R_pid;
  int     isInterrupted;
  // ...
} taskrunner_env_t;

typedef struct {
  int type;
  int padding; // not used ...
  void *data;
} thread_info_t;


void C_Taskrunner_SigactionInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>> %s <<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
//  c_backtrace();

  supr_thread_t *currentThread = (supr_thread_t *)
                  pthread_getspecific(currentThreadKey);

  thread_info_t *info = (thread_info_t *) currentThread->data;

  taskrunner_env_t *env = (taskrunner_env_t *)
     pthread_getspecific(taskrunnerThreadKey);

}
*/
void removeConnection(supr_socket_conn_t *conn)
{
  close(conn->fd);
  vectorRemoveElement(socket_connections, conn);
  Supr_decref(conn);
  // connDestroy();
}

struct sigaction R_oldSegvAct;
struct sigaction R_oldIntAct;

hashtable_t *dn_locations = NULL;

int HtmlDir_check()
{ // html
    //mkDir(SUPR_HOMEUSR, "html/worker");
  if(html_dir == NULL){
      html_dir = (char*) malloc(strlen(SUPR_DFS_HOMEUSR)+strlen("/html")+1);
      sprintf(html_dir, "%s/html", SUPR_DFS_HOMEUSR);
      DIR *dir = opendir(html_dir);
      if(!dir) {
        printf("Info: making dir %s\n", html_dir);
        if(mkdir(html_dir, 0700) == -1){
          printf("Error: %s, %s\n", html_dir, strerror(errno));
          return -1;
        }
      } else {
        closedir(dir);
      }
  } else {
      html_dir = strdup(html_dir);
      DIR *dir = opendir(html_dir);
      if(!dir) {
        printf("Error: %s, %s\n", html_dir, strerror(errno));
        return -1;
      } else {
        closedir(dir);
      }
  }

  /*
  {
    char path[PATH_MAX];

    sprintf(path, "%s/%s.%d.stdout.txt", html_dir, Supr_hostname, getpid());
    FILE *fs = fopen(path, "w+");
    if(fs){
      dup2(fileno(fs), STDOUT_FILENO);
    }
    char time_buf[256];
    fprintf(stdout, "Started at %s\n", Exec_timestamp(time_buf, 256));

  }
  */

  return 0;
}

void Html_sendImage(supr_socket_conn_t *conn, const char *file_name);

int system_exit(int n);

extern supr_thread_t *main_thread;

/* ???
typedef struct task_struct {
  void *data;
  void (*run)(struct task_struct *);
} task_t;

task_t *newTask(void (*run)(task_t *), void *data){
  task_t *task = (task_t *) malloc(sizeof(task_t));
  task->run = run;
  task->data= data;
  return task;
}
*/

extern char *X11_str;

//make the main_thread to shutdown?
void handleShutdown(supr_socket_conn_t *conn)
{
  Supr_curStrError = (char*) __func__;
  // 1. Make sure no thread is using the shared info_sc
  pthread_mutex_lock(&Supr_syncMutex);
    if(info_sc){
      close(info_sc->fd);
      info_sc = NULL;
    }
    if(parent_sc){
      close(parent_sc->fd);
      parent_sc = NULL;
    }
  pthread_mutex_unlock(&Supr_syncMutex);

  char msg[1024];
  //Cluster_sendSimpleMessage(__func__, msg_color, DEFAULT_INFO_TYPE, 0);

  // 2. Disconnect datanode connections
  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
      int msg[] = {CLUSTER_SHUTDOWN, 0};
      ssize_t size = write(sc->fd, msg, sizeof(msg));
      int rc;
      read(sc->fd, &rc, sizeof(int));
    }
    close(sc->fd); // Supr_decref???
    free(sc);
  }

  supr_thread_t *cth = pthread_getspecific(currentThreadKey);

  pthread_mutex_lock(threads->mutex);

  for(int i=vectorSize(threads)-1; i>=0; i--){
    supr_thread_t *th = vectorElementAt(threads, i);
    if(th != cth){
      int locked = !pthread_mutex_trylock(&th->mutex);
      if(locked){
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d, state: %s)", th->tid, th->pid, state2char(th->state));
      }else {
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d)", th->tid, th->pid);
      }
      fprintf(stderr, "%s\n", msg);

      int rc = pthread_cancel(th->ptid);
      if(locked){
        pthread_mutex_unlock(&th->mutex);
      }
    }
  }

  pthread_mutex_unlock(threads->mutex); // FIXME
  int rc = pthread_cancel(cth->ptid);

  //system_exit(CLUSTER_SHUTDOWN);
}

void handleHTTP_POST(supr_socket_conn_t *conn)
{
  int fd = conn->fd;

  size_t buf_size = 4096;
  unsigned char buf[buf_size+1];
  ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
  len = __read__(fd, buf, len);
  buf[len++] = 0;
  fprintf(stderr, "\033[0;36m[%s://%s:%d]\n\"%s\"\033[0m\n",
            connTypeToStr(conn->type), conn->host, conn->port, buf);

  char *file_name = strstr(buf, " /")+2;
  char *str = strstr(file_name, " HTTP/");
  *str = 0; str++;

  if(strcmp(file_name, "shutdown.R")==0){
    handleShutdown(conn);
    return; // not reached
  }

  char *ct = NULL;
  FILE *stdlog = NULL;
  if(stdlog){
    fprintf(stdlog, "Webclient: //%s\n", conn->host);
    fprintf(stdlog, "file_name/action: //%s\n", file_name);
    str = strstr(str, "Content-Type:");
    if(str){ // make tokens ...
      str += strlen("Content-Type:");
      while(*str == ' ') str++;
      ct = str;
      str = strstr(str, "\r\n");
      *str = 0;
      str += 2;
      fprintf(stdlog, "Content-Type: %s\n", ct);
    }

    if(ct && strcmp(ct, "application/x-www-form-urlencoded")==0
		    && (str=strstr(str, "\r\n\r\n"))) { // TODO...
      str += 4;
      fprintf(stdlog, "value: %s\n", str);
      char _buf[strlen(str)+1];
      int n = 0;
      for(int i=0; i<strlen(str); i++){
        if(str[i] == '%'){
          _buf[n++] =  strtol(str+i+1, NULL, 16);
	  i+=2;
	} else {
          _buf[n++] = str[i];
	}
      }
      _buf[n++] = 0;
      fprintf(stdlog, "value: %s\n", _buf);
      fflush(stdlog);
    }
  }

  /*
  char protocol[] = "HTTP/1.1 202 Accepted\r\n";
  char servName[] = "Server:SupR2\r\n\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  //char cntType[256];

  send(fd, protocol, strlen(protocol), 0);
  send(fd, servName, strlen(servName), 0);
  */

  Html_sendImage(conn, file_name);

  //Html_sendError(conn, file_name);
}

void Html_sendImage(supr_socket_conn_t *conn, const char *file_name)
{
  printf("file_name: %s\n", file_name);
  fflush(stdout);

  file_name = "/home/outlier/u43/chuanhai/supr/Rlogo.png";
  int file_fd = open(file_name, O_RDONLY);
  struct stat sb;
  if(file_fd == -1 || fstat(file_fd, &sb) == -1){
    Html_sendError(conn, file_name);
    return;
  }

  char protocol[] = "HTTP/1.1 200 OK\r\n";
  char servName[] = "Server:SupR2\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  char cntType[256];

  sprintf(cntLen, "Content-length: %ld\r\n", sb.st_size);
  char buf[sb.st_size];
  read(file_fd, buf, sb.st_size);
  close(file_fd);

  //char *ct = "image/webp";
  char *ct = "image/png";
  snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n",
		  ct);
#define TEST_SIGPIPE_HANDLER
#ifdef  TEST_SIGPIPE_HANDLER

  struct sigaction savePipeAct;
  struct sigaction sa;
  sa.sa_sigaction = Namenode_SigactionSIGPIPE;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
  sigaction(SIGPIPE, &sa, &savePipeAct);

  signal(SIGPIPE, SIG_IGN);

  int fd = conn->fd;
  ssize_t size;
  if(  (size = send(fd, protocol, strlen(protocol), 0)) != strlen(protocol)
     ||(size = send(fd, servName, strlen(servName), 0)) != strlen(servName)
     ||(size = send(fd, cntLen, strlen(cntLen), 0)) != strlen(cntLen)
     ||(size = send(fd, cntType, strlen(cntType), 0)) != strlen(cntType)
     ||(size = send(fd, buf, sizeof(buf), 0)) != sizeof(buf))
  { 
    fprintf(stderr, "Error: %s, %s\n", __func__, strerror(errno));
    //close(conn->fd);
    //vectorRemoveElement(socket_connections, conn);
	// connDestroy();
    removeConnection(conn);
  }

  sigaction(SIGPIPE, &savePipeAct, NULL);


#else

  int fd = conn->fd;
  send(fd, protocol, strlen(protocol), 0);
  send(fd, servName, strlen(servName), 0);
  send(fd, cntLen, strlen(cntLen), 0);
  send(fd, cntType, strlen(cntType), 0);

  send(fd, buf, sizeof(buf), 0);
#endif
}


// href="^datadir(/name)*.html"
void Html_sendFile(supr_socket_conn_t *conn, const char *file_name);

// dirpath: starting from dfs_name's cwd
int __listFiles__(FILE *fs, char *parent_dir, char *htmlpath, char *file)
{
	/*
    fprintf(fs, "<p>parent_dir: %s,<br> htmlpath: %s,<br> file: %s</p>\n",
		    parent_dir, htmlpath, file);
		    */

    char *dirname = file;
    while(*file != '/') file++;
    *file = 0;
    file ++;

    char thisdir[strlen(parent_dir)+strlen(dirname)+2];
    sprintf(thisdir, "%s/%s", parent_dir, dirname);

    //printf("thisdir: %s\n", thisdir);
    //printf("dirname: %s\n", dirname);

    char dirpath[PATH_MAX];
    memcpy(dirpath, htmlpath, strlen(htmlpath)+1);

    sprintf(dirpath + strlen(dirpath), "%s/", dirname);

    DIR *dir = opendir(thisdir);
    if(!dir) {
      fprintf(fs, "<p>Error: %s, %s</p>\n", thisdir, strerror(errno));
      //return -1;
      return 0;
    }

    fprintf(fs, "<UL>\n");

    char next_dirname[strlen(file)+1];
    memcpy(next_dirname, file, strlen(file)+1);
    char *s = next_dirname;
    while(*s && *s != '/') s++;
    *s = 0;

    /*
    fprintf(fs, "<p>parent_dir: %s,<br> htmlpath: %s,<br> file: %s,<br>"
		   " dirname: %s,<br> next_dirname: %s,<br>"
		   " dirpath: %s,</p>\n",
		    parent_dir, htmlpath, file, dirname, next_dirname,
		    dirpath);
		    */

    struct dirent *dp;
    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0
         || strncmp(dp->d_name, ".nfs", 4)==0)
              continue;
      if(strcmp(dp->d_name, next_dirname)==0) {
        //fprintf(fs, "<LI><font color=#FF0000>%s</font></LI>\n", dp->d_name);
        fprintf(fs, "<LI><a href=\"%s%s.html\">%s</a></LI>\n", dirpath,
		       	dp->d_name, dp->d_name);
	//char _dirpath[PATH_MAX];
	//memcpy(_dirpath, dirpath, strlen(dirpath)+1);
        __listFiles__(fs, thisdir, dirpath, file);
      } else if(dp->d_type == DT_DIR) {
        fprintf(fs, "<LI><a href=\"%s%s.html\">%s</a></LI>\n", dirpath,
		       	dp->d_name, dp->d_name);
      } else {
        fprintf(fs, "<LI>%s</LI>\n", dp->d_name);
      }
    }
    fprintf(fs, "</UL>\n");

    return 0;
}

void Html_sendFileList(supr_socket_conn_t *conn, const char *file_name)
{
  char template[128];
  sprintf(template, "/tmp/supr_dfs_XXXXXX.%s", "html");
  int fd = mkstemps(template, strlen("html")+1);
  FILE *fs = fopen(template, "w+");
  fprintf(fs, "<!DOCTYPE html>\n<HEAD>\n<TITLE>SupR2</TITLE>\n"
	"  <META charset=\"utf-8\">\n</HEAD>\n<BODY>\n");

  fprintf(fs, "<h4>datadir/</h4>\n");
  //fprintf(stderr, "TESTING: %s\n", file_name);

  char thisdir[PATH_MAX];
  char file[strlen(file_name)+1];
  memcpy(file, file_name, strlen(file_name)+1);
  char *s = file + strlen(file)-1;
  while(s != file && *s != '.') s--;
  *s = '/';
  s++; *s=0;

  getcwd(thisdir, PATH_MAX);

  char htmlpath[PATH_MAX];
  //htmlpath[0] = 0;
  htmlpath[0] = '/';
  htmlpath[1] = 0;

  //fprintf(stderr, "TESTING: %s\n", file_name);
  int rc = __listFiles__(fs, thisdir, htmlpath, file); 


  fprintf(fs, "</BODY>\n");
  fclose(fs);
  close(fd);

  
  if(rc == -1)
    Html_sendError(conn, file_name);
  else 
    Html_sendFile(conn, template);

  unlink(template);
  return;

  /*
  if(strcmp(file_name, "data.html")==0){
    char path[PATH_MAX];
    getcwd(path, PATH_MAX);
    sprintf(path + strlen(path), "/%s", "data");
    DIR *dir = opendir(path);
    if(!dir){
      Html_sendError(conn, file_name);
      return;
    }
    struct dirent *dp;
    size_t content_len = 0;
    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0
         || strncmp(dp->d_name, ".nfs", 4)==0)
              continue;
      content_len += strlen(dp->d_name)+1;
    }

    char content[content_len];
    content[0] = 0;
    rewinddir(dir);
    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0
         || strncmp(dp->d_name, ".nfs", 4)==0)
              continue;
      sprintf(content + strlen(content), "%s\n", dp->d_name);
    }

    closedir(dir);

    char protocol[] = "HTTP/1.1 200 OK\r\n";
    char servName[] = "Server:SupR2\r\n";
    char cntLen[256]; // = "Content-length:2048\r\n";
    char cntType[256];

    sprintf(cntLen, "Content-length: %ld\r\n", content_len);
    char *ct = "text/plain";
    snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n",
		  ct);

    int fd = conn->fd;
    send(fd, protocol, strlen(protocol), 0);
    send(fd, servName, strlen(servName), 0);
    send(fd, cntLen, strlen(cntLen), 0);
    send(fd, cntType, strlen(cntType), 0);

    send(fd, content, content_len, 0);
  }

  Html_sendError(conn, file_name);
  */
}

//extern void Html_sendFile(supr_socket_conn_t *conn, const char *file_name)

void Html_sendFile(supr_socket_conn_t *conn, const char *file_name)
{
  //fprintf(stderr, "file_name: %s\n", file_name);
  if(strncmp(file_name, "data", strlen("data"))==0) {
    //fprintf(stderr, "OKAY? file_name: %s\n", file_name);
    Html_sendFileList(conn, file_name);
    return; 
  }

  char path[PATH_MAX];
  if(strcmp(file_name, "stdout.txt")==0 ||strcmp(file_name, "stderr.txt")==0 ){
    fprintf(stdout, "cwd: %s\n", getcwd(path, PATH_MAX));
    fflush(stdout);
    //sprintf(path, "%s/%s.%d.%s", html_dir, Supr_hostname, getpid(), file_name);
    sprintf(path, "%s", file_name);
    /*
  } else if(strcmp(file_name, "stdlog.txt")==0 && stdlog != NULL ){
    fflush(stdlog);
    sprintf(path, "%s", Supr_stdlog_filename);
    */
  //} else if(strcmp(file_name, "info.txt")==0){
  } else if(strcmp(file_name, "supr.conf")==0){
    char path[PATH_MAX];
    sprintf(path, "%s/supr.conf", Supr_usrHome);
    // Html_sendFile(conn, path, "text/plain");
  } else if(*file_name =='/' ){
    sprintf(path, "%s", file_name);
  } else { // TODO ...
    Html_sendError(conn, file_name);
    return;
  }

  //fprintf(stderr, "path: %s\n", path);

  int file_fd = open(path, O_RDONLY);
  struct stat sb;
  if(file_fd == -1 || fstat(file_fd, &sb) == -1){
    Html_sendError(conn, file_name);
    return;
  }

  char protocol[] = "HTTP/1.1 200 OK\r\n";
  char servName[] = "Server:SupR2\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  char cntType[256];

  sprintf(cntLen, "Content-length: %ld\r\n", sb.st_size);
  char buf[sb.st_size];
  read(file_fd, buf, sb.st_size);
  close(file_fd);

  //char *ct = "image/webp";
  char *ct = "text/plain";
  {
     const char *s = file_name + strlen(file_name)-1;
     while(s != file_name && *s != '.')
	     s--;
     s++;
     if(strcmp(s, "html")==0){
       ct = "text/html";
     }
  }
  
  snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n",
		  ct);

  int fd = conn->fd;
  send(fd, protocol, strlen(protocol), 0);
  send(fd, servName, strlen(servName), 0);
  send(fd, cntLen, strlen(cntLen), 0);
  send(fd, cntType, strlen(cntType), 0);

  send(fd, buf, sizeof(buf), 0);
}


void Html_sendIndexPage(supr_socket_conn_t *conn)
{
  const char *p_format = "HTTP/1.1 200 OK\r\nServer:SupR2\r\n"  
	  "Content-length: %ld\r\nContent-type:%s; charset=UTF-8\r\n\r\n";
  char *ct = "text/html";

  char buf[4096];
  sprintf(buf, "<!DOCTYPE html>\n<HEAD>\n<TITLE>SupR2</TITLE>\n"
	"  <META charset=\"utf-8\">\n</HEAD>\n");

  sprintf(buf + strlen(buf), "<h3>Namenode</h3>\n<P>\n");
  for(int i=0; i < vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    if(sc->type == DFS_NAMENODE_CONN){
      char path[PATH_MAX];
      getcwd(path, PATH_MAX);
      sprintf(buf + strlen(buf), "//%s:%d, file://%s\n<UL>",
		      sc->host, sc->port, path);
      sprintf(buf + strlen(buf),
		      "<LI><a href=\"stdout.txt\">stdout</a></LI>\n");
      sprintf(buf + strlen(buf),
		      "<LI><a href=\"stderr.txt\">stderr</a></LI>\n");
      sprintf(buf + strlen(buf),
		      "<LI><a href=\"supr.conf\">supr.conf</a></LI>\n");
      sprintf(buf + strlen(buf), "</UL>\n");
    }
  }
  sprintf(buf + strlen(buf), "</P>\n");

  sprintf(buf + strlen(buf), "<h3>Datanodes</h3>\n<OL>\n");
  //printf("nConnections: %d\n", vectorSize(socket_connections));

  for(int i=0; i < vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    //printf("sc: %s://%s:%d\n", connTypeToStr(sc->type), sc->host, sc->port);
    if(sc->type == DFS_DATANODE_CONN){
      //sprintf(buf + strlen(buf), "<LI>//%s:%d</LI>\n", sc->host, sc->port);
      //sprintf(buf + strlen(buf), "<LI><a href=\"http://%s:%d/stdlog.txt\">"
      sprintf(buf + strlen(buf), "<LI><a href=\"http://%s:%d\">"
		      "http://%s:%d</a></LI>\n",
		      sc->host, sc->port, sc->host, sc->port);
    }
  }
  //fflush(stdout);
  sprintf(buf + strlen(buf), "</OL>\n");

  {
    sprintf(buf + strlen(buf), "<h3>All Connections</h3>\n<OL>\n");

    for(int i=0; i < vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
      sprintf(buf + strlen(buf), "<LI>//%s:%d</LI>\n", sc->host, sc->port);
    }

    sprintf(buf + strlen(buf), "</OL>\n");
  }

  sprintf(buf + strlen(buf), "<h3><a href=\"data.html\">/datadir</a></h3>\n");

  sprintf(buf + strlen(buf), "</OL>\n");

  // get or post?
  // get: example: GET /action_page.php?fname=u12&lname=startWorkers%28%29 HTTP/1.1
  //char *testing = "<form action=\"/action_page.php\" method=\"get\">"
  /*
  char *testing = "<form action=\"/action_page.php\" method=\"post\">"
    "<label for=\"fname\">First name:</label>"
    "<input type=\"text\" id=\"fname\" name=\"fname\"><br><br>"
    "<label for=\"lname\">Last name:</label>"
    "<input type=\"text\" id=\"lname\" name=\"lname\"><br><br>"
    "<input type=\"submit\" value=\"Submit\">"
    "</form>";
    */
  char *shutdown = "<form action=\"/shutdown.R\" method=\"post\">"
    "<input type=\"submit\" value=\"Shutdown\">"
    "<label for=\"fname\">(</label>"
    "<input type=\"text\" id=\"fname\" name=\"fname\">"
    "<label for=\"fname\">)</label><br><br>"
    "</form>";

  sprintf(buf + strlen(buf), "%s", shutdown);
  sprintf(buf + strlen(buf), "</BODY>\n");

  char protocol[strlen(p_format)+strlen(ct)+64];
  sprintf(protocol, p_format, strlen(buf), ct);

  send(conn->fd, protocol, strlen(protocol), 0);
  send(conn->fd, buf, sizeof(buf), 0);

}

/*
void __nn_free__(void *ptr, const char *file, int line)
{
  free(ptr);
  printf("[%s] <%p> %s:%d\n", __func__, ptr, file, line);
}
*/

//#define free(ptr) __nn_free__((ptr), __FILE__, __LINE__)


//int info_fd = -1;
int info_level = 0;


int SocketConn_info(int level, const char *format, ...)
{


  if (level > info_level || !info_sc) return 0;

  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(1024);


  va_list ap;
  va_start(ap, format);

  while(TRUE) {
    sb->size = 0;
    sb->buf[0] = 0;
    int n = vsnprintf(sb->buf, sb->buf_size, format, ap);
    if( n < sb->buf_size) break;

    // destroy(sb);
    sb = newStrbuf(sb->buf_size + sb->buf_size/2);
  } 


  //SocketConn_writeString(info_sc, sb->buf);
  Cluster_sendSimpleMessage(sb->buf, "\033[0;34m", 0, 0);

  return sb->size+1;
}

extern supr_thread_t *main_thread;

pid_t Main_pid =  -1;

void rmConnLog()
{
  if(getpid() != Main_pid) return;
  char fileName[strlen(Supr_usrHome)+strlen("/dfs_name.log")+1];
  sprintf(fileName, "%s/dfs_name.log", Supr_usrHome);
  File_remove(fileName);
}

extern pid_t main_pid;

void send_ExitInfo(){
  if(getpid() != main_pid) return;

  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  basic_info(__func__);
  if(cth) basic_info(cth->name);
  else return;

  supr_socket_conn_t *sc = NULL;
  if(info_addr && (sc = trySocketOpen1(info_addr))){
    int fd = sc->fd;

    int cmd = CLUSTER_PROC_CMD;
    write(fd, &cmd, sizeof(int));
    int len = strlen(proc_cmd)+1;
    write(fd, &len, sizeof(int));
    write(fd, proc_cmd, len);
    int rc;
    read(fd, &rc, sizeof(int));

    char msg[1024];

    if(Supr_options.verbose){
    for(int i=0; threads && i<vectorSize(threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);

      // msg_header?
      cmd = CLUSTER_INFO;
      write(fd, &cmd, sizeof(int));
      unsigned char buf[8];
      snprintf(buf, 8, "%s", msg_color);
      write(fd, buf, sizeof(buf));
      int type = DEFAULT_INFO_TYPE;
      write(fd, &type, sizeof(int));
      int level = 0; // not used
      write(fd, &level, sizeof(int));

      sprintf(msg, "\033[0;33m%s:%d: %s, tid: %d, state: %s, \tname: %s\033[0m",
                    __FILE__, __LINE__, __func__,
                    th->tid, state2char(th->state), th->name);

      ssize_t len_msg = strlen(msg)+1;
      write(fd, &len_msg, sizeof(ssize_t));
      write(fd, msg, len_msg);
      read(fd, &rc, sizeof(int));

    }
    }

    cmd = CLUSTER_INFO;
    write(fd, &cmd, sizeof(int));
    unsigned char buf[8];
    snprintf(buf, 8, "%s", msg_color);
    write(fd, buf, sizeof(buf));
    int type = DEFAULT_INFO_TYPE;
    write(fd, &type, sizeof(int));
    int level = 0; // not used
    write(fd, &level, sizeof(int));

    /*
    sprintf(msg, "\033[0;35m%s:%d: %s[%s], tid: %ld, .., terminated\033[0m",
       __FILE__, __LINE__, __func__, Supr_curStrError, syscall(SYS_gettid));
       */
    sprintf(msg, "\033[0;35m%d %s[%s], ..., terminated\033[0m",
		    getpid(), __func__, Supr_curStrError);

    ssize_t len_msg = strlen(msg)+1;
    write(fd, &len_msg, sizeof(ssize_t));
    write(fd, msg, len_msg);
    read(fd, &rc, sizeof(int));

  } else {
    fprintf(stderr, "func: %s, this tid: %ld, pid: %d ..., terminated",
                    __func__,
                    syscall(SYS_gettid),  getpid());
  }

  doCleanups();
}







hashtable_t *ddEnvironment = NULL; 


supr_thread_t *timedwait_thread = NULL;
int timedwait_timeout = 1; // seconds, specified by option?
//vector_t *timedwait_events = NULL;
vector_t *timedwait_queue = NULL;


typedef struct nn_timedwait_struct {
  struct timespec time;
  void (*run)(void *);
  void (*destroy)(struct nn_timedwait_struct *);
  void *data;
} nn_timedwait_t;

//void Timedwait_notifyTimeout(void *data);

// default Timedwait_destroy
void Timedwait_destroy(nn_timedwait_t *wait)
{
  void **data = (void**) wait->data;
  free(data[1]); // message
  free(wait->data);
  free(wait);
}


void Timedwait_add(void (*run)(void *), void *data, size_t data_size,
	       	void (*destroy)(struct nn_timedwait_struct *))
{
  nn_timedwait_t *event = (nn_timedwait_t *)
          malloc(sizeof(nn_timedwait_t));
  
  clock_gettime(CLOCK_REALTIME, &event->time);
  event->time.tv_sec += timedwait_timeout;

  event->run = run;
  event->data= malloc(data_size);
  memcpy(event->data, data, data_size);
  event->destroy = destroy;

  pthread_mutex_lock(timedwait_queue->mutex);
    vectorAdd(timedwait_queue, event);
  pthread_mutex_unlock(timedwait_queue->mutex);

  pthread_mutex_lock(&timedwait_thread->mutex);
    pthread_cond_signal(&timedwait_thread->cond);
  pthread_mutex_unlock(&timedwait_thread->mutex);
}

extern SEXP R_simpleTryEval(SEXP expr, SEXP env, int *errorOccurred);
extern SEXP R_simpleTryEval4(SEXP(*func)(SEXP args), SEXP args, SEXP env,
	       	int *errorOccurred);

/*
#define BEGIN_R_EVAL()     do      {       \
  pthread_mutex_lock(&main_thread->mutex);	\
  void *dummy; 	\
  int __save_R_CStackStart__ = R_CStackStart;	\
  R_CStackStart = (unsigned long) &dummy

#define END_R_EVAL()   \
  R_CStackStart = __save_R_CStackStart__;	\
  pthread_mutex_unlock(&main_thread->mutex);	\
} while(0)
*/


extern unsigned long R_CStackStart;
extern unsigned long R_CStackLimit;
extern int R_Interactive;
extern void run_Rmainloop(void);

extern void myR_SigactionSegv(int sig, siginfo_t *ip, void *context);

/*
#define _GNU_SOURCE
#define __USE_GNU
#include <dlfcn.h>

#define print_caller_info(which)        \
do {    \
   Dl_info __info__;    \
   int __rc__ = dladdr(__builtin_return_address(which), &__info__);     \
   fprintf(stderr, "\033[0;32m[%d] fun: %s (%s:%d)\033[0m\n", getpid(), __info__.dli_sname, __FILE__, __LINE__);      \
} while (0)
*/

//extern void c_backtrace();

void c_backtrace(){
  fprintf(stderr, "deprecated %s, pid: %d\n", __func__, getpid());

  sleep(120);

  char *buf= NULL;
  Supr_debug2(getpid(), &buf);
  if(buf)
  Supr_debug = TRUE;
  Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);
  free(buf);

  /*
  print_caller_info(0);
  print_caller_info(1);
  print_caller_info(2);
  print_caller_info(3);
  */
}


static shm_io_info_t *__io__ = NULL;


extern vector_t *cleanups;
extern void doCleanups();

int system_exit(int n){
  // cleanups later...

  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
              vectorRemove(socket_connections, i);
    shutdown(sc->fd, SHUT_WR);
    close(sc->fd);
  }



  supr_thread_t *cth = currentThread();
  printf("\033[0;31m[%s] pid: %d, tid: %d, terminating ...\033[0m\n", __func__,
		  cth->pid, cth->tid);

  doCleanups();
  sleep(2);

  exit(n);
}



int isDCLInterrupted = FALSE;
int isDisconnected = FALSE;

size_t __dcl_read__(int fd, void *ptr, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /* else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(listenfd, &readfds) = %d\n", __func__,
               FD_ISSET(fd, &readfds));
      } */
    }

    int n = read(fd, ptr + len,  size - len);
    //printf("[%s] isDCLInterrupted = %d n = %d\n", __func__, isDCLInterrupted, n);
    if(isDCLInterrupted) {
//      isDCLInterrupted = FALSE;
    //  return -1;
	    // clean...???
      errorcall(R_NilValue, "interrupted");
    } else if(n == -1) {
      errorcall(R_NilValue, "SIGPIPE?");
    } else if(n == 0) {
      printf("[%s] disconnected\n", __func__);
      isDisconnected = TRUE;
      errorcall(R_NilValue, "disconnected");
    }
    //if(n == -1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  return len;
}

// testing
//extern size_t (*__read__)(int, void *, size_t);


#include <readline/readline.h>
#include <readline/history.h>

 
void  myR_SigactionDCLInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  //c_backtrace();

  //if(isDCLInterrupted) exit(1);
  fprintf(stderr, "\033[0;31m[%s] FIXME: EXIT (%s, %d)\033[0m\n", __func__,
           __FILE__, __LINE__);
//  exit(1);

//  char *line = readline (">>> ");
//  printf("%s\n", line);
//  int c;
//  read(3, &c, 1);


  isDCLInterrupted = TRUE;

  if(FALSE && __io__){
    int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
    shm_io_write(__io__, __io__->out, array, sizeof(array));
  }
//  errorcall(R_NilValue, "segmentation fault"); //??? FIXME
//  exit(1); // not good...

  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);

}

//int isTaskrunnerInterrupted = FALSE;

//extern int isInterrupted;

char interrupt_message_buf[256];

/*
void  myR_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
  //c_backtrace();

  isTaskrunnerInterrupted = TRUE;
  isInterrupted = TRUE;

   

  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);
  //sigaction(SIGINT, &R_oldactInt, NULL);

  //errorcall(R_NilValue, msg); //??? FIXME
  //exit(1);
}
*/

/*
typedef struct tr_cntxt_struct {
  shm_io_info_t *io;
  int job_id;
  int tr_id;
  pid_t pid;
} tr_cntxt_t;

tr_cntxt_t tr_cntxt = {NULL, -1, -1, 0};
*/
extern tr_cntxt_t tr_cntxt;

char *cntxt2str(){
  char *s = malloc(256);
  sprintf(s, "\033[0;32mpid=%d, job_id=%d, tr_id=%d, %s\033[0m",
		  tr_cntxt.pid,  tr_cntxt.job_id,
		  tr_cntxt.tr_id, tr_cntxt.io->shm_info.shm_name);
  return s;
}

void  (*myTryEval_SigactionInt)(int sig, siginfo_t *ip, void *context) =NULL;

extern void sendDriverMessage(shm_io_info_t *io, int job_id, int tr_id, const char *msg);
extern void rjni_io_err_write(shm_io_info_t *io, const char *msg);

#define  BACKTRACE_SIZE 256
#include <execinfo.h>

char *myC_backtrace()
{
  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  size = backtrace(array, BACKTRACE_SIZE);
  strings = backtrace_symbols(array, size);

  int length = 0;
  for (i = 0; i < size; i++) //fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    length += strlen(strings[i]) + 1;
  
  char *str = (char*)malloc(length);
  char *s = str;
  for (i = 0; i < size; i++){
    memcpy(s, strings[i], strlen(strings[i]));
    s += strlen(strings[i]);
    *s = i== (size-1) ? 0 : '\n';
    s++;
  }

  free(strings);
  
  return str;
}

extern void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write);

char *myR_simpleTraceback();
//extern int isInterrupted;


/*
void  myR_SigactionTaskRunnerUsr2(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n",
		  __func__, pthread_self());
  //c_backtrace();

  isInterrupted = TRUE;

  int rc = sem_trywait(&__io__->err->sem_wr);
  fprintf(stderr, "\033[0;31m[%s] sem_trywait : %d\033[0m\n", __func__, rc);
  char *msg = "interrupted";
  if(rc == 0){
    msg = (char*) (__io__->err+1);
    msg[__io__->err->data_size-1] = 0;
    fprintf(stderr, "\033[0;31m[%s] message = %s\033[0m\n", __func__, msg);
    __io__->err->data_size = 0;
    sem_post(&__io__->err->sem_wr);
  }
  if(strlen(msg)==0) msg = "interrupted";
  int size = strlen(msg);
  if(sizeof(interrupt_message_buf)-1 < size)
	  size = sizeof(interrupt_message_buf)-1;
  memcpy(interrupt_message_buf, msg, size);
  interrupt_message_buf[size] = 0;

  
  kill(getpid(), SIGINT);

}
*/


/*
void  myTryEval_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n",
		  __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  c_backtrace();

  int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
  shm_io_write(__io__, __io__->out, array, sizeof(array));

  exit(1);
}
*/





/*
typedef struct shm_struct {
  size_t size;
  sem_t sem_w; // by java thread
  sem_t sem_r; // by java thread
} shm_struct_t;

typedef struct _shm_info {
  char *shm_name;
  void *mem_ptr;
} shm_info_t;
*/

//JNIEXPORT jlong JNICALL Java_RJNI_shmOpen (JNIEnv *javaEnv, jobject thisObj, jstring jshm_name)

/*
shm_info_t *shmOpen(const char *cshm_name) {
//  const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv, jshm_name, NULL);
  printf("[%s] cshm_name: %s\n", __func__, cshm_name);
  shm_info_t *shm_ptr = malloc(sizeof(shm_struct_t));

  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  size_t segment_size = sysconf(_SC_PAGE_SIZE);

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  close(fd);
  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);
//  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);

  shm_ptr->mem_ptr = mem_ptr;

  shm_struct_t * ssp = (shm_struct_t *)mem_ptr;
  ssp->size = segment_size;
  //sem_init(&ssp->sem_w, 1, 0);
  //sem_init(&ssp->sem_r, 1, 0);
  //sem_wait(&ssp->sem_w); sem_wait(&ssp->sem_r);
  int val;
  sem_getvalue(&ssp->sem_w, &val);
  printf("[%s] sem_getvalue(&ssp->sem_w, &val): %d\n", __func__, val);
  sem_getvalue(&ssp->sem_r, &val);
  printf("[%s] sem_getvalue(&ssp->sem_r, &val): %d\n", __func__, val);

  return shm_ptr;
}
*/

typedef void (*sighandler_t)(int);

//this worked 
void myTryEval_SIGINT_handler(int sig){
  fprintf(stderr, "[%s] is called on %d\n", __func__, getpid()); 
  fprintf(stdout, "[%s] is called on %d\n", __func__, getpid()); 
}

//extern char *__r2str(SEXP x, char *buf, int buf_size, int debug);
char *__r2str(SEXP x, char *buf, int buf_size, int debug)
{ 
       	return NULL;
}

char *sexp2char(SEXP x)
{
   int buf_size = 128*200;
   char buf[buf_size];
   //char *s = __r2str(x, buf, buf_size, 0);
   char *s = __r2str(x, buf, buf_size, 0);
   char *c = malloc(strlen(s)+1);
   memcpy(c, s, strlen(s)+1);
   return c;
}

char *myR_simpleTraceback()
{
  RCNTXT *cntxt = R_GlobalContext;
  int len  = 0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    len += strlen(c)+1+1+32;
    fprintf(stderr, "cntxt = %p: %s\n", cntxt, c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  char *str = malloc(len);
  char *s = str;
  cntxt = R_GlobalContext;
  int i=0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    if(i){ *s ='\n'; s++;}

    char b[16];
    sprintf(b, "%d: ", i++);
    memcpy(s, b, strlen(b));
    s += strlen(b);

    memcpy(s, c, strlen(c));
    s += strlen(c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  *s = 0;
  return str;
}


//extern int R_PPStackTop
//extern const char *R_curErrorBuf();
SEXP R_myTryEval(SEXP expr, SEXP env, int *errorOccurred)
{
#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue
//#define SETJMP(x) setjmp(x)

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  } 


#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));


  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      val = eval(expr, env);
      UNPROTECT(1);

    } else {

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  //UNPROTECT(1);

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n", 
		    __FILE__, __LINE__, save, R_PPStackTop);
  }

  return val;



//#undef SETJMP(x) 
#undef null
#undef R_ToplevelContext
}

extern int R_SignalHandlers;
void testing(int argc, char **argv){

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    //printf("R_CStackStart = %ld\n", R_CStackStart);
    //printf("R_CStackLimit = %ld\n", R_CStackLimit);
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();
  }

 
  /*
  {
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));

    int errorOccurred;
    printf("OKAY??\n");
    SEXP value = R_myTryEval(expr, R_GlobalEnv, &errorOccurred);
    printf("OKAY\n");
  }


  RCNTXT *__R_ToplevelContext  = R_GlobalContext;
  while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;

  printf("R_ToplevelContext>handlerstack:\n");
  PrintValue(__R_ToplevelContext->handlerstack);

#define R_ToplevelContext __R_ToplevelContext

  printf("R_ToplevelContext = %p\n", R_ToplevelContext);
  printf("R_GlobalContext   = %p\n", R_GlobalContext);
  printf("R_SignalHandlers   = %d\n", R_SignalHandlers);
  */
  //SETJMP(R_Toplevel.cjmpbuf);
/*
Defn.h:# define SIGSETJMP(x,s) sigsetjmp(x,s)
Defn.h:# define SETJMP(x) sigsetjmp(x,0)
Defn.h:# define SIGSETJMP(x,s) setjmp(x)
Defn.h:# define SETJMP(x) setjmp(x)
*/
//# define SETJMP(x) setjmp(x)
//  SETJMP(R_ToplevelContext->cjmpbuf);

  /*
  SETJMP(R_Toplevel.cjmpbuf);
    R_GlobalContext = R_ToplevelContext = R_SessionContext = &R_Toplevel;
    */
#define null R_NilValue
  /*
  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
  SEXP env = R_GlobalEnv;



  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

//  int count = 0;

  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

//    int succeeded = FALSE;
    if(!setjmp(R_ToplevelContext->cjmpbuf))
    //if(!setjmp(cntxt.cjmpbuf))
    {
      PrintValue(syscall);
   //   count++; if(count ==5) exit(1);
      printf("\033[0;31m%s: PrintValue\033[0m\n", __func__);
      val = PROTECT(eval(expr, env));
//      succeeded = TRUE;
    } else {
      val = PROTECT(mkString("pthread_error")); // to do
      setAttrib(val, install("class"), mkString("pthread_error"));
      PrintValue(val);
      printf("\033[0;35m%s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

  endcontext(&cntxt);
  */

  //exit(1);


  while(TRUE){

	  /*
    RCNTXT cntxt;
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
    SEXP env = R_GlobalEnv;
    SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

    begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    if(!setjmp(R_ToplevelContext->cjmpbuf))
    {
    */
        int errorOccurred;
        SEXP envir = R_GlobalEnv;
        SEXP expr = PROTECT(LCONS(install("stop"),
			    CONS(mkString("ERROR: TESTING"), R_NilValue)));
        SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(R_tryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(eval(expr, envir));
	printf("errorOccurred = %d\n", errorOccurred);
	if(errorOccurred)
	  fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
	else
          PrintValue(res);

	/*
    } else {
      printf("\033[0;35m[Error] %s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

    endcontext(&cntxt);
#undef null
*/

    //sleep(10);
  }

  //if(R_Interactive) run_Rmainloop();

  exit(1);
}

/*
typedef struct shm_data_header {
  int type;
  int padding;
  size_t size;
} shm_data_header_t;
*/
// Cluster.java:
#define TASK_RESULTS 303
#define TASK_EXIT    304

int  tr_get_shm_identityCode()
{
  static int code = 0;
  fprintf(stderr, "code = %d\n", code); 
  return code++;
}

static size_t __page_size__ = 0;
#define SHM_BLOCK_SIZE (2*__page_size__)

static socket_conn_t *__socket_conn__ = NULL;

extern SEXP SUPR_socketConnect(SEXP hostname, SEXP port, SEXP endian_str); 
extern SEXP SUPR_socketWrite(SEXP conn, SEXP x, SEXP endian_str);
extern SEXP SUPR_socketRead(SEXP conn, SEXP what, SEXP _n, SEXP endian_str); 
extern SEXP SUPR_socketReadObject(SEXP conn, SEXP env); 
extern SEXP SUPR_socketClose(SEXP conn); 
extern SEXP socketReadDCLEvent(SEXP socket_conn, SEXP env);

/*
void  dcl_error(const char *driver_host, int driver_port, int job_id,
	       	const char *msg, SEXP env)
{
  printf("%s: driver_host=%s\n", __func__, driver_host);
  printf("%s: driver_port=%d\n", __func__, driver_port);
  printf("%s: msg=%s\n", __func__, msg);

  SEXP host   = PROTECT(mkString(driver_host));
  SEXP port   = PROTECT(ScalarInteger(driver_port));
  SEXP endian = PROTECT(mkString("big"));
  SEXP conn   = PROTECT(SUPR_socketConnect(host, port, endian)); 

  SEXP x  = PROTECT(ScalarInteger(DCL_JOB_ERROR));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(ScalarInteger(job_id));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(mkString(msg));
  SUPR_socketWrite(conn, x, R_NilValue);

  SEXP ret  = SUPR_socketReadObject(conn, env); 
  UNPROTECT(7);


  printf("[%s] return\n", __func__);
  PrintValue(ret);

}
*/


/*
typedef struct sync_info_struct {
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  void (*run)(void *data);
  void *data;
  sem_t           sem_wait;
  sem_t           sem_notify;
} sync_info_t;
*/


void *rjni_shm_open(const char *cshm_name, size_t *size);

// argv[0] -DCL -port port -shm shm_name -name name
/*
int data_change_listener(int argc, char **argv)
{
  // parse args

  const char *driver_host = "localhost";
  int driver_port = 0;
  const char *shm_name = NULL;

  const char *dcl_name = "default";

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-port")==0 && i+1 < argc) {
      driver_port = atoi(argv[i+1]);
      i++;
    } else if(strcmp(argv[i], "-shm")==0 && i+1 < argc) {
      shm_name = argv[i+1];
      i++;
    } else if(strcmp(argv[i], "-name")==0 && i+1 < argc) {
      dcl_name = argv[i+1];
      i++;
    }
  }

  if(!driver_port){ // FIXME
    char *driver_log_file = "DriverDir/Driver.log";
    int fd = open(driver_log_file, O_RDONLY, 0600);
    if(fd != -1){
      struct stat statbuf;
      int rc = fstat(fd, &statbuf);
      if(rc == -1) {
        printf("[%s] Error (%s, %d): %s\n", __func__, __FILE__, __LINE__, strerror(errno));
      }
      size_t size = statbuf.st_size; // printf("%s: size=%ld\n", driver_log_file, size);
      char buf[size+1];
      read(fd, buf, size);
      close(fd); // printf("%s: %s\n", driver_log_file, buf);
      char *str = strstr(buf, ":");
      *str = 0;

      str++; // printf("%s: \"%s\"\n", driver_log_file, str);
      driver_port = atoi(str);

      driver_host = dupstr(buf+2);
      printf("%s: driver_host=%s\n", driver_log_file, driver_host);
      printf("%s: driver_port=%d\n", driver_log_file, driver_port);

    } else {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      exit(1);
    }
  }

  shm_io_info_t *io = NULL;

  tr_cntxt.io = io;
  tr_cntxt.pid = getpid();

  // initialize R
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);
  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE; 
    setup_Rmainloop();
  }

  myTryEval_SigactionInt = myR_SigactionDCLInt;

  // add/change signal handler
#ifdef __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sa.sa_sigaction = myR_SigactionDCLInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
  }
#endif

  __read__ = __dcl_read__;

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }

  SEXP res = R_NilValue;

  {
    SEXP call = PROTECT(LCONS(install("source"),
                            CONS(mkString("jR.R"), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);

    //printf("\033[0;32m\n\n[%s] OKAY 00\n\n\033[0m", __func__);
  }

  SEXP socket_conn = R_NilValue;
  SEXP env = R_GlobalEnv;

  if(driver_port) {
    SEXP host = PROTECT(mkString(driver_host));
    SEXP port = PROTECT(ScalarInteger(driver_port));
    SEXP endian = PROTECT(mkString("big"));
    socket_conn = PROTECT(SUPR_socketConnect(host, port, endian));
    __socket_conn__ = R_ExternalPtrAddr(socket_conn);
    //printf("[%s] socket fd = %d\n\n", __func__, __socket_conn__->fd);
 
    defineVar(install("socket.conn"), socket_conn, R_GlobalEnv); // fixme
    UNPROTECT(4);
  }

  // # register as the default listener
#define DCL_CONN 4
  SEXP x = PROTECT(ScalarInteger(DCL_CONN));
  //printf("\033[0;33m"); PrintValue(socket_conn);
  SEXP y = SUPR_socketWrite(socket_conn, x, R_NilValue);
  //printf("[%s] y = ", __func__); PrintValue(y); printf("[%s] OKAY 01\n", __func__);

  y = SUPR_socketWrite(socket_conn, install(dcl_name), R_NilValue);
  //printf("[%s] dcl_name = %s y = ", __func__, dcl_name);
  //PrintValue(y); printf("[%s] OKAY 02\n", __func__);
  UNPROTECT(1);


  int job_id = -1;
  int tr_id = -1;
  tr_cntxt.job_id = job_id;
  tr_cntxt.tr_id =  tr_id;

  SEXP envir = env;

  defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);
  defineVar(install(TR_TR_ID), ScalarInteger(tr_id), envir);
  SEXP ioPtr = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
  defineVar(install(TR_TR_IO), ioPtr, envir);
  UNPROTECT(1);


  SEXP expr = R_NilValue;

  int X11 = TRUE;

  SEXP event = R_NilValue;


  if(shm_name){

	 
    size_t size;
    void *mem_ptr = rjni_shm_open(shm_name, &size);
    printf("5/6: [%s] shm_name = %s\n", __func__, shm_name);
    printf("5/6: [%s] size = %ld, mem_ptr = %p\n", __func__, size, mem_ptr);

    sem_t *sem_wr = (sem_t *) mem_ptr;
    pid_t pid = ((pid_t*)(sem_wr+1))[0];
    printf("[%s] pid = %d, RDriver.pid = %d\n", __func__, getpid(), pid);
    pid = getpid();
    memcpy(sem_wr + 1, &pid, sizeof(pid_t));

    sem_post(sem_wr);
    munmap(mem_ptr, size);
   
  }

  while(TRUE){

    printf("\033[0;32m\n[%d] Next Job\n\033[0m", getpid()); 
    isDCLInterrupted = FALSE;
    isDisconnected   = FALSE;

    int errorOccurred;
    
    int save = R_PPStackTop;

    fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);

    int pi_envir;
    PROTECT_WITH_INDEX(envir, &pi_envir);
    int pi;
    PROTECT_WITH_INDEX(expr, &pi);


    SEXP nextEvent = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("socketReadDCLEvent"),
	    CONS(socket_conn, CONS(envir, R_NilValue)))));

    SEXP event = PROTECT(R_myTryEval(nextEvent, envir, &errorOccurred));

    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(event, 0)));

      if(isDCLInterrupted){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
        break;
      } else if(isDisconnected){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "disconnected");
        break;
      } else {
        UNPROTECT(4);
        continue;
      }
    } else if(TYPEOF(event) == NILSXP){
        UNPROTECT(4);
	continue;
    }
    defineVar(install("event"), event, envir);
    //PrintValue(event);

    const char *event_name = CHAR(PRINTNAME(VECTOR_ELT(event, 2))); // FIXME
    //printf("\033[031m[%s] event_name = \"%s\"\n", __func__, event_name);
    if(strcmp(event_name, "new()")==0){

       SEXP event_value = VECTOR_ELT(event, 3); // FIXME
       printf("event_value:\n"); PrintValue(event_value);

       printf("expr:\n");
       expr = VECTOR_ELT(event_value, 0); // FIXME
       REPROTECT(expr, pi);
       PrintValue(expr);

       job_id = INTEGER(VECTOR_ELT(event_value, 2))[0]; // FIXME
       printf("job_id: %d\n", job_id);
       defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);

       printf("envir:\n");
       envir = VECTOR_ELT(event_value, 1); // FIXME
       //REPROTECT(envir, pi_envir);
       if(TYPEOF(envir) == NILSXP){
         envir =  allocSExp(ENVSXP);
         REPROTECT(envir, pi_envir);
       //} else if(TYPEOF(envir) == VECSXP){
       } else if(TYPEOF(envir) != ENVSXP){
         //dcl_error(driver_host, driver_port, job_id, "invalid environment variable", R_GlobalEnv);
       }
       SET_ENCLOS(envir, R_GlobalEnv);
       PrintValue(envir);

    } else {
      printf("[%s] Whoops: event_name = \"%s\"\n", __func__, event_name);
      UNPROTECT(4);
      continue;
    }
    printf("\033[0m\n");
    if(save + 4 != R_PPStackTop) {
      fprintf(stderr, "Warning: save + 4 = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save + 4, R_PPStackTop, __FILE__, __LINE__);
    }

    SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
    //printf("[%s] errorOccurred = %d\n", __func__, errorOccurred);
    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
      //dcl_error(driver_host, driver_port, job_id, CHAR(STRING_ELT(res, 0)), envir); } else 
      PrintValue(res);

    
    if(isDCLInterrupted){
      fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
      break;
    }

    if(!errorOccurred)
      UNPROTECT(5);

    if(save != R_PPStackTop) {
      fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);
    }

  }

  //if(R_Interactive) run_Rmainloop();

  fprintf(stderr, "\033[0;31m%s\033[0m", "exit");
  exit(0);

}
*/

#include "util.h"

extern int SocketConn_reuseAddr;
extern supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);
extern supr_socket_conn_t *serverSocketAccept(supr_socket_conn_t *serverConn);


extern void SocketConn_closeAll(vector_t *conns, int do_shutdown);
/*
void SocketConn_closeAll(vector_t *conns)
{
  for(int i=vectorSize(conns)-1; i>=0; i--){
    supr_socket_conn_t *sc = vectorRemove(conns, i);
    int rc = shutdown(sc->fd, SHUT_RDWR);
    if(rc == -1) {
      printf("Error in shutdown: %s\n", strerror(errno));
    }
    rc = close(sc->fd);
    if(rc == -1) {
      printf("Error in close: %s\n", strerror(errno));
    }
    int val = 1;
    rc = setsockopt(sc->fd, SOL_SOCKET, SO_REUSEADDR, &val, INT_SIZE);
  }
}

*/

#define SocketConn_read(fd, buf, size) __read__(fd, buf, size)

size_t __read__(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      } 
    }

    int n = read(fd, buf + len,  size - len);

    if(n <= 0){
	    printf("[%s] read, n = %d, %s\n", __func__, n, strerror(errno));
	    return -1;
    } /* else if (n < size - len){
	    printf("[%s] Warning: read, n = %d, %s\n", __func__, n, strerror(errno));
    }
    */

    /*  n = -1: If no messages are available at the socket, the receive calls wait  for
       a  message  to arrive, unless the socket is nonblocking (see fcntl(2)),
       in which case the value -1 is returned and the external variable  errno
       is set to EAGAIN or EWOULDBLOCK.  The receive calls normally return any
       data available, up to the requested amount,  rather  than  waiting  for
       receipt of the full amount requested.
       */

    len += n;
  }
}

#define R_SERIALIZED_OBJECT 171117121
//#define R_SERIALIZED_OBJECT 825768241

void sendDriverInfoToWorkers(supr_socket_conn_t *driver)
{
  unsigned char buf[strlen(driver->host)+128];
  ((int*)buf)[0] = DRIVER_INFO;
  sprintf(buf+2*sizeof(int), "//%s:%d", driver->host, driver->port);
  ((int*)buf)[1] = strlen(buf+2*sizeof(int))+1;

  for(int i=0; i<vectorSize(socket_connections); i++){
      
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
         vectorElementAt(socket_connections, i);

    if(conn->type == WORKER_CONN)
      write(conn->fd, buf, 2*sizeof(int) + strlen(buf+2*sizeof(int))+1);

  }
}

void sendDriverInfoTo(supr_socket_conn_t *worker)
{
  for(int i=0; i<vectorSize(socket_connections); i++){
      
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
         vectorElementAt(socket_connections, i);

    if(conn->type == DRIVER_CONN){
      unsigned char buf[strlen(conn->host)+128];
      ((int*)buf)[0] = DRIVER_INFO;
      sprintf(buf+2*sizeof(int), "//%s:%d", conn->host, conn->port);
      ((int*)buf)[1] = strlen(buf+2*sizeof(int))+1;
      write(worker->fd, buf, 2*sizeof(int) + strlen(buf+2*sizeof(int))+1);
    }

  }
}


void writeError(int fd, const char* err){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    size_t len = strlen(err)+1;
    write(fd, &len, SIZE_SIZE);
    write(fd, err, len);
}

#define read(fd, buf, size) __read__((fd), (buf), (size))

static int rjni_strcmp(const void *a, const void *b)
{
  return strcmp(*((char **) a), *((char **) b));
}



void handleDD_list(supr_socket_conn_t *conn)
{
  //__supr_malloc_print__();
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

 
  dd_t *dd = Hashtable_get(ddEnvironment, name);
  if(dd){
#define __DD_LIST_DD_INFO__  1
    int rc = __DD_LIST_DD_INFO__;
    write(fd, &rc, INT_SIZE);
    int n;
    char **keys = Hashtable_keySet(dd->values, &n);
    qsort(keys, n, sizeof(char *), rjni_strcmp);
#define LIST_DATANODE_INFO
#ifdef  LIST_DATANODE_INFO
    int nDatanodes = 0;
    char *datanodeNames[vectorSize(socket_connections)];
    for(int i=0; i<vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc =  (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
      if(sc->type == DFS_DATANODE_CONN)
        datanodeNames[nDatanodes++] = SocketConn_addr(sc);
    }

    //printf("[%s] rc: %d, nDatanodes: %d\n", __func__, rc, nDatanodes);
    /*
    {
	    char msg[1024];
	    sprintf(msg, "rc: %d, nDatanodes: %d\n", rc, nDatanodes);
	    basic_info(msg);
    }
    */

    write(fd, &nDatanodes, INT_SIZE);
    for(int i=0; i< nDatanodes; i++)
      SocketConn_writeString(conn, datanodeNames[i]);

    write(fd, &n, INT_SIZE);
    for(int i=0; i<n; i++) {
      SocketConn_writeString(conn, keys[i]);
      /*
      {
	      int rc;
	      ssize_t size = read(fd, &rc, sizeof(int));
	      if(size != sizeof(int)){ // FIXME
		      basic_info(strerror(errno));
		      return;
	      }
      }
      */
      nn_value_t *subset = (nn_value_t *) Hashtable_get(dd->values, keys[i]);
      write(fd, &subset->stat, sizeof(dd_stat_t));

      int m = vectorSize(subset->addr);
      unsigned char which[nDatanodes];
      memset(which, 0, nDatanodes);
      for(int j=0; j<m; j++){
        char *addr = (char *) vectorElementAt(subset->addr, j);
        for(int k=0; k<nDatanodes; k++){
          if(strcmp(addr, datanodeNames[k])==0)
                  which[k] = 1;
        }
      }
      write(fd, which, sizeof(which));

    }
    free(keys);
#else
    write(fd, &n, INT_SIZE);
    for(int i=0; i<n; i++) {
      SocketConn_writeString(conn, keys[i]);
      nn_value_t *subset = (nn_value_t *) Hashtable_get(dd->values, keys[i]);
      write(fd, &subset->stat, sizeof(dd_stat_t));
    }
    free(keys);
#endif
    //__supr_malloc_print__();
    return;
  }
  

  char CWD_PATH[PATH_MAX];
  getcwd(CWD_PATH, PATH_MAX);
  char pathname[strlen(CWD_PATH)+strlen(name)+strlen("/data/")+1];
  sprintf(pathname, "%s/data/%s", CWD_PATH, name);

  printf("[%s] ls(%s)\n", __func__, pathname);

  struct stat sb;
  int rc = stat(pathname, &sb);
  if(rc == -1){ //send_error
    writeError(fd, strerror(errno));
    printf("Error: %s\n", strerror(errno));
    return;
  }

  write(fd, &rc, INT_SIZE);
  write(fd, &sb.st_mode, sizeof(mode_t));

  if(S_ISDIR(sb.st_mode)){
    DIR *dir = opendir(pathname);
    if(!dir){
      writeError(fd, strerror(errno));
      printf("Error: %s\n", strerror(errno));
      return;
    }
    rc = 0;
    write(fd, &rc, INT_SIZE);


    struct dirent *dp;
    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0)
	      continue;
      //printf("[%s] %s\n", __func__, dp->d_name);
      len = strlen(dp->d_name) + 1;
      write(fd, &len, SIZE_SIZE);
      write(fd, dp->d_name, len);
      sprintf(CWD_PATH, "%s/%s", pathname, dp->d_name);
      rc = stat(CWD_PATH, &sb);
      if(rc == -1){
        writeError(fd, strerror(errno));
      } else {
        write(fd, &rc, INT_SIZE);
        write(fd, &sb, sizeof(struct stat));
      }
    }
    len = 0;
    write(fd, &len, SIZE_SIZE);

  } else {
    write(fd, &sb, sizeof(struct stat));
  }

  //__supr_malloc_print__();
}


extern size_t SocketConn_writeString(supr_socket_conn_t* sc, const char *str);
extern char *SocketConn_readString(supr_socket_conn_t*, char *b, size_t b_size);
extern size_t SocketConn_writeInt(supr_socket_conn_t* sc, int val);

void Timedwait_notifyTimeout(void *data)
{
  void **args = (void**) data;
  supr_socket_conn_t *sc = (supr_socket_conn_t *) args[0];
  char *message = (char*) args[1];

  printf("[%s] message: %s\n", __func__, message);
  // isConnected?
  int fd = sc->fd;
  struct timeval tv;
  fd_set WR_fds;

  tv.tv_sec=10;
  tv.tv_usec=50000;

  FD_ZERO(&WR_fds);
  FD_SET(fd, &WR_fds);

  int ns = select(fd+1, NULL, &WR_fds, NULL, &tv);
  if(ns == 0){
    printf("%s:%d is disconnected", sc->host, sc->port);  
    return;
  }

  SocketConn_writeInt(sc, -1);
  SocketConn_writeString(sc, message);
  //free(message);
  //free(data);
}

void Timedwait_destroyDDMove(nn_timedwait_t *wait)
{
  void **data = (void **)wait->data;
  free(data[1]);// src
  free(data[3]);// src
  free(data[4]);// dest
  free(data);
  free(wait);
}

void handleDD_datanodeInfo(supr_socket_conn_t *conn)
{
  //int cmd = SocketConn_readInt(conn);
  //int level = SocketConn_readInt(conn);
  int fd = conn->fd;
  int cmd, level, type;
  read(fd,  &cmd, INT_SIZE);

  read(fd,  &cmd, INT_SIZE);

  unsigned char color[8];
  read(fd,  color, sizeof(color));
  read(fd,  &type, INT_SIZE);
  read(fd,  &level, INT_SIZE);

  size_t len;
  char *msg = SocketConn_readString(conn, NULL, 0);

  Cluster_sendSimpleMessage(msg, color, type, level);
  int rc = 0;
  write(fd,  &rc, INT_SIZE);
  free(msg);
}

#define DFS_DD_WAIT 

void handleDD_create(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  int rc = __mkdir__(name);
  if(rc ==  -1){
    writeError(fd, strerror(errno));
    printf("Error: %s\n", strerror(errno));
    SocketConn_info(0, "\033[0;31mError: %s\033[0m\n", strerror(errno));
  } else {

    dd_t *dd = newDD(name);
    printf("[%s] %s\n", __func__, Object_toString(dd));
    Hashtable_put(ddEnvironment, name, dd);

#ifdef  DFS_DD_WAIT 
  vector_t *att = newVector(FALSE);
  vectorAdd(att, conn);
  dd->att = att;
#endif

    for(int i=0; i<vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
      if(sc->type == DFS_DATANODE_CONN){
        write(sc->fd, &cmd, INT_SIZE);
        write(sc->fd, &len, SIZE_SIZE);
        write(sc->fd, name, len);
#ifdef  DFS_DD_WAIT 
	vectorAdd(dd->att, sc);
#endif
      }
    }

#ifndef  DFS_DD_WAIT 
  write(fd,  &rc, INT_SIZE);
#else
  void *data[] = {conn, strdup("Timeout"), dd};
  Timedwait_add(Timedwait_notifyTimeout, data, sizeof(data), Timedwait_destroy);
#endif
  }
}

void handleDD_createReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  char* dd_name = SocketConn_readString(conn, NULL, 0);
  int rc;
  read(fd,  &rc, INT_SIZE);
  static char* err = NULL;
  if(rc == -1){
    if(err) free(err);
    err = NULL;
    err = SocketConn_readString(conn, NULL, 0);
    SocketConn_info(0, "Error[%s:%d] %s", conn->host, conn->port,
		    dd_name, err); 
  }

  SocketConn_info(0, "//%s:%d", conn->host, conn->port);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  vector_t *att = (vector_t *) dd->att;

  //{ // TODO sleep(10); }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
    SocketConn_info(0, "Error: FIXME(%s:%d)", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    int rc = err? -1 : 0;
    pthread_mutex_lock(timedwait_queue->mutex);
    for(int i=vectorSize(timedwait_queue)-1; i>=0; i--) {
      nn_timedwait_t *event = vectorElementAt(timedwait_queue, i);
      void **data = (void **) event->data;
      if(data[2] == dd){
        vectorRemove(timedwait_queue, i);
        write(sc->fd, &rc, INT_SIZE);
	if(rc == -1){
          SocketConn_writeString(sc, err);
	  free(err);
	  err= NULL;
	}
      }
    }
    pthread_mutex_unlock(timedwait_queue->mutex);
    dd->att = NULL; // free/destroy...
  }

  free(dd_name);

}

void  Namenode_SigactionSegv(int sig, siginfo_t *ip, void *context);

void handleDD_open(supr_socket_conn_t *conn)
{

  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  int create;
  read(fd,  &create, INT_SIZE);

  DIR *dir;
  dd_t *dd = Hashtable_get(ddEnvironment, name);

  int rc = -1;
  if(dd) {
    rc = 0;
    
  } else if(dir = __opendir__(name)){
    closedir(dir);

    rc = 0;
    dd = newDD(name);

  } else if ( !create){

    writeError(fd, strerror(errno));
    printf("Error: %s\n", strerror(errno));
    return;

  } else if ( __mkdir__(name) != -1){

    rc = 0;
    dd = newDD(name);

  } else {
    writeError(fd, strerror(errno));
    printf("Error: %s\n", strerror(errno));
    return;
  }

  if(!dd) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
    exit(1);
  }

  Hashtable_put(ddEnvironment, name, dd);
  //printf("[%s] %s\n", __func__, Object_toString(dd));

//#ifdef  DFS_DD_WAIT 
//  vector_t *att = newVector(FALSE);
//  vectorAdd(att, conn);
//  dd->att = att;
//#endif

  supr_socket_conn_t *datanodes[vectorSize(socket_connections)];
  int n = 0;

  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
        write(sc->fd, &cmd, INT_SIZE);
        write(sc->fd, &len, SIZE_SIZE);
        write(sc->fd, name, len);
//	vectorAdd(att, sc);
	datanodes[n++] = sc;
    }
  }

  vector_t *errors = newVector(FALSE);

  // open save .__dd_info
  do {
    char path[strlen("data//.__dd_info")+strlen(name)+1];
    sprintf(path, "data/%s/.__dd_info", name);
    int persist_fd = open(path, O_RDONLY);
    if(persist_fd == -1) {
      //printf("[%s] Error: %s\n", __func__, strerror(errno));
      //vectorAdd(errors, strdup(strerror(errno)));
      break;
    }

    int len;
    // read locations
    int nLocations;
    read(persist_fd, &nLocations, INT_SIZE);
    char **locations = (char**) malloc(nLocations * sizeof(char*));
    //printf("\033[0;35m");
    for(int k=0; k<nLocations; k++){
      read(persist_fd, &len, INT_SIZE);
      char loc[len];
      read(persist_fd, loc, len);
      //printf("[%s] %d: %s\n", __func__, k, loc);
      String addr = Hashtable_get(dn_locations, loc);
      if(addr){
        //printf("\t%s -> %s\n", loc, Object_toString(addr));
	locations[k] = (char*) Object_toString(addr); // strdup???
      } else {
        printf("\t[WARNING] No datanode is available for %s\n", loc);
	locations[k] = NULL;
      }
    }

    // read subsets
    int n;
    read(persist_fd, &n, INT_SIZE);
    for(int i=0; i<n; i++){
      
      read(persist_fd, &len, INT_SIZE);
      char s_name[len];
      read(persist_fd, s_name, len);

      //printf("[%s] %d: %s", __func__, i, s_name);

      int m;
      read(persist_fd, &m, INT_SIZE);
      for(int j=0; j<m; j++){
	int idx;
        read(persist_fd, &idx, INT_SIZE);
        //printf(" [%d] %s", idx, locations[idx]); 
      }
      //printf("\n");
      
    }

    verbose_info("fd: %d", persist_fd);

    close(persist_fd);
    //printf("\033[0m");
    free(locations);

  } while(0);


  int nDatanodes = n;
  char *datanodeNames[n];
  for(int i=0; i< nDatanodes; i++)
    datanodeNames[i] = SocketConn_addr(datanodes[i]);

  while(n) {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=60;
      tv.tv_usec=0;

      FD_ZERO(&readfds);
      //FD_SET(fd, &readfds);
      int max_fd = 0;
      for(int i=0; i<n; i++){
        supr_socket_conn_t *sc = datanodes[i];
        int dn_fd = sc->fd;
        if(dn_fd > max_fd) max_fd = dn_fd;
        FD_SET(dn_fd, &readfds);
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
         if(Supr_debug){
	   Cluster_sendSimpleMessage("Waiting for datanodes",
                             "\033[0;34m", DEBUG_INFO_TYPE, 0);
	 }
         if(ns==0) continue;
      }

      for(int i=0; i < n; i++){
        supr_socket_conn_t *sc = datanodes[i];
	int dn_fd = sc->fd;
        if(FD_ISSET(dn_fd, &readfds)){

	  //printf("\n\033[0;35m[%s] Read //%s:%d\033[0m\n", __func__, sc->host, sc->port);
	  int rc;

          SocketConn_read(dn_fd, &rc, INT_SIZE);

	  //printf("\033[0;35m[%s] rc: %d\033[0m\n", __func__, rc);

	  if(rc == -1){
	    char *err = SocketConn_readString(sc, NULL, 0);
	    //printf("[%s] Error: %s\n", __func__, err);
            vectorAdd(errors, err);

	    n--;
	    for(; i<n; i++){
	      datanodes[i] = datanodes[i+1];
	    }
	    break;
	  }


	  while(TRUE){
            size_t slen;
            SocketConn_read(dn_fd, &slen, SIZE_SIZE);
	    //printf("\033[0;35m[%s] slen: %ld\033[0m\n", __func__, slen);
            if(slen == 0) break;

	    char s_name[slen];
            SocketConn_read(dn_fd, s_name, slen);
	    //printf("[%s] s_name: %s\n", __func__, s_name);

	    int rc;
            read(dn_fd, &rc, INT_SIZE);
	    //printf("[%s] rc: %d\n", __func__, rc);
	    if(rc == -1){
	      char *err = SocketConn_readString(sc, NULL, 0);
	      //printf("[%s] Error: %s, %s\n", __func__, s_name, err);
              //vectorAdd(dd->att, err);
              vectorAdd(errors, err);
	    } else {
              nn_value_t *subset = (nn_value_t *) Hashtable_get(
			      dd->values, s_name);
	      if(!subset) {
                subset = newNamenodeValue();
                Hashtable_put(dd->values, s_name, subset);
	      }
              read(dn_fd, &subset->stat, sizeof(dd_stat_t));
	      //vectorAdd(subset->addr, SocketConn_addr(sc));
	      vectorAddIfNotExists(subset->addr, SocketConn_addr(sc),
			      wrapped_strcmp);
	      //printf("[%s] %s: %ld\n", __func__, s_name, subset->stat.st_size);
	    }
            //vectorRemoveElement(dd->att, sc);
	  }

	  n--;
	  for(; i<n; i++){
	    datanodes[i] = datanodes[i+1];
	  }
	  break;
	}
      }
  }

  if(vectorSize(errors)){
	  /*
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = vectorSize(errors);
    write(fd, &n, INT_SIZE);
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      SocketConn_writeString(conn, err);
      free(err);
    }
    */
    size_t len = 0;
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorElementAt(errors, i);
      len += strlen(err)+strlen(ERROR_SEPARATOR);
    }
    char *strerr = (char*) malloc(len); 
    *strerr = 0;
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      sprintf(strerr + strlen(strerr), "%s%s", err, i==0 ? "":ERROR_SEPARATOR);
    }
    writeError(fd, strerr);
    free(strerr);
  } else {
    int rc = 0;
    write(fd, &rc, INT_SIZE);
	  /*
    int n;
    char **keys = Hashtable_keySet(dd->values, &n);

    write(fd, &nDatanodes, INT_SIZE);
    for(int i=0; i< nDatanodes; i++)
      SocketConn_writeString(conn, datanodeNames[i]);

    write(fd, &n, INT_SIZE);

    for(int i=0; i<n; i++){
      char *key = keys[i];
      SocketConn_writeString(conn, key);
      nn_value_t *subset = (nn_value_t *) Hashtable_get(dd->values, key);
      write(fd, &subset->stat, sizeof(dd_stat_t));
      int m = vectorSize(subset->addr);
      //write(fd, &m, INT_SIZE);
      unsigned char which[nDatanodes];
      memset(which, 0, nDatanodes);
      for(int j=0; j<m; j++){
        char *addr = (char *) vectorElementAt(subset->addr, j);
        //SocketConn_writeString(conn, addr);
	for(int k=0; k<nDatanodes; k++){
          if(strcmp(addr, datanodeNames[k])==0)
		  which[k] = 1;
	}
      } 
      write(fd, which, sizeof(which));
    }
    free(keys);
    */
  }

  vectorDestroy(errors);

  //printf("[%s] Return\n", __func__);
  //Cluster_sendSimpleMessage(__func__, "\033[0;34m", 0, 0);
}

#define __DD_INFO_FILE_NAME__ ".__dd_info__" 

/*
void handleDD_openReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  vector_t *att = (vector_t *) dd->att;

  int rc;
  static char *err = NULL;
  read(fd,  &rc, INT_SIZE);
  if(rc == -1) {
    err = SocketConn_readString(conn, NULL, 0);  
  } else {
    char datanode[256];
    sprintf(datanode, "//%s:%d", conn->host, conn->port);
    while(TRUE){
      int len;
      read(fd, &len, INT_SIZE);
      if(len == 0) break;
      char key[len];
      read(fd, key, len);
      printf("[%s] key/s_name: %s\n",__func__, key);
      
      nn_value_t *subset = (nn_value_t *)Hashtable_get(dd->values, key);
      if(!subset){
        subset = newNamenodeValue();
        Hashtable_put(dd->values, key, subset);
      }
      vectorAdd(subset->addr, datanode);

      read(fd, &rc, INT_SIZE);
      if(rc==-1){
        char *err = SocketConn_readString(conn, NULL, 0);
	subset->stat.st_size = 0;
      } else {
        read(fd, &subset->stat, sizeof(dd_stat_t));
      }
    }
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    if(rc == 0) {
      char file_name[strlen(dd_name) + strlen(__DD_INFO_FILE_NAME__)+2];
      sprintf(file_name, "%s/%s", dd_name, __DD_INFO_FILE_NAME__);
      int info_fd = open(file_name, O_RDONLY);
      if(info_fd != -1){
	dd_t dd_struct;
	read(info_fd, &dd_struct, sizeof(dd_t));
	int nkeys;
	read(info_fd, &nkeys, INT_SIZE);
	int n;
	char **keys = Hashtable_keySet(dd->values, &n);
	if(n != nkeys){
	  rc = -1;
	  err = "Subsets are inaccessible"; 
	}
	free(keys);
	close(info_fd);

	//for(int i=0; i<nkeys; i++){ }
      }
    }
  
    pthread_mutex_lock(timedwait_queue->mutex);
    for(int i=vectorSize(timedwait_queue)-1; i>=0; i--) {
      nn_timedwait_t *event = vectorElementAt(timedwait_queue, i);
      void **data = (void **) event->data;
      if(data[2] == dd){
        vectorRemove(timedwait_queue, i);

	if(rc == -1){
          write(sc->fd, &rc, INT_SIZE);
	  SocketConn_writeString(sc, err);
	  free(err);
	  err = NULL;
	} else {
          write(sc->fd, &rc, INT_SIZE);
	}
      }
    }
    pthread_mutex_unlock(timedwait_queue->mutex);
    dd->att = NULL; // free/destroy...
  }

}
*/

extern void  __supr_malloc_print__();

void handleDD_put(supr_socket_conn_t *conn)
{
//  __supr_malloc_print__();
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, name);

  if(!dd){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    char err[256];
    sprintf(err, "Cannot find opened DD '%s'", name);
    SocketConn_writeString(conn, err);
    return;
  }

  vector_t *att = newVector(FALSE);
//  vectorAdd(att, conn);
//  dd->att = att;

  supr_socket_conn_t *datanodes[vectorSize(socket_connections)];

  int n = 0;
  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
      datanodes[n++] = sc;
    } 
  }

  write(fd, &n, INT_SIZE);
  if(n==0) return;

  int m = 0;
  while(TRUE){
    size_t slen;
    read(fd, &slen, SIZE_SIZE);
    if(slen == 0) break;
    char subset_name[slen];
    read(fd,  subset_name, slen);
    so_t so; 
    read(fd,  &so, sizeof(so_t));
    so_t *s = (so_t*) malloc(sizeof(so_t)+so.size);
    read(fd,  s + 1, so.size);
    memcpy(s, &so, sizeof(so_t));
    printf("\033[0;33m[%s] dd_name: %s subset_name: %s\033[0m\n",
		    __func__, name, subset_name);

    if(n>0){
      long rn = random();
      supr_socket_conn_t *sc = datanodes[rn % n];
      int dn_fd = sc->fd;
      write(dn_fd, &cmd, INT_SIZE);
      write(dn_fd, &len, SIZE_SIZE);
      write(dn_fd, name, len);
      write(dn_fd, &slen, SIZE_SIZE);
      write(dn_fd, subset_name, slen);
      write(dn_fd, s, sizeof(so_t) + s->size);
      vectorAdd(att, sc);
      ////
      {
        int rc;
	read(dn_fd, &rc, INT_SIZE);
        write(fd, &rc, INT_SIZE);
      }
      ////
    }
    free(s);

    m++;
  }

  // error if n == 0;


  for(int i=0; i<n; i++){
    supr_socket_conn_t *sc = datanodes[i];
    int dn_fd = sc->fd;
    write(dn_fd, &cmd, INT_SIZE);
    len = 0;
    write(dn_fd, &len, SIZE_SIZE);
  }

  vector_t *errors = newVector(FALSE);

  struct timeval tv;
  fd_set readfds;

  tv.tv_sec=60;
  tv.tv_usec=0;

  while(n) {
      FD_ZERO(&readfds);
      //FD_SET(fd, &readfds);
      int max_fd = 0;
      for(int i=0; i<n; i++){
        supr_socket_conn_t *sc = datanodes[i];
        int dn_fd = sc->fd;
        if(dn_fd > max_fd) max_fd = dn_fd;
        FD_SET(dn_fd, &readfds);
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }

      for(int i=0; i < n; i++){
        supr_socket_conn_t *sc = datanodes[i];
	int dn_fd = sc->fd;
        if(FD_ISSET(dn_fd, &readfds)){
	  printf("[%s] Read //%s:%d\n", __func__, sc->host, sc->port);

	  while(TRUE){
            size_t slen;
            read(dn_fd, &slen, SIZE_SIZE);
            if(slen == 0) break;

	    char s_name[slen];
            read(dn_fd, s_name, slen); // TODO

	    int rc;
            read(dn_fd, &rc, INT_SIZE);
	    //printf("[%s] rc: %d\n", __func__, rc);
	    if(rc == -1){
	      char *err = SocketConn_readString(sc, NULL, 0);
	      printf("[%s] Error: %s, %s\n", __func__, s_name, err);
              //vectorAdd(dd->att, err);
              vectorAdd(errors, err);
	    } else {
              nn_value_t *subset = (nn_value_t *) Hashtable_get(
			      dd->values, s_name);
	      if(!subset) {
                subset = newNamenodeValue();
                Hashtable_put(dd->values, s_name, subset);
	      }
              read(dn_fd, &subset->stat, sizeof(dd_stat_t));
	      //vectorAdd(subset->addr, SocketConn_addr(sc));
	      vectorAddIfNotExists(subset->addr, SocketConn_addr(sc),
			      wrapped_strcmp);
	      printf("[%s] %s: %ld\n", __func__, s_name, subset->stat.st_size);
	    }
            vectorRemoveElement(att, sc);
	  }

	  n--;
	  for(; i<n; i++){
	    datanodes[i] = datanodes[i+1];
	  }
	  break;
	}
      }
  }

  //printf("[%s] vectorSize(dd->att): %d\n", __func__, vectorSize(dd->att));
  printf("dd->values: %s\n", (char*) Object_toString(dd->values));

  if(vectorSize(errors)){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = vectorSize(errors);
    write(fd, &n, INT_SIZE);
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      SocketConn_writeString(conn, err);
      free(err);
    }
  } else 
    write(fd, &m, INT_SIZE);

  vectorDestroy(errors);
  vectorDestroy(att);
  dd->att = NULL;


//  __supr_malloc_print__();
}


/*
void handleDD_putReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  read(fd,  &len, SIZE_SIZE);
  char subset_name[len];
  read(fd,  subset_name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  vector_t *att = (vector_t *) dd->att;

  int rc;
  static char *err = NULL;
  read(fd,  &rc, INT_SIZE);
  if(rc == -1) {
    err = SocketConn_readString(conn, NULL, 0);
  }

  { // TODO
    printf("\t[%s] %s::%s //%s:%d (err=%s)\n", __func__, dd_name, subset_name,
		    conn->host, conn->port, err);
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    int rc = 0;
    write(sc->fd, &rc, INT_SIZE);
    dd->att = NULL; // free/destroy...
  }

}
*/





/*
void handleDD_update(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, name);

  if(!dd) {
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    char err[256];
    sprintf(err, "Cannot find '%s'", name);
    size_t len =strlen(err)+1;
    write(fd, &len, SIZE_SIZE);
    write(fd, &err, len);
    return;
  }

}
*/

/*
void handleDD_updateReturn(supr_socket_conn_t *conn)
{
  // in bytes: [cmd dd_name, list of [subset_name, struct dd_stat_t]]
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  vector_t *att = (vector_t *) dd->att;

  // FIXME
  while(TRUE){

    read(fd, &len, SIZE_SIZE);
    if(len==0) break;

    char s_name[len];
    read(fd, s_name, len);
    dd_stat_t sb;
    read(fd, &sb, sizeof(dd_stat_t));

    nn_value_t *subset = (nn_value_t *)Hashtable_get(dd->values, s_name);
    if(!subset) {
      subset = newNamenodeValue();
      Hashtable_put(dd->values, s_name, subset);
      memcpy(&subset->stat, &sb, sizeof(dd_stat_t));
    } else {
      // TODO , compare ...
    }
    vectorAdd(subset->addr, SocketConn_addr(conn));
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *) 
	    vectorElementAt(att, 0);
    int rc = 0;
    write(sc->fd, &rc, INT_SIZE);
    dd->att = NULL; // free/destroy...
  }
  
}
*/

//

static int dd_strcmp(const void *a, const void *b)
{
  //return strcmp(*((char **) a), *((char **) b));
  return strcmp(*((char * const *) a), *((char * const *) b));
}

//



void handleDD_replicate(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  dd_t *dd = Hashtable_get(ddEnvironment, dd_name);
  if(!dd){
    char err[256];
    sprintf(err, "Cannot find opened DD '%s'", dd_name);
    writeError(fd, err);
    return;
  }

//#ifdef  DFS_DD_WAIT 
  vector_t *att = newVector(FALSE);
  //vectorAdd(att, conn);
  dd->att = att;
//#endif

  supr_socket_conn_t *dn_conns[vectorSize(socket_connections)];

  void *datanodes[vectorSize(socket_connections)][3];
  int n = 0;
  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
      dn_conns[n] = sc;

      datanodes[n][0] = SocketConn_addr(sc);
      datanodes[n++][1] =  sc;
    }
  }

  for(int i=0; i<n;i++){
    printf("Before:\n\t %d:\t%s <%p>\n", i, (char*) datanodes[i][0], datanodes[i][1] );
  }

  qsort(datanodes, n, 3*sizeof(char*), dd_strcmp);
  for(int i=0; i<n;i++){
    printf("After:\n\t %d:\t%s <%p>\n", i, (char*) datanodes[i][0], datanodes[i][1] );
    ((int*)&datanodes[i][2])[0] = i;
  }

  int n_replicates = n;
  int nkeys;
  char **keys = Hashtable_keySet(dd->values, &nkeys);
  for(int i=0; i<nkeys; i++){
    nn_value_t *nn_val = (nn_value_t*) Hashtable_get(dd->values, keys[i]);
    if(vectorSize(nn_val->addr) < n_replicates)
      n_replicates = vectorSize(nn_val->addr);
  }
  n_replicates++;
  if(n_replicates > n) {
    free(keys);
    n_replicates--;
    write(fd, &n_replicates, INT_SIZE);

    vectorDestroy(att);
    dd->att = NULL;

    return;
  }

  cmd = DFS_DD_PUT;

  for(int i=0; i < nkeys; i++){
    
    nn_value_t *nn_val = (nn_value_t*) Hashtable_get(dd->values, keys[i]);
    int n_src = vectorSize(nn_val->addr);
    if(n_src >= n_replicates) continue;

    char *src_addr = vectorElementAt(nn_val->addr, random() % n_src);
    printf("\tsrc_addr: %s\n", src_addr);

    int dest_idx = random() % (n - n_src);

    int dest_indicators[n];
    for(int j=0; j<n; j++) dest_indicators[j] = 1;

    for(int j=0; j < n_src; j++){
       void *s[] = {vectorElementAt(nn_val->addr, j)};
       void *which= bsearch(s, datanodes, n, 3*sizeof(void *), 
		       dd_strcmp);
       if(!which){
          fprintf(stderr, "Error: FIXME (%s:%d)\n", __FILE__, __LINE__);
       }
       int k  = ((int*)&((void **)which)[2])[0];
       dest_indicators[k] = 0;
       printf("\tdest[%d]: %s, \n", k, (char*) ((void **)which)[0]);
    }

    {
      for(int j=0; j<n; j++){
         printf("\033[0;32m\t%d: [%s] %s\033[0m\n",
			 j, dest_indicators[j]==1? "*":" ",
			(char*) datanodes[j][0]);
      }
    }

    int idx = 0;
    dest_idx ++;
    supr_socket_conn_t *sc = NULL;
    for(int j=0; j<n; j++){
      idx +=  dest_indicators[j];
      if(idx == dest_idx) {
	sc = (supr_socket_conn_t *) datanodes[j][1];
        break;
      }
    }

    if(sc==NULL) {
      fprintf(stderr, "Error: FIXME (%s:%d)\n", __FILE__, __LINE__);
    }

    write(sc->fd, &cmd, INT_SIZE);
    write(sc->fd, &len, SIZE_SIZE);
    write(sc->fd, dd_name, len);

    size_t size = strlen(keys[i])+1;
    write(sc->fd, &size, SIZE_SIZE);
    write(sc->fd, keys[i], size);

    /*
    size_t size = strlen(src_addr)+1;
    unsigned char so[sizeof(so_t) + size];
    so_t *s =  (so_t *)so;
    s->obj_type = SUPR_URI;
    s->size = size;
    */
    size = strlen(src_addr)+1;
    so_t so =  {0, 0, 0, SUPR_URI, size};

    write(sc->fd, &so, sizeof(so_t));
    write(sc->fd, src_addr, size);

//#ifdef  DFS_DD_WAIT
      vectorAdd(dd->att, sc);
//#endif

    ////
    {
        int rc;
        read(sc->fd, &rc, INT_SIZE); //write(fd, &rc, INT_SIZE);
	printf("[%s] rc: %d (? 0)\n", __func__, rc);
    }
   ////


  }

  for(int i=0; i<n; i++){
    supr_socket_conn_t *sc = dn_conns[i];
    int dn_fd = sc->fd;
    write(dn_fd, &cmd, INT_SIZE);
    len = 0;
    write(dn_fd, &len, SIZE_SIZE);
  }

  vector_t *errors = newVector(FALSE);

  while(n) {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=60;
      tv.tv_usec=0;

      FD_ZERO(&readfds);
      //FD_SET(fd, &readfds);
      int max_fd = 0;
      for(int i=0; i<n; i++){
        supr_socket_conn_t *sc = dn_conns[i];
        int dn_fd = sc->fd;
        if(dn_fd > max_fd) max_fd = dn_fd;
        FD_SET(dn_fd, &readfds);
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }

      for(int i=0; i < n; i++){
        supr_socket_conn_t *sc = dn_conns[i];
        printf("[%s] Read //%s:%d\n", __func__, sc->host, sc->port);
        int dn_fd = sc->fd;
        if(FD_ISSET(dn_fd, &readfds)){
          while(TRUE){
            size_t slen;
            SocketConn_read(dn_fd, &slen, SIZE_SIZE);
            if(slen == 0) break;

            char s_name[slen];
            SocketConn_read(dn_fd, s_name, slen); // TODO

            int rc;
            SocketConn_read(dn_fd, &rc, INT_SIZE);
            //printf("[%s] rc: %d\n", __func__, rc);
            if(rc == -1){
              char *err = SocketConn_readString(sc, NULL, 0);
              printf("[%s] Error: %s, %s\n", __func__, s_name, err);
              //vectorAdd(dd->att, err);
              vectorAdd(errors, err);
            } else {
              nn_value_t *subset = (nn_value_t *) Hashtable_get(
                              dd->values, s_name);
              if(!subset) {
                subset = newNamenodeValue();
                Hashtable_put(dd->values, s_name, subset);
              }
              //SocketConn_
              read(dn_fd, &subset->stat, sizeof(dd_stat_t));
              //vectorAdd(subset->addr, SocketConn_addr(sc));
              vectorAddIfNotExists(subset->addr, SocketConn_addr(sc),
                              wrapped_strcmp);
              //printf("[%s] %s: %ld\n", __func__, s_name, subset->stat.st_size);
            }
            vectorRemoveElement(dd->att, sc);
          }

          n--;
          for(; i<n; i++){
            dn_conns[i] = dn_conns[i+1];
          }
          break;
        }
      }
  }

  if(vectorSize(errors)){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = vectorSize(errors);
    write(fd, &n, INT_SIZE);
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      SocketConn_writeString(conn, err);
      free(err);
    }
  } else
    write(fd, &n_replicates, INT_SIZE);

  vectorDestroy(errors);
  vectorDestroy(att);
  dd->att = NULL;

  /*
#ifndef  DFS_DD_WAIT
  write(conn->fd, &n_replicates, INT_SIZE);
#endif
*/

}

/*
void handleDD_replicateReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  read(fd,  &len, SIZE_SIZE);
  char subset_name[len];
  read(fd,  subset_name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  vector_t *att = (vector_t *) dd->att;


  { // TODO
    printf("\t[%s] %s::%s //%s:%d\n", __func__, dd_name, subset_name,
		    conn->host, conn->port);
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    int rc = 0;
    write(sc->fd, &rc, INT_SIZE);
  }

}
*/



/*
void __handleDD_persist(task_t *task);

void handleDD_persist(supr_socket_conn_t *conn)
{
  printf("[%s] Start\n", __func__);
  conn->efd = conn->fd;
  conn->fd = -1;
  task_t *task = newTask(__handleDD_persist, conn);
  pthread_mutex_lock(&tasks_mutex);
    vectorAdd(tasks, task);
    pthread_cond_signal(&tasks_cond);
  pthread_mutex_unlock(&tasks_mutex);
  printf("[%s] end\n", __func__);
}
*/

void handle_interrupt(supr_socket_conn_t *conn);

#define ALLOW_INTRRUPTION


//void handleDD_persist(task_t *task)
void handleDD_persist(supr_socket_conn_t *conn)
{
  ////
  /*
  supr_socket_conn_t *conn = (supr_socket_conn_t *) task->data;
  pthread_setspecific(interruptThreadKey, conn); // testing
  */
  ////

  //int fd = conn->efd;
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  int level;
  //basic_info("[%s] dd_name: %s, level: %d\n", __func__, name, level);
  read(fd,  &level, INT_SIZE);

  verbose_info("[%s] dd_name: %s, level: %d\n", __func__, name, level);

  dd_t *dd = Hashtable_get(ddEnvironment, name);


  if(!dd){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n=1;
    write(fd, &n, INT_SIZE);
    char err[256];
    sprintf(err, "Cannot find DD '%s'", name);
    SocketConn_writeString(conn, err);
    return;
  }

  vector_t *att = newVector(FALSE);
  //vectorAdd(att, conn);
  //dd->att = att;

  int nDatanodes = 0;
  supr_socket_conn_t *dn_conns[vectorSize(socket_connections)];

  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
        
        write(sc->fd, &cmd, INT_SIZE);
        write(sc->fd, &len, SIZE_SIZE);
        write(sc->fd, name, len);
        write(sc->fd, &level, INT_SIZE);
        vectorAdd(att, sc);

	dn_conns[nDatanodes++] = sc;
    }
  }

  vector_t *errors = newVector(FALSE);
  do {
    int rc = 0;
    //char path[PATH_MAX]; getcwd(path, PATH_MAX);
    //printf("[%s] cwd: %s\n", __func__, path);
    char path[strlen("data//.__dd_info")+strlen(name)+1];
    sprintf(path, "data/%s/.__dd_info", name);
    int persist_fd = open(path, O_RDWR | O_CREAT | O_TRUNC, 0600);
    if(persist_fd == -1) {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      vectorAdd(errors, strdup(strerror(errno)));
      break;
    }


    int n;
    char **keys = Hashtable_keySet(dd->values, &n);

    char **locations = (char**) malloc(n*sizeof(char*)); // n -> nDatanodes?
    int nLocations = 0;
    int **location_indices = (int**) malloc(n*sizeof(int*));

    for(int i=0; i<n; i++){
      nn_value_t *subset =  (nn_value_t *) Hashtable_get(dd->values, keys[i]);
      //printf("key: %s\n", keys[i]);

      int m = vectorSize(subset->addr);
      /*
      int len = strlen(keys[i])+1;
      write(persist_fd, &len, INT_SIZE);
      write(persist_fd, keys[i], len);

      write(persist_fd, &m, INT_SIZE);
      */

      location_indices[i] = (int*) malloc((m+1)*sizeof(int));
      location_indices[i][0] = m;

      for(int j=0; j<m; j++){
        char *addr = (char*) vectorElementAt(subset->addr, j);
	char *loc = (char*) Object_toString(Hashtable_get(dn_locations, addr));
	printf("\t %s: %s\n", addr, loc);
	int k=0;
	for(; k<nLocations; k++){
          if(strcmp(loc, locations[k])==0) break;
	}
	if(k == nLocations) locations[nLocations++] = loc;
        //write(persist_fd, &k, INT_SIZE);
        location_indices[i][j+1] = k;
      }

    }

    int len;
    // save locations
    write(persist_fd, &nLocations, INT_SIZE);
    for(int k=0; k<nLocations; k++){
      len = strlen(locations[k]) + 1;
      write(persist_fd, &len, INT_SIZE);
      write(persist_fd, locations[k], len);
    }

    // save subsets
    write(persist_fd, &n, INT_SIZE);
    for(int i=0; i<n; i++){
      len = strlen(keys[i]) + 1;
      write(persist_fd, &len, INT_SIZE);
      write(persist_fd, keys[i], len);
      write(persist_fd, location_indices[i], (location_indices[i][0]+1)
		      *INT_SIZE);
      free(location_indices[i]);
    }
    close(persist_fd);

    free(keys);
    free(location_indices);
    free(locations);


  } while(0);

  // to allow interruption?
#ifdef  ALLOW_INTRRUPTION
  int server_fd = serverConn->fd;
  int isInterrupted = FALSE;
#endif
  int n = nDatanodes;

  struct timeval tv;
  fd_set readfds;

  tv.tv_sec=60;
  tv.tv_usec=0;


  while(n){
    tv.tv_sec=60;
    tv.tv_usec=0;
    verbose_info("read from %d datanodes...", n);
    FD_ZERO(&readfds);
      //FD_SET(fd, &readfds);
    int max_fd = 0;
#ifdef  ALLOW_INTRRUPTION
    if(server_fd>0){
      max_fd = server_fd;
      FD_SET(server_fd, &readfds);
    }
#endif
    for(int i=0; i<n; i++){
        supr_socket_conn_t *sc = dn_conns[i];
        int dn_fd = sc->fd;
        if(dn_fd > max_fd) max_fd = dn_fd;
        FD_SET(dn_fd, &readfds);
    }

    int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
    if(ns <= 0){
      if(ns==0) continue;
    }

#ifdef  ALLOW_INTRRUPTION
    if(server_fd>0 && FD_ISSET(server_fd, &readfds)){
      supr_socket_conn_t *clientConn = serverSocketAccept(serverConn);
      verbose_info("\033[0;34m[Driver:%s] clientConn->fd = %d\033[0m\n",
                          __func__, clientConn->fd);

      if(clientConn && clientConn->fd != -1){
            vectorAdd(socket_connections, clientConn);
      }
      int fd = clientConn->fd;
      fd_set _readfds;
      FD_SET(fd, &_readfds);
      int ns = select(fd+1, &_readfds, NULL, NULL, &tv);
      if(ns==1){
        int cmd;
	ssize_t n = recv(fd, &cmd, INT_SIZE, MSG_PEEK | MSG_DONTWAIT);
	if(n == INT_SIZE && cmd == SUPR_INTERRUPT){
	  printf("[%s] INTERRUPT: TODO\n", __func__);
	  /*
	  read(fd, &cmd, INT_SIZE);
	  int rc = 0;
	  write(fd, &rc, INT_SIZE);
	  */
	  handle_interrupt(clientConn);
          isInterrupted = TRUE;
          vectorAdd(errors, strdup("DFS_NAMENODE_INTERRUPTED"));
	  server_fd = -1;
	  //break;
	}
      }
    }
#endif
    for(int i=0; i < n; i++){
      supr_socket_conn_t *sc = dn_conns[i];
      int dn_fd = sc->fd;
      if(FD_ISSET(dn_fd, &readfds)){

        int rc;
        SocketConn_read(dn_fd, &rc, INT_SIZE);
        verbose_info("[%s:Read] Read rc: %d\n", __func__, rc);

        if(rc == -1){
	  int nerr;
          SocketConn_read(dn_fd, &nerr, INT_SIZE);
	  for(int j = 0; j<nerr; j++){
            char *err = SocketConn_readString(sc, NULL, 0);
            printf("[%s] Error: %s\n", __func__, err);
            char buf[256+strlen(err)];
            sprintf(buf, "%s (%s:%d)", err, sc->host, sc->port);
            vectorAdd(errors, strdup(buf));
            free(err);
	  }
        } 

        n--; for(; i<n; i++) dn_conns[i] = dn_conns[i+1];

	verbose_info("[INFO] %s: %d/%d\n", __func__, nDatanodes-n, nDatanodes);
        
        break;
      }
    }
  }



  if(vectorSize(errors)){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = vectorSize(errors);
    write(fd, &n, INT_SIZE);
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      //SocketConn_writeString(conn, err);
      FD_writeString(fd, err);
      free(err);
    }
  } else {
    int rc = 0;
    write(fd, &rc, INT_SIZE);
  }

  //pthread_setspecific(interruptThreadKey, NULL); // testing

  vectorDestroy(errors);
  vectorDestroy(att);

  ////
  /*
  cmd = DFS_DD_NULL;
  pthread_mutex_lock(backendConn->mutex);
    printf("[%s] write(backendConn->fd, %d, ...)\n", __func__, cmd);
    write(backendConn->fd, &cmd, INT_SIZE);
    conn->fd = conn->efd;
    write(backendConn->fd, &cmd, INT_SIZE);
  pthread_mutex_unlock(backendConn->mutex);

  free(task);
  */
  ////
}





/*
void handleDD_persistReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  vector_t *att = (vector_t *) dd->att;

  { // TODO
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    int rc = 0;
    write(sc->fd, &rc, INT_SIZE);
    dd->att = NULL; // free/destroy...
  }

}
*/



hashtable_t *infoEnvironment = NULL;

extern size_t SocketConn_writeSO(supr_socket_conn_t *sc, so_t *so);
extern so_t *SocketConn_readSO(supr_socket_conn_t *sc);
extern SEXP SocketConn_readRObject(supr_socket_conn_t *sc);


void handleDD_info(supr_socket_conn_t *conn)
{
  
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char topic[len];  // topic???
  read(fd,  topic, len);

  printf("\n[%s] topic: %s\n", __func__, topic);

  BEGIN_R_EVAL();

    SEXP args = PROTECT(SocketConn_readRObject(conn));
    //PrintValue(args);

  END_R_EVAL();

  // TODO

  so_t *ret;
  if(strcmp(topic, "datanodes")==0){
    int nDatanodes = 0;
    supr_socket_conn_t *dn_conns[vectorSize(socket_connections)];

    for(int i=0; i<vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc =  (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
      if(sc->type == DFS_DATANODE_CONN) dn_conns[nDatanodes++] = sc;
    }

    BEGIN_R_EVAL();
      SEXP val = PROTECT(allocVector(STRSXP, nDatanodes));
      for(int i=0; i<nDatanodes; i++) {
	String addr = String_new("%s:%d", SocketConn_addr(dn_conns[i]),
			dn_conns[i]->pid);
        SET_STRING_ELT(val,i, mkChar(addr->str));
	free(addr);
      }

      //PrintValue(val);
      
      size_t size;
      ret = SO_valueOf(val, &size);
      SocketConn_writeInt(conn, 0);
      SocketConn_writeSO(conn, ret);
      free(ret);

      UNPROTECT(1);
    END_R_EVAL();

  } else if(strcmp(topic, "NA")==0){
    int nDatanodes = 0;
    supr_socket_conn_t *dn_conns[vectorSize(socket_connections)];

    for(int i=0; i<vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc =  (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
      if(sc->type == DFS_DATANODE_CONN) dn_conns[nDatanodes++] = sc;
    }

    BEGIN_R_EVAL();
      SEXP dns = PROTECT(allocVector(STRSXP, nDatanodes));
      for(int i=0; i<nDatanodes; i++) {
	String addr = String_new("%s:%d", SocketConn_addr(dn_conns[i]),
			dn_conns[i]->pid);
        SET_STRING_ELT(dns,i, mkChar(addr->str));
	free(addr);
      }

      int n;
      char **keys = Hashtable_keySet(ddEnvironment, &n);
      qsort(keys, n, sizeof(char *), rjni_strcmp);
      SEXP ddSet = PROTECT(allocVector(STRSXP, n));
      for(int i=0; i<n; i++){
        SET_STRING_ELT(ddSet, i, mkChar(keys[i]));
      }

      SEXP val   = PROTECT(allocVector(VECSXP, 2));
      SEXP names = PROTECT(allocVector(STRSXP, 2));
      int k=0;
      SET_STRING_ELT(names, k, mkChar("datanodes"));
      SET_VECTOR_ELT(val, k++, dns);

      SET_STRING_ELT(names, k, mkChar("DDs"));
      SET_VECTOR_ELT(val, k++, ddSet);
      setAttrib(val, R_NamesSymbol, names);
      //PrintValue(val);
      
      size_t size;
      ret = SO_valueOf(val, &size);
      SocketConn_writeInt(conn, 0);
      SocketConn_writeSO(conn, ret);
      free(ret);

      UNPROTECT(4);
    END_R_EVAL();

  } else {
    char err[256];
    sprintf(err, "Unknown topic '%s'", topic);
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    SocketConn_writeString(conn, err);
  }
}




// handleDD_options
void handleDD_option(supr_socket_conn_t *conn)
{
  
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];  // topic???
  read(fd,  name, len);

  SEXP options = R_NilValue;

  printf("\n[%s]\n", __func__);
  so_t *ret;
  BEGIN_R_EVAL();

    SEXP args = PROTECT(SocketConn_readRObject(conn));
    PrintValue(args);

    SEXP call = PROTECT(LCONS(install("options"), args));
  
    int errorOccurred;
    
    options = PROTECT(R_simpleTryEval(call, R_GlobalEnv, &errorOccurred));
    PrintValue(options);
    if(errorOccurred){
      SocketConn_writeInt(conn, -1);
      SocketConn_writeString(conn, CHAR(STRING_ELT(options,0)));
      UNPROTECT(3);
    } else {
      size_t size;
      ret = SO_valueOf(options, &size);
      SocketConn_writeInt(conn, 0);
      SocketConn_writeSO(conn, ret);

      while(TYPEOF(args) != NILSXP){
	if(TYPEOF(TAG(args)) == SYMSXP){
          const char *tag = CHAR(PRINTNAME(TAG(args)));
	  if(strcmp(tag, "timeout")==0){
            timedwait_timeout = asInteger(CAR(args));
	  }
	}
	args = CDR(args);
      }
      UNPROTECT(3);
    }

  END_R_EVAL();

  return;
  // TODO

  if(infoEnvironment == NULL)
    infoEnvironment = newHashtable(FALSE);

#ifdef  DFS_DD_WAIT 
  vector_t *att = (vector_t *) Hashtable_get(infoEnvironment, name);
  if(!att) {
    att = newVector(FALSE);
    Hashtable_put(infoEnvironment, name, att);
  }
  vectorAdd(att, conn);
#endif


  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
        write(sc->fd, &cmd, INT_SIZE);
        write(sc->fd, &len, SIZE_SIZE);
        write(sc->fd, name, len);
//        write(sc->fd, &level, INT_SIZE);

#ifdef  DFS_DD_WAIT 
        vectorAdd(att, sc);
#endif

    }
  }

#ifndef  DFS_DD_WAIT 
  int rc = 0;
  write(fd,  &rc, INT_SIZE);
#endif
}

void handleDD_move(supr_socket_conn_t *conn)
{
  
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  char *name = SocketConn_readString(conn, NULL, 0);

  printf("\n[%s] name: %s\n", __func__, name);
  
  char *src = SocketConn_readString(conn, NULL, 0);
  char *dest = SocketConn_readString(conn, NULL, 0);
  printf("[%s] src: %s\n", __func__, src);
  printf("[%s] dest: %s\n", __func__, dest);

  free(name);
  name = src;

  {
    dd_t *dd = (dd_t *) Hashtable_get(ddEnvironment, name);
    if(dd){
      int rc = -1;
      write(fd, &rc, INT_SIZE);
      int n = 1;
      write(fd, &n, INT_SIZE);
      char err[256];
      sprintf(err, "'%s' is in use", src);
      SocketConn_writeString(conn, err);
      return;
    }
  }

  /*
  dd_t *dd = (dd_t *) Hashtable_get(ddEnvironment, name);
  if(!dd){
    dd = newDD(name);
    Hashtable_put(ddEnvironment, name, dd);
  }
  */

//#ifdef  DFS_DD_WAIT 
  vector_t *att = newVector(FALSE);
//  dd->att = att;
//  vectorAdd(att, conn);
//#endif

  int nDatanodes = 0;
  supr_socket_conn_t *dn_conns[vectorSize(socket_connections)];

  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
        write(sc->fd, &cmd, INT_SIZE);
	SocketConn_writeString(sc, name);
	SocketConn_writeString(sc, src);
	SocketConn_writeString(sc, dest);
        vectorAdd(att, sc);

	dn_conns[nDatanodes++] = sc;
    }
  }

  vector_t *errors = newVector(FALSE);
  {
    char old[strlen(src)+strlen("data/")+1];
    char new[strlen(dest)+strlen("data/")+1];
    sprintf(old, "data/%s", src);
    sprintf(new, "data/%s", dest);
    {
      char buf[PATH_MAX];
      getcwd(buf, PATH_MAX);
      printf("[%s] cwd: %s\n", __func__, buf);
    }
    int rc = rename(old, new);
    if(rc == -1) {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      vectorAdd(errors, strdup(strerror(errno)));
    }
  }

  int n = nDatanodes;
  while(n){
    struct timeval tv;
    fd_set readfds;

    tv.tv_sec=60;
    tv.tv_usec=0;

    FD_ZERO(&readfds);
      //FD_SET(fd, &readfds);
    int max_fd = 0;
    for(int i=0; i<n; i++){
        supr_socket_conn_t *sc = dn_conns[i];
        int dn_fd = sc->fd;
        if(dn_fd > max_fd) max_fd = dn_fd;
        FD_SET(dn_fd, &readfds);
    }

    int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
    if(ns <= 0){
      if(ns==0) continue;
    }

    for(int i=0; i < n; i++){
      supr_socket_conn_t *sc = dn_conns[i];
      int dn_fd = sc->fd;
      if(FD_ISSET(dn_fd, &readfds)){
        
	int rc;
	SocketConn_read(dn_fd, &rc, INT_SIZE);
	if(rc == -1){
          char *err = SocketConn_readString(sc, NULL, 0);

          printf("[%s] Error: %s\n", __func__, err);
              //vectorAdd(dd->att, err);
	  char buf[256+strlen(err)];
	  sprintf(buf, "%s (%s:%d)", err, sc->host, sc->port);
          vectorAdd(errors, strdup(buf));
	  free(err);
        }

	n--;
        for(; i<n; i++){
            dn_conns[i] = dn_conns[i+1];
        }
        break;
      }
    }
  }
  
  if(vectorSize(errors)){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = vectorSize(errors);
    write(fd, &n, INT_SIZE);
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      SocketConn_writeString(conn, err);
      free(err);
    }
  } else {
    int rc = 0;
    write(fd, &rc, INT_SIZE);
  }

  vectorDestroy(errors);
  vectorDestroy(att);
 // dd->att = NULL;


  //free(src); free(dest);

  /*
#ifndef  DFS_DD_WAIT 
  int rc = 0;
  write(fd,  &rc, INT_SIZE);
#else
  void *data[] = {conn, strdup("mv: Timeout"), dd, src, dest};
  //void **_data = malloc(sizeof(data));
  //memcpy(_data, data, sizeof(data));
  Timedwait_add(Timedwait_notifyTimeout, data, sizeof(data),
		  Timedwait_destroyDDMove); // free src and dest?
#endif
*/

  //free(src);
  //free(name); free(dest);

}







/*
void handleDD_infoReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  vector_t *att = (vector_t *) Hashtable_get(infoEnvironment, dd_name);

  { // TODO
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    int rc = 0;
    write(sc->fd, &rc, INT_SIZE);
  }

}
*/




void handleDD_optionReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  vector_t *att = (vector_t *) Hashtable_get(infoEnvironment, dd_name);

  { // TODO
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    int rc = 0;
    write(sc->fd, &rc, INT_SIZE);
  }

}




void handleDD_moveReturn(supr_socket_conn_t *conn)
{
  static char *err = NULL; // FIXME

  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  /*
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);
  */
  char *dd_name = SocketConn_readString(conn, NULL, 0);
  printf("\t[%s] dd_name: %s\n", __func__, dd_name);

  int rc;
  read(fd,  &rc, INT_SIZE);
  //char *err = NULL;
  if(rc == -1){
    err = SocketConn_readString(conn, NULL, 0);
    printf("\t[%s] Error: %s\n", __func__, err);
  }

  dd_t *dd = (dd_t *) Hashtable_get(ddEnvironment, dd_name);
  if(!dd){
    int n;
    char **keys = Hashtable_keySet(ddEnvironment, &n);
    for(int i=0; i<n; i++){
      printf("\t[%s] %d: %s\n", __func__, i, keys[i]);
    }
    free(keys);
  }
  vector_t *att = (vector_t*) dd->att;

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);
    int rc = 0;
    //write(sc->fd, &rc, INT_SIZE);
    pthread_mutex_lock(timedwait_queue->mutex);
    int i=vectorSize(timedwait_queue)-1; 
    for(; i>=0; i--) {
      nn_timedwait_t *event = vectorElementAt(timedwait_queue, i);
      void **data = (void **) event->data;
      if(data[2] == dd){
        conn = (supr_socket_conn_t*)  data[0];
	char *src = (char*) data[3];
	char *dest = (char*) data[4];
	data[3] = NULL;
	data[4] = NULL;

        vectorRemove(timedwait_queue, i);
	if(event->destroy)
	  event->destroy(event);

	if(err) {
          SocketConn_writeInt(conn, -1);
          SocketConn_writeString(conn, err);
	  err = NULL;
	} else {

	  char old[strlen(src)+strlen("data/")+1];
	  char new[strlen(dest)+strlen("data/")+1];
	  sprintf(old, "data/%s", src);
	  sprintf(new, "data/%s", dest); 
	  
	  { 
		  char buf[PATH_MAX];
		  getcwd(buf, PATH_MAX);
		  printf("[%s] cwd: %s\n", __func__, buf); 
	  } 
	  
	  int rc = rename(old, new);
	  SocketConn_writeInt(conn, rc);
	  if(rc == -1){
	    SocketConn_writeString(conn, strerror(errno));
	  } 
	}
	break;
      }
    }
    if(i<0) fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);

    pthread_mutex_unlock(timedwait_queue->mutex);
    dd->att = NULL; // free/destroy...
  }

  free(dd_name);

}




void handleDD_close(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

//  int save;
//  read(fd,  &save, INT_SIZE);


  dd_t *dd = Hashtable_get(ddEnvironment, name);

  if(!dd){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = 1;
    write(fd, &n, INT_SIZE);
    char err[256];
    sprintf(err, "Cannot find DD '%s'", name);
    SocketConn_writeString(conn, err);
    return;
  }

  vector_t *att = newVector(FALSE);
//  vectorAdd(att, conn);
//  dd->att = att;

  int nDatanodes = 0;
  supr_socket_conn_t *dn_conns[vectorSize(socket_connections)];

  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
        write(sc->fd, &cmd, INT_SIZE);
        write(sc->fd, &len, SIZE_SIZE);
        write(sc->fd, name, len);
//        write(sc->fd, &save, INT_SIZE);
        vectorAdd(att, sc);

	dn_conns[nDatanodes++] = sc;
    }
  }

  vector_t *errors = newVector(FALSE);
  {
    int rc;
    Hashtable_delete(ddEnvironment, name);
    if(rc == -1) {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      vectorAdd(errors, strdup(strerror(errno)));
    }
  }

  int n = nDatanodes;
  while(n){
    struct timeval tv;
    fd_set readfds;

    tv.tv_sec=60;
    tv.tv_usec=0;

    FD_ZERO(&readfds);
      //FD_SET(fd, &readfds);
    int max_fd = 0;
    for(int i=0; i<n; i++){
        supr_socket_conn_t *sc = dn_conns[i];
        int dn_fd = sc->fd;
        if(dn_fd > max_fd) max_fd = dn_fd;
        FD_SET(dn_fd, &readfds);
    }

    int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
    if(ns <= 0){
      if(ns==0) continue;
    }

    for(int i=n-1; i >= 0; i--) //for(int i=0; i < n; i++)
    {
      supr_socket_conn_t *sc = dn_conns[i];
      int dn_fd = sc->fd;
      if(FD_ISSET(dn_fd, &readfds)){

        int rc;
        SocketConn_read(dn_fd, &rc, INT_SIZE);
        if(rc == -1){
          char *err = SocketConn_readString(sc, NULL, 0);

          printf("[%s] Error: %s\n", __func__, err);
              //vectorAdd(dd->att, err);
          char buf[256+strlen(err)];
          sprintf(buf, "%s (%s:%d)", err, sc->host, sc->port);
          vectorAdd(errors, strdup(buf));
          free(err);
        }

        n--; for(; i<n; i++) dn_conns[i] = dn_conns[i+1];

	printf("[%s] %d/%d\n", __func__, nDatanodes -n , nDatanodes);
        
        //break;
      }
    }
  }

  if(vectorSize(errors)){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = vectorSize(errors);
    write(fd, &n, INT_SIZE);
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      SocketConn_writeString(conn, err);
      free(err);
    }
  } else {
    int rc = 0;
    write(fd, &rc, INT_SIZE);
  }

  vectorDestroy(errors);
  vectorDestroy(att);
}

/*
void handleDD_closeReturn(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  vector_t *att = (vector_t *) dd->att;


  { // TODO
    printf("\t[%s] %s //%s:%d\n", __func__, dd_name, 
                    conn->host, conn->port);
  }

  if(!vectorRemoveElement(att, conn)) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
  }

  if(vectorSize(att)==1){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(att, 0);

    Hashtable_delete(ddEnvironment, dd_name);

    int rc = 0;
    write(sc->fd, &rc, INT_SIZE);
    dd->att = NULL; // free/destroy...
  }

}
*/


void handleDD_get(supr_socket_conn_t *conn)
{
	/*
  if(Supr_debug){
    char buf[256];
    sprintf(buf, "[%s__]", __func__);
    Cluster_sendSimpleMessage(buf, "\033[0;34m", DEBUG_INFO_TYPE, 0);
  }
  */

  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  /*
  if(Supr_debug){
    char buf[256];
    sprintf(buf, "[%s] dd_name: %s", __func__, name);
    Cluster_sendSimpleMessage(buf, "\033[0;34m", DEBUG_INFO_TYPE, 0);
  }
  */
  verbose_info("[%s] dd_name: %s", __func__, name);

  int n;
  read(fd,  &n, INT_SIZE);

  char **_s_names = NULL;
  if(n>0){
    _s_names = (char**)malloc(n*sizeof(char*));
    for(int i=0; i<n; i++){
      read(fd, &len, SIZE_SIZE);
      _s_names[i] = (char*) malloc(len);
      read(fd, _s_names[i], len);
      /*
      if(Supr_debug){
        char buf[256];
        sprintf(buf, "[%s] %d: %s\n", __func__, i, _s_names[i]);
        Cluster_sendSimpleMessage(buf, "\033[0;34m", DEBUG_INFO_TYPE, 0);
      }
      */
      verbose_info("[%s] %d: %s\n", __func__, i, _s_names[i]);
    }
  }
 

  dd_t *dd = Hashtable_get(ddEnvironment, name);
  // handle error dd == null ...

  /*
  if(Supr_debug){
    char buf[256];
    sprintf(buf, "[%s] dd: <%p>", __func__, dd);
    Cluster_sendSimpleMessage(buf, "\033[0;34m", DEBUG_INFO_TYPE, 0);
  }
  */

  //if(n==1 && strcmp(_s_names[0], ".__NAMESPACE__.")==0){ }

  //vector_t *values = (vector_t*) Hashtable_get(dd->values, subset_name);

  //basic_info("[%s] dd: %p\n", __func__,  dd);

  if(dd){
	 

    int nDatanodes = 0;
    char *datanodeNames[vectorSize(socket_connections)];
    for(int i=0; i<vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc =  (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
      if(sc->type == DFS_DATANODE_CONN)
        datanodeNames[nDatanodes++] = SocketConn_addr(sc);
      //basic_info("nDatanodes: %d", nDatanodes);
    }

    //basic_info("nDatanodes: %d", nDatanodes);

    write(fd, &nDatanodes, INT_SIZE);

    for(int i=0; i< nDatanodes; i++)
      SocketConn_writeString(conn, datanodeNames[i]);

    unsigned char datanodes[nDatanodes];

    char **s_names = _s_names?_s_names : Hashtable_keySet(dd->values, &n);
    write(fd, &n, INT_SIZE);
    for(int i=0; i<n; i++){
      len = strlen(s_names[i])+1;
      write(fd,  &len, SIZE_SIZE);
      write(fd,  s_names[i], len);

      nn_value_t *subset = (nn_value_t *) Hashtable_get(dd->values, s_names[i]);

      memset(datanodes, 0, nDatanodes);
      if(subset){

	/*
        int nAddr = vectorSize(value->addr);
        write(fd,  &nAddr, INT_SIZE);
        for(int j=0; j<nAddr; j++){
	  char *addr = (char*) vectorElementAt(value->addr, j);
          len = strlen(addr)+1;
          write(fd,  &len, SIZE_SIZE);
          write(fd,  addr, len);
        }

        DD_stat_print(&value->stat);
        write(fd,  &value->stat, sizeof(dd_stat_t));
	*/
        int nAddr = vectorSize(subset->addr);
        for(int j=0; j<nAddr; j++){
	  char *addr = (char *) vectorElementAt(subset->addr, j);
	  for(int k=0; k<nDatanodes; k++){
          if(strcmp(addr, datanodeNames[k])==0)
                  datanodes[k] = 1;
          }
	}
      }// else { int nAddr = 0; write(fd,  &nAddr, INT_SIZE); }
      write(fd,  datanodes, nDatanodes);
    }

    if(_s_names){
      for(int i=0; i<n; i++) free(_s_names[i]);
    }
    free(s_names);

  } else {
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    char err[256];
    sprintf(err, "cannot find '%s' in the opened DDs", name);
    len = strlen(err)+1;
    write(fd, &len, SIZE_SIZE);
    write(fd, err, len);
  }

  /*
  if(Supr_debug){
    char buf[256];
    sprintf(buf, "[__%s]", __func__);
    Cluster_sendSimpleMessage(buf, "\033[0;34m", DEBUG_INFO_TYPE, 0);
  }
  */
}

void handleDD_exists(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  dd_t *dd = Hashtable_get(ddEnvironment, name);
  if(dd){
    int rc = TRUE;
    write(fd, &rc, INT_SIZE);
    return;
  }

  DIR *dir = __opendir__(name);
  if(dir){
    closedir(dir);
    int rc = TRUE;
    write(fd, &rc, INT_SIZE);
    return;
  }

  int rc = FALSE;
  write(fd, &rc, INT_SIZE);
}

void handleDD_remove(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  int recursive;
  read(fd,  &recursive, INT_SIZE);

  int rc = -1;

  {// check
    dd_t *dd = (dd_t *) Hashtable_get(ddEnvironment, name);
    if(dd){
      write(fd, &rc, INT_SIZE);
      int n = 1;
      write(fd, &n, INT_SIZE);
      char err[256];
      sprintf(err, "'%s' is in use", name);
      SocketConn_writeString(conn, err);
      return;
    }
  }

  if(strstr(name, "..")) {
    write(fd, &rc, INT_SIZE);
    int n = 1;
    write(fd, &n, INT_SIZE);
    char err[256];
    sprintf(err, "'name' contains '..'");
    SocketConn_writeString(conn, err);
    /*
    len = strlen(err)+1;
    write(fd, &len, SIZE_SIZE);
    write(fd, err, len);
    */
    return;
  }

  printf("[%s] recursive: %d\n", __func__, recursive);
  //vector_t *att = newVector(FALSE);

  supr_socket_conn_t *datanodes[vectorSize(socket_connections)];
  int n = 0;
  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc =  (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
      datanodes[n++] = sc;
      write(sc->fd, &cmd, INT_SIZE);
      SocketConn_writeString(sc, name);
      write(sc->fd, &recursive, INT_SIZE);
    }
  }

  vector_t *errors = newVector(FALSE);
  while(n) {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=60;
      tv.tv_usec=0;

      FD_ZERO(&readfds);
      //FD_SET(fd, &readfds);
      int max_fd = 0;
      for(int i=0; i<n; i++){
        supr_socket_conn_t *sc = datanodes[i];
        int dn_fd = sc->fd;
        if(dn_fd > max_fd) max_fd = dn_fd;
        FD_SET(dn_fd, &readfds);
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      }

      for(int i=0; i < n; i++){

        supr_socket_conn_t *sc = datanodes[i];
        int dn_fd = sc->fd;

        if(FD_ISSET(dn_fd, &readfds)){
          printf("\n\033[0;35m[%s] Read //%s:%d\033[0m\n", __func__,
		       	sc->host, sc->port);
          //while(TRUE){
		/*
            size_t slen;
            read(dn_fd, &slen, SIZE_SIZE);
            if(slen == 0) break;

            char s_name[slen];
            read(dn_fd, s_name, slen); // TODO
	    */

            int rc;
            SocketConn_read(dn_fd, &rc, INT_SIZE);
            printf("\t[%s] rc: %d\n", __func__, rc);
            if(rc == -1){
              char *err = SocketConn_readString(sc, NULL, 0);
              printf("\t[%s] Error: %s\n", __func__, err);
              //vectorAdd(dd->att, err);
              vectorAdd(errors, err);
            } /* else {
              nn_value_t *subset = (nn_value_t *) Hashtable_get(
                              dd->values, s_name);
              if(!subset) {
                subset = newNamenodeValue();
                Hashtable_put(dd->values, s_name, subset);
              }
              read(dn_fd, &subset->stat, sizeof(dd_stat_t));
              //vectorAdd(subset->addr, SocketConn_addr(sc));
              vectorAddIfNotExists(subset->addr, SocketConn_addr(sc),
                              wrapped_strcmp);
              //printf("[%s] %s: %ld\n", __func__, s_name, subset->stat.st_size);
            }*/
            //vectorRemoveElement(dd->att, sc);
          //}

          n--;
          for(; i<n; i++){
            datanodes[i] = datanodes[i+1];
          }
          break;
        }
      }
  }

  rc = __rmdir__(name, recursive);
  //printf("[%s] vectorSize(dd->att): %d\n", __func__, vectorSize(dd->att));
  if(rc == -1)
    vectorAdd(errors, strdup(strerror(errno)));

  if(vectorSize(errors)){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int n = vectorSize(errors);
    write(fd, &n, INT_SIZE);
    for(int i=vectorSize(errors)-1; i>=0; i--){
      char *err = (char*) vectorRemove(errors, i);
      SocketConn_writeString(conn, err);
      free(err);
    }
  } else {
    int rc = 0;
    write(fd, &rc, INT_SIZE);
  }

  vectorDestroy(errors);
  //vectorDestroy(att);
  //dd->att = NULL;

  Hashtable_delete(ddEnvironment, name);





  /*
  rc = __rmdir__(name, recursive);
  write(fd, &rc, INT_SIZE);
  if(rc == -1){
    char *err = strerror(errno);
    len = strlen(err)+1;
    write(fd, &len, SIZE_SIZE);
    write(fd, err, len);
  }
  */
}

static supr_thread_t *DT_thread = NULL;

void DT_thread_init(void *arg)
{
  sem_t *sem = (sem_t *) ((void **)arg)[0];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[1];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
                  (unsigned long) &sem);
  *sth = th;

  free(th->name);
  char name[256];
  sprintf(name, "DT.%d", gettid());
  th->name = strdup(name);
  th->state = THREAD_STATE_RUNNABLE;

  /*
  pthread_mutex_lock(sys_threads->mutex);
    vectorAdd(sys_threads, th);
  pthread_mutex_unlock(sys_threads->mutex);
  */

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);
}

void DT_thread_cleanup(void *data)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}


void *DT_thread_run(void *arg)
{
  pthread_cleanup_push(DT_thread_cleanup, NULL);

  // init:
  DT_thread_init(arg);
  //basic_info("DT_thread is ready ...");

  supr_thread_t *cth = SUPR_CURRENT_THREAD();

  // loop
  while(TRUE){
    //basic_info("Next tasks ...");
    while(TRUE){
      DT_thread_task_t *task = NULL;
      pthread_mutex_lock(DT_thread_tasks->mutex);
        if(vectorSize(DT_thread_tasks))
          task = (DT_thread_task_t *) vectorRemove(DT_thread_tasks,0);
      pthread_mutex_unlock(DT_thread_tasks->mutex);
      if(task == NULL) break;

      BEGIN_R_EVAL();
        //basic_info("eval: R_ToplevelExec(task->fun, task->data);");
        Rboolean success = R_ToplevelExec(task->fun, task->data);
        //basic_info("success: %d", success);
        if(!success) {
              error_info(R_curErrorBuf());
	      supr_socket_conn_t *conn = ((void **)task->data)[0];
	      if(conn){
                basic_info("conn: %s:%d", conn->host, conn->port);
	        int rc = -1;
	        write(conn->fd, &rc, sizeof(int));
		const char *err = R_curErrorBuf();
                basic_info("send error message: %d", err);
		int len = strlen(err)+1;
	        write(conn->fd, &len, sizeof(int));
	        write(conn->fd, err, len);
	      }
	} else {
	      supr_socket_conn_t *conn = ((void **)task->data)[0];
	      if(conn)
                basic_info("conn: %s:%d", conn->host, conn->port);
	}
      END_R_EVAL();
      free(task);
    }

    pthread_mutex_lock(&cth->mutex);
      int rc = pthread_cond_wait(&cth->cond, &cth->mutex);
    pthread_mutex_unlock(&cth->mutex);
  }


  pthread_cleanup_pop(TRUE);
  return NULL;
}

supr_thread_t *startDT_thread()
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&sem, &sth};
  int rc = pthread_create(&thread, NULL, DT_thread_run, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  return sth;
}

/*
typedef struct DT_thread_task_struct {
  void (*fun)(void *);
  void *data;
} DT_thread_task_t;
*/

extern SEXP Rf_deparse1m(SEXP call, Rboolean abbrev, int);
// from Defn.h
#define DEFAULTDEPARSE          1089


static void Check_deparse2(SEXP x, int line)
{
//   caller_info(1);
//   caller_info(2);
        if(strstr(Supr_hostname, "liu2")) return;
      SEXP expr = Rf_deparse1m(x, 0, DEFAULTDEPARSE);
      //basic_info("typeof(expr): %s", type2char(TYPEOF(expr)));
      //basic_info("deparsed expr: \"%s\"", CHAR(asChar(expr)));
      //basic_info("length(expr): %d", LENGTH(expr));
      for(int i=0; i<LENGTH(expr); i++){
        basic_info("[\033[0;34m%d\033[0m] [%d]: %s", line, i+1,
                        CHAR(STRING_ELT(expr, i)));
        if(i>=4) {
          basic_info("...");
          break;
        }
      }
}
#define Check_deparse(x) Check_deparse2((x), __LINE__)



extern SEXP Rf_deparse1m(SEXP call, Rboolean abbrev, int);
// from Defn.h
#define DEFAULTDEPARSE          1089


void DDT_exec(void *data)
{
//  void **data = {call, x};
//  basic_info("OKAY -1");
  SEXP call = (SEXP) ((void**)data)[0];
//  Check_deparse(call);
  //SEXP x = (SEXP) ((void**)data)[1];
  so_t *s = (so_t *) ((void**)data)[1];

  if(s->obj_type == SUPR_ERROR){
    if(s->size){
      //error_info("\033[0;31mError occurred:\033[0m"); 
      SEXP err = SO_toRObject(s+1, s->size);
      //error_info("\033[0;33mError occurred:\033[0m"); 
      //Check_deparse(err);
      if(TYPEOF(err) != STRSXP)
	      error(_("FIXME: wrong error message object type ..."));

      int len = 1;
      for(int i=0; i<LENGTH(err); i++)
        len += strlen(CHAR(STRING_ELT(err, i))) + strlen(ERROR_SEPARATOR);

      char str_err[len];
      str_err[0] = 0;
      for(int i=0; i<LENGTH(err); i++)
        sprintf(str_err + strlen(str_err), "%s%s", CHAR(STRING_ELT(err, i)),
			i == LENGTH(err)-1 ? "":ERROR_SEPARATOR);
      
      error(_("%s"), str_err);
    }
  }

  SEXP x = SO_toRObject(s, sizeof(so_t)+s->size);
  SEXP cntxt_env = (SEXP) ((void**)data)[2];
  SEXP args = CDDR(call);
  //Check_deparse(args);
  SEXP env = args;
  for(int i=0; i<3; i++){
    //basic_info("i = %d", i);
    //Check_deparse(env);
    if(env == R_NilValue) break;
    env = CDR(env);
  }
  //basic_info("OKAY -0.5");
  //Check_deparse(env);
  env = CAR(env);
  //Check_deparse(env);
  //basic_info("OKAY 0");
  if(TYPEOF(env) != ENVSXP){
    error_info("obbject 'env' not found, FIXME");
    error(_("object 'env' not found"));
  }
  //basic_info("OKAY 1");

  SET_ENCLOS(env, SuprEnv);
  int nUNPROTECT = 0;
  // i:

  args = CDR(args);
  // j:

  //  group:
  args = CDR(args);
  if(CAR(args) == R_NilValue){
      SEXP v = findVar(install(".group..value"), cntxt_env);
      if(v == R_UnboundValue) v = R_NilValue;

      x = PROTECT(CONS(x, v));
      supr_socket_conn_t *sc = (supr_socket_conn_t *) ((void**)data)[3];
      char buf[strlen(sc->host)+64];
      sprintf(buf, "%s:%d", sc->host, sc->port);
      SET_TAG(x, install(buf));

      defineVar(install(".group..value"), x, cntxt_env);
      UNPROTECT(1);
  } else {
    SEXP expr = CAR(args);
    //Check_deparse(expr);
    //basic_info("typeof(group expr): %s", type2char(TYPEOF(expr)));

    if(TYPEOF(expr) == SYMSXP || TYPEOF(expr) == STRSXP){
      const char *fun_name = TYPEOF(expr) == SYMSXP ?  CHAR(PRINTNAME(expr)):
              CHAR(STRING_ELT(expr,0));
      expr = PROTECT(LCONS(install(fun_name), R_NilValue));
      nUNPROTECT ++;
    } else if(TYPEOF(expr) == CLOSXP) { // testing ...
      expr = PROTECT(LCONS(expr, R_NilValue));
      nUNPROTECT ++;
//      basic_info("group. typeof(expr[?call]): %s", type2char(TYPEOF(expr)));
    } else if(TYPEOF(expr) == LANGSXP) {
      SEXP fun = CAR(expr);
//      basic_info("group. typeof(fun[????]): %s", type2char(TYPEOF(fun)));
      if(TYPEOF(fun) == SYMSXP) {
//        basic_info("\033[0;32mgroup. typeof(fun[????]): symbol=%s\033[0m", CHAR(PRINTNAME(fun)));
        //Check_deparse(fun);
        // function(){}() doesn't work, but (function(){})() ...
        if(strcmp(CHAR(PRINTNAME(fun)), "function")==0){
          expr = PROTECT(LCONS(expr, R_NilValue));
          nUNPROTECT ++;
        }
      }
    } else
      error(_("invalid 'group' argument"));


    //if(TYPEOF(expr) == LANGSXP){ // special functions

      SEXP v = findVar(install(".group..value"), cntxt_env);
      if(v == R_UnboundValue) v = R_NilValue;

      SEXP args = CDR(expr);

      SEXP y = PROTECT(CONS(x, CONS(v, R_NilValue)));
      SET_TAG(y, install("x"));
      SET_TAG(CDR(y), install("value"));
      setAttrib(y, R_ClassSymbol, mkString("DD.frame")); // the class of x

      SEXP new_expr = PROTECT(LCONS(CAR(expr), CONS(y, args)));
      //SETCAR(args, x);
      //Check_deparse(new_expr);

      //SEXP g_call = PROTECT(LCONS(install("with"), CONS(x, CONS(new_expr, R_NilValue))));

      //Check_deparse(g_call);
      //SEXP g = PROTECT(eval(g_call, env));
      SEXP g = PROTECT(eval(new_expr, env));

      //SETCAR(CDR(g_call), mkString("*"));
      //SETCAR(CDDR(g_call), mkString("*"));
      //Check_deparse(g_call);
      //SETCDR(CDR(new_expr), R_NilValue);
      //Check_deparse(new_expr);
      //Check_deparse(expr);
      x = g;
      setAttrib(x, R_ClassSymbol, mkString("DD.value")); // the class of x
      defineVar(install(".group..value"), x, cntxt_env);
      //basic_info("typeof(group): %s", type2char(TYPEOF(g)));
      //Check_deparse(x);
      nUNPROTECT += 3;
    //}
   /* else if(TYPEOF(expr) == SYMSXP || TYPEOF(expr) == STRSXP){ // special functions
      const char *cmd = TYPEOF(expr) == SYMSXP ?  CHAR(PRINTNAME(expr)):
              CHAR(STRING_ELT(expr,0));
      if(strcmp(cmd, ".n")==0){
        int n = asInteger(x);
        basic_info("found special function: `%s`, x: %d", cmd, n);
        SEXP s = findVar(install(".group..n"), cntxt_env);
        if(s != R_UnboundValue) n += asInteger(s);
        x = ScalarInteger(n);
        defineVar(install(".group..n"), x, cntxt_env);
        basic_info("found special function: `%s`, -> x: %d", cmd, n);
      } else {
                error_info("FIXME");
                error(_("Not implemented"));
      }
    } else {
      SEXP g_call = PROTECT(LCONS(install("with"), CONS(x, CONS(expr,
                                            R_NilValue))));
      //Check_deparse(g_call);
      SEXP g = PROTECT(eval(g_call, env));
      basic_info("typeof(group): %s, length: %d", type2char(TYPEOF(g)), LENGTH(g));
      nUNPROTECT += 2;
    }
    */
  }



  /*
  SEXP c = getAttrib(x, R_ClassSymbol);
  if(c!=R_NilValue && strcmp(CHAR(STRING_ELT(c,0)), "data.frame")==0)
  {
    SEXP names = getAttrib(x, install("row.names"));
    if(names == R_NilValue && LENGTH(x)>0){
      int n = LENGTH(VECTOR_ELT(x, 0));
      names = PROTECT(allocVector(STRSXP, n));
      nUNPROTECT += 1;
      setAttrib(x, install("row.names"), names);
      char buf[64];
      for(int i=0; i<n; i++) {
        sprintf(buf, "%d", i+1);
        SET_STRING_ELT(names, i, mkChar(buf));
      }
    }
//    fprintf(stdout, "After 4:\n");
//    PrintValue(x);
  }
  */

  if(Supr_options.verbose) {
    SEXP res = PROTECT(CONS(x, R_NilValue));
    SET_TAG(res, install("value"));
    basic_info("typeof(group result): %s", type2char(TYPEOF(x)));
    Check_deparse(res);
    UNPROTECT(1);
  }

  ((void**)data)[1] = x;
  UNPROTECT(nUNPROTECT);
}


void DDT_cancel(supr_socket_conn_t **dn_conns, int nconn)
{
    for(int i=0; i<nconn; i++){
      supr_socket_conn_t *sc = dn_conns[i];
      if(sc){ // ...
        //basic_info("inform '%s:%d' ... TODO", sc->host, sc->port);
	sc = socketOpen2(sc->host, sc->port);
	if(sc){
          int cmd = DFS_DDT_CALL_CANCEL;
	  write(sc->fd, &cmd, sizeof(int));
	  int rc;
	  read(sc->fd, &rc, sizeof(int));
	  close(sc->fd); // FIXME
	  free(sc);
	}
      }
    }
}

// change it to: void DT_thread_DDT_call(void *data)
void DT_thread_DDT_call(void *data)
{
  void **args = (void**) data;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) args[0];
  unsigned long long_id = (unsigned long) args[1];
  int nbytes = (int) ((unsigned long) args[2]);
  void *bytes = args[3];

  int isCancelled = FALSE;

  //basic_info("long_id: %ld", long_id);
  //{
    char var_name[256];
    sprintf(var_name, ".__DT.Call.%ld__.", long_id);
  //}
  //basic_info("%s. var_name: %s", __func__, var_name);

  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  vector_t *connections = (vector_t *) cth->properties;
  SEXP array = R_NilValue;
  int var_len;

  //BEGIN_R_EVAL();
    SEXP dt_call = findVar(install(var_name), SuprJobEnv);
    if(dt_call != R_UnboundValue){
      /*SEXP expr = Rf_deparse1m(dt_call, 0, DEFAULTDEPARSE);
      basic_info("typeof(expr): %s", type2char(TYPEOF(expr)));
      basic_info("deparsed expr: \"%s\"", CHAR(asChar(expr)));
      basic_info("length(expr): %d", LENGTH(expr));
      for(int i=0; i<LENGTH(expr); i++){
        basic_info("[%d]: %s", i+1, CHAR(STRING_ELT(expr, i)));
      }
      */

      // Rinternals.h:SEXP	 Rf_lcons(SEXP, SEXP);
      SEXP s =  dt_call;
      int n=0;
      while(TYPEOF(s) == LANGSXP){
	n++;
        //basic_info("[%d] LANGSXP: `%s` with args:", n, TYPEOF(CAR(s))==SYMSXP?  CHAR(PRINTNAME(CAR(s))):"?");
        SEXP args = CDR(s);
	/*
        SEXP expr = Rf_deparse1m(args, 0, DEFAULTDEPARSE);
        for(int i=0; i<LENGTH(expr); i++){
          basic_info("[%d]: %s", i+1, CHAR(STRING_ELT(expr, i)));
        }
        basic_info("\nnames(args)[1]: `%s`", CHAR(PRINTNAME(TAG(args))));
	*/
	s = CAR(args); 
      }
      //basic_info("chain depth: %d", n);

      var_len = n;
      array = PROTECT(allocVector(VECSXP, n));
      s =  dt_call;
      n = 0;
      while(TYPEOF(s) == LANGSXP){
        SET_VECTOR_ELT(array, n++, s);
        SEXP args = CDR(s);
	s = CAR(args); 
      }
      defineVar(install(var_name), array, SuprJobEnv);
      UNPROTECT(1);

    } else {
      error_info("object '%s' not found", var_name);
    }
  //END_R_EVAL();

      //basic_info("typeof(array): %s", type2char(TYPEOF(array)));
      //basic_info("LENGTH(array): %d", LENGTH(array));
      if(TYPEOF(array) == NILSXP || LENGTH(array)==0){
        //basic_info("cannot find opened DD '%s'", dd_name);
        char err[256];
        sprintf(err, "invalid DD, no name");
        //writeError(conn->fd, err);
	int rc = -1;
	write(conn->fd, &rc, sizeof(int));
	int len = strlen(err)+1;
	write(conn->fd, &len, sizeof(int));
	write(conn->fd, err, len);
	{ // FIXME?
		args[0] = NULL;
	}
        return;
      }

      SEXP x = CADR(VECTOR_ELT(array, LENGTH(array)-1));
      //basic_info("typeof(first x): %s", type2char(TYPEOF(x)));
      const char *dd_name = NULL;
      if(TYPEOF(x) == SYMSXP){ // the dflt case
        dd_name = CHAR(PRINTNAME(x));
      } else {
        dd_name = CHAR(asChar(x));
      }
      //basic_info("strval(x) or dd_name: %s", dd_name);


      for(int i=0; i<vectorSize(connections); i++){
         supr_socket_conn_t *sc = (supr_socket_conn_t *)
		 vectorElementAt(connections, i);

	 //
	 int cmd = CLUSTER_PING;
	 write(sc->fd, &cmd, sizeof(int));
	 int rc;
	 read(sc->fd, &rc, sizeof(int));
	 //basic_info("PING('%s:%d'): %d, rc: %d", sc->host, sc->port, cmd, rc);
	 //

	 cmd = DFS_DDT_CALL;
	 write(sc->fd, &cmd, sizeof(int));
	 //basic_info("write %ld (bytes)", sizeof(int));
	 write(sc->fd, &nbytes, sizeof(int));
	 //basic_info("write nbytes: %d", nbytes);
	 ssize_t size = write(sc->fd, bytes, nbytes);
	 //basic_info("wrote %ld bytes", size);
	 read(sc->fd, &rc, sizeof(int));
	 //basic_info("DDT_CALL('%s:%d'): %d, rc: %d", sc->host, sc->port, cmd, rc);
      }

      dd_t *dd = NULL;
      pthread_mutex_lock(ddEnvironment->mutex);
        dd = Hashtable_get(ddEnvironment, dd_name);
      pthread_mutex_unlock(ddEnvironment->mutex);

      if(!dd){
        //basic_info("cannot find opened DD '%s'", dd_name);
        char err[256];
        sprintf(err, "cannot find opened DD '%s'", dd_name);
        //writeError(conn->fd, err);
	int rc = -1;
	write(conn->fd, &rc, sizeof(int));
	int len = strlen(err)+1;
	write(conn->fd, &len, sizeof(int));
	write(conn->fd, err, len);
	{ // FIXME?
		args[0] = NULL;
	}
        return;
      }

      int nconn = vectorSize(connections);
      supr_socket_conn_t *dn_conns[nconn];
      void *datanodes[nconn][3];
      for(int i=0; i<nconn; i++){
        supr_socket_conn_t *sc =  (supr_socket_conn_t *)
              vectorElementAt(connections, i);
        dn_conns[i] = sc;
        datanodes[i][0] = SocketConn_addr(sc);
        //basic_info("\tSocketConn_addr(sc): %s", (char*) datanodes[i][0]);
        datanodes[i][1] =  sc;
      }
      qsort(datanodes, nconn, 3*sizeof(char*), dd_strcmp);

      /*
      int nkeys;
      char **keys = Hashtable_keySet(dd->values, &nkeys); // lock?
      for(int i=0; i < nkeys; i++){ // use more efficient scheme later ...
        nn_value_t *nn_val = (nn_value_t*) Hashtable_get(dd->values, keys[i]);
	int n_src = vectorSize(nn_val->addr);
	char *src_addr = vectorElementAt(nn_val->addr, random() % n_src);
        basic_info("\t%s -> (random chosen)src_addr: %s\n", keys[i], src_addr);
      }
      free(keys);
      */
      int nkeys;
      char **keys = Hashtable_keySet(dd->values, &nkeys); // lock?
     


      /*
      for(int k=LENGTH(array)-1; k>=0;  k--){
        SEXP call = VECTOR_ELT(array, k);
        basic_info("[%d] call: `%s` with args:", k+1,
	       	TYPEOF(CAR(call))==SYMSXP?  CHAR(PRINTNAME(CAR(call))):"?");
        SEXP args = CDR(call);
	if(k < LENGTH(array) - 1){
          basic_info("(`%s` = *,", CHAR(PRINTNAME(TAG(args))));
	  args = CDR(args);
	} 
        SEXP expr = Rf_deparse1m(args, 0, DEFAULTDEPARSE);
        for(int i=0; i<LENGTH(expr); i++){
          basic_info("\t: %s", CHAR(STRING_ELT(expr, i)));
        }


	//
      }
      */


  PROTECT_INDEX cntxt_pi;
  SEXP eval_cntxt = allocSExp(ENVSXP);
  PROTECT_WITH_INDEX(eval_cntxt, &cntxt_pi);
  SET_ENCLOS(eval_cntxt, R_EmptyEnv);
  SEXP EVAL_ERROR = eval_cntxt;
  //BEGIN_R_EVAL();
  //END_R_EVAL();


  for(int k=LENGTH(array)-1; k>=0;  k--){

  basic_info("k: %d", k);

    int iter = LENGTH(array)-1 - k;

    SEXP val = findVar(install("value"), eval_cntxt);
    int nsubsets = 0;
    int errorOccurred = FALSE;

    if(Supr_options.verbose){

        SEXP call = VECTOR_ELT(array, k);
        basic_info("\033[0;32mNEXT %d. call: `%s` with args:", k+1,
	       	TYPEOF(CAR(call))==SYMSXP?  CHAR(PRINTNAME(CAR(call))):"?");
        SEXP args = CDR(call);
	if(k < LENGTH(array) - 1){
          basic_info("\033[0;32m\t(`%s` = *,", CHAR(PRINTNAME(TAG(args))));
	  args = CDR(args);
	} 
        SEXP expr = Rf_deparse1m(args, 0, DEFAULTDEPARSE);
        for(int i=0; i<LENGTH(expr); i++){
          basic_info("\033[0;32m\t: %s", CHAR(STRING_ELT(expr, i)));
        }
    }


    // first subset, if any...
    int res_count = 0;

    for(int i=0; i<nconn; i++){
      supr_socket_conn_t *sc = dn_conns[i];
      int fd = sc->fd;

      if(iter == 0){
        if(keys){
          if(k < LENGTH(array)-1) error_info("\033[0;31mFIXME\033[0m");

	  char *subset_name = NULL;
          for(int i = nkeys - 1; i>=0; i--){
            nn_value_t *nn_val = (nn_value_t*) Hashtable_get(dd->values, keys[i]);
	    int n_src = vectorSize(nn_val->addr);
	    for(int j=0; j < n_src; j++){
	      char *addr = (char*) vectorElementAt(nn_val->addr, j);
              if(strncmp(addr+2, sc->host, strlen(sc->host))==0){
	        subset_name = keys[i];
	        break;
	      }
	    }
	    if(subset_name){
	      char uri_name[256];
	      sprintf(uri_name, "//%s#%s#%s", sc->host, dd_name, subset_name); 
	      verbose_info("\033[0;31m[k:%d] uri_name: %s\033[0m", k+1, uri_name);
              so_t subset = {0,0,0,SUPR_URI,strlen(uri_name)+1};
              write(fd, &subset, sizeof(so_t));
              write(fd, uri_name, strlen(uri_name)+1);
              res_count++;

              for(int j = i+1; j<nkeys; j++)
	        keys[j-1] = keys[j];

	      nkeys--;
	      if(nkeys==0) {
		    free(keys);
		    keys = NULL;
	      }
	      break;
	    }
	  }
	  if(!subset_name){
	    basic_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
                so_t subset = {0,0,0,0,0};
	        write(fd, &subset, sizeof(so_t));
            res_count++;
	  }
        } else {
	    basic_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
                so_t subset = {0,0,0,0,0};
	        write(fd, &subset, sizeof(so_t));
            res_count++;
        }
      }
      else if(val != R_UnboundValue){ // a list object?
        //basic_info("[Check]. typeof(val): %s", type2char(TYPEOF(val)));
        if(TYPEOF(val) == VECSXP){
          //basic_info("[Check]. length(val): %d, nsubsets: %d", LENGTH(val), nsubsets);
          // take it to be  a list of subsets ...
	  if(nsubsets < LENGTH(val)){
	    SEXP subset = VECTOR_ELT(val, nsubsets++);
	    size_t size;
	    so_t *so = SO_valueOf(subset, &size);
	    //write(fd, so, sizeof(so_t));
	    //write(fd, so + 1, so->size);
	    write(fd, so, size);
	  } else {
	    basic_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
            so_t subset = {0,0,0,0,0};
	    write(fd, &subset, sizeof(so_t));
	  }
        } else { // error
          error_info("\033[0;31mFIXME, expected a list object\033[0m");
	 // error(_("expected a list object"));
          errorOccurred = TRUE; // thread-safe message?
          so_t subset = {0,0,0,SUPR_ERROR,0};
	  write(fd, &subset, sizeof(so_t));
          defineVar(install("errors"), mkString("expected a list object"),
                                        eval_cntxt);
	  if(!isCancelled){
            DDT_cancel(dn_conns, nconn);
	    isCancelled = TRUE;
	  }

	  /*
	  basic_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
          so_t subset = {0,0,0,0,0};
	  write(fd, &subset, sizeof(so_t));
	  */

	  break;
        }
        res_count++;
      }
      else {
	    basic_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
                so_t subset = {0,0,0,0,0};
	        write(fd, &subset, sizeof(so_t));
            res_count++;
      }
    }

    int nres = res_count;
    so_t *res[res_count];

    //{
      SEXP S_err = PROTECT(findVar(install("errors"), eval_cntxt));
      eval_cntxt = allocSExp(ENVSXP);
      REPROTECT(eval_cntxt, cntxt_pi);
      SET_ENCLOS(eval_cntxt, R_EmptyEnv);
      EVAL_ERROR = eval_cntxt;
      if(S_err != R_UnboundValue) {
        defineVar(install("errors"), S_err, eval_cntxt);
      }
      UNPROTECT(1);
    //}

    //nconn = res_count;

    while(res_count>0) {
      struct timeval tv;
      tv.tv_sec=300;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      int max_fd = 0;
      for(int i=0; i<nconn; i++){
        supr_socket_conn_t *sc = dn_conns[i];
        int fd = sc->fd;
        FD_SET(fd, &readfds);
        if(fd > max_fd) max_fd = fd;
      }

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
        if(ns==0) continue;
	else {
            error_info("FIXME: %s", strerror(errno));
	    pthread_exit(NULL);
        }
      }

      for(int i=0; i<nconn; i++){
        supr_socket_conn_t *sc = dn_conns[i];
	int fd = sc->fd;
        if(!FD_ISSET(fd, &readfds)) continue;

        int cmd;
        ssize_t size = read(fd, &cmd, sizeof(int));
	if(size != sizeof(int)) {
            error_info("FIXME: %s", strerror(errno));
	    pthread_exit(NULL);
	}

	switch(cmd){
          case TR_NEXT_SUBSET:
	      {
	        if(errorOccurred){
                  so_t subset = {0,0,0,SUPR_ERROR,0};
		  break;
	        } 
		
		if(iter==0){
		  if(keys){
	      	    char *subset_name = NULL;
		    for(int i = nkeys - 1; i>=0; i--){
		      nn_value_t *nn_val = (nn_value_t*)
			    Hashtable_get(dd->values, keys[i]);
		      int n_src = vectorSize(nn_val->addr);
		      for(int j=0; j < n_src; j++){
		        char *addr = (char*) vectorElementAt(nn_val->addr, j);
		        if(strncmp(addr+2, sc->host, strlen(sc->host))==0){
			      subset_name = keys[i];
			      break;
		        }
		      }
		      if(subset_name){
		        char uri_name[256];
		        sprintf(uri_name, "//%s#%s#%s", sc->host, dd_name, subset_name); 
		        so_t subset = {0,0,0,SUPR_URI,strlen(uri_name)+1};
		        write(fd, &subset, sizeof(so_t));
		        write(fd, uri_name, strlen(uri_name)+1); 
		      
		        for(int j = i+1; j<nkeys; j++)
			      keys[j-1] = keys[j]; 
		        nkeys--;
		     
		        if(nkeys==0) {
			      free(keys);
			      keys = NULL;
		        }
		        break;
		      }
		    }
		    if(!subset_name){
		      //basic_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
		      so_t subset = {0,0,0,0,0};
		      write(fd, &subset, sizeof(so_t));
		    }
	       	  } else {
		    //basic_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
		    so_t subset = {0,0,0,0,0};
		    write(fd, &subset, sizeof(so_t));
		  }
		} // iter 
                else if (val != R_UnboundValue && TYPEOF(val) == VECSXP
				) {
                  //basic_info("[Check]. typeof(val): %s", type2char(TYPEOF(val)));
	          if(nsubsets < LENGTH(val)){
                    //basic_info("[Check]. length(val): %d, nsubsets: %d", LENGTH(val), nsubsets);
		    SEXP subset = VECTOR_ELT(val, nsubsets++);
		    size_t size;
		    so_t *so = SO_valueOf(subset, &size);
		    //write(fd, so, sizeof(so_t));
		    //write(fd, so + 1, so->size);
		    write(fd, so, sizeof(so_t) + so->size);
		  } else {
		    verbose_info("\033[0;31m[k:%d] NO MORE DATA\033[0m", k+1);
		    so_t subset = {0,0,0,0,0};
		    write(fd, &subset, sizeof(so_t));
		  }
	       	} else {
        	  error_info("\033[0;31mFIXME, expected a list object\033[0m");
		  // error(_("expected a list object"));
		  errorOccurred = TRUE; // thread-safe message?
		  so_t subset = {0,0,0,SUPR_ERROR,0};
		  write(fd, &subset, sizeof(so_t));
		  DDT_cancel(dn_conns, nconn);

	       	}
	      }
	      break;

          case TASK_RESULTS:
	      {
	        verbose_info("[k:%d] %s: TASK_RESULTS, res_count: %d", k+1,
			      sc->host,res_count);
                so_t so;
	       	ssize_t size = read(fd, &so, sizeof(so_t));
		so_t *s = (so_t *)malloc(sizeof(so_t)+so.size);
	       	memcpy(s, &so, sizeof(so_t));
	       	if(so.size>0)
		       	size = read(fd, s+1, so.size);

	        //basic_info("read: %ld bytes", size);
		//int rc = 0; // no more subsets...
	        //write(fd, &rc, sizeof(int));
		res_count--;
		res[res_count] = s; // FREE...

		if(so.size>0){
		  void *data[] = {VECTOR_ELT(array, k), s, eval_cntxt, sc};
		  Rboolean success = R_ToplevelExec(DDT_exec, data);
		  verbose_info("_ToplevelExec(DDT_exec, data): \033[0;31m%s\033[0m",
                                  success?"SUCCESS":"FAILURE");
		  if(!success) {  // FIXME, error handling ...
                    basic_info("Error: %s", R_curErrorBuf());

                    SEXP err = findVar(install("errors"), eval_cntxt);
                    if(err == R_UnboundValue)
                      defineVar(install("errors"), mkString(R_curErrorBuf()),
                                              eval_cntxt);
                    else {
                      int n=LENGTH(err);
                      SEXP new_err = PROTECT(allocVector(STRSXP, n+1));
                      for(int i=0; i<n; i++)
                        SET_STRING_ELT(new_err, i, STRING_ELT(err, i));
                      SET_STRING_ELT(new_err, n, mkChar(R_curErrorBuf()));
                      defineVar(install("errors"), new_err, eval_cntxt);
                    }

                    defineVar(install("value"), EVAL_ERROR, eval_cntxt);
		    if(!isCancelled) {
		      DDT_cancel(dn_conns, nconn);
		      isCancelled = TRUE;
		    }

                  } else {
                    defineVar(install("value"), (SEXP) data[1], eval_cntxt);
		  }
		}
		//

	      }
	      break;
	  default:
	      error_info("unknown cmd: %d", cmd);
	      break;

	}

	if(res_count==0) break;

      }
      if(res_count==0) break;

    }

    if(errorOccurred) break;
  }

  UNPROTECT(1); // eval_cntxt
  //END_R_EVAL();

  SEXP errors = findVar(install("errors"), eval_cntxt);

  int fd = conn->fd;

  if(errors != R_UnboundValue) {
    basic_info("send errors ...");
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    int len = 0;
    int n = LENGTH(errors);
    for(int i=0; i<n; i++) 
      len += strlen(CHAR(STRING_ELT(errors, i))) + strlen(ERROR_SEPARATOR);

    char err[len+1];
    err[0] = '\0';
    for(int i=0; i<n; i++) 
      sprintf(err + strlen(err), "%s%s", CHAR(STRING_ELT(errors, i)),
		      ERROR_SEPARATOR);
    basic_info("send errors: %s", err);
    len = strlen(err)+1;
    write(fd, &len, INT_SIZE);
    write(fd, err, len);
    { // FIXME?
      args[0] = NULL;
    }
    return;
  }

  SEXP val = findVar(install("value"), eval_cntxt);
  if(val == EVAL_ERROR) error_info("Unexpected value, FIXME");

  basic_info("send value ...");

  /*
  if(val == R_UnboundValue){ //
    int recv_frame = FALSE;
   //     BEGIN_R_EVAL();
          SEXP call = VECTOR_ELT(array, 0);
          SEXP args = CDR(call); // skip `[....`
          args = CDR(args); // skip x
          args = CDR(args); // skip i
          args = CDR(args); // skip j
          if(CAR(args) == R_NilValue){
            recv_frame = TRUE;
            basic_info("\033[0;31msave the final result to '.LastValue'???\033[0m");
	  }
  //      END_R_EVAL();
    if(!recv_frame) return;

    SEXP val = PROTECT(CONS(R_NilValue, R_NilValue));
    for(int i=0; i<nconn; i++){
      supr_socket_conn_t *sc = dn_conns[i];
      so_t so;
      read(sc->fd, &so, sizeof(so_t));
      so_t *s = malloc(sizeof(so_t) + so.size);
      memcpy(s, &so, sizeof(so_t));
      read(sc->fd, s+1, so.size); 
      int rc = 0;
      write(sc->fd, &rc, sizeof(int));

      SEXP x = SO_toRObject(s, sizeof(so_t)+s->size);
      if(x != R_UnboundValue && x != R_NilValue) { //??? can UnboundValue be serialized???
        SEXP t = PROTECT(CDR(val));
	SETCDR(val, x);
        SEXP s = val;
	while(CDR(s) != R_NilValue) s = CDR(s);
	SETCDR(s, t);
	UNPROTECT(1);
      }

    }

    defineVar(install(".LastValue"), CDR(val), SuprEnv);
    val = CDR(val);
    UNPROTECT(1);
  }
  */

	  // FIXME: what to do for large objects???

  Rboolean success = R_ToplevelExec(Supr_serialize1, &val);
  PROTECT(val);
  int len = LENGTH(val);
  write(fd, &len, INT_SIZE);
  write(fd, RAW(val), len);
  UNPROTECT(1);
  { // FIXME?
    args[0] = NULL;
  }
}

void handleDDT_call(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd; read(fd, &cmd, INT_SIZE);

  static unsigned long count = 0;

  Rboolean success;
  unsigned char *bytes = NULL;
  int nbytes = 0;

  BEGIN_R_EVAL();
    int len; read(fd, &len, INT_SIZE);
    SEXP raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);
    { // testing...
      nbytes = LENGTH(raw);
      bytes = malloc(nbytes);
      memcpy(bytes, RAW(raw), nbytes);
    }
    success = R_ToplevelExec(Supr_unserialize1, &raw);
    if(success) {
      PROTECT(raw);
      //basic_info("typeof(expr): %s",type2char(TYPEOF(raw)));
      UNPROTECT(1);
    }
    char var_name[256];
    sprintf(var_name, ".__DT.Call.%ld__.", count);
    //basic_info("var_name: %s", var_name);
    defineVar(install(var_name), raw, SuprJobEnv);
    UNPROTECT(1);
  END_R_EVAL();

  if(!success) {
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    rc = strlen(R_curErrorBuf())+1;
    write(fd, &rc, INT_SIZE);
    write(fd, R_curErrorBuf(), rc);
    return;
  }

  if(!DT_thread) {
    DT_thread_tasks = newVector(TRUE);

    DT_thread = startDT_thread();
    vectorAdd(threads, DT_thread);

    vector_t *connections = newVector(FALSE);
    for(int i=0; i<vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc =  (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
      if(sc->type == DFS_DATANODE_CONN){
        supr_socket_conn_t *c = socketOpen2(sc->host, sc->port);
	if(c) vectorAdd(connections, c);
      }
    }
    pthread_mutex_lock(&DT_thread->mutex);
      DT_thread->properties = connections;
    pthread_mutex_unlock(&DT_thread->mutex);

    basic_info("started the DDT_call handler thread %d", DT_thread->tid);
  }

  {
    DT_thread_task_t *task = malloc(sizeof(DT_thread_task_t) + 4*sizeof(void*));
    void **data = (void **) (task+1);

    data[0] = conn;
    data[1] = (void*)((unsigned long) count);
    data[2] = (void*)((unsigned long) nbytes);
    data[3] = bytes;
    task->data = (task+1);
    task->fun = DT_thread_DDT_call;
    pthread_mutex_lock(DT_thread_tasks->mutex);
      vectorAdd(DT_thread_tasks, task);
    pthread_mutex_unlock(DT_thread_tasks->mutex);

    pthread_mutex_lock(&DT_thread->mutex);
      pthread_cond_signal(&DT_thread->cond);
    pthread_mutex_unlock(&DT_thread->mutex);
  }
  count++;

  /*
  { // delete me ...
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    char *err = "[dfs_name] Not Implemented ...";
    rc = strlen(err)+1;
    write(fd, &rc, INT_SIZE);
    write(fd, err, rc);
    return;
  }

  write(fd, &nbytes, INT_SIZE);
  write(fd, bytes, nbytes);
  */
}

void handle_interrupt(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd; read(fd, &cmd, INT_SIZE);

  supr_thread_t *cth = currentThread();

  printf("[%s] INTERRUPTED (pid:%d, tid:%d)\n", __func__, cth->pid,
		  cth->tid);

  printf("threads: %s\n", (char*) Object_toString(threads));

  for(int i=0; i<vectorSize(threads); i++){
    supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);
    pthread_kill(th->ptid, SIGUSR2);
  }

  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    if(sc->type == DFS_DATANODE_CONN){
      int sc_fd = socket_client(sc->host, sc->port);
      printf("[%s] connected to: //%s:%d, fd: %d\n", __func__, sc->host,
                  sc->port, sc_fd);
      int cmd = SUPR_INTERRUPT;
      if(sc_fd != -1){
        write(sc_fd, &cmd, INT_SIZE);

        int rc;
        read(sc_fd, &rc, INT_SIZE);
        printf("[%s] rc: %d\n", __func__, rc);
        close(sc_fd);
      }
    }
  }
  
  int rc = 0;
  write(fd, &rc, INT_SIZE);
}

void startLocalDatanode()
{
  printf("[%s]\n", __func__);
  errno = 0;
  int rc = isatty(STDOUT_FILENO);
  if(errno) {
	  printf("[%s] Error: %s STDOUT_FILENO: %d (%s:%d)\n", __func__,
			  strerror(errno), STDOUT_FILENO,
			  __FILE__, __LINE__);
	  return;
  }
  if(rc){
    char buf[PATH_MAX];
    int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
    if(rc) {
	  printf("[%s] Error: %s (%s:%d)\n", __func__, strerror(errno),
			  __FILE__, __LINE__);
	  return;
    }
    printf("ttyname: %s\n", buf);
  }
    
#define USE_XTERM 1
  pid_t pid = fork();
  if(pid) 
    return;

  SocketConn_closeAll(socket_connections, 0);
  
  pid = getpid();
  char DFS_CMD_PATH[PATH_MAX];
  {
        sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src");
        chdir(DFS_CMD_PATH);
  }

  sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src/dfs_data");

  char *dir_name = "00"; //to do
  if(USE_XTERM && rc){ 
    char *argv[] = {
          DFS_CMD_PATH,
          "-dir", dir_name,
          (char*) NULL
      };
    supr_xterm_t *xterm = supr_xterm2("DFS_datanode", argv);
    if(xterm) {
      printf("[%s] run dfs_data: xterm =  %p\n", __func__, xterm);
    } else {
      printf("[%s] run dfs_data: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
    }

    exit(0);

  } else {
    int rc = execl(DFS_CMD_PATH, "dfs_data",
                  "-dir", dir_name,
                  (char*) NULL);
    printf("[%s] run dfs_data: rc =  %d, %s\n", __func__, rc, strerror(errno));
  }

}

extern supr_xterm_t *supr_xterm3(const char *window_name, char **argv,
                int window);

//static char *err_msg = NULL;

extern int Supr_waitpid(const char *tmp_out, const char *tmp_err,
        const char *sock_addr, pid_t pid, int *status, const char *X11);

//void
int startRemoteDatanode(char *addr, int argc, char **argv)
{
  char buf[strlen(addr)+1];
  strcpy(buf, addr);
  //char *hostname = strstr(buf, "//") + 2; // Check ...
  char *hostname = strstr(buf, "//") ? strstr(buf, "//") + 2 : buf;
  int port = -1;

  char *s = NULL;
  if(hostname){
    s = strstr(hostname, ":");
    *s = 0; s++;
    port = atoi(s);
  } else {
    // hostname = Supr_hostname;
    return -1; // NULL;
  }

  basic_info("\033[0;36m%s(%s:%d%s)\033[0m", __func__, hostname, port,
  	s && strchr(s, '+')?"+":"");

  /*
  {
    char buf[1024];
    snprintf(buf, 1024, "%s: %s:%d", __func__, hostname, port);
    Cluster_sendSimpleMessage(buf, "\033[0;34m", 0, 0);
  }
  */


  int rc;

  char shm_name[256];
  sprintf(shm_name, "%s-%d-dfs_name-%d", shm_prefix, getpid(), __LINE__);

  int fd = shm_open(shm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  if(fd == -1){
        shm_unlink(shm_name);
	return -1;
//        errorcall(R_NilValue, "[%s:%d:%s] shm_open(%s) %s", __FILE__, __LINE__, __func__, shm_name, strerror(errno));
  }

  size_t segment_size = sysconf(_SC_PAGE_SIZE);
  rc = ftruncate(fd, segment_size);
  if(rc != 0) {
	  return rc;
//    error(_("[%s:%d:%s] ftruncate(%s), %s\n"), __FILE__, __LINE__, __func__, shm_name, strerror(errno));
  }

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    error(_("[%s:%d:%s] mmap(%s), %s\n"),
                __FILE__, __LINE__, __func__, shm_name, strerror(errno));
  }
  close(fd);

  sem_t *sem = (sem_t*) mem_ptr;
  rc = sem_init(sem, 1, 0);
  if(rc == -1){
	  return rc;
//    error(_("[%s:%d:%s] sem_init(%s, 1, 0), \n"), __FILE__, __LINE__, __func__, shm_name, strerror(errno));
  }

  sprintf((char*)(sem+1), "pid: %d", getpid());


  const char *format = "bash -c 'source .suprrc;"
        " $SUPR_SYS_HOME/bin/dfs_data -X11 %s"
	" -namenode %s %s %s %s %s %s -notify %s -level %d'";

  size_t len = strlen(format) + 128+ 8*PATH_MAX; //+strlen(R_home);
  char ssh_exec_arg[len];

	char namenode[strlen(serverConn->host)+16];
        sprintf(namenode, "%s:%d", serverConn->host, serverConn->port);

  sprintf(ssh_exec_arg, format,
                 X11_str? X11_str : "_",
                 namenode, 
		 Supr_debug? "--debug":"",
		 Supr_verbose? "--verbose":"",
		 Supr_infov? "--info":"", 
		 info_addr ? "-info" : "", 
		 info_addr ? info_addr: "",
		 namenode, Supr_options.level
		);

  

  Cluster_sendSimpleMessage(__func__, "\033[0;34m", DEBUG_INFO_TYPE, 0);
  Cluster_sendSimpleMessage(addr, "\033[0;34m", DEBUG_INFO_TYPE, 0);
  Cluster_sendSimpleMessage(ssh_exec_arg, "\033[0;34m", DEBUG_INFO_TYPE, 0);

  pid_t pid = fork();
  if(pid == -1) return -1; // error(_("fork, %s"), strerror(errno));

  if(pid) {

    pthread_mutex_lock(&Supr_syncMutex);
    double time_elapsed = 0.0;

        sem_post(sem);

        isWaitingForDatanode = TRUE;
        double timeout = Supr_options.timeout;
	struct timespec wait;
	clock_gettime(CLOCK_REALTIME, &wait);
	double save_time = wait.tv_sec + wait.tv_nsec/1000000000.0;
	timeout += save_time;

	wait.tv_sec = (long) floor(timeout);
	wait.tv_nsec = (long) (1000000000*(timeout - floor(timeout)));
	
	Supr_syncObject = NULL;

        pthread_cond_timedwait(&Supr_syncCond, &Supr_syncMutex, &wait);
        isWaitingForDatanode = FALSE;

    pthread_mutex_unlock(&Supr_syncMutex);

    {
        char *addr = (char*) Supr_syncObject;
	
        char buf[1024];
	clock_gettime(CLOCK_REALTIME, &wait);
	save_time -= wait.tv_sec + wait.tv_nsec/1000000000.0;
	time_elapsed = -save_time;

	int connected = addr && strstr(addr,":") &&
	       	time_elapsed < Supr_options.timeout;


        snprintf(buf, 1024, "\033[0;32m%s dfs_data@%s (in %g sec.)\033[0m",
	    connected ?  "Started": "\033[0;31mFailed to start\033[0m",
		hostname, -save_time);
        Cluster_sendSimpleMessage(buf, "\033[0;34m",
			connected ?  BASIC_INFO_TYPE:ERROR_INFO_TYPE,
		       	0);
    
	/*
        snprintf(buf, 1024, "\033[0;31m[%d] parent proc: %d, child proc: %d\033[0m\n", __LINE__, getpid(), pid);
        Cluster_sendSimpleMessage(buf, "\033[0;34m", 0, 0);
	*/
    }

    /*
    Cluster_sendSimpleMessage((char*)(sem+1), msg_color, 0, 0);

    int val;
    rc = sem_getvalue(sem, &val);
    {
        char buf[256];
	sprintf(buf, "sem_getvalue(sem, &val): %d, val: %d", rc, val);
        Cluster_sendSimpleMessage(buf, msg_color, 0, 0);
        Cluster_sendSimpleMessage((char*)(sem+1), msg_color, 0, 0);
    }
    */

    int status;
    rc = waitpid(pid, &status, 0);
    /*
    fprintf(stderr,
        "P [%s] waitpid(pid=%d, &status, 0): %d, status: %d (%s:%d)\n",
           __func__, pid, rc, status, __FILE__, __LINE__ );
	   */

    //int val;
    /*
    rc = sem_getvalue(sem, &val);
    {
        char buf[256];
	sprintf(buf, "sem_getvalue(sem, &val): %d, val: %d", rc, val);
        Cluster_sendSimpleMessage(buf, msg_color, 0, 0);
        Cluster_sendSimpleMessage((char*)(sem+1), msg_color, 0, 0);
    }
    */
    sem_destroy(sem);
    munmap(mem_ptr, segment_size);
    shm_unlink(shm_name);

    if(time_elapsed >= Supr_options.timeout) {
      //error(_("cannot start dfs_data at %s:%d"), hostname, port); 
//      err_msg = malloc(strlen(hostname)+256);
 //     sprintf(err_msg, "cannot start dfs_data at %s:%d", hostname, port); 
      return -1;
    }
    return 0;
  }


  // use void *supr_shm_open(const char *cshm_name, size_t *size) ...
  //{
  // char shm_name[256];
  //  sprintf(shm_name, "SUPR_DFSNAME_%d", getppid());
    fd = shm_open(shm_name, O_RDWR, 0600);
    if(fd == -1){
        fprintf(stderr, "[%s:%d:%s] shm_open(%s) %s (pid: %d)",
	       	__FILE__, __LINE__, __func__, shm_name, strerror(errno),
		getpid());
        shm_unlink(shm_name);
	exit(EXIT_FAILURE);
    }

    //segment_size = sysconf(_SC_PAGE_SIZE);
    struct stat statbuf;
    rc = fstat(fd, &statbuf);
    if(rc == -1) {
       fprintf(stderr, "[%s:%d:%s] fstat(%s), %s (pid: %d)\n",
	      __FILE__, __LINE__, __func__, shm_name, strerror(errno),
	      getpid());
	exit(EXIT_FAILURE);
    }

    segment_size = statbuf.st_size;

    /*
    rc = ftruncate(fd, segment_size);
    if(rc != 0) {
       fprintf(stderr, "[%s:%d:%s] ftruncate(%s), %s (pid: %d)\n",
	      __FILE__, __LINE__, __func__, shm_name, strerror(errno),
	      getpid());
	exit(EXIT_FAILURE);
    }
    */

    mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
    if(mem_ptr == MAP_FAILED) {
      fprintf(stderr, "[%s:%d:%s] mmap(%s), %s (pid: %d)\n",
	      __FILE__, __LINE__, __func__, shm_name, strerror(errno),
	      getpid());
	exit(EXIT_FAILURE);
    }
    close(fd);

    sem = (sem_t*) mem_ptr;
    //rc = sem_init(sem, 1, 0);
    if(rc == -1){
      fprintf(stderr, "[%s:%d:%s] mmap(%s), %s (pid: %d)\n",
	      __FILE__, __LINE__, __func__, shm_name, strerror(errno),
	      getpid());
	exit(EXIT_FAILURE);
    }

    int val;
    rc = sem_getvalue(sem, &val);
    fprintf(stderr, "[%s:%d:%s] sem_getvalue(%s, ...): %d, pid: %d\n",
	      __FILE__, __LINE__, __func__, shm_name, val, getpid());
    fprintf(stderr, "[%s:%d:%s] (char*) (sem+1) %s\ngetppid(): %d\n",
	      __FILE__, __LINE__, __func__, (char*) (sem+1), getppid());


    sem_wait(sem);
    //sem_post(sem);
    //sem_post(sem);
    //munmap(mem_ptr, segment_size);
  //}
  info_sc = NULL; 

 
  fprintf(stderr, "\033[0;32m[%d] Child proc: %d\033[0m\n", __LINE__, getpid());
  sprintf((char*)(sem+1), "\033[0;32m[%d] Child proc: %d\033[0m\n", __LINE__, getpid());
  

  rc = setsid();
  
  fprintf(stderr, "[%d] setsid(): %d, error: %s\n", __LINE__, rc, rc==-1? strerror(errno) : "Success");


  char tmp_out[256];
  char tmp_err[256];
  sprintf(tmp_out, "dfs_data-init-%d.out", getpid());
  sprintf(tmp_err, "dfs_data-init-%d.err", getpid());

  int out_fd = open(tmp_out, O_WRONLY| O_CREAT | O_TRUNC, 0600);
  int err_fd = open(tmp_err, O_WRONLY| O_CREAT | O_TRUNC, 0600);

  pid = fork();
  //if(pid == -1) error(_("fork, %s"), strerror(errno));
  if(pid == -1) {
    fprintf(stderr, "[%s:%d:%s] fork, %s\n", __FILE__, __LINE__, __func__,
		    strerror(errno));
    //sem_post(sem);
    sprintf((char*)(sem+1),
		    "[%s:%d:%s] fork, %s\n", __FILE__, __LINE__, __func__,
		    strerror(errno));
    munmap(mem_ptr, segment_size);
    exit(EXIT_FAILURE);
  }

  info_sc = NULL;
  if(info_addr) info_sc = socketOpen1(info_addr);

  if(pid) {
      int status;
      errno = 0;
      /*
      fprintf(stderr, "C [%s (%s:%d)] waitpid: Wait %d\n", __func__, __FILE__,
                      __LINE__, pid);
      rc = waitpid(pid, &status, 0);
      fprintf(stderr, "C (%s:%d) waitpid(%d, ...), rc: %d, err: %s\n",
                      __FILE__, __LINE__, pid, rc, strerror(errno));
      */
      int rc = Supr_waitpid(tmp_out, tmp_err, namenode, pid, &status, X11_str);
      exit(EXIT_SUCCESS);
  } else { // FIXME... path to ssh
      //rc = execl("/usr/bin/ssh", "ssh", hostname, ssh_exec_arg, (char *) NULL);
      dup2(out_fd, STDOUT_FILENO);
      dup2(err_fd, STDERR_FILENO);

      fprintf(stderr, "CC [INFO] localhost: %s\n", Supr_hostname);

      if(   strcmp(hostname, Supr_hostname) == 0
         || strcmp(hostname, "localhost") == 0) {

        char path[strlen(Supr_sysHome) + strlen("/bin/dfs_name")+2];
        sprintf(path, "%s/bin/dfs_data",  Supr_sysHome);
        char port_str[32];
        sprintf(port_str, "%d", port);
        char min_port_str[32];
        sprintf(min_port_str, "%d", Supr_options.port);
	char namenode[strlen(serverConn->host)+16];
        sprintf(namenode, "%s:%d", serverConn->host, serverConn->port);

        char level_str[32];
        sprintf(level_str, "%d", Supr_options.level);

        rc = execl(path, path, "-namenode", namenode,
		 //"-db", debug_addr,
		 Supr_debug? "--debug":"",
		 Supr_verbose? "--verbose":"",
		 Supr_infov? "--info":"",
		 "-info", info_addr,
		 "-notify", namenode,
		 "-level", level_str,
                 (char *) NULL);
      } else {
        fprintf(stderr, "CC [INFO] ssh -Y %s %s\n", hostname, ssh_exec_arg);

        rc = execl("/usr/bin/ssh", "ssh", "-Y", hostname, ssh_exec_arg, (char *) NULL);
      }

      fprintf(stderr, "[[CC]] rc: %d, error: %s\n", rc,  strerror(errno));
  }
  fprintf(stderr, "Whoops: ppid: %d, pid:%d\n", getppid(), getpid());
  error(_("[%s:%d:%s] Whoops: ppid: %d, pid:%d"),
     __FILE__, __LINE__, __func__, getppid(), getpid());

  return -1 ; // not reached

}

//void startRemoteDatanodes(int argc, char **argv)
void startRemoteDatanodes(void *data)
{
  void **args = (void **)data;
  int argc = *((int*) args[0]);
  char **argv = (char **) args[1];
  //if(Supr_debug) sleep(10);

  char cn_file[PATH_MAX];
  //sprintf(cn_file, "%s/conf/nodes", SUPR_DFS_HOMEUSR);
  sprintf(cn_file, "%s/supr.conf", SUPR_DFS_HOMEUSR);

  int rc = access(cn_file, R_OK);
  if(rc == -1){ // FIXME
    strcpy(cn_file, SUPR_DFS_HOMEUSR);
    char *s = cn_file;
    s = strstr(s, "/");
    while(s){
      s++;
      sprintf(s, "supr.conf");
      if((rc = access(cn_file, R_OK))==0)
	      break;
      strcpy(cn_file, SUPR_DFS_HOMEUSR);
      s = strstr(s, "/");
    }
    if(rc==0) Cluster_sendSimpleMessage(cn_file, "\033[0;34m", 0, 0);
  }
  int fd = open(cn_file, O_RDWR, 0600);
  struct stat sb;
  if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {

        char buf[sb.st_size+1];
        read(fd, buf, sb.st_size);
        close(fd);

	char *name = "Datanode";

        buf[sb.st_size] = 0;
        //fprintf(stdout, "conf/node, %s\n", buf);
        char *line = strtok(buf, "\n");
        char *namenode_line = NULL;
        while(line){
          for(; line; line++)
		  if(!isspace(*line)) break;
	  if(!line) continue;

          if(strncmp(line, name, strlen(name))==0)
          {
            //namenode_line = line;
	    //printf("\033[0;34m%s: %s\033[0m\n", name, line);
	    int rc = startRemoteDatanode(line, argc, argv);
	    /*
	    if(rc != 0){
		    warning(_("cannot start dfs datanode %s ..."), line);
	    }
	    */

//            break;

          }
          line = strtok(NULL, "\n");
        }

        //fprintf(stdout, "%s: %s\n", name, namenode_line);
	/*
        if(namenode_line){
          line = strstr(namenode_line, "//");
          if(line) line = strstr(line+2, ":");
          if(line) line += 1;
          if(line) port = atoi(line);
        }
	*/
        //fprintf(stdout, "%s: //*:%d\n", name, port);

  } else {
        //fprintf(stdout, "Error: %s, %s\n", cn_file, strerror(errno));
    char buf[strlen(cn_file)+strlen(strerror(errno))+32];
    sprintf(buf, "Error: %s, %s\n", cn_file, strerror(errno));
    Cluster_sendSimpleMessage(buf, "\033[0;34m", 0, 0);
  }

 
}

void handleGetContext(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd; read(fd, &cmd, INT_SIZE);

  /*
  int n = 0;
  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    printf("[%s] sc->type: %d\n", __func__, sc->type);
    if(sc->type == DFS_DATANODE_CONN){
	    n++;
    }
  }
  */

  so_t *so = NULL;
  BEGIN_R_EVAL();
    char buf[256];
    sprintf(buf, "//%s:%d", serverConn->host, serverConn->port);
    SEXP val = PROTECT(CONS(mkString(buf), R_NilValue));
    SET_TAG(val, install("Namenode"));
    SEXP s = val;
    for(int i=0; i<vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
      printf("[%s] sc->type: %d\n", __func__, sc->type);
      if(sc->type == DFS_DATANODE_CONN){
	//char buf[256];
	sprintf(buf, "//%s:%d", sc->host, sc->port);
        SETCDR(s, CONS(mkString(buf), R_NilValue));
	s = CDR(s);
	SET_TAG(s, install("Datanode"));
      }
    }

    size_t size;
    so = SO_valueOf(val, &size);
    UNPROTECT(1);

  END_R_EVAL();

  write(fd, so, sizeof(so_t) + so->size);

}

/*
void startDatanode(int argc, char **argv)
{
//  startLocalDatanode();
  startRemoteDatanodes(argc, argv);
}
*/

void startWorkers(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd; read(fd, &cmd, INT_SIZE);

  int nWorkers;     read(fd, &nWorkers, INT_SIZE);

  size_t len;       read(fd, &len, SIZE_SIZE);
  char master[len]; read(fd, &master, len);

  printf("[%s] cmd: %d, nWorkers: %d, len: %ld, master: %s\n", __func__,
                  cmd, nWorkers, len, master);


  int nDatanodes = 0;
  for(int i=0; i<vectorSize(socket_connections); i++){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
	    vectorElementAt(socket_connections, i);
    printf("[%s] sc->type: %d\n", __func__, sc->type);
    if(sc->type == DFS_DATANODE_CONN){
      nDatanodes++;
      int sc_fd = socket_client(sc->host, sc->port);
      printf("[%s] connected to: //%s:%d, fd: %d\n", __func__, sc->host,
                  sc->port, sc_fd);
      if(sc_fd != -1){
        write(sc_fd, &cmd, INT_SIZE);
        write(sc_fd, &nWorkers, INT_SIZE);

	write(sc_fd, &len, SIZE_SIZE);
	write(sc_fd, &master, len);

        int rc;
        read(sc_fd, &rc, INT_SIZE);
        printf("[%s] rc: %d\n", __func__, rc);

	int close_cmd = CLOSE_CONN;
	write(sc_fd, &close_cmd, INT_SIZE);
        close(sc_fd);
      }
    }
  }

  /*
  if(nDatanodes == 0)
  {
    startRemoteDatanodes(0, NULL); // on the local machine
//    pending_cmd = cmd;
  }
  */
}

#undef read

extern const char *cmd2char(int);

void handleCommand(supr_socket_conn_t *conn)
{
  int fd = conn->fd;


  int cmd = -1;
  {
    char buf[1024];
    size_t len = 0;
    for( ;len < INT_SIZE; ) {
      ssize_t n = recv(fd, &cmd, INT_SIZE-len, MSG_PEEK | MSG_DONTWAIT);
      if(n <= 0){

	if(Supr_options.verbose){
          sprintf(buf, "\033[0;31m%d::recv [%s] conn(fd: %d) is disconnected "
                "(len=%ld, n: %ld), type:%d (%s)\033[0m\n\n", getpid(),
	       	__func__,
	       	conn->fd, len, n, conn->type, connTypeToStr(conn->type));
          verbose_info(buf);
	}
	
	if(conn->type == DFS_DATANODE_CONN) 
          SocketConn_info(0, "Datanode:://%s:%d:%d is disconnected", conn->host,
			  conn->port, conn->pid);

        close(conn->fd);
        vectorRemoveElement(socket_connections, conn);
	// connDestroy();
        return;
      }
      len += n;
    }


    if(Supr_options.debug || Supr_options.verbose){
      sprintf(buf, "%d::recv [%s] size = %ld, cmd = %d (%s) from //%s:%d (fd: %d, type: %d (%s))",
                   getpid(), __func__, len, cmd, cmd2char(cmd),
		   conn->host, conn->port, conn->fd, conn->type,
		   connTypeToStr(conn->type));

      basic_info(buf);
    }

  }

//#define DRIVER_REGISTER 11 
//#define DRIVER_CONN 3
  switch(cmd){
    case DRIVER_REGISTER:
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   conn->type = DRIVER_CONN;
	   conn->port = msg[1];
	   sendDriverInfoToWorkers(conn);

	   basic_info("driver '%s:%d' is connected",
			   conn->host, conn->port);
	 }
         return; //break;

    case WORKER_REGISTER:
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   conn->type = WORKER_CONN;
	   conn->port = msg[1];

	   sendDriverInfoTo(conn);

	   basic_info("worker '%s:%d' is connected",
			   conn->host, conn->port);
	 }
         return; //break;

    case CLUSTER_DFSDATANODE_STARTED:
	 {
	   size_t size = read(fd, &cmd, sizeof(int));
           int len;
           read(fd, &len, sizeof(int));
           char addr[len];
           read(fd, addr, len);
           int rc = 0;
           write(fd, &rc, sizeof(int));

	   debug_info("CLUSTER_DFSDATANODE_STARTED: %s, isWaitingForDatanode: %d", addr, isWaitingForDatanode);

	   pthread_mutex_lock(&Supr_syncMutex);
	     if(isWaitingForDatanode) {
	       Supr_syncObject = strdup(addr);
	       pthread_cond_signal(&Supr_syncCond);
	     }
	   pthread_mutex_unlock(&Supr_syncMutex);
	  
	 }
         return; //break;

    case DFS_DATANODE_REGISTER:
	 {
	   int msg[2];
           ssize_t size = read(fd, msg, sizeof(msg));
	   conn->type = DFS_DATANODE_CONN;
	   conn->port = msg[1];
           size = read(fd, &conn->pid, INT_SIZE);

	   char *cwd = SocketConn_readString(conn, NULL, 0);

	   sendDriverInfoTo(conn);

           //SocketConn_info(0, "Datanode:://%s:%d:%d/%s is connected", conn->host, conn->port, conn->pid, cwd);
	   //printf("[%s] cwd: %s\n", __func__, cwd);
	   String dn_location = String_new("%s/%s", conn->host, cwd);
	   char *addr = SocketConn_addr(conn);
	   Hashtable_put(dn_locations, strdup(dn_location->str),
			  String_new("%s", addr));
	   //String_destroy(dn_location);
	   Hashtable_put(dn_locations, addr, dn_location);

	   free(cwd);

	   //printf("dn_locations: %s\n", Object_toString(dn_locations));
	   //printf("getClass(dn_location): %s\n", getClass(dn_location)->name);
	   //printf("getClass(dn_locations): %s\n", getClass(dn_locations)->name);

           cmd = INFO_REGISTER;
           write(conn->fd, &cmd, INT_SIZE);

	   verbose_info("datanode '%s:%d' is connected",
			   conn->host, conn->port);
	 }
         return; //break;

	 /*
    case SET_VERBOSE:  // from the info server
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   int rc = 0;
	   Supr_verbose = msg[1];
           write(conn->fd, &rc, INT_SIZE);

	   for(int i=0; i<vectorSize(socket_connections); i++){
             supr_socket_conn_t *sc = vectorElementAt(socket_connections, i);
	     if(sc->type == DFS_DATANODE_CONN){
	       write(sc->fd, msg, sizeof(msg));
	       //read(sc->fd, msg, sizeof(int));
	     }
	   }
	 }
         return; //break;

    case SET_DEBUG:  // from the info server
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   int rc = 0;
	   Supr_debug = msg[1];
           write(conn->fd, &rc, INT_SIZE);

	   for(int i=0; i<vectorSize(socket_connections); i++){
             supr_socket_conn_t *sc = vectorElementAt(socket_connections, i);
	     if(sc->type == DFS_DATANODE_CONN){
	       write(sc->fd, msg, sizeof(msg));
	       //read(sc->fd, msg, sizeof(int));
	     }
	   }
	 }
         return; //break;
	 */

    case CLUSTER_SET_OPTIONS:
         {
           read(fd, &cmd, sizeof(int));
           supr_options_t options;
           read(fd, &options, sizeof(supr_options_t));
           //{
             Supr_options.info = options.info;
             Supr_options.debug = options.debug;
             Supr_options.verbose = options.verbose;
             //Supr_options.port = options.port;
             Supr_options.level = options.level;
             Supr_options.timeout = options.timeout;
           //}
           int rc = 0;
           write(fd, &rc, INT_SIZE);

           for(int i=vectorSize(socket_connections)-1; i >= 0; i--){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
                        vectorElementAt(socket_connections, i);
               if(sc->type == DFS_DATANODE_CONN){

                  write(sc->fd, &cmd, sizeof(int));
                  write(sc->fd, &options, sizeof(supr_options_t));
                  int rc = read(sc->fd, &rc, sizeof(int));
               }
           }
         }
         return;
	 
    case INFO_REGISTER:  // from the info server
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   conn->type = INFO_CONN;
	   info_level = msg[1];

	   int port; // info server port
           read(fd, &port, sizeof(int));
	   //info_fd = conn->fd;
	   int rc=0;
	   write(conn->fd, &rc, INT_SIZE);


           pthread_mutex_lock(&Supr_syncMutex);
	     info_sc = socketOpen2(conn->host, port);
           pthread_mutex_unlock(&Supr_syncMutex);
//	   info_sc->mutex = malloc(sizeof(pthread_mutex_t));
//	   pthread_mutex_init(info_sc->mutex, NULL);

	   if(info_sc) { // testing
	     info_sc->port = port;
             Cluster_sendSimpleMessage("DFS_name connected to INFO SERVER",
			     "\033[0;34m", 0, 0);
	/*
	     unsigned char buf[8];
	     strcpy(buf, "\033[0;32m");
	     int type = INFO_DFS_WARNING;
	     int level = 1;
	     write(info_sc->fd, buf, sizeof(buf));
	     write(info_sc->fd, &type, sizeof(int));
	     write(info_sc->fd, &level, sizeof(int));
	     char msg[256];
	     sprintf(msg, "Received INFO_REGISTER command from //%s:%d::%d",
			     conn->host, conn->port, conn->fd);
	     ssize_t len = strlen(msg)+1;
	     write(info_sc->fd, &len, sizeof(ssize_t));
	     write(info_sc->fd, msg, len);
             read(info_sc->fd, &rc, sizeof(int));
	     */
	   }
	   
	   //SocketConn_writeString(conn, "Testing");
	   for(int i=0; i<vectorSize(socket_connections); i++){
             supr_socket_conn_t *sc = vectorElementAt(socket_connections, i);
	     if(sc->type == DFS_DATANODE_CONN){
	       SocketConn_info(0, "Datanode: //%s:%d:%d",
			       sc->host, sc->port, sc->pid);
	       // inform datanodes to initialize ?
	       write(sc->fd, &cmd, INT_SIZE);
	     }
	   }
	 }
         return; //break;


    case CLUSTER_SHUTDOWN:
         {
	   int msg[2];
           ssize_t size = read(fd, msg, sizeof(msg));
	   write(fd, msg, sizeof(int));
	   //basic_info("SHUTTING DOWN ...");
         }

	 handleShutdown(conn);
         return; // not reached 

	 /*
    case CLUSTER_PING: // ECHO
         {
           size_t size = read(fd, &cmd, sizeof(int));
           write(fd, &cmd, sizeof(int));
         }
         return;
	 */

    case DFS_DD_LIST:
	 handleDD_list(conn);
         return;

    case DFS_DD_CREATE:
	 handleDD_create(conn);
         return;
	 /*
    case DFS_DD_CREATE_RETURN:
	 handleDD_createReturn(conn);
         return;
	 */

    case DFS_DD_OPEN:
	 handleDD_open(conn);
         return;

	 /*
    case DFS_DD_OPEN_RETURN:
	 handleDD_openReturn(conn);
         return;
	 */

    case DFS_DD_CLOSE:
	 handleDD_close(conn);
         return;
	 /*
    case DFS_DD_CLOSE_RETURN:
	 handleDD_closeReturn(conn);
         return;
	 */

    case DFS_DD_PUT:
	 handleDD_put(conn);
         return;
	 /*
    case DFS_DD_PUT_RETURN:
	 handleDD_putReturn(conn);
         return;
	 */

	 /*
    case DFS_DD_UPDATE:
	 handleDD_update(conn);
         return;
    case DFS_DD_UPDATE_RETURN:
	 handleDD_updateReturn(conn);
         return;
	 */

    case DFS_DD_GET:
	 handleDD_get(conn);
         return;

    case DFS_DD_REPLICATE:
	 handleDD_replicate(conn);
         return;
	 /*
    case DFS_DD_REPLICATE_RETURN:
	 handleDD_replicateReturn(conn);
         return;
	 */

    case DFS_DD_PERSIST:
	 handleDD_persist(conn);
         return;
	 /*
    case DFS_DD_PERSIST_RETURN:
	 handleDD_persistReturn(conn);
         return;
	 */

    case DFS_DD_INFO:
	 handleDD_info(conn);
         return;
	 /*
    case DFS_DD_INFO_RETURN:
	 handleDD_infoReturn(conn);
         return;
	 */

    case DFS_DD_DATANODE_INFO:
	 handleDD_datanodeInfo(conn);
         return;

    case DFS_DD_OPTION:
	 handleDD_option(conn);
         return;
	 /*
    case DFS_DD_OPTION_RETURN:
	 handleDD_optionReturn(conn);
         return;
	 */

    case DFS_DD_MOVE:
	 handleDD_move(conn);
         return;
	 /*
    case DFS_DD_MOVE_RETURN:
	 handleDD_moveReturn(conn);
         return;
	 */

    case DFS_DD_REMOVE:
	 handleDD_remove(conn);
         return;

    case DFS_DDT_CALL:
	 handleDDT_call(conn);
         return;

    case DFS_DD_EXISTS:
	 handleDD_exists(conn);
         return;

    case SUPR_INTERRUPT:
         handle_interrupt(conn);
         return;

    case DFS_DD_NULL:
         read(fd, &cmd, INT_SIZE);
	 printf("[%s] cmd = %d\n", __func__, cmd);
         write(fd, &cmd, INT_SIZE);

         read(fd, &cmd, INT_SIZE);
	 printf("[%s] cmd = %d\n", __func__, cmd);
         return;

    case DFS_DD_GET_LOCAL_DATANODE_PID:
	 {
           read(fd, &cmd, INT_SIZE);
	   for(int i=0; i<vectorSize(socket_connections); i++){
	     supr_socket_conn_t *sc = (supr_socket_conn_t *)
		     vectorElementAt(socket_connections, i);
	     if(sc->type==DFS_DATANODE_CONN && strcmp(sc->host, conn->host)==0){
		     write(fd, &sc->pid, INT_SIZE);
		     return;
	     }
	   }
	   int rc = -1;
           write(fd, &rc, INT_SIZE);
	 }
         return;

    case DFS_START_WORKERS:
	 startWorkers(conn);
         return;

    case CLUSTER_GET_CONTEXT:
	 handleGetContext(conn);
         return;

    case CLUSTER_CONTEXT_OBJECTS:
         {
           handleClusterList(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_EXISTS:
         {
           handleClusterExists(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_PUT:
         {
           handleClusterAssign(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_GET:
         {
           handleClusterContextGet(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_DOCALL:
         {
           handleClusterContextDoCall(conn, SuprEnv);
         }
         return;

    case INFO_SERVER_REGISTER:
         {
           read(fd, &cmd, INT_SIZE);
           int len; 
           read(fd, &len, INT_SIZE);
           char buf[len];
           read(fd, buf, len);

           free((char*)info_addr);
           info_addr = strdup(buf);

           basic_info(buf);
           basic_info("\033[0;36mClosing info_sc ...\033[0m");
           pthread_mutex_lock(&Supr_syncMutex);
             if(info_sc){
               close(info_sc->fd);
               free(info_sc);
               info_sc = NULL;
             }
             if(strstr(buf, ":")) {
               info_sc = trySocketOpen1(buf);
               if(info_sc){
                 Supr_registerSocketServer(socketServerConn, info_sc);
                 cmd = CLUSTER_PROC_CMD;
                 write(info_sc->fd, &cmd, sizeof(int));
                 len = strlen(proc_cmd)+1;
                 write(info_sc->fd, &len, sizeof(int));
                 write(info_sc->fd, proc_cmd, len);
                 int rc;
                 read(info_sc->fd, &rc, sizeof(int));
               }
             }
           pthread_mutex_unlock(&Supr_syncMutex);
           int rc = 0;
           write(fd, &rc, INT_SIZE);

           // Propagate to master and dfs...
           // TODO ...
	   /*
           for(int i = vectorSize(socket_connections)-1; i>=0; i--)
           {
             supr_socket_conn_t * conn = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
             if(conn->type == conn->type == DFS_DATANODE_CONN){
               write(conn->fd, &cmd, sizeof(int));
               write(conn->fd, &len, sizeof(int));
               write(conn->fd, buf, len);
	       read(conn->fd, &rc, len);
             }

           }
	   */

         }
         return;



    case CLUSTER_WHO:
         {
           read(fd, &cmd, INT_SIZE);
           int msg[] = {DFS_NAMENODE_CONN, getpid(), geteuid()};
           write(fd, msg, sizeof(msg));
         }
         return;

    case CLUSTER_GET_DATANODE_ADDR:
         {
           int args[2];
           read(fd, &args, sizeof(args));
           int which = args[1];
	   if(which == 0){ // all = TRUE
	     int len = 0;
             for(int i=0; i < vectorSize(socket_connections); i++){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
               if(sc->type == DFS_DATANODE_CONN)
	         len += strlen(sc->host) + 64;
	     }

	     char addr[len];
	     addr[0] = 0;
             for(int i=0; i < vectorSize(socket_connections); i++){
               supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
               if(sc->type == DFS_DATANODE_CONN)
	         sprintf(addr+strlen(addr), "//%s:%d;\n", sc->host, sc->port);
	     }
             len = strlen(addr)+1;
             write(fd, &len, sizeof(int));
             write(fd, addr, len);
             return;
	   }

           for(int i=0; i < vectorSize(socket_connections); i++){
             supr_socket_conn_t *sc = (supr_socket_conn_t *)
                     vectorElementAt(socket_connections, i);
             if(sc->type == DFS_DATANODE_CONN){
               which--;
               if(which==0){
                 char addr[strlen(sc->host)+64];
                 sprintf(addr, "//%s:%d", sc->host, sc->port);
                 verbose_info("datanode %d: %s", args[1], addr);
                 int len = strlen(addr)+1;
                 write(fd, &len, sizeof(int));
                 write(fd, addr, len);
                 return;
               }
             }
           }

           int rc = -1;
           write(fd, &rc, sizeof(int));
           char err[256];
           sprintf(err, "cannot find datanode %d, check nnenv()$connections",
			   args[1]);
           ssize_t len = strlen(err)+1;
           write(fd, &len, sizeof(size_t));
           write(fd, err, len);
         }
         return;


    case USER_REGISTER:
         {
           int msg[3];
           size_t size = read(fd, msg, sizeof(msg));
           conn->type = USER_CONN;
           conn->pid  = msg[1];
           conn->port = msg[2];

           /*
           if(!info_sc) {
             info_sc = socketOpen2(conn->host, conn->port);
           }
           {
             char msg[1024];
             sprintf(msg, "recv, size: %ld, cmd: %d (%s)\n", size, cmd,
                             cmd2char(cmd));
             Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
           }
           */

           /*
           fprintf(stderr, "USER_REGISTER: pid=%d\n", conn->pid);
           {
             char msg[1024];
             sprintf(msg, "vectorSize(socket_connections): %d\n",
                             vectorSize(socket_connections));
             Cluster_sendSimpleMessage(msg, msg_color, 0, 0);
             sleep(10);
           }
           */
         }
         return;

    case CLUSTER_PING:
	 {
           read(fd, &cmd, INT_SIZE);
	   cmd = CLUSTER_PONG;
           write(fd, &cmd, INT_SIZE);
	 }
         return;

    case CLUSTER_PONG:
	 {
           read(fd, &cmd, INT_SIZE); // TODO...
	 }
         return;

    case CLUSTER_INFO:
	 {
           read(fd, &cmd, INT_SIZE); 
	   char buf[8]; read(fd, buf, sizeof(buf));
	   int type;    read(fd, &type, sizeof(int));
	   int level;   read(fd, &level, sizeof(int));
	   ssize_t size;read(fd, &size, sizeof(ssize_t));
	   char buffer[128];
	   char *color = "\033[0;37m";
	   //sprintf(buffer,"%s<%s>", color, conn->host);
	   sprintf(buffer,"%s<%s>", buf, conn->host);
	   color = strstr(buffer,".");
	   if(color) { *color='>'; color++; *color=0;}
	   color = buffer;

	   unsigned char *msg = malloc(size+strlen(color)+strlen("\033[0m"));
	   read(fd, msg+strlen(color), size);
	   memcpy(msg, color, +strlen(color));
	   sprintf(msg+strlen(msg), "\033[0m");
	   Cluster_sendSimpleMessage(msg, buf, type, level);
	  // fprintf(stderr, "%s\n", msg);
	   //if(strstr(msg, "DATANODE")) sleep(120);
	   int rc = 0;
	   write(fd, &rc, sizeof(int));
	   free(msg);
	 }
         return;

    case SET_CONN_PID:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
           int pid;
           read(fd, &pid, sizeof(int));
           conn->pid = pid;
           int type;
           read(fd, &type, sizeof(int)); // ?
	   //int rc = 0; write(fd, &rc, sizeof(int)); // ?
         }
         return;

     case GET_CONN_PID:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
           pid_t pid = getpid();
           write(fd, &pid, sizeof(pid_t));
         }
         return;



	 /* FIXME
    case HTTP_GET:
	 {
           read(fd, &cmd, INT_SIZE); // TODO...
	 }
         return;
	 */

    case HTTP_POST:
	 {
            conn->type = WEB_CLIENT_CONN;
            handleHTTP_POST(conn);
            printf("[Dataname@%s] handled cmd %d\n", Supr_hostname, cmd);
	 }
         return;

    case HTTP_GET:
	 break;
         return;

    default:
	 {
           int rc = Supr_handleCommand(cmd, conn);
           if(rc == -1){
             //removeConn(conn);
             close(conn->fd);
             vectorRemoveElement(socket_connections, conn);
             return;
           } else if(rc == 0){
                 return;
           }
         }

	 error_info("[Dataname@%s] Error: unknown command, %d\n", Supr_hostname,
			 cmd);
	 break;
  }
//#undef DRIVER_CONN 
//#undef DRIVER_DRIVER_REGISTER

   if(cmd == HTTP_GET) { // WebClient?
    size_t buf_size = 4096;
    unsigned char buf[buf_size+1];
    ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
    len = __read__(fd, buf, len);
    buf[len++] = 0;
    //printf("\033[0;36m[%s://%s:%d]\n\"%s\"\033[0m\n", connTypeToStr(conn->type), conn->host, conn->port, buf);

    //if (strncmp(buf, "GET / HTTP/", strlen("GET / HTTP/")) == 0)
    /*
    if (strncmp(buf, "GET /", strlen("GET /")) == 0
        && strstr(buf, " HTTP/1.1\r\n"))
    {
      conn->type = WEB_CLIENT_CONN;
      char *s = strtok(buf, "\r\n");
      for(; s; s=strtok(NULL, "\r\n")){
        fprintf(stderr, "||\"%s\"||\n", s);
      }
    }
    */

    if(strncmp(buf, "GET ", strlen("GET ")) == 0){
      char *file_name = strstr(buf, " /")+2;
      char *s = strstr(file_name, " HTTP/1.1");
      *s = 0;
      //printf("\033[0;31mGET file: \"%s\"\033[0m\n", file_name);
      if(strlen(file_name) == 0)
      {
        file_name = "index.html";
        //fprintf(stderr, "\033[0;31mGET file: \"%s\"\033[0m\n", file_name);

	//send: image/webp
	//Html_sendImage(conn, "supr.ico");
        //Html_sendError(conn, file_name);
        //Html_sendIndexPage(conn);

	//return;

      } else if(strcmp(file_name, "favicon.ico") == 0) {
        //sprintf(buf, "400\r\n\r\rn");
        //write(fd, buf, strlen(buf));

        //fprintf(stderr, "\033[0;31mTesting supr.ico: \"%s\"\033[0m\n", file_name);
	Html_sendImage(conn, "supr.ico");
        //Html_sendError(conn, file_name);
        return;
      }

      if(strcmp(file_name, "index.html")==0) { 
        Html_sendIndexPage(conn);
      } else {
        Html_sendFile(conn, file_name);
      }
      return;
    }
  }


  char c;
  //int cmd;
  //size_t size = read(fd, &c, 1);
  //size_t size = __read__(fd, &c, 1);
  /*
  int cmd;
  size_t size = read(fd, &cmd, sizeof(int));
  //printf("[%s] size = %ld\n", __func__, size);

  if(size == 0) {
    printf("[%s] fd = %d is disconnected\n", __func__, fd);
    vectorRemoveElement(socket_connections, conn);
    socketDestroy(conn);

    return;
  } else {
    printf("read [%s] size = %ld, cmd = %d\n", __func__, size, cmd);
  }
  */

  while(TRUE){
    size_t size = recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT);
    if(size == -1){
	    printf("[%s] size = -1, no data ? %s\n", __func__, strerror(errno));
	    return;
    } else if(size == 0){
	    printf("[%s] size = 0,  %s\n", __func__, strerror(errno));
    } else {
	    read(fd, &c, 1);
	    printf(" %0x", c);
    }
  }

}

extern size_t fileWrite(const char*, char *, size_t);

void  pthread_key_destructor(void *data)
{
	printf("[%s] data= %p\n", __func__, data);
}

int backend_run(int port)
{
  //Cluster_sendSimpleMessage("start backend", msg_color, DEFAULT_INFO_TYPE, 0);
  //int reuse_addr = port ? SocketConn_reuseAddr : FALSE;
  //serverConn = serverSocketOpen(port, reuse_addr);

  verbose_info("port: %s:%d%s", Supr_hostname, port, nports?"":"+");

  serverConn = serverSocketOpen3(port, nports, cmd);

  if(!serverConn){
    fprintf(stderr, "cannot start socket server\n");
    if(notify_addr)
      Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_DFSNAME);

    exit(EXIT_FAILURE);
  }
  socketServerConn = serverConn;
  Supr_options.port = serverConn->port;

  serverConn->type = DFS_NAMENODE_CONN;
  serverConn->pid = getpid();

  Supr_registerSocketServer(serverConn, info_sc);

  if(notify_addr){ // notify addr?
    char *host = strdup(notify_addr);
    debug_info("notify '%s'", host);
    char *s = strstr(host, ":");
    if(s){
          *s = 0; s++;
          int port = atoi(s);
          supr_socket_conn_t *sc = socketOpen2(host, port);
          if(sc){
            int cmd = CLUSTER_CONNECT_DFSNAME;
            write(sc->fd, &cmd, sizeof(int));
            char buf[strlen(serverConn->host)+32];
            sprintf(buf, "%s:%d", serverConn->host,
                            serverConn->port);
            int len = strlen(buf)+1;
            write(sc->fd, &len, sizeof(int));
            write(sc->fd, buf, len);
            int rc;
            read(sc->fd, &rc, sizeof(int));
            sprintf(msg, "Sent dfsname_addr %s to %s", buf, notify_addr);
            Cluster_sendSimpleMessage(msg, "\033[0;34m", VERBOSE_INFO_TYPE, 0);
            close(sc->fd);
            free(sc);
	  } else {
            sprintf(msg, "Cannot connect to %s", notify_addr);
            Cluster_sendSimpleMessage(msg, "\033[0;34m", VERBOSE_INFO_TYPE, 0);
	  }
    }
    free(host);
  }



  {
    //char fileName[strlen(SUPR_DFS_HOMEUSR)+strlen("/dfs_namenode.log")+1];
    char fileName[strlen(SUPR_DFS_HOMEUSR)+strlen("/dfs_name.log")+1];
    sprintf(fileName, "%s/dfs_name.log", SUPR_DFS_HOMEUSR);
    fprintf(stderr, "[INFO] log-filename: %s\n", fileName);
    fprintf(stderr, "[INFO] Supr_usrHome: %s\n", Supr_usrHome);

    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\npid:%d\n", serverConn->port, getpid());
    size_t size = fileWrite(fileName, buf, strlen(buf)+1);

    /*
    {
      //char fileName[strlen(SUPR_DFS_HOMEUSR)+strlen("/dfs_namenode.log")+1];
      sprintf(fileName, "%s/dfs_namenode.log", SUPR_DFS_HOMEUSR);
      size = fileWrite(fileName, buf, strlen(buf)+1);
    }
    */


//printf("\n[%s] OKAY 2: buf value=%s (pid=%d, tid=%ld)\n", __func__, buf, getpid(), syscall(SYS_gettid));

     printf("[%s] getcwd(): %s\n", __func__, getcwd(buf, 1022));
  }



  if(!socket_connections)
    socket_connections = newVector(TRUE);
  vectorAdd(socket_connections, serverConn); 

  backendConn = socketOpen2(serverConn->host, serverConn->port);
  if(backendConn){
    backendConn->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(backendConn->mutex, NULL);
  } else {
    Cluster_sendSimpleMessage("cannot connect to the namenode socket server",
		    msg_color, ERROR_INFO_TYPE, 0);
    exit(EXIT_FAILURE);
  }

  /*
  if(info_sc) {
    info_sc->type = INFO_CONN;
    vectorAdd(socket_connections, info_sc);
  }
  */

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);

  //supr_thread_t *taskrunner = startDD_taskrunner( currentThread());
  //printf("FOPEN_MAX = %d\n", FOPEN_MAX);
  //printf("_SC_OPEN_MAX = %ld\n", sysconf(_SC_OPEN_MAX));

  while(TRUE) {
      struct timeval tv;
      //tv.tv_sec=1000;
      tv.tv_sec=60;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      //int fd = serverConn->fd;
      int max_fd = 0;

      // lock ...  printf("\n");
      for(int i=0; i<vectorSize(socket_connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 

	//conn->print(conn);
        int fd = conn->fd;
        FD_SET(fd, &readfds);

	if(fd > max_fd) max_fd = fd;
      }



      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) {
	      //SocketConn_info(0, "Warning (%s): select()=%d", __func__, ns);
	      // testing info
	      continue;
	    }
      } /*  else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(serverConn->fd, &readfds) = %d\n", __func__,
               FD_ISSET(serverConn->fd, &readfds));
      } 
      */

      for(int i = vectorSize(socket_connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
	       	continue;

	if(conn == serverConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(serverConn);
	  if(clientConn){
	    if(Supr_options.verbose){
	      char buf[256];
              sprintf(buf, "\033[0;32mNew conn %d from %s\033[0m\n",
			  clientConn->fd, clientConn->host);
              verbose_info(buf);
	    }

            vectorAdd(socket_connections, clientConn); 
	  } else {
		  fprintf(stderr, "%s:%d FIXME\n", __FILE__, __LINE__);
		  sleep(10);
	  }
	} else {
          handleCommand(conn);
	}
      }

//      sleep(1);
  }



  sleep(60);
//  int k = FOPEN_MAX;


  return 0;

}

//extern supr_thread_t *newThread(pthread_t ptid, pid_t, pid_t tid, int state);

void backend_cleanup(void *arg)
{
	fprintf(stderr, "[%s:%d:%s] exists\n", __FILE__, __LINE__, __func__);
//        exit(EXIT_FAILURE); // TODO
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}


void *backend_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;
  pthread_setspecific(currentThreadKey, th);

  int port = ((int*)data)[0];
  printf("[%s] port: %d\n", __func__, port);

  free(th->name);
  th->name = strdup("backend");

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  th->state = THREAD_STATE_RUNNABLE;
  pthread_cleanup_push(backend_cleanup, th);
    backend_run(port);
  pthread_cleanup_pop(TRUE);

  pthread_exit(th);
  return NULL;
}

SEXP jobSubmit(SEXP);
SEXP help(SEXP);

typedef struct callable_struct {
  char *name;
  char *par_names;
  SEXP (*func)(SEXP args); // args: pairlist
  char *doc;
} callable_t;

callable_t R_callable_functions[] =
{
  { "help",   "(topic)",   help, "..." },
  { "submit", "(expr, data, ...)", jobSubmit, "..." },
};

SEXP jobSubmit(SEXP args){
  return R_NilValue;
}

SEXP help(SEXP topic){
  if(TYPEOF(topic) == NILSXP){
    return mkString("TO DO");
  } else {

    PrintValue(topic);

    const char *name = CHAR(asChar(topic));
    for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
      if(strcmp(R_callable_functions[i].name, name)==0){
        return mkString(R_callable_functions[i].doc);
      }
    }
    errorcall(R_NilValue, "no doc is available on '%s'", name);
    return R_UnboundValue;

  }
}

void UI_run(shm_io_info_t *io){


  while(TRUE){
    size_t size;
    void *bytes = shm_io_read(io, io->in, &size, NULL);
    int cmd = ((int*)bytes)[0]; 
    printf("[%s] cmd = %d\n", __func__, cmd);

    // BEGIN_R_EVAL:
    SEXP res = R_NilValue;
    BEGIN_R_EVAL();
      // testing
      SEXP raw = PROTECT(allocVector(RAWSXP, size));
      memcpy(DATAPTR(raw), bytes, size); 
      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, null)));
      SEXP val = PROTECT(eval(call, R_GlobalEnv));
    
      printf("\033[0;36m[%s] cmd = %d\n", __func__, cmd);
      PrintValue(val);
      printf("\033[0;36m[%s] cmd = %d\033[0m\n", __func__, cmd);

      const char *func_name = CHAR(asChar(VECTOR_ELT(val,0)));
      SEXP (*func)(SEXP args) = NULL;
      for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
        if(strcmp(R_callable_functions[i].name, func_name)==0){ // use qsearch
          func = R_callable_functions[i].func;
	  break;
        }
      }
      printf("\033[0;36m[%s] func = %s\033[0m\n", __func__, func_name);
      printf("\033[0;36m[%s] func = %p\033[0m\n", __func__, func);

      if(func) {
        int errorOccurred;
        res = R_simpleTryEval4(func, VECTOR_ELT(val,1), R_GlobalEnv,
		       	&errorOccurred);
      } else {
        res = R_NilValue; // change it to error 
      }

    END_R_EVAL();
    // END_R_EVAL:

    shm_io_write(io, io->out, bytes, size);
    free(bytes);
  }
}

void *UI_Run(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;

  free(th->name);
  th->name = strdup(__func__);

  /*
  pthread_key_t th_key;
  pthread_key_create(&th_key, thread_destructor);
  pthread_setspecific(th_key, th);
  */


  //supr_socket_conn_t *serverConn = (supr_socket_conn_t *) data;
  //data += sizeof(supr_conn_t *);
 // char *shm_name = (char*) data;
  //int port = ((int*)data)[0];
  shm_io_info_t *io = (shm_io_info_t *)data;
  printf("[%s] io = %p\n", __func__, io);

//  supr_socket_conn_t *sock_conn = socketOpen(serverConn);


  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  if(io) UI_run(io);

  pthread_exit(th);
  return NULL;
}




supr_thread_t *startBackend(int port)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, &sem, &sth};
  int rc = pthread_create(&thread, NULL, backend_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  //printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

supr_thread_t *startUI(shm_io_info_t *io)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {io, &sem, &sth};
  int rc = pthread_create(&thread, NULL, UI_Run, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

void __R_init(int argc, char **argv){

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  Rf_initialize_R(new_argc, new_argv);
  void *dummy;
  R_CStackStart = (unsigned long) &dummy;
  R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
  setup_Rmainloop();

  R_thread_init();
}

void main_thread_cleanup(void *data){
  fprintf(stderr, "[%s:%d:%s] exists\n", __FILE__, __LINE__, __func__);

//  basic_info(__func__);
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;

  pthread_mutex_lock(threads->mutex); // FIXME?
  sleep(1);
//  basic_info("EXIT_SUCCESS");
  exit(EXIT_SUCCESS);

}

// main_thread:
// FIXME: manage info_sc
void  R_REPL(supr_thread_t *this_thread, int argc, char **argv)
{
  

  void *dummy;
  pthread_cleanup_push(main_thread_cleanup, argv[0]);

  int oldcancelstate;
  //int rc =
  pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);

  void *data[] = {&argc, argv};
  
  if(R_ToplevelExec(startRemoteDatanodes, data) == FALSE){
    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "\033[0;31mError occurred in startRemoteDatanodes"
		    "\n\t%s"
		    "\n\tSee also %s/stderr.txt\033[0m",
		    strerror(errno), CWD_PATH);
    Cluster_sendSimpleMessage(msg, msg_color, 0, 0);
  }

  pthread_setcancelstate(oldcancelstate, &oldcancelstate);


  supr_thread_t *cth = pthread_getspecific(currentThreadKey);


  while(TRUE){

    task_t *task = NULL;

//#define DEFAULT_HEARTBEAT_TIME 60

    double timeout = 5*Supr_options.timeout; // DEFAULT_HEARTBEAT_TIME;

    struct timespec wait;
    clock_gettime(CLOCK_REALTIME, &wait);
    wait.tv_sec += (long) timeout;

    pthread_mutex_lock(&tasks_mutex);

      if(vectorSize(tasks)) task = (task_t*) vectorRemove(tasks, 0);

      if(!task) {

	if(Supr_debug || Supr_verbose){
	  char buf[256];
	  char *s = argv[0]; while(strstr(s, "/")) s = strstr(s, "/") + 1;
          sprintf(buf, "%s: HEARTBEAT, pid: %d", s, getpid());
          Cluster_sendSimpleMessage(buf, msg_color, 0, 0);
	}

        cth->state = THREAD_STATE_WAITING;
        pthread_cond_timedwait(&tasks_cond, &tasks_mutex, &wait);
        cth->state = THREAD_STATE_RUNNABLE;
        if(vectorSize(tasks))
       	  task = (task_t*) vectorRemove(tasks, 0);
      }

    pthread_mutex_unlock(&tasks_mutex);

    while(task){
      task->run(task);
      pthread_mutex_lock(&tasks_mutex);
        if(vectorSize(tasks))
       	  task = (task_t*) vectorRemove(tasks, 0);
	else 
	  task = NULL;
      pthread_mutex_unlock(&tasks_mutex);
    }

    /*
    if(backendConn){
      pthread_mutex_lock(backendConn->mutex);
 //     int oldcancelstate; pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldcancelstate);

        int cmd = DFS_DD_NULL;
        write(backendConn->fd, &cmd, INT_SIZE);
        read(backendConn->fd, &cmd, INT_SIZE);
        printf("[%s] cmd: %d\n", __func__, cmd);

        for(int i=0; i<vectorSize(socket_connections); i++){
          supr_socket_conn_t *sc = (supr_socket_conn_t *)
		 vectorElementAt(socket_connections, i);
	  if(sc->type == DFS_DATANODE_CONN){
            int cmd = CLUSTER_PING;
            write(sc->fd, &cmd, INT_SIZE);
	  }
        }

        write(backendConn->fd, &cmd, INT_SIZE);

//      pthread_setcancelstate(oldcancelstate, &oldcancelstate);

      pthread_mutex_unlock(backendConn->mutex);
    }
    */

  }
  pthread_cleanup_pop(TRUE);
}

extern int setDir(const char *dir_path, const char *subdir); 


void  Namenode_SigactionSIGUSR2(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));
  c_backtrace();
  printf("\n\033[0;31m");

  void *object = pthread_getspecific(interruptThreadKey);
  if(object){ // FIXME
    // SocketConn_isInstace(object))
    supr_socket_conn_t *sc = (supr_socket_conn_t *) object;
    printf("\tinterruptThreadKey -> sc: //%s:%d\n", sc->host, sc->port);
    int rc = -1;
    write(sc->efd, &rc, INT_SIZE);
    int n = 1;
    write(sc->efd, &n, INT_SIZE);
    char err[256];
    sprintf(err, "[tid: %ld] INTERRUPTED", syscall(SYS_gettid));
    printf("\t[ERROR] %s\n", err);
    FD_writeString(sc->efd, err);
  }

  printf("\033[0m");
//  sleep(10);
}



void  Namenode_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s] pid=%d, tid=%ld\033[0m\n", 
                    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(120);
  system_exit(CLUSTER_SHUTDOWN);
}

void  Namenode_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s] pid=%d, tid=%ld\033[0m\n",
                    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);
}

//#include <sys/ptrace.h>

void  Namenode_sigaction(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "%s\n", __func__);
  if(sig == SIGTERM){
    fprintf(stderr, "%s SEND CLUSTER_SHUTDOWN INFO ...?\n", __func__);
    basic_info("SIGTERM");
    exit(EXIT_FAILURE);
  }
}


void  Namenode_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  supr_thread_t *cth = currentThread();
  if(cth == main_thread) {
    //Master_shutdown(NULL);
    basic_info(__func__);
    void *mem_ptr = NULL;
    ssize_t size = 0;
    char *shm_name = Supr_signal_shm_open(getpid(), sig, &mem_ptr, &size);
    pid_t pid = *((pid_t *)mem_ptr);
    int cmd = *((int *) (mem_ptr+sizeof(pid_t)));
    if(cmd == CLUSTER_INFO)
    { // INFO... TODO
      char *info_addr = (char*)  (mem_ptr+sizeof(pid_t)+sizeof(int)); //cmd_t
      supr_socket_conn_t *sc = trySocketOpen1(info_addr);
      if(sc && info_sc){
          close(info_sc->fd);
          free(info_sc); // FIXME
          info_sc = sc;

          int cmd = CLUSTER_PROC_CMD;
          write(info_sc->fd, &cmd, sizeof(int));
          int len = strlen(proc_cmd)+1;
          write(info_sc->fd, &len, sizeof(int));
          write(info_sc->fd, proc_cmd, len);
          int rc;
          read(info_sc->fd, &rc, sizeof(int));
      }
      basic_info(__func__);

      basic_info("\n\033[0;31mTODO: DEBUG?\033[0m\n");

      if(Supr_curStrError){
        basic_info(Supr_curStrError);
        exit(EXIT_FAILURE);
      } else {
        basic_info("\n\033[0;31mTODO: DEBUG?\033[0m\n");
      }

    }
    munmap(mem_ptr, size);
    shm_unlink(shm_name);
  } else
    pthread_kill(main_thread->ptid, SIGINT);

}

/*
 * When locks and condition variables are used together like this, the result is called a monitor :

    A collection of procedures manipulating a shared data structure.
    One lock that must be held whenever accessing the shared data (typically each procedure acquires the lock at the very beginning and releases the lock before returning).
    One or more condition variables used for waiting.
    */

void timedwait_thread_cleanup(void *data){
	//TODO?
  fprintf(stderr, "[%s:%d:%s] exists\n", __FILE__, __LINE__, __func__);
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}

void timedwait_thread_run()
{
  nn_timedwait_t *wait_event = NULL;
  supr_thread_t *cth = currentThread();

  pthread_cleanup_push(timedwait_thread_cleanup, cth);

  pthread_mutex_lock(&cth->mutex);

    cth->state = THREAD_STATE_RUNNABLE;

    while(TRUE){

      wait_event = NULL;
      pthread_mutex_lock(timedwait_queue->mutex); 

        struct timespec wait;
        clock_gettime(CLOCK_REALTIME, &wait);
        long current_time = wait.tv_sec*1000000000 + wait.tv_nsec;

	long min_time;

        for(int i = vectorSize(timedwait_queue)-1; i>=0; i--){
          nn_timedwait_t *event = vectorElementAt(timedwait_queue, i);
          printf("[%s:%d] message: %s\n", __func__, cth->tid,
			  (char*)((void**)event->data)[1]);
	  long wait_time = event->time.tv_sec*1000000000 + event->time.tv_nsec;

          if(current_time >= wait_time){
            if(event->run) 
              event->run(event->data);

            vectorRemove(timedwait_queue, i);

	    if(event->destroy)
              event->destroy(event);
	    
          } else if(wait_event==NULL || wait_time < min_time){
            wait_event = event;
	    min_time = wait_time;
          } 
        }
      pthread_mutex_unlock(timedwait_queue->mutex); 

      printf("[%s:%d] waiting...\n", __func__, cth->tid);
      if(wait_event){
        pthread_cond_timedwait(&cth->cond, &cth->mutex, &wait_event->time);
      } else {
        cth->state = THREAD_STATE_WAITING;
        pthread_cond_wait(&cth->cond, &cth->mutex);
        cth->state = THREAD_STATE_RUNNABLE;
      }

    }

  pthread_mutex_unlock(&cth->mutex);

  pthread_cleanup_pop(TRUE);
}

void *timedwaitThread_init(void *arg)
{
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[0];
  printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[1];
  printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &sem);
  *sth = th;

  free(th->name);
  th->name = strdup("timedwait");

  pthread_setspecific(currentThreadKey, th);
//  pthread_setspecific(save_R_CStackStartKey, malloc(sizeof(unsigned long)));

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  timedwait_thread_run();

  pthread_exit(th);
  return NULL;
}


supr_thread_t *startTimedwaitThread()
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&sem, &sth};
  int rc = pthread_create(&thread, NULL, timedwaitThread_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}



//struct sigaction R_oldSegvAct;
void  Namenode_SigactionSIGSEGV(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));
  //c_backtrace();
  printf("\n\033[0;31m");
  switch(ip->si_code){
    case SEGV_MAPERR:
         fprintf(stderr, "Address not mapped.\n");
         break;
    case SEGV_ACCERR:
         fprintf(stderr, "Access to this address is not allowed.\n");
         break;
    default:
         fprintf(stderr, "Unknown reason.\n");
         break;
  }
  printf("\n\033[0m\nR_oldSegvAct.sa_sigaction:\n");

  sleep(120);

  //R_oldSegvAct.sa_sigaction(sig, ip, context);
  //exit(1);
}

extern void (*__supr_cleanup)(void);

void dfs_cleanup()
{
  printf("SocketConn_closeAll:\n");
  SocketConn_closeAll(socket_connections, TRUE);
}

/*
void startStdlog(char *CWD_PATH)
{
    Supr_stdlog_filename = (char*)
            malloc(strlen(CWD_PATH)+strlen("stdlog.txt")+2);
    sprintf(Supr_stdlog_filename, "%s/%s", CWD_PATH, "stdlog.txt");
    fprintf(stderr, "stdlog.txt: %s\n", Supr_stdlog_filename);
    unlink(Supr_stdlog_filename);
    stdlog = fopen(Supr_stdlog_filename, "a+");
    if(stdlog == NULL)
      fprintf(stderr, "Error: %s, %s\n", Supr_stdlog_filename, strerror(errno));
    Supr_stdlog_fileno = fileno(stdlog);

    char time_buf[256];
    fprintf(stdlog, "Started at %s\n", Exec_timestamp(time_buf, 256));
}
*/



//extern vector_t * __classes__;
extern int Config_getPort(const char *name);
//extern SEXP SuprContect_cleanup(SEXP args); 
extern int SocketConn_cleanup(const char *service, int port);

extern void runAsDaemon(char *dir);

char *DFSNameDir()
{
  if(!Supr_usrHome)
    Supr_usrHome = getenv("SUPR_USR_HOME"); // FIXME

  char path[PATH_MAX];
  struct stat sb;
  if(!Supr_usrHome) {
     char *home = getenv("HOME"); // FIXME
     if(!home){
           fprintf(stderr, "No home directory is avialable");
           return NULL;
     }
     sprintf(path, "%s/.supr", home);
     if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
       Supr_usrHome = strdup(path);
     else if(mkdir(path, 0700) != -1)
       Supr_usrHome = strdup(path);
  }

  if(!Supr_usrHome) {
           fprintf(stderr, "No usr.home is avialable");
           return NULL;
  }

  // check supr.conf
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  int fd = open(path, O_RDONLY);
  //struct stat sb;
  if(fd != -1 && fstat(fd, &sb) != -1) {
    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    buf[sb.st_size] = 0;
    close(fd);
    char *namenode_spec = strstr(buf, "Namenode");
    char *namenode_dir = NULL;

    if(namenode_spec){ // FIXME

      char *s = strstr(namenode_spec,"{");
      if(!s) {
        s = strstr(namenode_spec,"\n");
	if(s) *s = 0;
        error_info("%s: expected '{' in line '%s'", path, namenode_spec);
	return NULL;
      }
      s = strstr(s,"}");
      if(!s) {
        s = strstr(namenode_spec,"\n");
	if(s) *s = 0;
        error_info("%s: expected '}' after '%s'", path, namenode_spec);
	return NULL;
      } else {
	      s++;
	      *s = 0;
      }

      //char *s = strstr(namenode_spec,"\n");
      s = strstr(namenode_spec,"{")+1;
      while(*s && (*s == ' ' || *s == '\n' || *s == '\r' || *s == '\t'))
	      s++;
      if(strncmp(s, "file", strlen("file"))==0) {
        namenode_dir = strstr(s, "//")+2;
        s = strstr(namenode_dir, "\n");
        if(s) *s = 0;
	s = namenode_dir;
	while(*s && *s != ' ' && *s != '\t') s++;
	*s = 0;

	memcpy(path, namenode_dir, strlen(namenode_dir)+1);
        if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
          return strdup(path);
        else if(mkdir(path, 0700) != -1) // not recursive
          return strdup(path);
      } else {

	//char login_r[256];
	//basic_info("OKAY 0031");
        //int rc = getlogin_r(login_r, sizeof(login_r));
	//basic_info("OKAY 0033, rc: %d", rc);
        //if(rc != 0) {
         // error_info("getlogin_r, %s\n", strerror(rc));
         // error_info("getlogin_r, %s\n", strerror(errno));
        //} else
       	//{

          char *__tmp = getenv("SUPR_DFS_DATADIR");
          if(!__tmp) __tmp = "/tmp";

	  sprintf(path, "%s/supr-%s", __tmp,  Supr_username);
          //basic_info("dfs_name root dir: %s", path);
	  
	  int rc;
          if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode)){
	  } else{
	    rc = mkdir(path, 0700);
	    if(rc == -1)
              basic_info("Warning in mkdir(%s): %s\n", path, strerror(errno));
	  }
	  
	  sprintf(path, "%s/supr-%s/dfs_name", __tmp,  Supr_username);

          if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode)) {
	  } else {
	    rc = mkdir(path, 0700);
	    if(rc == -1)
              basic_info("Warning in mkdir(%s): %s\n", path, strerror(errno));
	  }
	  
          if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
	  {
            verbose_info("dfs_name dir: %s", path);
            return strdup(path);
	  }
	//}
      }
    }
  }

  sprintf(path, "%s/%s", Supr_usrHome, SYS_COMMAND_DFS_NAMENODE);

  if(stat(path, &sb) == -1) {
    if(mkdir(path, 0700) == -1){
      perror(path);
      return NULL;
    }
  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    return NULL;
  }

  return strdup(path);
}

static const char *__doc__ =""
"  dfs_name [-port n] [--verbose] [--debug] [--info] [--help]\n"
"\t[-info addr] [-notify addr]";

// TODO:
// SO_LINGER: to set TIME_WAIT like timeout
// SO_REUSEADDR
// SO_REUSEPORT

/* Default: disable SO_REUSEADDR to allow finding a new port to use
 * When enabled with --reuse.addr, it will try to kill existing processes
 * using the same port (address)
 */

char *dfs_name_is_running(){
  char path[PATH_MAX];
  char *log = NULL;
  sprintf(path, "%s/dfs_name.log", Supr_usrHome);
  if(access(path, F_OK)==0){
    struct stat statbuf;
    int fd = open(path, O_RDONLY);
    int rc = fstat(fd, &statbuf);
    if(rc==0 && fd !=-1){
      log = malloc(statbuf.st_size+1);
      read(fd, log, statbuf.st_size);
      log[statbuf.st_size] = 0;
    }
    close(fd);
  } 

  return log;
}

/*
void argv_info(int argc, char **argv){
  if(argc<=0) return;

  int len = 0;
  for(int i=0; i<argc; i++) len +=  strlen(argv[i]) + 2;

  char buf[len];
  sprintf(buf, "%s", argv[0]);
  for(int i=1; i<argc; i++)
    sprintf(buf+strlen(buf), "\n\t%s",  argv[i]);
  //verbose_info(buf);
  basic_info(buf);
}
*/
// FIXME: mv to supr.c


/*
void DFSName_do_xterm(int use_xterm){

  static supr_thread_t *gdb_thread = NULL;
  static char *xterm_name = NULL;

  if(use_xterm){
    if(gdb_thread){
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        if(gdb_thread->name) {
	  //
	} else {
          void *ret_val;
          rc = pthread_join(gdb_thread->ptid, &ret_val);
	  // destroy...
	}
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
      gdb_thread = NULL; // FIXME... destroy 
    }

    if(!gdb_thread){ // if(!xterm_name || !gdb_thread)
      Supr_gdb_C(0, TRUE, &gdb_thread, &xterm_name);
      Supr_options.xterm = 1;
      fprintf(stderr, "%s:%d. tid: %d\n\n", __FILE__, __LINE__,
    	gdb_thread->tid);
      sleep(1);
    
// testing
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        rc = pthread_cond_signal(&gdb_thread->cond);
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
    }

    //fprintf(stderr, "tid: %d, rc: %d\n", gdb_thread->tid, rc);

  } else {
    basic_info("%s(%s): TODO...", __func__, use_xterm? "TRUE":"FALSE");
    xterm_name = NULL;
    if(gdb_thread){
      int rc = pthread_cancel(gdb_thread->ptid);
      fprintf(stderr, "pthread_cancel, rc: %d\n", rc);
      void *ret_val;
      rc = pthread_join(gdb_thread->ptid, &ret_val);
      fprintf(stderr, "pthread_join, rc: %d\n", rc);
      for(int i=0; i<10; i++) fprintf(stderr, "\n");
      gdb_thread = NULL;
    }
    Supr_options.xterm = 0;
  }
}
*/

void DFSName_do_ncpu(int ncpu){
    basic_info("%s(%s): TODO...", __func__, ncpu? "TRUE":"FALSE");
}


int main(int argc, char **argv)
{

  Supr_do_xterm_ptr = Supr_do_xterm;
  Supr_do_ncpu_ptr = DFSName_do_ncpu;


  proc_cmd = argv[0];
  while(strstr(proc_cmd, "/")) proc_cmd = strstr(proc_cmd, "/")+1;



  int port = -1;
//  int port_plus = FALSE;
  //int min_port = -1;

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--verbose")==0){
      Supr_options.verbose = Supr_verbose = TRUE;
    } else if(strcmp(argv[i], "--debug")==0){
      Supr_options.debug= Supr_debug = TRUE;
    } else if(strcmp(argv[i], "--info")==0){
      Supr_options.info = Supr_infov = TRUE;
    } else if(strcmp(argv[i], "-notify")==0 && i+1 < argc){
      notify_addr = argv[++i];
    } else if(strcmp(argv[i], "-timeout")==0 && i+1 < argc){
      Supr_options.timeout = atof(argv[++i]);
    } else if(strcmp(argv[i], "-level")==0 && i < argc-1){
      Supr_options.level = atoi(argv[++i]);
    } else if(strcmp(argv[i], "-port")==0 && i < argc-1){
       port = atoi(argv[++i]);
       nports = strstr(argv[i], "+") ? 0 : 1;
    //} else if(strcmp(argv[i], "-min_port")==0 && i < argc-1){ min_port = atoi(argv[++i]);
    } else if(strcmp(argv[i], "-X11")==0 && i < argc-1){
       X11_str = argv[++i];
    }
  }

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-info")==0 && i+1 < argc){
      info_addr = strdup(argv[i+1]);
      char *hostname = strdup(info_addr);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      info_sc = socketOpen2(hostname, port);
      if(info_sc) {
        info_sc->port = port;
	int cmd = CLUSTER_PROC_CMD;
	write(info_sc->fd, &cmd, sizeof(int));
	char *proc_cmd = argv[0];
	while(strstr(proc_cmd, "/"))
	  proc_cmd = strstr(proc_cmd, "/")+1;
	int len = strlen(proc_cmd)+1;
	write(info_sc->fd, &len, sizeof(int));
	write(info_sc->fd, proc_cmd, len);
	        int rc;
        read(info_sc->fd, &rc, sizeof(int));
      }
      Cluster_sendSimpleMessage(argv[0], "\033[0;34m", VERBOSE_INFO_TYPE, 0);
      free(hostname);
      break;
    }
  }

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--help")==0){
      fprintf(stderr, "%s\n", __doc__);
      exit(EXIT_SUCCESS);
    }
  }

  verbose_info("\033[0;33mserver port: %s:%d%s\033[0m", Supr_hostname, port, nports?"":"+");
  //for(int i=0; i<argc; i++)
//	  basic_info(argv[i]);
	  //verbose_info(argv[i]);
  argv_info(argc, argv);

  char *dfs_name_log = NULL;
  pid_t namenode_pid = -1;
  if(dfs_name_log = dfs_name_is_running()) {
    sprintf(msg, "Warning: %s/dfs_name.log exists,\n%s", Supr_usrHome, dfs_name_log);
    basic_info(msg);

    if(strstr(dfs_name_log, "pid:")){
      pid_t pid = atoi(strstr(dfs_name_log, "pid:") + 4);
      namenode_pid = pid;
      errno = 0;
      int rc = kill(pid, 0);
      if(rc == 0){
        basic_info("(dfs_name) proc %d is still running ...", pid);

	// leave it as is. as a feature ...
        if(notify_addr && nports){
          supr_socket_conn_t *sc=trySocketOpen1(dfs_name_log);
          if(!sc){
            sc = socketOpen1(dfs_name_log);
            if(sc) {
              basic_info("can connect to the server... (too many pending connections)");
	      int rc = Supr_checkLogin(sc->fd, sc, "DFS"); // FIXME?
              if(rc != 0){
                error_info("%s:%d. FIXME: Supr_checkLogin(DFS, *)",
                                    __func__, __LINE__);
              }

            } else {
              basic_info("cannot connect to the server (kill the master proc?)");
            }
          } else {
              basic_info("can connect to the server");
          }
	  char *shm_name = Supr_signal_shm_create(pid, SIGINT, CLUSTER_INFO,
                   (void*)info_addr, info_addr ? (strlen(info_addr)+1) : 0);


        }


      } else if(rc == -1 && errno == ESRCH){
        sprintf(msg, "kill(%d, 0): %s", pid, strerror(errno));
        Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
	char path[PATH_MAX];
	sprintf(path, "%s/dfs_name.log", Supr_usrHome);
        debug_info("removing %s", path);
        unlink(path);
	free(dfs_name_log);
	dfs_name_log = NULL;
      }
    } else {
      Cluster_sendSimpleMessage("pid not found", msg_color, ERROR_INFO_TYPE, 0);
    }
  } else {
    debug_info("file 'dfs_name.log' not found");
  }

  if(dfs_name_log){
    if(nports){
      if(notify_addr)
        Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_DFSNAME);
      error_info("q(\"no\")");
      exit(EXIT_FAILURE);
    } else {
	basic_info("ignore existing dfs_name.log: %s", dfs_name_log);
	free(dfs_name_log);
	dfs_name_log = NULL;
	kill(namenode_pid, SIGKILL);
    }
  }

  
#ifdef RUN_AS_DAEMON_PROC

  char *dir = DFSNameDir();
  if(!dir)
    exit(EXIT_FAILURE);

  {
    char buf[256];
    sprintf(msg, "[%s:%d:%s] Time: %s, \tDFSNameDir(): %s",
      __FILE__, __LINE__,__func__, Exec_timestamp(buf, sizeof(buf)), dir);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }

  //runAsDaemon(SYS_COMMAND_MASTER);

  //if(run_as_daemon)
  runAsDaemon(dir);

  main_pid = getpid();
  atexit(send_ExitInfo);
  

  verbose_info("\033[0;33mserver port: %s:%d%s\033[0m", Supr_hostname, port, nports?"":"+");

  //
  if(FALSE && info_addr){
    char *hostname = strdup(info_addr);
    char *s = strstr(hostname, ":");
    if(s) *s = 0; s++;
    int port = atoi(s);
    info_sc = socketOpen2(hostname, port);

    if(info_sc) {
        info_sc->port = port;
	int cmd = CLUSTER_PROC_CMD;
	write(info_sc->fd, &cmd, sizeof(int));
	char *proc_cmd = argv[0];
	while(strstr(proc_cmd, "/"))
	  proc_cmd = strstr(proc_cmd, "/")+1;
	int len = strlen(proc_cmd)+1;
	write(info_sc->fd, &len, sizeof(int));
	write(info_sc->fd, proc_cmd, len);
	        int rc;
        read(info_sc->fd, &rc, sizeof(int));
    }
    
    sprintf(msg,"dfs_name: Reconnected, pid: %d", getpid()); 
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "dfs_name CWD: %s", CWD_PATH);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);


    free(hostname);
  } else if(Supr_infov) {
    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "dfs_name CWD: %s", CWD_PATH);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  }


  if(TRUE){
    char buf[256];
    fprintf(stderr, "\033[0;33mTime: %s (%s:%d)\033[0m\n",
      Exec_timestamp(buf, sizeof(buf)), __FILE__, __LINE__);
  }
  // syslog(LOG_NOTICE, "supr2/bin/dfs_name started");
  // ...
  char buf[256];
  fprintf(stderr, "host: %s, ppid: %d, pid: %d, time: %s\n",
                  Supr_hostname, getppid(), getpid(),
                  Exec_timestamp(buf, sizeof(buf)));
#endif

//  for(int i=0; i<argc; i++){ printf("argv[%d] %s\n", i, argv[i]); }
#define SUPR_DEBUG
#ifndef SUPR_DEBUG
  int devNull = open("/dev/null", O_WRONLY);
  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);
  dup2(devNull, STDERR_FILENO);
  dup2(devNull, STDOUT_FILENO);
#endif

  stdout_fileno_save = dup(STDOUT_FILENO);
  stderr_fileno_save = dup(STDERR_FILENO);

  if(TRUE){
    char buf[256];
    fprintf(stderr, "\033[0;33mTime: %s (%s:%d)\033[0m\n",
      Exec_timestamp(buf, sizeof(buf)), __FILE__, __LINE__);
  }

//  SuprContect_cleanup(NULL);


  __supr_cleanup = dfs_cleanup;

  Main_pid =  getpid();

  {
    struct sigaction sa;
    sa.sa_sigaction = Namenode_SigactionSIGSEGV;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = Namenode_sigaction;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGTERM, &sa, NULL);
  }

  if(TRUE){
    char buf[256];
    fprintf(stderr, "\033[0;33mTime: %s (%s:%d)\033[0m\n",
      Exec_timestamp(buf, sizeof(buf)), __FILE__, __LINE__);
  }
//  __supr_malloc_init__();
  supr_init();

  /*
  if(!__classes__) {
    __classes__ = newVector(TRUE);
    vectorAdd(__classes__, __classes__->class);
  }
  */
  if(TRUE){
    char buf[256];
    fprintf(stderr, "\033[0;33mTime: %s (%s:%d)\033[0m\n",
      Exec_timestamp(buf, sizeof(buf)), __FILE__, __LINE__);
  }

  if(!cleanups)
    cleanups = newVector(TRUE);
  tasks = newVector(TRUE);


  atexit(rmConnLog);


  //ddEnvironment = newHashtable(FALSE);
  ddEnvironment = newHashtable(TRUE); // FIXME, check early implementation
  dn_locations = newHashtable(FALSE);

  for(int i=0; i<argc; i++) {
      printf("%s\n", argv[i]);
  }
  
  printf("\npid: %d\n", getpid());

  int rc = setpgrp(); // set process group to itself
  if(rc == -1)
  {
      printf("Error: %s\n", strerror(errno));
  }


//  int port = -1;
  char *shm_name = NULL;
  char *mmap_io_name = NULL;

  char *_stdout = NULL;

  /*
  for(int i=0; i<argc; i++){
     if(strcmp(argv[i], "-port")==0 && i < argc-1)
       port = atoi(argv[++i]);
     //else if(strcmp(argv[i], "-shm")==0 && i < argc-1) shm_name = argv[++i];
     //else if(strcmp(argv[i], "-mc")==0 && i < argc-1) mmap_io_name = argv[++i]; 
     //else if(strcmp(argv[i], "-html")==0 && i < argc-1) html_dir = argv[++i];
     else if(strcmp(argv[i], "--reuse.addr"))
       SocketConn_reuseAddr = TRUE;
     //else if(strstr(argv[i],"stdout") && i<argc-1) _stdout = argv[++i];
  }
  */


  /*
  printf("\033[0;34mport: %d\n", port);
  if(port == -1 && getenv("DFS_PORT")){
    port = atoi(getenv("DFS_PORT"));
  }
  */

  /*
  printf("\033[0;33mport: %d\n", port);
  if( port == -1 )
      port = Config_getPort("Namenode");

  if(TRUE){
    char buf[256];
    fprintf(stderr, "\033[0;33mTime: %s (%s:%d)\033[0m\n",
      Exec_timestamp(buf, sizeof(buf)), __FILE__, __LINE__);
    fflush(stderr);
  }
  */

#define LET_BACKEND_DO_THIS
#ifndef LET_BACKEND_DO_THIS
  int pong = tryPingSocketServer2(Supr_hostname, port);
  sprintf(msg, "tryPingSocketServer2(%s, %d): %d",
                      Supr_hostname, port, pong);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  //if(pong != CLUSTER_PONG){
    switch(pong){
      case -1: // OK socketOpen2 return NULL
           break;
      case -2: // cannot write
      case -3: // cannot read
      default:
           {
             sprintf(msg, "dfs_name with the same port %d is running on %s"
                             "\n\tkill ...",
                      port, Supr_hostname);
             Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
             vector_t *killed_cmds = newVector(FALSE);
             Supr_killSocketServer("dfs_name", port, killed_cmds);
             for(int i=vectorSize(killed_cmds)-1; i>=0; i--) {
               char *s = (char*) vectorRemove(killed_cmds, i);
               Cluster_sendSimpleMessage(s, "\033[0;31m", VERBOSE_INFO_TYPE, 0);
	       free(s);
	     }
	     vectorDestroy(killed_cmds);
           }
           break;
    }
  //}
#endif


    /*
#define DONOT_PORT_CLEANUP
#ifdef  DO_PORT_CLEANUP
  SocketConn_cleanup(SYS_COMMAND_DFS_NAMENODE, port);
#else
  if(port>0)
    SocketConn_cleanup(SYS_COMMAND_DFS_NAMENODE, port);
#endif
*/

  if(TRUE){
    char buf[256];
    fprintf(stderr, "\033[0;33mTime: %s (%s:%d)\033[0m\n",
      Exec_timestamp(buf, sizeof(buf)), __FILE__, __LINE__);
    fflush(stderr);
  }

  if(TRUE){
    char buf[256];
    fprintf(stderr, "\033[0;33mTime: %s (%s:%d)\033[0m\n",
      Exec_timestamp(buf, sizeof(buf)), __FILE__, __LINE__);
  }
  //suprHomeInit();
  suprDFSHomeInit();

  /*
  printf("\033[0;32m\n");
  printf("%s\n", argv[0]);
  printf("[deprecated] SUPR_DFS_HOMEUSR: %s\n", SUPR_DFS_HOMEUSR);
  printf("[deprecated] SUPR_DFS_HOMESYS: %s\n", SUPR_DFS_HOMESYS);
  printf("shm_name: %s\n\n", shm_name);
  printf("host: %s\n", Supr_hostname);
  printf("port: %d\n", port);
  printf("dir : %s\n", dir);
  printf("\033[0m\n");
  */

  

  //errno = 0;
  //int tty = isatty(STDOUT_FILENO);
  // if(errno) tty = 0;
  //if(tty == 0 && HtmlDir_check() == -1)
  //if(HtmlDir_check() == -1)
  //  exit(EXIT_FAILURE);


  /*
  if(TRUE){
      char buf[256];
      fprintf(stderr, "Time: %s (%s:%d)\n", Exec_timestamp(buf, sizeof(buf)),
      			__FILE__, __LINE__);
  }
  */

  // chdir
  
  char CWD_PATH[PATH_MAX];
  {
    //setDir(SUPR_DFS_HOMEUSR, SYS_COMMAND_DFS_NAMENODE);
    //Exec_setStdout(SYS_COMMAND_DFS_NAMENODE, _stdout);
    // check data subdirectory
    getcwd(CWD_PATH, PATH_MAX);
    char data_dir[strlen(CWD_PATH)+strlen("/data")+1];
    sprintf(data_dir, "%s/data", CWD_PATH);
    printf("data_dir: %s\n", data_dir);

    DIR *dir = opendir(data_dir);
    if(!dir){
      if(errno == ENOENT){ // create
        int rc =  mkdir(data_dir, 0700);
	if(rc == -1){
          printf("Error: mkdir(%s), %s\n", data_dir, strerror(errno));
          exit(EXIT_FAILURE);
	}
      } else { // create
        printf("Error: opendir(%s), %s\n", data_dir, strerror(errno));
        exit(EXIT_FAILURE);
      }
    } else {
      closedir(dir);
    }
  }
 
  /*
  if(TRUE){
      char buf[256];
      fprintf(stderr, "Time: %s (%s:%d)\n", Exec_timestamp(buf, sizeof(buf)),
      			__FILE__, __LINE__);
  }
  */

  //startStdlog(CWD_PATH);

  DD_init();

  // open shm_io
  shm_io_info_t *io = NULL;
  if(shm_name){
    io = shm_io_open(shm_name);
    shm_io_write(io, io->out, shm_name, strlen(shm_name)+1);
  }

  threads = newVector(TRUE);

  // initialized R_eval
  //printf("Initialize R...\n");
  __R_init(argc, argv);
  //printf("Initialized R\n");

#ifndef SUPR_DEBUG
  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
#endif

  // for debug ...
  {
    struct sigaction sa;
    sa.sa_sigaction = Namenode_SigactionSIGINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldIntAct);
  }
  {
    struct sigaction sa;
    sa.sa_sigaction = Namenode_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, &R_oldSegvAct);
  }
  {
    struct sigaction sa;
    sa.sa_sigaction = Namenode_SigactionSIGPIPE;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGPIPE, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = Namenode_SigactionSIGUSR2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);
  }


  supr_options_t save_supr_options;
  memcpy(&save_supr_options, &Supr_options, sizeof(supr_options_t));

//
  {
    //BEGIN_R_EVAL();
//       SEXP call = PROTECT(LCONS(install("library"),
//                           CONS(mkString("supr3"), R_NilValue)));
       SEXP call = PROTECT(LCONS(install("library"),
                           CONS(mkString(PACKAGE_NAME), R_NilValue)));
       eval(call, R_GlobalEnv);
       UNPROTECT(1);
    //END_R_EVAL();

       /*
     if(TRUE){
      char buf[256];
      fprintf(stderr, "Time: %s\n", Exec_timestamp(buf, sizeof(buf)));
      REprintf("\033[0;32mSupr_sysHome: %s\n", Supr_sysHome);
      REprintf("Supr_usrHome: %s\033[0m\n", Supr_usrHome);
     }
     */
  }
//
  memcpy(&Supr_options, &save_supr_options, sizeof(supr_options_t));
  Supr_infov = Supr_options.info;
  Supr_debug = Supr_options.debug;
  Supr_verbose = Supr_options.verbose;



  // start timeout monitor
  //supr_thread_t *timeout_monitor = startTimeoutMonitor();
  //vectorAdd(threads, timeout_monitor);

  if(port == -1){
    SEXP dfs = findVar(install("dfs"), SuprContextEnv);
    if(dfs != R_UnboundValue){
      const char *addr = CHAR(asChar(dfs));
      if(strstr(addr,":")) {
        port = atoi(strstr(addr,":")+1);
        nports = strstr(strstr(addr,":")+1, "+")? 0 : 1;
      }
    } 
  }

  /*
  if(port < 1024){
    port = 1024;
    port_plus = TRUE;
  }
  SocketConn_reuseAddr = port_plus ?  FALSE : TRUE;
  */

  if(!socket_connections)
    socket_connections = newVector(TRUE);

  
  free(main_thread->name);
  main_thread->name = strdup("main");

  if(vectorSize(threads)==0)
    vectorAdd(threads, main_thread);

  // start backend
  // basic_info("port: %d%s", port, nports?"":"+");

  supr_thread_t *backend = startBackend(port);
  vectorAdd(threads, backend);

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
      vectorElementAt(socket_connections, 0);
    //printf("main:"); conn->print(conn);
    if(io) shm_io_write(io, io->out, &conn->port, sizeof(int));
    if(mmap_io_name) {
      mmap_io_t *mmap_io = mmap_io_open(mmap_io_name);
      sprintf(mmap_io->buf, "//%s:%d",conn->host, conn->port);
      mmap_io->data_size = strlen(mmap_io->buf) + 1;
      printf("buf: %s, locking ...\n", mmap_io->buf);
      pthread_mutex_lock(&mmap_io->lock);
        printf("buf: %s, signal!\n", mmap_io->buf);
        pthread_cond_signal(&mmap_io->cond);
      pthread_mutex_unlock(&mmap_io->lock);
    }

  pthread_mutex_unlock(&main_thread->mutex);


  timedwait_queue = newVector(TRUE);
  timedwait_thread  = startTimedwaitThread(); // no longer used?
  vectorAdd(threads, timedwait_thread);

  // start User interface ?
  /*
  supr_thread_t *ui = startUI(io);
  vectorAdd(threads, ui);
  */
  
  // start R_eval service
  R_REPL(main_thread, argc, argv);
  /*
  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
  pthread_mutex_unlock(&main_thread->mutex);
  */
  
  void *retval;
  pthread_join(backend->ptid, &retval);

  printf("[%s] retval = %p\n", __func__, retval);

  return 0;

//  exit(1);
}

