
#include "supr.h"
#include "util.h"

#include <sys/types.h>
#include <sys/wait.h>

#include <netinet/tcp.h>


#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)

#define RUN_AS_DAEMON_PROC
#define msg_color "\033[0;36m"

extern char *Supr_sysHome;
extern char *Supr_usrHome;
extern int Supr_debug;

struct sigaction R_oldPipeAct; // FIXME

supr_socket_conn_t *masterServerConn = NULL;
//supr_socket_conn_t *errorConn  = NULL;

static const char *notify_addr = NULL;
static const char *info_addr = NULL;
extern supr_socket_conn_t *info_sc; 
extern pthread_mutex_t Supr_syncMutex;
extern pthread_cond_t  Supr_syncCond;
extern void *Supr_syncObject;
extern SEXP SuprEnv;


static char msg[1024];
extern char *cmd;
extern char *X11_str; // X11Forwarding


extern SEXP SuprContextEnv;
extern int localThreadServerPort;
/*
int Cluster_sendSimpleMessage(const char *msg, const char *color, int type, int level){
  //
  switch(type){
    case DEBUG_INFO_TYPE: if(!Supr_debug) return -1;
    case VERBOSE_INFO_TYPE: if(!Supr_verbose) return -1;
    default: break;
  }

  if(!info_sc) {
          fprintf(stderr, "%s%s\033[0m: %s\n", color, __func__, msg);
          return -1;
  }

  int cmd = CLUSTER_INFO;

  pthread_mutex_lock(&Supr_syncMutex);
   	write(info_sc->fd, &cmd, sizeof(int));
             unsigned char buf[8];
             snprintf(buf, 8, "%s", color);
             write(info_sc->fd, buf, sizeof(buf));
             write(info_sc->fd, &type, sizeof(int));
             write(info_sc->fd, &level, sizeof(int));
             ssize_t len = strlen(msg)+1;
             write(info_sc->fd, &len, sizeof(ssize_t));
             write(info_sc->fd, msg, len);
             int rc;
             read(info_sc->fd, &rc, sizeof(int));

  pthread_mutex_unlock(&Supr_syncMutex);

  return rc;

}
*/


char *html_dir = NULL;
const char *index_html_header = 
"<!DOCTYPE html>\n"
"<HEAD>\n"
"  <TITLE>SupR2</TITLE>\n"
"  <META charset=\"utf-8\">\n"
"</HEAD>\n";

const char *cmd2char(int cmd);
extern void supr_info(const char *format, ...);
extern char *connTypeToStr(int type);
extern char *Exec_timestamp(char *buf, size_t buf_size);

extern void Html_sendFile(supr_socket_conn_t *conn, const char *file_name,
		const char *ct);

extern ssize_t Socket_send(int socket, const void *buffer, size_t length, int flags);

#define send(s, b, len, flags) Socket_send((s), (b), (len), (flags))


const char *src_func;
const char *src_file;
int src_line;
void __src_info(const char *func, const char *file, int line)
{
  src_func = func;
  src_file = file;
  src_line = line;
}

void master_info(const char *format, ...)
{
  size_t buf_size = 1024;
  char buf[buf_size];
  va_list ap;
  va_start(ap, format);
  int n = vsnprintf(buf, buf_size, format, ap);

  if(html_dir) {
    char path[PATH_MAX];
    if(masterServerConn)
      sprintf(path, "%s/master.%s.%d.txt", html_dir, Supr_hostname,
		      masterServerConn->port);
    else 
      sprintf(path, "%s/master.%s.txt", html_dir, Supr_hostname);
    FILE *fs = fopen(path, "a+");
    if(!fs) {
      fprintf(stderr, "Error: %s, %s\n", path, strerror(errno));
      //return;
    } else {

      fprintf(fs, "%s (%s:%d) ", src_func, src_file, src_line);
      fprintf(fs, "%s", buf);
      fclose(fs);
      return;
    }

  }

  {
    if(Supr_verbose == FALSE) return;

    va_list ap;
    supr_thread_t *cth = currentThread();
    if(cth) printf("[INFO %d %d]", cth->pid, cth->tid);
    va_start(ap, format);
    vprintf(format, ap);

    fflush(stdout);
  }

}


#define printf __src_info(__func__, __FILE__, __LINE__); master_info

extern vector_t *socket_connections;

extern class_t *Runnable_class;

size_t __read__(int fd, void *buf, size_t size);

#define OUTPUT_BUF_SIZE 65536

size_t Output_bufSize = OUTPUT_BUF_SIZE;

typedef struct output_buf_struct {
  const char *host;
  int   port;
  pid_t pid;
  size_t  data_size;
  size_t  buf_size;
  size_t  offset;
  struct output_buf_struct *next; 
  //char  data[OUTPUT_BUF_SIZE];
  FILE *file;
  char  data[0];
} output_buf_t;

output_buf_t *output_buf_root = NULL;

#define USE_CHECKSUM
#ifdef  USE_CHECKSUM
#define MSG_HEADER_SIZE 2*INT_SIZE
int (*cfncn)(char *, int, uint32_t *, off_t *) = Supr_crc32;
#else
#define MSG_HEADER_SIZE 0
#endif

extern void Html_sendError(supr_socket_conn_t *conn, const char *file_name);
/*
void Html_sendError(supr_socket_conn_t *conn, const char *file_name)
{
        char protocol[] = "HTTP/1.1 400 Bad Request\r\n";
        char servName[] = "Server:simple web server\r\n";
        char cntType[] = "Content-type:text/html\r\n\r\n";

        //char content[] = "<html><head><title>SupR2</title></head>" "<body><p><center><h3>Error 400: couldn't find the requested object" "</h3></center></p></body></html>";

        char content[1024];
        sprintf(content, "<html><head><title>SupR2</title></head>"
		       	"<body><p><center><h3>Error 400:"
		        " couldn't find the requested object</h3><a>%s</a>"
		       	"</center></p></body></html>", file_name);
        //char cntLen[]   = "Content-length:2048\r\n";

        char cntLen[256];
        sprintf(cntLen,	"Content-length:%ld\r\n", strlen(content));

	int fd = conn->fd;
        send(fd, protocol, strlen(protocol), 0);
        send(fd, servName, strlen(servName), 0);
        send(fd, cntLen, strlen(cntLen), 0);
        send(fd, cntType, strlen(cntType), 0);
        send(fd, content, strlen(content), 0);
        
        //removeConn(conn);
	return;
}
*/

void Html_sendTaskrunnerOutput(supr_socket_conn_t *wsc,
	       supr_socket_conn_t *worker, int pid)
{
  char protocol[] = "HTTP/1.0 200 OK\r\n";
  char servName[] = "Server:SupR2\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  char cntType[256];

  if(pid == 0){
    // generate a list of href
    /*
    sprintf(buf, "worker: //%s:%d, taskrunner: %d\n", worker->host,
		  worker->port, pid);
    sprintf(buf+strlen(buf), "worker.att: %p\n", worker->att);
    */

    vector_t *trs = (vector_t*) worker->att;
    int ntr = trs? vectorSize(trs) : 0;

    unsigned char buf[1024+128*ntr];
    sprintf(buf, "%s", index_html_header);
    sprintf(buf + strlen(buf), "<BODY>\n<h3>Taskrunners</h3>\n<OL>\n");
    for(int i=0; i<ntr; i++){
      output_buf_t *out = (output_buf_t *) vectorElementAt(trs, i);

      sprintf(buf + strlen(buf),
	      "\t<LI><a href=\"taskrunner.%s.%d.%d.txt\">"
	      "taskrunner.%s.%d.%d.txt</a>\n\t</LI>\n",
		      worker->host, worker->port, out->pid,
		      worker->host, worker->port, out->pid);
    }
    sprintf(buf + strlen(buf), "</OL>\n</BODY>\n");

    snprintf(cntLen, sizeof(cntLen), "Content-length:%ld\r\n", strlen(buf));

    char *ct = "text/html";
    snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n", ct);

    int fd = wsc->fd;
    send(fd, protocol, strlen(protocol), 0);
    send(fd, servName, strlen(servName), 0);
    send(fd, cntLen, strlen(cntLen), 0);
    send(fd, cntType, strlen(cntType), 0);

    send(fd, buf, strlen(buf), 0);

  } else {

    //unsigned char buf[1024];
    //sprintf(buf, "worker: //%s:%d, taskrunner: %d\n", worker->host, worker->port, pid);
    output_buf_t *out = NULL;
    vector_t *trs = (vector_t*) worker->att;
    if(trs){
      for(int i=0; i<vectorSize(trs); i++){
        output_buf_t *u = (output_buf_t *) vectorElementAt(trs,i);
	if(u->pid == pid) {
		out = u;
		break;
	}
      }
    }

    if(out){

      size_t buf_size = out->data_size >= out->buf_size ? out->buf_size :
	      out->offset;
      buf_size += 1;
      unsigned char buf[buf_size];

      if(out->data_size >= out->buf_size){
	size_t n = out->buf_size - out->offset;
        memcpy(buf, out->data+out->offset, n);
        memcpy(buf +n, out->data, out->offset);
      } else {
        memcpy(buf, out->data, buf_size);
      }
      buf[buf_size-1] = 0;

      //fprintf(stderr, "buf_size: %ld\n", buf_size); 
      char _buf[buf_size+1];
      memcpy(_buf, buf, buf_size);
      _buf[buf_size] = 0;
      //fprintf(stderr, "%s", _buf); 
      //fprintf(stderr, "\nstrlen(_buf): %ld\n", strlen(_buf));
      if(strlen(_buf) < buf_size-1){
        fprintf(stderr, "\nWarning: embedded zeros???\n");
        fprintf(stderr, "More: %s\n...\n", _buf + strlen(_buf)+1);

	for(int i=0; i<buf_size-1; i++){
          if(buf[i] == 0){
            fprintf(stderr, "\nWarning: embedded zero at position %d, offset: %ld\n",
			    i, out->offset);
	    buf[i] = '\n';
	  }
	}
      }

      snprintf(cntLen, sizeof(cntLen), "Content-length:%ld\r\n", strlen(buf));



      char *ct = "text/plain";
      snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n", ct);
	
      int fd = wsc->fd;
      send(fd, protocol, strlen(protocol), 0);
      send(fd, servName, strlen(servName), 0);
      send(fd, cntLen, strlen(cntLen), 0);
      send(fd, cntType, strlen(cntType), 0);

      send(fd, buf, strlen(buf), 0);
    } else {
	    // send 400 error ...
      char path[PATH_MAX];
      sprintf(path, "taskrunner.%s.%d.%d.txt", worker->host, worker->port,
		      pid);
      Html_sendError(wsc, path);
    }
  }
}

void Html_update(void *data)
{
  if(!data){
    char path[PATH_MAX];
    sprintf(path, "%s/index.html", html_dir);
    FILE *fs = fopen(path, "w+");
    if(!fs) {
      printf("Error: %s, %s\n", path, strerror(errno));
      return;
    }

    fprintf(fs, "%s", index_html_header);
    fprintf(fs, "<BODY>\n");

    fprintf(fs, "<h3>Workers</h3>\n<OL>\n");
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
      if(sc->type == WORKER_CONN){
        fprintf(fs, "  <LI><a href=\"worker.%s.%d\">//%s:%d</a></LI>\n",
	   sc->host, sc->port, sc->host, sc->port);
      }
    }
    fprintf(fs, "</OL>\n");

    fprintf(fs, "<h3>Driver</h3>\n<OL>\n");
    for(int i=vectorSize(socket_connections)-1; i>=0; i--){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
	      vectorElementAt(socket_connections, i);
      if(sc->type == DRIVER_CONN){
        fprintf(fs, "  <LI><a href=\"driver.%s.%d\">//%s:%d</a></LI>\n",
	   sc->host, sc->port, sc->host, sc->port);
      }
    }
    fprintf(fs, "</OL>\n");

    fprintf(fs, "</BODY>\n");
    fclose(fs);
    return;
  }

  // CLUSTER_BYTE_MSG
  supr_socket_conn_t *sc = (supr_socket_conn_t *) data;
  int fd = sc->fd;

#ifdef  USE_CHECKSUM

  //fprintf(stderr,"%s://%s:%d\n",connTypeToStr(sc->type), sc->host, sc->port); 

  int cmd;
  ssize_t n = __read__(fd, &cmd, INT_SIZE);
  size_t buf_size;
  n = __read__(fd, &buf_size, SIZE_SIZE);
  //fprintf(stderr, "cmd: %s, size: %ld\n", cmd2char(cmd), buf_size);
  //sleep(10);
  char buf[buf_size];
  __read__(fd, buf, buf_size);
  uint32_t cksum_val;
  __read__(fd, &cksum_val, sizeof(uint32_t));

  uint32_t my_cksum_val;
  off_t    cksum_len;
  cfncn(buf, buf_size, &my_cksum_val, &cksum_len);
  if(my_cksum_val != cksum_val){
    fprintf(stderr, "Error: cfncn, cksum_val: %d, my_cksum_val: %d\n",
		    cksum_val, my_cksum_val);
    sleep(120);
    return;
  }

  int *hdr = (int*) buf;
  int pid  = hdr[0];
  int type = hdr[1];
  size_t len  = buf_size - MSG_HEADER_SIZE;
  char *msg = buf + MSG_HEADER_SIZE;

  //write(fd, &my_cksum_val, sizeof(uint32_t));

#else
  int cmd;
  ssize_t size = read(fd, &cmd, INT_SIZE);
  //Make it simple: pid, type[stdout/stderr], msg_size, msg
  pid_t pid; // 0: worker/driver
  int type;
  int len;
  __read__(fd, &pid,  INT_SIZE);
  __read__(fd, &type, INT_SIZE);
  __read__(fd, &len,  INT_SIZE);
  char msg[len];
  __read__(fd, msg, len);
#endif

  /*
  if(pid>0) {
//    fprintf(stderr, "\033[0;31mpid: %d, type: %d, len: %ld, msg:\033[0m %s\n", pid, type, len, msg);
    return;
  }
  */
  ////////////////////////////////////////////////

  if(sc->type != WORKER_CONN && sc->type != DRIVER_CONN){
    return;
  }


  output_buf_t *out = output_buf_root; 
  while(out){
    if(out->pid == pid && out->port == sc->port
		    && strcmp(out->host, sc->host)==0)
	    break;
    out = out->next;
  }

  //fprintf(stderr, "pid: %d, type: %d\n", pid, type);
  // fixme: keep the file alive for pid=0?

  if(!out){
    out = (output_buf_t *) malloc(sizeof(output_buf_t)
		    + (pid ? Output_bufSize : 0));
    out->host = sc->host;
    out->port = sc->port;
    out->pid = pid;
    out->buf_size = pid ? Output_bufSize : 0; // delete me ...
    out->data_size = 0;
    out->offset = 0;
    if(pid == 0) {
      char path[PATH_MAX];
      sprintf(path, "%s/%s.%s.%d.txt", html_dir,
	    sc->type == WORKER_CONN ? "worker" : "driver",
	    sc->host, sc->port);
      out->file = fopen(path, "a+");
      if(!out->file) {
        printf("Error: %s, %s\n", path, strerror(errno));
      }
      
    } else {
      //out->data[0] = 0;
      out->file = NULL;

      if(!sc->att) {
        sc->att = newVector(FALSE);
      }
      vectorAdd((vector_t*) sc->att, out);
    }
    
    out->next = output_buf_root;
    output_buf_root = out;

  }

  if(out->file){
    fprintf(out->file, "%s", msg);
    fflush(out->file);
    return;
  }

  {// check embedded zeros
    for(int i=0; i<len; i++){
       if(msg[i]==0){
	    fprintf(stderr, "Warning: read, embedded zeros, %d, %ld\n",
			    i, len-1);
	    fprintf(stderr, "Warning: %s\n", msg);
	    fprintf(stderr, "Warning: read, embedded zeros, %d, %ld\n",
			    i, len-1);
	    msg[i] = '\n';
        }
    }
  }

  while(TRUE){
    if(len > 0 && out->offset >= out->buf_size)
	    out->offset = 0;

    if(len <= out->buf_size - out->offset){
      memcpy(out->data + out->offset, msg, len);
      //if(out->data_size < out->buf_size)
      out->data_size += len;
      out->offset += len;
      break;
    } else {
      size_t n =  out->buf_size - out->offset;
      memcpy(out->data + out->offset, msg, n);
      out->data_size += n;
      out->offset = n;
      len -= n;
      msg += n;
//      fprintf(stderr, "next segment... //%s:%d, pid: %d, n: %ld, len: %ld, buf_size: %ld\n", sc->host, sc->port, pid, n, len, out->buf_size);
      //sleep(1);
    }
  }

  return;

#define NOTE_USE_THE_FOLLOWING
#ifndef NOTE_USE_THE_FOLLOWING
  ///////////////////////////////////////////////

  if(pid > 0 && type == 2){


    char path[PATH_MAX];
    sprintf(path, "%s/%s.%s.%d.%d.txt", html_dir,
	    sc->type == WORKER_CONN ? "taskrunner" : "driver",
	    sc->host, sc->port, pid);
    /*
    FILE *file = fopen(path, "a+");
    if(!file) {
        printf("Error: %s, %s\n", path, strerror(errno));
    }

    //fprintf(file, "%s", msg);
    //fflush(file);
    
    */
    //fprintf(stderr, "pid: %d, type: %d -> file: %s\n", pid, type, path);

    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if(fd == -1) {
        perror(path);
	return;
    }
    write(fd, msg, len);
    close(fd);
    return;
  }

  if(type==1 && out->data_size + len < out->buf_size) {
    memcpy(out->data + out->data_size, msg, len);
    out->data_size += strlen(msg);
    return;
  }

  // FIXME: make it more efficient ...
  char path[PATH_MAX];
  if(pid){
    sprintf(path, "%s/%s.%s.%d.%d.txt", html_dir,
	    sc->type == WORKER_CONN ? "taskrunner" : "driver",
	    sc->host, sc->port, pid);
  } else {
    sprintf(path, "%s/%s.%s.%d.txt", html_dir,
	    sc->type == WORKER_CONN ? "worker" : "driver",
	    sc->host, sc->port);
  }


  FILE *fs = fopen(path, "a+");
  if(!fs) {
      printf("Error: %s, %s\n", path, strerror(errno));
      return;
  }

  {
    struct stat sb;
    int fd = fileno(fs);
    if(fstat(fd, &sb) != -1){
      if(sb.st_size > 64*OUTPUT_BUF_SIZE){ // fixme
        void *ptr = malloc(sb.st_size);
	if(!ptr) {
          fprintf(stderr, "Error: %s\n", strerror(errno));
          fclose(fs);
	  return;
	}
        lseek(fd, 0, SEEK_SET);
        read(fd, ptr, sb.st_size);
        fclose(fs);
        unlink(path);
        fs = fopen(path, "a+");
        fd = fileno(fs);
        size_t half = sb.st_size/2;
        write(fd, ptr + half, sb.st_size-half);
        free(ptr);
      }
    }
  }
//  fprintf(stderr, "lseek(fileno(fs), 0, SEEK_CUR): %ld\n", lseek(fileno(fs), 0, SEEK_CUR));
  //if(type == 2) fprintf(fs, "<p><font color=#FF0000>");

  out->data[out->data_size] = 0;
  fprintf(fs, "%s", out->data);
  fprintf(fs, "%s", msg);
  out->data_size = 0;
  out->data[0] = 0;
  //if(strlen(msg) && msg[strlen(msg)-1] =='\n') fprintf(fs, "<br>");

  //if(type == 2) fprintf(fs, "</p></font>");

  fclose(fs);

  return;
#endif
#undef NOTE_USE_THE_FOLLOWING
}

extern supr_thread_t *main_thread;

//int *worker_windows = NULL;

extern char *SUPR_HOMEUSR;
extern char *SUPR_HOMESYS;
extern void suprHomeInit();

extern SEXP R_simpleTryEval(SEXP expr, SEXP env, int *errorOccurred);
extern SEXP R_simpleTryEval4(SEXP(*func)(SEXP args), SEXP args, SEXP env,
	       	int *errorOccurred);

extern void SocketConn_closeAll(vector_t *conns, int do_shutdown);

int Worker_useWindow = FALSE;
void Master_handleStartWorkers();

//int pipe_fd[2];
int cmd_argc = 0;
char **cmd_argv = NULL;

/*
#define BEGIN_R_EVAL()     do      {       \
  pthread_mutex_lock(&main_thread->mutex);	\
  void *dummy; 	\
  int __save_R_CStackStart__ = R_CStackStart;	\
  R_CStackStart = (unsigned long) &dummy

#define END_R_EVAL()   \
  R_CStackStart = __save_R_CStackStart__;	\
  pthread_mutex_unlock(&main_thread->mutex);	\
} while(0)
*/

extern void Thread_dumper();
extern supr_thread_t *main_thread;
extern vector_t *threads;

//vector_t *threads = NULL;

// is it the same as void Driver_shutdown(void *data)?
static void ThreadServer_shutdown(void *data)
{ //Thread_dumper();

  supr_thread_t *cth = currentThread();
  verbose_info("%s: data=\"%s\", pthread=%s", __func__, (char*)data,
  	cth? cth->name : NULL);

  if(cth == main_thread){
    for(int i=vectorSize(threads)-1; i>=0; i--){
      supr_thread_t *th = (supr_thread_t *)vectorElementAt(threads,i);
      if(th==cth) continue;
      int rc = pthread_cancel(th->ptid);
      //if(rc != 0) error_info("pthread_cancel(%p), %s", th->ptid, rc == ESRCH ? "'pthread' not found":"unknown");

      //if(rc == 0){
        void *retval;
        rc = pthread_join(th->ptid, &retval);
        char buf[256];
        sprintf(buf, "%p", retval);
        verbose_info("pthread_cancel(%s): %s", th->name,
                retval == PTHREAD_CANCELED ?  "PTHREAD_CANCELED" :
		(retval == ThreadServer_shutdown ?  "PTHREAD_EXITED" : buf));

      //} else { error_info("pthread_cancel(%p), %s", th->ptid, rc == ESRCH ? "'pthread' not found":"unknown"); }
    }
    exit(EXIT_SUCCESS);
  } else {
    pthread_cancel(main_thread->ptid);
    pthread_exit(ThreadServer_shutdown);
    //pthread_exit(PTHREAD_CANCELED); // 
    // wait...
  }
}

char *dupstr(const char *str)
{
  return memcpy(malloc(strlen(str)+1), str, strlen(str)+1);
}

//extern SEXP R_CStackStart;
extern unsigned long R_CStackStart;
extern unsigned long R_CStackLimit;
extern int R_Interactive;
extern void run_Rmainloop(void);

extern void myR_SigactionSegv(int sig, siginfo_t *ip, void *context);
extern void c_backtrace();



static shm_io_info_t *__io__ = NULL;


extern vector_t *cleanups;
extern void doCleanups();

int system_exit(int n)
{
  // cleanups later...
	/*
  if(cleanups){
    for(int i=vectorSize(cleanups)-1; i>=0; i--){
      do_t *cleanup = (do_t *) vectorElementAt(cleanups, i);
      printf("[%s] do_cleanup %p\n", __func__, cleanup);
      cleanup->_do_(cleanup->data);
    }
  }
  */

  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
     supr_socket_conn_t *sc = (supr_socket_conn_t *)
           vectorElementAt(socket_connections, i);
     if(sc->type == WORKER_CONN){
       int msg[] = {CLUSTER_SHUTDOWN, 1};
       write(sc->fd, msg, sizeof(msg));
     }
     shutdown(sc->fd, SHUT_RDWR); // unnecessary
     close(sc->fd);
  }


  printf("%s: terminating ...\n", Supr_hostname);

  int status;
  //pid_t pid = waitpid(-1, &status, 0);
  pid_t pid;
  /*
  for(;;){
    errno = 0;
    pid = waitpid(-1, &status, WNOHANG);
    fprintf(stderr,"\033[0;35mwaitpid: %d, info: %s\033[0m\n",
		    pid, strerror(errno));
    if(pid == -1) break;
  }
  */

 
  /*
  if(worker_windows){
    for(int i=0; worker_windows[i]; i++){
      fprintf(stderr, "\033[0;35mpid: %d, windown_pid: %d\033[0m\n",
		     getpid(), worker_windows[i]);
    }
  }
  */

  fflush(stdout);


  doCleanups();

 // sleep(100);

  //kill(getppid(), SIGKILL); //???


  exit(n);
}



int isDCLInterrupted = FALSE;
int isDisconnected = FALSE;

size_t __dcl_read__(int fd, void *ptr, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /* else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(listenfd, &readfds) = %d\n", __func__,
               FD_ISSET(fd, &readfds));
      } */
    }

    int n = read(fd, ptr + len,  size - len);
    //printf("[%s] isDCLInterrupted = %d n = %d\n", __func__, isDCLInterrupted, n);
    if(isDCLInterrupted) {
//      isDCLInterrupted = FALSE;
    //  return -1;
	    // clean...???
      errorcall(R_NilValue, "interrupted");
    } else if(n == -1) {
      errorcall(R_NilValue, "SIGPIPE?");
    } else if(n == 0) {
      printf("[%s] disconnected\n", __func__);
      isDisconnected = TRUE;
      errorcall(R_NilValue, "disconnected");
    }
    //if(n == -1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  return len;
}

// testing
//extern size_t (*__read__)(int, void *, size_t);


#include <readline/readline.h>
#include <readline/history.h>

 
void  myR_SigactionDCLInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  //c_backtrace();

  //if(isDCLInterrupted) exit(1);
  fprintf(stderr, "\033[0;31m[%s] FIXME: EXIT (%s, %d)\033[0m\n", __func__,
           __FILE__, __LINE__);
//  exit(1);

//  char *line = readline (">>> ");
//  printf("%s\n", line);
//  int c;
//  read(3, &c, 1);


  isDCLInterrupted = TRUE;

  if(FALSE && __io__){
    int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
    shm_io_write(__io__, __io__->out, array, sizeof(array));
  }
//  errorcall(R_NilValue, "segmentation fault"); //??? FIXME
//  exit(1); // not good...

  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);

}

//int isTaskrunnerInterrupted = FALSE;

//extern int isInterrupted;

char interrupt_message_buf[256];

/*
void  myR_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
  //c_backtrace();

  isTaskrunnerInterrupted = TRUE;
  isInterrupted = TRUE;

   

  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);
  //sigaction(SIGINT, &R_oldactInt, NULL);

  //errorcall(R_NilValue, msg); //??? FIXME
  //exit(1);
}
*/

/*
typedef struct tr_cntxt_struct {
  shm_io_info_t *io;
  int job_id;
  int tr_id;
  pid_t pid;
} tr_cntxt_t;

tr_cntxt_t tr_cntxt = {NULL, -1, -1, 0};
*/
extern tr_cntxt_t tr_cntxt;

char *cntxt2str(){
  char *s = malloc(256);
  sprintf(s, "\033[0;32mpid=%d, job_id=%d, tr_id=%d, %s\033[0m",
		  tr_cntxt.pid,  tr_cntxt.job_id,
		  tr_cntxt.tr_id, tr_cntxt.io->shm_info.shm_name);
  return s;
}

void  (*myTryEval_SigactionInt)(int sig, siginfo_t *ip, void *context) =NULL;

void  SystemExit_SigactionInt(int sig, siginfo_t *ip, void *context){
	exit(EXIT_SUCCESS);
}

extern void sendDriverMessage(shm_io_info_t *io, int job_id, int tr_id, const char *msg);
extern void rjni_io_err_write(shm_io_info_t *io, const char *msg);

#define  BACKTRACE_SIZE 256
#include <execinfo.h>

char *myC_backtrace()
{
  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  size = backtrace(array, BACKTRACE_SIZE);
  strings = backtrace_symbols(array, size);

  int length = 0;
  for (i = 0; i < size; i++) //fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    length += strlen(strings[i]) + 1;
  
  char *str = (char*)malloc(length);
  char *s = str;
  for (i = 0; i < size; i++){
    memcpy(s, strings[i], strlen(strings[i]));
    s += strlen(strings[i]);
    *s = i== (size-1) ? 0 : '\n';
    s++;
  }

  free(strings);
  
  return str;
}

extern void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write);

char *myR_simpleTraceback();
//extern int isInterrupted;


/*
void  myR_SigactionTaskRunnerUsr2(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n",
		  __func__, pthread_self());
  //c_backtrace();

  isInterrupted = TRUE;

  int rc = sem_trywait(&__io__->err->sem_wr);
  fprintf(stderr, "\033[0;31m[%s] sem_trywait : %d\033[0m\n", __func__, rc);
  char *msg = "interrupted";
  if(rc == 0){
    msg = (char*) (__io__->err+1);
    msg[__io__->err->data_size-1] = 0;
    fprintf(stderr, "\033[0;31m[%s] message = %s\033[0m\n", __func__, msg);
    __io__->err->data_size = 0;
    sem_post(&__io__->err->sem_wr);
  }
  if(strlen(msg)==0) msg = "interrupted";
  int size = strlen(msg);
  if(sizeof(interrupt_message_buf)-1 < size)
	  size = sizeof(interrupt_message_buf)-1;
  memcpy(interrupt_message_buf, msg, size);
  interrupt_message_buf[size] = 0;

  
  kill(getpid(), SIGINT);

}
*/


/*
void  myTryEval_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n",
		  __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  c_backtrace();

  int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
  shm_io_write(__io__, __io__->out, array, sizeof(array));

  exit(1);
}
*/





/*
typedef struct shm_struct {
  size_t size;
  sem_t sem_w; // by java thread
  sem_t sem_r; // by java thread
} shm_struct_t;

typedef struct _shm_info {
  char *shm_name;
  void *mem_ptr;
} shm_info_t;
*/

//JNIEXPORT jlong JNICALL Java_RJNI_shmOpen (JNIEnv *javaEnv, jobject thisObj, jstring jshm_name)

/*
shm_info_t *shmOpen(const char *cshm_name) {
//  const char *cshm_name = (*javaEnv)->GetStringUTFChars(javaEnv, jshm_name, NULL);
  printf("[%s] cshm_name: %s\n", __func__, cshm_name);
  shm_info_t *shm_ptr = malloc(sizeof(shm_struct_t));

  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR | O_EXCL, 0600);
  //int fd = shm_open(cshm_name, O_CREAT | O_TRUNC | O_RDWR, 0600);
  int fd = shm_open(cshm_name, O_RDWR, 0600);
  if(fd==-1){
    printf("[%s] ERROR: shm_open(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  size_t segment_size = sysconf(_SC_PAGE_SIZE);

  void *mem_ptr = mmap(0, segment_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd,0);
  if(mem_ptr == MAP_FAILED) {
    printf("[%s] ERROR: mmap(%s), %s\n", __func__, cshm_name,
                    strerror(errno));
    return 0;
  }

  close(fd);
  shm_ptr->shm_name = malloc(strlen(cshm_name)+1);
  sprintf(shm_ptr->shm_name, "%s", cshm_name);
//  (*javaEnv)->ReleaseStringUTFChars(javaEnv, jshm_name, cshm_name);

  shm_ptr->mem_ptr = mem_ptr;

  shm_struct_t * ssp = (shm_struct_t *)mem_ptr;
  ssp->size = segment_size;
  //sem_init(&ssp->sem_w, 1, 0);
  //sem_init(&ssp->sem_r, 1, 0);
  //sem_wait(&ssp->sem_w); sem_wait(&ssp->sem_r);
  int val;
  sem_getvalue(&ssp->sem_w, &val);
  printf("[%s] sem_getvalue(&ssp->sem_w, &val): %d\n", __func__, val);
  sem_getvalue(&ssp->sem_r, &val);
  printf("[%s] sem_getvalue(&ssp->sem_r, &val): %d\n", __func__, val);

  return shm_ptr;
}
*/

typedef void (*sighandler_t)(int);

//this worked 
void myTryEval_SIGINT_handler(int sig){
  fprintf(stderr, "[%s] is called on %d\n", __func__, getpid()); 
  fprintf(stdout, "[%s] is called on %d\n", __func__, getpid()); 
}

//extern char *__r2str(SEXP x, char *buf, int buf_size, int debug);
char *__r2str(SEXP x, char *buf, int buf_size, int debug)
{ 
       	return NULL;
}

char *sexp2char(SEXP x)
{
   int buf_size = 128*200;
   char buf[buf_size];
   //char *s = __r2str(x, buf, buf_size, 0);
   char *s = __r2str(x, buf, buf_size, 0);
   char *c = malloc(strlen(s)+1);
   memcpy(c, s, strlen(s)+1);
   return c;
}

char *myR_simpleTraceback()
{
  RCNTXT *cntxt = R_GlobalContext;
  int len  = 0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    len += strlen(c)+1+1+32;
    fprintf(stderr, "cntxt = %p: %s\n", cntxt, c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  char *str = malloc(len);
  char *s = str;
  cntxt = R_GlobalContext;
  int i=0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    if(i){ *s ='\n'; s++;}

    char b[16];
    sprintf(b, "%d: ", i++);
    memcpy(s, b, strlen(b));
    s += strlen(b);

    memcpy(s, c, strlen(c));
    s += strlen(c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  *s = 0;
  return str;
}


//extern int R_PPStackTop
//extern const char *R_curErrorBuf();
SEXP R_myTryEval(SEXP expr, SEXP env, int *errorOccurred)
{
#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue
//#define SETJMP(x) setjmp(x)

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  } 


  /*
#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif
*/

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));


  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      val = eval(expr, env);
      UNPROTECT(1);

    } else {

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  //UNPROTECT(1);

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n", 
		    __FILE__, __LINE__, save, R_PPStackTop);
  }

  return val;



#undef null
#undef R_ToplevelContext
}

extern int R_SignalHandlers;
void testing(int argc, char **argv){

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    //printf("R_CStackStart = %ld\n", R_CStackStart);
    //printf("R_CStackLimit = %ld\n", R_CStackLimit);
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();
  }

 
  /*
  {
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));

    int errorOccurred;
    printf("OKAY??\n");
    SEXP value = R_myTryEval(expr, R_GlobalEnv, &errorOccurred);
    printf("OKAY\n");
  }


  RCNTXT *__R_ToplevelContext  = R_GlobalContext;
  while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;

  printf("R_ToplevelContext>handlerstack:\n");
  PrintValue(__R_ToplevelContext->handlerstack);

#define R_ToplevelContext __R_ToplevelContext

  printf("R_ToplevelContext = %p\n", R_ToplevelContext);
  printf("R_GlobalContext   = %p\n", R_GlobalContext);
  printf("R_SignalHandlers   = %d\n", R_SignalHandlers);
  */
  //SETJMP(R_Toplevel.cjmpbuf);
/*
Defn.h:# define SIGSETJMP(x,s) sigsetjmp(x,s)
Defn.h:# define SETJMP(x) sigsetjmp(x,0)
Defn.h:# define SIGSETJMP(x,s) setjmp(x)
Defn.h:# define SETJMP(x) setjmp(x)
*/
//# define SETJMP(x) setjmp(x)
//  SETJMP(R_ToplevelContext->cjmpbuf);

  /*
  SETJMP(R_Toplevel.cjmpbuf);
    R_GlobalContext = R_ToplevelContext = R_SessionContext = &R_Toplevel;
    */
#define null R_NilValue
  /*
  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
  SEXP env = R_GlobalEnv;



  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

//  int count = 0;

  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

//    int succeeded = FALSE;
    if(!setjmp(R_ToplevelContext->cjmpbuf))
    //if(!setjmp(cntxt.cjmpbuf))
    {
      PrintValue(syscall);
   //   count++; if(count ==5) exit(1);
      printf("\033[0;31m%s: PrintValue\033[0m\n", __func__);
      val = PROTECT(eval(expr, env));
//      succeeded = TRUE;
    } else {
      val = PROTECT(mkString("pthread_error")); // to do
      setAttrib(val, install("class"), mkString("pthread_error"));
      PrintValue(val);
      printf("\033[0;35m%s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

  endcontext(&cntxt);
  */

  //exit(1);


  while(TRUE){

	  /*
    RCNTXT cntxt;
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
    SEXP env = R_GlobalEnv;
    SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

    begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    if(!setjmp(R_ToplevelContext->cjmpbuf))
    {
    */
        int errorOccurred;
        SEXP envir = R_GlobalEnv;
        SEXP expr = PROTECT(LCONS(install("stop"),
			    CONS(mkString("ERROR: TESTING"), R_NilValue)));
        SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(R_tryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(eval(expr, envir));
	printf("errorOccurred = %d\n", errorOccurred);
	if(errorOccurred)
	  fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
	else
          PrintValue(res);

	/*
    } else {
      printf("\033[0;35m[Error] %s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

    endcontext(&cntxt);
#undef null
*/

    //sleep(10);
  }

  //if(R_Interactive) run_Rmainloop();

  exit(1);
}

/*
typedef struct shm_data_header {
  int type;
  int padding;
  size_t size;
} shm_data_header_t;
*/
// Cluster.java:
#define TASK_RESULTS 303
#define TASK_EXIT    304

int  tr_get_shm_identityCode()
{
  static int code = 0;
  fprintf(stderr, "code = %d\n", code); 
  return code++;
}

static size_t __page_size__ = 0;
#define SHM_BLOCK_SIZE (2*__page_size__)

static socket_conn_t *__socket_conn__ = NULL;

extern SEXP SUPR_socketConnect(SEXP hostname, SEXP port, SEXP endian_str); 
extern SEXP SUPR_socketWrite(SEXP conn, SEXP x, SEXP endian_str);
extern SEXP SUPR_socketRead(SEXP conn, SEXP what, SEXP _n, SEXP endian_str); 
extern SEXP SUPR_socketReadObject(SEXP conn, SEXP env); 
extern SEXP SUPR_socketClose(SEXP conn); 
extern SEXP socketReadDCLEvent(SEXP socket_conn, SEXP env);

/*
void  dcl_error(const char *driver_host, int driver_port, int job_id,
	       	const char *msg, SEXP env)
{
  printf("%s: driver_host=%s\n", __func__, driver_host);
  printf("%s: driver_port=%d\n", __func__, driver_port);
  printf("%s: msg=%s\n", __func__, msg);

  SEXP host   = PROTECT(mkString(driver_host));
  SEXP port   = PROTECT(ScalarInteger(driver_port));
  SEXP endian = PROTECT(mkString("big"));
  SEXP conn   = PROTECT(SUPR_socketConnect(host, port, endian)); 

  SEXP x  = PROTECT(ScalarInteger(DCL_JOB_ERROR));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(ScalarInteger(job_id));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(mkString(msg));
  SUPR_socketWrite(conn, x, R_NilValue);

  SEXP ret  = SUPR_socketReadObject(conn, env); 
  UNPROTECT(7);


  printf("[%s] return\n", __func__);
  PrintValue(ret);

}
*/


/*
typedef struct sync_info_struct {
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  void (*run)(void *data);
  void *data;
  sem_t           sem_wait;
  sem_t           sem_notify;
} sync_info_t;
*/


void *rjni_shm_open(const char *cshm_name, size_t *size);

// argv[0] -DCL -port port -shm shm_name -name name
/*
int data_change_listener(int argc, char **argv)
{
  // parse args

  const char *driver_host = "localhost";
  int driver_port = 0;
  const char *shm_name = NULL;

  const char *dcl_name = "default";

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-port")==0 && i+1 < argc) {
      driver_port = atoi(argv[i+1]);
      i++;
    } else if(strcmp(argv[i], "-shm")==0 && i+1 < argc) {
      shm_name = argv[i+1];
      i++;
    } else if(strcmp(argv[i], "-name")==0 && i+1 < argc) {
      dcl_name = argv[i+1];
      i++;
    }
  }

  if(!driver_port){ // FIXME
    char *driver_log_file = "DriverDir/Driver.log";
    int fd = open(driver_log_file, O_RDONLY, 0600);
    if(fd != -1){
      struct stat statbuf;
      int rc = fstat(fd, &statbuf);
      if(rc == -1) {
        printf("[%s] Error (%s, %d): %s\n", __func__, __FILE__, __LINE__, strerror(errno));
      }
      size_t size = statbuf.st_size; // printf("%s: size=%ld\n", driver_log_file, size);
      char buf[size+1];
      read(fd, buf, size);
      close(fd); // printf("%s: %s\n", driver_log_file, buf);
      char *str = strstr(buf, ":");
      *str = 0;

      str++; // printf("%s: \"%s\"\n", driver_log_file, str);
      driver_port = atoi(str);

      driver_host = dupstr(buf+2);
      printf("%s: driver_host=%s\n", driver_log_file, driver_host);
      printf("%s: driver_port=%d\n", driver_log_file, driver_port);

    } else {
      printf("[%s] Error: %s\n", __func__, strerror(errno));
      exit(1);
    }
  }

  shm_io_info_t *io = NULL;

  tr_cntxt.io = io;
  tr_cntxt.pid = getpid();

  // initialize R
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);
  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    R_Interactive = TRUE; 
    setup_Rmainloop();
  }

  myTryEval_SigactionInt = myR_SigactionDCLInt;

  // add/change signal handler
#ifdef __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sa.sa_sigaction = myR_SigactionDCLInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
  }
#endif

  __read__ = __dcl_read__;

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }

  SEXP res = R_NilValue;

  {
    SEXP call = PROTECT(LCONS(install("source"),
                            CONS(mkString("jR.R"), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);

    //printf("\033[0;32m\n\n[%s] OKAY 00\n\n\033[0m", __func__);
  }

  SEXP socket_conn = R_NilValue;
  SEXP env = R_GlobalEnv;

  if(driver_port) {
    SEXP host = PROTECT(mkString(driver_host));
    SEXP port = PROTECT(ScalarInteger(driver_port));
    SEXP endian = PROTECT(mkString("big"));
    socket_conn = PROTECT(SUPR_socketConnect(host, port, endian));
    __socket_conn__ = R_ExternalPtrAddr(socket_conn);
    //printf("[%s] socket fd = %d\n\n", __func__, __socket_conn__->fd);
 
    defineVar(install("socket.conn"), socket_conn, R_GlobalEnv); // fixme
    UNPROTECT(4);
  }

  // # register as the default listener
#define DCL_CONN 4
  SEXP x = PROTECT(ScalarInteger(DCL_CONN));
  //printf("\033[0;33m"); PrintValue(socket_conn);
  SEXP y = SUPR_socketWrite(socket_conn, x, R_NilValue);
  //printf("[%s] y = ", __func__); PrintValue(y); printf("[%s] OKAY 01\n", __func__);

  y = SUPR_socketWrite(socket_conn, install(dcl_name), R_NilValue);
  //printf("[%s] dcl_name = %s y = ", __func__, dcl_name);
  //PrintValue(y); printf("[%s] OKAY 02\n", __func__);
  UNPROTECT(1);


  int job_id = -1;
  int tr_id = -1;
  tr_cntxt.job_id = job_id;
  tr_cntxt.tr_id =  tr_id;

  SEXP envir = env;

  defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);
  defineVar(install(TR_TR_ID), ScalarInteger(tr_id), envir);
  SEXP ioPtr = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
  defineVar(install(TR_TR_IO), ioPtr, envir);
  UNPROTECT(1);


  SEXP expr = R_NilValue;

  int X11 = TRUE;

  SEXP event = R_NilValue;


  if(shm_name){

	 
    size_t size;
    void *mem_ptr = rjni_shm_open(shm_name, &size);
    printf("5/6: [%s] shm_name = %s\n", __func__, shm_name);
    printf("5/6: [%s] size = %ld, mem_ptr = %p\n", __func__, size, mem_ptr);

    sem_t *sem_wr = (sem_t *) mem_ptr;
    pid_t pid = ((pid_t*)(sem_wr+1))[0];
    printf("[%s] pid = %d, RDriver.pid = %d\n", __func__, getpid(), pid);
    pid = getpid();
    memcpy(sem_wr + 1, &pid, sizeof(pid_t));

    sem_post(sem_wr);
    munmap(mem_ptr, size);
   
  }

  while(TRUE){

    printf("\033[0;32m\n[%d] Next Job\n\033[0m", getpid()); 
    isDCLInterrupted = FALSE;
    isDisconnected   = FALSE;

    int errorOccurred;
    
    int save = R_PPStackTop;

    fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);

    int pi_envir;
    PROTECT_WITH_INDEX(envir, &pi_envir);
    int pi;
    PROTECT_WITH_INDEX(expr, &pi);


    SEXP nextEvent = PROTECT(LCONS(install(".Call"),
	    CONS(mkString("socketReadDCLEvent"),
	    CONS(socket_conn, CONS(envir, R_NilValue)))));

    SEXP event = PROTECT(R_myTryEval(nextEvent, envir, &errorOccurred));

    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(event, 0)));

      if(isDCLInterrupted){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
        break;
      } else if(isDisconnected){
        fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "disconnected");
        break;
      } else {
        UNPROTECT(4);
        continue;
      }
    } else if(TYPEOF(event) == NILSXP){
        UNPROTECT(4);
	continue;
    }
    defineVar(install("event"), event, envir);
    //PrintValue(event);

    const char *event_name = CHAR(PRINTNAME(VECTOR_ELT(event, 2))); // FIXME
    //printf("\033[031m[%s] event_name = \"%s\"\n", __func__, event_name);
    if(strcmp(event_name, "new()")==0){

       SEXP event_value = VECTOR_ELT(event, 3); // FIXME
       printf("event_value:\n"); PrintValue(event_value);

       printf("expr:\n");
       expr = VECTOR_ELT(event_value, 0); // FIXME
       REPROTECT(expr, pi);
       PrintValue(expr);

       job_id = INTEGER(VECTOR_ELT(event_value, 2))[0]; // FIXME
       printf("job_id: %d\n", job_id);
       defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);

       printf("envir:\n");
       envir = VECTOR_ELT(event_value, 1); // FIXME
       //REPROTECT(envir, pi_envir);
       if(TYPEOF(envir) == NILSXP){
         envir =  allocSExp(ENVSXP);
         REPROTECT(envir, pi_envir);
       //} else if(TYPEOF(envir) == VECSXP){
       } else if(TYPEOF(envir) != ENVSXP){
         //dcl_error(driver_host, driver_port, job_id, "invalid environment variable", R_GlobalEnv);
       }
       SET_ENCLOS(envir, R_GlobalEnv);
       PrintValue(envir);

    } else {
      printf("[%s] Whoops: event_name = \"%s\"\n", __func__, event_name);
      UNPROTECT(4);
      continue;
    }
    printf("\033[0m\n");
    if(save + 4 != R_PPStackTop) {
      fprintf(stderr, "Warning: save + 4 = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save + 4, R_PPStackTop, __FILE__, __LINE__);
    }

    SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
    //printf("[%s] errorOccurred = %d\n", __func__, errorOccurred);
    if(errorOccurred){
      fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
      //dcl_error(driver_host, driver_port, job_id, CHAR(STRING_ELT(res, 0)), envir); } else 
      PrintValue(res);

    
    if(isDCLInterrupted){
      fprintf(stderr, "\033[0;31m%s\033[0m\n\n", "INTERRUPTED");
      break;
    }

    if(!errorOccurred)
      UNPROTECT(5);

    if(save != R_PPStackTop) {
      fprintf(stderr, "Warning: save = %d, R_PPStackTop = %d (%s, %d)\n", 
			  save, R_PPStackTop, __FILE__, __LINE__);
    }

  }

  //if(R_Interactive) run_Rmainloop();

  fprintf(stderr, "\033[0;31m%s\033[0m", "exit");
  exit(0);

}
*/

#include "util.h"

extern int SocketConn_reuseAddr;
extern supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);
extern supr_socket_conn_t *serverSocketAccept(supr_socket_conn_t *serverConn);

size_t __read__(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      } 
    }

    int n = read(fd, buf + len,  size - len);

    if(n <= 0){
      printf("[%s] read, n = %d, %s\n", __func__, n, strerror(errno));
      return -1;
//	    errorcall(null, "read, n = %d, %s", n, strerror(errno));
    }

    /*  n = -1: If no messages are available at the socket, the receive calls wait  for
       a  message  to arrive, unless the socket is nonblocking (see fcntl(2)),
       in which case the value -1 is returned and the external variable  errno
       is set to EAGAIN or EWOULDBLOCK.  The receive calls normally return any
       data available, up to the requested amount,  rather  than  waiting  for
       receipt of the full amount requested.
       */

    len += n;
  }
}

#define R_SERIALIZED_OBJECT 171117121
//#define R_SERIALIZED_OBJECT 825768241

void sendDriverInfoToWorkers(supr_socket_conn_t *driver)
{
  unsigned char buf[strlen(driver->host)+128];
  ((int*)buf)[0] = DRIVER_INFO;
  sprintf(buf+2*sizeof(int), "//%s:%d", driver->host, driver->port);
  ((int*)buf)[1] = strlen(buf+2*sizeof(int))+1;

  for(int i=0; i<vectorSize(socket_connections); i++){
      
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
         vectorElementAt(socket_connections, i);

    if(conn->type == WORKER_CONN)
      write(conn->fd, buf, 2*sizeof(int) + strlen(buf+2*sizeof(int))+1);

  }
}

void sendDriverInfoTo(supr_socket_conn_t *worker)
{
  for(int i=0; i<vectorSize(socket_connections); i++){
      
    supr_socket_conn_t *conn = (supr_socket_conn_t *)
         vectorElementAt(socket_connections, i);

    if(conn->type == DRIVER_CONN){
      unsigned char buf[strlen(conn->host)+128];
      ((int*)buf)[0] = DRIVER_INFO;
      sprintf(buf+2*sizeof(int), "//%s:%d", conn->host, conn->port);
      ((int*)buf)[1] = strlen(buf+2*sizeof(int))+1;
      write(worker->fd, buf, 2*sizeof(int) + strlen(buf+2*sizeof(int))+1);
    }

  }
}

extern class_t *Runnable_class;

void removeConn(supr_socket_conn_t *conn)
{
  printf("\033[0;31m//%s:%d, fd: %d\033[0m\n", conn->host, conn->port,
		  conn->fd);
  int type = conn->type;
  close(conn->fd);
  vectorRemoveElement(socket_connections, conn);

  if(conn->att){
    vector_t *att = (vector_t *) conn->att;
    for(int i=vectorSize(att)-1; i>=0; i--){
      object_t *obj = (object_t *) vectorRemove(att, i);
      if(obj->class == Runnable_class){
         run_t *r = (run_t *) obj;
         r->run(r->data);
      }
    }
  }
  /*
  if(type == DFS_NAMENODE_CONN){
                doCleanup();
     pthread_mutex_lock(&main_thread->mutex);
       main_thread->data = PTHREAD_INTERRUPTED;
       pthread_cond_signal(&main_thread->cond);
     pthread_mutex_unlock(&main_thread->mutex);
  }
  */
}


void Master_handleGetContext(supr_socket_conn_t *conn)
{
  int cmd, fd = conn->fd;
  read(fd, &cmd, INT_SIZE);
  int n = vectorSize(socket_connections); // LOCK?

  so_t *s = NULL;
  size_t size;

  BEGIN_R_EVAL();
    SEXP ret = PROTECT(CONS(R_NilValue, R_NilValue));
    SEXP t = ret;
    for(int i=0; i < vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
             vectorElementAt(socket_connections, i);
      char buf[256];
      sprintf(buf, "//%s:%d", sc->host, sc->port);
      SETCDR(t, CONS(mkString(buf), R_NilValue));
      t = CDR(t);
      sprintf(buf, "%s", connTypeToStr(sc->type));
      SET_TAG(t, install(buf));
    }

    errno = 0;
    int rc = isatty(STDOUT_FILENO);
    if(errno ==0 && rc){
      char buf[PATH_MAX];
      int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
      char *name = rc ? strerror(errno) : buf;
      SETCDR(t, CONS(mkString(name), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("stdout"));
    } else {
      char buf[PATH_MAX];
      ssize_t n = readlink("/proc/self/fd/1", buf, sizeof(buf));
      buf[n] = 0;
      SETCDR(t, CONS(mkString(buf), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("stdout"));

      n = readlink("/proc/self/fd/2", buf, sizeof(buf));
      buf[n] = 0;
      SETCDR(t, CONS(mkString(buf), R_NilValue));
      t = CDR(t);
      SET_TAG(t, install("stderr"));
    }

    s = SO_valueOf(CDR(ret), &size);
    UNPROTECT(1);
  END_R_EVAL();

  write(fd, s, size); // handle errors ...
  free(s);
}

void handleShutdown(supr_socket_conn_t *conn)
{
           system_exit(CLUSTER_SHUTDOWN);
}

void handleHTTP_POST(supr_socket_conn_t *conn)
{
  int fd = conn->fd;

  size_t buf_size = 4096;
  unsigned char buf[buf_size+1];
  ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
  len = __read__(fd, buf, len);

  // fixme ... read to get "\r\n\r\n" ...
  // while(!strstr(buf, "\r\n\r\n")){
  //   ... ... Html_readHeader(...)
  // }

  buf[len++] = 0;
  fprintf(stderr, "\033[0;36m[%s://%s:%d]\n\"%s\"\033[0m\n",
            connTypeToStr(conn->type), conn->host, conn->port, buf);

  char *file_name = strstr(buf, " /")+2;
  char *str = strstr(file_name, " HTTP/");
  *str = 0; str++;

  if(strcmp(file_name, "shutdown.R")==0){
    handleShutdown(conn);
    return; // no return
  }

  Html_sendError(conn, file_name);

}

void handleCommand(supr_socket_conn_t *conn);

int __handleCommand(supr_socket_conn_t *conn){
  handleCommand(conn);
  return 0;
}

void handleCommand(supr_socket_conn_t *conn)
{
  int fd = conn->fd;

  static int prev_cmd = -1;

  int cmd;
  {
    ssize_t len = 0;
    int print_recv = FALSE;
    int count = 0;
    for( ;; ) {
      len = recv(fd, &cmd, INT_SIZE, MSG_PEEK | MSG_DONTWAIT);
      if(len == INT_SIZE)
	      break;
      else if(len == 0) {
         error_info("%s: len=0", __func__);
         removeConn(conn);
	 return;
      }
      else if(len == -1) {
         error_info("%s", strerror(errno));
         removeConn(conn);
	 return;
      } else {
         fprintf(stderr,
	 "(%s:%d) slow network? len: %ld, host: %s:://%s:%d, prev_cmd: %s\n",
			 __FILE__, __LINE__, len,
			 connTypeToStr(conn->type),
			 conn->host, conn->port,
			 cmd2char(prev_cmd));

	 int _cmd = CLUSTER_BYTE_MSG;
	 for(int i=0; i<len; i++){
           fprintf(stderr, "%d. %u ? %u\n", i, ((unsigned char*)&cmd)[i],
			   ((unsigned char*)&_cmd)[i]);
	 }
	 count ++;
	 if(count>30){
		 fprintf(stderr, "Error:\n");
		 break;
		 int c;
		 while(recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT)){
		         read(fd, &c, 1);
			 fprintf(stderr, "%c", c);
		 }
		 fprintf(stderr, "\n");
		 return;
	 }
	 sleep(1);
	 print_recv = TRUE;
      }
    }

    //if(print_recv || TRUE) {
      verbose_info("recv: size=%ld, cmd=%d (%s)", len, cmd, cmd2char(cmd));
    //}

    prev_cmd = cmd;

  }

//#define DRIVER_REGISTER 11 
//#define DRIVER_CONN 3
  switch(cmd){
    case DRIVER_REGISTER:
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   conn->type = DRIVER_CONN;
	   conn->port = msg[1];
	   sendDriverInfoToWorkers(conn);

	   Html_update(NULL);
	   /*
	   run_t *runnable = newRunnable(Html_update, NULL);
	   pthread_mutex_lock(&main_thread->mutex);
	     main_thread->data = runnable;
	     pthread_cond_signal(&main_thread->cond);
	   pthread_mutex_unlock(&main_thread->mutex);
	   */
	 }
         return; //break;

    case WORKER_REGISTER:
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   conn->type = WORKER_CONN;
	   conn->port = msg[1];
	   sendDriverInfoTo(conn);

	   Html_update(NULL);
	   /*
	   run_t *runnable = newRunnable(Html_update, NULL);
	   pthread_mutex_lock(&main_thread->mutex);
	     main_thread->data = runnable;
	     pthread_cond_signal(&main_thread->cond);
	   pthread_mutex_unlock(&main_thread->mutex);
	   */
	   //
	   {
             int flags =1;
             int rc = setsockopt(conn->fd, SOL_TCP, TCP_NODELAY,
                      (void *)&flags, sizeof(flags));
             if(rc == -1) perror("setsockopt");
           }
	   //

	 }
         return; //break;

    case CLUSTER_SHUTDOWN:
	 {
	   int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
	   write(fd, msg, INT_SIZE);
	 }
         handleShutdown(conn);
         return;

    case CLUSTER_PING:
         {
           size_t size = read(fd, &cmd, sizeof(int));
	   printf("\033[0;36m[PING] Read, size: %ld, cmd: %d\n", size, cmd);
	   cmd = CLUSTER_PONG;
           size = write(fd, &cmd, sizeof(int));
	   printf("\033[0;36m[PING] Write, size: %ld\n", size);
         }
         return;

    case CLUSTER_MASTER_STOP:
         {
           size_t size = read(fd, &cmd, sizeof(int));
           System_shutdown(strdup(cmd2char(cmd)));
         }
         return;

    case CLUSTER_GET_CONTEXT:
         Master_handleGetContext(conn);
         return;

    case CLUSTER_START_WORKERS:
	 {
           size_t size = read(fd, &cmd, sizeof(int));
	   pthread_mutex_lock(&main_thread->mutex);
             main_thread->data = Master_handleStartWorkers;
	     pthread_cond_signal(&main_thread->cond);
	   pthread_mutex_unlock(&main_thread->mutex);
	 }
         return;

    case CLUSTER_CONTEXT_OBJECTS:
         {
           handleClusterList(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_EXISTS:
         {
           handleClusterExists(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_PUT:
         {
           handleClusterAssign(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_GET:
         {
           handleClusterContextGet(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_DOCALL:
         {
           handleClusterContextDoCall(conn, SuprEnv);
         }
         return;

         return;

    case SET_CONN_PID:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
           int pid;
           read(fd, &pid, sizeof(int));
           conn->pid = pid;
           int type;
           read(fd, &type, sizeof(int)); // ?
           //int rc = 0; write(fd, &rc, sizeof(int)); // ?
         }
         return;



    case CLUSTER_BYTE_MSG:
	 Html_update(conn);
	 return;

    case HTTP_POST:
	 handleHTTP_POST(conn);
	 break;

    case HTTP_GET:
	 break;

	 /*
    case CLUSTER_MASTER_NULL:
	 {
           int cmd;
           size_t size = read(fd, &cmd, INT_SIZE);
//         printf("cmd: %d\n", cmd);
           write(fd, &cmd, INT_SIZE);
           read(fd, &cmd, INT_SIZE);
//         printf("cmd: %d\n", cmd);
	 }
         return;
	 */

    default:
        printf("Unknown cmd: %d from %s:://%s:%d\n", cmd,
		       	connTypeToStr(conn->type), conn->host, conn->port);
	break;
  }


  /*
  if(conn->type == WEB_CLIENT_CONN){
    size_t buf_size = 4096;
    unsigned char buf[buf_size+1];
    ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
    len = __read__(fd, buf, len);
    buf[len++] = 0;
    fprintf(stderr, "\033[0;32m[//%s:%d]\n\"%s\"\033[0m\n",
		    conn->host, conn->port, buf);
   
    return;
  }
  */


  if(cmd == HTTP_GET) { // WebClient?
    size_t buf_size = 4096;
    unsigned char buf[buf_size+1];
    ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
    len = __read__(fd, buf, len);
    buf[len++] = 0;
    //fprintf(stderr, "\033[0;36m[%s://%s:%d]\n\"%s\"\033[0m\n", connTypeToStr(conn->type), conn->host, conn->port, buf);

    //if (strncmp(buf, "GET / HTTP/", strlen("GET / HTTP/")) == 0)
    /*
    if (strncmp(buf, "GET /", strlen("GET /")) == 0
        && strstr(buf, " HTTP/1.1\r\n"))
    {
      conn->type = WEB_CLIENT_CONN;
      char *s = strtok(buf, "\r\n");
      for(; s; s=strtok(NULL, "\r\n")){
        fprintf(stderr, "||\"%s\"||\n", s);
      }
    }
    */

    if(strncmp(buf, "GET ", strlen("GET ")) == 0){
      char *file_name = strstr(buf, " /")+2;
      char *s = strstr(file_name, " HTTP/1.1");
      *s = 0;
      //fprintf(stderr, "\033[0;31mGET file: \"%s\"\033[0m\n", file_name);
      if(strlen(file_name) == 0)
      {
        file_name = "index.html";
        //fprintf(stderr, "\033[0;31mGET file: \"%s\"\033[0m\n", file_name);
      } /* else if(strcmp(file_name, "favicon.ico") == 0) {
	//sprintf(buf, "400\r\n\r\rn");
        //write(fd, buf, strlen(buf));

	Html_sendError(conn, file_name);
        return;
      }*/


      if(strcmp(file_name, "index.html")==0)
      { // OK
#define BUF_SIZE  2048
#define BUF_SMALL  100
        char protocol[] = "HTTP/1.1 200 OK\r\n";
        char servName[] = "Server:simple web server\r\n";
        char cntLen[] = "Content-length:2048\r\n";
        char cntType[BUF_SMALL];
        char buf[BUF_SIZE];
//        FILE* sendFile;

	const char *text = "message";
	text = index_html_header;

        char *ct = "text/html";
        //char *ct = "text/plain";

        //sprintf_s(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n", ct);
        snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n", ct);

	/*
        if (fopen_s(&sendFile, fileName, "r") != 0)
        {
          SendErrorMSG(sock);
          return;
        }
	*/

        send(fd, protocol, strlen(protocol), 0);
        send(fd, servName, strlen(servName), 0);
        send(fd, cntLen, strlen(cntLen), 0);
        send(fd, cntType, strlen(cntType), 0);

	/*
        while (fgets(buf, BUF_SIZE, sendFile) != NULL) {
          send(fd, buf, strlen(buf), 0);
        }
	*/
	sprintf(buf, "%s", text);
        send(fd, buf, strlen(buf), 0);


	sprintf(buf, "<BODY>\n");
        send(fd, buf, strlen(buf), 0);
	{ file:///home/outlier/u43/chuanhai/.supr/html/master.liu1.stat.purdue.edu.7202.txt
//	    "\t<LI><a href=\"master.%s.%d.txt\">stdout and stderr</a></LI>\n"
          sprintf(buf, "<h4>Master</h4>\n<UL>\n"
	    "\t<LI><a href=\"stdout.txt\">stdout</a></LI>\n"
	    "\t<LI><a href=\"stderr.txt\">stderr</a></LI>\n"
	    "\t<LI><a href=\"info.txt\">info</a></LI>\n"
	    "\t<LI><a href=\"supr.conf\">conf</a></LI>\n"
	    "\t<LI><a href=\"logo.png\">logo</a></LI>\n"
	    "</UL>\n");
//	    Supr_hostname, masterServerConn->port);
          send(fd, buf, strlen(buf), 0);

          sprintf(buf, "<h4>Workers</h4>\n<OL>\n");
          send(fd, buf, strlen(buf), 0);

          for(int i=vectorSize(socket_connections)-1; i>=0; i--){
            supr_socket_conn_t *sc = (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
            if(sc->type == WORKER_CONN){
              //sprintf(buf, "  <LI><a href=\"worker.%s.%d\">//%s:%d</a></LI>\n", sc->host, sc->port, sc->host, sc->port);

              //sprintf(buf, "  <LI>//%s:%d<p>\n", sc->host, sc->port);
              sprintf(buf, "  <LI><a href=\"http://%s:%d\">//%s:%d</a></LI>\n",
			      sc->host, sc->port,
			      sc->host, sc->port);
              send(fd, buf, strlen(buf), 0);

	      /*
              sprintf(buf, "\t<UL>\n\t\t<LI><a href=\"worker.%s.%d.txt\">"
			   "stdout and stderr</a></LI>\n",
                	      sc->host, sc->port);
              sprintf(buf+strlen(buf), "\t\t<LI><a href=\"taskrunner.%s.%d.html\">"
			      "taskrunners</a></LI>\n\t</UL>\n",
                	      sc->host, sc->port);
              send(fd, buf, strlen(buf), 0);

              sprintf(buf, "    </p></LI>\n");
              send(fd, buf, strlen(buf), 0);
	      */
            }
          }
          sprintf(buf, "</OL>\n");
          send(fd, buf, strlen(buf), 0);

          sprintf(buf, "<h4>Driver</h4>\n<OL>\n");
          send(fd, buf, strlen(buf), 0);
          for(int i=vectorSize(socket_connections)-1; i>=0; i--){
            supr_socket_conn_t *sc = (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
            if(sc->type == DRIVER_CONN){
              sprintf(buf, "  <LI><a href=\"http://%s:%d\">//%s:%d</a></LI>\n",
		      sc->host, sc->port, sc->host, sc->port);
	      send(fd, buf, strlen(buf), 0);

	      /*
              sprintf(buf, "  <LI>//%s:%d<p>\n", sc->host, sc->port);
              send(fd, buf, strlen(buf), 0);

              sprintf(buf, "\t<UL>\n\t\t<LI><a href=\"driver.%s.%d.txt\">"
			   "stdout and stderr</a></LI>\n\t</UL>\n",
                	      sc->host, sc->port);
              send(fd, buf, strlen(buf), 0);

              sprintf(buf, "    </p></LI>\n");
              send(fd, buf, strlen(buf), 0);
	      */

            }
          }
          sprintf(buf, "</OL>\n");
          send(fd, buf, strlen(buf), 0);
	  
	  char *shutdown = "<form action=\"/shutdown.R\" method=\"post\">"
    		"<input type=\"submit\" value=\"Shutdown\">"
    		"<label for=\"fname\">(</label>"
    		"<input type=\"text\" id=\"fname\" name=\"fname\">"
    		"<label for=\"fname\">)</label><br><br>"
    		"</form>";
          send(fd, shutdown, strlen(shutdown), 0);

          sprintf(buf, "</BODY>\n");
          send(fd, buf, strlen(buf), 0);
	}

	sprintf(buf, "</BODY>\n");
        send(fd, buf, strlen(buf), 0);
	//close(fd);
        removeConn(conn);

	return;

#undef BUF_SIZE
#undef BUF_SMALL
      }

      if(strcmp(file_name, "stdout.txt")==0
		      || strcmp(file_name, "stderr.txt")==0){
	fflush(stdout);
        Html_sendFile(conn, file_name, "text/plain");
      } else if(strcmp(file_name, "supr.conf")==0){
        char path[PATH_MAX];
	sprintf(path, "%s/supr.conf", Supr_usrHome);
        Html_sendFile(conn, path, "text/plain");
      } else if(strcmp(file_name, "logo.png")==0 
	      || strcmp(file_name, "favicon.ico")==0){
        char path[PATH_MAX];
	sprintf(path, "%s/data/%s", Supr_sysHome, file_name);
        Html_sendFile(conn, path, "image/png");
      } else if(strcmp(file_name, "info.txt")==0){
	char template[64];
        sprintf(template, "/tmp/supr_XXXXXX");
        int fd = mkstemp(template);
	FILE *file = fdopen(fd, "w");

	fprintf(file, "Connections:\n");
        for(int i=0; i < vectorSize(socket_connections); i++){
          supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(socket_connections, i);
          fprintf(file, "  %s://%s:%d\n", connTypeToStr(sc->type),
			  sc->host, sc->port);
        }
	// more to do ...

	fclose(file);
        Html_sendFile(conn, template, "text/plain");

	close(fd);
	unlink(template);


      } if(strncmp(file_name, "taskrunner.", strlen("taskrunner."))==0){
	char *host = file_name+strlen("taskrunner.");
	char *suffix = file_name + strlen(file_name) -1;
	while(suffix != file_name && *suffix != '.') suffix--; 

	//fprintf(stderr, "host: %s, suffix: %s\n", host, suffix);

	if(strcmp(".txt", suffix)==0) {
	  char *s = file_name + strlen(file_name) - strlen(".txt") - 1;
	  while(s != file_name && *s != '.') s--; 
	  int pid = atoi(s+1);

	  s--;

	  while(s != file_name && *s != '.') s--; 
	  int port = atoi(s+1);

	  //fprintf(stderr, "host: %s, port: %d, pid: %d\n", host, port, pid);

          for(int i=vectorSize(socket_connections)-1; i>=0; i--){
            supr_socket_conn_t *sc = (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
            if(sc->type == WORKER_CONN && sc->port == port &&
	       strncmp(host, sc->host, strlen(sc->host))==0){
	         Html_sendTaskrunnerOutput(conn, sc, pid);
		 return;
	    }
	  }
	} else if(strcmp(".html", suffix)==0) {
	  char *s = file_name + strlen(file_name) - strlen(".html") - 1;
	  while(s != file_name && *s != '.') s--; 
	  int port = atoi(s+1);

	  //fprintf(stderr, "host: %s, port: %d\n", host, port);
          for(int i=vectorSize(socket_connections)-1; i>=0; i--){
            supr_socket_conn_t *sc = (supr_socket_conn_t *)
              vectorElementAt(socket_connections, i);
            if(sc->type == WORKER_CONN && sc->port == port &&
	       strncmp(host, sc->host, strlen(sc->host))==0){
	         Html_sendTaskrunnerOutput(conn, sc, 0);
		 return;
	    }
	    //fprintf(stderr, "Whoops ... host: %s, port: %d\n", sc->host, sc->port);
	  }
	} else {
	}
        
	//return;
      }

      // attach taskrunner files to worker conns??? TODO
      char path[PATH_MAX];
      sprintf(path, "%s/%s", html_dir, file_name);
      struct stat sb;
      int file_fd = open(path, O_RDONLY);



      if(file_fd == -1 || fstat(file_fd, &sb) == -1){
        char protocol[] = "HTTP/1.0 400 Bad Request\r\n";
        char servName[] = "Server:simple web server\r\n";
        char cntLen[]   = "Content-length:2048\r\n";
        char cntType[] = "Content-type:text/html\r\n\r\n";
        char content[] = "<html><head><title>SupR2</title></head>"
          "<body><p><center><h3>Error 400: couldn't find the requested object"
          "</h3></center></p></body></html>";

        send(fd, protocol, strlen(protocol), 0);
        send(fd, servName, strlen(servName), 0);
        send(fd, cntLen, strlen(cntLen), 0);
        send(fd, cntType, strlen(cntType), 0);
        send(fd, content, strlen(content), 0);
        
        removeConn(conn);
	return;
      } else {
        char protocol[] = "HTTP/1.0 200 OK\r\n";
        char servName[] = "Server:SupR2\r\n";
        char cntLen[256]; // = "Content-length:2048\r\n";
	snprintf(cntLen, sizeof(cntLen), "Content-length:%ld\r\n", sb.st_size);

        char cntType[256];
        char *ct = "text/plain";
        snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n", ct);
	
        //char buf[BUF_SIZE];
	unsigned char *buf = (unsigned char *) malloc(sb.st_size);
	read(file_fd, buf, sb.st_size);

        send(fd, protocol, strlen(protocol), 0);
        send(fd, servName, strlen(servName), 0);
        send(fd, cntLen, strlen(cntLen), 0);
        send(fd, cntType, strlen(cntType), 0);

        send(fd, buf, sb.st_size, 0);

	return;
      }


      /*
    sprintf(buf, "HTTP/1.1 101 Switching Protocols\r\n"
      "Upgrade: websocket\r\n"
      "Connection: Upgrade\r\n"
		    "\r\n");
    write(fd, buf, strlen(buf));
    */

      /*
      buf[0] = 1 << 7;
      fprintf(stderr, "\033[0;31mbuf[0]: %d\033[0m\n", buf[0]);
      unsigned char opcode = 0x1;
      buf[0] |= opcode;
      fprintf(stderr, "\033[0;31mbuf[0]: %d\033[0m\n", buf[0]);
      char *msg="Hello!";
      buf[1] = strlen(msg);
      sprintf(buf+2, "%s", msg);
      write(fd, buf, 2+strlen(buf+2));
      write(fd, buf, 2+strlen(buf+2));
      */

//    return;

      //return;
    }


    /* response to Opening Handshake, marked by "GET /chat HTTP/1.1"
    sprintf(buf, "HTTP/1.1 101 Switching Protocols\r\n"
      "Upgrade: websocket\r\n"
      "Connection: Upgrade\r\n"
//      "Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=\r\n"
		    "\r\n");
    write(fd, buf, strlen(buf));
    return;
    */
  }

  fprintf(stderr, "Unknown cmd: %d from %s:://%s:%d\n", cmd,
		       	connTypeToStr(conn->type), conn->host, conn->port);
//#undef DRIVER_CONN 
//#undef DRIVER_DRIVER_REGISTER

  char c;
  //int cmd;
  //size_t size = read(fd, &c, 1);
  //size_t size = __read__(fd, &c, 1);
  /*
  int cmd;
  size_t size = read(fd, &cmd, sizeof(int));
  //printf("[%s] size = %ld\n", __func__, size);

  if(size == 0) {
    printf("[%s] fd = %d is disconnected\n", __func__, fd);
    vectorRemoveElement(socket_connections, conn);
    socketDestroy(conn);

    return;
  } else {
    printf("read [%s] size = %ld, cmd = %d\n", __func__, size, cmd);
  }
  */

  while(TRUE){
    size_t size = recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT);
    if(size == -1){
	    fprintf(stderr, "[%s] size = -1, no data ? %s\n", __func__, strerror(errno));
	    return;
    } else if(size == 0){
	    fprintf(stderr, "[%s] size = 0,  %s\n", __func__, strerror(errno));
	    return;
    } else {
	    read(fd, &c, 1);
	    fprintf(stderr, " %0x", c);
    }
  }

}

extern size_t fileWrite(const char*, char *, size_t);

void  pthread_key_destructor(void *data)
{
	printf("[%s] data= %p\n", __func__, data);
}


void backend_cleanup(void *arg)
{
  printf("close(masterServerSocket)\n");
  vector_t *conns = (vector_t *) arg;
  if(masterServerConn) 
    close(masterServerConn->fd);

  if(!conns) return;
  for(int i= vectorSize(conns)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)vectorElementAt(conns,i);
    printf("close(//%s:%d)\n", sc->host, sc->port);
    close(sc->fd);
    sc->class->finalize(sc->class, sc);
    vectorRemove(conns,i);
  }
}


int backend_run(int port)
{

  pthread_cleanup_push(backend_cleanup, socket_connections);

  int reuse_addr = port ? SocketConn_reuseAddr : FALSE;
  //supr_socket_conn_t *serverConn = serverSocketOpen(port, reuse_addr);
  supr_socket_conn_t *serverConn = serverSocketOpen3(port, reuse_addr, cmd);
  masterServerConn = serverConn;
  masterServerConn->type = MASTER_CONN;

  sprintf(msg, "port: %d to serverConn->port: %d", port, serverConn->port);
  Cluster_sendSimpleMessage(msg, "\033[0;37m", VERBOSE_INFO_TYPE, 0);

  /*
  if(notify_addr){
    char *host = strdup(notify_addr);
    char *s = strstr(host, ":");
    if(s){
	    *s = 0; s++;
	    int port = atoi(s);
	    supr_socket_conn_t *sc = socketOpen2(host, port);
	    if(sc){
	    int cmd = CLUSTER_CONNECT_MASTER;
	    write(sc->fd, &cmd, sizeof(int));
	    char buf[strlen(masterServerConn->host)+32];
	    sprintf(buf, "%s:%d", masterServerConn->host,
			    masterServerConn->port);
	    int len = strlen(buf)+1;
	    write(sc->fd, &len, sizeof(int));
	    write(sc->fd, buf, len);
	    int rc;
	    read(sc->fd, &rc, sizeof(int));
	    sprintf(msg, "Sent master_addr %s to %s", buf, notify_addr);
	    Cluster_sendSimpleMessage(msg, "\033[0;37m", VERBOSE_INFO_TYPE, 0);
	    close(sc->fd);
	    free(sc);
	    }
    }
    free(host);
  }
  */


  /*
  {
    char fileName[strlen(SUPR_HOMEUSR)+strlen("/master.log")+1];
    sprintf(fileName, "%s/thread.log", SUPR_HOMEUSR);
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\npid:%d\n", serverConn->port, getpid());
    size_t size = fileWrite(fileName, buf, strlen(buf)+1);

    printf("%s (pid=%d, tid=%ld)\n", buf, getpid(), syscall(SYS_gettid));
    printf("Started at %s\n\n", Exec_timestamp(buf, sizeof(buf)));
  }
  */



  socket_connections = newVector(TRUE);
  vectorAdd(socket_connections, serverConn); 

  /*
  {
    BEGIN_R_EVAL();
    //if(R_ToplevelExec(startRemoteDatanodes, data) == FALSE){ }
      SEXP threadServer = findVar(install("ths"), SuprContextEnv);
      if(threadServer != R_UnboundValue){
	if(TYPEOF(threadServer) == VECEXP && LENGTH(threadServer)>0)
	  threadServer = VECTOR_ELT(threadServer,0);
	SEXP addr = getAttrib(threadServer, install("address"));
	if(TYPEOF(addr) != NILSXP){
	}
      }
    END_R_EVAL();
  }
  */

  if(notify_addr){
    sprintf(msg, "%s:%d", serverConn->host, serverConn->port);
    Supr_notify(notify_addr, msg, CLUSTER_CONNECT_THREADSERVER);
  }

//  errorConn = 

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);
  /*
  {
    pthread_key_t key;
    printf("[%s] sizeof(key) = %ld\n", __func__, sizeof(key));
    pthread_key_create(&key, pthread_key_destructor);
    pthread_setspecific(key, serverConn);
//    pthread_key_delete(key);
    printf("[%s] serverConn = %p\n", __func__, serverConn);
  }
  */

  //printf("FOPEN_MAX = %d\n", FOPEN_MAX);
  //printf("_SC_OPEN_MAX = %ld\n", sysconf(_SC_OPEN_MAX));

  while(TRUE) {
      struct timeval tv;
      tv.tv_sec=1000;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      //int fd = serverConn->fd;
      int max_fd = 0;

      // lock ...  printf("\n");
      for(int i=0; i<vectorSize(socket_connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 

	//conn->print(conn);
        int fd = conn->fd;
        FD_SET(fd, &readfds);

	if(fd > max_fd) max_fd = fd;
      }
      //printf("Master: max_fd: %d\n", max_fd);

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      }  /*else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(serverConn->fd, &readfds) = %d\n", __func__,
               FD_ISSET(serverConn->fd, &readfds));
      } */

      for(int i = vectorSize(socket_connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
	       	continue;

	if(conn == serverConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(serverConn);
          basic_info("\033[0;31mMaster::clientConn, fd: %d\033[0m\n",
			  clientConn->fd);

          vectorAdd(socket_connections, clientConn); 
	} else {
          handleCommand(conn);
	}
      }

      //sleep(1);
  }



  sleep(60);
//  int k = FOPEN_MAX;

  pthread_cleanup_pop(TRUE);

  return 0;

}

//extern supr_thread_t *newThread(pthread_t ptid, pid_t, pid_t tid, int state);

void *backendRun(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);


  //supr_socket_conn_t *serverConn = (supr_socket_conn_t *) data;
  //data += sizeof(supr_conn_t *);
 // char *shm_name = (char*) data;
  int port = ((int*)data)[0];
  printf("[%s] shm_name = \"port = %d\"\n", __func__, port);

//  supr_socket_conn_t *sock_conn = socketOpen(serverConn);


  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  backend_run(port);

  pthread_exit(th);
  return NULL;
}

SEXP jobSubmit(SEXP);
SEXP help(SEXP);

typedef struct callable_struct {
  char *name;
  char *par_names;
  SEXP (*func)(SEXP args); // args: pairlist
  char *doc;
} callable_t;

callable_t R_callable_functions[] =
{
  { "help",   "(topic)",   help, "..." },
  { "submit", "(expr, data, ...)", jobSubmit, "..." },
};

SEXP jobSubmit(SEXP args){
  return R_NilValue;
}

SEXP help(SEXP topic){
  if(TYPEOF(topic) == NILSXP){
    return mkString("TO DO");
  } else {

    PrintValue(topic);

    const char *name = CHAR(asChar(topic));
    for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
      if(strcmp(R_callable_functions[i].name, name)==0){
        return mkString(R_callable_functions[i].doc);
      }
    }
    errorcall(R_NilValue, "no doc is available on '%s'", name);
    return R_UnboundValue;

  }
}

void UI_run(shm_io_info_t *io){


  while(TRUE){
    size_t size;
    void *bytes = shm_io_read(io, io->in, &size, NULL);
    int cmd = ((int*)bytes)[0]; 
    printf("[%s] cmd = %d\n", __func__, cmd);

    // BEGIN_R_EVAL:
    SEXP res = R_NilValue;
    BEGIN_R_EVAL();
      // testing
      SEXP raw = PROTECT(allocVector(RAWSXP, size));
      memcpy(DATAPTR(raw), bytes, size); 
      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, null)));
      SEXP val = PROTECT(eval(call, R_GlobalEnv));
    
      printf("\033[0;36m[%s] cmd = %d\n", __func__, cmd);
      PrintValue(val);
      printf("\033[0;36m[%s] cmd = %d\033[0m\n", __func__, cmd);

      const char *func_name = CHAR(asChar(VECTOR_ELT(val,0)));
      SEXP (*func)(SEXP args) = NULL;
      for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
        if(strcmp(R_callable_functions[i].name, func_name)==0){ // use qsearch
          func = R_callable_functions[i].func;
	  break;
        }
      }
      printf("\033[0;36m[%s] func = %s\033[0m\n", __func__, func_name);
      printf("\033[0;36m[%s] func = %p\033[0m\n", __func__, func);

      if(func) {
        int errorOccurred;
        res = R_simpleTryEval4(func, VECTOR_ELT(val,1), R_GlobalEnv,
		       	&errorOccurred);
      } else {
        res = R_NilValue; // change it to error 
      }

    END_R_EVAL();
    // END_R_EVAL:

    shm_io_write(io, io->out, bytes, size);
    free(bytes);
  }
}

void *UI_Run(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
		  (unsigned long) &data);
  *sth = th;

  /*
  pthread_key_t th_key;
  pthread_key_create(&th_key, thread_destructor);
  pthread_setspecific(th_key, th);
  */


  //supr_socket_conn_t *serverConn = (supr_socket_conn_t *) data;
  //data += sizeof(supr_conn_t *);
 // char *shm_name = (char*) data;
  //int port = ((int*)data)[0];
  shm_io_info_t *io = (shm_io_info_t *)data;
  printf("[%s] io = %p\n", __func__, io);

//  supr_socket_conn_t *sock_conn = socketOpen(serverConn);


  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  if(io) UI_run(io);

  pthread_exit(th);
  return NULL;
}




supr_thread_t *startBackend(int port)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, &sem, &sth};
  int rc = pthread_create(&thread, NULL, backendRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

supr_thread_t *startUI(shm_io_info_t *io)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {io, &sem, &sth};
  int rc = pthread_create(&thread, NULL, UI_Run, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

void __R_init(int argc, char **argv){
#ifndef SUPR_DEBUG
  int devNull = open("/dev/null", O_WRONLY);
  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);
  dup2(devNull, STDERR_FILENO);
  dup2(devNull, STDOUT_FILENO);
#endif

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  Rf_initialize_R(new_argc, new_argv);
  void *dummy;
  R_CStackStart = (unsigned long) &dummy;
  R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
  setup_Rmainloop();

#ifndef SUPR_DEBUG
  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
#endif

  R_thread_init();
}

void REPL_cleanup(void *data)
{
  //basic_info("\033[0;31mEXIT_SUCCESS\033[0m");
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
  sleep(2);
  //exit(EXIT_SUCCESS);
  ThreadServer_shutdown("main thread");
}



void  R_REPL(supr_thread_t *this_thread, int argc, char **argv)
{
  pthread_cleanup_push(REPL_cleanup, NULL); 

  Html_update(NULL);

  //printf("[%s]\n", __func__);
  //void (*run)() = NULL;
  void *what;
  while(TRUE){ // TODO
//    Cluster_sendSimpleMessage("\033[0;31mMaster: Runnable run ... ?\033[0m\n", "\033[0;37m", VERBOSE_INFO_TYPE, 0);
    pthread_mutex_lock(&this_thread->mutex);
      //printf("[%s] wait\n", __func__);
      pthread_cond_wait(&this_thread->cond, &main_thread->mutex);

      what = this_thread->data;
      this_thread->data = NULL;

    pthread_mutex_unlock(&this_thread->mutex);

//    Cluster_sendSimpleMessage("\033[0;31mRunnable run ... ?\033[0m\n", "\033[0;37m", VERBOSE_INFO_TYPE, 0);
    //if(run) run();
    if(what && ((object_t*)what)->class == Runnable_class){
      run_t * runnable = (run_t *) what;
      printf("\033[0;31mRunnable run ...!\033[0m\n");
      runnable->run(runnable->data);
      free(runnable);
    }


    //printf("[%s] eval\n", __func__);
    // eval ...
  }
  pthread_cleanup_pop(TRUE);
}

void  Master_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  supr_thread_t *cth = currentThread();
  if(cth == main_thread)
    System_shutdown(NULL);
  else
    pthread_kill(main_thread->ptid, SIGINT);
}

void  Master_SigactionSIGUSR2(int sig, siginfo_t *ip, void *context)
{
}

void  Master_SigactionSIGUSR1(int sig, siginfo_t *ip, void *context)
{
}

extern int Config_getPort(const char *name);

extern supr_xterm_t *supr_xterm3(const char *window_name, char **argv,
	       	int window);

extern int X11_check();

/* Note: Created ~/.ssh/config with
Host *
    ForwardAgent yes
    ForwardX11 yes 
 */

/* To make it simple:
 *
 * Master: -o NULL // no -out specification, use default master.out
 *         -o --window 
 *         -o filename
 *
 */

// Error constructing proxy for org.gnome.Terminal:/org/gnome/Terminal/Factory0: Could not connect: Connection refused
// Solved such problems once by killing 5641 25644 sshd: chuanhai@pts/9
// and
// 10351 32634 32637 sshd: chuanhai@notty


extern void Supr_startWorker(char *addr, const char *master,
	       	int argc, char** argv, int use_window);

//#define MASTER_START_WORKER_FUNC
#ifdef MASTER_START_WORKER_FUNC
void Master_startWorker(char *addr, const char *master, int argc, char** argv,
		int use_window)
{
  {
    Supr_startWorker(addr, master, argc, argv, use_window);
    return;
  }
    /*
    printf("addr: %s\n", addr);
    //printf("[%s]\n", __func__);

  */

  //int Worker_useWindow = 
  int Taskrunner_useWindow = FALSE;

  char *_window = NULL;
  for(int i=0; i<argc; i++){
    printf("\033[0;34margv[%d]: %s\033[0m\n", i, argv[i]);
    if( (
          strcmp(argv[i], "-stdout")==0 ||
	  strcmp(argv[i], "-taskrunner.stdout")==0
	) && i <argc-1 && strcmp(argv[i+1], "--window")==0) {
       _window = "-taskrunner.stdout --window";
       Taskrunner_useWindow = TRUE;
       //Worker_useWindow = TRUE;
    }
  }

  /*
  {
    char CMD_PATH[PATH_MAX];
    sprintf(CMD_PATH, "/usr/bin/ssh");

    char *hostname = strstr(addr, "//")+2;
    char *str = strstr(hostname, ":");
    *str = 0; str++;

    size_t len = 0;
    const char *format = "'cd supr/src; gnome-terminal --hide-menubar --title"
	 " \"Worker@%s\" --window-with-profile=Default"
	 " -- sh -c worker -port %s -master %s%s'";
    len += strlen(format);
    len += strlen(addr) + strlen(master)+strlen("--window")+3;

    char ssh_arg[len];

    sprintf(ssh_arg, "'cd supr/src; worker -port %s -master %s %s'", str,
		    master, _window ? _window : ""); 

    char cmd[strlen("ssh %s %s") + strlen(hostname)+strlen(ssh_arg)+1];
    sprintf(cmd, "ssh %s %s", hostname, ssh_arg);
    printf("\033[0;32mcmd: %s\033[0m\n", cmd);
    //int rc = system(cmd);
    len = strlen(cmd)+1;
    write(pipe_fd[1], &len, SIZE_SIZE);
    write(pipe_fd[1], cmd, len);

    return;
  }
  */

  pid_t pid = fork();
  if(pid) {
    //sleep(5);
	  printf("\n\n\n\n\n\n");
	  /*
    if(worker_windows == NULL){
      worker_windows = (int*) malloc(sizeof(int)*2);
      worker_windows[0] = pid;
      worker_windows[1] = 0;
    } else {
      int *p = worker_windows;
      int n = 0;
      while(p[n]) n++;
      n++;
      worker_windows = (int*) malloc(sizeof(int)*(n+1));
      memcpy(worker_windows+1, p, n*sizeof(int));
      worker_windows[0] = pid;
      free(p);

      //n = 0; while(worker_windows[n]) { n++; }
    }
    */
    return;
  }

  pid = getpid();

  supr_thread_t *cth = currentThread();
  cth->pid = pid;
  cth->tid = (int) syscall(SYS_gettid);
  cth->ptid = pthread_self();

  SocketConn_closeAll(socket_connections, 0);

  /*
  int __count = 0;
  for(int i=0; i< 10; i++) {
    DIR* dir = opendir("/proc/self/fd");
    struct dirent *dp;
    int count =0;
    while((dp = readdir (dir))){
      printf("\033[0;36m[%s] %s\033[0m\n", __func__, dp->d_name);
      if(strcmp(dp->d_name, ".") == 0
        ||strcmp(dp->d_name, "..") == 0
        ||strcmp(dp->d_name, "0") == 0
        ||strcmp(dp->d_name, "1") == 0
        ||strcmp(dp->d_name, "2") == 0)
	      continue;

      char path[512];
      sprintf(path, "/proc/self/fd/%s", dp->d_name);
      char buf[PATH_MAX];
      int n = readlink(path, buf, sizeof(buf));
      buf[n] = 0;
      printf("%s: \"%s\"\n", dp->d_name, buf);

      count ++;
      int fd = atoi(dp->d_name);
      errno = 0;
      int rc = close(fd);
      printf("rc: %d, err: %s\n", rc, strerror(errno));
    }

    closedir(dir);
    sleep(1);
    if(count==0) break;
  }
  */

  {
	  int rc = setpgrp(); 
  }

  char CMD_PATH[PATH_MAX];
  sprintf(CMD_PATH, "/usr/bin/ssh");

  char *hostname = strstr(addr, "//")+2;
  char *str = strstr(hostname, ":");
  *str = 0; str++;

  size_t len = 0;
  const char *format = "'cd supr/src; gnome-terminal --hide-menubar --title"
	 " \"Worker@%s\" --window"
	 " -- sh -c \"worker -port %s -master %s %s\"; exec bash'";
  len += strlen(format);
  len += strlen(addr) + strlen(master) + (_window ? strlen(_window) : 0)+3;

  char ssh_arg[len];

 
  //if(_window && strcmp(_window, "--window")==0)
  if(FALSE && Taskrunner_useWindow)
  {
    sprintf(ssh_arg, format, hostname, str, master, 
		    "-taskrunner.stdout --window"); 
  } else {
    sprintf(ssh_arg, "'cd supr/src; worker -port %s -master %s %s'", str, master,
		    _window ? _window : ""); 
  }
  
  //sprintf(ssh_arg, "'cd supr/src; worker -port %s -master %s %s'", str, master, _window ? _window : ""); 

  /*
  if(_window){
    // ssh -Y host 'gnome-terminal --window -- /bin/bash -c "cd supr/src; T"'
    char ssh_arg[1024];
    sprintf(ssh_arg, "'gnome-terminal --window --title Worker@%s -- /bin/sh -c \"sleep 60; cd supr/src;"
		   " worker -port %s -master %s; exec bash\"'", hostname, str,
		   master);

    printf("\033[0;32mhostname: %s\033[0m\n", hostname);
    printf("\033[0;32mssh_arg: %s\033[0m\n", ssh_arg);

//    int rc = execl("/usr/bin/ssh",  "ssh", hostname, ssh_arg, (char*) NULL);
    char cmd[strlen("ssh -Y ")+strlen(hostname) + 1 + strlen(ssh_arg)+1];
    sprintf(cmd, "ssh -Y %s %s", hostname, ssh_arg);
    printf("\033[0;32mcmd: %s\033[0m\n", cmd);
    int rc = execl("/bin/sh", "-c",  cmd, (char*)0);
   
    //char cmd[1024];
    //sprintf(cmd, "ssh %s %s", hostname, ssh_arg);
    //printf("\033[0;32mcmd: %s\033[0m\n", cmd);
    //int rc = system(cmd);
  

    printf("[%s] run worker: rc =  %d, %s\n", __func__, rc, strerror(errno));
    exit(0);

  }
  */

    printf("\033[0;32mhostname: %s\033[0m\n", hostname);
    printf("\033[0;32mssh_arg: %s\033[0m\n", ssh_arg);

//#define USE_XTERM 1
#define USE_XTERM 0
  //char *dir_name = "00"; //to do
  //if(USE_XTERM && rc)
  //if(_window && strcmp(_window, "--window")==0)
 //if(FALSE && Taskrunner_useWindow) 
 if(FALSE && Taskrunner_useWindow)
 {

    char *X11 = "-Y";
    char cmd[strlen("ssh %s %s %s &")+strlen(X11)+strlen(hostname)+strlen(ssh_arg)+3];
    //sprintf(cmd, "ssh %s %s %s&", X11, hostname, ssh_arg);
    //sprintf(cmd, "ssh %s %s %s &", X11, hostname, ssh_arg);
    sprintf(cmd, "ssh %s %s %s", X11, hostname, ssh_arg);
    printf("\n\033[0;32mcmd: %s\033[0m\n\n", cmd);
    int rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
    exit(0);
 } else if(Worker_useWindow) {

    char *X11 = "-Y";
    char *argv[] = {
          CMD_PATH, X11, hostname, ssh_arg,
	  (char*) NULL
      };

    char window_name[256];
    sprintf(window_name, "Worker@%s", hostname);
    //supr_xterm_t *xterm = supr_xterm3(window_name, argv, TRUE);
    supr_xterm_t *xterm = supr_xterm3(window_name, argv, FALSE);
    //supr_xterm_t *xterm = supr_xterm3(window_name, argv, Taskrunner_useWindow);

    if(xterm) {
      printf("[%s] run worker: xterm =  %p\n", __func__, xterm);
    } else {
      printf("[%s] run worker: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
    }

    exit(0);

  } else {
    char *X11 = "-Y"; // ""; // "-Y";
    printf("\033[0;34mhostname: %s\033[0m\n", hostname);
    printf("\033[0;34mssh_arg: %s\033[0m\n", ssh_arg);
    printf("\033[0;34mX11: %s\033[0m\n", X11);
#define USE_EXECL
#ifdef  USE_EXECL

    char cmd[strlen("ssh %s %s %s &")+strlen(X11)+strlen(hostname)+strlen(ssh_arg)+3];
    //sprintf(cmd, "ssh %s %s %s&", X11, hostname, ssh_arg);
    sprintf(cmd, "ssh %s %s %s &", X11, hostname, ssh_arg);
    printf("\n\033[0;32mcmd: %s\033[0m\n\n", cmd);

    {
	    /*
	    for(int i=0; i<5; i++) {
                    printf("\033[0;32m..\033[0m\n");
		    sleep(1);
	    }
	    */
		    //sleep(1);
    printf("\n\033[0;32mcmd: %s\033[0m\n\n", cmd);
      char *display_env = getenv("DISPLAY");
      int rc = X11_check();
      printf("display_env: %s, X11_check(): %d\n", display_env, rc);

      errno = 0;
      rc = isatty(STDOUT_FILENO);
      if(errno) {
          printf("[%s] Error: %s STDOUT_FILENO: %d (%s:%d)\n", __func__,
                          strerror(errno), STDOUT_FILENO,
                          __FILE__, __LINE__);
          rc = 0;
      }
      if(rc){
        char buf[PATH_MAX];
        int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
        if(rc) {
          printf("[%s] Error: %s (%s:%d)\n", __func__, strerror(errno),
                          __FILE__, __LINE__);
        } else {
          printf("ttyname: %s\n", buf);
	}
      }
    }

    int rc = execl("/bin/sh", "sh", "-c", cmd, (char *) 0);
    /*
    int rc = execl(CMD_PATH, "ssh", X11,
                  hostname, ssh_arg,
                  (char*) NULL);
		  */
#else
    char cmd[1024];
    sprintf(cmd, "ssh %s %s", hostname, ssh_arg);
    printf("\033[0;32mcmd: %s\033[0m\n", cmd);
    int rc = system(cmd);
#endif

    printf("[%s] run worker: rc =  %d, %s\n", __func__, rc, strerror(errno));
    sleep(120);
    exit(0);
  }

}

#endif // define MASTER_START_WORKER_FUNC

void Master_startWorkers(int argc, char **argv, int use_window)
{
  char master[256];
  sprintf(master, "//%s:%d", masterServerConn->host,
		  masterServerConn->port);

  char cn_file[PATH_MAX];
  //sprintf(cn_file, "%s/conf/nodes", SUPR_HOMEUSR);
  //sprintf(cn_file, "%s/supr.conf", SUPR_HOMEUSR);
  sprintf(cn_file, "%s/%s", SUPR_HOMEUSR, SYS_SUPR_CONF_FILENAME);

  int rc = access(cn_file, R_OK);
  int fd = open(cn_file, O_RDWR, 0600);
  struct stat sb;
  if(rc == 0 && (fd = open(cn_file, O_RDWR, 0600))!=-1
                 && (rc = fstat(fd, &sb))==0) {

        char buf[sb.st_size+1];
        read(fd, buf, sb.st_size);
        close(fd);

        char *name = "Worker";

        buf[sb.st_size] = 0;
        //fprintf(stdout, "conf/node, %s\n", buf);
        char *line = strtok(buf, "\n");
        char *namenode_line = NULL;
	int nWorkers = 0;
        while(line){
          for(; line; line++)
                  if(!isspace(*line)) break;
          if(!line) continue;

          if(strncmp(line, name, strlen(name))==0)
          { //namenode_line = line;
	    nWorkers++;
            printf("\033[0;34m\n\n\n%d. %s: %s\033[0m\n",
			   nWorkers, name, line);
            //Master_startWorker(line, master, argc, argv);
            Supr_startWorker(line, master, argc, argv, use_window);
	    //sleep(10); //break;
          }
          line = strtok(NULL, "\n");
        }
  } else {
        fprintf(stdout, "Error: %s, %s\n", cn_file, strerror(errno));
  }
}

void Master_handleStartWorkers()
{
  Master_startWorkers(cmd_argc, cmd_argv, Worker_useWindow);
}

extern int setDir(const char *dir_path, const char *subdir);

//master [--help] [--version] [--window]
//  [-o file_name] [-port port_number] [-shm shm_name] [-reuse.addr TRUE|FALSE] 

char *__doc__ = "[--help] [--version] [--window] [-o file_name] "
	"[-port port_number] [-shm shm_name] [-reuse.addr TRUE|FALSE]"; 

char *__version__ = "2.0.0";


/*
int child_run()
{
  close(pipe_fd[1]);
//  sleep(10);
  for(;;){
    ssize_t len;
    size_t n = read(pipe_fd[0], &len, SIZE_SIZE);
    if(n != SIZE_SIZE)
	    exit(1);

    if(len==-1) break;

    char cmd[len+1];
    n = read(pipe_fd[0], cmd, len);
    if(n != len)
	    exit(1);
    cmd[len] = 0;
    fprintf(stderr, "\n\033[0;31m[%d] cmd: %s\033[0m\n\n", getpid(), cmd);
    if(fork() == 0)  {
        system(cmd);
	exit(0);
    }

  }
  exit(0);
}
*/

int HtmlDir_check()
{ // html
    //mkDir(SUPR_HOMEUSR, "html/worker");
  if(html_dir == NULL){
      html_dir = (char*) malloc(strlen(SUPR_HOMEUSR)+strlen("/html")+1);
      sprintf(html_dir, "%s/html", SUPR_HOMEUSR);
      DIR *dir = opendir(html_dir);
      if(!dir) {
        printf("Info: making dir %s\n", html_dir);
	if(mkdir(html_dir, 0700) == -1){
          printf("Error: %s, %s\n", html_dir, strerror(errno));
	  return -1;
	}
      } else {
        closedir(dir);
      }
  } else {
      html_dir = strdup(html_dir);
      DIR *dir = opendir(html_dir);
      if(!dir) {
        printf("Error: %s, %s\n", html_dir, strerror(errno));
	return -1;
      } else {
        closedir(dir);
      }
  }

  // remove "worker.*.txt" and "driver.*.txt" files
  DIR *dir = opendir(html_dir);
  struct dirent *dp;
  while((dp = readdir(dir))){
	  if( strlen(dp->d_name) < strlen(".txt") ) continue;
	 //fprintf(stderr, "file: %s\n", dp->d_name);
	 //fprintf(stderr, "    : %s\n", dp->d_name + strlen(dp->d_name)-strlen(".txt"));
      if((  strncmp(dp->d_name, "driver.", strlen("driver."))==0
         ||strncmp(dp->d_name, "worker.", strlen("worker."))==0
         ||strncmp(dp->d_name, "taskrunner.", strlen("taskrunner."))==0
         ||strncmp(dp->d_name, "master.", strlen("master."))==0
	 ) && strncmp(dp->d_name + strlen(dp->d_name)-strlen(".txt"),
		 ".txt", strlen(".txt"))==0) {
         char path[PATH_MAX];
	 sprintf(path, "%s/%s", html_dir, dp->d_name);
	 fprintf(stderr, "rm: %s\n", path);
         unlink(path);
      }
  }

  char path[PATH_MAX];
  sprintf(path, "%s/index.html", html_dir);
  //int rc = access(path, R_OK);
  FILE *fs = fopen(path, "w+");
  if(!fs) {
    printf("Error: %s, %s\n", path, strerror(errno));
    return -1;
  }

  /*
  int fd = fileno(fs);
  write(fd, index_html_header, strlen(index_html_header));
  */
  fprintf(fs, "%s", index_html_header);
  fprintf(fs, "<BODY>\n"); 
  fprintf(fs, "master-host: %s\n", Supr_hostname);
  fprintf(fs, "verbose: %s\n", Supr_verbose ? "TRUE" : "FALSE"); 
  fprintf(fs, "</BODY>\n"); 
  fclose(fs);
  return 0;
}

extern char *gdb_trace(int id, int full);

void  Master_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);
  fprintf(stderr, "\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));
  fprintf(stderr, "\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
                  pthread_self(), getpid(), syscall(SYS_gettid));

  {
    const char *s = gdb_trace(0, FALSE);
    fprintf(stderr, "gdb_trace:\n%s\n", s);
  }

  c_backtrace();

  fflush(stdout);

  //sleep(2);
  //exit(1);
  sleep(120);
}


extern void runAsDaemon(char *cmd_name);


// ssh tunnel example: ssh -L 7100:outlier.stat.purdue.edu:300 outlier.stat.purdue.edu
#define SYS_COMMAND_THREAD "threadserver"

char *Thread_dir()
{
  if(!Supr_usrHome)
    Supr_usrHome = getenv("SUPR_USR_HOME"); // FIXME

  char path[PATH_MAX];
  struct stat sb;
  if(!Supr_usrHome) {
     char *home = getenv("HOME"); // FIXME
     if(!home){
           fprintf(stderr, "No home directory is avialable");
           return NULL;
     }
     sprintf(path, "%s/.supr", home);
     if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
       Supr_usrHome = strdup(path);
     else if(mkdir(path, 0700) != -1)
       Supr_usrHome = strdup(path);
  }

  if(!Supr_usrHome) {
           fprintf(stderr, "No usr.home is avialable");
           return NULL;
  }

  sprintf(path, "%s/%s", Supr_usrHome, SYS_COMMAND_THREAD);

  if(stat(path, &sb) == -1) {
    if(mkdir(path, 0700) == -1){
      perror(path);
      return NULL;
    }
  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    return NULL;
  }

  sprintf(path + strlen(path), "/%s", Supr_hostname);

  if(stat(path, &sb) == -1) {
    if(mkdir(path, 0700) == -1){
      perror(path);
      return NULL;
    }
  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    return NULL;
  }


  return strdup(path);
}

/*
static const char *__doc__ ="  master [-port] [--help] ... TODO..."
	"..."
	"... TODO\n";
*/

// a simple thread server

extern int __rm_recursive__(const char *pathname); 

static char *threadserver_dir = NULL;
static pid_t threadserver_pid = 0;

static void useExistingServer(char *threadserver_dir, int port,
	       	int SocketConn_reuseAddr, const char *notify_addr)
{
  DIR *dir = opendir(threadserver_dir);
  if(!dir) return;

  struct dirent *dp;
  while((dp = readdir(dir))){
    if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0)
              continue;

    if(dp->d_type == DT_DIR){
      char path[PATH_MAX];
      int rc = kill(atoi(dp->d_name), 0);
      if(rc == -1) continue;

      sprintf(path, "%s/%s/threadserver.log", threadserver_dir, dp->d_name);
      FILE *f = fopen(path, "r");
      if(f){
        char buf[1024];
        char *addr = fgets(buf, sizeof(buf), f);
	fclose(f);

	if(addr){
	  if(strstr(addr, "//")) addr = strstr(addr, "//") + 2;
	  char *s = strstr(addr, "\n"); if(s) *s = 0;
	  int log_port = atoi(strstr(addr,":")+1);
	  if(log_port == port || (log_port>=port && !SocketConn_reuseAddr)){

            supr_socket_conn_t *sc = socketOpen1(addr);
	    if(sc){
	      if(notify_addr) {
		sprintf(addr+strlen(addr), ":%s", dp->d_name); 
                Supr_notify(notify_addr, addr, THREADSERVER_STARTED); 
	      }
	      close(sc->fd);
	      free(sc); // FIXME
	      exit(EXIT_SUCCESS);
	    }
	  }
	}
      }
    }
  }
}

static void rmConnLog()
{
  if(!threadserver_dir) return;

  fclose(stdout);
  fclose(stderr);

  //Cluster_sendSimpleMessage("pthreads:", msg_color, BASIC_INFO_TYPE, 0);
  for(int i=vectorSize(threads)-1; i>=0; i--){
    supr_thread_t *th = vectorElementAt(threads, i);
    if(!pthread_equal(th->ptid, pthread_self()))
	    pthread_cancel(th->ptid);
  }

  /*
  Cluster_sendSimpleMessage(__func__, msg_color, BASIC_INFO_TYPE, 0);
  sprintf(msg, "pid: %d, ppid: %d, threadserver_pid: %d", getpid(), getppid(),
		  threadserver_pid);
  Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
  Cluster_sendSimpleMessage(threadserver_dir, msg_color, BASIC_INFO_TYPE, 0);
  */

  int rm_ok = TRUE;
  if(threadserver_pid == getpid()) {
    if(strstr(threadserver_dir, "/.supr/threadserver/")){
       int rc = __rm_recursive__(threadserver_dir);
       if(rc == -1) {
         //Cluster_sendSimpleMessage(strerror(errno),msg_color,ERROR_INFO_TYPE,0);
         //Rf_endEmbeddedR(0);
         if(access(threadserver_dir, F_OK)==0)
	 {
	   rc = rmdir(threadserver_dir);
	   if(rc == -1){
	     rm_ok = FALSE;
	     if(errno == EBUSY){
	        sprintf(msg, "rmdir(%s), %s",threadserver_dir, strerror(errno));
                Cluster_sendSimpleMessage(msg,msg_color,ERROR_INFO_TYPE,0);
	      } else 
	        sprintf(msg, "rmdir(%s), %s",threadserver_dir, strerror(errno));
                Cluster_sendSimpleMessage(msg,msg_color,ERROR_INFO_TYPE,0);
	   }
	 }
       }
    }

    char *s = threadserver_dir + strlen(threadserver_dir);
    while(s && *s != '/') s--;
    *s = 0;
    //Cluster_sendSimpleMessage(threadserver_dir, msg_color, BASIC_INFO_TYPE,0);
    chdir(threadserver_dir);

    DIR *dir = opendir(threadserver_dir);
    if(!dir) return;

    struct dirent *dp;
    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0)
              continue;

      if(dp->d_type == DT_DIR){

        pid_t pid = atoi(dp->d_name);
	if(pid == getpid()) continue;
	int rc = kill(pid, 0);
	if(rc==-1) {
	  if(errno == ESRCH){
            char buf[strlen(threadserver_dir)+strlen(dp->d_name)+2];
            sprintf(buf, "%s/%s", threadserver_dir, dp->d_name);
            if(strstr(buf, "/.supr/threadserver/")){
              int rc = __rm_recursive__(buf);
	      if(rc == -1){
	        sprintf(msg, "rm %s, %s", buf, strerror(errno));
                Cluster_sendSimpleMessage(msg, msg_color, ERROR_INFO_TYPE, 0);
	      }
	      if(access(buf, F_OK)==0) rmdir(buf);
	    }
	  }
	} else {
	  sprintf(msg, "threadserver %d exists", pid);
          Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
	  char path[PATH_MAX];
	  sprintf(path, "%s/%s/threadserver.log", threadserver_dir, dp->d_name);
	  FILE *f = fopen(path, "r");
	  if(f){
	    char *line = fgets(msg, sizeof(msg), f);
	    if(line){
              supr_socket_conn_t *sc = socketOpen1(line);
	      if(!sc) {
		int rc = kill(pid, SIGKILL);
		sprintf(msg, "kill(%d): %d", pid, rc);
                Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
	      }
	      else {
		sprintf(msg, "connected to %s:%d:%d",  sc->host, sc->port, pid);
                Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
		close(sc->fd);
	      }
	    }
	    fclose(f);
	  } else {
		int rc = kill(pid, SIGKILL);
		sprintf(msg, "kill(%d): %d", pid, rc);
                Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
	  }
	}
	
      }
    }
    closedir(dir);

    //if(!rm_ok)
    

  }
//  sprintf(path + strlen(path), "/%s.log", cmd);
//  unlink(path);

}

char *cmd_is_running(const char *dir, const char *cmd, char **file_name_addr){
  char path[PATH_MAX];
  if(dir) strcpy(path, dir);
  else getcwd(path, PATH_MAX);
  char *log = NULL;
  while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
  sprintf(path+strlen(path), "/%s.log", cmd);
  *file_name_addr = strdup(path);
  if(access(path, F_OK)==0){
    struct stat statbuf;
    int fd = open(path, O_RDONLY);
    int rc = fstat(fd, &statbuf);
    if(rc==0 && fd !=-1){
      log = malloc(statbuf.st_size+1);
      read(fd, log, statbuf.st_size);
      log[statbuf.st_size] = 0;
    }
    close(fd);
  }

  return log;
}


static char *getDefaultAddr(const char *which){
  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  struct stat sb;
  int fd = open(path, O_RDONLY);
  if(fd != -1 && fstat(fd, &sb) != -1) {

    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    buf[sb.st_size] = 0;
    close(fd);

    char *s = strstr(buf, which);
    if(s) s = strstr(s, "{");
    if(s) {
      char *t = strstr(s, "}");
      if(t) *t=0;
      if(strstr(s, Supr_hostname)){
         char *t = strstr(s, "\n");
         if(t) {*t=0; t++;}
	 return strdup(s);
      }
    }
  }

  char buf[strlen(Supr_hostname)+32];
  sprintf(buf, "%s:1024+", Supr_hostname);
  return strdup(buf);
}


void C_ThreadServer_start(void *data){

     if(!SuprContextEnv){
       SEXP call = PROTECT(LCONS(install("library"),
                           CONS(mkString(PACKAGE_NAME), R_NilValue)));
       eval(call, R_GlobalEnv);
       UNPROTECT(1);
     }

     // start a thread server
     int port = *((int*)data);
     SEXP S_port = PROTECT(ScalarInteger(port));
     SEXP call = PROTECT(LCONS(install("ThreadServer.start"),
			       CONS(S_port, R_NilValue)));
     SEXP server = eval(call, R_GlobalEnv);
     //threadServer = server;
       
     //defineVar(install("threadServer"), server, SuprContextEnv);
     SEXP ths   = PROTECT(allocVector(VECSXP, 1));
     SET_VECTOR_ELT(ths, 0, server);
     SEXP addr = getAttrib(server, install("address"));
     if(TYPEOF(addr) == STRSXP && LENGTH(addr)>0){
       setAttrib(ths, R_NamesSymbol, addr);
       const char *c = CHAR(STRING_ELT(addr,0));
       if(strstr(c, ":")) *((int*)data) =  atoi(strstr(c, ":")+1);
     } else {
       setAttrib(ths, R_NamesSymbol, mkChar(Supr_hostname)); // FIXME
     }
     defineVar(install("ths"), ths, SuprContextEnv);

     //PrintValue(server);

     UNPROTECT(3);
}


extern void runAsDaemon2(char *dir, char *sub_dir);

pid_t main_pid = -1;

void send_ExitInfo(){
  if(getpid() != main_pid) return;

  /*
  info_sc = NULL;
  if(info_addr) info_sc = socketOpen1(info_addr);
	           error_info("%s, %s", __func__, strerror(errno));
		         Supr_decref(info_sc);
			 */
  supr_thread_t *cth = SUPR_CURRENT_THREAD();

  basic_info("\033[0;35m%s ... terminated\033[0m", __func__);
  // TODO ...
}


int main(int argc, char **argv)
{
    //  Supr_verbose = TRUE; Supr_debug = TRUE; Supr_infov = TRUE;
  Cluster_handleCommand = __handleCommand;
  System_shutdown = ThreadServer_shutdown;

  Supr_do_xterm_ptr = Supr_do_xterm;

  int port = -1;
  SocketConn_reuseAddr = TRUE;
  cmd = "threadserver";

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--verbose")==0){
      Supr_options.verbose = Supr_verbose = TRUE;
    } else if(strcmp(argv[i], "--debug")==0){
      Supr_options.debug = Supr_debug = TRUE;
    } else if(strcmp(argv[i], "--info")==0){
      Supr_options.info = Supr_infov = TRUE;
    } else if(strcmp(argv[i], "-port")==0 && i < argc-1){
      port = atoi(argv[++i]);
      if(port < 1024) port = 1024;
      if(strstr(argv[i], "+")) SocketConn_reuseAddr = FALSE;
    } else if(strcmp(argv[i], "-notify")==0 && i+1 < argc){
            notify_addr = argv[++i];
    } else if(strcmp(argv[i], "-X11")==0 && i+1 < argc){
            X11_str = argv[++i];
    }
  }

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-info")==0 && i+1 < argc){
      info_addr = argv[++i];
      if(strstr(info_addr, ":")){
        char *hostname = strdup(info_addr);
        char *s = strstr(hostname, ":");
        if(s) *s = 0; s++;
        int port = atoi(s);
        info_sc = socketOpen2(hostname, port);

	if(info_sc) {
          info_sc->port = port;
          int cmd = CLUSTER_PROC_CMD;
          write(info_sc->fd, &cmd, sizeof(int));
          char *proc_cmd = argv[0];
          while(strstr(proc_cmd, "/"))
            proc_cmd = strstr(proc_cmd, "/")+1;
          int len = strlen(proc_cmd)+1;
          write(info_sc->fd, &len, sizeof(int));
          write(info_sc->fd, proc_cmd, len);
          int rc;
          read(info_sc->fd, &rc, sizeof(int));
        }

        verbose_info("\033[0;37m%s\033[0m", argv[0]);
        free(hostname);
      } else {
        info_addr = NULL;
      }
      break;
    }
  }

  argv_info(argc, argv);

  /*
  if(Supr_debug){
    for(int i=0; i<argc; i++) 
    Cluster_sendSimpleMessage(argv[i], "\033[0;37m", BASIC_INFO_TYPE, 0);
  }
  */


  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--help")==0){
      fprintf(stderr, "%s\n", __doc__);
      exit(EXIT_SUCCESS);
    }
  }

  if(port <= 0){
    char *addr = getDefaultAddr("ThreadServers");

    port = atoi(strstr(addr, ":")+1);
    if(strstr(strstr(addr, ":")+1, "+"))
            SocketConn_reuseAddr = FALSE;
    else
            SocketConn_reuseAddr = TRUE;
    fprintf(stderr, "[%s] default port: %d\n", __func__, port);

    sprintf(msg, "use default addr: %s", addr);
    Cluster_sendSimpleMessage(msg, msg_color, BASIC_INFO_TYPE, 0);
    free(addr);
  }



#ifdef RUN_AS_DAEMON_PROC
  char *dir = Thread_dir();
  if(!dir) 
    exit(EXIT_FAILURE);

  // use an existing server, if any
  useExistingServer(dir, port, SocketConn_reuseAddr, notify_addr);


  runAsDaemon2(dir, "");

  main_pid = getpid();

  threadserver_pid = getpid();
  {
    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    threadserver_dir = strdup(CWD_PATH);
//    Cluster_sendSimpleMessage("threadserver_dir", "\033[0;37m", BASIC_INFO_TYPE, 0);
//    Cluster_sendSimpleMessage(threadserver_dir, "\033[0;37m", BASIC_INFO_TYPE, 0);
  }
  chdir(dir);

  atexit(rmConnLog);
  atexit(send_ExitInfo);

#define __USE_SIGINT__
#ifdef __USE_SIGINT__
  //struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = SystemExit_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    //sigaction(SIGINT, &sa, &save_sigaction);
    sigaction(SIGINT, &sa, NULL);
  }
#endif

  //
  /*
  if(FALSE && info_addr){
    free(info_sc);
    info_sc = 0;
    char *hostname = strdup(info_addr);
    char *s = strstr(hostname, ":");
    if(s) *s = 0; s++;
    int port = atoi(s);
    info_sc = socketOpen2(hostname, port);
    Cluster_sendSimpleMessage("Reconnected", "\033[0;37m", VERBOSE_INFO_TYPE, 0);
    Cluster_sendSimpleMessage(argv[0], "\033[0;37m", VERBOSE_INFO_TYPE, 0);

    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "master CWD: %s", CWD_PATH);
    Cluster_sendSimpleMessage(msg, "\033[0;37m", VERBOSE_INFO_TYPE, 0);

    free(hostname);
  } else
  {
    char CWD_PATH[PATH_MAX];
    getcwd(CWD_PATH, PATH_MAX);
    sprintf(msg, "CWD: %s", CWD_PATH);
    Cluster_sendSimpleMessage(msg, "\033[0;37m", BASIC_INFO_TYPE, 0);
  }
  */


  char buf[256];
  msg[sizeof(msg)-1] = 0;
  /*
  snprintf(msg, sizeof(msg)-1, "host: %s, ppid: %d, pid: %d, time: %s\n",
		  Supr_hostname, getppid(), getpid(),
		  Exec_timestamp(buf, sizeof(buf)));
  Cluster_sendSimpleMessage(msg, "\033[0;37m", VERBOSE_INFO_TYPE, 0);
  */

#endif

#define SUPR_DEBUG
#ifndef SUPR_DEBUG
  int devNull = open("/dev/null", O_WRONLY);
  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);
  dup2(devNull, STDERR_FILENO);
  dup2(devNull, STDOUT_FILENO);
#endif

//  Supr_verbose = TRUE;

  //fprintf(stderr, "pid: %d\n", getpid());

  cmd_argc = argc;
  cmd_argv = argv;

  /*pipe(pipe_fd);

  int pid = fork();
  if(pid == 00) 
	  child_run();

  close(pipe_fd[0]);
  */

  /*
  for(int i=0; i<100; i++){
    write(pipe_fd[1], &i, INT_SIZE);
    sleep(1);
  }
  {
    int i=-1;
    write(pipe_fd[1], &i, INT_SIZE);
  }
  */
  

  //cleanups = newVector(FALSE);

  // handle --help and --version
  /*
  for(int i=0; i<argc; i++) {
    if(strcmp(argv[i], "--help")==0) {
      fprintf(stdout, "%s %s\n", SYS_COMMAND_MASTER,  __doc__);
      return EXIT_SUCCESS;
    } else if(strcmp(argv[i], "--version")==0) {
      fprintf(stdout, "%s\n", __version__);
      return EXIT_SUCCESS;
    }
  }

  // handle --window
  for(int i=0; i<argc; i++) {
    if(strcmp(argv[i], "--window")==0) {
      suprHomeInit();

      char CMD_PATH[PATH_MAX];
      sprintf(CMD_PATH, "%s/%s", SUPR_HOMESYS, SYS_COMMAND_MASTER);

      int w_argc = argc+1;
      char **w_argv = (char**) malloc(w_argc * sizeof(char*));
      for(int i=0; i<w_argc; i++) w_argv[i] = NULL;

      int k=0;
      w_argv[k++] = CMD_PATH;
      for(int i=0; i<argc; i++){
        if(strcmp(argv[i], "--window")==0 )
                continue;
        else if(strstr(argv[i], "-master") && strstr(argv[i], "stdout")
                        && i < argc-1)
        {
          w_argv[k++] = argv[i];
          w_argv[k++] = argv[++i];
        } else
          w_argv[k++] = argv[i];
      }


      char window_name[256];
      char hostname[256];
      gethostname(hostname, 256);
      sprintf(window_name, "(Self-started) Master@%s", hostname);
      supr_xterm_t *xterm = supr_xterm3(window_name, w_argv, TRUE);
      printf("\033[0m\n");
      printf("window_name: %s, xterm: %p\n", window_name, xterm);
      exit(0);
    }
  }
  */



  //printf("\n\n\n\033[0;31m =============== Master ==========\n\n");
  //for(int i=0; i<argc; i++) { printf("argv[%d] %s\n", i, argv[i]); }
  //printf("\n\n\n\033[0;31m --------------- Master ----------\n\n");

  int rc = setpgrp(); // set process group to itself
  if(rc == -1)
  {
      printf("Error: %s\n", strerror(errno));
  }


  char *shm_name = NULL;


  char *_stdout = NULL;

  for(int i=0; i<argc; i++){
     if(strcmp(argv[i], "-port")==0 && i < argc-1)
       port = atoi(argv[++i]);
     else if(strcmp(argv[i], "-master.port")==0 && i < argc-1)
       port = atoi(argv[++i]);
     else if(strcmp(argv[i], "-shm")==0 && i < argc-1)
       shm_name = argv[++i];
     else if(strcmp(argv[i], "-verbose")==0 && i < argc-1)
       Supr_verbose = *argv[++i] == 'T';
     else if(strcmp(argv[i], "-html")==0 && i < argc-1)
       html_dir = argv[++i];
     else if(strcmp(argv[i],"-master.stdout") ==0 && i<argc-1)
       _stdout = argv[++i];
     else if(strcmp(argv[i], "-reuse.addr")==0 && i < argc-1)
     {
       if(strcmp(argv[++i], "TRUE")==0) SocketConn_reuseAddr = TRUE;
     }
     else if(( strcmp(argv[i], "-stdout")==0
	      || strcmp(argv[i], "-worker.stdout")==0
	     ) && i < argc-1 && strcmp(argv[i+1], "--window")==0)
       Worker_useWindow = TRUE;
  }

  suprHomeInit();

  /*
  printf("\033[0;32m\n");
  printf("[%s] SUPR_HOMEUSR = %s\n", argv[0], SUPR_HOMEUSR);
  printf("[%s] SUPR_HOMESYS = %s\n", argv[0], SUPR_HOMESYS);
  printf("[%s] port = %d\n", argv[0], port);
  printf("[%s] shm_name = %s\n", argv[0], shm_name);
  printf("\033[0m\n");
  */

  //setDir(SUPR_HOMEUSR, SYS_COMMAND_MASTER);

  if(HtmlDir_check() == -1)
    exit(EXIT_FAILURE);

  /*
  if(port == -1) {
    char *port_str = getenv("SUPR_MASTER_PORT");
    port = port_str ?  atoi(port_str) : Config_getPort("Master");
  }
  */

  sprintf(msg, "[%s] port: %d", argv[0], port);
  Cluster_sendSimpleMessage(msg, "\033[0;37m", VERBOSE_INFO_TYPE, 0);


  /*
  int pong = tryPingSocketServer2(Supr_hostname, port);
  sprintf(msg, "tryPingSocketServer2(%s, %d): %d (PONG: %d)",
                      Supr_hostname, port, pong, CLUSTER_PONG);
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  //if(pong != CLUSTER_PONG){
    switch(pong){
      case -1: // OK socketOpen2 return NULL
           break;
      case -2: // cannot write
      case -3: // cannot read
      default:
           {
             sprintf(msg, "thread with the same port %d is running on %s"
                             "\n\tkill ...",
                      port, Supr_hostname);
             Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
             vector_t *killed_cmds = newVector(FALSE);
             Supr_killSocketServer("thread", port, killed_cmds);
             for(int i=vectorSize(killed_cmds)-1; i>=0; i--) {
               char *s = (char*) vectorRemove(killed_cmds, i);
               Cluster_sendSimpleMessage(s, "\033[0;31m", VERBOSE_INFO_TYPE, 0);
               free(s);
             }
             vectorDestroy(killed_cmds);
           }
           break;
    }
    */
  /*
  } else {
    sprintf(msg, "\033[0;31mError: master with the same port %d is running on %s.\033[0m",
                      port, Supr_hostname);
    Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
    if(notify_addr){
      supr_socket_conn_t *sc = socketOpen1(notify_addr);
      if(sc){
	    int cmd = CLUSTER_CONNECT_DFSNAME;
	    write(sc->fd, &cmd, sizeof(int));
	    char buf[strlen(Supr_hostname)+32];
            sprintf(buf, "%s:%d", Supr_hostname, port);
            int len = strlen(buf)+1;
            write(sc->fd, &len, sizeof(int));
            write(sc->fd, buf, len);
            int rc;
            read(sc->fd, &rc, sizeof(int));
            sprintf(msg, "Sent master_addr %s to %s", buf, notify_addr);
            Cluster_sendSimpleMessage(msg, "\033[0;34m", VERBOSE_INFO_TYPE, 0);
            close(sc->fd);
            free(sc);
      } else {
        sprintf(msg, "\033[0;31mError: cannot connect to %s\033[0m",
                      notify_addr);
        Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
      }
    }
    exit(EXIT_FAILURE);
  }
  */





  // open shm_io
  shm_io_info_t *io = NULL;
  if(shm_name){
    io = shm_io_open(shm_name);
    {
      printf("[%s] (shm_io) io->out->pid: %d\n", __func__, io->out->pid);
      //if(io->out->pid)
    }
    sem_post(&io->out->sem_wait);

    /*
    shm_io_write(io, io->out, shm_name, strlen(shm_name)+1);
    pid_t pid = getpid();
    shm_io_write(io, io->out, &pid, sizeof(pid_t));
    */

    shm_io_write(io, io->out, shm_name, strlen(shm_name)+1);
    pid_t pid = getpid();
    shm_io_write(io, io->out, &pid, INT_SIZE);

  }

  //Exec_setStdout(SYS_COMMAND_MASTER, _stdout);

  threads = newVector(TRUE);

  // initialized R_eval


  verbose_info("initialize R ...");
  __R_init(argc, argv);


#ifndef SUPR_DEBUG
  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
#endif


  Cluster_sendSimpleMessage("set signal handlers", msg_color, VERBOSE_INFO_TYPE, 0);
  SUPR_setSignalHandler(Master_SigactionSIGINT, Master_SigactionSIGUSR1,
                 Master_SigactionSIGUSR2);

  //SEXP threadServer = R_NilValue; 
  {

     Rboolean success;
     BEGIN_R_EVAL();
       success = R_ToplevelExec(C_ThreadServer_start, &port);
     END_R_EVAL();
     if(!success) {
       Cluster_sendSimpleMessage("Failed to start ThreadServer", msg_color, ERROR_INFO_TYPE, 0);
       exit(EXIT_FAILURE);
     }
  }

  if(notify_addr){
    char addr[strlen(Supr_hostname)+64];
    sprintf(addr, "%s:%d:%d", Supr_hostname, localThreadServerPort,
		    getpid()); // FIXME
    //sprintf(addr, "%s:%d", Supr_hostname, port);
    Supr_notify(notify_addr, addr, THREADSERVER_STARTED);
  }

  /*
  Supr_do_xterm_ptr(TRUE);
  sleep(10);
  Supr_do_xterm_ptr(TRUE);
  */
//  supr_thread_t *server = (supr_thread_t *)R_ExternalPtrAddr(threadServer);
  //supr_socket_conn_t *conn
#define SKIP_TO_REPL
#ifndef SKIP_TO_REPL
  Cluster_sendSimpleMessage("send server port ...", msg_color, VERBOSE_INFO_TYPE, 0);
  Cluster_sendSimpleMessage(Supr_hostname, msg_color, VERBOSE_INFO_TYPE, 0);
  int fd = info_sc->fd; // use notify_sc ...
  int cmd = THREADSERVER_STARTED;
  write(fd, &cmd, sizeof(int)); 
  char addr[strlen(Supr_hostname)+32];
  sprintf(addr, "%s:%d", Supr_hostname, localThreadServerPort); // FIXME
  int len = strlen(addr)+1;
  write(fd, &len, sizeof(int)); 
  write(fd, addr, len);
  
  read(fd, &rc, sizeof(int)); 


#define TJUMP_O_R_REPL
#ifndef TJUMP_O_R_REPL
  {
    //sigaction(SIGPIPE, &sa, &R_oldPipeAct);
    struct sigaction sa;
    sa.sa_sigaction = Master_SigactionSIGPIPE;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGPIPE, &sa, &R_oldPipeAct);
  }

  // start timeout monitor
  //supr_thread_t *timeout_monitor = startTimeoutMonitor();
  //vectorAdd(threads, timeout_monitor);
  
  // start backend
  supr_thread_t *backend = NULL;

  main_thread->name = strdup(__func__);
  // is main_thread defined??
  pthread_mutex_lock(&main_thread->mutex);

    Cluster_sendSimpleMessage("start backend thread...", msg_color, VERBOSE_INFO_TYPE, 0);
    backend = startBackend(port); // use the same port? if addr_reuse ?
    vectorAdd(threads, backend);

    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);

    supr_socket_conn_t *conn = (supr_socket_conn_t *)
      vectorElementAt(socket_connections, 0);

    // testing
    /*
    supr_socket_conn_t *sc;
    while(TRUE){
      sc = socketOpen2(conn->host, conn->port);
      if(sc) {
	int cmd = CLUSTER_PING;
	ssize_t size =  write(sc->fd, &cmd, INT_SIZE);
	if(size != INT_SIZE){
          printf("Error in write: %s\n", strerror(errno));
	}

	int i=0;
       	for(; i<60; i++){
          size = recv(sc->fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
	  if(size == INT_SIZE) {
	     break;
	  }
	  else {
            printf("Warning in recv, size: %ld (%s)\n", size, strerror(errno));
	    sleep(1);
	  }
	}
	if(i<60) {
		size = read(sc->fd, &cmd, INT_SIZE);
                printf("Main, size: %ld, cmd: %d\n", size, cmd);
	       	break;
	} else {
          printf("Error in recv: %s\n", strerror(errno));
	}
      }


      printf("Error: %s\n", strerror(errno));
      sleep(10);
    }
    close(sc->fd);
    Supr_decref(sc);

    printf("main:"); conn->print(conn);
    if(io) shm_io_write(io, io->out, &conn->port, INT_SIZE);
    */
  pthread_mutex_unlock(&main_thread->mutex);

//  Exec_setStdout(SYS_COMMAND_MASTER, _stdout);
#define SKIP_TO_REPL
#ifndef SKIP_TO_REPL
  // start User interface ?
  supr_thread_t *ui = startUI(io);
  vectorAdd(threads, ui);

  // startWorkers
#ifdef MASTER_START_WORKERS
  printf("\n\n\033[0;32mMaster_startWorkers\033[0m\n\n");
  Master_startWorkers(argc, argv, Worker_useWindow);
#endif
   
#endif // SKIP_TO_REPL
 

  // start R_eval service
#endif
#endif // SKIP_TO_REPL
  Cluster_sendSimpleMessage("start REPL by the main thread ...", msg_color, VERBOSE_INFO_TYPE, 0);

  R_REPL(main_thread, argc, argv);
  /*
  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
  pthread_mutex_unlock(&main_thread->mutex);
  */
  

  exit(1);
}

/*
int main(int argc, char **argv){ //	testing(argc, argv);

  fprintf(stderr, "\n==================");
  for(int i=0; i<argc; i++){
     printf("[%d] %s\n", i, argv[i]); 
     fprintf(stderr, " %s", argv[i]); 
  }
  fprintf(stderr, " ====================\n");

  myTryEval_SigactionInt = myR_SigactionTaskRunnerInt;
  //myTryEval_SigactionInt = myTryEval_SigactionTaskRunnerInt;

#define DATA_CHANGE_LISTENER   "-DCL"
  for(int i=0; i<argc; i++){
     if(strcmp(argv[i], DATA_CHANGE_LISTENER)==0)
       return data_change_listener(argc, argv);
  }
#undef DATA_CHANGE_LISTENER  

  shm_io_info_t *io = shm_io_open(argv[1]);

  __io__ = io;

  tr_cntxt.io = io;
  tr_cntxt.pid = getpid();
  
  extern int (*get_shm_identityCode)(void);
  get_shm_identityCode = tr_get_shm_identityCode;
 


  char buf[256];
  sprintf(buf, "\033[0;32m%d: Hello %d!\033[0m", getppid(), getpid());
  shm_io_write(io, io->out, buf, strlen(buf)+1);


  // Start R
  //char *argv[] = {"REmbeddedPostgres", "--gui=none", "--silent"};
  //char *new_argv[] = {"Java_HelloJNI"};
  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  //printf("\033[0;31mR_CStackStart = %ld\n\033[0m", R_CStackStart);
  //printf("R_CStackLimit = %ld\n", R_CStackLimit);
  //printf("R_Interactive = %d\n", R_Interactive);


  //Rf_initEmbeddedR(argc, argv);
  // start a large stack-size pthread???
  // set JVM stack size
  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    //printf("R_CStackStart = %ld\n", R_CStackStart);
    //printf("R_CStackLimit = %ld\n", R_CStackLimit);
    R_Interactive = TRUE;
    setup_Rmainloop();
  }

 
#ifdef __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionInt;
    sa.sa_sigaction = myR_SigactionTaskRunnerInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &R_oldactInt);
  }
#endif
  
 
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
  }
 
#ifdef __USE_SIGUSR1__
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }
#endif

#ifdef __USE_SIGUSR2__
  {
    struct sigaction sa;
    sa.sa_sigaction = myR_SigactionTaskRunnerUsr2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);
  }
#endif
  
  SEXP res = R_NilValue;


  {
    SEXP call = PROTECT(LCONS(install("source"),
			    CONS(mkString("jR.R"), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);
  }


  while(TRUE) { 
    
    //isTaskrunnerInterrupted = FALSE;
    isInterrupted = FALSE;
    int terminate = FALSE;

    size_t size;
    //char *_shm_name=NULL;

    printf("[%s] Ready for the next job ...\n", __func__);
    fprintf(stderr, "[%s] Ready for the next job ...\n", __func__);
    // { printf("[%s] No error\n", __func__); PrintValue(res); }
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    int cmd = ((int*) ptr)[0];
    //printf("Command: %d %s\n",  cmd, cmd2str(cmd));
    //fprintf(stderr, "Command: %d %s\n",  cmd, cmd2str(cmd));
    //free(ptr);
    
    if(cmd ==  TR_EXIT)  {
      free(ptr);
      break;
    } else if(cmd == TR_NEW_JOB){


      int job_id = ((int*)ptr)[1];
      free(ptr);
      printf("\n[%s] job_id = %d, Continue ...\n", __func__, job_id);

      ptr = shm_io_read(io, io->in, &size, NULL);
      printf("\n[%s] size = %ld, Continue ...\n", __func__, size);

      int myid = -1; // for this job

      tr_cntxt.job_id = job_id;
      
      { // register
        cmd = TR_JOB_REGISTER;
        shm_io_write(io, io->out, &cmd, sizeof(int));

        size_t _size;
        //char *_shm_name=NULL;
        void *id = shm_io_read(io, io->in, &_size, NULL);
	myid = ((int*)id)[0];
        printf("\n[%s] myid = %d, Continue ...\n", __func__, myid);
        fprintf(stderr, "\n[%s] myid = %d, Continue ...\n", __func__, myid);
        fprintf(stderr, "[%s] myid = %d, Continue ...\n", __func__, myid);
	free(id);
	if(myid == -1){
          cmd = TR_NEXT_JOB;
          shm_io_write(io, io->out, &cmd, sizeof(int));
	  free(ptr);
	  continue;
	}
      }

      if(myid == -1){
        free(ptr);
        cmd = TR_NEXT_JOB;
        shm_io_write(io, io->out, &cmd, sizeof(int));
	continue;
      }

      tr_cntxt.tr_id = myid;

      SEXP ro = PROTECT(SUPR_unserialize(ptr, R_GlobalEnv, size));
      free(ptr); // not for mem_data

      //printf("Info: ROBJ object (%s):\n", type2char(TYPEOF(ro)));
      //PrintValue(ro);
      {
        char buf[128*200];
        fprintf(stderr, "Info: ROBJ object: %s\n", 
		      __r2str(ro, buf, sizeof(buf), 0));
      }

//    SEXP expr  = VECTOR_ELT(ro, 0);
      SEXP envir = VECTOR_ELT(ro, 1);
      if(envir == R_NilValue) {
        //envir = R_GlobalEnv;
        envir =  PROTECT(allocSExp(ENVSXP));
        SET_VECTOR_ELT(ro, 1, envir);
	UNPROTECT(1);
      } 
      SET_ENCLOS(envir, R_GlobalEnv); // FIXME
      defineVar(install(TR_JOB_ID), ScalarInteger(job_id), envir);
      defineVar(install(TR_TR_ID), ScalarInteger(myid), envir);
      //SEXP ioPtr=PROTECT(R_MakeExternalPtr(io, install("future"),R_NilValue));
      SEXP ioPtr = PROTECT(R_MakeExternalPtr(io, R_NilValue, R_NilValue));
      defineVar(install(TR_TR_IO), ioPtr, envir);
        
      tr_shm_init(job_id, myid);

      int errorOccurred;
      //SEXP res = PROTECT(R_tryEval(VECTOR_ELT(ro,0), R_GlobalEnv,
      //		    &errorOccurred));

      //SEXP res = PROTECT(R_tryEval(VECTOR_ELT(ro, 0), envir,
      //		    &errorOccurred));

      int save = R_PPStackTop;
      fprintf(stderr, "[%s, %d] save %d, R_PPStackTop = %d\n",
		     __FILE__, __LINE__,  save, R_PPStackTop);

      SEXP res = PROTECT(R_myTryEval(VECTOR_ELT(ro, 0), envir,
			    &errorOccurred));

      if(R_PPStackTop <= save) {
        fprintf(stderr, "[%s, %d] save %d, R_PPStackTop = %d\n",
		     __FILE__, __LINE__,  save, R_PPStackTop);
	PROTECT(ro);
	PROTECT(res);
      }
      SET_VECTOR_ELT(ro, 0, res);
      SET_VECTOR_ELT(ro, 1, ScalarInteger(errorOccurred));
      SET_VECTOR_ELT(ro, 2, mkString(argv[1]));
      SEXP names = getAttrib(ro, R_NamesSymbol);
      if(errorOccurred)
        SET_STRING_ELT(names, 0, mkChar("error"));
      else
        SET_STRING_ELT(names, 0, mkChar("value"));
      SET_STRING_ELT(names, 1, mkChar("rc")); // return code
      SET_STRING_ELT(names, 2, mkChar("task.runner")); // return code

      // warnings???

      {
         size_t buf_size = 128*200;
	 char buf[buf_size];
	 fprintf(stderr, "result to return: %s\n", __r2str(ro, buf, buf_size, 0));
	 fprintf(stdout, "result to return: %s\n", __r2str(ro, buf, buf_size, 0));
	 fprintf(stderr, "isInterrupted: %d\n\n", isInterrupted);
	 fprintf(stdout, "isInterrupted: %d\n\n", isInterrupted);
	 terminate = isInterrupted;
	 //isInterrupted = 0;

	 if(isInterrupted){
	   fprintf(stderr, "exit: %d\n\n", isInterrupted);
	   fprintf(stdout, "exit: %d\n\n", isInterrupted);
           exit(1);
	 }

      }


      PrintValue(ro);

#ifdef USE_SUPR_SERIALIZE
      size_t size;
      void *raw = SUPR_serialize(ro, R_GlobalEnv, &size);

      cmd = TR_SEND_DRIVER;
      shm_io_write(io, io->out, &cmd, sizeof(int));

      {
         void *array = malloc(4*sizeof(int) + size);

	 int *header = (int*) array;
	 header[0] = TASK_RESULTS;
	 header[1] = job_id;
	 header[2] = myid;
#define SERIALIZED_R_OBJ 100
	 header[3] = SERIALIZED_R_OBJ; // fixme

	 memcpy(array+4*sizeof(int), raw, size);
         shm_io_write(io, io->out, array, 4*sizeof(int)+ size);
	 free(raw);

         ptr = shm_io_read(io, io->in, &size, NULL);
	 printf("[%s] Received %ld bytes\n", __func__, size);
	 if(size==4){
	   printf("[%s] Received integer %d \n", __func__, ((int*)ptr)[0]);
	 }
	 // ignore?
      }
      //UNPROTECT(3);
      UNPROTECT(R_PPStackTop);

#else
///////////////////////////////////////
      SEXP call = PROTECT(LCONS(install("serialize"),
                         CONS(ro, CONS(R_NilValue, R_NilValue))));
      SEXP raw = PROTECT(eval(call, R_GlobalEnv));

      cmd = TR_SEND_DRIVER;
      shm_io_write(io, io->out, &cmd, sizeof(int));
      //shm_io_write(io, io->out, RAW(raw), LENGTH(raw));
      {

         void *array = malloc(4*sizeof(int) + LENGTH(raw)); 

	 int *header = (int*) array;
	 header[0] = TASK_RESULTS;
	 header[1] = job_id;
	 header[2] = myid;
#define SERIALIZED_R_OBJ 100
	 header[3] = SERIALIZED_R_OBJ;

#ifdef __TESTING__
	 memcpy(array+4*sizeof(int), raw, sizeof(SEXPREC_ALIGN) + LENGTH(raw));
         shm_io_write(io, io->out, array, 4*sizeof(int)+LENGTH(raw)
			 +sizeof(SEXPREC_ALIGN));
#else
	 //memcpy(array+4*sizeof(int), RAW(raw), LENGTH(raw));
         //shm_io_write(io, io->out, array, 4*sizeof(int)+LENGTH(raw));
	 memcpy(array+4*sizeof(int), raw, LENGTH(raw));
         shm_io_write(io, io->out, array, 4*sizeof(int)+ LENGTH(raw));
	 printf("4*sizeof(int)+LENGTH(raw)=%ld\n", 4*sizeof(int)+LENGTH(raw));
#endif

         ptr = shm_io_read(io, io->in, &size, NULL);
	 printf("[%s] Received %ld bytes\n", __func__, size);
	 if(size==4){
	   printf("[%s] Received integer %d \n", __func__, ((int*)ptr)[0]);
	 }
	 // ignore?

#ifdef __TESTING__
	 printf("***** sizeof(SEXPREC_ALIGN) - (RAW(raw) - raw) = %d\n",
	         sizeof(SEXPREC_ALIGN) - ((long)RAW(raw) - (long) raw));
#endif
      }


//      UNPROTECT(6);
      UNPROTECT(5);
#endif

      cmd = TR_NEXT_JOB;
      shm_io_write(io, io->out, &cmd, sizeof(int));

      //fprintf(stderr, "[1] R_interrupts_pending = %d\n", R_interrupts_pending);
      //fprintf(stdout, "[1] R_interrupts_pending = %d\n", R_interrupts_pending);
    } else {
	    TODO();
    }
    //fprintf(stderr, "[2] R_interrupts_pending = %d\n", R_interrupts_pending);
    //fprintf(stdout, "[2] R_interrupts_pending = %d\n", R_interrupts_pending);

    if(terminate) // if(isInterrupted)
    {
      fprintf(stderr, "[%s] isInterrupted = %d\n", __func__,
			    isInterrupted);
      cmd = TR_EXIT;
      char buf[256];
      memcpy(buf, &cmd, sizeof(int));
      sprintf(buf+sizeof(int), "interrupted");
      shm_io_write(io, io->out, &buf, sizeof(int)+strlen(buf+sizeof(int)));
      break;
    }
  }
  

  //R_Interactive = FALSE; 
  //if(R_Interactive) run_Rmainloop();

 // Rf_endEmbeddedR(0);

  return 0;
}
*/
