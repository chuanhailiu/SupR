
//#include "supr.h"
//#include "util.h"

#include "dd.h"

#include <sys/types.h>
#include <sys/wait.h>

#define msg_color "\033[0;35m"

#define RUN_AS_DAEMON_PROC

supr_socket_conn_t *socketServerConn = NULL;

extern pthread_mutex_t Supr_syncMutex;
extern pthread_mutex_t Supr_syncCond;
extern void Supr_syncObject;
extern supr_socket_conn_t *info_sc;
//extern supr_socket_conn_t *debug_sc;
static char msg[1024];
extern char *info_addr;
static char *notify_addr = NULL;

extern char *Supr_defaultInfonode;
extern char *X11_str; // X11Forwarding

static int main_argc = 0;
static char **main_argv = NULL;
static char *cmd = NULL;

static supr_socket_conn_t *info2nn_sc = NULL;

extern void addCleanups(void (*run)(void *), void *data);
extern vector_t *cleanups;
extern void doCleanups();
extern SEXP SuprEnv;
extern SEXP SuprJobEnv;



typedef struct DT_thread_task_struct {
  void (*fun)(void *);
  void *data;
} DT_thread_task_t;

vector_t *DT_thread_tasks = NULL;
#define gettid() ((int)syscall(SYS_gettid))

static int  DDT_isCancelled = FALSE;



//
static int Cluster_sendSimpleMessage2nn(const char *msg, const char *color, int type, int level){
  /*
    switch(type){ // FIXME
    case VERBOSE_INFO_TYPE: if(!Supr_verbose) return -1;
        break;
    case DEBUG_INFO_TYPE: if(!Supr_debug) return -1;
        break;
    case 0:
    case BASIC_INFO_TYPE: if(!Supr_infov) return -1;
        break;
    default: break;
  }
  */

  if(!info2nn_sc) {
          fprintf(stderr, "%s%s\033[0m: %s\n", color, __func__, msg);
          return -1;
  }

  int rc;

  pthread_mutex_lock(&Supr_syncMutex);

      int fd = info2nn_sc->fd;

      int cmd = DFS_DD_DATANODE_INFO;
      write(fd, &cmd, sizeof(int)); 

      cmd = CLUSTER_INFO;
      write(fd, &cmd, sizeof(int));

             unsigned char buf[8];
             snprintf(buf, 8, "%s", color);
             write(fd, buf, sizeof(buf));
             write(fd, &type, sizeof(int));
             write(fd, &level, sizeof(int));
             ssize_t len = strlen(msg)+1;
             write(fd, &len, sizeof(ssize_t));
             write(fd, msg, len);
             read(fd, &rc, sizeof(int));
  
  pthread_mutex_unlock(&Supr_syncMutex);

  return rc;
}
//

#ifndef _
#define _(x) (x)
#endif


//vector_t *socket_connections = NULL;
extern vector_t *socket_connections;
vector_t *threads = NULL;

char *DFS_namenodeAddr = NULL;

extern int Supr_debug;

//#define  DEBUG_VECTOR
#ifdef   DEBUG_VECTOR
int __vectorDestroy(vector_t *vec, const char* func, const char *file, int line) {
  printf("[%s] %s (%s:%d): [vec=%p, vec->elements=%p]\n", __func__,
                  func, file, line, vec, vec->elements);
 return vectorDestroy(vec);
}

void *__vectorAdd(vector_t *vec, void *elem, const char* func, const char *file, int line) {
  printf("[%s] %s (%s:%d): [vec=%p, vec->elements=%p]\n", __func__,
                  func, file, line, vec, vec->elements);
  return vectorAdd(vec, elem);
}

vector_t *__newVector(int sync, const char* func, const char *file, int line) {
        vector_t *vec = newVector(sync);
  printf("[%s] %s (%s:%d): [vec=%p, vec->elements=%p]\n", __func__,
                  func, file, line, vec, vec->elements);
  return vec;
}

#define vectorDestroy(v) __vectorDestroy((v), __func__, __FILE__, __LINE__)
#define vectorAdd(v, e) __vectorAdd((v), (e), __func__, __FILE__, __LINE__)
#define newVector(s) __newVector((s), __func__, __FILE__, __LINE__)
#endif

#define USE_MULTI_DIRS

//#define DEBUG_OPEN_FILES
#ifdef  DEBUG_OPEN_FILES
static int max_fd = 0;
static pthread_mutex_t max_fd_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif

typedef struct datanode_dir_struct {
  int fd; // 
  int padding;
  char *path;
} datanode_dir_t;

typedef struct dir_array_struct {
  int ndir; // number of locations/directories 
  int padding;
  datanode_dir_t dirs[0];
} dir_array_t;

dir_array_t *dir_array = NULL;
// 
//dir_array_t *Datanode_dirArray = dir_array; ...
#define DD_DIR_LENGTH (dir_array->ndir)
#define DD_DIR_PATH(idx) (dir_array->dirs[(idx)].path)


extern char *Exec_timestamp(char *buf, size_t buf_size);
//extern FILE *stdlog;
extern char *Supr_usrHome;
extern char *Supr_dfsHome;

extern char *connTypeToStr(int type);


/*
int __open__2(const char *path, int oflag,
		const char *file, int line, const char *fun
		){

	// va_list ap; int mode; va_start(ap, oflag); mode = va_arg(ap, int); va_end(ap);

  int fd = open(path, oflag);
  if(strstr(path,"EM_data") && *(strstr(path,"EM_data")+strlen("EM_data"))==0){
    fprintf(stderr, "%s:%d:%s: file: %s fd: %d\n", file, line, fun, path, fd);
    fflush(stderr);
  }
  return fd;
}

int __open__3(const char *path, int oflag, mode_t mode,
		const char *file, int line, const char *fun
		){
  int fd = open(path, oflag, mode);
  if(strstr(path,"EM_data") && *(strstr(path,"EM_data")+strlen("EM_data"))==0){
    fprintf(stderr, "%s:%d:%s: file: %s fd: %d\n", file, line, fun, path, fd);
    fflush(stderr);
  }
  return fd;
}

int __openat__3(int dirfd, const char *path, int oflag,
		const char *file, int line, const char *fun
		){
  int fd = openat(dirfd, path, oflag);
  if(strstr(path,"EM_data") && *(strstr(path,"EM_data")+strlen("EM_data"))==0){
    fprintf(stderr, "%s:%d:%s: file: %s fd: %d\n", file, line, fun, path, fd);
    fflush(stderr);
  }
  return fd;
}

int __openat__4(int dirfd, const char *path, int oflag, mode_t mode,
		const char *file, int line, const char *fun
		){
  int fd = openat(dirfd, path, oflag, mode);
  if(strstr(path,"EM_data") && *(strstr(path,"EM_data")+strlen("EM_data"))==0){
    fprintf(stderr, "%s:%d:%s: file: %s fd: %d\n", file, line, fun, path, fd);
    fflush(stderr);
  }
  return fd;
}

#define open(p, f) __open__2((p), (f), __FILE__, __LINE__, __func__);
#define open3(p, f, m) __open__3((p), (f), (m), __FILE__, __LINE__, __func__);
#define openat(fd, p, f) __openat__3((fd), (p), (f), __FILE__, __LINE__, __func__);
#define openat4(fd, p, f, m) __openat__4((fd), (p), (f), (m), __FILE__, __LINE__, __func__);
*/

/*
#define CHECK_OPEN(s) 	do {	\
	if(strstr((s), "testing_data"))	{	\
		char msg[256];	\
		sprintf(msg, "%s:%d: %s",__FILE__, __LINE__, (s));	\
		basic_info((s));	\
	}	\
} while(0)
*/


void __printf__(const char *format, ...)
{
	static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  va_list ap;
  va_start(ap, format);
  pthread_mutex_lock(&mutex);

  /*
  if(stdlog) {
    vfprintf(stdlog, format, ap);
    fflush(stdlog);
  } else {
  */
    vprintf(format, ap);
    fflush(stdout);
  //}

  pthread_mutex_unlock(&mutex);


}

#define printf __printf__("(%s:%d) ", __FILE__, __LINE__); __printf__

//pthread_key_t stacktraceKey;
//pthread_key_t interruptThreadKey;


extern char *SUPR_DFS_HOMEUSR;
extern char *SUPR_DFS_HOMESYS;
extern void suprDFSHomeInit();

supr_socket_conn_t *backendConn = NULL;
supr_socket_conn_t *namenodeConn = NULL;

//supr_thread_t *backend_2 = NULL;

// for local shm connections
supr_thread_t *startBackend_2(shm_io_info_t *io);
//vector_t *backend_2_tasks = NULL;

/*
typedef struct backend_2_task_struct {
  void (*run)(struct backend_2_task_struct *);
  void *data;
} backend_2_task_t ; // FIXME
*/

//vector_t *shm_names = NULL;


#ifdef DEBUG_OPEN_FILES
static vector_t *ft_conns = NULL;
// check...
#define MAX_FDS 1024
static char *file_names[MAX_FDS];

void DFSDATA_showOpenedFileNames()
{
      fprintf(stderr, "\n");
  char buf[PATH_MAX];
  for(int i=0; i<MAX_FDS; i++){
    char fileName[PATH_MAX];
    sprintf(fileName, "/proc/self/fd/%d", i);
    ssize_t n = readlink(fileName, buf, sizeof(buf));
    if(n != -1) {
      buf[n] = 0;
      sprintf(fileName + strlen(fileName), ": %s", buf);
      fprintf(stderr, "%s\n", fileName);
      //basic_info(fileName);
    }
  }
      fprintf(stderr, "\n");
      fflush(stderr);
}

void DFSDATA_socketDestroy(supr_socket_conn_t *conn){
  int n = 0;
  pthread_mutex_lock(ft_conns->mutex);
    vectorRemoveElement(ft_conns, conn);
    n = vectorSize(ft_conns);
  pthread_mutex_unlock(ft_conns->mutex);
  socketDestroy(conn);
  {
    char msg[256];
    sprintf(msg, "nconns: %d", n);
    basic_info(msg);

    if(n==0){
      for(int i=0; i<MAX_FDS; i++){
        if(file_names[i]) {
	  basic_info(file_names[i]);
	  n++;
	}
      }
      sprintf(msg, "nfiles: %d", n);
      basic_info(msg);

      //DFSDATA_showOpenedFileNames();
    }
  }
}

void  DFSDATA_socketAdd(supr_socket_conn_t *conn){
  pthread_mutex_lock(ft_conns->mutex);
    vectorAdd(ft_conns, conn);
  pthread_mutex_unlock(ft_conns->mutex);
}

void  DFSDATA_fileDelete(int fd){
  free(file_names[fd]);
  file_names[fd] = NULL;
}

void  DFSDATA_fileSet(int fd, const char *fileName){
  if(fd < 0) return;
  static int max_fd = -1;
  if(max_fd < fd) {
    max_fd = fd;
    char msg[256];
    sprintf(msg, "Set file_names[max_fd=%d]: %s", fd, fileName);
    basic_info(msg);
  }
  file_names[fd] = strdup(fileName);
}

#endif


void doCleanup();
//#ifndef malloc
#define malloc(size) __supr_malloc__((size), __func__, __FILE__, __LINE__)
#define realloc(ptr, size) __supr_realloc__((ptr), (size), __func__, __FILE__, __LINE__)
#define free(ptr) __supr_free__((ptr), __func__, __FILE__, __LINE__)
//#endif


size_t __read__(int fd, void *buf, size_t size);

extern void Html_sendError(supr_socket_conn_t *conn, const char *file_name);

/*
#define STDLOG_BUF_SIZE 4096;
typedef struct stdlog_struct {
  size_t buf_size;
}
*/

//extern int Supr_stdlog_fileno;
//extern char *Supr_stdlog_filename;

void Html_sendIndex(supr_socket_conn_t *conn)
{
  char *idx = "<!DOCTYPE html>\n<HEAD>\n<TITLE>DFS_data</TITLE>\n"
        "  <META charset=\"utf-8\">\n</HEAD>\n<BODY>\n<UL>\n"
        "\t<LI><a href=\"stdout.txt\">stdout</a></LI>\n"
        "\t<LI><a href=\"stderr.txt\">stderr</a></LI>\n"
        "\t<LI><a href=\"info.txt\">info</a></LI>\n"
        "\t<LI><a href=\"data.html\">/datadir</a></LI>\n"
        "</UL>\n</BODY>\n";

  const char *p_format = "HTTP/1.1 200 OK\r\nServer:SupR2\r\n"
          "Content-length: %ld\r\nContent-type:%s; charset=UTF-8\r\n\r\n";
  char *ct = "text/html";

  char protocol[strlen(p_format)+strlen(ct)+64];
  sprintf(protocol, p_format, strlen(idx), ct);

  send(conn->fd, protocol, strlen(protocol), 0);
  send(conn->fd, idx, strlen(idx), 0);

}

void Html_sendFile(supr_socket_conn_t *conn, const char *file_name);
int __listFiles__(FILE *fs, char *parent_dir, char *htmlpath, char *file);
void Html_sendFileList(supr_socket_conn_t *conn, const char *file_name);

// modified from dfs_name.c/handleHTTP_GET
void Html_sendFile(supr_socket_conn_t *conn, const char *file_name)
{
  //fprintf(stderr, "file_name: %s\n", file_name);
  if(strncmp(file_name, "data", strlen("data"))==0) {
    //fprintf(stderr, "OKAY? file_name: %s\n", file_name);
    Html_sendFileList(conn, file_name);
    return;
  }

  char path[PATH_MAX];
  if(strcmp(file_name, "stdout.txt")==0 ||strcmp(file_name, "stderr.txt")==0 ){
    fprintf(stdout, "cwd: %s\n", getcwd(path, PATH_MAX));
    fflush(stdout);
    //sprintf(path, "%s/%s.%d.%s", html_dir, Supr_hostname, getpid(), file_name);
    sprintf(path, "%s", file_name);
    /*
  } else if(strcmp(file_name, "stdlog.txt")==0 && stdlog != NULL ){
    fflush(stdlog);
    sprintf(path, "%s", Supr_stdlog_filename);
    */
  //} else if(strcmp(file_name, "info.txt")==0){
  } else if(strcmp(file_name, "supr.conf")==0){
    char path[PATH_MAX];
    sprintf(path, "%s/supr.conf", Supr_usrHome);
    // Html_sendFile(conn, path, "text/plain");
  } else if(*file_name =='/' ){
    sprintf(path, "%s", file_name);
  } else { // TODO ...
    Html_sendError(conn, file_name);
    return;
  }

  //fprintf(stderr, "path: %s\n", path);


  int file_fd = open(path, O_RDONLY);
  struct stat sb;
  if(file_fd == -1 || fstat(file_fd, &sb) == -1){
    Html_sendError(conn, file_name);
    return;
  }

  char protocol[] = "HTTP/1.1 200 OK\r\n";
  char servName[] = "Server:SupR2\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  char cntType[256];

  sprintf(cntLen, "Content-length: %ld\r\n", sb.st_size);
  char buf[sb.st_size];
  read(file_fd, buf, sb.st_size);
  close(file_fd);

  //char *ct = "image/webp";
  char *ct = "text/plain";
  {
     const char *s = file_name + strlen(file_name)-1;
     while(s != file_name && *s != '.')
             s--;
     s++;
     if(strcmp(s, "html")==0){
       ct = "text/html";
     }
  }

  snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n",
                  ct);

  int fd = conn->fd;
  send(fd, protocol, strlen(protocol), 0);
  send(fd, servName, strlen(servName), 0);
  send(fd, cntLen, strlen(cntLen), 0);
  send(fd, cntType, strlen(cntType), 0);

  send(fd, buf, sizeof(buf), 0);
}


// modified from dfs_name.c/handleHTTP_GET
int __listFiles__(FILE *fs, char *parent_dir, char *htmlpath, char *file)
{
        /*
    fprintf(fs, "<p>parent_dir: %s,<br> htmlpath: %s,<br> file: %s</p>\n",
                    parent_dir, htmlpath, file);
                    */

    char *dirname = file;
    while(*file != '/') file++;
    *file = 0;
    file ++;

    char thisdir[strlen(parent_dir)+strlen(dirname)+2];
    sprintf(thisdir, "%s/%s", parent_dir, dirname);

    //printf("thisdir: %s\n", thisdir);
    //printf("dirname: %s\n", dirname);

    char dirpath[PATH_MAX];
    memcpy(dirpath, htmlpath, strlen(htmlpath)+1);

    sprintf(dirpath + strlen(dirpath), "%s/", dirname);

    printf("thisdir: %s\n", thisdir);
    //fprintf(fs, "thisdir: %s\n", thisdir);


    DIR *dir = opendir(thisdir);
    if(!dir) {
      fprintf(fs, "<p>Error: %s, %s</p>\n", thisdir, strerror(errno));
      //return -1;
      return 0;
    }

    fprintf(fs, "<UL>\n");

    char next_dirname[strlen(file)+1];
    memcpy(next_dirname, file, strlen(file)+1);
    char *s = next_dirname;
    while(*s && *s != '/') s++;
    *s = 0;


    struct dirent *dp;
    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0
         || strncmp(dp->d_name, ".nfs", 4)==0)
              continue;
      if(strcmp(dp->d_name, next_dirname)==0) {
        //fprintf(fs, "<LI><font color=#FF0000>%s</font></LI>\n", dp->d_name);
        fprintf(fs, "<LI><a href=\"%s%s.html\">%s</a></LI>\n", dirpath,
                        dp->d_name, dp->d_name);
        //char _dirpath[PATH_MAX];
        //memcpy(_dirpath, dirpath, strlen(dirpath)+1);
        __listFiles__(fs, thisdir, dirpath, file);
      } else if(dp->d_type == DT_DIR) {
        fprintf(fs, "<LI><a href=\"%s%s.html\">%s</a></LI>\n", dirpath,
                        dp->d_name, dp->d_name);
      } else {
        fprintf(fs, "<LI>%s</LI>\n", dp->d_name);
      }
    }
    fprintf(fs, "</UL>\n");

    return 0;
}


// modified from dfs_name.c/handleHTTP_GET
void Html_sendFileList(supr_socket_conn_t *conn, const char *file_name)
{
  char template[128];
  sprintf(template, "/tmp/supr_dfs_XXXXXX.%s", "html");
  int fd = mkstemps(template, strlen("html")+1);
  FILE *fs = fopen(template, "w+");
  fprintf(fs, "<!DOCTYPE html>\n<HEAD>\n<TITLE>SupR2</TITLE>\n"
        "  <META charset=\"utf-8\">\n</HEAD>\n<BODY>\n");

  fprintf(fs, "<h4>datadir/</h4>\n");

  fprintf(stderr, "[%s] TESTING: %s\n", __func__, file_name);


#ifdef USE_MULTI_DIRS
  int rc = 0;
  fprintf(fs, "<OL>\n");
  for(int dir_idx = 0;  dir_idx < DD_DIR_LENGTH;  dir_idx ++){
    char dir[PATH_MAX];
    sprintf(dir, "%s/data", DD_DIR_PATH(dir_idx));
    fprintf(fs, "<LI>%s<br><p>\n", dir);
    //if(strstr(file_name, dir)){

      char thisdir[PATH_MAX];
      char file[strlen(file_name)+1];
      memcpy(file, file_name, strlen(file_name)+1);
      char *s = file + strlen(file)-1;
      while(s != file && *s != '.') s--;
      *s = '/';
      s++; *s=0;

      //getcwd(thisdir, PATH_MAX);
      sprintf(thisdir, "%s", DD_DIR_PATH(dir_idx));

      char htmlpath[PATH_MAX];
      //htmlpath[0] = 0;
      htmlpath[0] = '/';
      htmlpath[1] = 0;

      //fprintf(stderr, "TESTING: %s\n", file_name);
      int rc = __listFiles__(fs, thisdir, htmlpath, file);

    //}
    fprintf(fs, "</p></LI>\n");
  }
  fprintf(fs, "</OL>\n");
#else


  char thisdir[PATH_MAX];
  char file[strlen(file_name)+1];
  memcpy(file, file_name, strlen(file_name)+1);
  char *s = file + strlen(file)-1;
  while(s != file && *s != '.') s--;
  *s = '/';
  s++; *s=0;

  getcwd(thisdir, PATH_MAX);

  char htmlpath[PATH_MAX];
  //htmlpath[0] = 0;
  htmlpath[0] = '/';
  htmlpath[1] = 0;

  //fprintf(stderr, "TESTING: %s\n", file_name);
  int rc = __listFiles__(fs, thisdir, htmlpath, file);

#endif


  fprintf(fs, "</BODY>\n");
  fclose(fs);
  close(fd);


  if(rc == -1)
    Html_sendError(conn, file_name);
  else
    Html_sendFile(conn, template);

  unlink(template);
  return;
}

void handleHTTP_GET(supr_socket_conn_t *conn)
{
  int fd = conn->fd;

  size_t buf_size = 4096;
  unsigned char buf[buf_size+1];
  ssize_t len = recv(fd, buf, buf_size, MSG_PEEK | MSG_DONTWAIT);
  len = __read__(fd, buf, len);
  buf[len++] = 0;
  fprintf(stderr, "\033[0;36m[%s://%s:%d]\n\"%s\"\033[0m\n", connTypeToStr(conn->type), conn->host, conn->port, buf);

  char *file_name = strstr(buf, " /")+2;
  char *str = strstr(file_name, " HTTP/");
  *str = 0;

  unsigned char *content = NULL;
  char *ct = "text/plain";
  size_t content_size;

  struct stat sb;

  if(strlen(file_name)==0){
    //Html_sendError(conn, "index.html");
    Html_sendIndex(conn);
    return;
    /*
  } else if (strcmp(file_name, "stdlog.txt")==0 && Supr_stdlog_fileno != -1
	  && fstat(Supr_stdlog_fileno, &sb) != -1) {
    content = (unsigned char *) malloc(sb.st_size);
    //rewind(stdlog);
    lseek(Supr_stdlog_fileno, 0, SEEK_SET);
    read(Supr_stdlog_fileno, content, sb.st_size);
    content_size = sb.st_size;
    lseek(Supr_stdlog_fileno, 0, SEEK_END);
    */
  } else if (strcmp(file_name, "info.txt")==0 ){
    char buf[4096];
    char *s = buf;
    sprintf(s, "Connections:\n"); s += strlen(s);
    for(int i=0; i < vectorSize(socket_connections); i++){
      supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(socket_connections, i);
      sprintf(s, "  %s://%s:%d\n", connTypeToStr(sc->type),sc->host, sc->port);
      s += strlen(s);
    }

    content_size = strlen(buf);
    content = (unsigned char *) malloc(content_size);
    memcpy(content, buf, content_size);

  } else if (strcmp(file_name, "stderr.txt")==0 
		  || strcmp(file_name, "stdout.txt")==0 ){
    fflush(stdout);
    int rc = stat(file_name, &sb);
    if(rc == -1){
      Html_sendError(conn, file_name);
      return;
    }
    content_size = sb.st_size;
    content = (unsigned char *) malloc(sb.st_size);
    int file_fd = open(file_name, O_RDONLY);
    read(file_fd, content, sb.st_size);
    close(file_fd);
  } else if  (strncmp(file_name, "data", strlen("data"))==0 
             || strncmp(file_name, "/data", strlen("/data"))==0){ 
    Html_sendFileList(conn, file_name);
    return;
  } else {
    Html_sendError(conn, file_name);
    return;
  }

  char protocol[] = "HTTP/1.1 200 OK\r\n";
  char servName[] = "Server:SupR2\r\n";
  char cntLen[256]; // = "Content-length:2048\r\n";
  sprintf(cntLen, "Content-length: %ld\r\n", content_size);
  char cntType[256];
  snprintf(cntType, sizeof(cntType), "Content-type:%s; charset=UTF-8\r\n\r\n",
                  ct);

  /*
  fprintf(stderr, "protocol: %s", protocol);
  fprintf(stderr, "servName: %s", servName);
  fprintf(stderr, "cntLen: %s", cntLen);
  fprintf(stderr, "cntType: %s", cntType);

  fprintf(stderr, "Supr_stdlog_filename: %s", Supr_stdlog_filename);
  write(STDERR_FILENO, content, content_size);
  fprintf(stderr, "\n");
  fprintf(stderr, "Supr_stdlog_fileno: %d, stdlog_fileno: %d\n",
		  Supr_stdlog_fileno, fileno(stdlog));
  */

 // int fd = conn->fd;
  send(fd, protocol, strlen(protocol), 0);
  send(fd, servName, strlen(servName), 0);
  send(fd, cntLen, strlen(cntLen), 0);
  send(fd, cntType, strlen(cntType), 0);

  send(fd, content, content_size, 0);

  free(content);
}

#define TODO_STR() __TODO__(__func__, __FILE__, __LINE__)
char *__TODO__(const char *func, const char* file, int line)
{
  char buf[256];
  sprintf(buf, "FIXME: %s (%s:%d)", func, file, line);
  return strdup(buf);
}

int DD_checkUserInterrupt()
{
  void *value = pthread_getspecific(interruptThreadKey);
  int isInterrupted = FALSE;
  if(value){ // TODO???
    isInterrupted = TRUE;
    // pthread_setspecific(interruptThreadKey, NULL);
  }
  return isInterrupted;
}

// change the names later ...

// task for file transfers
typedef struct task_struct {
  void (*run)(void *data); // task
  void *data;
  vector_t *processed; // _queue
  //char *err;
  String err;
  int  rc;
  int  err_no;
  pthread_mutex_t *notify_mutex;
  pthread_cond_t  *notify_cond;
} task_t;

task_t *newTask(void (*run)(void *), void *data, vector_t *processed,
	pthread_mutex_t *notify_mutex, pthread_cond_t  *notify_cond){

  task_t *task = (task_t *) malloc(sizeof(task_t));
  task->run = run;
  task->data= data;
  task->processed = processed;
  task->err = NULL;
  task->rc  = 0;
  task->err_no  = 0;

  task->notify_mutex = notify_mutex;
  task->notify_cond  = notify_cond;

}
// destroy???

supr_thread_t *startTaskrunner(supr_thread_t *executor);

vector_t *file_transfers = NULL;
vector_t *backend_taskrunners = NULL; // change the name

#define   DECREASE_REF(x) do {	\
	printf("[DECREASE_REF] %s:%d\n", __FILE__, __LINE__);	\
	__decrease_ref__(x)	;	\
} while(0)

// under development
#define DEBUG_GC

typedef struct __malloc_obj_struct {
  size_t size;
  int ref_count;
#ifdef DEBUG_GC
  int src_line; // delete me
  char *src_file;
#else
  int padding;
#endif
} __malloc_obj_t;


#ifdef DEBUG_GC
#endif
typedef struct malloc_debug_struct {
  void *ptr; //
  void *malloc_ptr;
  struct malloc_debug_struct *next;
} malloc_debug_t;

malloc_debug_t malloc_bebug_root_struct = {NULL, NULL, NULL};
malloc_debug_t *malloc_bebug_root = &malloc_bebug_root_struct;

malloc_debug_t *malloc_bebug_add(malloc_debug_t *m)
{
  m->next = malloc_bebug_root->next;
  return malloc_bebug_root->next = m;
}

#ifdef USE_THIS_MALLOC

void *__malloc__(size_t size, char *src_file, int src_line)
{
  printf("\033[0;36m[%s]\033[0m] %s:%d\n", __func__, src_file, src_line);
  __malloc_obj_t *p = (__malloc_obj_t *) malloc(sizeof(__malloc_obj_t)+size);

  p->size = size;
  p->ref_count = 1;
#ifdef DEBUG_GC
  p->src_line = src_line;
  p->src_file = src_file;
#endif
  return p+1;
}


// man 3 free

void __free__(__malloc_obj_t *p)
{
  fprintf(stderr, "\033[0;36m[%s] %s:%d\033[0m]\n", __func__,
		  p->src_file, p->src_line);
//  __malloc_obj_t *p = (__malloc_obj_t *) ( (long) ptr - sizeof(__malloc_obj_t)); 
  free(p);
}

#endif

//void __malloc_obj__(class_t *class){}

int __decrease_ref__(void *ptr)
{
	/*
  __malloc_obj_t *p = (__malloc_obj_t *) ptr;
  p->ref_count--;
  if(p->ref_count == 0) 
   __free__(p);
   */
  return 0;
}

#define USE_SUPR_MALLOC
#ifdef  USE_SUPR_MALLOC

//#define malloc(size) __malloc__((size), __FILE__, __LINE__)
//#define free(ptr) __free__(ptr)
#endif





hashtable_t *syncEnvironment = NULL;
hashtable_t *waitEnvironment = NULL;

hashtable_t *ddEnvironment = NULL;

typedef struct executor_property_struct {
  supr_socket_conn_t *sc2worker;
  supr_socket_conn_t *sc2driver;
} executor_property_t;

vector_t *executors = NULL;

vector_t *jobs = NULL; // new_jobs???
vector_t *all_jobs = NULL;

int UID = 0;
void *PTHREAD_INTERRUPTED = NULL;
void *PTHREAD_TIMEOUT = NULL;

typedef struct {
  int type;
  int padding; // not used ...
  void *data;
} thread_info_t;

#define INTERRUPT 1     // {type, (char*) cause?}
#define NEW_JOB   2	// {type, job}

// info used for combine_bykey
typedef struct cbk_struct {
  pthread_cond_t cond;
  hashtable_t *shm_names;
  char **keys;
  int nkeys;
  int count;
} cbk_t;

typedef struct w_job_struct {
  class_t *class;
  int id;
  int count;  // or for padding
  void *expr; // (serialized R expression for taskrunners
  SEXP env;   // for driver and workers?

//  iterator_t *tasks; // implemented as subsets
  char *result; // for combine
//  void *future;

  pthread_mutex_t mutex;

  vector_t *taskrunners;
  vector_t *executors; // or workers, identified by socket address
  // data change listeners ...
  // vector_t assigned tasks
  supr_socket_conn_t *sc; // socket connection to driver;

  int stage;
  cbk_t *cbk;

} w_job_t;

//(cost)
const char *workerJobToString(class_t *class, void *object);

/*
typedef struct object_struct {
  class_t *class;
} object_t;
*/

// delete me ...
class_t *WorkerJob_class = NULL;

w_job_t *newWorkerJob(int job_id, void *expr){

  static class_t *class = NULL;
  if(!class){
    class = newClass("WorkerJob", workerJobToString , NULL);
//    printf("[%s] class = %p\n", __func__, class);
//    printf("[%s] class->name = %s\n", __func__, class->name);
    WorkerJob_class = class;
  }

  w_job_t *job = (w_job_t *)malloc(sizeof(w_job_t));
  job->class = class;
  job->id    = job_id;
  job->count = 0;
  job->expr  = expr;
  job->env   = R_NilValue;
//  job->tasks = tasks;
  job->result= NULL;
//  job->future= NULL;
  job->taskrunners = newVector(FALSE); // registered trs
  job->executors   = newVector(FALSE);
  job->stage = 0;

  job->cbk = NULL;

  //vectorAdd(jobs, job);

  //job->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(&job->mutex, NULL);

  job->sc = NULL;
//  __job__ = job;
//  __job_id__ = job->id;

  return job;
}

const char *workerJobToString(class_t *class, void *object)
{
  static strbuf_t *sb = NULL;
  if(!sb) sb = newStrbuf(256);

  sb->size = 0;
  strbufPutStr(sb, "(");
  strbufPutStr(sb, class->name);
  strbufPutStr(sb, ") ");
  char buf[256];
  sprintf(buf, "%p [job_id = %d]", object, ((w_job_t *)object)->id); 
  strbufPutStr(sb, buf);
  return sb->buf;
}

typedef struct {
  w_job_t *job;
  shm_io_info_t *io;
  pid_t   R_pid;  
  int     isInterrupted;
  // ...
} taskrunner_env_t;

//pthread_key_t taskrunnerThreadKey;

extern supr_thread_t *main_thread;
//supr_thread_t *main_thread = NULL;

extern char *SUPR_HOMEUSR;
extern char *SUPR_HOMESYS;
extern void suprHomeInit();

extern SEXP R_simpleTryEval(SEXP expr, SEXP env, int *errorOccurred);
extern SEXP R_simpleTryEval4(SEXP(*func)(SEXP args), SEXP args, SEXP env,
	       	int *errorOccurred);

/*
#define BEGIN_R_EVAL()     do      {       \
  pthread_mutex_lock(&main_thread->mutex);	\
  void *dummy; 	\
  int __save_R_CStackStart__ = R_CStackStart;	\
  R_CStackStart = (unsigned long) &dummy

#define END_R_EVAL()   \
  R_CStackStart = __save_R_CStackStart__;	\
  pthread_mutex_unlock(&main_thread->mutex);	\
} while(0)
*/


char *dupstr(const char *str)
{
  return memcpy(malloc(strlen(str)+1), str, strlen(str)+1);
}

//extern SEXP R_CStackStart;
extern unsigned long R_CStackStart;
extern unsigned long R_CStackLimit;
extern int R_Interactive;
extern void run_Rmainloop(void);

extern void myR_SigactionSegv(int sig, siginfo_t *ip, void *context);
extern void c_backtrace();



static shm_io_info_t *__io__ = NULL;

extern vector_t *cleanups;
extern void doCleanups();

int system_exit(int n){
  // cleanups later...
	/*
  if(cleanups){
    for(int i=vectorSize(cleanups)-1; i>=0; i--){
      do_t *cleanup = (do_t *) vectorElementAt(cleanups, i);
      printf("[%s] do_cleanup %p\n", __func__, cleanup);
      cleanup->_do_(cleanup->data);
    }
  }
  */

  printf("[%s] terminating ...\n", __func__);
  doCleanup();
  doCleanups();

  sleep(30);

  exit(n);
}

 
void rmConnLog()
{
  char path[PATH_MAX];
  getcwd(path, PATH_MAX);
  while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
  sprintf(path+strlen(path), "/%s.log", cmd);
  unlink(path);
}

extern pid_t main_pid;


void send_ExitInfo(){
  if(getpid() != main_pid) return;

  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  basic_info(__func__);
  if(cth) basic_info(cth->name);
  else return;

  supr_socket_conn_t *sc = NULL;
  if(info_addr && (sc = trySocketOpen1(info_addr))){
    int fd = sc->fd;

    int cmd = CLUSTER_PROC_CMD;
    write(fd, &cmd, sizeof(int));
    int len = strlen(proc_cmd)+1;
    write(fd, &len, sizeof(int));
    write(fd, proc_cmd, len);
    int rc;
    read(fd, &rc, sizeof(int));

    char msg[1024];

    for(int i=0; threads && i<vectorSize(threads); i++){
      supr_thread_t *th = (supr_thread_t *) vectorElementAt(threads, i);

      // msg_header?
      if(Supr_options.verbose || th->state != THREAD_STATE_TERMINATED){
        cmd = CLUSTER_INFO;
        write(fd, &cmd, sizeof(int));
        unsigned char buf[8]; 
        snprintf(buf, 8, "%s", msg_color); 
        write(fd, buf, sizeof(buf));
        int type = DEFAULT_INFO_TYPE;
        write(fd, &type, sizeof(int));
        int level = 0; // not used
        write(fd, &level, sizeof(int));

        sprintf(msg, "\033[0;33m%s:%d: %s, tid: %d, state: %s, \tname: %s\033[0m",
		    __FILE__, __LINE__, __func__, 
		    th->tid, state2char(th->state), th->name);
        ssize_t len_msg = strlen(msg)+1;
        write(fd, &len_msg, sizeof(ssize_t));
        write(fd, msg, len_msg);
        read(fd, &rc, sizeof(int));
      }

      if(th->state != THREAD_STATE_TERMINATED)
	     sleep(Supr_options.timeout);
      else {
	      void *ret_val;
	      pthread_join(th->ptid, &ret_val);
      }

    }

    cmd = CLUSTER_INFO;
    write(fd, &cmd, sizeof(int));
    unsigned char buf[8]; 
    snprintf(buf, 8, "%s", msg_color); 
    write(fd, buf, sizeof(buf));
    int type = DEFAULT_INFO_TYPE;
    write(fd, &type, sizeof(int));
    int level = 0; // not used
    write(fd, &level, sizeof(int));

    /*
    sprintf(msg, "\033[0;35m%s:%d: %s[%s], .., terminated\033[0m",
		    __FILE__, __LINE__, __func__, Supr_curStrError);
		    */
    sprintf(msg, "\033[0;35m%d %s[%s], ..., terminated\033[0m",
		    getpid(), __func__, Supr_curStrError);

    ssize_t len_msg = strlen(msg)+1;
    write(fd, &len_msg, sizeof(ssize_t));
    write(fd, msg, len_msg);
    read(fd, &rc, sizeof(int));

  } else {
    fprintf(stderr, "func: %s[%s], this tid: %ld, pid: %d ..., terminated",
		    __func__, Supr_curStrError,
		    syscall(SYS_gettid),  getpid());
  }

  doCleanups();
}




int isDCLInterrupted = FALSE;
int isDisconnected = FALSE;

size_t __dcl_read__(int fd, void *ptr, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /* else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(listenfd, &readfds) = %d\n", __func__,
               FD_ISSET(fd, &readfds));
      } */
    }

    int n = read(fd, ptr + len,  size - len);
    //printf("[%s] isDCLInterrupted = %d n = %d\n", __func__, isDCLInterrupted, n);
    if(isDCLInterrupted) {
//      isDCLInterrupted = FALSE;
    //  return -1;
	    // clean...???
      errorcall(R_NilValue, "interrupted");
    } else if(n == -1) {
      errorcall(R_NilValue, "SIGPIPE?");
    } else if(n == 0) {
      printf("[%s] disconnected\n", __func__);
      isDisconnected = TRUE;
      errorcall(R_NilValue, "disconnected");
    }
    //if(n == -1) errorcall(R_NilValue, "SIGPIPE?");
    len += n;
  }
  return len;
}

// testing
//extern size_t (*__read__)(int, void *, size_t);


#include <readline/readline.h>
#include <readline/history.h>

 
void  myR_SigactionDCLInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  //c_backtrace();

  //if(isDCLInterrupted) exit(1);
  fprintf(stderr, "\033[0;31m[%s] FIXME: EXIT (%s, %d)\033[0m\n", __func__,
           __FILE__, __LINE__);
//  exit(1);

//  char *line = readline (">>> ");
//  printf("%s\n", line);
//  int c;
//  read(3, &c, 1);


  isDCLInterrupted = TRUE;

  if(FALSE && __io__){
    int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
    shm_io_write(__io__, __io__->out, array, sizeof(array));
  }
//  errorcall(R_NilValue, "segmentation fault"); //??? FIXME
//  exit(1); // not good...

  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);

}

//int isTaskrunnerInterrupted = FALSE;

//extern int isInterrupted;

char interrupt_message_buf[256];

/*
void  myR_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
  //c_backtrace();

  isTaskrunnerInterrupted = TRUE;
  isInterrupted = TRUE;


  //if(R_oldactInt.sa_sigaction) R_oldactInt.sa_sigaction(sig, ip, context);
  //sigaction(SIGINT, &R_oldactInt, NULL);

  //errorcall(R_NilValue, msg); //??? FIXME
  //exit(1);
}
*/

/*
typedef struct tr_cntxt_struct {
  shm_io_info_t *io;
  int job_id;
  int tr_id;
  pid_t pid;
} tr_cntxt_t;

tr_cntxt_t tr_cntxt = {NULL, -1, -1, 0};
*/
extern tr_cntxt_t tr_cntxt;

char *cntxt2str(){
  char *s = malloc(256);
  sprintf(s, "\033[0;32mpid=%d, job_id=%d, tr_id=%d, %s\033[0m",
		  tr_cntxt.pid,  tr_cntxt.job_id,
		  tr_cntxt.tr_id, tr_cntxt.io->shm_info.shm_name);
  return s;
}

void  (*myTryEval_SigactionInt)(int sig, siginfo_t *ip, void *context) =NULL;

extern void sendDriverMessage(shm_io_info_t *io, int job_id, int tr_id, const char *msg);
extern void rjni_io_err_write(shm_io_info_t *io, const char *msg);

#define  BACKTRACE_SIZE 256
#include <execinfo.h>

char *myC_backtrace()
{
  void    *array[BACKTRACE_SIZE];
  int   size, i;
  char   **strings;

  size = backtrace(array, BACKTRACE_SIZE);
  strings = backtrace_symbols(array, size);

  int length = 0;
  for (i = 0; i < size; i++) //fprintf(stderr, "\033[0;32m%2d : %s\033[0m\n", i, strings[i]);
    length += strlen(strings[i]) + 1;
  
  char *str = (char*)malloc(length);
  char *s = str;
  for (i = 0; i < size; i++){
    memcpy(s, strings[i], strlen(strings[i]));
    s += strlen(strings[i]);
    *s = i== (size-1) ? 0 : '\n';
    s++;
  }

  free(strings);
  
  return str;
}

extern void  rjni_shm_io_state(shm_io_info_t *io, int *can_read, int *can_write);

char *myR_simpleTraceback();
//extern int isInterrupted;


/*
void  myR_SigactionTaskRunnerUsr2(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n",
		  __func__, pthread_self());
  //c_backtrace();

  isInterrupted = TRUE;

  int rc = sem_trywait(&__io__->err->sem_wr);
  fprintf(stderr, "\033[0;31m[%s] sem_trywait : %d\033[0m\n", __func__, rc);
  char *msg = "interrupted";
  if(rc == 0){
    msg = (char*) (__io__->err+1);
    msg[__io__->err->data_size-1] = 0;
    fprintf(stderr, "\033[0;31m[%s] message = %s\033[0m\n", __func__, msg);
    __io__->err->data_size = 0;
    sem_post(&__io__->err->sem_wr);
  }
  if(strlen(msg)==0) msg = "interrupted";
  int size = strlen(msg);
  if(sizeof(interrupt_message_buf)-1 < size)
	  size = sizeof(interrupt_message_buf)-1;
  memcpy(interrupt_message_buf, msg, size);
  interrupt_message_buf[size] = 0;

  
  kill(getpid(), SIGINT);

}
*/


/*
void  myTryEval_SigactionTaskRunnerInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>>>>>> %s <<<<<<<<<<<<<<<\033[0m\n",
		  __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());

  c_backtrace();

  int array[] = {TR_EXIT, TR_CANCELED}; // INTERRUPTED
  shm_io_write(__io__, __io__->out, array, sizeof(array));

  exit(1);
}
*/





/*
typedef struct shm_struct {
  size_t size;
  sem_t sem_w; // by java thread
  sem_t sem_r; // by java thread
} shm_struct_t;

typedef struct _shm_info {
  char *shm_name;
  void *mem_ptr;
} shm_info_t;
*/

//JNIEXPORT jlong JNICALL Java_RJNI_shmOpen (JNIEnv *javaEnv, jobject thisObj, jstring jshm_name)


typedef void (*sighandler_t)(int);

//this worked 
void myTryEval_SIGINT_handler(int sig){
  fprintf(stderr, "[%s] is called on %d\n", __func__, getpid()); 
  fprintf(stdout, "[%s] is called on %d\n", __func__, getpid()); 
}

//extern char *__r2str(SEXP x, char *buf, int buf_size, int debug);
char *__r2str(SEXP x, char *buf, int buf_size, int debug)
{ 
       	return NULL;
}

char *sexp2char(SEXP x)
{
   int buf_size = 128*200;
   char buf[buf_size];
   //char *s = __r2str(x, buf, buf_size, 0);
   char *s = __r2str(x, buf, buf_size, 0);
   char *c = malloc(strlen(s)+1);
   memcpy(c, s, strlen(s)+1);
   return c;
}

char *myR_simpleTraceback()
{
  RCNTXT *cntxt = R_GlobalContext;
  int len  = 0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    len += strlen(c)+1+1+32;
    fprintf(stderr, "cntxt = %p: %s\n", cntxt, c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  char *str = malloc(len);
  char *s = str;
  cntxt = R_GlobalContext;
  int i=0;
  while(cntxt){
    SEXP call = cntxt->call;
    char *c = sexp2char(call);
    if(i){ *s ='\n'; s++;}

    char b[16];
    sprintf(b, "%d: ", i++);
    memcpy(s, b, strlen(b));
    s += strlen(b);

    memcpy(s, c, strlen(c));
    s += strlen(c);
    free(c);
    cntxt = cntxt->nextcontext;
  }
  *s = 0;
  return str;
}


//extern int R_PPStackTop
//extern const char *R_curErrorBuf();
SEXP R_myTryEval(SEXP expr, SEXP env, int *errorOccurred)
{
#define R_ToplevelContext __R_ToplevelContext
#define null R_NilValue
//#define SETJMP(x) setjmp(x)

  static RCNTXT *__R_ToplevelContext = NULL;
  if(!__R_ToplevelContext){
    __R_ToplevelContext  = R_GlobalContext;
    while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;
  } 


#ifdef __USE_SIGINT__
  struct sigaction save_sigaction;
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionTaskRunnerInt;
    sa.sa_sigaction = myTryEval_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, &save_sigaction);
  }
#endif

  R_isInterrupted = FALSE;

  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  int save = R_PPStackTop;

  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));


  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    *errorOccurred = FALSE;

    if(!setjmp(R_ToplevelContext->cjmpbuf)) {

      val = eval(expr, env);
      UNPROTECT(1);

    } else {

      *errorOccurred = TRUE;
      const char *errbuf = R_curErrorBuf();
      if(strlen(errbuf) == 0 && R_isInterrupted) {
        //val = mkString("interrupted");
        val = mkString(interrupt_message_buf);
      } else
        val = mkString(errbuf);

    }

  endcontext(&cntxt);

#ifdef __USE_SIGINT__
  sigaction(SIGINT, &save_sigaction, NULL);
#endif

  //UNPROTECT(1);

  if(save != R_PPStackTop) {
    fprintf(stderr, "Warning (%s, %d): save = %d, R_PPStackTop = %d\n", 
		    __FILE__, __LINE__, save, R_PPStackTop);
  }

  return val;



//#undef SETJMP(x) 
#undef null
#undef R_ToplevelContext
}

extern int R_SignalHandlers;
void testing(int argc, char **argv){

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  {
    Rf_initialize_R(new_argc, new_argv);
    void *dummy;
    R_CStackStart = (unsigned long) &dummy;
    //printf("R_CStackStart = %ld\n", R_CStackStart);
    //printf("R_CStackLimit = %ld\n", R_CStackLimit);
    R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
    setup_Rmainloop();
  }

 
  /*
  {
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));

    int errorOccurred;
    printf("OKAY??\n");
    SEXP value = R_myTryEval(expr, R_GlobalEnv, &errorOccurred);
    printf("OKAY\n");
  }


  RCNTXT *__R_ToplevelContext  = R_GlobalContext;
  while(__R_ToplevelContext->nextcontext)
      __R_ToplevelContext = __R_ToplevelContext->nextcontext;

  printf("R_ToplevelContext>handlerstack:\n");
  PrintValue(__R_ToplevelContext->handlerstack);

#define R_ToplevelContext __R_ToplevelContext

  printf("R_ToplevelContext = %p\n", R_ToplevelContext);
  printf("R_GlobalContext   = %p\n", R_GlobalContext);
  printf("R_SignalHandlers   = %d\n", R_SignalHandlers);
  */
  //SETJMP(R_Toplevel.cjmpbuf);
/*
Defn.h:# define SIGSETJMP(x,s) sigsetjmp(x,s)
Defn.h:# define SETJMP(x) sigsetjmp(x,0)
Defn.h:# define SIGSETJMP(x,s) setjmp(x)
Defn.h:# define SETJMP(x) setjmp(x)
*/
//# define SETJMP(x) setjmp(x)
//  SETJMP(R_ToplevelContext->cjmpbuf);

  /*
  SETJMP(R_Toplevel.cjmpbuf);
    R_GlobalContext = R_ToplevelContext = R_SessionContext = &R_Toplevel;
    */
#define null R_NilValue
  /*
  RCNTXT *globalContext = R_GlobalContext;
  SEXP val = null;

  SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
  SEXP env = R_GlobalEnv;



  RCNTXT cntxt;
  SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

//  int count = 0;

  begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

//    int succeeded = FALSE;
    if(!setjmp(R_ToplevelContext->cjmpbuf))
    //if(!setjmp(cntxt.cjmpbuf))
    {
      PrintValue(syscall);
   //   count++; if(count ==5) exit(1);
      printf("\033[0;31m%s: PrintValue\033[0m\n", __func__);
      val = PROTECT(eval(expr, env));
//      succeeded = TRUE;
    } else {
      val = PROTECT(mkString("pthread_error")); // to do
      setAttrib(val, install("class"), mkString("pthread_error"));
      PrintValue(val);
      printf("\033[0;35m%s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

  endcontext(&cntxt);
  */

  //exit(1);


  while(TRUE){

	  /*
    RCNTXT cntxt;
    SEXP expr = PROTECT(LCONS(install("sstop"),
			    CONS(mkString("testing"), R_NilValue)));
    SEXP env = R_GlobalEnv;
    SEXP syscall = PROTECT(LCONS(install("eval"), CONS(expr, CONS(env, null))));

    begincontext(&cntxt, CTXT_RETURN, syscall, env, env, null, null);

    if(!setjmp(R_ToplevelContext->cjmpbuf))
    {
    */
        int errorOccurred;
        SEXP envir = R_GlobalEnv;
        SEXP expr = PROTECT(LCONS(install("stop"),
			    CONS(mkString("ERROR: TESTING"), R_NilValue)));
        SEXP res = PROTECT(R_myTryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(R_tryEval(expr, envir, &errorOccurred));
        //SEXP res = PROTECT(eval(expr, envir));
	printf("errorOccurred = %d\n", errorOccurred);
	if(errorOccurred)
	  fprintf(stderr, "\033[0;31m%s\033[0m", CHAR(STRING_ELT(res, 0)));
	else
          PrintValue(res);

	/*
    } else {
      printf("\033[0;35m[Error] %s: R_GlobalContext (%p) = globalContext (%p)?\033[0m\n",
		      __func__, R_GlobalContext, globalContext);
    }

    endcontext(&cntxt);
#undef null
*/

    //sleep(10);
  }

  //if(R_Interactive) run_Rmainloop();

  exit(1);
}

/*
typedef struct shm_data_header {
  int type;
  int padding;
  size_t size;
} shm_data_header_t;
*/
// Cluster.java:
#define TASK_RESULTS 303
#define TASK_EXIT    304

int  tr_get_shm_identityCode()
{
  static int code = 0;
  fprintf(stderr, "code = %d\n", code); 
  return code++;
}

static size_t __page_size__ = 0;
#define SHM_BLOCK_SIZE (2*__page_size__)

static socket_conn_t *__socket_conn__ = NULL;

extern SEXP SUPR_socketConnect(SEXP hostname, SEXP port, SEXP endian_str); 
extern SEXP SUPR_socketWrite(SEXP conn, SEXP x, SEXP endian_str);
extern SEXP SUPR_socketRead(SEXP conn, SEXP what, SEXP _n, SEXP endian_str); 
extern SEXP SUPR_socketReadObject(SEXP conn, SEXP env); 
extern SEXP SUPR_socketClose(SEXP conn); 
extern SEXP socketReadDCLEvent(SEXP socket_conn, SEXP env);

/*
void  dcl_error(const char *driver_host, int driver_port, int job_id,
	       	const char *msg, SEXP env)
{
  printf("%s: driver_host=%s\n", __func__, driver_host);
  printf("%s: driver_port=%d\n", __func__, driver_port);
  printf("%s: msg=%s\n", __func__, msg);

  SEXP host   = PROTECT(mkString(driver_host));
  SEXP port   = PROTECT(ScalarInteger(driver_port));
  SEXP endian = PROTECT(mkString("big"));
  SEXP conn   = PROTECT(SUPR_socketConnect(host, port, endian)); 

  SEXP x  = PROTECT(ScalarInteger(DCL_JOB_ERROR));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(ScalarInteger(job_id));
  SUPR_socketWrite(conn, x, R_NilValue);

  x  = PROTECT(mkString(msg));
  SUPR_socketWrite(conn, x, R_NilValue);

  SEXP ret  = SUPR_socketReadObject(conn, env); 
  UNPROTECT(7);


  printf("[%s] return\n", __func__);
  PrintValue(ret);

}
*/


/*
typedef struct sync_info_struct {
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  void (*run)(void *data);
  void *data;
  sem_t           sem_wait;
  sem_t           sem_notify;
} sync_info_t;
*/


void *rjni_shm_open(const char *cshm_name, size_t *size);

#include "util.h"

extern int SocketConn_reuseAddr;
extern supr_socket_conn_t *serverSocketOpen(int port, int reuse_addr);
extern supr_socket_conn_t *serverSocketAccept(supr_socket_conn_t *serverConn);


size_t __read__(int fd, void *buf, size_t size)
{
  size_t len = 0;
  for(; len < size; ){

    {
      struct timeval tv;
      fd_set readfds;

      tv.tv_sec=10;
      tv.tv_usec=50000;

      FD_ZERO(&readfds);
      FD_SET(fd, &readfds);

      int ns = select(fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) continue;
      } 
    }

    int n = read(fd, buf + len,  size - len);

    if(n <= 0){
	    printf("[%s] read, n = %d, %s\n", __func__, n, strerror(errno));
	    return -1;
//	    errorcall(null, "read, n = %d, %s", n, strerror(errno));
    }

    /*  n = -1: If no messages are available at the socket, the receive calls wait  for
       a  message  to arrive, unless the socket is nonblocking (see fcntl(2)),
       in which case the value -1 is returned and the external variable  errno
       is set to EAGAIN or EWOULDBLOCK.  The receive calls normally return any
       data available, up to the requested amount,  rather  than  waiting  for
       receipt of the full amount requested.
       */

    len += n;
  }
}

#define R_SERIALIZED_OBJECT 171117121
//#define R_SERIALIZED_OBJECT 825768241

supr_socket_conn_t *workerServerConn = NULL;
supr_socket_conn_t *driverServerConn = NULL;

void handleClusterGet(supr_socket_conn_t *conn)
{
  fprintf(stderr, "[%s] conn: <%p>, Start\n", __func__, conn);
  int fd = conn->fd;
  int cmd, remove, len;
  read(fd, &cmd, sizeof(int));
  read(fd, &remove, sizeof(int));
  read(fd, &len, sizeof(int));

  fprintf(stderr, "[%s] remove: %d len: %d\n", __func__, remove, len);

  char data_name[len];
  read(fd, data_name, len);
  fprintf(stderr, "[%s] date_name: %s\n", __func__, data_name);
  // try globalEnvironment ...
  // try shm
  size_t size;
  //assuming it is a so_t object
  void *mem_ptr = rjni_shm_open(data_name, &size); // fixme?
  fprintf(stderr, "[%s] mem_ptr = %p, data_name: %s\n", __func__, mem_ptr,
		  data_name);
  if(!mem_ptr) {
    so_t so = {0, 0, 0, SUPR_UNBOUND_VALUE, 0};
    write(fd, &so, sizeof(so_t));

  } else {
    write(fd, mem_ptr, size);
    munmap(mem_ptr, size);
    if(remove)
      shm_unlink(data_name);
  }
  fprintf(stderr, "[%s] conn: <%p> Return\n", __func__, conn);
  
}

extern const char *cmd2char(int cmd);
void __DD_sendInfo(const char *msg, int level, int line);

#define DD_sendInfo(msg, level) __DD_sendInfo((msg), (level), __LINE__)

#define read(fd, buf, size) __read__((fd), (buf), (size))

#define DFS_DD_WAIT

void DD_checkDevice()
{
  char path[PATH_MAX];
  getcwd(path, PATH_MAX);
  struct stat sb;
  int rc;

  rc = stat("/", &sb);
  if(rc == -1) return;
  printf("\n[%s] path: / st_dev: %ld\n", __func__, sb.st_dev);

  dev_t root_dev = sb.st_dev;

  rc = stat(path, &sb);
  if(rc == -1) return;
  printf("[%s] path: %s st_dev: %ld\n", __func__, path, sb.st_dev);

  dev_t current_dev = sb.st_dev;

  if(sb.st_dev != root_dev){
    char *p = path + strlen(path);
    for(; p != path; p--){
      if(*p == '/'){
        char* change_point = p+1;
        *p = 0;
        rc = stat(path, &sb);
        if(rc == -1) return;
        printf("[%s] path: %s st_dev: %ld\n", __func__, path, sb.st_dev);
	if(sb.st_dev != current_dev){
          printf("\033[0;32m[%s] Change point: %s\033[0m\n", __func__,
			  change_point);
	}
        current_dev = sb.st_dev;
      }
    }
  }

}



char *DD_infoInit(){
  char path[PATH_MAX];
  getcwd(path, PATH_MAX);

  char *init_msg = (char *)malloc(strlen(path)+1); 
  memcpy(init_msg, path, strlen(path)+1);

  struct stat sb;
  int rc;

  rc = stat("/", &sb);
  if(rc == -1) return strdup(strerror(errno));
  printf("\n[%s] path: / st_dev: %ld\n", __func__, sb.st_dev);

  dev_t root_dev = sb.st_dev;

  rc = stat(path, &sb);
  if(rc == -1) return strdup(strerror(errno));
  printf("[%s] path: %s st_dev: %ld\n", __func__, path, sb.st_dev);

  dev_t current_dev = sb.st_dev;

  if(sb.st_dev != root_dev){
    char *p = path + strlen(path);
    char *q = init_msg + strlen(init_msg);
    for(; p != path; p--, q--){
      if(*p == '/'){
        char* change_point = p+1;
        *p = 0;
        rc = stat(path, &sb);
        if(rc == -1) return strdup(strerror(errno));

        printf("[%s] path: %s st_dev: %ld\n", __func__, path, sb.st_dev);
	if(sb.st_dev != current_dev){
          printf("\033[0;32m[%s] Change point: %s\033[0m\n", __func__,
			  change_point);
	  *q = '*';
	}
        current_dev = sb.st_dev;
      }
    }
  }

  return init_msg;

}



void handleDD_create(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  {
    DD_checkDevice();
  }

  int rc = __mkdir__(dd_name);

#ifdef DFS_DD_WAIT
  cmd = DFS_DD_CREATE_RETURN;
  write(fd, &cmd, INT_SIZE);
  SocketConn_writeString(conn, dd_name);
  SocketConn_writeInt(conn, rc);
  
  if(rc ==  -1){
    SocketConn_writeString(conn, strerror(errno));

    DD_sendInfo(strerror(errno), 0);
  } else {

    dd_t *dd = newDD(dd_name);
    Hashtable_put(ddEnvironment, dd_name, dd);
  }
#else
  SocketConn_writeInt(conn, rc);

  if(rc ==  -1){ //writeError(fd, strerror(errno));
    fprintf(stderr, "Error: %s\n", strerror(errno));
    SocketConn_writeString(conn, strerror(errno));

    DD_sendInfo(strerror(errno), 0);
  } else {

    dd_t *dd = newDD(dd_name);
    Hashtable_put(ddEnvironment, dd_name, dd);
  }
#endif

}

extern int __rm_recursive__(const char *pathname); // dd.c

void handleDD_remove(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd, &cmd, INT_SIZE);
  char *name = SocketConn_readString(conn, NULL, 0);

  int recursive;
  read(fd, &recursive, INT_SIZE);

#ifdef USE_MULTI_DIRS

  int rc;
  for(int dir_idx = 0; dir_idx < DD_DIR_LENGTH; dir_idx ++){
    char pathname[PATH_MAX];
    sprintf(pathname, "%s/data/%s", DD_DIR_PATH(dir_idx), name);

    struct stat sb;
    rc = stat(pathname, &sb);
    if(rc == -1) break;

    if(recursive) {
      rc = __rm_recursive__(pathname);
    } else if(S_ISDIR(sb.st_mode)) {
      rc = rmdir(pathname);
    } else {
      rc = unlink(pathname);
    }

    if(rc == -1) break;
  }

#else

  int rc = __rmdir__(name, recursive);

#endif

  write(fd, &rc, INT_SIZE);
  if(rc == -1) {
    SocketConn_writeString(conn, strerror(errno));
  }

  Hashtable_delete(ddEnvironment, name);

  free(name);
}

void handleDD_move(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  /*
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);
  */
  char *dd_name = SocketConn_readString(conn, NULL, 0);

  printf("[%s] dd_name: %s\n", __func__, dd_name);
  char *src  = SocketConn_readString(conn, NULL, 0);
  char *dest = SocketConn_readString(conn, NULL, 0);
  printf("[%s] src: %s\n", __func__, src);
  printf("[%s] dest: %s\n", __func__, dest);

#ifdef USE_MULTI_DIRS

  int rc;
  for(int dir_idx = 0; dir_idx < DD_DIR_LENGTH; dir_idx ++) {
    char old[PATH_MAX], new[PATH_MAX];
    char *dir_path = DD_DIR_PATH(dir_idx);
    sprintf(old, "%s/data/%s", dir_path, src);
    sprintf(new, "%s/data/%s", dir_path, dest);
    rc = rename(old, new);
    if(rc == -1) 
      break;
  }

#else

  char old[strlen(src)+strlen("data/")+1];
  char new[strlen(dest)+strlen("data/")+1];
  sprintf(old, "data/%s", src);
  sprintf(new, "data/%s", dest);
  {
    char buf[PATH_MAX];
    getcwd(buf, PATH_MAX);
    printf("[%s] cwd: %s\n", __func__, buf);
  }

  int rc = rename(old, new);

#endif

  /*
  cmd = DFS_DD_MOVE_RETURN;
  SocketConn_writeInt(conn, cmd);
  SocketConn_writeString(conn, dd_name);
  */

  SocketConn_writeInt(conn, rc);

  if(rc ==  -1){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    SocketConn_writeString(conn, strerror(errno));
  } 

  free(dd_name);
  free(src);
  free(dest);
}

extern void DD_destroy(dd_t *dd);

static supr_thread_t *DT_thread = NULL;

void DT_thread_init(void *arg)
{
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,
                  (unsigned long) &sem);
  *sth = th;

  free(th->name);
  char name[256];
  sprintf(name, "DT.%d", gettid());
  th->name = strdup(name);
  th->state = THREAD_STATE_RUNNABLE;

  /*
  pthread_mutex_lock(sys_threads->mutex);
    vectorAdd(sys_threads, th);
  pthread_mutex_unlock(sys_threads->mutex);
  */

  pthread_setspecific(currentThreadKey, th);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);
}

void DT_thread_cleanup(void *data)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}

void handleDDT_call(void *data); // FIXME

void *DT_thread_run(void *arg)
{
  pthread_cleanup_push(DT_thread_cleanup, NULL);

  void *data = (void *) ((void **)arg)[0];
  supr_socket_conn_t *sc = (supr_socket_conn_t *) data;
  //basic_info("sc: '%s:%d'", sc->host, sc->port);
  // init:
  DT_thread_init(arg);
  //basic_info("DT_thread is ready ...");

  handleDDT_call(data);

  /*
  supr_thread_t *cth = SUPR_CURRENT_THREAD();

  // loop
  while(TRUE){
    basic_info("Next tasks ...");
    while(TRUE){
      DT_thread_task_t *task = NULL;
      pthread_mutex_lock(DT_thread_tasks->mutex);
        if(vectorSize(DT_thread_tasks))
          task = (DT_thread_task_t *) vectorRemove(DT_thread_tasks,0);
      pthread_mutex_unlock(DT_thread_tasks->mutex);
      if(task == NULL) break;

      BEGIN_R_EVAL();
        Rboolean success = R_ToplevelExec(task->fun, task->data);
        if(!success)
              error_info(R_curErrorBuf());
      END_R_EVAL();
      free(task);
    }

    pthread_mutex_lock(&cth->mutex);
      int rc = pthread_cond_wait(&cth->cond, &cth->mutex);
    pthread_mutex_unlock(&cth->mutex);
  }
  */


  pthread_cleanup_pop(TRUE);
  return NULL;
}

supr_thread_t *startDT_thread(supr_socket_conn_t *sc)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {sc, &sem, &sth};
  int rc = pthread_create(&thread, NULL, DT_thread_run, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);

  return sth;
}


extern SEXP Rf_deparse1m(SEXP call, Rboolean abbrev, int);
// from Defn.h
#define DEFAULTDEPARSE          1089
//extern void writeError(int fd, const char* err);
void writeError(int fd, const char* err){
    int rc = -1;
    write(fd, &rc, INT_SIZE);
    size_t len = strlen(err)+1;
    write(fd, &len, SIZE_SIZE);
    write(fd, err, len);
}

extern int suffix2type(const char *suffix);
extern SEXP DD_getDefaultRFuncBySuffix(const char *suffix);


/*
#define _GNU_SOURCE
#define __USE_GNU
#include <dlfcn.h>

#define caller_info(which)        \
do {    \
   Dl_info __info__;    \
   int __rc__ = dladdr(__builtin_return_address(which), &__info__);     \
   if(__rc__)   \
     basic_info("\033[0;32mdli_sname: %s\033[0m", __info__.dli_sname);      \
} while (0)
*/


static void Check_deparse2(SEXP x, int line)
{
//   caller_info(1);
//   caller_info(2);
	if(strstr(Supr_hostname, "liu2")) return; 
      SEXP expr = Rf_deparse1m(x, 0, DEFAULTDEPARSE);
      //basic_info("typeof(expr): %s", type2char(TYPEOF(expr)));
      //basic_info("deparsed expr: \"%s\"", CHAR(asChar(expr)));
      //basic_info("length(expr): %d", LENGTH(expr));
      for(int i=0; i<LENGTH(expr); i++){
        basic_info("[\033[0;34m%d\033[0m] [%d]: %s", line, i+1,
		       	CHAR(STRING_ELT(expr, i)));
	if(i>=4) {
          basic_info("...");
	  break;
	}
      }
}
#define Check_deparse(x) Check_deparse2((x), __LINE__)

void List_defineVar(SEXP S_name, SEXP value, SEXP list)
{
  SEXP s = list;
  const char *name = CHAR(PRINTNAME(S_name));
  while(CDR(s) != R_NilValue){
    SEXP t = CDR(s);
    if(strcmp(name, CHAR(PRINTNAME(TAG(t))))==0){
	    SETCAR(t, value);
	    return;
    }
    s = t;
  }

  SETCDR(s, CONS(value, R_NilValue));
  SET_TAG(CDR(s), S_name);
}

SEXP List_findVar(SEXP S_name, SEXP list)
{
  SEXP s = CDR(list);
  const char *name = CHAR(PRINTNAME(S_name));
  while(s != R_NilValue){
    if(strcmp(name, CHAR(PRINTNAME(TAG(s))))==0) return CAR(s);
    s = CDR(s);
  }

  return R_UnboundValue;
}

void DDT_checkUserInterrupt()
{
  int isInterrupted;
  pthread_mutex_lock(&Supr_syncMutex);
    isInterrupted = DDT_isCancelled;
    DDT_isCancelled = FALSE;
  pthread_mutex_unlock(&Supr_syncMutex);
  if(isInterrupted)
    error(_("interrupted"));
}

void DDT_exec(void *data)
{
  SEXP call = (SEXP) ((void**)data)[0];
  SEXP x = (SEXP) ((void**)data)[1];
  SEXP cntxt_env = (SEXP) ((void**)data)[2];
  SEXP args = CDDR(call);
  SEXP env = args;
  for(int i=0; i<3; i++){
    if(env == R_NilValue) break;
    env = CDR(env);
  }
  env = CAR(env);
  if(TYPEOF(env) != ENVSXP){
    error_info("obbject 'env' not found, FIXME");
    error(_("object 'env' not found"));
  }

  int nUNPROTECT = 0;

  //
  if(TYPEOF(x) != VECSXP){
    switch(TYPEOF(x)){
      case INTSXP:
      case REALSXP:
      case STRSXP:
      case LGLSXP:
	      {
		      SEXP y = PROTECT(allocVector(VECSXP,1));
		      nUNPROTECT ++;
		      SET_VECTOR_ELT(y, 0, x);
		      x = y;
		      setAttrib(x, R_NamesSymbol, mkString("V.1"));
	      }
	      break;
      default: error(_("expected a DDT object"));
	       break;
    }
  }

  SET_ENCLOS(env, SuprEnv);

  // i:
  if(CAR(args) != R_NilValue){
    SEXP row_call = PROTECT(LCONS(install("with"), CONS(x, CONS(CAR(args),
					    R_NilValue))));
    SEXP row = eval(row_call, env);

    PROTECT_INDEX row_pi;
    PROTECT_WITH_INDEX(row, &row_pi);
    nUNPROTECT += 2;

    if(TYPEOF(row) != NILSXP) {
       if(TYPEOF(row) == LGLSXP) {
	     int n = LENGTH(row), m = 0;
	     if(LENGTH(x)==0 || n != LENGTH(VECTOR_ELT(x,0)))
		     error(_("dimensions don't match"));

             int *lgl_idx = LOGICAL(row);
	     for(int i=0; i<n; i++) m += lgl_idx[i]; 
	     SEXP idx = PROTECT(allocVector(INTSXP, m));
	     int *val = INTEGER(idx);
	     m = 0;
	     for(int i=0; i<n; i++)
	       if(lgl_idx[i]) val[m++] = i;
	     row = idx;
	     REPROTECT(row, row_pi);
	     UNPROTECT(1);
      }

      if(TYPEOF(row) == INTSXP){
        setAttrib(x, install("row.names"), R_NilValue);
	int m = LENGTH(row);
	int *idx = INTEGER(row);
        for(int j=0; j < LENGTH(x); j++){
	  SEXP y = VECTOR_ELT(x, j);
	  switch(TYPEOF(y)){
	   case REALSXP:
	        {
	          SEXP z = PROTECT(allocVector(REALSXP, m));
	          double *y_val = REAL(y);
	          double *z_val = REAL(z);
		  int k = 0;
		  for(int i=0; i<m; i++) z_val[i] = y_val[idx[i]];
		  SET_VECTOR_ELT(x, j, z);
		  UNPROTECT(1);
	      	}
		break;

	   case LGLSXP:
	   case INTSXP:
	        {
	          SEXP z = PROTECT(allocVector(INTSXP, m));
	          int *y_val = INTEGER(y);
	          int *z_val = INTEGER(z);
		  int k = 0;
		  for(int i=0; i<m; i++) z_val[i] = y_val[idx[i]];
		  SET_VECTOR_ELT(x, j, z);
		  UNPROTECT(1);
	      	}
		break;

	   case STRSXP:
	        {
	          SEXP z = PROTECT(allocVector(STRSXP, m));
		  for(int i=0; i<m; i++) 
		    SET_STRING_ELT(z, i, STRING_ELT(y, idx[i]));
		  SET_VECTOR_ELT(x, j, z);
		  UNPROTECT(1);
	      	}
		break;

	   default:
		{
		  error_info("FIXME, TODO");
		  error(_("Not implemented"));
		}
		break;
	  }
	}
      } else {
	      error(_("invalid row indices"));
      }
    }
  }

  // j:
  args = CDR(args);
  if(CAR(args) != R_NilValue){
    SEXP col_call = PROTECT(LCONS(install("with"), CONS(x, CONS(CAR(args),
					    R_NilValue))));
    SEXP col = eval(col_call, env);
    PROTECT_INDEX col_pi;
    PROTECT_WITH_INDEX(col, &col_pi);
    nUNPROTECT += 2;

    if(TYPEOF(col) != NILSXP) {
      if(TYPEOF(col) == LGLSXP) {
	     int n = LENGTH(col), m = 0;
	     if(n != LENGTH(x)) error(_("dimensions don't match"));

             int *lgl_idx = LOGICAL(col);
	     for(int i=0; i<n; i++) m += lgl_idx[i]; 
	     SEXP idx = PROTECT(allocVector(INTSXP, m));
	     int *val = INTEGER(idx);
	     m = 0;
	     for(int i=0; i<n; i++)
	       if(lgl_idx[i]) val[m++] = i;
	     col = idx;
	     REPROTECT(col, col_pi);
	     UNPROTECT(1);
      } else if(TYPEOF(col) == STRSXP) {
	     int n = LENGTH(x), m = LENGTH(col);

	     SEXP idx = PROTECT(allocVector(INTSXP, m));
	     for(int i=0; i<m; i++) {
	       INTEGER(idx)[i] = -1;
               const char *c = CHAR(STRING_ELT(col, i));
	       for(int j=0; j<n; j++) {
                 if(strcmp(c, CHAR(STRING_ELT(x, j)))==0){
			 INTEGER(idx)[i] = j;
			 break;
		 }
	       }
	       if(INTEGER(idx)[i] == -1)
		       error(_("variable '%s' not found"), c);
	     }
	     col = idx;
	     REPROTECT(col, col_pi);
	     UNPROTECT(1);
      }

      if(TYPEOF(col) == INTSXP){
        SEXP x_names = getAttrib(x, R_NamesSymbol); // check names ...
	SEXP y = PROTECT(allocVector(VECSXP, LENGTH(col)));
	SEXP names = PROTECT(allocVector(STRSXP, LENGTH(col)));
	setAttrib(y, R_NamesSymbol, names);
	int *idx = INTEGER(col);
        nUNPROTECT ++;
        for(int i=0; i < LENGTH(col); i++) {
          SET_VECTOR_ELT(y, i, VECTOR_ELT(x, idx[i]));
	  if(x_names != R_NilValue)
            SET_STRING_ELT(names, i, STRING_ELT(x_names, idx[i]));
	  else {
	    char buf[64];
	    sprintf(buf, "V.%d", i+1);
            SET_STRING_ELT(names, i, mkChar(buf));
	  }
	}
	//
	//setAttrib(y, install("row.names"), getAttrib(x,install("row.names")));
	//
        x = y; 

      } else if(TYPEOF(col) == VECSXP){
        int m;
        SEXP names = getAttrib(col, R_NamesSymbol); // check names ...
        for(int j=0; j < LENGTH(col); j++){
          SEXP y = VECTOR_ELT(col, j);
          if(j==0) m = LENGTH(y);
	  else if(m != LENGTH(y)){
	    error(_("dimenssions don't match"));
	  }
        }
        x = col; 
      } else {
	      error(_("invalid row indices"));
      }

    }
    //nUNPROTECT += 2;
  }

  setAttrib(x, R_ClassSymbol, mkString("DD.frame")); 
  // group: CHANGE IT TO combine
  args = CDR(args);
  if(CAR(args) == R_NilValue){

    //basic_info("3. typeof(x[or value]): %s", type2char(TYPEOF(x)));

    SEXP frame = List_findVar(install("frame"), cntxt_env);
    if(frame == R_UnboundValue) {
      frame = PROTECT(CONS(x, R_NilValue));
      List_defineVar(install("frame"), frame, cntxt_env);
      UNPROTECT(1);
    } else {
      SEXP s = frame;
      while(CDR(s) != R_NilValue) s = CDR(s);
      SETCDR(s, CONS(x, R_NilValue));
    }

  } else {
    SEXP expr = CAR(args);
//    basic_info("\033[0;35mgroup. typeof(group expr): %s\033[0m", type2char(TYPEOF(expr)));
//    Check_deparse(expr);

    if(TYPEOF(expr) == SYMSXP || TYPEOF(expr) == STRSXP){
      const char *fun_name = TYPEOF(expr) == SYMSXP ?  CHAR(PRINTNAME(expr)):
              CHAR(STRING_ELT(expr,0));
      expr = PROTECT(LCONS(install(fun_name), R_NilValue));
      nUNPROTECT ++;
    } else if(TYPEOF(expr) == CLOSXP) { // testing ...
      expr = PROTECT(LCONS(expr, R_NilValue)); 
      nUNPROTECT ++;
//      basic_info("group. typeof(expr[?call]): %s", type2char(TYPEOF(expr)));
    } else if(TYPEOF(expr) == LANGSXP) {
      SEXP fun = CAR(expr);
//      basic_info("group. typeof(fun[????]): %s", type2char(TYPEOF(fun)));
      if(TYPEOF(fun) == SYMSXP) {
//        basic_info("\033[0;32mgroup. typeof(fun[????]): symbol=%s\033[0m", CHAR(PRINTNAME(fun)));
//        Check_deparse(fun);
	// function(){}() doesn't work, but (function(){})() ...
	if(strcmp(CHAR(PRINTNAME(fun)), "function")==0){
          expr = PROTECT(LCONS(expr, R_NilValue)); 
          nUNPROTECT ++;
	}
      }
    } else 
      error(_("invalid 'group' argument"));

    //if(TYPEOF(expr) == LANGSXP){

      SEXP v = List_findVar(install(".group..value"), cntxt_env);
      if(v == R_UnboundValue) v = R_NilValue;

      SEXP args = CDR(expr);
    
      SEXP y = PROTECT(CONS(x, CONS(v, R_NilValue)));
      SET_TAG(y, install("x"));
      SET_TAG(CDR(y), install("value"));
      setAttrib(y, R_ClassSymbol, mkString("DD.frame")); // the class of x
     
      SEXP new_expr = PROTECT(LCONS(CAR(expr), CONS(y, args)));
      SEXP g_call = PROTECT(LCONS(install("with"), CONS(x, CONS(new_expr,
					    R_NilValue))));

    //Check_deparse(new_expr);

      SEXP g = PROTECT(eval(g_call, env));

      //Check_deparse(expr);
      //basic_info("typeof(group): %s", type2char(TYPEOF(g)));
      x = g;
      setAttrib(x, R_ClassSymbol, mkString("DD.value")); // the class of x
      List_defineVar(install(".group..value"), x, cntxt_env);
      //Check_deparse(g);
      nUNPROTECT += 4;
    //}
//    fprintf(stdout, "After 3:\n");
//    PrintValue(x);
  }
//  basic_info("OKAY 4");


  if(Supr_options.verbose) {
    SEXP res = PROTECT(CONS(x, R_NilValue));
    SET_TAG(res, install("value"));
    Check_deparse(res);
    UNPROTECT(1);
  }

  ((void**)data)[1] = x;
  UNPROTECT(nUNPROTECT);

  DDT_checkUserInterrupt();
}


void __handleDDT_call(supr_socket_conn_t *conn)
{
  pthread_mutex_lock(&Supr_syncMutex);
     DDT_isCancelled = FALSE;
  pthread_mutex_unlock(&Supr_syncMutex);

  static unsigned long count = 0;

  int fd = conn->fd;
  int cmd = -1;
  read(fd,  &cmd, INT_SIZE);

  if(cmd == CLUSTER_PING){
    cmd = CLUSTER_PONG;
    write(fd,  &cmd, INT_SIZE);
    return;
  } else if(cmd != DFS_DDT_CALL){
    error_info("cmd: %d != DFS_DDT_CALL: %d", cmd, DFS_DDT_CALL);
    close(fd);
    free(conn);
    pthread_exit(NULL);
  }

  char var_name[256];
  int var_len = 0;
  int rc = 0;
  SEXP array = R_NilValue;

  //int ssave_R_PPStackTop = R_PPStackTop;

  Rboolean success;
  BEGIN_R_EVAL();
    //ssave_R_PPStackTop = R_PPStackTop;
    int len; read(fd, &len, INT_SIZE);
    SEXP raw = PROTECT(allocVector(RAWSXP, len));
    read(fd, RAW(raw), len);
    write(fd,  &cmd, INT_SIZE);
    /*
    { // testing...
      nbytes = LENGTH(raw);
      bytes = malloc(nbytes);
      memcpy(bytes, RAW(raw), nbytes);
    }
    */
    success = R_ToplevelExec(Supr_unserialize1, &raw);
    if(success) {
      PROTECT(raw);
      //basic_info("typeof(expr): %s",type2char(TYPEOF(raw)));
      UNPROTECT(1);
    }
    sprintf(var_name, ".__DT.Call.%ld__.", count);
    verbose_info("var_name: %s", var_name);
    defineVar(install(var_name), raw, SuprJobEnv);
    UNPROTECT(1);

    SEXP dt_call = raw;
    if(dt_call != R_UnboundValue){
      /*SEXP expr = Rf_deparse1m(dt_call, 0, DEFAULTDEPARSE);
      basic_info("typeof(expr): %s", type2char(TYPEOF(expr)));
      basic_info("deparsed expr: \"%s\"", CHAR(asChar(expr)));
      basic_info("length(expr): %d", LENGTH(expr));
      for(int i=0; i<LENGTH(expr); i++){
        basic_info("[%d]: %s", i+1, CHAR(STRING_ELT(expr, i)));
      }
      */

      // Rinternals.h:SEXP       Rf_lcons(SEXP, SEXP);
      SEXP s =  dt_call;
      int n=0;
      while(TYPEOF(s) == LANGSXP){
        n++;
        //basic_info("[%d] LANGSXP: `%s` with args:", n, TYPEOF(CAR(s))==SYMSXP?  CHAR(PRINTNAME(CAR(s))):"?");
        SEXP args = CDR(s);
        /*
        SEXP expr = Rf_deparse1m(args, 0, DEFAULTDEPARSE);
        for(int i=0; i<LENGTH(expr); i++){
          basic_info("[%d]: %s", i+1, CHAR(STRING_ELT(expr, i)));
        }
        basic_info("\nnames(args)[1]: `%s`", CHAR(PRINTNAME(TAG(args))));
        */
        s = CAR(args);
      }
      //basic_info("chain depth: %d", n);

      var_len = n;
      array = PROTECT(allocVector(VECSXP, n));
      s =  dt_call;
      n = 0;
      while(TYPEOF(s) == LANGSXP){
        SET_VECTOR_ELT(array, n++, s);
        SEXP args = CDR(s);
        s = CAR(args);
      }
      defineVar(install(var_name), array, SuprJobEnv);

      /*
      SEXP x = CADR(VECTOR_ELT(array, LENGTH(array)-1));
      basic_info("typeof(first x): %s", type2char(TYPEOF(x)));
      const char *dd_name = NULL;
      if(TYPEOF(x) == SYMSXP){ // the dflt case
        dd_name = CHAR(PRINTNAME(x));
      } else {
        dd_name = CHAR(asChar(x));
      }
      basic_info("strval(x) or dd_name: %s", dd_name);

      dd_t *dd = NULL;
      pthread_mutex_lock(ddEnvironment->mutex);
        dd = Hashtable_get(ddEnvironment, dd_name);
      pthread_mutex_unlock(ddEnvironment->mutex);

      if(!dd){
        char err[256];
        sprintf(err, "Cannot find opened DD '%s'", dd_name);
        writeError(conn->fd, err);
	rc = -1;
      } 
      */

      UNPROTECT(1);

    }

  END_R_EVAL();

  //{
      SEXP x = CADR(VECTOR_ELT(array, LENGTH(array)-1));
      //basic_info("typeof(first x): %s", type2char(TYPEOF(x)));
      const char *dd_name = NULL;
      if(TYPEOF(x) == SYMSXP){ // the dflt case
        dd_name = CHAR(PRINTNAME(x));
      } else {
        dd_name = CHAR(asChar(x));
      }
      //basic_info("strval(x) or dd_name: %s", dd_name);

      dd_t *dd = NULL;
      pthread_mutex_lock(ddEnvironment->mutex);
        dd = Hashtable_get(ddEnvironment, dd_name);
      pthread_mutex_unlock(ddEnvironment->mutex);

      if(!dd){
        char err[256];
        sprintf(err, "Cannot find opened DD '%s'", dd_name);
        writeError(conn->fd, err);
	rc = -1;
      } 
  //}
  if(rc == -1) return;

  PROTECT_INDEX cntxt_pi;
  SEXP eval_cntxt = CONS(R_NilValue, R_NilValue);
  PROTECT_WITH_INDEX(eval_cntxt, &cntxt_pi);
  SEXP EVAL_ERROR = eval_cntxt;

  //int save_R_PPStackTop = R_PPStackTop;
  int errorOccured = FALSE;


  for(int k=var_len - 1; k>=0;  k--){

    //basic_info("save_R_PPStackTop: %d, R_PPStackTop: %d",
    //		    save_R_PPStackTop, R_PPStackTop);
    //save_R_PPStackTop = R_PPStackTop;
    
    int iter = var_len - 1 - k;

    if(Supr_options.verbose){
        BEGIN_R_EVAL();
          SEXP call = VECTOR_ELT(array, k);
          basic_info("[%d] call: `%s` with args:", k+1,
                TYPEOF(CAR(call))==SYMSXP?  CHAR(PRINTNAME(CAR(call))):"?");
          SEXP args = CDR(call);
          if(k < LENGTH(array) - 1){
            basic_info("(`%s` = *,", CHAR(PRINTNAME(TAG(args))));
            args = CDR(args);
          }

          SEXP expr = Rf_deparse1m(args, 0, DEFAULTDEPARSE);
          for(int i=0; i<LENGTH(expr); i++){
            basic_info("\t: %s", CHAR(STRING_ELT(expr, i)));
          }
        END_R_EVAL();
    }


    PROTECT_INDEX frame_pi;
    SEXP frame = R_UnboundValue;
    BEGIN_R_EVAL();
      frame = List_findVar(install("frame"), eval_cntxt);
      PROTECT_WITH_INDEX(frame, &frame_pi);
    /*
    List_deleteVar(install("frame"), eval_cntxt);
    List_deleteVar(install("value"), eval_cntxt);
    List_deleteVar(install("..group..value"), eval_cntxt);
    */
      SETCDR(eval_cntxt, R_NilValue);
    END_R_EVAL();

    /*
    SEXP eval_cntxt = PROTECT(allocSExp(ENVSXP)); // crossing multiple subsets
    SET_ENCLOS(eval_cntxt, R_EmptyEnv);
    SEXP EVAL_ERROR = eval_cntxt;
    */

    /*
    if(frame != R_UnboundValue){
      so_t so;
      read(fd, &so, sizeof(so_t));
      if(so.obj_type || so.size){
        error_info("FIXME");
      }
    }
    */

    int nsub = 0;// debug
        
    while(TRUE){ // get and process next.subset
      
      SEXP data_frame = NULL;
      int cmd = -1;

      if(frame != R_UnboundValue) {
        BEGIN_R_EVAL();
	  if(frame == R_NilValue){
            frame = R_UnboundValue;
	  } else {
            data_frame = PROTECT(CAR(frame));
            frame = CDR(frame);
	    REPROTECT(frame, frame_pi);
	    //basic_info("k: %d, nsub: %d", k+1, ++nsub);
	  }
        END_R_EVAL();
      }

      if(!data_frame){

      so_t so;
      read(fd, &so, sizeof(so_t));
      if(so.obj_type == SUPR_URI){
        char uri_name[so.size];
        read(fd, uri_name, so.size);
	//basic_info("\033[0;32m[k:%d] usr_name: %s\033[0m", k+1, uri_name);
	char *subset_name = strstr(uri_name, "#")+1;
	subset_name = strstr(subset_name, "#")+1;
	//basic_info("\033[0;32m[k:%d] subset_name: %s\033[0m", k+1, subset_name);
	if(dd) {
	  so_t *data = NULL;
	  pthread_mutex_lock(dd->values->mutex);
            data = (so_t*) Hashtable_get(dd->values, subset_name);
    	  pthread_mutex_unlock(dd->values->mutex);
	  if(data){
            switch(data->mem_type){
              case SUPR_MEMTYPE_FILE:
	          {
		    //basic_info("SUPR_MEMTYPE_FILE");
	     ////
#ifdef USE_MULTI_DIRS
             char path[PATH_MAX];
             sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(data->sys_type),
                             dd_name, subset_name);
             int file_fd = open(path, O_RDONLY); //// CHECK X
#else
             int file_fd = openat(dd->dir_fd, subset_name, O_RDONLY);
#endif
             if(file_fd == -1) error_info("FIXME");
             struct stat sb;
             int rc = fstat(file_fd, &sb);
             if(rc == -1){
               error_info("%s\n", strerror(errno)); // FIXME
	       error(_("%s"), strerror(errno));
             }

	     int data_type =  suffix2type(subset_name);
	     //basic_info("subset_name: %s, data_type: %d", subset_name, data_type);


	     switch(data_type) {
	       case FILE_SUFFIX_R_DATA:
		 {
	           BEGIN_R_EVAL();
		     SEXP load =  DD_getDefaultRFuncBySuffix(
				strstr(subset_name, ".")+1);
		     SEXP call = PROTECT(LCONS(load, CONS(mkString(path),
						     R_NilValue)));
		     SEXP val = PROTECT(eval(call, R_GlobalEnv));
	        //basic_info("typeof(val): %s, length: %d", type2char(TYPEOF(val)), LENGTH(val));
		//PrintValue(val); // testing
		//SEXP data_frame = NULL;
		     for(int i=0; i< LENGTH(val); i++){
                       SEXP x = VECTOR_ELT(val, i);
	          //basic_info("1. typeof(x): %s", type2char(TYPEOF(x)));
		       SEXP c = getAttrib(x, R_ClassSymbol);
	          //basic_info("2. typeof(c): %s", type2char(TYPEOF(c)));
		       if(TYPEOF(c) == STRSXP &&
                         strcmp(CHAR(STRING_ELT(c, 0)), "data.frame")==0) {
		         data_frame = x; // PROTECT...
		         break;
		       }
		     }
		     UNPROTECT(2);
		     PROTECT(data_frame); // FIXME?
	           END_R_EVAL();
		 }
		 break;

	       case FILE_SUFFIX_SUPR_OBJECT:
		 {
	           BEGIN_R_EVAL();
		     data_frame = PROTECT(read_rso(path));
//	             basic_info("2. typeof(data_frame): %s", type2char(TYPEOF(data_frame)));
	           END_R_EVAL();
		 }
		 break;

	       default: error_info("FIXME, not implemented");
			break;
	     }

	     ////
		  }
		  break;

	      case SUPR_MEMTYPE_TMP:
	          {
		    basic_info("SUPR_MEMTYPE_TMP");
		  }
		  break;

	      case SUPR_MEMTYPE_SHM:
	          {
		    basic_info("SUPR_MEMTYPE_SHM");
		  }
		  break;

	      case SUPR_MEMTYPE_MEM:
	          {
		    basic_info("SUPR_MEMTYPE_MEM");
		    //ssize_t n = write(fd, data, sizeof(so_t) + data->size);
		  }
		  break;

	      default: error_info("FIXME");
		       break;
	    }
	  } else {
	    error_info("FXIME");
	  }
	}

	// processing...
        //int cmd = TR_NEXT_SUBSET;
	//ssize_t size = write(fd, &cmd, sizeof(int));
        cmd = TR_NEXT_SUBSET;

      } else if(so.obj_type == SUPR_SERIALIZED_ROBJ){
        //basic_info("so.obj_type: %d", so.obj_type);
	so_t *s = malloc(sizeof(so_t) + so.size);
	memcpy(s, &so, sizeof(so_t));
       	read(fd, s+1, so.size);
        data_frame = PROTECT(SO_toRObject(s, sizeof(so_t) + s->size));
	free(s);

        cmd = TR_NEXT_SUBSET;

      } else if(so.obj_type == 0 && so.size == 0){
	//basic_info("\033[0;34m[k:%d] NO MORE DATA AVAILABLE\033[0m", k+1);
	// processing...
      } else {
	      error_info("so.obj_type: %d", so.obj_type);
	// error...
      }

      }


      if(data_frame){ // eval
	//basic_info("3. typeof(data_frame): %s", type2char(TYPEOF(data_frame)));
	BEGIN_R_EVAL();
		  void *data[] = {VECTOR_ELT(array, k), data_frame, eval_cntxt};
		  Rboolean success = R_ToplevelExec(DDT_exec, data);
//		  basic_info("_ToplevelExec(DDT_exec, data): \033[0;31m%s\033[0m", success?"SUCCESS":"FAILURE");
		  if(!success) {  // FIXME, error handling ...
	            basic_info("Error: %s", R_curErrorBuf());
		    SEXP err = List_findVar(install("errors"), eval_cntxt);
		    if(err == R_UnboundValue)
		      List_defineVar(install("errors"),
				      mkString(R_curErrorBuf()), eval_cntxt);
		    else {
                      int n=LENGTH(err);
		      SEXP new_err = PROTECT(allocVector(STRSXP, n+1));
		      for(int i=0; i<n; i++)
		        SET_STRING_ELT(new_err, i, STRING_ELT(err, i));
		      SET_STRING_ELT(new_err, n, mkChar(R_curErrorBuf()));
		      List_defineVar(install("errors"), new_err, eval_cntxt);
		    } 

		    List_defineVar(install("value"), EVAL_ERROR, eval_cntxt);

		    errorOccured = TRUE;

		  } else {
		    SEXP frame = List_findVar(install("frame"), eval_cntxt);
		    if(frame == R_UnboundValue)
		      List_defineVar(install("value"), (SEXP) data[1], eval_cntxt);
		  }
	END_R_EVAL();
        
        if(!errorOccured && cmd == TR_NEXT_SUBSET){
	  ssize_t size = write(fd, &cmd, sizeof(int));
	}
	UNPROTECT(1); // data.frame
      }

      if(!data_frame || errorOccured) { // report
	verbose_info("\033[0;34m[k:%d] NO MORE DATA AVAILABLE? REPORTING...\033[0m", k+1);
	// processing...
	
        int cmd = TASK_RESULTS;
	ssize_t size = write(fd, &cmd, sizeof(int));

        SEXP err = NULL;
	BEGIN_R_EVAL();
          err = List_findVar(install("errors"), eval_cntxt);
	END_R_EVAL();

        if(err != R_UnboundValue) {
	  so_t *so = NULL;
	  BEGIN_R_EVAL();
	    size_t len;
	    so = SO_valueOf(err, &len);

	    /*{ // checking
            basic_info("[Checking] typeof(err): %s", type2char(TYPEOF(err)));
	    PrintValue(err);
	    SEXP err = SO_toRObject(so, sizeof(so_t)+so->size);
            basic_info("[Checking] typeof(err): %s", type2char(TYPEOF(err)));
	    PrintValue(err);
	    //Check_deparse2(err, __LINE__);
	    }*/
	  END_R_EVAL();

	  so_t res = {0,0,0,SUPR_ERROR, sizeof(so_t) + so->size};
          write(fd, &res, sizeof(so_t));
          ssize_t size = write(fd, so, res.size);
	} else {
	  so_t *so = NULL;
	  BEGIN_R_EVAL();
	    SEXP res = List_findVar(install("value"), eval_cntxt);
	    if(res != R_UnboundValue){
	      size_t len;
	      so = SO_valueOf(res, &len);

	//basic_info("5. typeof(res): %s", type2char(TYPEOF(res)));
        //basic_info("save_R_PPStackTop: %d, R_PPStackTop: %d", save_R_PPStackTop, R_PPStackTop);
      //
  if(Supr_options.verbose) {
    SEXP res = PROTECT(CONS(res, R_NilValue));
    SET_TAG(res, install("value"));
    Check_deparse(res);
    UNPROTECT(1);
  }
  //

	    }
	  END_R_EVAL();
	  if(so){
            size = write(fd, so, sizeof(so_t)+so->size);
	    //basic_info("wrote: %ld bytes", size);
	    free(so);
	  } else if (k==0) {

            //int send_frame = FALSE;
  
            BEGIN_R_EVAL();
              SEXP call = VECTOR_ELT(array, 0);
              SEXP args = CDR(call); // skip `[....` 
              args = CDR(args); // skip x
              args = CDR(args); // skip i
              args = CDR(args); // skip j
	      if(CAR(args) == R_NilValue){
	        //send_frame = TRUE;
	        verbose_info("send the final result");
                SEXP frame = List_findVar(install("frame"), eval_cntxt);
                if(frame == R_UnboundValue) frame = R_NilValue;
	    
                size_t size;
	       	so_t *s = NULL;
	       	BEGIN_R_EVAL();
	       	s = SO_valueOf(frame, &size);
	       	END_R_EVAL();
	       
		write(fd, s, sizeof(so_t) + s->size);
	       	//int rc; read(fd, &rc, sizeof(int));
	      }
            END_R_EVAL();

	  } else {
	    so_t res = {0,0,0,SUPR_ERROR,0}; // FIXME? 
            write(fd, &res, sizeof(so_t));
	  }
	}

	break;

      }
      //UNPROTECT(1);
    }
    
    UNPROTECT(1); // frame
    if(dd) dd = NULL;

    if(errorOccured) break;
  }


  /*
  if(errorOccured) return;
  int send_frame = FALSE;
  {
        BEGIN_R_EVAL();
          SEXP call = VECTOR_ELT(array, 0);
          SEXP args = CDR(call); // skip `[....` 
          args = CDR(args); // skip x
          args = CDR(args); // skip i
          args = CDR(args); // skip j
	  if(CAR(args) == R_NilValue){
	    send_frame = TRUE;
	    basic_info("\033[0;32msave the final result to '.LastValue'???\033[0m");
	  }
        END_R_EVAL();
  }

  if(!send_frame) return;

  SEXP frame = List_findVar(install("frame"), eval_cntxt);
  //
  if(frame == R_UnboundValue){
    //error_info("save the final result to '.LastValue'???");
	  frame = R_NilValue;
  }
  //
  {
    size_t size;
    so_t *s = NULL;
    BEGIN_R_EVAL();
      s = SO_valueOf(frame, &size);
    END_R_EVAL();

    write(fd, s, sizeof(so_t) + s->size);
    int rc;
    read(fd, &rc, sizeof(int));
  }
  */


  UNPROTECT(1); // eval_cntxt

//        basic_info("ssave_R_PPStackTop: %d, R_PPStackTop: %d", ssave_R_PPStackTop, R_PPStackTop);
}

void handleDDT_call(void *data)
{
  supr_socket_conn_t *conn = (supr_socket_conn_t *)data;
  int fd = conn->fd;

  while(TRUE){

      struct timeval tv;
      //tv.tv_sec=1000;
      tv.tv_sec=60;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      int max_fd = fd;
      FD_SET(fd, &readfds);

      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
            if(ns==0) {
              //SocketConn_info(0, "Warning (%s): select()=%d", __func__, ns);
              // testing info
              continue;
            } else {
              close(fd);
	      free(conn);
	      pthread_exit(NULL);
	    }
      } 
      __handleDDT_call(conn);
  }

}

void handleDD_open(supr_socket_conn_t *conn)
{
	/*
fprintf(stderr, "\033[0;33m%s:%d\n", __FILE__, __LINE__);
      DFSDATA_showOpenedFileNames();
fprintf(stderr, "\033[0m");
*/

  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char name[len];
  read(fd,  name, len);

  {
    char path[PATH_MAX];
    getcwd(path, PATH_MAX);
    //printf("\n\n[%s] cwd: %s\n", __func__, path);
    //printf("[%s] dir_array: %p\n", __func__, dir_array);
    //printf("[%s] dd_name: %s\n", __func__, name);
  }

  DIR *dir;
  dd_t *dd = Hashtable_get(ddEnvironment, name);

  int rc = -1;
  if(dd) {

    Hashtable_delete(ddEnvironment, name);
    DD_destroy(dd);
    dd = newDD(name);
    //Hashtable_put(ddEnvironment, name, dd);
    rc = 0;

  } else if(dir = __opendir__(name)){
    closedir(dir);

    rc = 0;
    dd = newDD(name);

  } else if ( __mkdir__(name) != -1){

    rc = 0;
    dd = newDD(name);

  } else {
 //   writeError(fd, strerror(errno));
    fprintf(stderr, "Error: %s\n", strerror(errno));
    //return;
  }

  if(!dd) {
    fprintf(stderr, "Error: FIXME(%s:%d)\n", __FILE__, __LINE__);
    exit(1);
  }

  // only the main dir in the dir_array case??
  if(dd->dir_fd == -1){
    char path[PATH_MAX];
    getcwd(path, PATH_MAX);
    sprintf(path+strlen(path), "/data/%s", name);
    dd->dir_fd = open(path, O_DIRECTORY); //// CHECK, not used, why open ?
    if(dd->dir_fd == -1) rc = -1;
  }

  Hashtable_put(ddEnvironment, name, dd);
  //printf("[%s] %s\n", __func__, Object_toString(dd));


  /*
  cmd = DFS_DD_OPEN_RETURN;
  write(fd, &cmd, INT_SIZE);
  write(fd, &len, SIZE_SIZE);
  write(fd, name, len);
  */
  write(fd, &rc, INT_SIZE);
  if(rc == -1){
    SocketConn_writeString(conn, strerror(errno));
    return;
  } else {
#ifdef  USE_MULTI_DIRS

  /*
typedef struct datanode_dir_struct {
  int fd; // 
  int padding;
  char *path;
} datanode_dir_t;

typedef struct dir_array_struct {
  int ndir; // number of locations/directories 
  int padding;
  datanode_dir_t dirs[0];
} dir_array_t;
*/

    hashtable_t *values = dd->values;

    struct dirent *dp;
    size_t len;
    struct stat sb;

    int dir_fd;

    for(int dir_idx = 0; dir_idx < dir_array->ndir; dir_idx ++) {
      char path[PATH_MAX];
      sprintf(path, "%s/data/%s", dir_array->dirs[dir_idx].path,
		      name);

      /*
fprintf(stderr, "\033[0;32m%s:%d\n", __FILE__, __LINE__);
      DFSDATA_showOpenedFileNames();
fprintf(stderr, "\033[0m");
*/
      //DIR *dir;
      dir = opendir(path);
      if(!dir){
        int rc = __mkdir__(path);
	continue;
      }

      /*
fprintf(stderr, "\033[0;34m%s:%d\n", __FILE__, __LINE__);
      DFSDATA_showOpenedFileNames();
fprintf(stderr, "\033[0m");
*/

      dir_fd = dirfd(dir); //open(path, O_DIRECTORY); //// CHECK
      /*
      if(dir_fd == -1){
        fprintf(stderr, "open(%s, O_DIRECTORY), %s\n", path,
		       	strerror(errno));
	continue;
      }

      {
	fprintf(stderr, "open(%s): %d\n", path, dir_fd);
      }
      */

      while((dp = readdir(dir))){
        if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0
           || strncmp(dp->d_name, ".nfs", 4)==0)
              continue;
      
        len = strlen(dp->d_name) + 1;
        write(fd, &len, SIZE_SIZE);
        write(fd, dp->d_name, len);

        int file_fd = openat(dir_fd, dp->d_name, O_RDONLY); //// CHECK X
        rc = file_fd == -1? -1 : fstat(file_fd, &sb);

#ifdef  DEBUG_OPEN_FILES
        if(max_fd < file_fd) {
	  pthread_mutex_lock(&max_fd_mutex);
	       	max_fd = file_fd;
	  pthread_mutex_unlock(&max_fd_mutex);
	}
#endif

        write(fd, &rc, INT_SIZE);
        if(rc == -1){
          SocketConn_writeString(conn, strerror(errno));
	  if(file_fd != -1) close(file_fd);
        } else {
          write(fd, &sb, sizeof(struct stat));
	  close(file_fd);

	  so_t *so = (so_t *) malloc(sizeof(so_t));
          so->ref_count = 1; 
	  // ...
	  so->sys_type = dir_idx; // for now?
	  // ...
          so->mem_type = SUPR_MEMTYPE_FILE;
          so->size = 0;

          pthread_mutex_lock(values->mutex);
            Hashtable_put(values, dp->d_name, so);
          pthread_mutex_unlock(values->mutex);
	  //printf("\t%s size: %ld\n", dp->d_name, sb.st_size);
	}
      }
      /*
      int rc = close(dir_fd);
      {
	fprintf(stderr, "close(%d[%s]): %d, %s\n\n", dir_fd, path, rc, strerror(errno));
      }
      */
      closedir(dir);
    }
    len = 0;
    write(fd, &len, SIZE_SIZE);

#ifdef  DEBUG_OPEN_FILES
    /*
    {
      char msg[256];
      sprintf(msg, "max_fd: %d, nconn: %d", max_fd,
		      vectorSize(socket_connections));
      basic_info(msg);
      //DFSDATA_showOpenedFileNames();
    }
    */
#endif

#else

    dir = __opendir__(name);
    struct dirent *dp;
    size_t len;
    struct stat sb;

    // FIXME, use dd->dir_fd
    /*
    char path[PATH_MAX]; // getcwd(path, PATH_MAX);
    sprintf(path, "data/%s", name);
    int dir_fd = open(path, O_DIRECTORY);
    */
    int dir_fd = dd->dir_fd;

    hashtable_t *values = dd->values;

    while((dp = readdir(dir))){
      if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0
         || strncmp(dp->d_name, ".nfs", 4)==0)
              continue;
      
      len = strlen(dp->d_name) + 1;
      write(fd, &len, SIZE_SIZE);
      write(fd, dp->d_name, len);
      /*
      char pathname[PATH_MAX];
      sprintf(pathname, "data/%s/%s", name, dp->d_name);
      printf("\t[%s] %s ---> %s\n", __func__, dp->d_name, pathname);
      */
      //sprintf(CWD_PATH, "%s/%s", pathname, dp->d_name);
      //rc = stat(pathname, &sb);

      int file_fd = openat(dir_fd, dp->d_name, O_RDONLY);
      rc = file_fd == -1? -1 : fstat(file_fd, &sb);

      write(fd, &rc, INT_SIZE);
      if(rc == -1){
        SocketConn_writeString(conn, strerror(errno));
      } else {
        write(fd, &sb, sizeof(struct stat));
	close(file_fd);

	so_t *so = (so_t *) malloc(sizeof(so_t));
        so->ref_count = 1;
        so->mem_type = SUPR_MEMTYPE_FILE;
        so->size = 0;

        pthread_mutex_lock(values->mutex);
          Hashtable_put(values, dp->d_name, so);
        pthread_mutex_unlock(values->mutex);
	printf("\t%s size: %ld\n", dp->d_name, sb.st_size);
      }
    }
    len = 0;
    write(fd, &len, SIZE_SIZE);
    //close(dir_fd);
#endif
  }


/*
	fprintf(stderr, "\n\n");
fprintf(stderr, "\033[0;31m%s:%d\n", __FILE__, __LINE__);
      DFSDATA_showOpenedFileNames();
fprintf(stderr, "\033[0m");
	fprintf(stderr, "\n\n");
	*/
}

pthread_mutex_t ft_task_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t ft_task_cond  = PTHREAD_COND_INITIALIZER;
vector_t *ft_tasks = NULL;

pthread_mutex_t backend_task_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t backend_task_cond  = PTHREAD_COND_INITIALIZER;
vector_t *backend_tasks = NULL;

typedef struct dd_put_data_struct {
  int ref_count;
  int padding; 
  char *dd_name;
  char *subset_name;
  so_t *so; 
  dd_stat_t stat;
} dd_put_data_t;

/*
typedef struct dd_close_data_struct {
  int ref_count;
  int save;
  char *dd_name;
} dd_close_data_t;
*/

typedef struct dd_persist_data_struct {
  int level;
  int count_max;
  char *dd_name;
  char *subset_name;
  supr_socket_conn_t *conn;
  int dir_fd;
  int padding;
} dd_persist_data_t;


void __DD_sendInfo(const char *msg, int level, int line)
{
  printf("[%s] deprecated: FIXME(%s:%d)\n", __func__, __FILE__, line);
  return;
  pthread_mutex_lock(backendConn->mutex);
 
    int cmd = DFS_DD_DATANODE_INFO;

    write(backendConn->fd, &cmd, INT_SIZE);

    write(namenodeConn->fd, &cmd, INT_SIZE);
    write(namenodeConn->fd, &level, INT_SIZE);
    SocketConn_writeString(namenodeConn, msg);

    write(backendConn->fd, &cmd, INT_SIZE);

  pthread_mutex_unlock(backendConn->mutex);
}


extern so_t *SO_getDDSubset(const char *dd_name, const char *subset_name,
                const char *addr, SEXP func, SEXP env);

extern int supr_errno;
extern const char *supr_strerror(int err_no);

void __handleDD_put(supr_socket_conn_t *conn, int fd);

void backend_handleDD_put(void *arg)
{
  task_t *task = (task_t *) arg; //dd_put_data_t *data = (dd_put_data_t *) arg;

  if(!task->processed){ // run as the "master"
    supr_socket_conn_t *conn = (supr_socket_conn_t *) task->data;

    __handleDD_put(conn, conn->efd);

    int cmd = DFS_DD_NULL;
    pthread_mutex_lock(backendConn->mutex);
      write(backendConn->fd, &cmd, INT_SIZE);
      conn->fd = conn->efd;
      write(backendConn->fd, &cmd, INT_SIZE);
    pthread_mutex_unlock(backendConn->mutex);

    free(task);
    return;
  }


  dd_put_data_t *data = task->data;

  so_t *so = data->so;
  supr_thread_t *cth = currentThread();
  /*
   basic_info("\033[0;33mdd_name: %s subset_name: %s" 
  " so: [ref_count: %d mem_type: %d sys_type: %d obj_type: %d, size: %ld]\033[0m",
	  data->dd_name, data->subset_name,
	  so->ref_count, so->mem_type, so->sys_type, so->obj_type, so->size);
	  */

  if(so->obj_type == SUPR_URI){ // download
    so_t *s = so;
    errno = 0;

    so = SO_getDDSubset(data->dd_name, data->subset_name, (char*)(s+1),
		    NULL, NULL);

    if(!so || so->obj_type == SUPR_ERROR){

      char *err = so? (char*)(so+1) : strerror(errno);
      //printf("[%s] Error: %s\n", __func__, err);

      task->rc = -1;
      String _err = String_new("%s, %s", (char*)(s+1), err);
      //printf("\033[0;31m[%s] Error: %s\033[0m\n", __func__, _err->str);

      task->err = _err;
      if(task->processed){
        pthread_mutex_lock(task->processed->mutex);
          vectorAdd(task->processed, task);
        pthread_mutex_unlock(task->processed->mutex);
      }

      if(task->notify_mutex && task->notify_cond){
        pthread_mutex_lock(task->notify_mutex);
          pthread_cond_signal(task->notify_cond);
        pthread_mutex_unlock(task->notify_mutex);
      }

      if(so) free(so);
      return;
    }
  }

  printf("[%s:%d] so->size: %ld\n", __func__, cth->tid, so->size);

  dd_t *dd;
  pthread_mutex_lock(ddEnvironment->mutex);
    dd = (dd_t*) Hashtable_get(ddEnvironment, data->dd_name);
  pthread_mutex_unlock(ddEnvironment->mutex);

  switch(so->mem_type){

      case SUPR_MEMTYPE_MEM:
           {
	     printf("[%s] Leave it in memory: %d\n", __func__, so->mem_type);
	     if(so == data->so)
	       so->ref_count++;
	     data->stat.st_size = so->size;
	     ////
	     data->stat.st_dev  = so->mem_type;
	     data->stat.st_ino  = so->obj_type;
	     clock_gettime(CLOCK_REALTIME, &data->stat.st_mtim);
	     ////

	     pthread_mutex_lock(dd->values->mutex);
               Hashtable_put(dd->values, strdup(data->subset_name), so);
	     pthread_mutex_unlock(dd->values->mutex);
	     //// Checking
	     /*
             if(so->obj_type == SUPR_SERIALIZED_ROBJ){
               BEGIN_R_EVAL();
	         SEXP val = SO_toRObject(so, sizeof(so)+so->size);
		 PrintValue(val);
               END_R_EVAL();
	     }
	     */
	     ////
	   }
	   break;

      case SUPR_MEMTYPE_SHM:
           { // TODO
	     so->ref_count++;
	     pthread_mutex_lock(dd->values->mutex);
               Hashtable_put(dd->values, data->subset_name, so);
	     pthread_mutex_unlock(dd->values->mutex);
	   }
	   break;

      case SUPR_MEMTYPE_FILE:
           { 
	     so->ref_count++;

	     /*
	     char file_name[strlen("data/")+strlen(data->dd_name)
		     +strlen(data->subset_name)+2];
	     sprintf(file_name, "data/%s/%s", data->dd_name, data->subset_name);
	     printf("[%s] Creating file: %s\n", __func__, file_name);
	     int fd = open(file_name, O_RDWR | O_CREAT | O_TRUNC, 0600);
	     */
#ifdef USE_MULTI_DIRS
	     long rn =  random();
	     int dir_idx = rn % DD_DIR_LENGTH;
	     char path[PATH_MAX];
	     sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(dir_idx),
			     data->dd_name, data->subset_name);

	     //printf("path: %s\n", path);

	     int fd = open(path, O_RDWR | O_CREAT | O_TRUNC, 0600);
#else
	     int fd = openat(dd->dir_fd, data->subset_name,
			     O_RDWR | O_CREAT | O_TRUNC, 0600);
#endif

	     if(fd == -1){
	       printf("Error: %s, FIXME(%s:%d)\n",
			 strerror(errno), __FILE__, __LINE__);
               task->rc = -1;
               String _err = String_new("%s/%s, %s", data->dd_name,
			       data->subset_name, strerror(errno));
               task->err = _err;
               if(task->processed){
                 pthread_mutex_lock(task->processed->mutex);
                   vectorAdd(task->processed, task);
                 pthread_mutex_unlock(task->processed->mutex);
               }

               if(task->notify_mutex && task->notify_cond){
                 pthread_mutex_lock(task->notify_mutex);
                   pthread_cond_signal(task->notify_cond);
                 pthread_mutex_unlock(task->notify_mutex);
               }

	       if(so != data->so)
	         free(so);
               //pthread_mutex_unlock(ddEnvironment->mutex);
	       return;
	     }

	     //write(fd, so+1, so->size);
	     write(fd, so->val, so->size);
	       //stat(file_name, &data->stat);
	     fstat(fd, &data->stat);
	     close(fd);


	       /*
	       so = (so_t*) malloc(sizeof(so_t)+strlen(file_name)+1);
	       so->mem_type = SUPR_MEMTYPE_FILE;
	       so->obj_type = SUPR_FILE;
	       so->size = strlen(file_name)+1;
	       memcpy(so+1, file_name, strlen(file_name)+1);
	       */
	     so_t *s = (so_t*) malloc(sizeof(so_t));
	     memcpy(s, so, sizeof(so_t));
	     if(so != data->so) free(so);

	     s->mem_type = SUPR_MEMTYPE_FILE;
	     s->obj_type = SUPR_FILE;
#ifdef USE_MULTI_DIRS
	     s->sys_type = dir_idx;
#endif
	     s->size = 0;

	     pthread_mutex_lock(dd->values->mutex);
               Hashtable_put(dd->values, strdup(data->subset_name), s);
	     pthread_mutex_unlock(dd->values->mutex);
	    
	   }
	   break;

      case SUPR_MEMTYPE_TMP:
      default:
	   {
	     fprintf(stderr,
     "\033[0;31mError: not implemented type: %d, FIXME(%s:%d)\033[0m\n",
			 so->obj_type, __FILE__, __LINE__);
	     if(so == data->so)
	       so->ref_count++;
	     pthread_mutex_lock(dd->values->mutex);
               Hashtable_put(dd->values, strdup(data->subset_name), so);
	     pthread_mutex_unlock(dd->values->mutex);
	   }
	   break;
           //pthread_mutex_unlock(ddEnvironment->mutex);
	   //exit(1);
  }

  //pthread_mutex_unlock(ddEnvironment->mutex);

/*
  data->ref_count--;
  so->ref_count--;
  if(data->ref_count==0){ free(data); }
  if(so->ref_count==0){
	  printf("\033[0;31m[%s]Free so: <%p>\033[0m\n", __func__, so);
	  free(so);
  }
  */

  task->rc =  0;
  task->err = NULL;
  if(task->processed){
    pthread_mutex_lock(task->processed->mutex);
      vectorAdd(task->processed, task);
    pthread_mutex_unlock(task->processed->mutex);
  }
  if(task->notify_mutex && task->notify_cond){
    pthread_mutex_lock(task->notify_mutex);
      pthread_cond_signal(task->notify_cond);
    pthread_mutex_unlock(task->notify_mutex);
  }
/*
{
  pthread_mutex_lock(ddEnvironment->mutex);
  dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, data->dd_name);
  pthread_mutex_unlock(ddEnvironment->mutex);
  pthread_mutex_lock(dd->values->mutex);
  so_t *s = (so_t *) Hashtable_get(dd->values, "part_000008.sro");
  if(s) printf("\033[0;32m%s: part_000008.sro: <%p> size = %ld\033[0m\n",
		  __func__, s, s->size);
  s = (so_t *) Hashtable_get(dd->values, "part_000007.sro");
  if(s) printf("\033[0;32m%s: part_000007.sro: <%p> size = %ld\033[0m\n",
		  __func__, s, s->size);
  s = (so_t *) Hashtable_get(dd->values, "part_000004.sro");
  if(s) printf("\033[0;32m%s: part_000004.sro: <%p> size = %ld\033[0m\n",
		  __func__, s, s->size);
  s = (so_t *) Hashtable_get(dd->values, "part_000022.sro");
  if(s) printf("\033[0;32m%s: part_000022.sro: <%p> size = %ld\033[0m\n",
		  __func__, s, s->size);
  pthread_mutex_unlock(dd->values->mutex);
  printf("\n\n");
}
*/

}

// save???
/*
void ft_handleDD_close(void *arg)
{
  task_t *task = (task_t *) arg;
  dd_close_data_t *data = (dd_close_data_t *) task->data;
  supr_thread_t *cth = currentThread();
  printf("\033[0;33m[%s:%d] dd_name: %s save: %d\n",
		  __func__, __LINE__, data->dd_name, data->save);

  int tid = syscall(SYS_gettid);
  printf("\033[0;32m\t[pid: %d tid:%d]\033[0m\n", getpid(), tid);

  dd_t *dd;
  pthread_mutex_lock(ddEnvironment->mutex);
    dd = (dd_t*) Hashtable_get(ddEnvironment, data->dd_name);
    Hashtable_delete(ddEnvironment, data->dd_name);
  pthread_mutex_unlock(ddEnvironment->mutex);

  { // TODO...
  }

#ifdef DFS_DD_WAIT
  printf("\033[0;35m\t[%s:%d] block the backend to use namenodeConn...\n",
		  __func__, tid);
  pthread_mutex_lock(backendConn->mutex);
  {
    int cmd = DFS_DD_CLOSE_RETURN;
    // block the backend to use namenodeConn
    write(backendConn->fd, &cmd, INT_SIZE);

    write(namenodeConn->fd, &cmd, INT_SIZE);
    size_t len;
    len = strlen(data->dd_name)+1;
    write(namenodeConn->fd, &len, SIZE_SIZE);
    write(namenodeConn->fd, data->dd_name, len);

    write(backendConn->fd, &cmd, INT_SIZE);
  }
  pthread_mutex_unlock(backendConn->mutex);
  printf("\033[0;35m\t[%s:%d] block the backend to use namenodeConn... done!\n",
		  __func__, tid);
#endif
}
*/

void DD_show(const char *dd_name)
{
  dd_t *dd;
  pthread_mutex_lock(ddEnvironment->mutex);
      dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
  pthread_mutex_unlock(ddEnvironment->mutex);
  printf("[%s] dd: <%p>\n", __func__, dd);
  if(!dd) return;

#ifdef USE_MULTI_DIRS
  if(dd->dir_fd != -1)
    printf("[%s] [USE_MULTI_DIRS: FIXME] dd->dir_fd: %d\n", __func__,
		    dd->dir_fd); 
#else
  printf("[%s] dd->dir_fd: %d\n", __func__, dd->dir_fd); 
#endif

  hashtable_t *values = dd->values;
  pthread_mutex_lock(values->mutex);
    int n;
    char **keys = Hashtable_keySet(values, &n);
    for(int i=0; i<n; i++){
      so_t *so = (so_t*) Hashtable_get(values, keys[i]);
      printf("%4d: %s [%d, mem: %d, %d, %d, sz: %ld]", i, keys[i],
		      so->ref_count, so->mem_type, so->sys_type,
		      so->obj_type, so->size);
      switch(so->mem_type){
        case SUPR_MEMTYPE_MEM:
	     {
               printf("\n");
	     }
	     break;

        case SUPR_MEMTYPE_SHM:
	     {
               size_t size;
	       void *mem_ptr = rjni_shm_open((char*)so->val, &size);
               printf(" file: %s, sz: %ld, <%p>\n", (char*)so->val,
			       size, mem_ptr);
	       munmap(mem_ptr, size);
	     }
	     break;

        case SUPR_MEMTYPE_TMP:
	     {
	       struct stat sb;
	       int rc = stat((char*)so->val, &sb);
	       if(rc == -1){
                 printf(" file: %s, Error: %s\n", (char*)so->val,
				 strerror(errno));
		 break;
	       }

               printf(" file: %s, sz: %ld\n", (char*)so->val, sb.st_size);

	     }
	     break;

        case SUPR_MEMTYPE_FILE:
	     {
	       struct stat sb;
#ifdef USE_MULTI_DIRS
	       char path[PATH_MAX];
	       sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(so->sys_type),
			       dd_name, keys[i]);
	       int rc = stat(path, &sb);
	       if(rc == -1){
                 printf(" file: %s, Error: %s\n", path, strerror(errno));
		 break;
	       }
#else
	       int rc = fstatat(dd->dir_fd, keys[i], &sb, O_RDONLY);
	       if(rc == -1){
//                 Note: no so->val, because so->size  = 0 
//                 printf(" file: %s, Error: %s\n", (char*)so->val, strerror(errno));
                 printf(" file: %s, Error: %s\n", keys[i], strerror(errno));
		 break;
	       }
#endif

               printf(" file: %s, sz: %ld\n", keys[i], sb.st_size);
	     }
	     break;

	default: {
               printf("Error: FIXME (%s:%d)\n", __FILE__, __LINE__);
	       exit(1);
		 }
		 break;

      }
    }
  pthread_mutex_unlock(values->mutex);
}

extern void *rjni_shm_create(const char *shm_name, size_t size);

void backend_handleDD_persist(void *arg)
{
  task_t *task = (task_t *) arg;

  if(!task->processed){ // run as the "master"
    supr_socket_conn_t *sc = (supr_socket_conn_t *)task->data;
    int fd = sc->efd;
    int cmd; read(fd,  &cmd, INT_SIZE); 
    size_t len; read(fd,  &len, SIZE_SIZE);
    char dd_name[len]; read(fd,  dd_name, len);
    int level; read(fd,  &level, INT_SIZE);

    verbose_info("\033[0;35m[%s] dd_name: %s, level: %d\033[0m\n", __func__,
		    dd_name, level);

    dd_t *dd;
    pthread_mutex_lock(ddEnvironment->mutex);
      dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
    pthread_mutex_unlock(ddEnvironment->mutex);
    if(!dd) {
      int rc = -1;
      write(fd, &rc, INT_SIZE);
      char err[256];
      sprintf(err, "Cannot find DD '%s'", dd_name);
      FD_writeString(fd, err);
      sc->fd = sc->efd;
      cmd = DFS_DD_NULL;
      pthread_mutex_lock(backendConn->mutex);
        write(backendConn->fd, &cmd, INT_SIZE);
        write(backendConn->fd, &cmd, INT_SIZE);
      pthread_mutex_unlock(backendConn->mutex);
      // free ...
      return;
    }

    char path[PATH_MAX]; // getcwd(path, PATH_MAX);
    sprintf(path, "data/%s", dd_name);
    int dir_fd = open(path, O_DIRECTORY);
    if(dir_fd == -1){
      write(fd, &dir_fd, INT_SIZE);
      FD_writeString(fd, strerror(errno));
      sc->fd = sc->efd;
      cmd = DFS_DD_NULL;
      pthread_mutex_lock(backendConn->mutex);
        write(backendConn->fd, &cmd, INT_SIZE);
        write(backendConn->fd, &cmd, INT_SIZE);
      pthread_mutex_unlock(backendConn->mutex);
      // free ...
      return;
    }

    //{
/*
#ifdef USE_MULTI_DIRS
    if(level == DFS_DD_PERSIST_FILE_LEVEL) {
      printf("\033[0;31m[%s] remove files: %s/%s/*, ..., if any\033[0m\n",
		      __func__, DD_DIR_PATH(0), dd_name);

      for(int dir_idx = 0; dir_idx < DD_DIR_LENGTH; dir_idx ++){
        char pathname[PATH_MAX];
        sprintf(pathname, "%s/data/%s", DD_DIR_PATH(dir_idx), dd_name);
	DIR *dir = opendir(pathname); // don't check errors?
 	struct dirent *dp;
        while((dp = readdir(dir))){
	  if(strcmp(dp->d_name, ".")==0 || strcmp(dp->d_name, "..")==0)
              continue;
	  char buf[strlen(pathname)+strlen(dp->d_name)+2];
          sprintf(buf, "%s/%s", pathname, dp->d_name);

          printf("\033[0;33mremove %s\033[0m\n", buf);

	  __rm_recursive__(buf);
	}
	closedir(dir);
      }
    }
#endif
*/
    //}

    vector_t *processed = newVector(TRUE);
    hashtable_t *values = dd->values;
    pthread_mutex_lock(values->mutex);

      int n;
      char **keys = Hashtable_keySet(values, &n);

      /*{
	char path[PATH_MAX];
	char *s = getcwd(path, PATH_MAX);
        basic_info("[%s] nkeys: %d, pwd: %s\n", __func__, n, s);
      }*/

      for(int i=0; i<n; i++){
	//so_t *so = (so_t*) Hashtable_get(values, keys[i]);
        dd_persist_data_t *data = (dd_persist_data_t *)
            malloc(sizeof(dd_persist_data_t));
	data->level     = level;
	data->count_max = n; 
	data->dd_name   = dd->name; //dd_name;
	data->subset_name = keys[i];
	data->conn      = sc;
	data->dir_fd    = dir_fd; // not used for MULTI_DIRS...

	pthread_mutex_lock(&backend_task_mutex);
	  vectorAdd(backend_tasks, newTask(backend_handleDD_persist, data,
		       	processed, NULL, NULL));
	  //pthread_cond_signal(&backend_task_cond);
	  pthread_cond_broadcast(&backend_task_cond);
	pthread_mutex_unlock(&backend_task_mutex);
      }
      free(keys);

    pthread_mutex_unlock(values->mutex);



    if(n==0){ // nothing to save

	    /*
	      int interrupted = FALSE;
	    for(int i=0; i<120; i++)
	    {
	      interrupted = DD_checkUserInterrupt();
	      if(interrupted) break;
	      sleep(1);
	    }
      if(interrupted){
        int rc = -1, nerr = 1;
        write(sc->efd, &rc, INT_SIZE);
        write(sc->efd, &nerr, INT_SIZE);
        FD_writeString(sc->efd, "DFS_DATANODE_INTERRUPTED");
      } else {
        int rc = 0;
        write(sc->efd, &rc, INT_SIZE);
      }
      */

      /*{
        int rc = -1, nerr = 1;
        write(sc->efd, &rc, INT_SIZE);
        write(sc->efd, &nerr, INT_SIZE);
        FD_writeString(sc->efd, "DFS_DATANODE_INTERRUPTED");
      }*/

      {
        verbose_info("[%s] the n=0 case, write rc=0", __func__);
        int rc = 0;
        write(fd, &rc, sizeof(int));
      }

      int cmd = DFS_DD_NULL;
      pthread_mutex_lock(backendConn->mutex);
        write(backendConn->fd, &cmd, INT_SIZE);
        sc->fd = sc->efd;
        write(backendConn->fd, &cmd, INT_SIZE);
      pthread_mutex_unlock(backendConn->mutex);
      Vector_destroy(processed);
    }
    //verbose_info("[%s] 'master' Done!", __func__);
    return;
  }

  int rc = 0;
  String err = NULL;

  // persist operation
  dd_persist_data_t *data = (dd_persist_data_t *) task->data;
  supr_thread_t *cth = currentThread();

  printf("\033[0;33m[%s:%d] dd_name: %s level: %d, subset: %s, count: %d\n",
		  __func__, __LINE__, data->dd_name, data->level,
		  data->subset_name, data->count_max);
  printf("\033[0;32m\t[pid: %d tid:%d] dir_fd: %d\033[0m\n", getpid(),
		  cth->tid, data->dir_fd);

  dd_t *dd;
  pthread_mutex_lock(ddEnvironment->mutex);
    dd = (dd_t*) Hashtable_get(ddEnvironment, data->dd_name);
    //Hashtable_delete(ddEnvironment, data->dd_name);
  pthread_mutex_unlock(ddEnvironment->mutex);

  hashtable_t *values;
  so_t *so;
  if(dd) {
    values = dd->values;
    pthread_mutex_lock(values->mutex);
      so = (so_t*)Hashtable_get(values, data->subset_name);
    pthread_mutex_unlock(values->mutex);
  } else {
    rc = -1;
    err = String_new("Cannot find DD '%s'", data->dd_name); 
  }

//  supr_thread_t *cth = currentThread();

  int persist_level = data->level;
  if(rc == 0){
    switch(persist_level){
      case DFS_DD_PERSIST_FILE_LEVEL: 
           if(so->mem_type != SUPR_MEMTYPE_FILE)
	   {
#ifdef USE_MULTI_DIRS
	     { // Remove ... not efficient??
	        int rc = -1;
      		int dir_idx = 0; 
      		for(; dir_idx < DD_DIR_LENGTH; dir_idx++) {
		  char pathname[PATH_MAX];
		  sprintf(pathname, "%s/data/%s/%s", DD_DIR_PATH(dir_idx),
				  data->dd_name, data->subset_name);
	          rc = __rm_recursive__(pathname);
          	  //basic_info("\033[0;33mremove: %s, rc: %d\033[0m\n", pathname, rc);
		  if(rc == 0) break;
      		}
		if(rc == -1) {
          	  printf("\033[0;33mremove: %s/%s, FAILED [rc: %d, dir_idx: %d]\033[0m\n",
				  data->dd_name, data->subset_name, rc, dir_idx);
		}
	     }

	     long rn =  random();
             int dir_idx = rn % DD_DIR_LENGTH;
             char path[PATH_MAX];
             sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(dir_idx),
                             data->dd_name, data->subset_name);
             int fd = open(path, O_RDWR | O_CREAT | O_TRUNC, 0600);
#else
             int fd = openat(data->dir_fd, data->subset_name,
		      O_RDWR | O_CREAT | O_TRUNC, 0600);
#endif
             if(fd == -1){
                 rc = -1;
	         err = String_new("%s",strerror(errno));
		 break;
             } 

	     switch(so->mem_type){
	       case SUPR_MEMTYPE_TMP:
		    {
		      int t_fd = open((char*)so->val, O_RDONLY);
		      struct stat sb;
                      if(fd == -1 || fstat(t_fd, &sb) == -1){
                 	rc = -1;
	         	err = String_new("%s, %s", (char*)so->val,strerror(errno));
		 	break;
             	      }
		      void *p = malloc(sb.st_size);
		      read(t_fd, p, sb.st_size);
		      close(t_fd);

		      write(fd, p, sb.st_size);
		      free(p);

		      { // unlink((char*)so->val); // ??
			   //SO_decref(so);
		      }
		    }
		    break;
	       case SUPR_MEMTYPE_SHM:
		    {
		      size_t size;
		      void *mem_ptr = rjni_shm_open((char*) so->val, &size);
		      write(fd, mem_ptr, size);
		      munmap(mem_ptr, size);
		      /*
		      shm_unlink((char*) so->val);
	              pthread_mutex_lock(shm_names->mutex);
	                vectorRemoveElement(shm_names, (char*) so->val);
	              pthread_mutex_unlock(shm_names->mutex);
		      */
		      ShmCache_dec_ref((char*) so->val);
		    }
		    break;
	       case SUPR_MEMTYPE_MEM:
		    {
                      char *s = data->subset_name;
		      //basic_info("data->subset_name: %s", data->subset_name);
		      s +=  strlen(s);
		      while(s != data->subset_name && *s != '.') s--;
		      //basic_info("suffix: \"%s\", so->size: %ld", s,so->size);
		      if(strcmp(s, ".sro")==0)
                      //write(fd, so, sizeof(so_t) + so->size);
                        write(fd, so, sizeof(so_t));
		    }
		    //basic_info("so->val: %p, so+1: %p, so->size: %ld", so->val, so+1, so->size);
                    write(fd, so->val, so->size); // SO_decref(so); // ??
		    break;
	       default:
		    {
	               rc = -1;
	               err = String_new("Unimplemented object mem_type: %d",
					 so->mem_type);
		    }
		    break;
	     }

             close(fd);
             if(rc != -1){
      
               so_t *s = (so_t *) malloc(sizeof(so_t));
	       memcpy(s, so, sizeof(so_t));
	       free(so);
               s->ref_count = REF_COUNT_INITIALIZER;
               s->mem_type = SUPR_MEMTYPE_FILE;
#ifdef USE_MULTI_DIRS
	       s->sys_type = dir_idx;
#endif
               s->size = 0;
               pthread_mutex_lock(values->mutex);
                 Hashtable_put(values, data->subset_name, s);
               pthread_mutex_unlock(values->mutex);
               
             }
           }
	   break;
      case DFS_DD_PERSIST_TMP_LEVEL: // delete tmp?
           if(so->mem_type != SUPR_MEMTYPE_TMP)
	   { // FIXME
             printf("[%s] so->mem_type: %d\n", __func__, so->mem_type);
                      char cwd[PATH_MAX]; getcwd(cwd, PATH_MAX);
		      char *p = cwd + strlen(cwd);
		      while(*p != '/') p--;
		      char *tmp_dir = strdup(p);
		      sprintf(cwd, "/tmp/supr.%d%s/data/%s", geteuid(),
				      tmp_dir, data->dd_name);
		      tmp_dir = cwd;
		      printf("[%s] tmp_dir: %s\n", __func__, tmp_dir);
		      pthread_mutex_lock(values->mutex); // FIXME, rm dir...
		        DIR *dir = opendir(tmp_dir);
			if(dir){
			  closedir(dir);
			} else {
			  rc  = __mkdir__(tmp_dir);
			}
		      pthread_mutex_unlock(values->mutex);
		      if(rc ==-1){
	                err = String_new("mkdir(%s), %s", tmp_dir,
				       	strerror(errno));
			break;
		      }
		      sprintf(cwd + strlen(cwd), "/%s", data->subset_name);
		      printf("[%s] tmp_file: %s\n", __func__, cwd);
		      int tmp_fd = open(cwd, O_RDWR | O_CREAT | O_TRUNC, 0600);
		      if(tmp_fd == -1){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			break;
		      } 

	     switch(so->mem_type){
               case SUPR_MEMTYPE_FILE:
		    {
#ifdef USE_MULTI_DIRS
		      char path[PATH_MAX];
		      sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(so->sys_type),
                             data->dd_name, data->subset_name);
                      int fd = open(path,O_RDONLY);
#else
                      int fd = openat(data->dir_fd, data->subset_name,O_RDONLY);
#endif
		      struct stat sb;
                      if(fd == -1  || fstat(fd, &sb) == -1){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			if(fd != -1) close(fd);
			break;
		      }

		      void *val;
		      if((val = malloc(sb.st_size)) == NULL ||
		         read(fd, val, sb.st_size) == -1 ||
		         write(tmp_fd, val, sb.st_size) == -1)
		      {
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			if(val) free(val);
		      }
		      free(val);
		      close(fd);
		    }
		    break;

	       case SUPR_MEMTYPE_SHM:
		    {
		      size_t size;
		      void *mem_ptr = rjni_shm_open((char*) so->val, &size);
		      write(tmp_fd, mem_ptr, size);
		      munmap(mem_ptr, size);
		      /*
		      shm_unlink((char*) so->val);
	              pthread_mutex_lock(shm_names->mutex);
	                vectorRemoveElement(shm_names, (char*) so->val);
	              pthread_mutex_unlock(shm_names->mutex);
		      */
		      ShmCache_dec_ref((char*) so->val);
		    }
		    break;
		    
	       case SUPR_MEMTYPE_MEM:
                    //write(tmp_fd, so, sizeof(so_t) + so->size);
                    write(tmp_fd, so->val, so->size);
		    break;
               default: { 
	               rc = -1;
	               err = String_new("Unimplemented object mem_type: %d",
					 so->mem_type);
	            }
		    break;
	     }

	     close(tmp_fd);
	     if(rc != -1){
                      so_t *s = (so_t *) malloc(sizeof(so_t)+strlen(cwd)+1);
		      memcpy(s, so, sizeof(so_t));
	              free(so);

                      s->ref_count = REF_COUNT_INITIALIZER;
                      s->mem_type = SUPR_MEMTYPE_TMP;
                      s->size = strlen(cwd)+1;

		      memcpy(s->val, cwd, s->size);
                      pthread_mutex_lock(values->mutex);
                        Hashtable_put(values, data->subset_name, s);
                      pthread_mutex_unlock(values->mutex);
	     }
	   }
	   break;
      case DFS_DD_PERSIST_SHM_LEVEL:
	   if(so->mem_type != SUPR_MEMTYPE_SHM)
	   {
	     char *shm_name = __mk_tmpnam__("supr.dfs", data->subset_name);
	     // keep the file suffix
             printf("[%s] so->mem_type: %d (TO: SHM): tmp_name: %s\n", __func__,
			     so->mem_type, shm_name);

	     switch(so->mem_type){
               case SUPR_MEMTYPE_FILE:
		    { 
		    printf("\033[0;32m[%s] Start (file->shm): %s/%s\033[0m\n", __func__,
				    data->dd_name, data->subset_name);
#ifdef USE_MULTI_DIRS
		      char path[PATH_MAX];
		      sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(so->sys_type),
                             data->dd_name, data->subset_name);
                      int fd = open(path,O_RDONLY);
#else
                      int fd = openat(data->dir_fd, data->subset_name,O_RDONLY);
#endif
		      struct stat sb;
                      if(fd == -1  || fstat(fd, &sb) == -1){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			if(fd != -1) close(fd);
			break;
		      }
		      void *mem_ptr = rjni_shm_create(shm_name, sb.st_size);
		      if(!mem_ptr){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
		        close(fd);
			break;
		      }
		      read(fd, mem_ptr, sb.st_size);
		      close(fd);
		      munmap(mem_ptr, sb.st_size);
		    printf("\033[0;32m[%s] Done: %s/%s\033[0m\n", __func__,
				    data->dd_name, data->subset_name);
		    }
		    break;

	       case SUPR_MEMTYPE_TMP:
		    {
		    printf("\033[0;32m[%s] Start (tmp->shm): %s/%s\033[0m\n", __func__,
				    data->dd_name, data->subset_name);
                      int fd = open((char*)so->val, O_RDONLY);
		      struct stat sb;
                      if(fd == -1  || fstat(fd, &sb) == -1){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			if(fd != -1) close(fd);
			break;
		      }
		      void *mem_ptr = rjni_shm_create(shm_name, sb.st_size);
		      if(!mem_ptr){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
		        close(fd);
			break;
		      }
		      read(fd, mem_ptr, sb.st_size);
		      close(fd);
		      munmap(mem_ptr, sb.st_size);
		    printf("\033[0;32m[%s] Done (tmp->shm): %s/%s\033[0m\n", __func__,
				    data->dd_name, data->subset_name);
		    }
		    break;

	       case SUPR_MEMTYPE_MEM:
		    {
		    printf("\033[0;32m%d[%s] Start (mem->shm): %s/%s\033[0m\n",
				   cth->tid, __func__,
				    data->dd_name, data->subset_name);
		      void *mem_ptr = rjni_shm_create(shm_name, so->size);
		      if(!mem_ptr){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			break;
		      }
		      memcpy(mem_ptr, so->val, so->size);
		      munmap(mem_ptr, so->size);
		    printf("\033[0;32m%d[%s] Done: %s/%s\033[0m\n",
				   cth->tid, __func__,
				    data->dd_name, data->subset_name);
		    }
		    break;

               default: { 
	              rc = -1;
	              err = String_new("Unimplemented object mem_type: %d",
					 so->mem_type);
	            }
		    break;
	     }
		      
	     if(rc != -1 ){
	       so_t *s = (so_t*) malloc(sizeof(so_t) + strlen(shm_name)+1);
	       memcpy(s, so, sizeof(so_t));
	       s->mem_type = SUPR_MEMTYPE_SHM;
	       s->size = strlen(shm_name)+1;
	       memcpy(s->val, shm_name, strlen(shm_name)+1);

	       free(so);
	       free(shm_name);  //??

	       /*
	       pthread_mutex_lock(shm_names->mutex);
	         //vectorAdd(shm_names, s->val);
	         vectorAdd(shm_names, strdup(s->val));
	       pthread_mutex_unlock(shm_names->mutex);
	       */

               pthread_mutex_lock(values->mutex);
                 Hashtable_put(values, data->subset_name, s);
               pthread_mutex_unlock(values->mutex);
	     }
		     
	   }
	   break; 
      case DFS_DD_PERSIST_MEM_LEVEL:
	   if(so->mem_type != SUPR_MEMTYPE_MEM) //?
	   { 
	     switch(so->mem_type){
               case SUPR_MEMTYPE_FILE:
		    { 
#ifdef USE_MULTI_DIRS
		      char path[PATH_MAX];
		      sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(so->sys_type),
                             data->dd_name, data->subset_name);
                      int fd = open(path,O_RDONLY);
#else
                      int fd = openat(data->dir_fd, data->subset_name,O_RDONLY);
#endif
		      struct stat sb;
                      if(fd == -1  || fstat(fd, &sb) == -1){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			if(fd != -1) close(fd);
			break;
		      }

		      so_t *s = (so_t*)malloc(sizeof(so_t) + sb.st_size);
		      memcpy(s, so, sizeof(so_t));
		      s->size = sb.st_size;

		      read(fd, s->val, s->size);
		      close(fd);

		      free(so);
		      so = s;

		    }
		    break;

               case SUPR_MEMTYPE_TMP:
		    {
                      int fd = open((char*)so->val, O_RDONLY);
		      struct stat sb;
                      if(fd == -1  || fstat(fd, &sb) == -1){
	                rc = -1;
	                err = String_new("%s", strerror(errno));
			if(fd != -1) close(fd);
			break;
		      }

		      so_t *s = (so_t*)malloc(sizeof(so_t) + sb.st_size);
		      memcpy(s, so, sizeof(so_t));
		      s->size = sb.st_size;

		      read(fd, s->val, s->size);
		      close(fd);

		      unlink((char*)so->val);
		      free(so);
		      so = s;
		    }
		    break;

	       case SUPR_MEMTYPE_SHM:
		    {
		      size_t size;
		      void *mem_ptr = rjni_shm_open((char*) so->val, &size);
                      if(!mem_ptr){
	                rc = -1;
	                err = String_new("%s, %s", (char*)so->val,strerror(errno));
			break;
		      }
		      
		      so_t *s = (so_t*)malloc(sizeof(so_t) + size);
		      memcpy(s, so, sizeof(so_t));
		      s->size = size;

		      memcpy(s->val, mem_ptr, s->size);
		      munmap(mem_ptr, size);

		      /*
		      shm_unlink((char*) so->val);
	              pthread_mutex_lock(shm_names->mutex);
	                vectorRemoveElement(shm_names, (char*) so->val);
	              pthread_mutex_unlock(shm_names->mutex);
		      */
		      ShmCache_dec_ref((char*) so->val);
		      free(so);
		      so = s;

		    }
		    break;
		    
               default: { 
	              rc = -1;
	              err = String_new("Unimplemented object mem_type: %d",
					 so->mem_type);
	            }
		    break;
	     }

	     if(rc != -1){

	       so->mem_type = SUPR_MEMTYPE_MEM;
	       so->ref_count= REF_COUNT_INITIALIZER;

               pthread_mutex_lock(values->mutex);
                 Hashtable_put(values, data->subset_name, so);
               pthread_mutex_unlock(values->mutex);
	     }
		      
	   }
	   break; 
      default: { 
	         rc = -1;
	         err = String_new("Unknown level: %d", data->level);
	       }
	       break;
    }
  }

  printf("\033[0;33m[%s:%d] path: %s/%s ... done!\n", __func__,__LINE__,
		       data->dd_name, data->subset_name);

  task->rc = rc;
  task->err= err;

  supr_socket_conn_t *sc = NULL;
  vector_t *processed = task->processed;

  pthread_mutex_lock(processed->mutex);
    vectorAdd(processed, task);

    printf("[%s] %d/%d\n", __func__, vectorSize(processed), data->count_max);

    if(vectorSize(processed) == data->count_max){
      int n = 0;
      sc = data->conn;
      char *dd_name = dd->name;
      close(data->dir_fd); // FIXME...
      for(int i = vectorSize(processed) -1; i>=0; i--){
        task = (task_t*) vectorElementAt(processed, i);
	if(task->rc == -1)
          n ++;
	else { 
          vectorRemove(processed, i);
	  free(task->data);
	  free(task);
	}
      }
      int fd = sc->efd;
      if(n){
	int rc = -1;
        write(fd, &rc, INT_SIZE);
        write(fd, &n, INT_SIZE);
        for(int i=vectorSize(processed)-1; i>=0; i--){
          task = (task_t*) vectorRemove(processed, i);
	  FD_writeString(fd, task->err->str);
	  free(task->err);
	  free(task->data);
	  free(task);
        }
      } else {
        write(fd, &n, INT_SIZE);
        DD_show(dd_name);
      }
    }
  pthread_mutex_unlock(processed->mutex);

  if(sc){
      //printf("[%s] sc->fd: %d, sc->efd: %d\n", __func__, sc->fd, sc->efd);
      int cmd = DFS_DD_NULL;
      pthread_mutex_lock(backendConn->mutex);
        write(backendConn->fd, &cmd, INT_SIZE);
        sc->fd = sc->efd;
        write(backendConn->fd, &cmd, INT_SIZE);
      pthread_mutex_unlock(backendConn->mutex);
      Vector_destroy(processed);

  }
}









// FIXME
/*
#define SUPR_OBJECT  1
#define R_DATA       2
#define TEXT         3
#define TEXT_CSV     4
#define TEXT_TAB     5
#define UNKNOWN_TYPE 0
int suffix2type(const char *suffix){
  if(suffix == NULL){
    return UNKNOWN_TYPE;
  } else if(strcmp(suffix, "sro")==0){
    return SUPR_OBJECT;
  } else if(strcmp(suffix, "rda")==0){
    return R_DATA;
  } else if(strcmp(suffix, "txt")==0){
    return TEXT;
  } else if(strcmp(suffix, "csv")==0){
    return TEXT_CSV;
  } else if(strcmp(suffix, "tab")==0){
    return TEXT_TAB;
  } else {
    return UNKNOWN_TYPE;
  }
}
*/

extern void socketDestroy(supr_socket_conn_t *sc); 

// Send
void ft_handleDD_get(void *arg)
{

#ifdef DEBUG_OPEN_FILES
	/*
	int __debug_fd = open3("testing", O_CREAT | O_RDWR, 0600);
	if(__debug_fd != -1)
	{ 
	       char buf[256];
	       sprintf(buf, "\033[0;33m%s:%d\033[0m", __FILE__, __LINE__);
	       DFSDATA_fileSet(__debug_fd , buf);
	}
	*/
#endif

  task_t *task = (task_t *) arg;
  supr_socket_conn_t *conn = (supr_socket_conn_t *) task->data;
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  int tid = syscall(SYS_gettid);
  //printf("[%s:%d] dd_name: %s\n", __func__, tid, dd_name);

  read(fd, &len, SIZE_SIZE);
  char subset_name[len];
  read(fd, subset_name, len);

//  int tid = currentThread()->tid;

  //basic_info("dd_name: %s, subset_name: %s\n", dd_name, subset_name);

  //printf("[%s:%d] ddEnv.owner: %d\n", __func__, tid, ddEnvironment->mutex->__data.__owner);

  so_t *data = NULL;
  dd_t *dd = NULL;
  pthread_mutex_lock(ddEnvironment->mutex);
    dd = Hashtable_get(ddEnvironment, dd_name);
  pthread_mutex_unlock(ddEnvironment->mutex);

  if(dd) {
    pthread_mutex_lock(dd->values->mutex);
      data = (so_t*) Hashtable_get(dd->values, subset_name);
    pthread_mutex_unlock(dd->values->mutex);
  }

  //printf("[%s:%d] subset_data: <%p>, data->size: %ld\n", __func__, tid, data, data->size);

  if(data){

    //basic_info("mem_type: %d\n", data->mem_type);
    write(fd, &data->mem_type, INT_SIZE);

    switch(data->mem_type){

      case SUPR_MEMTYPE_FILE:
           {

		   /*
             char *file_name = (char*)(data + 1); // + SIZE_SIZE;
             char pathname[strlen(dd_name) + strlen(subset_name)+8];
             if(data->size == 0){
               sprintf(pathname, "data/%s/%s", dd_name, subset_name);
               file_name = pathname;
             }

             printf("[%s:%d] file_name: %s\n", __func__, tid, file_name);
	     */
#ifdef USE_MULTI_DIRS
	     char path[PATH_MAX];
	     sprintf(path, "%s/data/%s/%s", DD_DIR_PATH(data->sys_type),
			     dd_name, subset_name);
             int file_fd = open(path, O_RDONLY); //// CHECK X
#else
             int file_fd = openat(dd->dir_fd, subset_name, O_RDONLY);
#endif
	     if(file_fd == -1) {
		     error_info("FIXME");
	     }
#ifdef DEBUG_OPEN_FILES
	     { // if(file_fd == -1) /// FIXME
	       char buf[256];
	       sprintf(buf, "%s:%d", __FILE__, __LINE__);
	       DFSDATA_fileSet(file_fd, buf);
	     }
#endif
             struct stat sb;
             int rc = fstat(file_fd, &sb);
             if(rc == -1){
               printf("[%s] Error: %s\n", __func__, strerror(errno)); // FIXME
             }
	     /*
             char *suffix = NULL;
             for(char *p = file_name; *p; p++){
              if(*p == '.') suffix = p+1;
             }
	     */
             //basic_info("suffix: %s type: %d (FILE_SUFFIX_SUPR_OBJECT: %d)\n", subset_name, suffix2type(subset_name), FILE_SUFFIX_SUPR_OBJECT);
        
             switch(suffix2type(subset_name)){
               case FILE_SUFFIX_SUPR_OBJECT: 
	            {
	              data = malloc(sb.st_size); 
                      //int file_fd = open(file_name, O_RDONLY);
                      read(file_fd, data, sb.st_size);
#ifdef DEBUG_OPEN_FILES
		      DFSDATA_fileDelete(file_fd);
#endif
		      close(file_fd);
		      {
	                so_t *so = (so_t*) data;
              //          basic_info("so->size: %ld, sb.st_size: %ld", so->size, sb.st_size);
			if(sizeof(so_t) + so->size != sb.st_size){
			  error_info("FIXME ...");
			  so->size = sb.st_size - sizeof(so_t);
			}
		      }
	              write(fd, data, sb.st_size);
	              free(data);
	            }
	            break;
	       default:
	            { //printf("[%s:%d] Sending (size: %ld)\n", __func__, tid, sb.st_size);

                      //int file_fd = open(file_name, O_RDONLY);
	              data = (so_t *) malloc(sizeof(so_t) + sb.st_size); 
                      read(file_fd, data->val, sb.st_size);
#ifdef DEBUG_OPEN_FILES
		      DFSDATA_fileDelete(file_fd);
#endif
	              close(file_fd);
	              data->ref_count = REF_COUNT_INITIALIZER; // not used...
	              data->mem_type = SUPR_MEMTYPE_FILE;
	              data->sys_type = 0; // TODO
	              data->obj_type = suffix2type(subset_name);
	              data->size = sb.st_size;
	              write(fd, data, sizeof(so_t) + sb.st_size);
	              free(data);
		     // printf("[%s:%d] Sent\n", __func__, tid);
	            }
	            break;
	     }
           } 
           break;

      case SUPR_MEMTYPE_TMP:
           {
	     int file_fd = open((char*)data->val, O_RDONLY);
	     struct stat sb;
	     if(file_fd == -1 || fstat(file_fd, &sb) == -1){
               int rc = -1;
               write(fd, &rc, INT_SIZE);
               char err[256];
	       // thread safe? errno??
               sprintf(err, "%s/%s, %s", dd_name, subset_name, strerror(errno));
               len = strlen(err)+1;
    	       write(fd, &len, SIZE_SIZE);
               write(fd, err, len);
	       if(file_fd != -1) close(file_fd);
	       break;
	     } else {
  printf("\033[0;31m[%s:%d] subset_data: <%p>, data->size: %ld\ntmp_file: %s, size:%ld\n",
		  __func__, tid, data, data->size, (char*)data->val, sb.st_size);
#ifdef DEBUG_OPEN_FILES
// FIXME ??		      DFSDATA_fileDelete(file_fd);
#endif
	              data = (so_t *) malloc(sizeof(so_t) + sb.st_size); 
                      read(file_fd, data->val, sb.st_size);
#ifdef DEBUG_OPEN_FILES
//		      DFSDATA_fileDelete(file_fd);
#endif
	              close(file_fd);
	              data->ref_count = REF_COUNT_INITIALIZER; // not used...
	              data->mem_type = SUPR_MEMTYPE_TMP;
	              data->sys_type = 0; // TODO
	              data->obj_type = suffix2type(subset_name);
	              data->size = sb.st_size;
	              write(fd, data, sizeof(so_t) + sb.st_size);
	              free(data);
		      printf("[%s:%d] Sent\033[0m\n", __func__, tid);
	     }
           } 
           break;

      case SUPR_MEMTYPE_SHM:
           {
	     size_t size;
	     void *mem_ptr = rjni_shm_open((char*) data->val, &size);
  printf("\033[0;31m[%s:%d] subset_data: <%p>, data->size: %ld\nshm_file: %s, size:%ld\n",
		  __func__, tid, data, data->size, (char*)data->val, size);
             so_t so;
	     memcpy(&so, data, sizeof(so_t));
	     so.mem_type = SUPR_MEMTYPE_SHM;
	     so.size = size;
             ssize_t n = write(fd, &so, sizeof(so_t));
             n = write(fd, mem_ptr, size);
	     munmap(mem_ptr, size);
      	     printf("[%s:%d] Sent\033[0m\n", __func__, tid);
           } 
           break;

      case SUPR_MEMTYPE_MEM:
      default:
           {
             ssize_t n = write(fd, data, sizeof(so_t) + data->size);
           }
           break;
    }
      
  } else {

    int rc = -1;
    write(fd, &rc, INT_SIZE);
    char err[256];
    sprintf(err, "Cannot find %s/%s", dd_name, subset_name);
    len = strlen(err)+1;
    write(fd, &len, SIZE_SIZE);
    write(fd, err, len);

  }

  
  struct timeval tv;
  fd_set readfds;

  tv.tv_sec=20;
  tv.tv_usec=0;

  FD_ZERO(&readfds);
  FD_SET(fd, &readfds);

  int ns = select(fd+1, &readfds, NULL, NULL, &tv);
  if(ns > 0 // && FD_ISSET(fd, &readfds)
		  ) {
    ssize_t n = recv(fd, &cmd, INT_SIZE, MSG_PEEK | MSG_DONTWAIT);
    if(n > 0){
      fprintf(stderr, "Error: FIXME (%s:%d)\n", __FILE__, __LINE__);
      error_info("Error: FIXME");
      if(n == sizeof(int) && cmd == 0){
        char msg[256];
	sprintf(msg, "close fd=%d", fd);
        basic_info(msg);
      }
    } /* else if(n==0) {
      fprintf(stderr, "n: %ld (%s:%d)\n", n, __FILE__, __LINE__);
    } */
  } 
  //  socketDestroy(conn);
#ifdef DEBUG_OPEN_FILES
  DFSDATA_socketDestroy(conn);
#else
  socketDestroy(conn);
#endif

#ifdef DEBUG_OPEN_FILES
  /*
        DFSDATA_fileDelete(__debug_fd);
	__debug_fd = open3("testing", O_CREAT | O_RDWR, 0600);
	if(__debug_fd != -1)
	{ 
	       char buf[256];
	       sprintf(buf, "\033[0;33m%s:%d\033[0m", __FILE__, __LINE__);
	       DFSDATA_fileSet(__debug_fd , buf);
	}
        DFSDATA_fileDelete(__debug_fd);
	*/
#endif

}

void handleDD_get(supr_socket_conn_t *conn)
{
  //printf("\033[0;34m[%s] Start, conn->fd: %d\033[0m\n", __func__, conn->fd);
  pthread_mutex_lock(&ft_task_mutex);
    vectorAdd(ft_tasks, newTask(ft_handleDD_get, conn, NULL, NULL, NULL));
    pthread_cond_signal(&ft_task_cond);
  pthread_mutex_unlock(&ft_task_mutex);

}

extern void __supr_malloc_print__();

void __handleDD_put(supr_socket_conn_t *conn, int fd)
{
//  printf("\n\033[0;36m"); __supr_malloc_print__(); printf("\n\033[0m");
  static int call_times = 0;
  call_times ++;
	for(int i=0; i<20; i++) printf("[call: %d]\n", call_times);

  vector_t *processed = newVector(TRUE);
  //int fd = conn->fd;

  supr_thread_t *cth = currentThread();

  /*
  if( call_times>=2) {
    dd_t *dd = Hashtable_get(ddEnvironment, "mydata");
    int n;
    char **keys = Hashtable_keySet(dd->values, &n);
    for(int i=0; i<n; i++){
       so_t *so = (so_t*) Hashtable_get(dd->values, keys[i]); 
       printf("[%s] %s, so: <%p>, size = %ld\n", __func__, keys[i],
		      so, so->size);
    }
	   
	for(int i=0; i<20; i++) printf("[call: %d]\n", call_times);
	free(keys);
  }
  */

  char *_dd_name = NULL;
  int m = 0;
  while(TRUE){
    int cmd;
    read(fd,  &cmd, INT_SIZE);
    size_t len;
    read(fd,  &len, SIZE_SIZE);

    if(len==0) break; // send a task result

    char dd_name[len];
    read(fd,  dd_name, len);
    //printf("[%s] dd_name: %s\n", __func__, dd_name);
    if(! _dd_name) _dd_name = strdup(dd_name);

    read(fd, &len, SIZE_SIZE);
    char subset_name[len];
    read(fd, subset_name, len);

    //printf("[%s] subset_name: %s\n", __func__, subset_name);

    so_t so;
    read(fd, &so, sizeof(so_t));
    //printf("[%s] so.size: %ld\n", __func__, so.size);

    so_t *s = (so_t *) malloc(sizeof(so_t)+so.size);
    read(fd, s + 1, so.size);
    memcpy(s, &so, sizeof(so_t));

    //printf("[%s] s->size: %ld\n", __func__, s->size);

    pthread_mutex_lock(&backend_task_mutex); // to get
      dd_put_data_t *data = (dd_put_data_t *)malloc(sizeof(dd_put_data_t));
      data->ref_count = 1;
      data->dd_name     = strdup(dd_name);
      data->subset_name = strdup(subset_name);
      data->so = s;
      s->ref_count = 1;
    

      vectorAdd(backend_tasks, newTask(backend_handleDD_put, data, processed,
			      &cth->mutex, &cth->cond));
      pthread_cond_signal(&backend_task_cond);
    pthread_mutex_unlock(&backend_task_mutex);

  ////
    {
      int rc = 0;
      write(fd,  &rc, INT_SIZE);
    }
  ////
    m++;
  }

  while(TRUE){
    pthread_mutex_lock(&cth->mutex);

      pthread_mutex_lock(processed->mutex);
	printf("\033[0;31m[%s] Processed: %d, m: %d\033[0m", __func__,
			vectorSize(processed), m);
        if(vectorSize(processed) >= m){
          pthread_mutex_unlock(processed->mutex);
          pthread_mutex_unlock(&cth->mutex);
	  break;
        }
      pthread_mutex_unlock(processed->mutex);

      pthread_cond_wait(&cth->cond, &cth->mutex); // timedwait... ???
    pthread_mutex_unlock(&cth->mutex);
  }

  //if(call_times > 1) sleep(60);
  //printf("\033[0;31m[%s] Processed: %d, m: %d\033[0m", __func__, vectorSize(processed), m);

  for(int i= vectorSize(processed)-1; i>=0; i--){
    task_t *task = (task_t *) vectorRemove(processed, i);
    dd_put_data_t * data = (dd_put_data_t *) task->data;
    //SocketConn_writeString(conn, data->subset_name);
    FD_writeString(fd, data->subset_name);
    write(fd, &task->rc, INT_SIZE);
    if(task->rc == -1){
      //SocketConn_writeString(conn, task->err->str);
      FD_writeString(fd, task->err->str);
    } else {
      //dd_stat_t stat;
      //write(fd, &stat, sizeof(dd_stat_t));
      write(fd, &data->stat, sizeof(dd_stat_t));
      printf("[%s] s_name: %s, size: %ld\n", __func__, data->subset_name,
		      data->stat.st_size);
    }

    if(data->so && --data->so->ref_count == 0)
	    free(data->so);
    free(data->dd_name);
    free(data->subset_name);
    free(data); 
    free(task); 
  }

  size_t len = 0;
  write(fd, &len, SIZE_SIZE);

  vectorDestroy(processed);

  if(_dd_name) {
	  printf("\n\033[0;32mShow: %s\n", _dd_name);
	  DD_show(_dd_name);
	  free(_dd_name);
	  printf("\n\033[0m\n");
  }
//  __supr_malloc_print__();
}


#define handleDD_put(conn) do {     \
  printf("[%s] Start 0\n", __func__);   \
  conn->efd = conn->fd;         \
  conn->fd =  -1;       \
  task_t *task = newTask(backend_handleDD_put, conn, NULL, NULL, NULL);     \
  pthread_mutex_lock(&backend_task_mutex);      \
    vectorAdd(backend_tasks, task);     \
    pthread_cond_signal(&backend_task_cond);    \
  pthread_mutex_unlock(&backend_task_mutex);    \
  printf("[%s] Done 0\n", __func__);    \
} while(0)


#define handleDD_persist(conn) do {	\
  printf("[%s] Start 0\n", __func__);	\
  conn->efd = conn->fd; 	\
  conn->fd =  -1;	\
  task_t *task = newTask(backend_handleDD_persist, conn, NULL, NULL, NULL);	\
  pthread_mutex_lock(&backend_task_mutex);	\
    vectorAdd(backend_tasks, task);	\
    pthread_cond_signal(&backend_task_cond);	\
  pthread_mutex_unlock(&backend_task_mutex);	\
  printf("[%s] Done 0\n", __func__);	\
} while(0)


void handleDD_close(supr_socket_conn_t *conn) {

  int fd = conn->fd;
  int cmd; read(fd,  &cmd, INT_SIZE);
  size_t len; read(fd,  &len, SIZE_SIZE);
  char dd_name[len]; read(fd,  dd_name, len);
//  int save; read(fd,  &save, INT_SIZE);

  printf("[%s] dd_name: %s\n", __func__, dd_name);
#ifndef USE_MULTI_DIRS
  printf("[%s] FIXME: close(dir->fd): %s\n", __func__, dd_name);
#endif

  Hashtable_delete(ddEnvironment, dd_name);
  int rc = 0;
  write(fd, &rc, INT_SIZE);

  return;
}



void handleDD_info(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  int level;
  read(fd,  &level, INT_SIZE);

  printf("[%s] dd_name: %s\n", __func__, dd_name);

  // threads
  for(int i=0; i< vectorSize(backend_taskrunners); i++){
    supr_thread_t *th = (supr_thread_t *)vectorElementAt(backend_taskrunners,i);
    pthread_kill(th->ptid, SIGUSR1);
  }
  for(int i=0; i< vectorSize(file_transfers); i++){
    supr_thread_t *th = (supr_thread_t *)vectorElementAt(file_transfers,i);
    pthread_kill(th->ptid, SIGUSR1);
  }

  cmd = DFS_DD_INFO_RETURN;
  // TODO

}

void handleDD_update(supr_socket_conn_t *conn)
{
  int fd = conn->fd;
  int cmd;
  read(fd,  &cmd, INT_SIZE);
  size_t len;
  read(fd,  &len, SIZE_SIZE);
  char dd_name[len];
  read(fd,  dd_name, len);

  printf("[%s] dd_name: %s\n", __func__, dd_name);

  cmd = DFS_DD_UPDATE_RETURN;
  write(fd,  &cmd, INT_SIZE);
  write(fd,  &len, SIZE_SIZE);
  write(fd,  dd_name, len);

  pthread_mutex_lock(ddEnvironment->mutex);
    dd_t *dd = Hashtable_get(ddEnvironment, dd_name);
    dd_stat_t sb; // TODO
    sb.st_dev = 1001; // testing
    int n;
    char **s_names = Hashtable_keySet(dd->values, &n);
    for(int i=0; i<n; i++){
      printf("[%s] %d: subset_name: %s\n", __func__, i, s_names[i]);
      len = strlen(s_names[i])+1;
      write(fd,  &len, SIZE_SIZE);
      write(fd,  s_names[i], len);

      so_t *so = (so_t *) Hashtable_get(dd->values, s_names[i]);
      sb.st_size = sizeof(so_t) + so->size;
      time_t now = time(NULL);

      sb.st_atim.tv_sec = now;
      sb.st_atim.tv_nsec = 0;

      write(fd,  &sb, sizeof(dd_stat_t));
    }
    free(s_names);
  pthread_mutex_unlock(ddEnvironment->mutex);

  len = 0;
  write(fd,  &len, SIZE_SIZE);
}




void handle_interrupt(supr_socket_conn_t *conn)
{
  int cmd;
  int fd = conn->fd;
  read(fd, &cmd, INT_SIZE);
  printf("[%s] namenodeConn: fd=%d\n", __func__, namenodeConn->fd);
 
  printf("[%s] backend_taskrunners: %s\n", __func__, 
		  (char*) Object_toString(backend_taskrunners));

  for(int i=0; i<vectorSize(backend_taskrunners); i++){
    supr_thread_t *th = (supr_thread_t *)
	    vectorElementAt(backend_taskrunners, i);
    pthread_kill(th->ptid, SIGUSR2);
  }
  /*
  pthread_mutex_lock(&backend_task_mutex);
   printf("backend_tasks: %s\n", (char*) Object_toString(backend_tasks));
  pthread_mutex_unlock(&backend_task_mutex);
  */

  printf("[%s] MORE TODO?\n", __func__);
  int rc = 0;
  write(fd, &rc, INT_SIZE);
}

void startWorker(int port, const char *master)
{

  int rc = isatty(STDOUT_FILENO);
  if(errno) {
      printf("Error: %s (%s:%d)\n", strerror(errno), __FILE__, __LINE__);

      pid_t pid = fork();
      if(pid) return;

      char DFS_CMD_PATH[PATH_MAX];
      {
        sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src");
        chdir(DFS_CMD_PATH);
      }

      sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src/worker");
      //char *dir_name = "00"; //to do
      char sport[64];
      sprintf(sport, "%d", port);
      
      int rc = execl(DFS_CMD_PATH, "worker",
		    "-port", (char*) sport,
		    "-master", (char*) master,
                  (char*) NULL);
      printf("[%s] run dfs_data: rc = %d, %s\n", __func__, rc, strerror(errno));
      exit(0);
     // return;
  }
  if(rc){
    char buf[PATH_MAX];
    int rc = ttyname_r(STDOUT_FILENO, buf, PATH_MAX);
    if(rc) {
          printf("Error: %s (%s:%d)\n", strerror(errno), __FILE__, __LINE__);
          return;
    }
    printf("ttyname: %s\n", buf);
  }

  printf("[%s] port: %d, master: %s\n", __func__, port, master);

#define USE_XTERM 1

  pid_t pid = fork();
  if(pid)
	  return;

  pid = getpid();

 
  char DFS_CMD_PATH[PATH_MAX];
  {
        sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src");
        chdir(DFS_CMD_PATH);
  }

  sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src/worker");


  char *dir_name = "00"; //to do
  char sport[64];
  sprintf(sport, "%d", port);

  if(USE_XTERM && rc){

    char *argv[] = {
          DFS_CMD_PATH,
	  "-port", (char*) sport,
//          "-shm", shm_name,
//          "-dir", (char*) CHAR(asChar(subdir)),
          "-master", (char*) master,
          "--window", 
          (char*) NULL
      };
    supr_xterm_t *xterm = supr_xterm2("worker", argv);
    if(xterm) {
      printf("[%s] run worker: xterm =  %p\n", __func__, xterm);
    } else {
      printf("[%s] run worker: xterm =  %p, %s\n", __func__, xterm,
                  strerror(errno));
    }

  } else {
    int rc = execl(DFS_CMD_PATH, "worker",
		    "-port", (char*) sport,
		    "-master", (char*) master,
                  (char*) NULL);
    printf("[%s] run dfs_data: rc =  %d, %s\n", __func__, rc, strerror(errno));
  }

  exit(0);

}


void startWorkers(supr_socket_conn_t *conn)
{
  int fd = conn->fd; 
  int cmd;          read(fd, &cmd, INT_SIZE);
  int nWorkers;     read(fd, &nWorkers, INT_SIZE);

  size_t len;       read(fd, &len, SIZE_SIZE);
  char master[len]; read(fd, &master, len);



  printf("[%s] cmd: %d, nWorkers: %d, len: %ld, master: %s\n", __func__,
		  cmd, nWorkers, len, master);


  //workerServerConn; // FIX the name

  for(int i=0; i<nWorkers; i++)
    startWorker(workerServerConn->port+1, master);

  int rc = 0;
  write(fd, &rc, INT_SIZE);

}

#undef read

// called by the backend thread...
void handleShutdown(){

  if(Supr_curStrError){
    char *err = malloc(strlen(Supr_curStrError) + strlen(__func__)
		    + strlen("<-")+1);
    sprintf(err, "%s<-%s", __func__, Supr_curStrError);
    Supr_curStrError = err;
  } else {
    Supr_curStrError = (char*)  __func__;
  }
  // wait for threads that are using info_sc ?
  pthread_mutex_lock(&Supr_syncMutex);
    if(info_sc){
      close(info_sc->fd);
      info_sc = NULL;
    }
    if(parent_sc){
      close(parent_sc->fd);
      parent_sc = NULL;
    }
  pthread_mutex_unlock(&Supr_syncMutex);


  // 1. Close connections


  for(int i=vectorSize(socket_connections)-1; i>=0; i--){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)
            vectorElementAt(socket_connections, i);
    close(sc->fd); // Supr_decref???
    free(sc);
  }

  // 2. Cancel pthreads
  supr_thread_t *cth = pthread_getspecific(currentThreadKey);

  for(int i=vectorSize(threads)-1; i>=0; i--){
    supr_thread_t *th = vectorElementAt(threads, i);
    if(th != cth){
      int locked = !pthread_mutex_trylock(&th->mutex);
      if(locked){
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d, state: %s)", th->tid, th->pid, state2char(th->state));
      }else {
        sprintf(msg, "Canceling pthread (tid: %d,  pid: %d)", th->tid, th->pid);
      }
      fprintf(stderr, "%s\n", msg);

      int rc = pthread_cancel(th->ptid);
      if(locked){
        pthread_mutex_unlock(&th->mutex);
      }
      /*
      if(rc == 0){
	void *retval;
        int rc = pthread_join(th->ptid, &retval);
	if(retval == PTHREAD_CANCELED){
          fprintf(stderr, " pthread_join(%d, ...): PTHREAD_CANCELED\n",
			  th->tid);
	} else {
          fprintf(stderr, " pthread_join(%d, ...): %p\n",
			  th->tid, retval);
	}
      }
      */
    }
  }


//  pthread_mutex_unlock(&Supr_syncMutex);
  int rc = pthread_cancel(cth->ptid);
  //pthread_exit(NULL); //??
}

void removeConn(supr_socket_conn_t *conn)
{
  printf("\033[0;31m[%s] //%s:%d\033[0m\n", __func__, conn->host, conn->port);
  int type = conn->type;
  close(conn->fd);
  vectorRemoveElement(socket_connections, conn);

  if(type == DFS_NAMENODE_CONN){
    Supr_curStrError = strdup("lost name node connection");
    handleShutdown();
  }

  free(conn); // FIXME
}

void handleCommand(supr_socket_conn_t *conn)
{
  int fd = conn->fd, cmd;
  {
    //char buf[1024];
    size_t len = 0;
    for( ;len < sizeof(int); ) {
      ssize_t n = recv(fd, &cmd, sizeof(int), MSG_PEEK | MSG_DONTWAIT);
      if(n <= 0 ){
        verbose_info("\033[0;31m%d::recv [%s] conn(fd: %d) is disconnected "
		"(len=%ld)\033[0m", getpid(), __func__, conn->fd, len);
	removeConn(conn);
	return;
      }
      len += n;
    }
    
    debug_info("'%s:%d', cmd: %d (%s)", conn->host, conn->port, cmd,
		    cmd2char(cmd));
  }

  switch(cmd){

    case DFS_DD_CREATE:
         handleDD_create(conn);
         return;

    case DFS_DD_OPEN:
         handleDD_open(conn);
         return;

    case DFS_DD_CLOSE:
         handleDD_close(conn);
         return;

    case DFS_DD_PUT:
         handleDD_put(conn);
         return;

    case DFS_DD_PERSIST:
         handleDD_persist(conn);
         return;

    case DFS_DD_MOVE:
         handleDD_move(conn);
         return;

    case DFS_DD_REMOVE:
         handleDD_remove(conn);
         return;

    case DFS_DD_INFO:
	 printf("\033[0;31m");
         handleDD_info(conn);
	 printf("\033[0m");
         return;

    case DFS_DD_PUT_RETURN:
    case DFS_DD_CLOSE_RETURN:
    case DFS_DD_PERSIST_RETURN:
    case DFS_DD_DATANODE_INFO:

    case DFS_DD_NULL:
         read(fd, &cmd, INT_SIZE);
	 printf("[%s] cmd: %d\n", __func__, cmd);
         read(fd, &cmd, INT_SIZE);
	 printf("[%s] cmd: %d\n", __func__, cmd);
         return;

    case DFS_DD_UPDATE:
         handleDD_update(conn);
         return;

    case DFS_DD_GET:
	 {
	   vectorRemoveElement(socket_connections, conn);
#ifdef DEBUG_OPEN_FILES
           DFSDATA_socketAdd(conn);
#endif
           handleDD_get(conn);
	 }
         return;

	 /*
     case SET_VERBOSE:  // from the info server
         {
           int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
           int rc = 0;
           Supr_verbose = msg[1];
           //write(conn->fd, &rc, INT_SIZE);
         }
         return;

    case SET_DEBUG:  // from the info server
         {
           int msg[2];
           size_t size = read(fd, msg, sizeof(msg));
           int rc = 0;
           Supr_debug = msg[1];

         }
         return; //break;
	 */

    case CLUSTER_SET_OPTIONS:
         {
           read(fd, &cmd, sizeof(int));
           supr_options_t options;
           read(fd, &options, sizeof(supr_options_t));
           //{
             Supr_options.info = options.info;
             Supr_options.debug = options.debug;
             Supr_options.verbose = options.verbose;
             //Supr_options.port = options.port;
             Supr_options.level = options.level;
             Supr_options.timeout = options.timeout;
           //}
           int rc = 0;
           write(fd, &rc, INT_SIZE);
         }
         return;

    case INFO_REGISTER: // from the namenode, wrong name
	 {
           read(fd, &cmd, INT_SIZE);
/*
	   char *init_msg = DD_infoInit();  
           DD_sendInfo(init_msg, 0);
	   free(init_msg);
*/
	 }
         return;

    case SUPR_INTERRUPT: // from the namenode, wrong name
	 handle_interrupt(conn);
         return;

    case DFS_START_WORKERS:
         startWorkers(conn); // from the namenode, wrong name
         return;

    case CLOSE_CONN:
	 {
           read(fd, &cmd, INT_SIZE);
	   removeConn(conn);
	 }
         return;

    case DFS_DDT_CALL:
	 {
           //handleDDT_call(conn);
           //if(!DT_thread) {
	     DT_thread = startDT_thread(conn);
	     vectorAdd(threads, DT_thread);
	     DT_thread_tasks = newVector(TRUE);
	   //}
	   vectorRemoveElement(socket_connections, conn);
	   basic_info("started the DDT_call handler thread %d", DT_thread->tid);
	 }
         return;

    case DFS_DDT_CALL_CANCEL:
	 {
           pthread_mutex_lock(&Supr_syncMutex);
	     DDT_isCancelled = TRUE;
           pthread_mutex_unlock(&Supr_syncMutex);

           read(fd, &cmd, INT_SIZE);
	   int rc = 0;
	   write(fd, &rc, INT_SIZE);
	 }
         return;

    case CLUSTER_PING:
	 {
           read(fd, &cmd, INT_SIZE);
	   int cmd = CLUSTER_PONG;
	   write(fd, &cmd, INT_SIZE);
	 }
         return;

    case CLUSTER_CONTEXT_OBJECTS:
         {
           handleClusterList(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_EXISTS:
         {
           handleClusterExists(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_PUT:
         {
           handleClusterAssign(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_GET:
         {
           handleClusterContextGet(conn, socket_connections);
         }
         return;

    case CLUSTER_CONTEXT_DOCALL:
         {
           handleClusterContextDoCall(conn, SuprEnv);
         }
         return;

    case SET_CONN_PID:
         {
           ssize_t size = read(fd, &cmd, INT_SIZE);
           int pid;
           read(fd, &pid, sizeof(int));
           conn->pid = pid;
           int type;
           read(fd, &type, sizeof(int)); // ?
	  // int rc=0; write(fd, &rc, sizeof(int)); // ?
         }
         return;

     case INFO_SERVER_REGISTER:
         {
           read(fd, &cmd, INT_SIZE);
           int len;
           read(fd, &len, INT_SIZE);
           char buf[len];
           read(fd, buf, len);

           free((char*)info_addr);
           info_addr = strdup(buf);

           basic_info(buf);
           basic_info("\033[0;36mClosing info_sc ...\033[0m");
           pthread_mutex_lock(&Supr_syncMutex);
             if(info_sc){
               close(info_sc->fd);
               free(info_sc);
               info_sc = NULL;
             }
             if(strstr(buf, ":")) {
               info_sc = trySocketOpen1(buf);
               if(info_sc){
                 Supr_registerSocketServer(socketServerConn, info_sc);
                 cmd = CLUSTER_PROC_CMD;
                 write(info_sc->fd, &cmd, sizeof(int));
                 len = strlen(proc_cmd)+1;
                 write(info_sc->fd, &len, sizeof(int));
                 write(info_sc->fd, proc_cmd, len);
                 int rc;
                 read(info_sc->fd, &rc, sizeof(int));
               }
             }
           pthread_mutex_unlock(&Supr_syncMutex);
           int rc = 0;
           write(fd, &rc, INT_SIZE);
         }
         return;

     case CLUSTER_SHUTDOWN:
         {
           pthread_mutex_lock(&Supr_syncMutex);
	   info_sc = NULL;
	   parent_sc = NULL;
           pthread_mutex_unlock(&Supr_syncMutex);
           int msg[2];
	   read(fd, msg, sizeof(msg));
	   int rc = 0;
	   write(fd, &rc, sizeof(int));

//	   close(fd);
	   handleShutdown();
         }
         return; // not reached

    case HTTP_GET:
	 {
	     conn->type = WEB_CLIENT_CONN;
             handleHTTP_GET(conn);
	     //printf("[Datanode@%s] handled cmd %d\n", Supr_hostname, cmd);
	 }
         return;


    default:

	 printf("[Datanode@%s] Error: unknown command, %d (HTTP_GET: %d)\n",
			 Supr_hostname, cmd, HTTP_GET);
	 break;
  }



  char c;
  //int cmd;
  //size_t size = read(fd, &c, 1);
  //size_t size = __read__(fd, &c, 1);
  /*
  int cmd;
  size_t size = read(fd, &cmd, sizeof(int));
  //printf("[%s] size = %ld\n", __func__, size);

  if(size == 0) {
    printf("[%s] fd = %d is disconnected\n", __func__, fd);
    vectorRemoveElement(socket_connections, conn);
    socketDestroy(conn);

    return;
  } else {
    printf("read [%s] size = %ld, cmd = %d\n", __func__, size, cmd);
  }
  */
  static int nZsroSize=0; // FIXME

  while(TRUE){
    size_t size = recv(fd, &c, 1, MSG_PEEK | MSG_DONTWAIT);
    if(size == -1){
	    printf("[%s] size = -1, no data ? %s\n", __func__, strerror(errno));
	    if(errno == EBADF){
              printf("\033[0;31m[%s] fd = %d is disconnected\033[0m\n", __func__, fd);
              vectorRemoveElement(socket_connections, conn);
              socketDestroy(conn);
	    }
	    return;
    } else if(size == 0){
	    printf("[%s] size = 0,  %s\n", __func__, strerror(errno));
	    nZsroSize++;
	    if(nZsroSize>100) sleep(10);
	    
    } else {
	    read(fd, &c, 1);
	    printf(" %0x", c);
    }
  }

}

extern size_t fileWrite(const char*, char *, size_t);
extern char *fileRead(const char* file); 
extern supr_socket_conn_t *socketOpen2(const char *host, int port);

void  pthread_key_destructor(void *data)
{
	printf("[%s] data= %p\n", __func__, data);
}

shm_io_info_t *master_io = NULL;

SEXP startMaster(const char *port, int *master_port)
{
  if(!SUPR_HOMESYS) suprHomeInit();

  char shm_name[128];
  sprintf(shm_name, "supr.master-%d-%d",geteuid(), getpid());
  printf("[%d] %s\n", getpid(), shm_name);

  //SEXP shm_conn = R_shmCreate
  size_t block_size = sysconf(_SC_PAGE_SIZE);
  shm_io_info_t *io = shm_io_create(shm_name, block_size);

  master_io = io;

  SEXP r_io = PROTECT(R_MakeExternalPtr(io, null, null));
  setAttrib(r_io, R_ClassSymbol, mkString("shm_conn"));
  setAttrib(r_io, R_NameSymbol, mkString(shm_name));
  UNPROTECT(1);


  pid_t pid = fork();
  if(pid) {
    fprintf(stderr, "%s: proc %d is to run \"%s\"\n", __func__, pid, "driver");
    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: \"%s\"\033[0m\n", (char*) ptr);
    ptr = shm_io_read(io, io->in, &size, NULL);
    fprintf(stderr, "\033[0;34mshm_read: serverSocket: port = %d\033[0m\n",
                    ((int*) ptr)[0]);
    *master_port = ((int*) ptr)[0];
    return r_io;
  }

  char CMD_PATH[PATH_MAX];
  sprintf(CMD_PATH, "%s/master", SUPR_HOMESYS);
  printf("[%s] cmd path: %s\n", __func__,  CMD_PATH);

  //const char *port = CHAR(asChar(sport));

  int rc = execl(CMD_PATH, "master",
                  "-port", port,
                  "-shm", shm_name,
          (char*) NULL);

  printf("[%s] run master: rc =  %d, %s\n", __func__, rc, strerror(errno));

  exit(0);

//  SEXP conn = connectDriver(SEXP hostname, SEXP sport)
}

char *getNamenodeAddr(){

    if(DFS_namenodeAddr){
      char *addr = strdup(DFS_namenodeAddr);
      return addr;
    }

    char fileName[strlen(SUPR_DFS_HOMEUSR)+strlen("/dfs_name.log")+1];
    sprintf(fileName, "%s/dfs_name.log", SUPR_DFS_HOMEUSR);

    printf("[%s] fileName: %s\n", __func__, fileName);
    /*
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\n", serverConn->port);
    */
    char *addr = fileRead(fileName);

    printf("[%s] addr: %s\n", __func__, addr);

    return addr;
}

void backend_exit(){

  pthread_mutex_lock(&main_thread->mutex);
    main_thread->data = PTHREAD_INTERRUPTED;
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);
  pthread_exit(NULL);
}

void SocketConn_dumper(vector_t *v)
{
  if(!v) {
    fprintf(stdout, "[null]\n");
  }
  for(int i=0; i<vectorSize(v); i++){
    supr_socket_conn_t *sc = (supr_socket_conn_t *)vectorElementAt(v, i);
    fprintf(stdout, "%2d. %s\t//%s:%d, fd:%d\n", i+1, connTypeToStr(sc->type),
		    sc->host, sc->port, sc->fd);
  }
}

void backend_cleanup(void *data){
  basic_info(__func__);
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}

// subdir
int backend_run(int port)
{
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  free(cth->name);
  cth->state = THREAD_STATE_RUNNABLE;
  cth->name = strdup(__func__);

  pthread_cleanup_push(backend_cleanup, NULL);

  verbose_info("port: %s:%d%s", Supr_hostname, port, nports?"":"+");

  //int reuse_addr = port ? SocketConn_reuseAddr : FALSE;
  //supr_socket_conn_t *serverConn = serverSocketOpen(port, reuse_addr);
  supr_socket_conn_t *serverConn = serverSocketOpen3(port, nports, cmd);

  if(!serverConn){
    if(notify_addr)
      Supr_notify(notify_addr, Supr_hostname, CLUSTER_DFSDATANODE_STARTED);
    exit(EXIT_FAILURE);
  }

  socketServerConn = serverConn;
  Supr_options.port = serverConn->port;

  workerServerConn = serverConn; // FIXME?
  workerServerConn->type = DFS_DATANODE_CONN;

  workerServerConn->mutex = (pthread_mutex_t*)
	  malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(workerServerConn->mutex, NULL);

  /*
  backend_2_tasks = newVector(TRUE);
  backend_2 = startBackend_2(currentThread()); // not to be used...
  */

  //shm_names = newVector(TRUE);

  {
    char fileName[strlen("dfs_data.log")+1];
    sprintf(fileName, "dfs_data.log");
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\npid:%d\n", serverConn->port, getpid());
    size_t size = fileWrite(fileName, buf, strlen(buf)+1);

    /*
    printf("[%s:%s] OKAY 2: buf value=%s (pid=%d, tid=%ld)\n",
	       __FILE__,	__func__, buf,
		getpid(), syscall(SYS_gettid));


    printf("[%s] getcwd(): %s\n", __func__, getcwd(buf, 1022));
    */
  }



  //
  if(!socket_connections)
    socket_connections = newVector(TRUE);

  serverConn->pid = getpid();
  vectorAdd(socket_connections, serverConn);
  //

  SocketConn_dumper(socket_connections);



  backendConn = socketOpen2(serverConn->host, serverConn->port);
  if(backendConn){
    backendConn->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(backendConn->mutex, NULL);
  }
  


  // connect master / dfs_namenode
  supr_socket_conn_t * master_conn = NULL;
  {
	  /*
    char fileName[strlen(SUPR_DFS_HOMEUSR)+strlen("/dfs_name.log")+1];
    sprintf(fileName, "%s/dfs_name.log", SUPR_DFS_HOMEUSR);
    char buf[1024];
    sprintf(buf, "//");
    int len = gethostname(buf+2, 1022);
    sprintf(buf + strlen(buf), ":%d\n", serverConn->port);
    char *addr = fileRead(fileName);
    */

    char *addr = getNamenodeAddr();
    if(addr){
      char *str = strstr(addr, ":");
      int master_port = atoi(str+1);
      *str = 0;
      char *host = strstr(addr, "//") ? strstr(addr, "//")+2 : addr;
      master_conn = socketOpen2(host, master_port);
      if(master_conn && master_conn->fd != -1)
      {
	  master_conn->type = DFS_NAMENODE_CONN;
	  master_conn->port = master_port;
	  int msg[] = {DFS_DATANODE_REGISTER, serverConn->port};
	  int size = write(master_conn->fd, msg, sizeof(msg));
	  int pid = getpid();
	  size = write(master_conn->fd, &pid, INT_SIZE);

	  {
	    //SocketConn_writeString(master_conn, SUPR_DFS_HOMEUSR);
	    char *cwd = (char*)malloc(PATH_MAX);
	    getcwd(cwd, PATH_MAX);
	    SocketConn_writeString(master_conn, cwd);
	    free(cwd);
	  }

	  printf("[Datanode:%s] size = %d (%ld)\n", __func__, size,
			  sizeof(msg));
	  if(size == -1){
	    printf("[Datanode:%s] Error,  %s\n", __func__, strerror(errno));
	    // destroy?
	    master_conn = NULL;
	  } else {
            vectorAdd(socket_connections, master_conn); 
	  }
      }
    } else backend_exit();


    /*
    if(!master_conn){
      BEGIN_R_EVAL();

      printf("\n\033[0;33mstartMaster:\n");
	int master_port;
        SEXP shm_conn = startMaster("0", &master_port);
      printf("\n\033[0;33mstartMaster master_port = %d:\n", master_port);
        PrintValue(shm_conn);
        defineVar(install("shm_conn"), shm_conn, R_GlobalEnv);
      printf("\033[0m\n");

        master_conn = socketOpen2("localhost", master_port);
        if(master_conn && master_conn->fd != -1)
	{
//          vectorAdd(socket_connections, master_conn); 
//#define MASTER_CONN 3
	  master_conn->type = MASTER_CONN;
	  master_conn->port = master_port;
//#undef MASTER_CONN
//#define WORKER_REGISTER 12
	  int msg[] = {WORKER_REGISTER, serverConn->port};
	  int size = write(master_conn->fd, msg, sizeof(msg));
	  printf("[Driver:%s] size = %d (%ld)\n", __func__, size,
			  sizeof(msg));
	  if(size == -1){
	    printf("[Driver:%s] Error,  %s\n", __func__, strerror(errno));
	    // destroy?
	    master_conn = NULL;
	  } else {
            vectorAdd(socket_connections, master_conn); 
	  }
//#undef WORKER_REGISTER
	}

      END_R_EVAL();


    }
    */

  }
  namenodeConn = master_conn;

  //
  {
//    basic_info("\033[0;32mFROM A DATANODE 01\033[0m");
    if(namenodeConn)
      parent_sc = trySocketOpen2(namenodeConn->host, namenodeConn->port);
    /*
    close(info_sc->fd);
    free(info_sc); // FIXME
    info_sc = NULL;
    */

//    basic_info("\033[0;31mFROM A DATANODE 02\033[0m");
  }
  //


  /*
  if(info_sc) {
    info_sc->type = INFO_CONN;
    vectorAdd(socket_connections, info_sc);
  }
  */

  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_signal(&main_thread->cond);
  pthread_mutex_unlock(&main_thread->mutex);

  ft_tasks = newVector(FALSE);
  file_transfers = newVector(FALSE);

  backend_tasks = newVector(FALSE);
  backend_taskrunners = newVector(FALSE);

  int nFiletransfers = 4; 
  for(int i=0; i<nFiletransfers; i++){
    supr_thread_t *th = startTaskrunner(currentThread());
    vectorAdd(backend_taskrunners, th);
  }
  for(int i=0; i<nFiletransfers; i++){
    supr_thread_t *th = startTaskrunner(NULL);
    vectorAdd(file_transfers, th);
  }

  if(notify_addr){
    char by[strlen(serverConn->host)+32];
    sprintf(by, "%s:%d", serverConn->host, serverConn->port);
    Supr_notify(notify_addr, by, CLUSTER_DFSDATANODE_STARTED);
  }


  while(TRUE) {
      struct timeval tv;
      tv.tv_sec=5000;
      tv.tv_usec=50000;

      fd_set readfds;
      FD_ZERO(&readfds);

      //int fd = serverConn->fd;
      int max_fd = 0;

      // lock ...
      //printf("\n");
      for(int i=0; i<vectorSize(socket_connections); i++){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 

	//conn->print(conn);
        int fd = conn->fd;

	if(fd<=2) continue;

        FD_SET(fd, &readfds);

	if(fd > max_fd) max_fd = fd;
      }



      int ns = select(max_fd+1, &readfds, NULL, NULL, &tv);
      if(ns <= 0){
        if(ns==0) continue;

        if(ns == -1){
	    basic_info(msg);
	    sprintf(msg, "Error in select(...), %s", strerror(errno));
	    if(errno == EINTR){
		    continue;
	    } else
	      exit(EXIT_FAILURE);
        }
            //printf("Warning (%s): select()=%d\n", __func__, ns);
      } /*  else {
            printf("%s: select()=%d\n", __func__, ns);
            printf("%s: FD_ISSET(serverConn->fd, &readfds) = %d\n", __func__,
               FD_ISSET(serverConn->fd, &readfds));
      }*/ 

      for(int i = vectorSize(socket_connections)-1; i>=0; i--){
        supr_socket_conn_t *conn = (supr_socket_conn_t *)
                 vectorElementAt(socket_connections, i); 
        int fd = conn->fd;
        if(!FD_ISSET(fd, &readfds))
	       	continue;

	if(conn == serverConn){
          supr_socket_conn_t *clientConn = serverSocketAccept(serverConn);
          //printf("\033[0;34m[Driver:%s] clientConn->fd = %d\033[0m\n", __func__, clientConn->fd);

	  if(clientConn && clientConn->fd != -1){
            vectorAdd(socket_connections, clientConn); 
	  }
	} else {
          handleCommand(conn);
	}

	/*
        if(Supr_debug){
	  sprintf(msg, "i: %d, vectorSize(): %d", i, vectorSize(socket_connections));
          basic_info(msg);
        }
	*/
      }

      //sleep(1);
  }



  //sleep(60);
//  int k = FOPEN_MAX;

  pthread_cleanup_pop(TRUE);

  return 0;

}

//extern supr_thread_t *newThread(pthread_t ptid, pid_t, pid_t tid, int state);

void *backend_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  //printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW, (unsigned long) &data);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);


  int port = ((int*)data)[0];
  printf("[%s] port: %d\n", __func__, port);

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  backend_run(port);

  pthread_exit(th);
  return NULL;
}

SEXP jobSubmit(SEXP);
SEXP help(SEXP);

typedef struct callable_struct {
  char *name;
  char *par_names;
  SEXP (*func)(SEXP args); // args: pairlist
  char *doc;
} callable_t;

callable_t R_callable_functions[] =
{
  { "help",   "(topic)",   help, "..." },
  { "submit", "(expr, data, ...)", jobSubmit, "..." },
};

SEXP jobSubmit(SEXP args){
  return R_NilValue;
}

SEXP help(SEXP topic){
  if(TYPEOF(topic) == NILSXP){
    return mkString("TO DO");
  } else {

    PrintValue(topic);

    const char *name = CHAR(asChar(topic));
    for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
      if(strcmp(R_callable_functions[i].name, name)==0){
        return mkString(R_callable_functions[i].doc);
      }
    }
    errorcall(R_NilValue, "no doc is available on '%s'", name);
    return R_UnboundValue;

  }
}

//supr_thread_t *startTaskrunner(supr_thread_t *executor);



void executor_run(int nTaskrunners)
{
  //workerServerConn = serverConn;
  

  // wait if no workerServerConn
  for(;;){
    if(workerServerConn)
	    break;
    printf("Waiting for worker connection...\n");
    sleep(1);
  }

  supr_socket_conn_t *sc2worker = NULL;
  if(workerServerConn) { // sync ...
    printf("[%s] executor to worker conn: //%s:%d\n", __func__,
		    workerServerConn->host,
		    workerServerConn->port);
    sc2worker = socketOpen(workerServerConn);
  }

  supr_socket_conn_t *sc2driver = NULL;

  // wait if no driverServerConn
  for(;;){
    if(driverServerConn)
	    break;
    printf("Waiting for driver connection...\n");
    sleep(1);
  }

  if(driverServerConn) {
    printf("[%s] executor to driver conn: //%s:%d\n", __func__,
		    driverServerConn->host,
		    driverServerConn->port);
    sc2driver = socketOpen(driverServerConn);
  }

  if(sc2worker){
    sc2worker->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(sc2worker->mutex, NULL);
  }
  if(sc2driver){
    sc2driver->mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(sc2driver->mutex, NULL);
  }

  supr_thread_t *currentThread = (supr_thread_t *)
		  pthread_getspecific(currentThreadKey);

  executor_property_t *properties = (executor_property_t *)
	  malloc(sizeof(executor_property_t));
  currentThread->properties = properties;
  properties->sc2driver = sc2driver;
  properties->sc2worker = sc2worker;


  pthread_mutex_lock(&currentThread->mutex);
    //  pthread_cond_wait(&currentThread->cond, &currentThread->mutex);
    currentThread->state = THREAD_STATE_RUNNABLE;
  pthread_mutex_unlock(&currentThread->mutex);

  vector_t *taskrunners = newVector(FALSE);
  //printf("[%s] %s\n", taskrunners->class->toString(taskrunners->class, taskrunners));
  // checking..
  for(int i=0; i<nTaskrunners; i++){
    supr_thread_t *tr = startTaskrunner(currentThread);
    vectorAdd(taskrunners, tr);
  }

  while(TRUE){

    int isInterrupted = FALSE;

    pthread_mutex_lock(&currentThread->mutex);
      currentThread->state = THREAD_STATE_WAITING;
      currentThread->data = NULL;
      pthread_cond_wait(&currentThread->cond, &currentThread->mutex);
      printf("[%s:%d (excutor)] NOTIFIED\n", __func__, currentThread->tid);

      thread_info_t *info = (thread_info_t *) currentThread->data;
      currentThread->data = NULL;
      if(!info){
        pthread_mutex_unlock(&currentThread->mutex);
	continue;
      }

      if(info->type == INTERRUPT){
        printf("[%s:%d (executor)] THREAD INTERRUPTED\n", __func__,
		       	currentThread->tid);
	isInterrupted = TRUE;
      }

      currentThread->state = THREAD_STATE_RUNNABLE;

      if(info->type == NEW_JOB){
        void *object = info->data; // currentThread->data;
        if(object){
          class_t *class = NULL; (class_t*) ((void **) object)[0];
          //class_t *
	  class = ((object_t*)object)->class;
          const char *str = class->toString(class, object);
          //printf("[%s:%d] data: %s\n", __func__, __LINE__, str);

	  if(class == WorkerJob_class){

            if(driverServerConn && sc2driver == NULL) 
	    {
	      for(int i=0; ; i++) {
                sc2driver = socketOpen(driverServerConn);
	        if(sc2driver == NULL) {
		  printf("%d: Connecting to driver...\n", __LINE__);
	          sleep(1);
	        }
	        else break;
	      }
	     
	    }

	    ((w_job_t*)object)->sc = sc2driver; // delete me later ...
            properties->sc2driver = sc2driver;

	    for(int i=0; i < vectorSize(taskrunners); i++){
              supr_thread_t *tr=(supr_thread_t *)vectorElementAt(taskrunners,i);
	      class_t *class = classOf(tr);
              printf("[%s:%d] tr = %s\n",__func__,__LINE__, objectToString(tr));


	      pthread_mutex_lock(&tr->mutex);
	        //tr->data = object;
	        tr->data = info;
	        pthread_cond_signal(&tr->cond);
	      pthread_mutex_unlock(&tr->mutex);

	      if(tr->state == THREAD_STATE_TERMINATED){
	        void *val;
                pthread_join(tr->ptid, &val);
	        threadDestroy(tr);
	        if(val == PTHREAD_CANCELED){
                  printf("[%s:%d] canceled\n", __func__, __LINE__);
	        } else {
                  printf("[%s:%d] retval = <%p>\n", __func__, __LINE__, val);
                  printf("[%s:%d] retval = %s\n",__func__,__LINE__,(char*) val);
	        }

                tr = startTaskrunner(currentThread);
	        pthread_mutex_lock(&tr->mutex);
	          //tr->data = object;
	          tr->data = info;
	        pthread_mutex_unlock(&tr->mutex);
                vectorSet(taskrunners, i, tr);

	      }

	      if(isInterrupted){
	      //pthread_kill(tr->ptid, SIGUSR1);
	        tr->data = PTHREAD_INTERRUPTED;
	      }

	    }

	  }


        }
      } else if(info->type == INTERRUPT ){
        printf("[%s:%d] INTERRUPT, TOD0 ...\n",__func__,__LINE__);
        void *object = info->data; // currentThread->data;
        if(object){
          class_t *class = ((object_t*)object)->class;
	  if(class == WorkerJob_class){
	    for(int i=0; i < vectorSize(taskrunners); i++){
              supr_thread_t *tr=(supr_thread_t *)vectorElementAt(taskrunners,i);
	      pthread_mutex_lock(&tr->mutex);
	        pthread_cond_signal(&tr->cond);
	        //tr->data = object;
	        tr->data = info;
		pthread_kill(tr->ptid, SIGINT);
	      pthread_mutex_unlock(&tr->mutex);
	    }
	  }
	}
      }
    pthread_mutex_unlock(&currentThread->mutex);
  }

}

#define  DEFAULT_TASKRUNNER_TIMEOUT 600

so_t *readObject(int fd){
  so_t so;
  read(fd, &so, sizeof(so_t));
  so_t *s = (so_t *) malloc(sizeof(so_t) + so.size);
  read(fd, s+1, so.size);
  memcpy(s, &so, sizeof(so_t));
  return s;
}

void TR_registerTaskrunner(w_job_t *job, pid_t tr_pid, shm_io_info_t *io)
{
  int tr_id = -1;
  so_t *s = NULL;
  pthread_mutex_lock(&job->mutex);

    //if(job->count==0 && vectorSize(job->taskrunners)>0)
    if(job->stage)
    { // too late>
      shm_io_write(io, io->out, &tr_id, sizeof(int)); 
    } else
    {
      const char *host = workerServerConn->host;
      int port = workerServerConn->port;
      char tr_addr[strlen(host)+64];
      sprintf(tr_addr, "//%s:%d#%d",host, port, tr_pid);

      char msg[4*sizeof(int)+strlen(tr_addr)+1];
      int *intVal = (int*) msg;
      intVal[0] = CLUSTER_BYTE_MSG; 
      intVal[1] = CLUSTER_TASKRUNNER_REGISTER;
      intVal[2] = job->id;
      intVal[3] = strlen(tr_addr)+1;
      sprintf(msg+4*sizeof(int), "%s", tr_addr);
      int fd = job->sc->fd;
      write(fd, msg, sizeof(msg));
      read(fd, &tr_id, sizeof(int));
      printf("[%s] tr_id: %d\n", __func__, tr_id);

      shm_io_write(io, io->out, &tr_id, sizeof(int)); 

      if(tr_id != -1){

	vectorAdd(job->taskrunners, strdup(tr_addr));
        job->count++;

        so_t so; // make this into a function
	read(fd, &so, sizeof(so_t));
	s = (so_t *) malloc(sizeof(so_t)+so.size);
	memcpy(s, &so, sizeof(so_t));
	read(fd, s + 1, s->size);


      } else {
        job->stage++;
      }
    }
  pthread_mutex_unlock(&job->mutex);

  if(s) {
    shm_io_write(io, io->out, s, sizeof(so_t) + s->size);
    free(s);
  }
}


void combine(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job)
{
  int job_id = ((int*)ptr)[1]; // job->id;
  int tr_id  = ((int*)ptr)[2]; 
  int id_no  = ((int*)ptr)[3];

  printf("[%s:%ld] job_id: %d(%d) tr_id: %d\n", __func__,
		  syscall(SYS_gettid),
		  job_id, job->id, tr_id);

  so_t so = {0,0,0, 0, 0};
  char *shm_name = NULL;
  char *uri_name = NULL;

  pthread_mutex_lock(&job->mutex);
    if(job->result){
      printf("\033[0;32mTake it (job->count=%d)\n\033[0m", job->count);
      so.obj_type = SUPR_SHM_NAME;
      shm_name = job->result;
      job->result = NULL;
    } else {
      printf("\033[0;33mLeave it (job->count=%d)\n\033[0m", job->count);
      char buf[256];
      sprintf(buf, "RTR_%d_TASK_%d_%d_%d", UID, job_id, tr_id,id_no);
      job->result = strdup(buf);
      job->count --;
      if(job->count){
        so.obj_type = SUPR_NILSXP; // done, without the final result
      } else {
        printf("\033[0;34mCluster-level Combine!\n\033[0m");
	supr_socket_conn_t *conn = job->sc; // FIXME, use one sc per executor?
	int cmd = CLUSTER_BYTE_MSG;
	write(conn->fd, &cmd, sizeof(int));
	write(conn->fd, ptr, size);
	int len = strlen(job->result)+1;
	write(conn->fd, &len, sizeof(int));
	write(conn->fd, job->result, len);

	//so_t so;
	read(conn->fd, &so, sizeof(so_t));
        printf("\033[0;34mso.obj_type: %d\n\033[0m", so.obj_type);
	if(so.obj_type == SUPR_URI){
	  //int len;
	  //read(conn->fd, &len, sizeof(int));
	  //uri_name = (char*) malloc(len);
	  //read(conn->fd, uri_name, len);
	  uri_name = (char*) malloc(so.size);
	  read(conn->fd, uri_name, so.size);
          printf("\033[0;34muri_name: \"%s\"\n\033[0m", uri_name);

	  job->count ++;
	  job->result = NULL;
	} else {
	  job->result = NULL;
          job->count  = vectorSize(job->taskrunners);
	}
      }
    }
  pthread_mutex_unlock(&job->mutex);

  if(shm_name){
    so.size = sizeof(int)+strlen(shm_name)+1;
    unsigned char buf[sizeof(so_t)+so.size];
    memcpy(buf, &so, sizeof(so_t));
    ((int*)(buf+sizeof(so_t)))[0] = strlen(shm_name)+1;
    sprintf(buf+sizeof(so_t)+sizeof(int), "%s", shm_name);
    free(shm_name);
    shm_io_write(io, io->out, buf, sizeof(buf));

  } else if(uri_name){ // let R process do this

	  /*
    char *host = strstr(uri_name, "//")+2;
    char *str = strstr(uri_name, ":");
    *str = 0; str++;
    int port = atoi(str);
    char *data_name = strstr(str, "#")+1;

    printf("[%s] Connecting %s:%d\n", host, port);
    int sc_fd = socket_client(host, port);
    // check error...
    int cmd = TR_CLUSTER_GET;
    write(sc_fd, &cmd, sizeof(int));
    int len = strlen(data_name)+1;
    write(sc_fd, &len, sizeof(int));
    write(sc_fd, data_name, len);
    so_t so;
    read(sc_fd, &so, sizeof(so_t));
    so_t *s = (so_t*) malloc(sizeof(so_t) + so.size);
    memcpy(s, &so, sizeof(so_t));
    read(sc_fd, s +1, so.size);

    free(uri_name);
    char buf[1];
    shm_io_write(io, io->out, buf, sizeof(buf));
    */

	  /*
    so.size = sizeof(int)+strlen(uri_name)+1;
    unsigned char buf[sizeof(so_t)+so.size];
    memcpy(buf, &so, sizeof(so_t));
    ((int*)(buf+sizeof(so_t)))[0] = strlen(uri_name)+1;
    sprintf(buf+sizeof(so_t)+sizeof(int), "%s", uri_name);
    free(uri_name);
    */

    so.size = strlen(uri_name)+1;
    unsigned char buf[sizeof(so_t)+so.size];
    memcpy(buf, &so, sizeof(so_t));
    sprintf(buf+sizeof(so_t), "%s", uri_name);

    shm_io_write(io, io->out, buf, sizeof(buf));


  } else {
    shm_io_write(io, io->out, &so, sizeof(so_t));
  }
}


void combine_bykey_get(shm_io_info_t *io, w_job_t *job)
{
  static const char *KEY_SEP = ";";
  char *key = NULL;

  printf("[%s] ...\n", __func__);
  
  vector_t *shm_names = NULL;
  pthread_mutex_lock(&job->mutex);
    
    cbk_t *cbk = job->cbk;
    if(cbk->count){
      key =  cbk->keys[--cbk->count];
      shm_names = hashtableGet(cbk->shm_names, key);
    }

  pthread_mutex_unlock(&job->mutex);

  if(key){
   
      int len = strlen(key)+1;
      for(int i=0; i< vectorSize(shm_names); i++)
        len += strlen((char*) vectorElementAt(shm_names, i))+1;

      char buf[len];
      memcpy(buf, key, strlen(key));
      len = strlen(key);
      for(int i=0; i< vectorSize(shm_names); i++)
      {
        char *s = (char*) vectorElementAt(shm_names, i);
	buf[len++] = KEY_SEP[0];
	memcpy(buf+len, s, strlen(s));
	len += strlen(s);
      }
      buf[len++] = 0;

      printf("[%s] buf: %s\n", __func__, buf);

      shm_io_write(io, io->out, buf, len);

  } else {
  
      //so_t so = {0,0,0, SUPR_UNBOUND_VALUE, 0};
      shm_io_write(io, io->out, (void*)KEY_SEP, 1); // FIXME 

  }
}

/*
typedef struct cbk_struct {
  pthread_cond_t cond;
  hashtable_t *shm_names;
  char **keys;
  int nkeys;
  int count;
} cbk_t;
*/



void combine_bykey(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job)
{
  static const char *KEY_SEP = ";";

  if(size == 3*sizeof(int)) { // nkey == 0??
    combine_bykey_get(io, job);
    return;
  }

  int job_id = ((int*)ptr)[1]; // job->id;
  int tr_id  = ((int*)ptr)[2]; 
  int nkeys  = ((int*)ptr)[3];

  printf("[%s:%ld] job_id: %d(%d) tr_id: %d, nkeys: %d\n", __func__,
	  syscall(SYS_gettid), job_id, job->id, tr_id, nkeys);


  pthread_mutex_lock(&job->mutex);
    char *str = (char*)(ptr + 4*sizeof(int));
    printf("[%s] keys: \"%s\"\n", __func__, str);
    int len=0;
    char *shm_name = strdup(strtok(str, KEY_SEP));
    char *keys[nkeys];
    while(str = strtok(NULL, KEY_SEP)){
      printf("[%s] [%d/%d]: \"%s\"\n", __func__, len+1, nkeys, str);
      keys[len++] = strdup(str); // free???
    }
    free(ptr);

    printf("[%s] job->count: %d\n", __func__, job->count);

    if(job->count == vectorSize(job->taskrunners)){
      job->cbk = (cbk_t*) malloc(sizeof(cbk_t));
      job->cbk->shm_names = newHashtable(FALSE);
      pthread_cond_init(&job->cbk->cond, NULL);
      job->cbk->keys = NULL;
      job->cbk->nkeys = 0;
      job->cbk->count = 0;

    }

    hashtable_t *shm_names = job->cbk->shm_names;
    for(int i=0; i<nkeys; i++){
      vector_t *names = (vector_t *) hashtableGet(shm_names, keys[i]);
      if(names == NULL){
        names = newVector(FALSE);
        hashtablePut(shm_names, keys[i], names);
      }
      vectorAdd(names, shm_name);
    }
    job->count--;
    if(job->count){
      pthread_cond_wait(&job->cbk->cond, &job->mutex);
    } else {
      char **keys = hashtableKeySet(shm_names, &nkeys);
      supr_socket_conn_t *conn = job->sc;
      len = 0;
      for(int i=0; i<nkeys; i++) len += strlen(keys[i])+1;
      char *line = (char*)malloc(len);
      len = 0;
      for(int i=0; i<nkeys; i++) {
        if(i>0) line[len++] = KEY_SEP[0];
	memcpy(line + len, keys[i], strlen(keys[i]));
	len += strlen(keys[i]);
      }
      line[len++] = 0;
      printf("[%s] keys (to driver): \"%s\"\n", __func__, line);
      int args[]= {CLUSTER_BYTE_MSG, TR_COMBINE_BYKEY_INIT, job_id, tr_id, 
	     nkeys, len};
      write(conn->fd, args, sizeof(args));
      write(conn->fd, line, len);
      so_t so;
      read(conn->fd, &so, sizeof(so_t));
      printf("[%s] so.obj_type = %d\n", __func__, so.obj_type);
      job->cbk->keys = keys;
      job->cbk->nkeys = nkeys;
      job->cbk->count = nkeys;
      pthread_cond_broadcast(&job->cbk->cond);
    }

  pthread_mutex_unlock(&job->mutex);

  combine_bykey_get(io, job);

}

void thread_sync(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int));
  printf("[%s] SYNC: %s\n", __func__, mutex);

  string_t *mutex_str = newString(mutex);

  supr_thread_t *cth = currentThread();

  pthread_mutex_lock(syncEnvironment->mutex);
    vector_t *sync_queue = (vector_t *)
	    hashtableGet(syncEnvironment, mutex);
    if(! sync_queue){
      sync_queue = newVector(FALSE);
      hashtablePut(syncEnvironment, mutex, sync_queue);
    }
    vectorAdd(sync_queue, cth);
  pthread_mutex_unlock(syncEnvironment->mutex);

  pthread_mutex_lock(&cth->mutex);
    pthread_mutex_lock(exec_prop->sc2worker->mutex);
      int cmd = TR_CLUSTER_SYNC;
      write(exec_prop->sc2worker->fd, &cmd, sizeof(int)); 
      writeString(exec_prop->sc2worker->fd, mutex_str);
    pthread_mutex_unlock(exec_prop->sc2worker->mutex);

    printf("[%s:%d] SYNC: waiting\n", __func__, cth->tid);
    printf("[%s:%d] SYNC: thread mutex owner: %d\n", __func__, cth->tid,
		    cth->mutex.__data.__owner);
    pthread_cond_wait(&cth->cond, &cth->mutex);
    printf("[%s:%d] SYNC: continue\n", __func__, cth->tid);
  pthread_mutex_unlock(&cth->mutex);
  int rc = 0;
  shm_io_write(io, io->out, &rc, INT_SIZE);
}

void thread_unsync(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int));
  printf("[%s] UNSYNC: %s\n", __func__, mutex);

  string_t *mutex_str = newString(mutex);

  supr_thread_t *cth = currentThread();

  pthread_mutex_lock(syncEnvironment->mutex);
    vector_t *sync_queue = (vector_t *)
	    hashtableGet(syncEnvironment, mutex);
    vectorRemoveElement(sync_queue, cth);
  pthread_mutex_unlock(syncEnvironment->mutex);

  pthread_mutex_lock(exec_prop->sc2worker->mutex);
      int cmd = TR_CLUSTER_UNSYNC;
      write(exec_prop->sc2worker->fd, &cmd, sizeof(int)); 
      writeString(exec_prop->sc2worker->fd, mutex_str);
  pthread_mutex_unlock(exec_prop->sc2worker->mutex);

  int rc = 0;
  shm_io_write(io, io->out, &rc, INT_SIZE);
}

// ptr -> char args[sizeof(int)+ sizeof(double)+ strlen(m)+1];
void cluster_wait(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int) + sizeof(double));
  double timeout = *((double*) (ptr+sizeof(int)));
  printf("[%s] WAIT: %s, %f\n", __func__, mutex, timeout);

  string_t *mutex_str = newString(mutex);
  supr_thread_t *cth = currentThread();

  pthread_mutex_lock(waitEnvironment->mutex);
    vector_t *wait_queue = (vector_t *)
	    hashtableGet(waitEnvironment, mutex);
    if(! wait_queue){
      wait_queue = newVector(FALSE);
      hashtablePut(waitEnvironment, mutex, wait_queue);
    }
    vectorAdd(wait_queue, cth);
  pthread_mutex_unlock(waitEnvironment->mutex);

  int rc = 0;
  pthread_mutex_lock(&cth->mutex);
    pthread_mutex_lock(exec_prop->sc2worker->mutex);
      int cmd = TR_CLUSTER_WAIT;
      write(exec_prop->sc2worker->fd, &cmd,      INT_SIZE); 
      write(exec_prop->sc2worker->fd, &cth->tid, INT_SIZE); 
      write(exec_prop->sc2worker->fd, &timeout,  DOUBLE_SIZE); 
      writeString(exec_prop->sc2worker->fd, mutex_str);
    pthread_mutex_unlock(exec_prop->sc2worker->mutex);

    printf("[%s:%d] WAIT: waiting\n", __func__, cth->tid);
    printf("[%s:%d] WAIT: thread mutex owner: %d\n", __func__, cth->tid,
		    cth->mutex.__data.__owner);

    cth->data = NULL;
    /*
    if(timeout>0) {
      struct timespec wait;
      clock_gettime(CLOCK_REALTIME, &wait);
      wait.tv_sec += (long) timeout;
      pthread_cond_timedwait(&cth->cond, &cth->mutex, &wait);

      if(!cth->data) rc = 1;
    } else {
      pthread_cond_wait(&cth->cond, &cth->mutex);
    }
    */
    pthread_cond_wait(&cth->cond, &cth->mutex);
    if(cth->data == PTHREAD_TIMEOUT)
	    rc = 1;

    printf("\033[0;31m[%s:%d] WAIT: continue, rc=%d\n", __func__, cth->tid,
		    rc);
  pthread_mutex_unlock(&cth->mutex);
  shm_io_write(io, io->out, &rc, INT_SIZE);
}

void cluster_notify(shm_io_info_t *io, void *ptr, size_t size, w_job_t *job,
		executor_property_t *exec_prop)
{
  char *mutex = (char*) (ptr+sizeof(int));
  double timeout = *((double*) (ptr+sizeof(int)));
  printf("[%s] NOTIFY: %s\n", __func__, mutex);

  string_t *mutex_str = newString(mutex);

  /*
  pthread_mutex_lock(exec_prop->sc2worker->mutex);
      write(exec_prop->sc2worker->fd, ptr,  INT_SIZE); 
      writeString(exec_prop->sc2worker->fd, mutex_str);
  pthread_mutex_unlock(exec_prop->sc2worker->mutex);
  */

  pthread_mutex_lock(exec_prop->sc2driver->mutex);
      int cmd = CLUSTER_BYTE_MSG;
      write(exec_prop->sc2driver->fd, &cmd, INT_SIZE); 
      write(exec_prop->sc2driver->fd, ptr,  INT_SIZE); 
      writeString(exec_prop->sc2driver->fd, mutex_str);
  pthread_mutex_unlock(exec_prop->sc2driver->mutex);

  DECREASE_REF(mutex_str);

  int rc = 0;
  shm_io_write(io, io->out, &rc, INT_SIZE);
}


void C_Taskrunner_SigactionInt(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m>>>>>>>>>> %s <<<<<<<<<<\033[0m\n", __func__);
  fprintf(stderr, "\033[0;31m[%s] pthread.self() = %ld\033[0m\n", __func__,
          pthread_self());
  c_backtrace();

  supr_thread_t *currentThread = (supr_thread_t *)
		  pthread_getspecific(currentThreadKey);

  thread_info_t *info = (thread_info_t *) currentThread->data;

  taskrunner_env_t *env = (taskrunner_env_t *)
     pthread_getspecific(taskrunnerThreadKey);

  if(env->job == info->data){
    fprintf(stderr, "\033[0;31m[%s] TO DO ...\033[0m\n", __func__);
    env->isInterrupted = TRUE;
    //kill(env->R_pid, SIGINT);
    kill(env->R_pid, SIGUSR2);
  }
  // ignore otherwise
  // to do ...
}

// check the function ...
extern int shm_io_destroy (shm_io_info_t *io);
extern so_t *SO_read(int fd);

void taskrunner_cleanup(void *data){
  basic_info(__func__);
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}
void taskrunner_lock_cleanup(void *data){
  basic_info(__func__);
  pthread_mutex_t *ptr = (pthread_mutex_t *)data;
  int owner = ptr->__data.__owner;
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  if(owner == cth->tid)
	  pthread_mutex_unlock(ptr);
}
// executor = NULL: file_transfers
void taskrunner_run(supr_thread_t *executor)
{
  pthread_cleanup_push(taskrunner_cleanup, NULL);

  //executor_property_t *exec_properties = (executor_property_t *) executor->properties;

  vector_t *stacktrace = (vector_t*) pthread_getspecific(stacktraceKey);
  vectorAdd(stacktrace, strdup(__func__));

  supr_thread_t *currentThread = (supr_thread_t *)
		  pthread_getspecific(currentThreadKey);

  taskrunner_env_t *thread_env = (taskrunner_env_t *)
	  malloc(sizeof(taskrunner_env_t));
  pthread_setspecific(taskrunnerThreadKey, thread_env);
  thread_env->isInterrupted = FALSE;

  pthread_mutex_lock(&currentThread->mutex);
    currentThread->state = THREAD_STATE_RUNNABLE;
  pthread_mutex_unlock(&currentThread->mutex);

#define __USE_SIGINT__
#ifdef  __USE_SIGINT__
  {
    struct sigaction sa;
    //sa.sa_sigaction = myTryEval_SigactionInt;
    sa.sa_sigaction = C_Taskrunner_SigactionInt;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, NULL);
  }
#endif

  void *sync_monitor[] = {&ft_task_mutex, &ft_task_cond}; // for now ...
  task_t *task = NULL; // ???

  // run as file transfer
  pthread_mutex_t *task_mutex_ptr;
  pthread_cond_t  *task_cond_ptr;
  vector_t *tasks;
  if(executor){
    task_mutex_ptr = &backend_task_mutex;
    task_cond_ptr = &backend_task_cond;
    tasks = backend_tasks;
  } else {
    task_mutex_ptr = &ft_task_mutex;
    task_cond_ptr = &ft_task_cond;
    tasks = ft_tasks;
  }

  //{
  while(TRUE){
      task = NULL;
      pthread_mutex_lock(task_mutex_ptr);
      /*
        pthread_mutex_lock(&currentThread->mutex);
          currentThread->state = THREAD_STATE_WAITING;
          currentThread->data  = sync_monitor;
        pthread_mutex_unlock(&currentThread->mutex);
	*/

        if(vectorSize(tasks)) task = (task_t *) vectorRemove(tasks, 0);


        if(!task){
          pthread_cleanup_push(taskrunner_lock_cleanup, task_mutex_ptr);//
            pthread_cond_wait(task_cond_ptr, task_mutex_ptr);
          pthread_cleanup_pop(FALSE);

	    /*
        pthread_mutex_lock(&currentThread->mutex);
          currentThread->state = THREAD_STATE_RUNNABLE;
          currentThread->data  = NULL;
        pthread_mutex_unlock(&currentThread->mutex);
	*/

            if(vectorSize(tasks)) task = (task_t *) vectorRemove(tasks, 0);
	}

      pthread_mutex_unlock(task_mutex_ptr);

      while(task){
        //task->run(task->data);
	pthread_setspecific(interruptThreadKey, NULL);
        task->run(task);
	/*
	if(executor){
          pthread_mutex_lock(&executor->mutex);
            pthread_cond_signal(&executor->cond);
          pthread_mutex_unlock(&executor->mutex);
	}
	if(task->){
          pthread_mutex_lock(&executor->mutex);
            pthread_cond_signal(&executor->cond);
          pthread_mutex_unlock(&executor->mutex);
	}
	*/
        task = NULL;

        pthread_mutex_lock(task_mutex_ptr);
          if(vectorSize(tasks)){
            task = (task_t *) vectorRemove(tasks, 0);
          } else {
            task = NULL;
          }
        pthread_mutex_unlock(task_mutex_ptr);

      }
  }
  //}

  free(vectorRemove(stacktrace, vectorSize(stacktrace)-1));

  pthread_cleanup_pop(TRUE);
}

extern void SO_print(so_t* s);

void backend_2_cleanup(void *data){
  basic_info(__func__);
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;
}
//void backend_io_run(shm_io_info_t *io)
void backend_2_run(shm_io_info_t *io)
{
  pthread_cleanup_push(backend_2_cleanup, NULL);
  supr_thread_t *cth = currentThread();

  /*
  char shm_name[256];
  sprintf(shm_name, "sdfs.%d.%d", geteuid(), cth->pid);
  size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
  shm_io_info_t *io = shm_io_create(shm_name, block_size);
  */

  char cwd[PATH_MAX];
  getcwd(cwd, PATH_MAX);

  while(TRUE){

    size_t size;
    void *ptr = shm_io_read(io, io->in, &size, NULL);

    int cmd = ((int*)ptr)[0];
    switch(cmd){
      case DFS_DD_GET:
	   {
	     printf("\033[031m[%s] GET: %s\033[0m\n", __func__,
			     (char*) (ptr+INT_SIZE));
	     char *dd_name = (char*) (ptr+INT_SIZE);
	     char *subset_name = dd_name + strlen(dd_name);
	     for(;subset_name != dd_name; subset_name--){
	       if(*subset_name == '/'){
                  *subset_name = 0;
		  subset_name ++;
		  break;
	       }
	     }
	     if(subset_name == dd_name){
	       char err[256];
	       sprintf(err+INT_SIZE, "Invalid arguments");
	       *((int *) err) = -1;
	       shm_io_write(io, io->out, &err,
			       INT_SIZE + strlen(err+INT_SIZE)+1);
	       break;
	     }

	     pthread_mutex_lock(ddEnvironment->mutex);
	     dd_t *dd = (dd_t*) Hashtable_get(ddEnvironment, dd_name);
	     pthread_mutex_unlock(ddEnvironment->mutex);
	     if(!dd){ 
	       char err[256];
	       *((int *) err) = -1;
	       sprintf(err+INT_SIZE, "Cannot find DD '%s'", dd_name);
	       shm_io_write(io, io->out, &err,
			       INT_SIZE + strlen(err+INT_SIZE)+1);
	       break;
	     }
	     pthread_mutex_lock(dd->values->mutex);
	     so_t *so = (so_t*) Hashtable_get(dd->values, subset_name);
	     pthread_mutex_unlock(dd->values->mutex);
	     if(!so){
	       char err[256];
	       *((int *) err) = -1;
	       sprintf(err+INT_SIZE, "Cannot find subset '%s'", subset_name);
	       shm_io_write(io, io->out, &err,
			       INT_SIZE + strlen(err+INT_SIZE)+1);
	       break;
	     }
	     printf("\033[0;31m"); SO_print(so); printf("\033[0m");

	     switch(so->mem_type){
	       case SUPR_MEMTYPE_SHM:
	       case SUPR_MEMTYPE_TMP:
	            printf("\033[0;31mFile: %s\033[0m\n", (char*)so->val);

	       case SUPR_MEMTYPE_MEM:
	            shm_io_write(io, io->out, so, sizeof(so_t) + so->size);
		    break;

	       case SUPR_MEMTYPE_FILE:
#ifdef USE_MULTI_DIRS
		    {
		      int dir_idx = so->sys_type;
		      char *dir_path = DD_DIR_PATH(dir_idx);

		      char pathname[sizeof(so_t)+strlen(dir_path)+strlen("/data/")
			     + strlen(dd_name)+strlen(subset_name)+2];
		      sprintf(pathname+sizeof(so_t), "%s/data/%s/%s",
				      dir_path, dd_name, subset_name);
		      memcpy(pathname, so, sizeof(so_t));
		      so = (so_t*) pathname;
		      so->size = strlen(dir_path)+strlen("/data/")
                             + strlen(dd_name)+strlen(subset_name)+2;
		      verbose_info(pathname+sizeof(so_t));
	              shm_io_write(io, io->out, so, sizeof(so_t) + so->size);
		    }
#else
		    {
		      char pathname[sizeof(so_t)+strlen(cwd)+strlen("/data/")
			     + strlen(dd_name)+strlen(subset_name)+2];
		      sprintf(pathname+sizeof(so_t), "%s/data/%s/%s",
				      cwd, dd_name, subset_name);
		      memcpy(pathname, so, sizeof(so_t));
		      so = (so_t*) pathname;
		      so->size = strlen(cwd)+strlen("/data/")
                             + strlen(dd_name)+strlen(subset_name)+2;
	              printf("\033[0;31mFile: %s\033[0m\n", pathname+sizeof(so_t));
	              shm_io_write(io, io->out, so, sizeof(so_t) + so->size);
		    }
#endif
		    break;

	       default: 
		    {
	              char err[256];
	              *((int *) err) = -1;
	              sprintf(err+INT_SIZE, "%s", strerror(38));
	              shm_io_write(io, io->out, &err,
			       INT_SIZE + strlen(err+INT_SIZE)+1);
		    }
                    break;
	     }
	   }
	   break;
      default:
	   {
	   printf("\033[031m[%s] Unknown command: %d\033[0m\n", __func__,cmd);
	     int rc = -1;
	     shm_io_write(io, io->out, &rc, INT_SIZE);
	   }
	   break;
    }
  }

  pthread_cleanup_pop(TRUE);
}

void UI_run(shm_io_info_t *io){

  while(TRUE){
    size_t size;
    void *bytes = shm_io_read(io, io->in, &size, NULL);
    int cmd = ((int*)bytes)[0]; 
    printf("[%s] cmd = %d\n", __func__, cmd);

    // BEGIN_R_EVAL:
    SEXP res = R_NilValue;
    BEGIN_R_EVAL();
      // testing
      SEXP raw = PROTECT(allocVector(RAWSXP, size));
      memcpy(DATAPTR(raw), bytes, size); 
      SEXP call = PROTECT(LCONS(install("unserialize"), CONS(raw, null)));
      SEXP val = PROTECT(eval(call, R_GlobalEnv));
    
      printf("\033[0;36m[%s] cmd = %d\n", __func__, cmd);
      PrintValue(val);
      printf("\033[0;36m[%s] cmd = %d\033[0m\n", __func__, cmd);

      const char *func_name = CHAR(asChar(VECTOR_ELT(val,0)));
      SEXP (*func)(SEXP args) = NULL;
      for(int i=sizeof(R_callable_functions)/sizeof(callable_t)-1; i>=0; i--){
        if(strcmp(R_callable_functions[i].name, func_name)==0){ // use qsearch
          func = R_callable_functions[i].func;
	  break;
        }
      }
      printf("\033[0;36m[%s] func = %s\033[0m\n", __func__, func_name);
      printf("\033[0;36m[%s] func = %p\033[0m\n", __func__, func);

      if(func) {
        int errorOccurred;
        res = R_simpleTryEval4(func, VECTOR_ELT(val,1), R_GlobalEnv,
		       	&errorOccurred);
      } else {
        res = R_NilValue; // change it to error 
      }

    END_R_EVAL();
    // END_R_EVAL:

    shm_io_write(io, io->out, bytes, size);
    free(bytes);
  }
}

void *UI_Run(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW, (unsigned long) &data);
  *sth = th;

  /*
  pthread_key_t th_key;
  pthread_key_create(&th_key, thread_destructor);
  pthread_setspecific(th_key, th);
  */


  //supr_socket_conn_t *serverConn = (supr_socket_conn_t *) data;
  //data += sizeof(supr_conn_t *);
 // char *shm_name = (char*) data;
  //int port = ((int*)data)[0];
  shm_io_info_t *io = (shm_io_info_t *)data;
  printf("[%s] io = %p\"\n", __func__, io);

//  supr_socket_conn_t *sock_conn = socketOpen(serverConn);


  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  if(io) UI_run(io);

  threadDestroy(th);
  pthread_exit(th);
  return NULL;
}

void *executorRun(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,(unsigned long) &data);
  *sth = th;

  /*
  pthread_key_t th_key;
  pthread_key_create(&th_key, thread_destructor);
  pthread_setspecific(th_key, th);
  */
  pthread_setspecific(currentThreadKey, th);

  int nTaskrunners = ((int*) data)[0];

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  executor_run(nTaskrunners);

  pthread_exit(th); // FIXME
  return NULL;
}

void *taskrunner_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  //printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_NEW,(unsigned long) &data);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  vector_t *stacktrace = newVector(FALSE);
  pthread_setspecific(stacktraceKey, stacktrace);
  // push
  vectorAdd(stacktrace, strdup(__func__));


  supr_thread_t *executor = (supr_thread_t *) data;

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  taskrunner_run(executor);

  // pop
  free(vectorRemove(stacktrace, vectorSize(stacktrace)-1));
  pthread_exit(th);
  return NULL;
}

void *backend_2_init(void *arg)
{
  void *data = (void*) ((void **)arg)[0];
  //printf("[%s] data = %p\n", __func__, data);
  // data = [serverSocketConn, (int) shm_fd, shm_name]
  sem_t *sem = (sem_t *) ((void **)arg)[1];
  //printf("[%s] sem = %p\n", __func__, sem);
  supr_thread_t **sth = (supr_thread_t **) ((void **)arg)[2];
  //printf("[%s] sth = %p\n", __func__, *sth);

  supr_thread_t *th = newThread(pthread_self(), getpid(),
                  syscall(SYS_gettid), THREAD_STATE_RUNNABLE,
		  (unsigned long) &data);
  *sth = th;

  pthread_setspecific(currentThreadKey, th);

  vector_t *stacktrace = newVector(FALSE);
  pthread_setspecific(stacktraceKey, stacktrace);
  // push
  vectorAdd(stacktrace, strdup(__func__));


  shm_io_info_t *io = (shm_io_info_t *) data;

  pthread_mutex_lock(&th->mutex);
    sem_post(sem);
    pthread_cond_wait(&th->cond, &th->mutex);
  pthread_mutex_unlock(&th->mutex);

  //while(TRUE){
  //}

  backend_2_run(io);

  // pop
  free(vectorRemove(stacktrace, vectorSize(stacktrace)-1));
  pthread_exit(th);
  return NULL;
}










supr_thread_t *startBackend(int port)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&port, &sem, &sth};
  int rc = pthread_create(&thread, NULL, backend_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

supr_thread_t *startUI(shm_io_info_t *io)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {io, &sem, &sth};
  int rc = pthread_create(&thread, NULL, UI_Run, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

supr_thread_t *startExecutor(int nTaskrunners)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {&nTaskrunners, &sem, &sth};
  int rc = pthread_create(&thread, NULL, executorRun, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}

supr_thread_t *startTaskrunner(supr_thread_t *executor)
{
  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {executor, &sem, &sth};
  int rc = pthread_create(&thread, NULL, taskrunner_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  vectorAdd(threads, sth);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);


  return sth;
}


supr_thread_t *startBackend_2(shm_io_info_t *io)
{

  pthread_t thread;
  sem_t sem;
  sem_init(&sem, 1, 0);
  supr_thread_t *sth = NULL;
  void *arg[] = {io, &sem, &sth};
  int rc = pthread_create(&thread, NULL, backend_2_init, arg);

  sem_wait(&sem);
  sem_destroy(&sem);

  pthread_mutex_lock(&sth->mutex);
    pthread_cond_signal(&sth->cond);
  pthread_mutex_unlock(&sth->mutex);
  
  printf("[%s] rc = %d, sth = %p\n", __func__, rc, sth);

  return sth;
}



void __R_init(int argc, char **argv){

  char *new_argv[] = {argv[0], "--vanilla", "--no-save"};
  int new_argc = sizeof(new_argv)/sizeof(new_argv[0]);

  Rf_initialize_R(new_argc, new_argv);
  void *dummy;
  R_CStackStart = (unsigned long) &dummy;
  R_Interactive = TRUE;  /* Rf_initialize_R set this based on isatty */
  setup_Rmainloop();

  R_thread_init();
}

int isLocalOrNFS(const char *dir_path)
{
  struct statfs buf;
  int rc;
  const char *path[] = {"/etc", "/home", dir_path};

  for(int i=0; i<sizeof(path)/sizeof(char*); i++){

    rc =  statfs(path[i], &buf);

    printf("\n ------------ %s -----------\n", path[i]);
    printf("\nf_type: %lx\n", buf.f_type);
    printf("\nf_bsize: %lx  // Optimal transfer block size\n", buf.f_bsize);
    printf("\n");
//    printf("========= EXT2_SUPER_MAGIC: %ld, EXT3_SUPER_MAGIC: %ld =====\n", EXT2_SUPER_MAGIC, EXT3_SUPER_MAGIC);
  }

  return -1; // TO DO

}


int setDir(const char *dir_path, const char *subdir){
  char buf[strlen(dir_path)+strlen(subdir)+2];

  DIR* dir = opendir(dir_path);
  if(!dir){
    printf("[%s] Error: %s\n", __func__, strerror(errno));
    return -1;
  } else {
    struct dirent *dp;
    while((dp = readdir (dir))){
      printf("[%s] %s\n", __func__, dp->d_name);
    }
    closedir(dir);
  }

  sprintf(buf, "%s", dir_path);

  char b[strlen(subdir)+2];
  sprintf(b, "%s/", subdir);
  char *s = b;
  while(s && strstr(s, "/")){
    char *name = s;
    s =  strstr(s, "/");
    *s = 0; s++;
    sprintf(buf+strlen(buf), "/%s", name);
    printf("buf::: %s\n", buf);
    dir = opendir(buf);
    if(!dir){ // create
      if(mkdir(buf, 0700)==-1){
        printf("[%s] Error: mkdir, %s\n", __func__, strerror(errno));
	return -1;
      } else 
        printf("[%s] mkdir(%s, 0700)\n", __func__, buf);
    } else {
      closedir(dir);
    }
  }

  printf("s::: %s\n", s);

  sprintf(buf, "%s/%s", dir_path, subdir); 
  printf("[chdir]: %s\n", buf);
  int rc = chdir(buf);
  if(rc == -1)
     printf("[%s] Error: chdir(%s), %s\n", __func__, buf, strerror(errno));
  return rc;
}

int restart(int argc, char** argv);

void REPL_cleanup(void *data){
  basic_info(__func__);
  supr_thread_t *cth = SUPR_CURRENT_THREAD();
  cth->state = THREAD_STATE_TERMINATED;

  sleep(1);
  basic_info("EXIT_SUCCESS");
  exit(EXIT_SUCCESS);
}

void  R_REPL(supr_thread_t *this_thread, int argc, char**argv)
{
  pthread_cleanup_push(REPL_cleanup, NULL);



  while(TRUE){
    if(Supr_debug){
      double timeout = 5*Supr_options.timeout;

      struct timespec wait;
      clock_gettime(CLOCK_REALTIME, &wait);
      wait.tv_sec += (long) timeout;

      int rc;

      pthread_mutex_lock(&this_thread->mutex);

	char buf[256], buf0[128];
	char *s = argv[0]; while(strstr(s, "/")) s = strstr(s, "/") + 1;
	sprintf(buf, "%s: HEARTBEAT, pid: %d, %s", s,
		getpid(), Exec_timestamp(buf0, sizeof(buf0)));
        basic_info(buf);

        rc = pthread_cond_timedwait(&this_thread->cond, &main_thread->mutex, &wait);

        if(this_thread->data == PTHREAD_INTERRUPTED) exit(EXIT_SUCCESS);

      pthread_mutex_unlock(&this_thread->mutex);
    } else {
      pthread_mutex_lock(&this_thread->mutex);
        if(Supr_verbose) {
	  char buf[256], buf0[128];
	  char *s = argv[0]; while(strstr(s, "/")) s = strstr(s, "/") + 1;
	  sprintf(buf, "%s: HEARTBEAT, pid: %d, %s", s,
		getpid(), Exec_timestamp(buf0, sizeof(buf0)));
          Cluster_sendSimpleMessage(buf, "\033[0;35m", VERBOSE_INFO_TYPE, 0);
	}

        int rc = pthread_cond_wait(&this_thread->cond, &main_thread->mutex);

        if(this_thread->data == PTHREAD_INTERRUPTED) exit(EXIT_SUCCESS);

      pthread_mutex_unlock(&this_thread->mutex);
    }
  }

  pthread_cleanup_pop(TRUE);
}

struct sigaction R_oldSegvAct;


void Datanode_SigactionAbort(int sig, siginfo_t *ip, void *context)
{
	/*
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
		  pthread_self(), getpid(), syscall(SYS_gettid));
		  */

  sleep(440);
}

void  Datanode_SigactionSegv(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s] pid=%d, tid=%ld\033[0m\n",    
                    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }

  sleep(180);
  exit(1); 
}

void  Datanode_SigactionSIGPIPE(int sig, siginfo_t *ip, void *context)
{
  fprintf(stderr, "\033[0;31m\n%s pid=%d, tid=%ld\033[0m\n", __func__,
                  getpid(), syscall(SYS_gettid));
  fprintf(stderr, "ip->si_fd: %d\n", ip->si_fd);

  /* TODO...
  if(info_addr){
    info_sc = socketOpen1(info_addr); // FIXME
    sprintf(msg, "\033[0;31m\n[%s] pid=%d, tid=%ld\033[0m\n",    
                    __func__, getpid(), syscall(SYS_gettid));
    Supr_debug = TRUE;
    Cluster_sendSimpleMessage(msg, msg_color, DEBUG_INFO_TYPE, 0);

    char *buf= NULL;
    Supr_debug2(getpid(), &buf); // TODO
    if(buf)
      Cluster_sendSimpleMessage(buf, msg_color, DEBUG_INFO_TYPE, 0);

    free(buf);
  }
  */

  sleep(120);
  exit(1); 
}

void  Datanode_SigactionSIGINT(int sig, siginfo_t *ip, void *context)
{
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mpthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
		  pthread_self(), getpid(), syscall(SYS_gettid));

  sleep(120);
  exit(1);
}

void  Datanode_SigactionSIGUSR1(int sig, siginfo_t *ip, void *context)
{
  static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31msig: SIGUSR1 pthread_self() = %ld, pid=%d, tid=%ld\033[0m\n",
		  pthread_self(), getpid(), syscall(SYS_gettid));
  //c_backtrace();


  supr_thread_t *cth = currentThread();
  pthread_mutex_lock(&cth->mutex);
    void *save = cth->data;
    vector_t *stacktrace = (vector_t *) pthread_getspecific(stacktraceKey);
    pthread_mutex_lock(&mutex);
    for(int i=0; i<vectorSize(stacktrace); i++){
      printf("\t%s\n", (char*) vectorElementAt(stacktrace,i));
    }
    pthread_mutex_unlock(&mutex);
    cth->data = save;
  pthread_mutex_unlock(&cth->mutex);


}

// UserInterrupt
void  Datanode_SigactionSIGUSR2(int sig, siginfo_t *ip, void *context)
{
  static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  printf("\n\033[0;31m>>>>>>>>>>>>>>>>    %s    <<<<<<<<<<<<<<<<<<\033[0m\n\n",
                  __func__);

  printf("\033[0;31mPTHREAD_INTERRUPTED: %p\033[0m\n", PTHREAD_INTERRUPTED);
  pthread_setspecific(interruptThreadKey, PTHREAD_INTERRUPTED);


}


// Re-do sigaction?
/*
void  Datanode_sigaction(int sig, siginfo_t *ip, void *context)
{
  if(sig == SIGPIPE){
  }
}
*/

int restart(int argc, char **argv)
{
	return -1;

  char *dir_suffix = "00";
  if(argc>1) dir_suffix = argv[1];




  // start a process by calling system ...
 
  pid_t pid = getpid();
  /*
  pid_t pid = fork();
  if(pid) {

    fprintf(stderr, "%s: proc %d is to run \"%s\"\n", __func__, pid, dir_suffix);
    //return pid;
    exit(0);
  }
  */


  fprintf(stderr, "%s: proc %d is to run \"%s\"\n", __func__, pid, dir_suffix);

  char DFS_CMD_PATH[PATH_MAX];
  sprintf(DFS_CMD_PATH, "/home/outlier/u43/chuanhai/supr/src/dfs_monitor");

  int rc = execl(DFS_CMD_PATH, "dfs_monitor", dir_suffix, (char*) NULL);
  fprintf(stderr, "%s: proc %d is to run \"%s\"\n", __func__, pid, dir_suffix);
  fprintf(stderr, "%s: [pid=%d] rc = %d\n", __func__, pid, rc);
  return rc;

}

void doCleanup()
{
  printf("[%s] is called\n", __func__);
  /*
  if(shm_names){
    for(int i=vectorSize(shm_names)-1; i>=0; i--){
      char *name = (char*) vectorRemove(shm_names, i);
      shm_unlink(name);
    }
    Vector_destroy(shm_names);
    shm_names = NULL;
  }
  */
}

/*
void startStdlog(char *CWD_PATH)
{
    Supr_stdlog_filename = (char*)
	    malloc(strlen(CWD_PATH)+strlen("stdlog.txt")+2);
    sprintf(Supr_stdlog_filename, "%s/%s", CWD_PATH, "stdlog.txt"); 
    fprintf(stderr, "stdlog.txt: %s\n", Supr_stdlog_filename);
    unlink(Supr_stdlog_filename);
    stdlog = fopen(Supr_stdlog_filename, "a+");
    if(stdlog == NULL)
      fprintf(stderr, "Error: %s, %s\n", Supr_stdlog_filename, strerror(errno));
    Supr_stdlog_fileno = fileno(stdlog);

    char time_buf[256];
    fprintf(stdlog, "Started at %s\n", Exec_timestamp(time_buf, 256));
}
*/


//extern SEXP SuprContect_cleanup(SEXP args);
extern int SocketConn_cleanup(const char *service, int port);

extern void runAsDaemon(char *dir);





void MultiDir_print()
{
  if(!dir_array) return;

  for(int i=0; i<dir_array->ndir; i++){
    fprintf(stdout, "%d. fd: %d, path: %s\n", (i+1), dir_array->dirs[i].fd,
		    dir_array->dirs[i].path);
  }
}

void MultiDir_create(char *dir, char *next_line)
{
  //printf("\033[0;36mnamenode_spec: %s\n%s\033[0m\n", Supr_hostname, dir);

  int ndir = 1; // dir
  char *line = strtok(next_line, "\n");
  for(; strstr(line, "file"); line = strtok(NULL, "\n"))
	    ndir++;
    
  //printf("\033[0;36mnamenode_spec: ndir: %d\033[0m\n", ndir);

  dir_array = (dir_array_t *) malloc(sizeof(dir_array_t) + 
		  ndir * sizeof(datanode_dir_t));
  dir_array->ndir = ndir;
  int i=0;
  dir_array->dirs[i].fd = -1;
  dir_array->dirs[i].path = strdup(dir);
  i++;
  for(; i<ndir; i++){
    line = next_line;

  //printf("\033[0;36mline: %s\033[0m\n", line);
  //printf("\033[0;36m &: %ld\033[0m\n", (unsigned long) (&dir_array->dirs[i+1].fd) -(unsigned long) (&dir_array->dirs[i].fd));

    next_line += strlen(line)+1;
    line = strstr(line, "//");
    if(!line || strlen(line)==0){
      fprintf(stderr, "invalid specification of datanode directory\n");
      exit(EXIT_FAILURE);
    }
    line += 2;
    char *s = line + strlen(line)-1;
    while(s != line && (*s==' ' || *s=='\t')) s--;
    s++; *s = 0;
    dir_array->dirs[i].fd = -1;
    dir_array->dirs[i].path = strdup(line);
  }

  for(int i=ndir-1; i>=0; i--){
    char path[PATH_MAX];
    sprintf(path, "%s/data", dir_array->dirs[i].path);
    int rc = __mkdir__(path);
    //printf("\033[0;36mirc: %d, dir: %s\033[0m\n", rc, path);
    //setDir(SUPR_DFS_HOMEUSR, buf);
  }

}


// Importing the POSIX regex library
#include <regex.h>
//const char *__regex_spec = "Datanode //[:word:]:[:number:]";
//const char *__regex_spec = "Datanode";

//char *__regex_spec = "Datanode[ \t\n]*//[a-zA-Z0-9][a-zA-Z0-9\\-\\.]*"
//	"[ \t\n]*:[ \t\n]*[0-9]*[ \t\n]*?[ \t\n]*data[ \t\n]*="
//	"[ \t\n]*{[^}]*}";

//char *__regex_spec = "Datanode[ \t\n]*//[a-zA-Z0-9][a-zA-Z0-9\\-\\.]*"
//	":[0-9]*[ \t]*\n"
//	"\\([ \t]\\+file://[^\n]*\n\\)*";


/*
           typedef struct {
               regoff_t rm_so;
               regoff_t rm_eo; //relative to rm_so
           } regmatch_t;
*/
  // ValidHostnameRegex = "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$";

//  hostname = "\\(\\([a-zA-Z0-9][a-zA-Z0-9\\-\\.]*\\)\\|\\(adhara5.stat.purdue.edu\\)\\)";
//  const char *format = "%s[ \t]*//%s:[0-9]*[ \t]*\n\\([ \t]\\+file://[^\n]*\n\\)*";


static char *DFSDatanodeDir_strerror = NULL;

char *DFSDatanodeDir(int argc, char **argv)
{
  Cluster_sendSimpleMessage("usrhome:", "\033[0;35m", DEBUG_INFO_TYPE, 0);
  Cluster_sendSimpleMessage(Supr_usrHome, "\033[0;35m", DEBUG_INFO_TYPE, 0);

  if(!Supr_usrHome)
    Supr_usrHome = getenv("SUPR_USR_HOME"); // FIXME

  char path[PATH_MAX];
  struct stat sb;
  if(!Supr_usrHome) {
     char *home = getenv("HOME"); // FIXME
     if(!home){
           fprintf(stderr, "No home directory is avialable");
	   DFSDatanodeDir_strerror =strdup("No home directory is avialable");
           return NULL;
     }
     sprintf(path, "%s/.supr", home);
     if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
       Supr_usrHome = strdup(path);
     else if(mkdir(path, 0700) != -1)
       Supr_usrHome = strdup(path);
  }

  Cluster_sendSimpleMessage("usrhome:", "\033[0;35m", DEBUG_INFO_TYPE, 0);
  Cluster_sendSimpleMessage(Supr_usrHome, "\033[0;35m", DEBUG_INFO_TYPE, 0);

  if(!Supr_usrHome) {
           fprintf(stderr, "No usrhome is avialable");
	   DFSDatanodeDir_strerror =strdup("No usr.home is avialable");
           return NULL;
  }

  
  if(Supr_dfsHome && strcmp(Supr_dfsHome, Supr_usrHome)){
    fprintf(stderr, "[%s] Warning: Supr_dfsHome != Supr_usrHome\n", __func__);
    fprintf(stderr, "\tSupr_dfsHome: %s\n", Supr_dfsHome);
    fprintf(stderr, "\tSupr_usrHome: %s\n", Supr_usrHome);
    fprintf(stderr, "\tSupr_usrHome is used\n");
  }


  // check supr.conf
  sprintf(path, "%s/supr.conf", Supr_usrHome);

  Cluster_sendSimpleMessage("Read supr.conf...", "\033[0;35m", DEBUG_INFO_TYPE, 0);


  int fd = open(path, O_RDONLY);
  //struct stat sb;
  if(fd != -1 && fstat(fd, &sb) != -1) {
    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    buf[sb.st_size] = 0;
    close(fd);
    char *namenode_spec = NULL;

    printf("\033[0;35m%s\033[0m\n", Supr_hostname);
    char *line = strstr(buf, "Datanode");
    for(; line; line = strstr(line, "Datanode")){
      char *s = strstr(line, "\n");
      *s = 0;
      printf("\033[0;31m%s\033[0m\n", line);
      if(strstr(line, Supr_hostname)){
        *s = '\n';
        namenode_spec = line;
	break;
      }
      line = s+1;
    }

    if(!namenode_spec){
      error_info("cannot find Datanode configuration for '%s'"
        " in supr.conf: %s", Supr_hostname, path);
      return NULL;
    }



    char *namenode_dir = NULL;
    //if(namenode_spec && strstr(namenode_spec,"?data={"))
    if(namenode_spec)
    {
	          char *s = strstr(namenode_spec,"{");
      if(!s) {
        s = strstr(namenode_spec,"\n");
        if(s) *s = 0;
        error_info("%s: expected '{' in line '%s'", path, namenode_spec);
        return NULL;
      }
      s = strstr(s,"}");
      if(!s) {
        s = strstr(namenode_spec,"\n");
        if(s) *s = 0;
        error_info("%s: expected '}' after '%s'", path, namenode_spec);
        return NULL;
      } else {
              s++;
              *s = 0;
      }


      //char *s = strstr(namenode_spec,"\n");
      s = strstr(namenode_spec,"{") + 1;
      while(*s && (*s == ' ' || *s == '\n' || *s == '\r' || *s == '\t'))
              s++;

      char *dir = NULL;
      if(strncmp(s, "file", strlen("file"))==0) {
        namenode_dir = strstr(s, "//")+2;
        s = strstr(namenode_dir, "\n");
	char *next_line = s+1;
        if(s) *s = 0;
        s = namenode_dir;
        while(*s && *s != ' ' && *s != '\t') s++;
        *s = 0;

        memcpy(path, namenode_dir, strlen(namenode_dir)+1);
        if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
          dir = strdup(path);
        else if(mkdir(path, 0700) != -1) // not recursive
          dir = strdup(path);

	if(dir){
	  MultiDir_create(dir, next_line);
	  return dir;
	}
      } else {
	//char login_r[256];
//  basic_info("OKAY 0031");
        //int rc = getlogin_r(login_r, sizeof(login_r));
//  basic_info("OKAY 0033, rc: %d", rc);
        //if(rc != 0) {
          //error_info("getlogin_r, %s", strerror(rc));
          //error_info("getlogin_r, %s", strerror(errno));
        //} else {

          char *__tmp = getenv("SUPR_DFS_DATADIR");
	  if(!__tmp) __tmp = "/tmp";

          sprintf(path, "%s/supr-%s", __tmp,  Supr_username);
          //basic_info("dfs_data root dir: %s", path);

	  int rc;
          if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode)) {
	  }else{
            rc = mkdir(path, 0700);
            if(rc == -1)
              basic_info("Warning in mkdir(%s): %s", path, strerror(errno));
	  }

          sprintf(path, "%s/supr-%s/dfs_data-%s", __tmp,
			  Supr_username,Supr_hostname);

          if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode)) {
	  } else {
            rc = mkdir(path, 0700);
            if(rc == -1)
              basic_info("Warning in mkdir(%s): %s", path, strerror(errno));
	  }

          if(stat(path, &sb) != -1 && S_ISDIR(sb.st_mode))
	  {
            verbose_info("dfs_data dir: %s", path);
            return strdup(path);
	  }
        //}

      }
    }
  } else {
      char buf[strlen(path)+128];
      sprintf(buf, "[%s:%d] Warning: cannot read %s", __FILE__, __LINE__, path);
      Cluster_sendSimpleMessage(buf, "\033[0;35m", DEBUG_INFO_TYPE, 0);
  }

  sprintf(path, "%s/%s", Supr_usrHome, SYS_COMMAND_DFS_DATANODE);

  if(stat(path, &sb) == -1) {

    {
      char buf[strlen(path)+128];
      sprintf(buf, "[%s:%d] mkdir(%s, 0700)", __FILE__, __LINE__, path);
      Cluster_sendSimpleMessage(buf, "\033[0;35m", DEBUG_INFO_TYPE, 0);
    }

    if(mkdir(path, 0700) == -1){
      perror(path);
      DFSDatanodeDir_strerror =strdup(path);
      return NULL;
    }

  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    char buf[strlen(path)+128];
    sprintf(buf, "Error: %s is not a directory", path);
    DFSDatanodeDir_strerror =strdup(buf);
    return NULL;
  }


  char *dir_suffix = "_0";
  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-dir")==0 && i < argc-1){
        dir_suffix = argv[++i];
        break;
    }
  }

  sprintf(path + strlen(path), "/%s%s", Supr_hostname, dir_suffix);


  if(stat(path, &sb) == -1) {
    {
      char buf[strlen(path)+128];
      sprintf(buf, "[%s:%d] mkdir(%s, 0700)", __FILE__, __LINE__, path);
      Cluster_sendSimpleMessage(buf, "\033[0;35m", DEBUG_INFO_TYPE, 0);
    }

    if(mkdir(path, 0700) == -1){
      perror(path);
      DFSDatanodeDir_strerror =strdup(path);
      return NULL;
    }
  } else if(!S_ISDIR(sb.st_mode)) {
    fprintf(stderr, "Error: %s is not a directory", path);
    char buf[strlen(path)+128];
    sprintf(buf, "%s is not a directory", path);
    DFSDatanodeDir_strerror =strdup(buf);
    return NULL;
  }

  return strdup(path);
}


extern void Supr_killall(char *name);

#define SHM_CLEANUP
#ifdef  SHM_CLEANUP
void Shm_cleanup()
{
  char cmd[256];
  sprintf(cmd, "rm /dev/shm/sdfs.%d.*", geteuid());
  int rc = system(cmd);
  printf("system(\"%s\"): %d\n", cmd, rc);
}
#endif

char *cmd_is_running(const char *cmd, char **file_name_addr){
  char path[PATH_MAX];
  getcwd(path, PATH_MAX);
  char *log = NULL;
  while(strstr(cmd, "/")) cmd = strstr(cmd, "/") + 1;
  sprintf(path+strlen(path), "/%s.log", cmd);
  *file_name_addr = strdup(path);
  if(access(path, F_OK)==0){
    struct stat statbuf;
    int fd = open(path, O_RDONLY);
    int rc = fstat(fd, &statbuf);
    if(rc==0 && fd !=-1){
      log = malloc(statbuf.st_size+1);
      read(fd, log, statbuf.st_size);
      log[statbuf.st_size] = 0;
    }
    close(fd);
  }

  return log;
}

static char *getDefaultDatanodeAddr(){
  char path[PATH_MAX];
  sprintf(path, "%s/supr.conf", Supr_usrHome);
  struct stat sb;
  int fd = open(path, O_RDONLY);
  if(fd != -1 && fstat(fd, &sb) != -1) {

    char buf[sb.st_size+1];
    read(fd, buf, sb.st_size);
    buf[sb.st_size] = 0;
    close(fd);

    char *s = buf;
    while((s = strstr(s, "Datanode")) && (s = strstr(s, "//"))){
      char *t = strstr(s, "\n") + 2;
      if(t) {*t=0; t++;}
      if(strstr(s, Supr_hostname)){
         s = strdup(s);
         break;
      }
      s = t;
    }

    if(s) return s;
  }

  char buf[strlen(Supr_hostname)+32];
  sprintf(buf, "%s:1024+", Supr_hostname);
  return strdup(buf);
}

static const char *__doc__ ="  "
"dfs_data [-port n] [--verbose] [--debug] [--info] [--help]\n"
"\t[-nn addr] [-info addr] [-notify addr]"; 


/*
void argv_info(int argc, char **argv){
  if(argc<=0) return;

  int len = 0;
  for(int i=0; i<argc; i++) len +=  strlen(argv[i]) + 2;

  char buf[len];
  sprintf(buf, "%s", argv[0]);
  for(int i=1; i<argc; i++)
    sprintf(buf+strlen(buf), "\n\t%s",  argv[i]);
  verbose_info(buf);
  basic_info(buf);
}
*/


/*
// FIXME
extern void Worker_do_ncpu(int ncpu);
extern void Worker_do_xterm(int use_xterm);
*/


/*
void DFSData_do_xterm(int use_xterm){

  static supr_thread_t *gdb_thread = NULL;
  static char *xterm_name = NULL;

  if(use_xterm){
    if(gdb_thread){
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        if(gdb_thread->name) {
	  //
	} else {
          void *ret_val;
          rc = pthread_join(gdb_thread->ptid, &ret_val);
	  // destroy...
	}
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
      gdb_thread = NULL; // FIXME... destroy 
    }

    if(!gdb_thread){ // if(!xterm_name || !gdb_thread)
      Supr_gdb_C(0, TRUE, &gdb_thread, &xterm_name);
      Supr_options.xterm = 1;
      fprintf(stderr, "%s:%d. tid: %d\n\n", __FILE__, __LINE__,
    	gdb_thread->tid);
      sleep(1);
    
// testing
      int rc = pthread_mutex_lock(&gdb_thread->mutex);
        rc = pthread_cond_signal(&gdb_thread->cond);
      rc = pthread_mutex_unlock(&gdb_thread->mutex);
    }

    //fprintf(stderr, "tid: %d, rc: %d\n", gdb_thread->tid, rc);

  } else {
    basic_info("%s(%s): TODO...", __func__, use_xterm? "TRUE":"FALSE");
    xterm_name = NULL;
    if(gdb_thread){
      int rc = pthread_cancel(gdb_thread->ptid);
      fprintf(stderr, "pthread_cancel, rc: %d\n", rc);
      void *ret_val;
      rc = pthread_join(gdb_thread->ptid, &ret_val);
      fprintf(stderr, "pthread_join, rc: %d\n", rc);
      for(int i=0; i<10; i++) fprintf(stderr, "\n");
      gdb_thread = NULL;
    }
    Supr_options.xterm = 0;
  }
}
*/

void DFSData_do_ncpu(int ncpu){
    basic_info("%s(%s): TODO...", __func__, ncpu? "TRUE":"FALSE");
}

int main(int argc, char **argv)
{

  Supr_do_xterm_ptr = Supr_do_xterm;
  Supr_do_ncpu_ptr = DFSData_do_ncpu;

  //proc_cmd = argv[0];
  //while(strstr(proc_cmd, "/")) proc_cmd = strstr(proc_cmd, "/")+1;
  

  main_argv = argv;
  main_argc = argc;
  cmd = argv[0];

  int port = -1;
  //SocketConn_reuseAddr = TRUE;

  for(int i=0; i<argc; i++) fprintf(stdout, "%s\n", argv[i]);
  

  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--verbose")==0){
      Supr_options.verbose = Supr_verbose = TRUE;
    } else if(strcmp(argv[i], "--debug")==0){
      Supr_options.debug = Supr_debug = TRUE;
    } else if(strcmp(argv[i], "--info")==0){
      Supr_options.info = Supr_infov = TRUE;
    } else if(strcmp(argv[i], "-notify")==0 && i + 1 < argc){
       notify_addr = argv[++i];
    } else if(strcmp(argv[i], "-level")==0 && i < argc-1){
       Supr_options.level = atoi(argv[++i]);
    } else if(strcmp(argv[i], "-port")==0 && i < argc-1){
       port = atoi(argv[++i]);
       if(port < 1024) port = 1024;
       nports = strstr(argv[i], "+") ? 0 : 1;
    } else if(strcmp(argv[i], "-X11")==0 && i < argc-1){
       X11_str = argv[++i];
    }
  }

  fprintf(stderr, "OKAY 02\n");

//  char *debug_addr = NULL;
//  int __argc = argc;
  for(int i=0; i<argc; i++){
    //if(strcmp(argv[i], "-db")==0 && i+1 < argc)
    if(strcmp(argv[i], "-info")==0 && i+1 < argc){
      info_addr = strdup(argv[i+1]);
      char *hostname = strdup(info_addr);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      fprintf(stderr, "dfs_data info_addr->port: %d\n", port);
      info_sc = socketOpen2(hostname, port);

      if(info_sc) {
        info_sc->port = port;
        int cmd = CLUSTER_PROC_CMD;
        write(info_sc->fd, &cmd, sizeof(int));
    //    char *proc_cmd = argv[0]; while(strstr(proc_cmd, "/")) proc_cmd = strstr(proc_cmd, "/")+1;
        int len = strlen(proc_cmd)+1;
        write(info_sc->fd, &len, sizeof(int));
        write(info_sc->fd, proc_cmd, len);
        int rc;
        read(info_sc->fd, &rc, sizeof(int));
      }

      Cluster_sendSimpleMessage(argv[0], "\033[0;35m", DEBUG_INFO_TYPE, 0);
      free(hostname);
      break;
    }
  }

  argv_info(argc, argv);
  //basic_info("Supr_options.ncpu: %d", Supr_options.ncpu);

  if(port == -1){

    char *addr = getDefaultDatanodeAddr();

    if(!addr) backend_exit();
    
    port = atoi(strstr(addr, ":")+1);
    nports = strstr(strstr(addr, ":")+1, "+") ? 0 : 1;
    verbose_info("use port in supr.conf: %d%s", port, nports?"":"+");
    free(addr);
  }

  fprintf(stderr, "OKAY 08\n");


  char *nn = NULL;
  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "-namenode")==0 && i+1 < argc){
      nn = argv[i+1];
      char *hostname = strdup(nn);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      info2nn_sc = socketOpen2(hostname, port);
      //debug_sc = info2nn_sc; // FIXME

      parent_sc = info2nn_sc;

      Cluster_sendSimpleMessage(argv[0], "\033[0;35m", VERBOSE_INFO_TYPE, 0);//TODO
      free(hostname);
      break;
    }
  }

  for(int i=0; i<argc; i++) {
    if(info2nn_sc)
      Cluster_sendSimpleMessage2nn(argv[i], "\033[0;35m", VERBOSE_INFO_TYPE, 0);
    else {
      // Cluster_sendSimpleMessage(argv[i], "\033[0;35m", BASIC_INFO_TYPE, 0);
      //verbose_info(argv[i]);
      basic_info(argv[i]);
    }
  }


  for(int i=0; i<argc; i++){
    if(strcmp(argv[i], "--help")==0){
      fprintf(stderr, "%s\n", __doc__);
      char *doc = strdup(__doc__);
      Cluster_sendSimpleMessage(doc, "\033[0;35m", 0, 0);
      free(doc);
      exit(EXIT_SUCCESS);
    }
  }



#ifdef  SHM_CLEANUP
  Shm_cleanup();
#endif

  fprintf(stderr, "%s, pid: %d\n", argv[0], getpid());
#ifdef RUN_AS_DAEMON_PROC

  /*
  sprintf(msg, "\033[0;31m[%s:%d] %s, pid: %d\033[0m\n",
		 __FILE__, __LINE__, argv[0], getpid());
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  Cluster_sendSimpleMessage2nn(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  */

  char *dir = DFSDatanodeDir(argc, argv);
  if(!dir) {

    error_info("\033[0;31m[%s:%d] Error %s in DFSDatanodeDir, %s\033[0m\n",
	 __FILE__, __LINE__, DFSDatanodeDir_strerror, strerror(errno));
    //FIXME...
    //int cmd = CLUSTER_INFO_DISCONNECT;
    //if(info_sc) write(info_sc->fd, &cmd, sizeof(int));
    //if(notify_addr){
      //char buf[strlen(masterServerConn->host)+32];
      //sprintf(buf, "%s:%d", masterServerConn->host, masterServerConn->port);
      //Supr_notify(notify_addr, buf, CLUSTER_CONNECT_MASTER);
    //}
    atexit(send_ExitInfo);
    exit(EXIT_FAILURE);
  }

  //runAsDaemon(SYS_COMMAND_MASTER);
  fprintf(stderr, "%s, pid: %d\n", argv[0], getpid());

  /*
  sprintf(msg, "\033[0;31m[%s:%d] %s, pid: %d\033[0m\n",
		 __FILE__, __LINE__, argv[0], getpid());
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  Cluster_sendSimpleMessage2nn(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  */

  runAsDaemon(dir);

  main_pid = getpid();
  atexit(Shm_cleanup);
  atexit(send_ExitInfo);


  char *cmd_log = NULL;
  char *file_name = NULL;

  pid_t datanode_pid = -1;
  if(cmd_log = cmd_is_running(cmd, &file_name)) {
    basic_info("Warning: %s exists,\n%s", file_name, cmd_log);

    if(strstr(cmd_log, "pid:")){
      pid_t pid = atoi(strstr(cmd_log, "pid:") + 4);
      datanode_pid = pid;
      errno = 0;
      int rc = kill(pid, 0);
      if(rc == 0){
        basic_info("kill(%d, 0): %d, %s", pid, rc, strerror(errno));
      } else if(rc == -1 && errno == ESRCH){
        //sprintf(msg, "kill(%d, 0): %s", pid, strerror(errno));
        //Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
        char path[PATH_MAX];
        //sprintf(msg, "Removing %s", file_name);
        //Cluster_sendSimpleMessage(msg, msg_color, DEFAULT_INFO_TYPE, 0);
        unlink(file_name);
        free(cmd_log);
        free(file_name);
        cmd_log = NULL;
      }
    } else {
      Cluster_sendSimpleMessage("pid not found", msg_color, ERROR_INFO_TYPE, 0);

      basic_info("Removing %s", file_name);
      unlink(file_name);
      free(cmd_log);
      free(file_name);
      cmd_log = NULL;
    }
  }

  if(cmd_log){
    //if(notify_addr) Supr_notify(notify_addr, Supr_hostname, CLUSTER_CONNECT_DFSNAME);
    //
    if(nports){
      for(int i=0; i<main_argc; i++){
        if(strcmp(main_argv[i], "-notify")==0 && i+1 < main_argc) {
          Supr_notify(main_argv[i+1], Supr_hostname, CLUSTER_DFSDATANODE_STARTED);
          break;
        }
      }
  //
      Cluster_sendSimpleMessage("q(\"no\")", msg_color, ERROR_INFO_TYPE, 0);
      fprintf(stderr, "exit(EXIT_FAILURE)\n");
      exit(EXIT_FAILURE);
    } else {
      basic_info("Warning: ignore existing DFS datanode.log: %s", cmd_log);
      fprintf(stderr, "kill(%d, SIGKILL)\n", datanode_pid);
      int rc = kill(datanode_pid, SIGKILL);
      unlink(file_name);
      free(cmd_log);
      free(file_name);
      cmd_log = NULL;
    }
  }


  /*
  sprintf(msg, "\033[0;31m[%s:%d] %s, pid: %d\033[0m\n",
		 __FILE__, __LINE__, argv[0], getpid());
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);
  */
  //Cluster_sendSimpleMessage2nn(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  fprintf(stderr, "\033[0;31m%s, pid: %d\033[0m\n", argv[0], getpid());
  fprintf(stdout, "\033[0;31m%s, pid: %d\033[0m\n", argv[0], getpid());

  sprintf(msg, "\033[0;32m%s, pid: %d\033[0m\n", argv[0], getpid());
  Cluster_sendSimpleMessage(msg, msg_color, VERBOSE_INFO_TYPE, 0);

  //{
  /*
  free(debug_sc); // FIXME;
  debug_sc = NULL;
  free(info_sc); // FIXME
  info_sc = NULL;
  if(FALSE && debug_addr){
      char *hostname = strdup(debug_addr);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      pthread_mutex_lock(&Supr_syncMutex);
        debug_sc = socketOpen2(hostname, port);
      pthread_mutex_unlock(&Supr_syncMutex);
      free(hostname);
      char buf[32];
      sprintf(buf, "Supr_debug: %d", Supr_debug);
      Cluster_sendSimpleMessage(buf, "\033[0;35m", 0, 0);
  }
  */
  //}

  //{
  if(nn){
      char *hostname = strdup(nn);
      char *s = strstr(hostname, ":");
      if(s) *s = 0; s++;
      int port = atoi(s);
      basic_info("Connect namenode //%s:%d ...", hostname, port);
      //pthread_mutex_lock(&Supr_syncMutex);
        info2nn_sc = socketOpen2(hostname, port);
      //pthread_mutex_unlock(&Supr_syncMutex);
      free(hostname);
      //char buf[32];
      //sprintf(buf, "Supr_debug: %d", Supr_debug);
      //Cluster_sendSimpleMessage2nn(buf, "\033[0;35m", 0, 0);
      //Cluster_sendSimpleMessage(buf, "\033[0;35m", 0, 0);
  }
  //}
  //Cluster_sendSimpleMessage(debug_addr, "\033[0;35m", 0, 0);
  //Cluster_sendSimpleMessage(nn, "\033[0;35m", 0, 0);

  char buf[256];
  fprintf(stdout, "\033[0;31mhost: %s, ppid: %d, pid: %d, time: %s\033[0m\n",
                  Supr_hostname, getppid(), getpid(),
                  Exec_timestamp(buf, sizeof(buf)));
  fprintf(stderr, "\033[0;31mhost: %s, ppid: %d, pid: %d, time: %s\033[0m\n",
                  Supr_hostname, getppid(), getpid(),
                  Exec_timestamp(buf, sizeof(buf)));

#endif

#ifdef USE_MULTI_DIRS

  if( !dir_array ){
    dir_array = (dir_array_t *) malloc(sizeof(dir_array_t)
		    +sizeof(datanode_dir_t));
    dir_array->ndir = 1;
    dir_array->dirs[0].fd = -1;
    dir_array->dirs[0].path = dir;
  }

   srandom((unsigned int) getpid());

#endif

  /*
typedef struct datanode_dir_struct {
  int fd; // 
  int padding;
  char *path;
} datanode_dir_t;

typedef struct dir_array_struct {
  int ndir; // number of locations/directories 
  int padding;
  datanode_dir_t dirs[0];
} dir_array_t;
*/

  if(Supr_debug){
    printf("dir: %s\n", dir);
    printf("directories:\n");
    MultiDir_print();
  }


#define SUPR_DEBUG
#ifndef SUPR_DEBUG
  int devNull = open("/dev/null", O_WRONLY);
  int out_fd = dup(STDOUT_FILENO);
  int err_fd = dup(STDERR_FILENO);
  dup2(devNull, STDERR_FILENO);
  dup2(devNull, STDOUT_FILENO);
#endif

  char CWD_PATH[PATH_MAX];
    //getcwd(CWD_PATH, PATH_MAX);
    //printf("cwd: %s\n", CWD_PATH);

  atexit(doCleanup);
  atexit(rmConnLog);

  // FIXME
  void *dummy= NULL;
  PTHREAD_INTERRUPTED = &dummy;
  void *timeout_dummy= NULL;
  PTHREAD_TIMEOUT = &timeout_dummy;

//  __supr_malloc_init__();
  Cluster_sendSimpleMessage("supr_init...", msg_color, VERBOSE_INFO_TYPE, 0);
  supr_init();

  {
     int rc = isatty(STDOUT_FILENO);
     printf("isatty: %d\n", rc);
  }

  UID = geteuid();

  if(!cleanups)
	  cleanups = newVector(TRUE);

#ifdef DEBUG_OPEN_FILES
  ft_conns = newVector(TRUE);
  for(int i=0; i < MAX_FDS; i++) file_names[i] = NULL;
#endif
  /*
  jobs = newVector(TRUE);
  all_jobs = newVector(TRUE);
  */

  char *subdir = NULL;
  {
    char *p = (char*) malloc(strlen(Supr_hostname)+strlen("_0")+2);
    //gethostname(p, 1024);
    sprintf(p, "%s_0", Supr_hostname);
    subdir = strdup(p);
    free(p);
  }

  for(int i=0; i<argc; i++)
  {
    fprintf(stderr, "%s ", argv[i]);
    if(strcmp(argv[i], "-dir")==0 && i < argc-1)
	    subdir = argv[++i];
    else if(strcmp(argv[i], "-namenode")==0 && i < argc-1)
	    DFS_namenodeAddr = argv[++i];
  }
  printf("\n\n");

  printf("[%s] subdir: %s\n", __func__, subdir);
  fprintf(stderr, "DFS_namenodeAddr: %s\n", DFS_namenodeAddr);
  //sleep(5);


  int rc = setpgrp(); // set process group to itself
  if(rc == -1)
  {
      printf("Error: %s\n", strerror(errno));
  }



  char *shm_name = NULL;

  suprHomeInit();
  suprDFSHomeInit();

  // chdir
  //char CWD_PATH[PATH_MAX];
  {
        // check data subdirectory
    getcwd(CWD_PATH, PATH_MAX);
    //printf("[%s] cwd: %s\n", CWD_PATH);

    char data_dir[strlen(CWD_PATH)+strlen("/data")+1];
    sprintf(data_dir, "%s/data", CWD_PATH);
    printf("[%s] data_dir = %s\n", argv[0], data_dir);

    DIR *dir = opendir(data_dir);
    if(!dir){
      if(errno == ENOENT){ // create
        int rc =  mkdir(data_dir, 0700);
        if(rc == -1){
          printf("Error: mkdir(%s), %s\n", data_dir, strerror(errno));
          exit(1);
        }
      } else { // create
        printf("Error: opendir(%s), %s\n", data_dir, strerror(errno));
        exit(1);
      }
    } else {
      closedir(dir);
    }
  }

  //startStdlog(CWD_PATH);

  printf("\033[0;32m\n");
  printf("[deprecated] SUPR_DFS_HOMEUSR: %s\n", SUPR_DFS_HOMEUSR);
  //printf("[deprecated] SUPR_DFS_HOMESYS: %s\n", SUPR_DFS_HOMESYS);
  printf("SUPR_DFS_HOMEUSR: %s\n", Supr_usrHome);
  //printf("SUPR_DFS_HOMESYS: %s\n", Supr_sysHome);
  printf("port: %d\n", port);
  printf("shm_name: %s\n", shm_name);
  printf("\033[0m\n");

  DD_init();

  /*
  {
      char buf[1024];
      snprintf(buf, 1024, "[%d] %s: DD_init()", __LINE__, __func__);
      Cluster_sendSimpleMessage(buf, "\033[0;35m", 0, 0);
  }
  */
  verbose_info("[%d] %s: DD_init()", __LINE__, __func__);

  // open shm_io
  shm_io_info_t *io = NULL;
  if(shm_name){
    io = shm_io_open(shm_name);
    shm_io_write(io, io->out, shm_name, strlen(shm_name)+1);
  }

  SUPR_setSignalHandler(NULL, NULL, NULL);

  syncEnvironment = newHashtable(TRUE);
  waitEnvironment = newHashtable(TRUE);

  ddEnvironment = newHashtable(TRUE);

  threads = newVector(TRUE);

  executors = newVector(TRUE); // change executors to file_tranfers?

  // initialized R_eval
  __R_init(argc, argv);

#ifndef SUPR_DEBUG
  dup2(out_fd, STDOUT_FILENO);
  dup2(err_fd, STDERR_FILENO);
#endif

  
  {
    struct sigaction sa;
    sa.sa_sigaction = Datanode_SigactionSIGUSR1;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
  }

  {
    struct sigaction sa;
    sa.sa_sigaction = Datanode_SigactionSIGUSR2;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGUSR2, &sa, NULL);
  }
  // for debug ...
  {
    struct sigaction sa;
    sa.sa_sigaction = Datanode_SigactionSIGINT;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGINT, &sa, NULL);
  }
  {
    struct sigaction sa;
    sa.sa_sigaction = Datanode_SigactionSegv;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGSEGV, &sa, &R_oldSegvAct);
  }
  {
    struct sigaction sa;
    sa.sa_sigaction = Datanode_SigactionSIGPIPE;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGPIPE, &sa, NULL);
  }
  {
    struct sigaction sa;
    sa.sa_sigaction = Datanode_SigactionAbort;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_ONSTACK | SA_SIGINFO;
    sigaction(SIGABRT, &sa, NULL);
  }

  argc = 2;
  char *cmd_name = argv[0];
  char *new_argv[] = {argv[0], subdir}; 
  argv = new_argv;

#ifdef __USE_LOCAL_GET__
  {
    char shm_name[256];
    sprintf(shm_name, "sdfs.%d.%d", geteuid(), getpid());
    size_t block_size = 8*sysconf(_SC_PAGE_SIZE);
    shm_io_info_t *io = shm_io_create(shm_name, block_size);
    supr_thread_t *shm_th = startBackend_2(io);
    free(shm_th->name);
    shm_th->name = strdup("shm_backend");
    vectorAdd(threads, shm_th);
  }
#endif

  free(main_thread->name);
  main_thread->name = strdup(__func__);

  supr_options_t save_supr_options;
  memcpy(&save_supr_options, &Supr_options, sizeof(supr_options_t));


  {
    SEXP call = PROTECT(LCONS(install("library"),
                           CONS(mkString(PACKAGE_NAME), R_NilValue)));
    eval(call, R_GlobalEnv);
    UNPROTECT(1);
//    basic_info("Supr_options.ncpu: %d", Supr_options.ncpu);
  }

  save_supr_options.ncpu = Supr_options.ncpu;

  memcpy(&Supr_options, &save_supr_options, sizeof(supr_options_t));
  Supr_infov = Supr_options.info;
  Supr_debug = Supr_options.debug;
  Supr_verbose = Supr_options.verbose;

  if(port == -1){

    char *addr = getDefaultDatanodeAddr();

    if(!addr) backend_exit();
    
    port = atoi(strstr(addr, ":")+1);
    nports = strstr(strstr(addr, ":")+1, "+") ? 0 : 1;
    fprintf(stderr, "[%s] default port: %d\n", __func__, port);

    verbose_info("use port in supr.conf: %d", port);
    free(addr);
  }

  //basic_info("port: %d%s", port, nports?"":"+");
  
  pthread_mutex_lock(&main_thread->mutex);
    // start backend
    supr_thread_t *backend = startBackend(port);
    vectorAdd(threads, backend);

    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
    if(main_thread->data == PTHREAD_INTERRUPTED) {
       restart(argc, argv);
    }

    supr_socket_conn_t *conn = (supr_socket_conn_t *)
      vectorElementAt(socket_connections, 0);
    //printf("main:");
    //conn->print(conn);
    if(io) shm_io_write(io, io->out, &conn->port, sizeof(int));

    //parent_sc = trySocketOpen2(conn->host, conn->port);

  pthread_mutex_unlock(&main_thread->mutex);

  // start User interface ?
  //supr_thread_t *ui = startUI(io);
  //vectorAdd(threads, ui);

  // start executor
 
  /*
  int nTaskrunners = 2;
  supr_thread_t *executor = startExecutor(nTaskrunners);
  vectorAdd(threads, executor);
  vectorAdd(executors, executor);
  */

  // start R_eval service -- not really
  R_REPL(main_thread, argc, argv);
  /*
  pthread_mutex_lock(&main_thread->mutex);
    pthread_cond_wait(&main_thread->cond, &main_thread->mutex);
  pthread_mutex_unlock(&main_thread->mutex);
  */
  

  return 0;
}

