# 
# $1.1.5: a .R  (or .r) file, or via a .Rin file containing code which in trun
# creates the corresponding .R file
# ...
# The results of running a .R file are written to a .Rout file.
# If there is a corresponding .Rout.save file, the two are compared ...

print("testing, testing...")
